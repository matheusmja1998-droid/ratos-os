// Facilita SDR — servidor da VPS.
// Webhook da uazapi + API do painel (consumida pelo app na Vercel) + worker de disparo.
// REGRA DE OURO (chip proprio do Matheus): a IA SO responde telefone que existe
// na tabela leads. Qualquer outra conversa do WhatsApp dele e invisivel pro sistema.
import express from "express";
import multer from "multer";
import { execFile } from "node:child_process";
import { mkdirSync, renameSync } from "node:fs";
import { dirname, join, extname } from "node:path";
import { fileURLToPath } from "node:url";
import {
  db, agoraSP, getConfig, setConfig, upsertLead, getLead, getLeadPorTelefone,
  atualizarLead, salvarMensagem, historicoLead, ultimaMensagemUsuario,
  naBlocklist, bloquear, registrarEvento, webhookJaVisto, metricas,
  reunioesAtivas, reuniaoAtivaDoLead, cancelarReuniao, campanhaAtiva, disparosHoje,
  listarInstancias, getInstancia, getInstanciaPorToken, criarInstanciaDB,
  atualizarInstancia, removerInstancia, instanciasConectadas,
  tarefasDoLead, addTarefa, marcarTarefa, removerTarefa,
} from "./lib/db.js";
import {
  parseWebhook, enviarTexto, mostrarDigitando, criarInstancia,
  conectarInstancia, statusInstanciaLive, statusConectado, configurarWebhook, checarWhatsapp,
} from "./lib/uazapi.js";
import { responderLead, horariosDisponiveis } from "./lib/agente.js";
import { alertar } from "./lib/telegram.js";
import { iniciarWorker } from "./worker.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8795);
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || "";
const PAINEL_SENHA = process.env.PAINEL_SENHA || "";
const DELAY_MIN = Number(process.env.DELAY_MIN || 26);
const DELAY_MAX = Number(process.env.DELAY_MAX || 34);
const DADOS_DIR = process.env.DADOS_DIR || join(__dirname, "dados");
mkdirSync(DADOS_DIR, { recursive: true });

const app = express();
app.use(express.json({ limit: "8mb" }));
const upload = multer({ dest: join(DADOS_DIR, "tmp"), limits: { fileSize: 20 * 1024 * 1024 } });

// ---------- CORS (painel na Vercel consome essa API) ----------
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// ---------- auth do painel ----------
// Login email+senha (POST /api/login) troca por um token de sessao (o PAINEL_SENHA
// interno, que continua forte). Freio: 8 tentativas erradas por IP a cada 15min.
import { createHash } from "node:crypto";
const sha = (s) => createHash("sha256").update(String(s)).digest("hex");
const tentativas = new Map(); // ip -> { n, ate }

function auth(req, res, next) {
  if (!PAINEL_SENHA) return res.status(500).json({ erro: "PAINEL_SENHA nao configurada" });
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (token !== PAINEL_SENHA) return res.status(401).json({ erro: "sessao invalida" });
  next();
}

app.post("/api/login", (req, res) => {
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?";
  const t = tentativas.get(ip) || { n: 0, ate: 0 };
  if (t.n >= 8 && Date.now() < t.ate) return res.status(429).json({ erro: "muitas tentativas, espera uns minutos" });
  const { email, senha } = req.body || {};
  // login vem do banco (setado via node/setConfig) OU, em container de cliente
  // provisionado, das envs PAINEL_EMAIL / PAINEL_SENHA_LOGIN (fallback só quando
  // o banco não tem credencial — o login do Matheus na VPS não muda em nada)
  const emailCfg = getConfig("painel_email", "") || String(process.env.PAINEL_EMAIL || "").trim().toLowerCase();
  const hashCfg = getConfig("painel_senha_hash", "");
  const emailOk = String(email || "").trim().toLowerCase() === emailCfg && Boolean(emailCfg);
  const senhaOk = hashCfg
    ? sha(senha || "") === hashCfg
    : (process.env.PAINEL_SENHA_LOGIN ? String(senha || "") === process.env.PAINEL_SENHA_LOGIN : false);
  if (!emailOk || !senhaOk) {
    tentativas.set(ip, { n: t.n + 1, ate: Date.now() + 15 * 60_000 });
    return res.status(401).json({ erro: "email ou senha errados" });
  }
  tentativas.delete(ip);
  res.json({ ok: true, token: PAINEL_SENHA });
});

// ============================================================
// WEBHOOK uazapi
// ============================================================
const OPTOUT_FORTE = /\b(par[ae] de (me )?(mandar|enviar)|remove\w* meu (numero|número|contato)|descadastr|me tir[ae] d)\b/i;
// RECUSA (nao e opt-out): move pra PERDIDO, porta aberta, sem bloquear o numero.
// Cobre: sem interesse, ja tem, nao e o momento, e "a empresa nao e mais alvo"
// (vendendo/fechando/encerrando o negocio).
const RECUSA = /\b(n[aã]o (tenho|temos|há|ha|tem) interesse|n[aã]o (quero|queremos|precisamos|preciso)|sem interesse|n[aã]o obrigad|j[aá] (tenho|temos|uso|usamos|trabalho|trabalhamos)|n[aã]o (é|e) (o )?momento|agora n[aã]o|(estou|estamos|vou|vamos) (vend|fech|encerr|desativ)\w*|(clínica|clinica|empresa|negócio|negocio) (foi )?(vendid|fechad|encerrad)\w*|n[aã]o (atuo|atuamos|trabalho) mais)\b/i;
const debounces = new Map(); // leadId -> { msgId, timer }
const processando = new Set(); // lock por lead

app.post("/webhook", async (req, res) => {
  res.json({ ok: true }); // responde ja (uazapi reenvia sem 200 rapido)
  try {
    if (WEBHOOK_SECRET && req.query.secret !== WEBHOOK_SECRET) { console.log("[webhook] secret errado"); return; }
    const m = parseWebhook(req.body);
    console.log("[webhook]", m ? `${m.telefone} fromMe=${m.fromMe} tipo=${m.tipo} "${(m.texto || "").slice(0, 40)}"` : "payload nao parseado");
    if (!m || m.ehGrupo || m.tipo === "figurinha") return;
    if (webhookJaVisto(m.messageId)) return;

    const lead = getLeadPorTelefone(m.telefone);
    if (!lead) return; // chip proprio: conversa que nao e lead NAO EXISTE pra gente

    // MULTI-WHATSAPP: responde pelo MESMO numero que recebeu (token no payload)
    const tokenPayload = req.body?.token || req.body?.instance || null;
    const instRecebeu = getInstanciaPorToken(tokenPayload) || instanciasConectadas()[0] || null;
    const tokenResposta = instRecebeu?.uazapi_token || getConfig("instancia_token", "");

    // eco da propria IA (mensagem que NOS enviamos volta como fromMe) -> ignora
    if (m.fromMe && m.enviadaPelaApi) return;

    // Matheus respondeu esse lead pelo celular -> humano assumiu, IA pausa
    if (m.fromMe) {
      if (m.texto) salvarMensagem(lead.id, "assistant", m.texto);
      if (!lead.ia_pausada) {
        atualizarLead(lead.id, { ia_pausada: 1 });
        registrarEvento(lead.id, "handoff", "atendente respondeu pelo celular");
      }
      return;
    }

    if (naBlocklist(m.telefone)) return;

    // mensagem do lead
    const texto = m.texto || (m.tipo === "audio" ? "[o lead enviou um áudio que você não consegue ouvir; peça com jeito pra pessoa escrever]" : "[o lead enviou uma mídia que você não consegue abrir]");
    salvarMensagem(lead.id, "user", texto, m.tipo);

    // primeira resposta do lead = evento de funil + status
    if (lead.status === "disparado" || lead.status === "novo") {
      atualizarLead(lead.id, { status: "respondeu" });
      registrarEvento(lead.id, "resposta", "");
    }

    // opt-out mecanico (rede de seguranca alem do agente): bloqueia o numero
    if (OPTOUT_FORTE.test(m.texto || "")) {
      bloquear(lead.telefone, `pediu: "${m.texto.slice(0, 80)}"`); // forma SALVA do numero (casa com o disparo)
      atualizarLead(lead.id, { status: "optout", ia_pausada: 1 });
      registrarEvento(lead.id, "optout", "mecanico");
      const desc = "Tranquilo, não te mando mais nada. Obrigado pelo retorno!";
      const r = await enviarTexto(tokenResposta, m.telefone, desc);
      if (r.ok) salvarMensagem(lead.id, "assistant", desc);
      return;
    }

    // RECUSA clara ("não tenho interesse"): move pra PERDIDO na hora, uma resposta
    // educada de porta aberta, e a IA para (nao fica insistindo). Nao bloqueia.
    if (RECUSA.test(m.texto || "")) {
      atualizarLead(lead.id, { status: "perdido", ia_pausada: 1, motivo_perda: `recusou: "${m.texto.slice(0, 60)}"` });
      registrarEvento(lead.id, "perdido", "recusa mecanica");
      const desc = "Tranquilo! Qualquer coisa no futuro, é só chamar. Abraço!";
      const r = await enviarTexto(tokenResposta, m.telefone, desc);
      if (r.ok) salvarMensagem(lead.id, "assistant", desc);
      return;
    }

    if (lead.ia_pausada) return; // humano no comando

    // DEBOUNCE humanizado: espera ~30s desde a ULTIMA mensagem, com "digitando",
    // e so o handler da ultima mensagem responde (rajada = 1 resposta com contexto todo)
    const msgIdRef = ultimaMensagemUsuario(lead.id);
    const alvoMs = (DELAY_MIN + Math.random() * (DELAY_MAX - DELAY_MIN)) * 1000;
    const antigo = debounces.get(lead.id);
    if (antigo) clearTimeout(antigo.timer);

    const digitando = setInterval(() => mostrarDigitando(tokenResposta, m.telefone), 7000);
    mostrarDigitando(tokenResposta, m.telefone);

    const timer = setTimeout(async () => {
      clearInterval(digitando);
      debounces.delete(lead.id);
      if (ultimaMensagemUsuario(lead.id) !== msgIdRef) return; // chegou msg mais nova
      if (processando.has(lead.id)) return;
      processando.add(lead.id);
      try {
        await responderLead(lead.id, tokenResposta);
      } finally {
        processando.delete(lead.id);
      }
    }, alvoMs);
    debounces.set(lead.id, { msgId: msgIdRef, timer });
  } catch (e) {
    console.error("[webhook] erro:", e);
  }
});

// ============================================================
// API do painel
// ============================================================
app.get("/api/estado", auth, (req, res) => {
  res.json({
    metricas: metricas(),
    instancia: (() => {
      const insts = listarInstancias();
      const con = insts.filter((i) => i.status === "conectado").length;
      return { status: con > 0 ? "conectado" : (insts.length ? "desconectado" : "sem instância"),
               detalhe: `${con}/${insts.length}`, total: insts.length, conectadas: con };
    })(),
    campanha: campanhaAtiva() || null,
    audio_configurado: Boolean(getConfig("audio_oficial")),
    horarios: horariosDisponiveis(),
    agora: agoraSP(),
  });
});

app.get("/api/leads", auth, (req, res) => {
  const { status, busca, incluir_teste } = req.query;
  let sql = "SELECT * FROM leads", cond = [], vals = [];
  if (!incluir_teste) cond.push("eh_teste = 0"); // pipeline/conversas escondem testes
  if (status) { cond.push("status = ?"); vals.push(status); }
  if (busca) { cond.push("(nome_clinica LIKE ? OR telefone LIKE ? OR cidade LIKE ?)"); vals.push(`%${busca}%`, `%${busca}%`, `%${busca}%`); }
  if (cond.length) sql += " WHERE " + cond.join(" AND ");
  sql += " ORDER BY atualizado_em DESC LIMIT 500";
  const leads = db.prepare(sql).all(...vals);
  // anexa a ULTIMA mensagem de cada lead (pra preview no card do pipeline)
  const ultima = db.prepare("SELECT role, texto, criado_em FROM mensagens WHERE lead_id = ? ORDER BY id DESC LIMIT 1");
  const contNotas = db.prepare("SELECT COUNT(*) c FROM notas WHERE lead_id = ?");
  const tarefaAberta = db.prepare("SELECT texto, quando FROM tarefas WHERE lead_id = ? AND feita = 0 ORDER BY COALESCE(quando,'9999') ASC, id ASC LIMIT 1");
  const reengHoras = Number(getConfig("reengajar_horas", "20"));
  const engajados = ["respondeu", "em_conversa"]; // só quem está em conversa (decisor já avançou)
  for (const l of leads) {
    const u = ultima.get(l.id);
    l.ultima_role = u?.role || null;
    l.ultima_msg = u?.texto || null;
    l.qtd_notas = contNotas.get(l.id).c;
    // TAREFA (só pra lead que ENGAJOU; follow-up frio de quem nunca respondeu está desligado):
    // 0) MINHA tarefa manual (ligar pro decisor etc) — vence as automáticas no card
    // 1) follow-up de intermediário agendado pela IA (followup_em)
    // 2) lead quente que ESFRIOU: respondeu, última msg foi nossa, e sumiu -> IA vai reengajar
    const tm = tarefaAberta.get(l.id);
    if (tm) {
      l.tem_tarefa = true; l.tarefa_tipo = "manual";
      l.tarefa_texto = tm.texto; l.tarefa_quando = tm.quando || null;
    } else if (l.followup_em && !l.ia_pausada) {
      l.tem_tarefa = true; l.tarefa_quando = l.followup_em.slice(0, 16); l.tarefa_tipo = "retorno";
    } else if (!l.ia_pausada && !l.reengajado_em && engajados.includes(l.status) && u?.role === "assistant" && !l.telefone_decisor) {
      const horasParado = u.criado_em ? (Date.now() - new Date(u.criado_em + "Z").getTime()) / 3600000 : 0;
      if (horasParado >= reengHoras - 4) { // aparece um pouco antes de disparar
        l.tem_tarefa = true; l.tarefa_tipo = "reengajar"; l.tarefa_quando = null;
        l.horas_parado = Math.round(horasParado);
      } else l.tem_tarefa = false;
    } else l.tem_tarefa = false;
  }
  res.json(leads);
});

app.get("/api/lead/:id", auth, (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ erro: "lead nao existe" });
  const notas = db.prepare("SELECT * FROM notas WHERE lead_id = ? ORDER BY id DESC").all(lead.id);
  const tarefas = tarefasDoLead(lead.id);
  res.json({ lead, mensagens: historicoLead(lead.id, 200), reuniao: reuniaoAtivaDoLead(lead.id) || null, notas, tarefas, resumo: lead.resumo || null });
});

// resumo por IA (cacheado; regenera so se a conversa andou) — chamado sob demanda
app.get("/api/lead/:id/resumo", auth, async (req, res) => {
  try {
    const { resumoDaConversa } = await import("./lib/agente.js");
    res.json({ resumo: await resumoDaConversa(Number(req.params.id)) });
  } catch (e) { res.json({ resumo: null }); }
});

app.patch("/api/lead/:id", auth, (req, res) => {
  atualizarLead(req.params.id, req.body || {});
  res.json({ ok: true, lead: getLead(req.params.id) });
});

app.delete("/api/lead/:id", auth, (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ erro: "lead nao existe" });
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM mensagens WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM reunioes WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM eventos WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM campanha_leads WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM leads WHERE id = ?").run(lead.id);
  });
  tx();
  res.json({ ok: true });
});

// exclusao em massa (todos de um status, ex: limpar "Sem WhatsApp")
app.post("/api/leads/excluir-status", auth, (req, res) => {
  const { status } = req.body || {};
  if (!status) return res.status(400).json({ erro: "status obrigatorio" });
  const ids = db.prepare("SELECT id FROM leads WHERE status = ?").all(status).map((r) => r.id);
  const tx = db.transaction(() => {
    for (const id of ids) {
      db.prepare("DELETE FROM mensagens WHERE lead_id = ?").run(id);
      db.prepare("DELETE FROM reunioes WHERE lead_id = ?").run(id);
      db.prepare("DELETE FROM eventos WHERE lead_id = ?").run(id);
      db.prepare("DELETE FROM campanha_leads WHERE lead_id = ?").run(id);
      db.prepare("DELETE FROM leads WHERE id = ?").run(id);
    }
  });
  tx();
  res.json({ ok: true, excluidos: ids.length });
});

// atendente responde pela tela (IA pausa sozinha)
app.post("/api/lead/:id/mensagem", auth, async (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ erro: "lead nao existe" });
  const texto = String(req.body?.texto || "").trim();
  if (!texto) return res.status(400).json({ erro: "texto vazio" });
  const simulado = String(lead.telefone).startsWith("0000");
  const tokEnvio = instanciasConectadas()[0]?.uazapi_token || "";
  const r = simulado ? { ok: true } : await enviarTexto(tokEnvio, lead.telefone, texto);
  if (!r.ok) return res.status(502).json({ erro: r.erro });
  salvarMensagem(lead.id, "assistant", texto);
  if (!lead.ia_pausada) { atualizarLead(lead.id, { ia_pausada: 1 }); registrarEvento(lead.id, "handoff", "painel"); }
  res.json({ ok: true });
});

app.post("/api/lead/:id/ia", auth, async (req, res) => {
  const lead = getLead(req.params.id);
  if (!lead) return res.status(404).json({ erro: "lead nao existe" });
  const pausar = Boolean(req.body?.pausar);
  atualizarLead(lead.id, { ia_pausada: pausar ? 1 : 0 });
  registrarEvento(lead.id, "handoff", pausar ? "humano assumiu (painel)" : "devolvido pra IA (painel)");
  res.json({ ok: true });

  // DEVOLVEU pra IA -> ela RETOMA a conversa na hora (nao espera o lead responder).
  // Le todo o historico, inclusive o que o humano escreveu no meio, e da sequencia.
  if (!pausar) {
    const ultima = db.prepare("SELECT role FROM mensagens WHERE lead_id = ? ORDER BY id DESC LIMIT 1").get(lead.id);
    // se a ultima foi do lead (esperando resposta) OU foi do humano fechando um gap, a IA continua.
    // se nao ha nada a dizer, o proprio agente devolve acoes vazias e nada e enviado.
    const tokRetomar = instanciasConectadas()[0]?.uazapi_token || "SIMULADO";
    responderLead(lead.id, tokRetomar).catch((e) => console.error("[retomar IA] erro:", e.message));
  }
});

// ---------- reunioes ----------
app.get("/api/reunioes", auth, (req, res) => {
  res.json(db.prepare(`SELECT r.*, l.nome_clinica, l.telefone, l.cidade, l.dor
    FROM reunioes r JOIN leads l ON l.id = r.lead_id ORDER BY r.inicio DESC LIMIT 200`).all());
});
app.patch("/api/reuniao/:id", auth, async (req, res) => {
  const { status } = req.body || {};
  if (!["marcada", "remarcada", "realizada", "no_show", "cancelada"].includes(status))
    return res.status(400).json({ erro: "status invalido" });
  cancelarReuniao(req.params.id, status);
  const r = db.prepare("SELECT * FROM reunioes WHERE id = ?").get(req.params.id);
  if (r) {
    if (status === "no_show") atualizarLead(r.lead_id, { status: "reuniao_marcada" });
    if (status === "realizada") atualizarLead(r.lead_id, { status: "compareceu" });
    if (status === "cancelada" && r.gcal_event_id) {
      const { apagarEventoMeet } = await import("./lib/gcal.js");
      apagarEventoMeet(r.closer, r.gcal_event_id).catch(() => {}); // best-effort
    }
  }
  res.json({ ok: true });
});

// ---------- campanhas ----------
app.get("/api/campanhas", auth, (req, res) => {
  const camps = db.prepare("SELECT * FROM campanhas ORDER BY id DESC").all();
  const hoje = agoraSP().data;
  for (const c of camps) {
    c.templates = db.prepare("SELECT * FROM templates WHERE campanha_id = ?").all(c.id);
    c.total_leads = db.prepare("SELECT COUNT(*) c FROM campanha_leads WHERE campanha_id = ?").get(c.id).c;
    c.disparados = db.prepare("SELECT COUNT(*) c FROM campanha_leads WHERE campanha_id = ? AND disparado_em IS NOT NULL").get(c.id).c;
    c.na_fila = db.prepare(`SELECT COUNT(*) c FROM campanha_leads cl JOIN leads l ON l.id = cl.lead_id
      WHERE cl.campanha_id = ? AND cl.disparado_em IS NULL AND l.status = 'novo'`).get(c.id).c;
    // "hoje" = VOLUME TOTAL de mensagens ativas (disparo + reengajamento + follow-up),
    // que e o que conta pro teto. Assim o X/25 do card bate com o limite real.
    c.disparados_hoje = disparosHoje();
    c.aberturas_hoje = db.prepare(`SELECT COUNT(*) c FROM eventos e JOIN campanha_leads cl ON cl.lead_id = e.lead_id
      WHERE cl.campanha_id = ? AND e.tipo = 'disparo' AND datetime(e.criado_em,'-3 hours') >= datetime(? || ' 00:00')`).get(c.id, hoje).c;
    c.sem_whatsapp = db.prepare("SELECT COUNT(*) c FROM leads WHERE status = 'sem_whatsapp'").get().c;
  }
  res.json(camps);
});

app.post("/api/campanhas", auth, (req, res) => {
  const b = req.body || {};
  if (!b.nome) return res.status(400).json({ erro: "nome obrigatorio" });
  const pct = b.pct_reengajar !== undefined ? Math.max(0, Math.min(100, Number(b.pct_reengajar))) : 30;
  const r = db.prepare(`INSERT INTO campanhas (nome, teto_dia, cadencia_min_seg, cadencia_max_seg, janela_inicio, janela_fim, dias_semana, pct_reengajar)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(
    b.nome, b.teto_dia || 25, b.cadencia_min_seg || 180, b.cadencia_max_seg || 420,
    b.janela_inicio || "08:30", b.janela_fim || "18:00", b.dias_semana || "1,2,3,4,5", pct);
  const id = r.lastInsertRowid;
  for (const t of b.aberturas || []) db.prepare("INSERT INTO templates (campanha_id, tipo, texto) VALUES (?, 'abertura', ?)").run(id, t);
  res.json({ ok: true, id });
});

app.patch("/api/campanha/:id", auth, (req, res) => {
  const b = req.body || {};
  if (b.status) {
    if (b.status === "ativa") db.prepare("UPDATE campanhas SET status = 'pausada' WHERE status = 'ativa'").run(); // 1 ativa por vez
    db.prepare("UPDATE campanhas SET status = ? WHERE id = ?").run(b.status, req.params.id);
  }
  for (const k of ["teto_dia", "cadencia_min_seg", "cadencia_max_seg", "janela_inicio", "janela_fim", "dias_semana", "pct_reengajar"])
    if (b[k] !== undefined) db.prepare(`UPDATE campanhas SET ${k} = ? WHERE id = ?`).run(b[k], req.params.id);
  res.json({ ok: true });
});

// substitui as mensagens (aberturas/follow-ups) de uma campanha existente
app.patch("/api/campanha/:id/templates", auth, (req, res) => {
  const b = req.body || {};
  const tipos = { aberturas: "abertura", followup1: "followup1", followup2: "followup2" };
  for (const [campo, tipo] of Object.entries(tipos)) {
    if (!Array.isArray(b[campo])) continue;
    db.prepare("DELETE FROM templates WHERE campanha_id = ? AND tipo = ?").run(req.params.id, tipo);
    for (const t of b[campo].filter(Boolean))
      db.prepare("INSERT INTO templates (campanha_id, tipo, texto) VALUES (?, ?, ?)").run(req.params.id, tipo, t);
  }
  res.json({ ok: true });
});

// vincula todos os leads status=novo (opcionalmente filtrando cidade) na campanha
app.post("/api/campanha/:id/leads", auth, (req, res) => {
  const { cidade } = req.body || {};
  const leads = db.prepare(`SELECT id FROM leads WHERE status = 'novo' ${cidade ? "AND cidade LIKE ?" : ""}`)
    .all(...(cidade ? [`%${cidade}%`] : []));
  const ins = db.prepare("INSERT OR IGNORE INTO campanha_leads (campanha_id, lead_id) VALUES (?, ?)");
  let n = 0;
  for (const l of leads) n += ins.run(req.params.id, l.id).changes;
  res.json({ ok: true, vinculados: n });
});

// ---------- importar CSV (formato Apify Google Maps ou generico) ----------
function parseCSV(texto) {
  const linhas = [];
  let atual = [], campo = "", aspas = false;
  for (let i = 0; i < texto.length; i++) {
    const c = texto[i];
    if (aspas) {
      if (c === '"' && texto[i + 1] === '"') { campo += '"'; i++; }
      else if (c === '"') aspas = false;
      else campo += c;
    } else if (c === '"') aspas = true;
    else if (c === "," || c === ";") { atual.push(campo); campo = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && texto[i + 1] === "\n") i++;
      atual.push(campo); campo = "";
      if (atual.some((x) => x.trim())) linhas.push(atual);
      atual = [];
    } else campo += c;
  }
  if (campo || atual.length) { atual.push(campo); if (atual.some((x) => x.trim())) linhas.push(atual); }
  return linhas;
}

app.post("/api/importar", auth, upload.single("csv"), async (req, res) => {
  try {
    const { readFileSync, unlinkSync } = await import("node:fs");
    const texto = readFileSync(req.file.path, "utf8");
    unlinkSync(req.file.path);
    const linhas = parseCSV(texto);
    if (linhas.length < 2) return res.status(400).json({ erro: "csv vazio" });
    const header = linhas[0].map((h) => h.trim().toLowerCase());
    const col = (...nomes) => header.findIndex((h) => nomes.includes(h));
    const iNome = col("title", "nome", "name", "nome_clinica");
    const iTel = col("phone", "telefone", "phoneunformatted", "whatsapp");
    const iCidade = col("city", "cidade");
    const iSite = col("website", "site", "url");
    const iNota = col("totalscore", "nota", "rating");
    const iAval = col("reviewscount", "avaliacoes", "reviews");
    const iNicho = col("categoryname", "nicho", "categoria");
    if (iTel === -1) return res.status(400).json({ erro: `coluna de telefone nao achada. header: ${header.join(", ")}` });

    const origem = req.body?.origem || req.file.originalname || "csv";
    let novos = 0, repetidos = 0, semTel = 0;
    for (const l of linhas.slice(1)) {
      let tel = String(l[iTel] || "").replace(/\D/g, "");
      if (!tel) { semTel++; continue; }
      if (tel.length <= 11 && !tel.startsWith("55")) tel = "55" + tel; // BR sem DDI
      const antes = db.prepare("SELECT COUNT(*) c FROM leads").get().c;
      upsertLead({
        nome_clinica: l[iNome] || "Clínica", telefone: tel,
        cidade: iCidade >= 0 ? l[iCidade] : null, site: iSite >= 0 ? l[iSite] : null,
        nota: iNota >= 0 ? l[iNota] : null, avaliacoes: iAval >= 0 ? l[iAval] : null,
        nicho: iNicho >= 0 ? l[iNicho] : null, origem_lista: origem,
      });
      db.prepare("SELECT COUNT(*) c FROM leads").get().c > antes ? novos++ : repetidos++;
    }
    res.json({ ok: true, novos, repetidos, semTel });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// ---------- audio oficial ----------
app.post("/api/audio", auth, upload.single("audio"), (req, res) => {
  if (!req.file) return res.status(400).json({ erro: "arquivo nao veio" });
  const ext = (extname(req.file.originalname || "") || ".ogg").toLowerCase();
  const destino = join(DADOS_DIR, `audio-oficial${ext}`);
  renameSync(req.file.path, destino);
  setConfig("audio_oficial", destino);
  setConfig("audio_oficial_info", JSON.stringify({ nome: req.file.originalname, kb: Math.round(req.file.size / 1024), em: agoraSP().iso }));
  res.json({ ok: true, caminho: destino });
});

// toca o audio oficial no painel (auth por query, tag <audio> nao manda header)
app.get("/api/audio-arquivo", async (req, res) => {
  if (String(req.query.t || "") !== PAINEL_SENHA) return res.status(401).end();
  const caminho = getConfig("audio_oficial", "");
  const { existsSync } = await import("node:fs");
  if (!caminho || !existsSync(caminho)) return res.status(404).end();
  res.sendFile(caminho);
});

app.get("/api/audio-info", auth, (req, res) => {
  const caminho = getConfig("audio_oficial", "");
  let info = null;
  try { info = JSON.parse(getConfig("audio_oficial_info", "null")); } catch {}
  res.json({ configurado: Boolean(caminho), info });
});

// ---------- config ----------
app.get("/api/config", auth, (req, res) => {
  const chaves = ["slots_matheus", "slots_valentino", "meet_matheus", "meet_valentino",
    "closer_matheus_ativo", "closer_valentino_ativo", "audio_oficial", "instancia_status",
    "treino_geral", "treino_pitch", "treino_objecoes", "treino_exemplo", "link_apresentacao"];
  res.json(Object.fromEntries(chaves.map((c) => [c, getConfig(c, "")])));
});
app.post("/api/config", auth, (req, res) => {
  const permitidas = ["slots_matheus", "slots_valentino", "meet_matheus", "meet_valentino",
    "closer_matheus_ativo", "closer_valentino_ativo",
    "treino_geral", "treino_pitch", "treino_objecoes", "treino_exemplo", "link_apresentacao"];
  for (const [k, v] of Object.entries(req.body || {}))
    if (permitidas.includes(k)) setConfig(k, v);
  res.json({ ok: true });
});

// ---------- WhatsApps (multi-instancia + rotacao) ----------
const WHATSAPPS_LIMITE = Number(process.env.WHATSAPPS_LIMITE || 99); // container de cliente define pelo plano

app.get("/api/instancias", auth, (req, res) => {
  res.json({ instancias: listarInstancias(), limite: WHATSAPPS_LIMITE });
});

app.post("/api/instancias", auth, (req, res) => {
  const insts = listarInstancias();
  if (insts.length >= WHATSAPPS_LIMITE)
    return res.status(403).json({ erro: `seu plano permite ${WHATSAPPS_LIMITE} WhatsApp(s). Fale com o suporte pra aumentar (R$20/mês por número).` });
  const nome = String(req.body?.nome || `WhatsApp ${insts.length + 1}`).slice(0, 40);
  const id = criarInstanciaDB(nome);
  res.json({ ok: true, id });
});

app.patch("/api/instancias", auth, (req, res) => {
  const inst = getInstancia(req.body?.id);
  if (!inst) return res.status(404).json({ erro: "não existe" });
  const campos = {};
  if (req.body.nome !== undefined) campos.nome = String(req.body.nome).slice(0, 40);
  if (req.body.cota_dia !== undefined) campos.cota_dia = Math.max(0, Number(req.body.cota_dia) || 0);
  atualizarInstancia(inst.id, campos);
  res.json({ ok: true });
});

app.delete("/api/instancias", auth, (req, res) => {
  const inst = getInstancia(req.query.id);
  if (!inst) return res.status(404).json({ erro: "não existe" });
  removerInstancia(inst.id);
  res.json({ ok: true });
});

// QR por instancia: ?inst=<id>. Cria/recupera token na uazapi e conecta.
app.get("/api/qr", auth, async (req, res) => {
  const inst = req.query.inst ? getInstancia(req.query.inst) : listarInstancias()[0];
  if (!inst) return res.status(404).json({ erro: "adicione um WhatsApp primeiro" });
  const rotulo = `${process.env.CLIENTE_NOME || "Facilita SDR"} - ${inst.nome}`;
  let token = inst.uazapi_token;
  if (!token) {
    const nova = await criarInstancia(rotulo);
    if (!nova.token) return res.status(502).json({ erro: `nao criei instancia: ${nova.erro}` });
    token = nova.token;
    atualizarInstancia(inst.id, { uazapi_token: token });
  }
  let r = await conectarInstancia(token);
  if (r.tokenInvalido) {
    const nova = await criarInstancia(rotulo);
    if (!nova.token) return res.status(502).json({ erro: "token morto e nao recriei" });
    token = nova.token;
    atualizarInstancia(inst.id, { uazapi_token: token });
    r = await conectarInstancia(token);
  }
  if (statusConectado(r.status)) {
    atualizarInstancia(inst.id, { status: "conectado", numero: r.owner || inst.numero });
    setConfig("instancia_status", "conectado"); // compat
    await configurarWebhook(token);
  }
  res.json({ status: r.status, qrcode: r.qrcode || null, paircode: r.paircode || null, inst: inst.id });
});

// ---------- OAuth Google por closer (botao "Conectar agenda" no painel) ----------
// Requer o redirect URI cadastrado no OAuth client do Google Cloud:
//   https://sdr.2-25-138-60.sslip.io/api/gcal/callback
const PAINEL_URL = process.env.PAINEL_URL || "https://facilita-sdr.vercel.app";
const assinaState = (closer, ts) => sha(`${WEBHOOK_SECRET}|gcal|${closer}|${ts}`).slice(0, 24);

app.get("/api/gcal/conectar", (req, res) => {
  const t = String(req.query.t || "");
  if (t !== PAINEL_SENHA) return res.status(401).send("sessao invalida — abre pelo painel");
  const closer = req.query.closer === "valentino" ? "valentino" : "matheus";
  const ts = Date.now();
  const state = `${closer}.${ts}.${assinaState(closer, ts)}`;
  const url = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID || "",
    redirect_uri: `${process.env.APP_URL}/api/gcal/callback`,
    response_type: "code",
    scope: "https://www.googleapis.com/auth/calendar.events",
    access_type: "offline",
    prompt: "consent",
    state,
  });
  res.redirect(url);
});

app.get("/api/gcal/callback", async (req, res) => {
  try {
    const [closer, ts, assin] = String(req.query.state || "").split(".");
    if (!["matheus", "valentino"].includes(closer) || assin !== assinaState(closer, ts) ||
        Date.now() - Number(ts) > 15 * 60_000)
      return res.status(400).send("state invalido/expirado — tenta de novo pelo painel");
    const r = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code: String(req.query.code || ""),
        client_id: process.env.GOOGLE_CLIENT_ID || "",
        client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
        redirect_uri: `${process.env.APP_URL}/api/gcal/callback`,
        grant_type: "authorization_code",
      }),
    });
    const d = await r.json();
    if (!d.refresh_token) return res.status(502).send("Google nao devolveu autorizacao: " + JSON.stringify(d).slice(0, 200));
    setConfig(`gcal_refresh_${closer}`, d.refresh_token);
    registrarEvento(null, "gcal", `agenda conectada: ${closer}`);
    res.redirect(`${PAINEL_URL}?gcal=${closer}`);
  } catch (e) {
    res.status(500).send("erro: " + e.message);
  }
});

// ---------- status da agenda Google por closer ----------
app.get("/api/gcal-status", auth, async (req, res) => {
  const { statusConexao } = await import("./lib/gcal.js");
  res.json({
    matheus: await statusConexao("matheus"),
    valentino: await statusConexao("valentino"),
  });
});

// abertura da campanha ativa (mesmas mensagens que o disparo real usa)
function aberturaDaCampanha(lead) {
  const camp = campanhaAtiva();
  const tpls = camp ? db.prepare("SELECT texto FROM templates WHERE campanha_id = ? AND tipo = 'abertura'").all(camp.id) : [];
  const tpl = tpls.length ? tpls[Math.floor(Math.random() * tpls.length)].texto
    : `Oi, tudo bem? Aqui é o Matheus. Consigo falar com o responsável da {nome_clinica}?`;
  return tpl.replaceAll("{nome_clinica}", lead.nome_clinica || "clínica").replaceAll("{cidade}", lead.cidade || "");
}

// ---------- teste REAL: cadastra um telefone teu como lead e dispara a abertura ----------
app.post("/api/testar-real", auth, async (req, res) => {
  const instCon = instanciasConectadas()[0];
  if (!instCon) return res.status(409).json({ erro: "nenhum WhatsApp conectado (Config → QR)" });
  const token = instCon.uazapi_token;
  let tel = String(req.body?.telefone || "").replace(/\D/g, "");
  if (!tel) return res.status(400).json({ erro: "telefone obrigatório" });
  if (tel.length <= 11 && !tel.startsWith("55")) tel = "55" + tel;
  const existente = getLeadPorTelefone(tel);
  if (existente && !["novo", "disparado"].includes(existente.status))
    return res.status(409).json({ erro: `esse número já está em conversa (${existente.status}) — acompanha pela aba Conversas` });
  const nome = req.body?.nome || "Clínica Teste Real";
  const chk = await checarWhatsapp(token, tel);
  if (chk.temWhatsapp === false) return res.status(422).json({ erro: `esse número não tem WhatsApp (${tel})` });
  if (chk.numeroCorrigido) tel = chk.numeroCorrigido;
  const id = existente?.id || upsertLead({ nome_clinica: nome, telefone: tel, cidade: "Teste", nicho: "teste", origem_lista: "teste-real" });
  const abertura = aberturaDaCampanha(getLead(id));
  const r = await enviarTexto(token, tel, abertura);
  if (!r.ok) return res.status(502).json({ erro: `envio falhou: ${r.erro}` });
  salvarMensagem(id, "assistant", abertura);
  atualizarLead(id, { status: "disparado", ia_pausada: 0, eh_teste: 1 }); // teste nunca suja a pipe
  registrarEvento(id, "disparo", "teste-real");
  res.json({ ok: true, lead_id: id, msg: "abertura enviada; responde do outro celular que a IA assume" });
});

// ---------- simulador (teste E2E sem WhatsApp real) ----------
app.post("/api/simular", auth, async (req, res) => {
  const { texto, reset } = req.body || {};
  const telefoneFake = "0000" + (req.body?.slot || "1");
  let lead = getLeadPorTelefone(telefoneFake);
  if (reset && lead) {
    db.prepare("DELETE FROM mensagens WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM reunioes WHERE lead_id = ?").run(lead.id);
    db.prepare("DELETE FROM leads WHERE id = ?").run(lead.id);
    lead = null;
  }
  if (!lead) {
    const id = upsertLead({ nome_clinica: "Clínica Simulada", telefone: telefoneFake, cidade: "Belo Horizonte", nicho: "clínica de teste", origem_lista: "simulador" });
    lead = getLead(id);
    salvarMensagem(lead.id, "assistant", aberturaDaCampanha(lead));
    atualizarLead(lead.id, { status: "disparado" });
  }
  if (!texto) return res.json({ lead, mensagens: historicoLead(lead.id, 100) });
  salvarMensagem(lead.id, "user", texto);
  if (lead.status === "disparado") { atualizarLead(lead.id, { status: "respondeu" }); registrarEvento(lead.id, "resposta", "simulador"); }
  await responderLead(lead.id, "SIMULADO");
  res.json({ lead: getLead(lead.id), mensagens: historicoLead(lead.id, 100), reuniao: reuniaoAtivaDoLead(lead.id) || null });
});

// apresentacao comercial publica (link que a IA manda pro intermediario/lead)
app.get("/apresentacao", async (req, res) => {
  const { existsSync } = await import("node:fs");
  const pdf = join(DADOS_DIR, "apresentacao.pdf");
  if (!existsSync(pdf)) return res.status(404).send("apresentacao nao configurada");
  res.setHeader("Content-Disposition", 'inline; filename="Facilita-AI-Apresentacao.pdf"');
  res.sendFile(pdf);
});

// ============================================================
// NOTAS do lead (follow-up manual, observacoes do vendedor)
// ============================================================
app.get("/api/lead/:id/notas", auth, (req, res) => {
  res.json(db.prepare("SELECT * FROM notas WHERE lead_id = ? ORDER BY id DESC").all(req.params.id));
});
app.post("/api/lead/:id/notas", auth, (req, res) => {
  const texto = String(req.body?.texto || "").trim();
  if (!texto) return res.status(400).json({ erro: "nota vazia" });
  const id = db.prepare("INSERT INTO notas (lead_id, texto) VALUES (?, ?)").run(req.params.id, texto).lastInsertRowid;
  registrarEvento(Number(req.params.id), "nota", texto.slice(0, 60));
  res.json({ ok: true, id });
});
app.delete("/api/nota/:id", auth, (req, res) => {
  db.prepare("DELETE FROM notas WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

// ============================================================
// TAREFAS manuais do lead (minhas, fora da IA: ligar pro decisor etc)
// ============================================================
app.get("/api/lead/:id/tarefas", auth, (req, res) => {
  res.json(tarefasDoLead(req.params.id));
});
app.post("/api/lead/:id/tarefas", auth, (req, res) => {
  const texto = String(req.body?.texto || "").trim();
  if (!texto) return res.status(400).json({ erro: "tarefa vazia" });
  const quando = String(req.body?.quando || "").trim() || null;
  const id = addTarefa(Number(req.params.id), texto, quando);
  registrarEvento(Number(req.params.id), "tarefa", texto.slice(0, 60));
  res.json({ ok: true, id });
});
app.patch("/api/tarefa/:id", auth, (req, res) => {
  marcarTarefa(Number(req.params.id), req.body?.feita ? 1 : 0);
  res.json({ ok: true });
});
app.delete("/api/tarefa/:id", auth, (req, res) => {
  removerTarefa(Number(req.params.id));
  res.json({ ok: true });
});

// ============================================================
// DASHBOARD (funil + metricas + benchmarks Adriano Aquino)
// ============================================================
app.get("/api/dashboard", auth, (req, res) => {
  const dias = Math.min(90, Math.max(1, Number(req.query.dias) || 30));
  const desde = `datetime('now','-${dias} days')`;
  const contaEvt = (tipo) => db.prepare(`SELECT COUNT(*) c FROM eventos WHERE tipo = ? AND criado_em >= ${desde}`).get(tipo).c;

  const disparos = contaEvt("disparo");
  const respostas = contaEvt("resposta");
  const reunioes = contaEvt("reuniao");
  const optouts = contaEvt("optout");
  const followups = contaEvt("followup");
  const decisores = contaEvt("responsavel") + db.prepare(`SELECT COUNT(*) c FROM eventos WHERE tipo='decisor_contato' AND criado_em >= ${desde}`).get().c;

  // funil por status (foto atual)
  const porStatus = {};
  for (const r of db.prepare("SELECT status, COUNT(*) c FROM leads WHERE eh_teste = 0 GROUP BY status").all()) porStatus[r.status] = r.c;

  // taxas
  const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : 0);
  const taxaResposta = pct(respostas, disparos);
  const taxaDecisor = pct(decisores, disparos);
  const taxaReuniao = pct(reunioes, respostas);
  const taxaReuniaoDisparo = pct(reunioes, disparos);

  // BENCHMARKS de outbound WhatsApp:
  //  disparo->decisor 8-12% · decisor->reuniao 40-50% · follow->decisor 30-40% · min 40 disparos/dia
  const bench = {
    disparo_decisor: { min: 8, max: 12, atual: taxaDecisor, ok: taxaDecisor >= 8 },
    decisor_reuniao: { min: 40, max: 50, atual: pct(reunioes, decisores), ok: pct(reunioes, decisores) >= 40 },
    disparos_dia: { min: 40, atual: Math.round(disparos / dias), ok: Math.round(disparos / dias) >= 40 },
  };

  // serie diaria (disparos x respostas x reunioes) pros ultimos N dias
  const serie = db.prepare(`
    SELECT date(criado_em) d,
      SUM(tipo='disparo') disparos, SUM(tipo='resposta') respostas, SUM(tipo='reuniao') reunioes
    FROM eventos WHERE criado_em >= ${desde} GROUP BY date(criado_em) ORDER BY d`).all();

  // por instancia (split/rotacao)
  const porWhats = listarInstancias().map((i) => ({ nome: i.nome, disparos_hoje: i.disparos_hoje || 0, cota_dia: i.cota_dia || 0, status: i.status }));

  // motivos de perda
  const motivosPerda = db.prepare("SELECT motivo_perda m, COUNT(*) c FROM leads WHERE status IN ('perdido','descartado') AND motivo_perda IS NOT NULL GROUP BY motivo_perda ORDER BY c DESC LIMIT 6").all();

  res.json({
    dias, disparos, respostas, reunioes, optouts, followups, decisores,
    taxaResposta, taxaDecisor, taxaReuniao, taxaReuniaoDisparo,
    porStatus, bench, serie, porWhats, motivosPerda,
    leadsComTarefa: db.prepare("SELECT COUNT(*) c FROM leads WHERE followup_em IS NOT NULL AND ia_pausada = 0").get().c,
  });
});

// ============================================================
// ENTREVISTA (monta o cerebro conversando)
// ============================================================
app.post("/api/entrevista", auth, async (req, res) => {
  try {
    const { entrevistaTurno } = await import("./lib/agente.js");
    const r = await entrevistaTurno(Array.isArray(req.body?.historico) ? req.body.historico : []);
    // persiste os blocos que o entrevistador atualizou
    for (const k of ["treino_geral", "treino_pitch", "treino_objecoes"])
      if (typeof r.campos?.[k] === "string" && r.campos[k].trim()) setConfig(k, r.campos[k]);
    res.json({ mensagem: r.mensagem, campos: Object.keys(r.campos || {}), concluido: Boolean(r.concluido) });
  } catch (e) {
    res.status(500).json({ erro: "IA indisponível: " + e.message });
  }
});

// ============================================================
// CHAVE ANTHROPIC (containers de cliente; interno usa o plano)
// ============================================================
const MODO_IA = process.env.SDR_IA_MODO || "plano";

app.get("/api/chave", auth, (req, res) => {
  res.json({
    modo: MODO_IA,
    configurada: Boolean(getConfig("anthropic_key", "") || (MODO_IA === "api" && process.env.ANTHROPIC_API_KEY)),
    origem: getConfig("anthropic_key", "") ? "painel" : (process.env.ANTHROPIC_API_KEY ? "provisionamento" : "nenhuma"),
  });
});

app.post("/api/chave", auth, async (req, res) => {
  const chave = String(req.body?.chave || "").trim();
  if (!chave.startsWith("sk-ant-")) return res.status(422).json({ erro: "formato inválido (começa com sk-ant-)" });
  // valida com uma chamada minima na API da Anthropic
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": chave, "anthropic-version": "2023-06-01", "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 1, messages: [{ role: "user", content: "oi" }] }),
      signal: AbortSignal.timeout(20_000),
    });
    if (r.status === 401) return res.status(422).json({ erro: "chave inválida ou revogada" });
    if (r.status === 400 || r.ok) { /* 400 de modelo tambem prova autenticacao ok */ }
    else if (r.status === 429 || r.status === 402) return res.status(422).json({ erro: "chave sem saldo — recarregue em console.anthropic.com" });
  } catch (e) {
    return res.status(502).json({ erro: "não consegui validar agora: " + e.message });
  }
  setConfig("anthropic_key", chave);
  res.json({ ok: true });
});

// tutorial publico de como gerar a chave (pra mandar pro cliente)
app.get("/tutorial-chave", (req, res) => {
  res.type("html").send(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Como gerar sua chave de IA</title>
<style>body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px;margin:40px auto;padding:0 20px;color:#14201a;line-height:1.6}h1{color:#166534}ol li{margin-bottom:14px}code{background:#eef1ef;padding:2px 6px;border-radius:4px}.dica{background:#e8f7ee;border-radius:8px;padding:12px 16px;font-size:14px}</style></head><body>
<h1>🔑 Como gerar sua chave de IA (Anthropic)</h1>
<p>Sua IA de prospecção usa a <b>sua</b> conta da Anthropic (a empresa do Claude). Você paga só o que usar: centavos por conversa. Leva 5 minutos:</p>
<ol>
<li>Acesse <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a> e crie sua conta (pode entrar com Google).</li>
<li>No menu, vá em <b>Billing</b> (Cobrança) e adicione um crédito inicial. <b>US$5 já rodam centenas de conversas.</b></li>
<li>Vá em <b>API Keys</b> → <b>Create Key</b>. Dê um nome (ex: "Prospecta") e clique em criar.</li>
<li><b>Copie a chave</b> (começa com <code>sk-ant-</code>). Ela só aparece uma vez!</li>
<li>Cole a chave no seu painel do Prospecta, em <b>Config → Chave da IA</b>, e clique em validar.</li>
</ol>
<div class="dica">💡 Quando o crédito acabar, a IA para de responder. É só recarregar em Billing que volta na hora. Dica: ative o "auto reload" pra nunca parar.</div>
</body></html>`);
});

// ============================================================
// ASSINATURA (Stripe por link ate automatizar)
// ============================================================
app.get("/api/assinatura", auth, (req, res) => {
  const whats = listarInstancias().length || 1;
  res.json({
    modo: MODO_IA, // so faz sentido em container de cliente
    status: getConfig("assinatura_status", "trial"),
    preco_base: 100, preco_whats: 20,
    whats,
    total: 100 + Math.max(0, whats - 1) * 20,
    link: process.env.STRIPE_LINK || getConfig("stripe_link", ""),
    pausada: getConfig("conta_pausada", "") === "1",
  });
});

// ============================================================
// ADMIN (so funciona no SDR interno da VPS: le os containers dos clientes)
// ============================================================
app.get("/api/admin/clientes", auth, async (req, res) => {
  const { readdirSync, existsSync: ex, readFileSync: rf } = await import("node:fs");
  const BASE = "/root/sdr-clientes";
  if (!ex(BASE)) return res.status(404).json({ erro: "sem clientes aqui (rota exclusiva do interno)" });
  const Database = (await import("better-sqlite3")).default;
  const clientes = [];
  for (const slug of readdirSync(BASE)) {
    const dir = `${BASE}/${slug}`;
    if (!ex(`${dir}/.env`)) continue;
    const envTxt = rf(`${dir}/.env`, "utf8");
    const pega = (k) => (envTxt.match(new RegExp(`^${k}=(.*)$`, "m")) || [])[1] || "";
    const c = { slug, nome: pega("CLIENTE_NOME") || slug, email: pega("PAINEL_EMAIL"), url: pega("APP_URL"),
      leads: 0, disparos: 0, respostas: 0, reunioes: 0, whats_conectados: 0, pausada: false, erro: null };
    try {
      const cdb = new Database(`${dir}/dados/sdr.db`, { readonly: true, fileMustExist: true });
      c.leads = cdb.prepare("SELECT COUNT(*) c FROM leads WHERE eh_teste = 0").get().c;
      c.disparos = cdb.prepare("SELECT COUNT(*) c FROM eventos WHERE tipo = 'disparo'").get().c;
      c.respostas = cdb.prepare("SELECT COUNT(*) c FROM eventos WHERE tipo = 'resposta'").get().c;
      c.reunioes = cdb.prepare("SELECT COUNT(*) c FROM eventos WHERE tipo = 'reuniao'").get().c;
      try { c.whats_conectados = cdb.prepare("SELECT COUNT(*) c FROM instancias WHERE status = 'conectado'").get().c; } catch {}
      try { c.pausada = cdb.prepare("SELECT valor FROM config WHERE chave = 'conta_pausada'").get()?.valor === "1"; } catch {}
      cdb.close();
    } catch (e) { c.erro = e.message.slice(0, 60); }
    clientes.push(c);
  }
  res.json({ clientes, mrr_estimado: clientes.length * 100 });
});

// ============================================================
// MARCA (painel troca o nome conforme o deploy: interno vs cliente)
// ============================================================
app.get("/api/marca", (req, res) => {
  res.json({ produto: process.env.SDR_MARCA || "Facilita SDR", cliente: process.env.CLIENTE_NOME || "" });
});

// ============================================================
// TERMOS DE USO + PRIVACIDADE (LGPD)
// ============================================================
const paginaLegal = (titulo, corpo) => `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${titulo} — Prospecta</title>
<style>body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:720px;margin:40px auto;padding:0 20px;color:#14201a;line-height:1.65;font-size:15px}h1{color:#166534}h2{color:#166534;font-size:17px;margin-top:26px}</style></head><body><h1>${titulo}</h1>${corpo}<p style="margin-top:30px;color:#5f6f66;font-size:13px">Última atualização: agosto de 2026.</p></body></html>`;

app.get("/termos", (req, res) => {
  res.type("html").send(paginaLegal("Termos de Uso", `
<p>Ao usar o Prospecta, você ("Cliente") concorda com estes termos.</p>
<h2>1. O serviço</h2><p>O Prospecta é uma ferramenta de prospecção que envia mensagens via WhatsApp e conduz conversas com apoio de inteligência artificial, sob configuração e responsabilidade do Cliente.</p>
<h2>2. Responsabilidades do Cliente</h2><p>O Cliente é o único responsável: (a) pelas listas de contatos que importa, garantindo base legal para o contato (LGPD, art. 7º); (b) pelo conteúdo das mensagens e do treinamento da IA; (c) pelo número de WhatsApp conectado, ciente de que envio em massa pode violar os termos do WhatsApp e resultar em bloqueio do número, risco que o Cliente assume; (d) pela chave de API de IA e seus custos.</p>
<h2>3. Opt-out obrigatório</h2><p>O sistema honra automaticamente pedidos de descadastro ("pare de mandar"). O Cliente não deve contornar esse mecanismo.</p>
<h2>4. Pagamento</h2><p>Assinatura mensal conforme plano contratado. Inadimplência suspende os disparos, preservando os dados por 30 dias.</p>
<h2>5. Limitação</h2><p>O serviço é fornecido "como está". Não garantimos resultados comerciais, entregabilidade de mensagens ou disponibilidade ininterrupta.</p>
<h2>6. Encerramento</h2><p>O Cliente pode cancelar a qualquer momento. Dados são excluídos definitivamente 30 dias após o cancelamento, salvo obrigação legal.</p>`));
});

app.get("/privacidade", (req, res) => {
  res.type("html").send(paginaLegal("Política de Privacidade (LGPD)", `
<h2>1. Papéis</h2><p>Na operação do Prospecta, o <b>Cliente é o Controlador</b> dos dados pessoais dos contatos que importa e prospecta. O Prospecta atua como <b>Operador</b>, processando esses dados exclusivamente conforme instruções do Cliente (LGPD, arts. 37-39).</p>
<h2>2. Dados tratados</h2><p>Nome, telefone e conteúdo de conversas de contatos comerciais importados pelo Cliente; dados cadastrais do próprio Cliente (email, dados de pagamento).</p>
<h2>3. Finalidade</h2><p>Exclusivamente a prospecção comercial configurada pelo Cliente. Não vendemos nem compartilhamos dados com terceiros, exceto suboperadores necessários ao serviço (infraestrutura de servidor, API de WhatsApp e API de IA).</p>
<h2>4. Direitos dos titulares</h2><p>Pedidos de descadastro são honrados automaticamente e o número entra em lista de bloqueio permanente. Titulares podem solicitar acesso, correção ou exclusão dos seus dados através do Cliente (Controlador) ou pelo nosso contato.</p>
<h2>5. Segurança e retenção</h2><p>Dados isolados por cliente, backups diários criptografados em trânsito, retenção durante a vigência do contrato e por 30 dias após o cancelamento.</p>
<h2>6. Contato do encarregado</h2><p>suporte via WhatsApp/email do Prospecta.</p>`));
});

// o painel mora DENTRO do servidor: o cliente abre o proprio endereco e pronto
// (o painel na Vercel continua funcionando como espelho, apontando via "avancado")
// painel SEM cache: senao o navegador segura a versao antiga depois de um deploy
// e o usuario nao ve as mudancas (aconteceu — nao remover esses headers).
app.get("/", (req, res) => {
  res.set("Cache-Control", "no-store, no-cache, must-revalidate");
  res.sendFile(join(__dirname, "painel", "index.html"));
});

app.get("/health", (req, res) => res.json({ ok: true, agora: agoraSP() }));

// na VPS direto: 127.0.0.1 (Caddy local). Em container: BIND_HOST=0.0.0.0
app.listen(PORT, process.env.BIND_HOST || "127.0.0.1", () => {
  console.log(`[sdr] servidor na porta ${PORT}`);
  iniciarWorker();
});

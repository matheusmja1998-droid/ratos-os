---
fonte: livro PDF
autor: Timothy Ferriss
tags: [produtividade, automação, delegação, estilo-de-vida, liberdade, DEAL]
aplicar: [WinVision, pessoal]
---

# Trabalhe 4 Horas por Semana — Timothy Ferriss

## Ideia central

> Esqueça a aposentadoria como meta final. Distribua períodos de descanso, aventura e projetos estimulantes **ao longo da vida** — não no final dela.

A meta não é riqueza acumulada. É **tempo + mobilidade + renda** operando em paralelo.

---

## Novos Ricos (NR) vs. Adiadores (A)

| Adiadores (A) | Novos Ricos (NR) |
|---|---|
| Trabalhar para si mesmo | Fazer outros trabalharem para você |
| Aposentar cedo e viver depois | Miniaposentadorias ao longo da vida |
| Comprar tudo que quer | Fazer tudo que quer — ter menos, fazer mais |
| Ser o patrão | Ser o dono (não operar o dia a dia) |
| Ganhar muito dinheiro | Ganhar dinheiro com propósito definido |
| Alcançar estabilidade final | Fluxo de caixa constante agora |

> "Não ser nem o patrão nem o empregado, mas o proprietário. Ser o dono da ferrovia e ter alguém para operar os trens."

---

## O Framework DEAL

### D — Definição
Redefinir as regras do jogo. Questionar o que "sucesso" significa para você.

- O que você faria se não pudesse falhar?
- Qual é o custo real de **não agir**?
- Medo não é sinal de parar — é sinal de que algo importa

### E — Eliminação
Aplicar o Princípio de Pareto (80/20) de forma radical.

- 20% das atividades geram 80% dos resultados
- 20% dos clientes geram 80% do faturamento (e 80% do trabalho)
- Eliminar: e-mails desnecessários, reuniões sem pauta, tarefas de baixo impacto
- **Dieta pobre em informação:** só consumir o que é relevante e acionável

**Técnica do Low Information Diet:**
- Pare de verificar e-mail de hora em hora
- Defina horários fixos para e-mail (ex: 12h e 17h)
- Notícias importantes chegam até você sem você precisar buscar

### A — Automação
Criar sistemas que funcionem sem sua presença constante.

- **Terceirização:** delegar tarefas repetitivas para assistentes virtuais (locais ou internacionais)
- **Receita em piloto automático:** produto ou serviço que vende e entrega sem operação manual constante
- Regra: se pode ser feito por outro a 80% da sua qualidade → delegue

### L — Libertação
Separar presença física de geração de renda.

- **Trabalho remoto:** negociar com chefe ou cliente
- **Miniaposentadorias:** períodos longos fora (1-3 meses) intercalados com trabalho
- O vazio após eliminar o trabalho precisa ser preenchido com projetos que importam

---

## A Lei de Parkinson

> "O trabalho se expande para preencher o tempo disponível para ele."

Se você dá 8 horas para uma tarefa, leva 8 horas. Se dá 2 horas, leva 2.

**Aplicação:** defina prazos curtos e agressivos. Trabalhe com urgência artificial.

---

## Os 80/20 Críticos para Matheus

| Área | 80/20 Provável |
|---|---|
| Clientes WinVision | Quais 20% dos clientes geram 80% do faturamento e satisfação? |
| Tarefas diárias | Quais tarefas, se eliminadas, não afetariam os resultados? |
| Reuniões | Quais reuniões poderiam ser substituídas por uma mensagem? |
| Conteúdo | Qual formato gera mais leads com menos tempo de produção? |

---

## Miniaposentadorias

Ao invés de trabalhar 40 anos e descansar no final, tirar mini-períodos distribuídos:

- 1 semana por trimestre em lugar diferente
- 1 mês por ano em modo exploração
- Não esperar ter "dinheiro suficiente" — começar agora com o possível

---

**Ver também:** [[O Mito do Empreendedor — Michael Gerber]] | [[Antecipação de Decisão e Pomodoro]] | [[WinVision — Visão Geral]]

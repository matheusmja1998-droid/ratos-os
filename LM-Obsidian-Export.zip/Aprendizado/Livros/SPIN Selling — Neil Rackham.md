---
fonte: livro PDF
autor: Neil Rackham
tags: [vendas, perguntas, SPIN, consultiva, necessidade, implicação]
aplicar: [WinVision, LM]
---

# SPIN Selling — Neil Rackham

## Ideia central

> Pesquisa com 35.000 visitas de venda em 12 anos revelou que as técnicas clássicas de vendas funcionam em vendas pequenas — e **atrapalham** em vendas grandes.

A diferença não está no fechamento nem na apresentação. Está nas **perguntas que você faz**.

---

## Os 4 Estágios de uma Visita de Vendas

| Estágio | O que acontece |
|---|---|
| **1. Abertura** | Apresentações, contexto, construção de rapport |
| **2. Investigação** | Descoberta de necessidades via perguntas — **o mais importante** |
| **3. Demonstração de capacidade** | Mostrar como você pode ajudar |
| **4. Obtenção de compromisso** | Próximo passo claro |

> O maior erro: pular para a demonstração antes de desenvolver bem as necessidades.

---

## Necessidades Implícitas vs. Explícitas

| Tipo | O que é | Exemplo |
|---|---|---|
| **Implícita** | O lead reconhece um problema, mas não sente urgência para resolvê-lo | "Às vezes temos dificuldade para acompanhar os leads." |
| **Explícita** | O lead expressa desejo claro de mudança | "Preciso de um sistema para não perder mais leads." |

> **Objetivo das perguntas SPIN:** Transformar necessidades implícitas em explícitas.

---

## A Estratégia SPIN

### S — Situação

Perguntas que coletam fatos e contexto sobre o cenário atual do cliente.

- "Quantas pessoas trabalham no comercial?"
- "Como você acompanha os leads hoje?"
- "Qual é seu processo atual de follow-up?"

**Atenção:** Use com parcimônia. Compradores se cansam de perguntas de situação. Pesquise antes e minimize.

---

### P — Problema

Perguntas que identificam dificuldades, insatisfações ou desconfortos.

- "Onde você sente que está perdendo mais oportunidades?"
- "O que mais te frustra no processo comercial atual?"
- "Qual é o maior gargalo entre o lead entrar e a venda fechar?"

**Por que funcionam:** Revelam necessidades implícitas. O lead começa a perceber o problema com mais clareza.

---

### I — Implicação

Perguntas que ampliam o impacto do problema — mostram o custo de **não resolver**.

- "Se você continuar perdendo X% dos leads, o que isso representa em faturamento no ano?"
- "Quanto essa desorganização já custou em oportunidades perdidas?"
- "Se a equipe continuar sem processo, o que acontece quando você escalar?"

> **Implicação é o coração do SPIN.** Vendedores de elite fazem muito mais perguntas de implicação. São as que mais movem o lead para a ação.

---

### N — Necessidade de Solução (Need-Payoff)

Perguntas que fazem o lead **verbalizar os benefícios da solução** — em vez de você vender, ele se convence.

- "Se você tivesse um processo de follow-up automatizado, o que mudaria?"
- "Como seria ter um time comercial com script e playbook?"
- "Qual seria o impacto de ter previsibilidade de receita?"

> "Quando o lead fala dos benefícios com as próprias palavras, a compra já aconteceu mentalmente."

---

## Por que Fechamento Excessivo Não Funciona

Em vendas grandes, muitas técnicas de fechamento **reduzem** a taxa de conversão. O comprador se sente pressionado e resiste.

O que funciona: **obter compromissos menores ao longo do processo** (próxima reunião, envio de proposta, apresentação para sócios) em vez de forçar a decisão final de uma vez.

---

## Características vs. Vantagens vs. Benefícios

| Tipo | O que é | Impacto |
|---|---|---|
| **Característica** | O que o produto tem ou faz | Neutro |
| **Vantagem** | Como a característica pode ajudar | Pequeno |
| **Benefício** | Como resolve uma necessidade **explícita** já desenvolvida | Alto |

> Só apresente benefícios **depois** de ter desenvolvido a necessidade correspondente com SPIN.

---

## Aplicação no Diagnóstico da L.M

O Script de Diagnóstico da Ignição Comercial já usa SPIN estruturalmente:

| Bloco do Script | SPIN |
|---|---|
| Bloco 2 — Contexto | **Situação** |
| Bloco 3 — Dores e problemas | **Problema** |
| Bloco 4 — Consequências | **Implicação** |
| Bloco 5 — Visão de futuro | **Necessidade de Solução** |

---

**Ver também:** [[Ignição Comercial — Script de Diagnóstico v2]] | [[Neurovendas — Simon Hazeldine]] | [[Prospecção Fanática — Jeb Blount]]

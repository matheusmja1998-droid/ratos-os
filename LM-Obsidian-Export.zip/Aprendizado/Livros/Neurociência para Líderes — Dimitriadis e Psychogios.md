---
fonte: livro PDF
autor: Nikolaos Dimitriadis e Alexandros Psychogios
tags: [liderança, neurociência, comportamento, equipe, gestão, decisão]
aplicar: [LM, WinVision]
---

# Neurociência para Líderes — Dimitriadis e Psychogios

## Ideia central

> Liderança eficaz não é sobre carisma ou técnicas de gestão — é sobre entender como o cérebro humano funciona e criar condições para que as pessoas deem o melhor de si.

---

## O Cérebro Social

O ser humano é fundamentalmente social. O cérebro trata **ameaças sociais** (rejeição, exclusão, injustiça) com a mesma intensidade que ameaças físicas.

**Implicação para líderes:** ambientes de medo, microgestão e falta de reconhecimento ativam os mesmos circuitos de defesa que uma situação de perigo real — prejudicando performance e criatividade.

---

## O Modelo SCARF — Ameaças e Recompensas Sociais

David Rock identificou 5 domínios sociais que o cérebro monitora constantemente:

| Domínio | O que ativa "ameaça" | O que ativa "recompensa" |
|---|---|---|
| **S — Status** | Ser corrigido em público, perder posição | Reconhecimento, promoção, elogio |
| **C — Certainty** | Mudanças inesperadas, falta de informação | Clareza, previsibilidade, processos claros |
| **A — Autonomy** | Microgestão, falta de escolha | Dar opções, permitir decisões próprias |
| **R — Relatedness** | Isolamento, não pertencer ao grupo | Conexão, confiança, pertencimento |
| **F — Fairness** | Injustiça percebida, regras inconsistentes | Transparência, tratamento igualitário |

> Um líder que ativa "ameaça" em qualquer desses domínios reduz a capacidade cognitiva da equipe — independente da intenção.

---

## Neuroplasticidade e Aprendizado

O cérebro adulto continua se moldando com a experiência (neuroplasticidade). Isso tem implicações diretas para treinamento e desenvolvimento de times:

- Repetição com feedback cria novos caminhos neurais
- Aprendizado emocional (experiência + emoção) é retido mais profundamente
- Stress moderado melhora performance; stress crônico a destrói

---

## Tomada de Decisão sob Pressão

Sob pressão, o cérebro **reduz a atividade no córtex pré-frontal** (raciocínio) e aumenta a atividade na amígdala (reação emocional).

**Para líderes:** decisões importantes não devem ser tomadas em momentos de alta pressão emocional. Criar espaço para reflexão melhora a qualidade das decisões.

---

## Motivação Intrínseca vs. Extrínseca

| Tipo | O que é | Limitação |
|---|---|---|
| **Extrínseca** | Dinheiro, bônus, punição | Funciona para tarefas mecânicas; reduz criatividade |
| **Intrínseca** | Propósito, autonomia, maestria | Sustentável; gera engajamento real |

> Para times comerciais: metas de comissão funcionam para volume, mas **propósito e maestria** sustentam a alta performance a longo prazo.

---

## Comunicação e o Cérebro

- Histórias ativam muito mais regiões cerebrais do que dados brutos
- O cérebro processa **tom e linguagem não-verbal** antes do conteúdo verbal
- Mensagens repetidas em múltiplos contextos constroem crenças

---

## Aplicação para Times Comerciais (L.M)

| Conceito | Aplicação no Time |
|---|---|
| SCARF — Status | Reconhecer publicamente ligações/reuniões bem-feitas |
| SCARF — Certainty | Metas claras, processos documentados, dailies com estrutura fixa |
| SCARF — Autonomy | Deixar cada vendedor personalizar abordagem dentro do processo |
| Neuroplasticidade | Repetição + feedback nos POPs e role-plays |
| Motivação intrínseca | Conectar o trabalho comercial ao propósito maior da empresa |

---

**Ver também:** [[Compromissos e Metodologia OAE]] | [[Treinamento de POPs]] | [[O Mito do Empreendedor — Michael Gerber]]

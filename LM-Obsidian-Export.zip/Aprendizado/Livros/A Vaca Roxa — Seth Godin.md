---
fonte: livro PDF
autor: Seth Godin
tags: [marketing, diferenciação, posicionamento, produto, remarkeável]
aplicar: [WinVision, LM]
---

# A Vaca Roxa — Seth Godin

## Ideia central

> Uma vaca é uma vaca é uma vaca. Mas uma **vaca roxa** — isso é diferente. Isso é marcante.

O marketing de massa morreu. Anúncios de TV, listas de e-mail em massa, mídia de interrupcão — tudo isso perdeu poder. Hoje, só o que se espalha é o que é **genuinamente notável**.

---

## O fim do complexo industrial da TV

**Antes:** você fazia um produto mediano → comprava anúncios → vendia mais → reinvestia em mais anúncios.

**Hoje:** as pessoas ignoram anúncios. Você não pode mais forçar atenção.

> "Ninguém está ansioso para se adaptar ao seu produto. A grande maioria dos consumidores está satisfeita."

---

## A curva de adoção e quem realmente importa

| Grupo | Comportamento |
|---|---|
| Inovadores (Aficionados) | Adoram novidades, testam tudo — são quem você deve capturar |
| Maioria precoce | Espera os aficionados aprovarem antes de comprar |
| Maioria tardia | Só compra quando já é padrão |
| Retardatários | Compram quando o produto já está obsoleto |

> **Insight:** Você não convence a maioria diretamente. Você convence os aficionados, e eles convencem a maioria.

---

## O que é ser Vaca Roxa

Ser marcante não é sobre ser extravagante. É sobre ser **diferente o suficiente para ser notado e comentado**.

- Vantagem de preço extrema: isso é marcante
- Produto que resolve um problema de forma surpreendente: marcante
- Experiência completamente diferente de tudo na categoria: marcante
- Mediano, seguro e previsível: invisível

> "O contrário de 'marcante' não é 'ruim'. É 'muito bom'."

---

## Otaku

Conceito japonês: paixão profunda por um nicho específico. Pessoas com otaku são os evangelistas naturais de produtos marcantes. Elas buscam o que é novo e fascinante no seu nicho e espalham para os demais.

> **Regra:** Encontre o otaku do seu nicho. Crie para eles. Eles vendem para o resto.

---

## Os dois grandes erros

1. **Criar para a maioria** — a maioria ignora o que é novo. Você não chega até eles diretamente.
2. **Ter medo de ser marcante** — seguro é arriscado. O risco está em ser mediano, não em ser ousado.

> "Jogar pelo seguro agora é a postura mais arriscada de todas."

---

## Aplicação prática

| Pergunta | WinVision / LM |
|---|---|
| O que torna minha oferta marcante o suficiente para ser comentada? | Resultado tangível, não só metodologia |
| Quem é o "aficionado" no nicho de energia solar? | Integradores que já querem crescer com processo |
| O que eu entrego que nenhum concorrente entrega de forma similar? | Implantação + acompanhamento + CRM + playbook |

---

**Ver também:** [[$100M Money Models — Hormozi]] | [[Minha Oferta de Serviços — WinVision]]

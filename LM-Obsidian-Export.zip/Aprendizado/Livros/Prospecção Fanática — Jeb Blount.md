---
fonte: livro PDF
autor: Jeb Blount
tags: [prospecção, outbound, ligação, pipeline, mentalidade, vendas]
aplicar: [LM, WinVision]
---

# Prospecção Fanática — Jeb Blount

## Ideia central

> "Prospectar é o cerne, a base, o coração de todo esforço de vendas de sucesso."

A única razão pela qual pipelines secam é a falta de prospecção consistente. Não existe substituto. Não existe atalho.

> "Eis a verdade brutal: não há como selecionar a opção 'fácil' em vendas. Prospectar é um trabalho duro, emocionalmente exaustivo, e é o preço que você paga para ter uma renda alta."

---

## A Regra dos 30 Dias

A prospecção que você faz **hoje** vai gerar resultado nos **próximos 90 dias**.

- Perca um dia → sente o impacto 90 dias depois
- Perca uma semana → queda no cheque de comissão
- Perca um mês inteiro → pipeline vazio, desespero em 90 dias

> "Ao internalizar essa regra, ela vai orientá-lo a nunca deixar a prospecção para outro dia."

---

## As 7 Mentalidades de Prospectores Fanáticos

| # | Mentalidade | Como se manifesta |
|---|---|---|
| 1 | **Otimista e entusiasta** | Vêem cada dia como nova oportunidade; dispensam energia negativa |
| 2 | **Competitivo** | Tratam cada ligação como competição; gostam de vencer |
| 3 | **Confiante** | Acreditam no produto, no processo e em si mesmos |
| 4 | **Relentless (implacável)** | Não aceitam "não" como resposta final; tentam novamente |
| 5 | **Focado no processo** | Medem atividade, não só resultado; controlam o que podem controlar |
| 6 | **Adaptável** | Mudam abordagem conforme o lead; não têm script fixo |
| 7 | **Mentalidade de dono** | Tratam o pipeline como um ativo pessoal, não como obrigação do emprego |

---

## Balanceamento do Pipeline — Múltiplos Canais

Não dependa de um único canal. Prospecção equilibrada usa:

| Canal | Quando usar |
|---|---|
| **Telefone** | Alta conversão, ciclo rápido, decisores difíceis |
| **E-mail** | Volume, primeiro contato, follow-up |
| **Redes sociais** | Aquecimento, relacionamento, pesquisa prévia |
| **Presencial** | Leads de alto ticket, território geográfico |
| **Indicação** | Melhor custo de aquisição, maior taxa de conversão |
| **Eventos** | Relacionamento de massa, autoridade |

> **Regra:** Nunca dependa de um único canal. Quando um trava, os outros sustentam.

---

## Horas de Ouro vs. Horas de Platina

| Tipo | Quando é | O que fazer |
|---|---|---|
| **Horas de Platina** | Quando decisores estão disponíveis (manhã e fim de tarde) | APENAS prospecção — sem reuniões internas, sem admin |
| **Horas de Ouro** | Resto do horário comercial | Reuniões, follow-ups, propostas |

> "Horas de Platina são sagradas. Quem as desperdiça com burocracia paga o preço nos 90 dias seguintes."

---

## Os Quatro Objetivos da Prospecção

Todo contato de prospecção tem apenas um de 4 objetivos possíveis:

1. **Marcar uma reunião** (R1 ou R2)
2. **Conseguir uma referência**
3. **Obter uma informação qualificadora**
4. **Criar consciência de marca** (apenas se nenhum dos 3 anteriores for possível)

> **Nunca entre em uma ligação sem saber qual é o objetivo.**

---

## A Regra da Interrupção

O lead **não estava esperando sua ligação**. Você está interrompendo o dia dele. Isso é fato.

A reação padrão é resistência. Não é rejeição pessoal — é resposta humana à interrupção.

> Prospectores fanáticos entendem isso e **não levam para o lado pessoal**. Eles passam para a próxima ligação com a mesma energia.

---

## Aplicação — Conexão com Os Escolhidos

| Conceito Blount | Aplicação L.M |
|---|---|
| Regra dos 30 Dias | Semana 1 do mês é sagrada — [[Antecipação de Decisão e Pomodoro]] |
| Horas de Platina | Blocos de Pomodoro de manhã = só ligação |
| Múltiplos canais | Ligação + Disparo + Follow-up = [[Canais CAC Zero — Ligação, Disparo e Follow-up]] |
| 4 objetivos | Toda ligação tem meta clara antes de discar |

---

**Ver também:** [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Horizonte de Oportunidades]] | [[Ciclo de Vendas — Como Encurtar]]

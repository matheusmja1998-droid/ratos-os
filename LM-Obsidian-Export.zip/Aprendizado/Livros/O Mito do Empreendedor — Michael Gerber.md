---
fonte: livro PDF
autor: Michael E. Gerber
tags: [empreendedorismo, sistema, franquia, processo, negócio, escala]
aplicar: [WinVision, LM]
---

# O Mito do Empreendedor — Michael Gerber

## O Mito

> O maior mito sobre empreendedorismo: "Se você é bom técnico em algo, pode abrir um negócio disso."

Isso é a **Convulsão do Empreendedor** — o momento em que um técnico decide que sabe mais do que o patrão e abre seu próprio negócio.

O resultado: o técnico não abre um negócio. Ele **cria um emprego para si mesmo** — com um chefe ainda pior do que o anterior (ele mesmo).

---

## As 3 Personalidades

Todo empreendedor é um três em um — e cada personalidade quer ser o chefe:

| Personalidade | O que quer | Quando domina |
|---|---|---|
| **Empreendedor** | Visão, futuro, inovação, possibilidades | No momento de euforia e lançamento |
| **Gestor** | Ordem, processo, previsibilidade, controle | Depois que o caos aparece |
| **Técnico** | Execução, fazer o trabalho agora | No dia a dia |

> "O Empreendedor vive no futuro, o Gestor vive no passado e o Técnico vive no presente."

**O problema:** A maioria dos empreendedores é 70% Técnico. Fazem tudo, não delegam, não constroem processo.

---

## A Convulsão do Empreendedor

**Sequência fatal:**

1. Excitação (início)
2. Terror (quando a demanda cresce e o técnico não dá conta)
3. Exaustão (trabalhando cada vez mais por resultados cada vez menores)
4. Desespero (dívidas, sem saber o que fazer a seguir)

> A causa: o técnico confundiu "gostar de fazer tartes" com "saber construir um negócio de tartes".

---

## A Perspectiva da Franquia

### Por que a McDonald's é o melhor modelo de negócio do mundo

Ray Kroc não criou um hambúrguer — criou um **sistema replicável**. A McDonald's cumpre exatamente a mesma promessa em 40.000 lojas, todos os dias, independente de quem está trabalhando.

> **A pergunta certa:** "Como construo um negócio que funcione **sem mim**?"

### O Protótipo de Franquia

Construa seu negócio como se fosse vender 5.000 franquias:

- Cada processo deve ser documentado
- Qualquer pessoa razoavelmente treinada deve conseguir executar
- O resultado deve ser previsível e consistente
- O dono trabalha **no negócio**, não dentro dele

---

## Trabalhar NO negócio vs. DENTRO do negócio

| Trabalhar DENTRO | Trabalhar NO |
|---|---|
| Executar tarefas | Construir sistemas |
| Fazer o trabalho do técnico | Criar processos que outros executam |
| Necessário no início | Necessário para crescer |
| Você é o gargalo | O processo é o ativo |

---

## Os Sistemas que Todo Negócio Precisa

1. **Sistema de marketing** — como gerar leads de forma previsível
2. **Sistema de vendas** — como converter leads em clientes de forma consistente
3. **Sistema de entrega** — como entregar o produto/serviço com qualidade constante
4. **Sistema de gerenciamento** — como a empresa é gerida sem depender do dono

> "Se o seu negócio não pode funcionar sem você, não é um negócio — é um emprego."

---

## Aplicação — WinVision e L.M

| Pergunta Gerber | WinVision | L.M |
|---|---|---|
| O que acontece se você parar? | Sem processo documentado = sem entrega | Time comercial depende de Matheus/Valentino? |
| O que precisa virar sistema? | Scripts de diagnóstico, playbook, CRM | Onboarding, fluxo comercial, daily |
| Você é o técnico ou o dono? | Objetivo: sair da execução e escalar | Objetivo: replicar o processo para o time |

---

**Ver também:** [[$100M Money Models — Hormozi]] | [[Minha Oferta de Serviços — WinVision]] | [[LM — Visão Geral]]

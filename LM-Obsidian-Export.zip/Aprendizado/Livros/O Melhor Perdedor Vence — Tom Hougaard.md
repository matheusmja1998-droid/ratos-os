---
fonte: livro PDF
autor: Tom Hougaard
tags: [trading, psicologia, mentalidade, mercado, perdas, disciplina]
aplicar: [pessoal]
---

# O Melhor Perdedor Vence — Tom Hougaard

## Ideia central

> "Se 'normal' é o padrão que conhecemos, e se 'normal' é abrir uma conta em uma corretora e perder dinheiro — então uma pessoa normal é basicamente uma representante de todas as outras."

O problema no trading não é técnico. É psicológico. As ferramentas não fazem o trader. A mentalidade faz.

---

## A Estatística Que Ninguém Quer Aceitar

Taxas de fracasso nas maiores corretoras de CFD do mundo:

| Corretora | Taxa de fracasso |
|---|---|
| IG Markets | 75% |
| Markets.com | 89% |
| CMC Markets | 75% |
| Saxo Bank | 74% |
| FX PRO | 77% |

> Mais de 70% dos traders de varejo perdem dinheiro — consistentemente, em todas as corretoras, em todos os anos.

**A causa não são as ferramentas ou o mercado. É o comportamento humano normal.**

---

## Por que o Pensamento Normal Não Funciona

O cérebro humano foi moldado por milhares de anos para **sobrevivência**, não para trading. Nossos instintos nos sabotam:

| Instinto natural | O que faz no trading |
|---|---|
| Evitar dor → cortar perdas logo | Sair cedo demais, antes do mercado se recuperar |
| Buscar prazer → realizar lucro logo | Fechar posições vencedoras antes de completar o potencial |
| Seguir o grupo | Comprar nas topos e vender nas baixas (exatamente o oposto) |
| Aversão à perda | Segurar posições perdedoras por tempo demais (esperança) |

---

## O Paradoxo do Título

O **melhor perdedor** vence porque:

1. Aceita perdas pequenas rapidamente — sem ego, sem esperança irracional
2. Deixa posições vencedoras rodarem — sem ansiedade de realizar antes da hora
3. Não precisa ter razão — precisa ser lucrativo

> "O decisor não precisa estar certo. Precisa ser disciplinado."

---

## As Duas Armadilhas Principais

### 1. Revenge Trading (Trading de Vingança)
Após uma perda, entrar imediatamente em nova operação para "recuperar". O estado emocional prejudica o julgamento e amplifica as perdas.

### 2. Hope Trading (Trading de Esperança)
Segurar uma posição perdedora esperando que o mercado volte. A esperança substitui a análise.

> **Regra:** Quando a análise mudou, saia. Quando o stop foi atingido, saia. Sem negociação com você mesmo.

---

## Disciplina Processual

A alta performance no trading não vem de prever o mercado — vem de **executar o processo consistentemente**, independente do resultado de cada operação.

| Trader comum | Trader disciplinado |
|---|---|
| Avalia cada operação pelo resultado | Avalia cada operação pela qualidade do processo |
| Muda o sistema após 3 perdas seguidas | Segue o sistema mesmo em sequências ruins |
| Emocionalmente afetado pelas perdas | Aceita perdas como custo do negócio |

---

## Aplicação Beyond Trading

Os conceitos se aplicam a qualquer área de alta performance com resultados variáveis:

| Princípio | Vendas / Prospecção |
|---|---|
| Aceitar perdas rapidamente | Um "não" rápido libera energia para o próximo lead |
| Não levar para o pessoal | Rejeição não é pessoal — é parte do processo |
| Executar o processo | Foco em ligações/dia, não em resultado/dia |
| Não mudar o sistema após sequência ruim | Prospectar mesmo sem reuniões no dia anterior |

---

**Ver também:** [[Prospecção Fanática — Jeb Blount]] | [[Controle de Pomodoro e Gestão de Tarefas]] | [[Compromissos e Metodologia OAE]]

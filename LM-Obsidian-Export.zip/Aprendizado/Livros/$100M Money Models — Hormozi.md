---
livro: $100M Money Models — Como Ganhar Dinheiro
autor: Alex Hormozi
ano: 2025
páginas: 163
tags: [hormozi, modelos-monetários, ofertas, vendas, negócios]
lido: 2026-04-12
aplicar: [WinVision, LM]
---

# $100M Money Models — Alex Hormozi

## Ideia central

> **Modelo Monetário = uma sequência de ofertas.**
> Você não precisa de um produto melhor. Você precisa de mais ofertas — na ordem certa.

O erro da maioria dos negócios: custa mais conseguir um cliente do que o lucro que ganham com ele. A solução é um Modelo Monetário que **recupera o investimento rapidamente** e maximiza o valor de cada cliente.

---

## Os 4 tipos de oferta

| Tipo | Função |
|---|---|
| **Atração** | Transforma estranhos em clientes |
| **Upsell** | Faz as pessoas gastarem mais |
| **Downsell** | Transforma "não" em "sim" |
| **Continuidade** | Faz as pessoas continuarem comprando |

> "Se você tornar seus clientes 2x mais valiosos, conseguir o dobro deles e conquistá-los 2x mais rápido — seu negócio cresce 8x mais rápido."

---

## Seção II — Ofertas de Atração

> Objetivo: transformar olhares em dinheiro. Oferece algo gratuito ou com desconto para gerar leads e converter em clientes.

### 1. Recupere Seu Dinheiro (Win Your Money Back)
> "Se você fizer X dentro do prazo Y seguindo as regras Z, pode obter gratuitamente."

- Cliente paga e recebe de volta se atingir a meta
- Funciona com coisas que as pessoas começam e abandonam (cursos, emagrecimento, negócios)
- **Na prática:** quem atinge a meta geralmente usa o dinheiro para comprar mais
- **Bônus:** gera prova social e indicações massivas

### 2. Brindes
Ofertas gratuitas para capturar leads. O brinde cobre o CAC da oferta principal.

### 3. Ofertas Falsas (Pseudo-gratuitas)
O cliente "ganha" algo mas precisa fazer uma ação de valor equivalente para receber.

### 4. Compre X e Ganhe Y Grátis
Agrupa produtos para aumentar o valor percebido e justificar preço mais alto.

### 5. Pague Menos Agora ou Pague Mais Depois
Versão de entrada com preço menor — captura quem não compraria o produto completo.

### 6. Oferta de Boa Vontade Gratuita
Entrega valor genuíno sem pedir nada em troca. Constrói autoridade e confiança antes de vender.

---

## Seção III — Ofertas de Upsell

> Objetivo: fazer o cliente gastar mais — agora.
> Regra: ofereça o upsell no momento em que o cliente percebe que precisa da próxima coisa.

### 1. Upsell Clássico
> "Você não pode ter X sem Y."

Exemplo da empresa de armazenamento: primeiro mês grátis → fechadura R$47 → caixas → seguro → upgrade de espaço.
**O cliente foi buscar algo gratuito e saiu gastando R$127.**

**Táticas:**
- Disponibilize o upsell o mais rápido possível (quanto mais rápido o acesso, maior o valor percebido)
- Agrupe em pacotes com nomes: "Pacote Resultados Rápidos", "Pacote Transformação"
- Integre o próximo produto dentro do primeiro produto comprado
- **BAMFAM:** marcar uma reunião a partir de uma reunião

### 2. Upsell no Menu
Apresenta opções de diferentes preços/pacotes. O cliente escolhe — mas sempre compra algo.

### 3. Upsell Âncora
Apresenta um produto muito caro primeiro para ancorar o preço. O produto real parece barato em comparação.

### 4. Upsell de Rolagem
Sequência de ofertas adicionais feitas uma após a outra. Só para quando o cliente diz não em definitivo.

---

## Seção IV — Ofertas de Downsell

> Objetivo: transformar "não" em "sim" ajustando a oferta.
> Você muda **a forma de pagamento** ou **o que o cliente recebe**.

### Processo de Downsell com Plano de Pagamento (7 etapas)

1. **Recompensar pagamento integral** (não punir parcelado)
   - Apresenta o preço com juros incluídos → desconto para quem paga à vista
   - "São R$5.000... mas são R$4.000 se pagar hoje. É o que a maioria faz."

2. **Financiamento por terceiros / cartão de crédito**
   - "Você prefere que eu decida as condições ou você decide?"
   - Quando ele diz que prefere decidir → "Use o cartão de crédito."

3. **Metade agora, metade depois**

4. **Confirmar se ainda quer o produto** (reforçar o desejo antes de continuar)

5. **Dividir em 3 pagamentos**

6. **Pagamentos distribuídos uniformemente**

7. **Teste gratuito** (última opção — menor risco para o cliente)

> **Insight:** faturamento trimestral (4x/ano) reduz churn em relação ao mensal. Menos pontos de decisão = menos cancelamentos.

### Julgamento com Pena (Trial)
Deixa o cliente experimentar antes de pagar. Remove o risco da decisão.

### Vendas com Desconto
Última opção antes de perder o cliente. Use com critério — desgasta o preço se usado com frequência.

---

## Seção V — Ofertas de Continuidade

> "Você pode tosquiar uma ovelha durante toda a sua vida, mas só pode esfolá-la uma vez."
> Você vende uma vez — recebe pagamentos repetidamente.

**Por que continuidade é o melhor modelo:**
- 10 clientes × R$1.000 único = R$10.000
- 40 clientes × R$50/mês × 20 meses = R$40.000

### 1. Bônus de Continuidade
> "Se você se tornar membro, o programa de entrada é gratuito — mais esses bônus exclusivos."

- Foco no bônus, não na assinatura
- Os bônus agem como upsell da continuidade
- Transforme em bônus coisas que você já faz (newsletters antigas, gravações, templates)

**Tipos de bônus:**
- Mais do mesmo: "2 anos de newsletter gratuitos ao se tornar membro"
- Complementar: "Nutrição grátis ao assinar o plano de fitness"
- Upgrade: "Assinatura ouro grátis ao comprar a bronze"

### 2. Desconto por Continuidade
Desconto vitalício em troca de compromisso de longo prazo.
Exemplo: R$50 de desconto por mês para sempre — com compromisso de 12 meses.

### 3. Isenção de Taxa
Remove uma taxa recorrente em troca de assinatura de continuidade.

---

## Seção VI — Construa seu Modelo de Ganhos

### Exemplo real: Gym Launch (negócio de US$100M do Hormozi)

| Fase | Oferta | Valor |
|---|---|---|
| Atração | Cursos gratuitos + call gratuita | R$0 |
| Core | Implementação done-with-you | US$16.000 |
| Upsell | Serviços empresariais avançados | US$42.000/ano |
| Downsell | Parcelamento | US$10k + parcelas |
| Continuidade | Recursos modulares | US$100–800/semana |

**Resultado:** de R$0 para US$475.000/mês em 3 meses.

### Como construir seu modelo

1. **Comece com uma oferta de atração** — resolve o CAC
2. **Adicione um upsell imediato** — aumenta o lucro por cliente
3. **Adicione um downsell** — captura quem diria não
4. **Feche com continuidade** — transforma receita pontual em recorrente

### Regra de precificação
> Aumente o preço em etapas. Muitas respostas positivas → suba o preço. Continue subindo até que o dinheiro extra não compense mais as respostas negativas.

---

## Princípios fundamentais

1. **Troque o mantra:** "isso não vai funcionar para mim" → "como posso fazer isso funcionar?"
2. **Venda agressiva é para produtos fracos.** Faça ofertas no momento certo — não force.
3. **Seja transparente.** Má reputação não tem recuperação.
4. **Qualquer oferta pode ser usada isoladamente, em qualquer ordem.**
5. **Se cliente pedir reembolso, devolva.** Invista em conseguir clientes melhores.

---

## Aplicações diretas para WinVision e L.M

### Ignição Solo → Ignição Comercial
Já é um modelo de atração → upsell. Os R$497 viram crédito no produto de R$5.000. ✅

### O que falta estruturar
- [ ] **Downsell do Ignição Comercial** — qual é o "não" a transformar em "sim"?
- [ ] **Continuidade** — o que vem depois do Ignição Comercial? (ex: assinatura mensal de acompanhamento)
- [ ] **Win Your Money Back** — aplicar no Ignição Comercial: "se não gerar reunião, devolvemos" ✅ (já tem)
- [ ] **Upsell da WinVision** — o que oferecer depois do primeiro produto a clientes existentes?
- [ ] **Protocolo Pipeline Zero** (R$12k) precisa de downsell estruturado

---

**Ver também:** [[Ignição Comercial — Oferta Completa]] | [[Ignição Solo — Oferta]] | [[Mentoria Nimoto — Fundamentos Comercial]]

---
fonte: livro PDF
autor: Marcos Aurélio de Lima (sobre Aristóteles)
tags: [retórica, persuasão, argumentação, ética, paixões, filosofia]
aplicar: [LM, WinVision, pessoal]
---

# A Retórica em Aristóteles

## Ideia central

> "O mais simples dos homens, que tem paixão, persuade mais que o mais eloqüente, que não a tem." — La Rochefoucauld

A retórica para Aristóteles não é manipulação — é a **arte de encontrar os meios de persuasão disponíveis em cada caso**.

---

## Os 3 Meios de Persuasão (Provas Retóricas)

| Prova | O que é | Como usar |
|---|---|---|
| **Ethos** | Caráter e credibilidade do orador | Quem você é antes de falar importa tanto quanto o que você diz |
| **Pathos** | Emoções do auditório | Mover o público para o estado emocional correto para a decisão |
| **Logos** | Argumentos lógicos e racionais | Razões, evidências, estrutura lógica |

> **Aristóteles:** Ethos é o mais poderoso. Sem credibilidade, nem lógica nem emoção convencem.

---

## O Entimema

Versão retórica do silogismo filosófico. Argumento que **não precisa explicar todas as premissas** — porque o auditório já as conhece implicitamente.

**Exemplo:**
> "Empresas que dependem só de indicação estão à mercê do acaso." ← (premissa implícita: indicação é aleatória) → "Você quer previsibilidade?" → Conclusão natural: precisa de outro canal.

---

## Paixões e Orientação do Auditório

Aristóteles catalogou as emoções humanas e como elas afetam o julgamento:

- **Ira → Calma** — audiências iradas não ouvem bem
- **Medo → Confiança** — medo predispõe a aceitar soluções
- **Vergonha → Honra** — apelo à identidade e reputação
- **Inveja → Emulação** — inspirar pela conquista possível, não pelo que outros têm

> A orientação das paixões é ética quando move o auditório em direção a algo verdadeiro e bom.

---

## Retórica e Sabedoria Prática (Phronesis)

Aristóteles conecta retórica com **ética**. Persuadir bem requer não só técnica mas sabedoria prática — saber o que é bom para o auditório, não só o que funciona para convencer.

> Diferença entre o **sofista** (persuade para vencer o argumento) e o **orador ético** (persuade em direção ao bem verdadeiro do outro).

---

## O Sublime e o Belo

A linguagem elevada — metáforas vivas, ritmo, imagens — não é apenas estética. Ela cria **impacto emocional duradouro** que argumentos secos não criam.

> Quem domina linguagem figurada e ritmo atinge zonas do cérebro que o argumento racional não alcança.

---

## Verossimilhança vs. Verdade

A retórica opera no campo do **verossímil** — o que parece verdadeiro ao auditório, o que é provável nas circunstâncias.

> Para persuadir, não basta ter razão. É preciso que o auditório **acredite** que você tem razão.

---

## Aplicação em Vendas e Comunicação

| Conceito Aristotélico | Aplicação Prática |
|---|---|
| **Ethos** | Autoridade construída antes da reunião (cases, conteúdo, apresentação prévia) |
| **Pathos** | Desenvolvimento da dor antes de apresentar a solução |
| **Logos** | ROI, métricas, estudos de caso — justificativa racional |
| **Entimema** | Perguntas que ativam conclusões já implícitas no lead |
| **Verossimilhança** | Linguagem do nicho — falar como o decisor fala |

---

**Ver também:** [[Neurovendas — Simon Hazeldine]] | [[SPIN Selling — Neil Rackham]] | [[Mentoria Nimoto — Execução e Webinar]]

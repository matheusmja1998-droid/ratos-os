---
fonte: livro PDF
autor: Simon Hazeldine
tags: [neurovendas, neurociência, cérebro, decisão, persuasão, vendas]
aplicar: [WinVision, LM]
---

# Neurovendas — Simon Hazeldine

## Ideia central

> "O futuro do seu sucesso em vendas está abrigado naquele um quilo e meio de células cerebrais na cabeça do seu cliente."

Neurovendas aplica descobertas da neurociência para tornar o processo de vendas **amigável ao cérebro** — tanto para o cliente quanto para o vendedor.

---

## Como o Cérebro Toma Decisões

O cérebro não toma decisões de forma puramente racional. A maior parte do processamento acontece no nível **inconsciente**.

- O cérebro consome 20% do oxigênio e energia do corpo
- Decisões são tomadas antes de chegarmos à consciência racional
- Emoções **não atrapalham** a decisão — elas **são** a decisão

> "Vendas amigáveis ao cérebro tornam o processo mais fácil para todos os envolvidos."

---

## Os 3 Cérebros (Modelo Triune)

| Cérebro | Função | O que ativa |
|---|---|---|
| **Reptiliano** | Sobrevivência, instintos básicos, medo, segurança | Ameaças, novidade, contraste |
| **Límbico (mamífero)** | Emoções, memória, relacionamento | Confiança, pertencimento, histórias |
| **Neocórtex** | Lógica, linguagem, razão | Argumentos, dados, justificativas |

> **Insight crítico:** A decisão é tomada pelo cérebro reptiliano e límbico. O neocórtex **justifica** depois.

---

## Os 6 Estímulos que Ativam o Cérebro Reptiliano

| Estímulo | Como usar em vendas |
|---|---|
| **Eu mesmo (self-centered)** | Conecte tudo à situação específica do comprador |
| **Contraste** | Antes e depois, com processo vs. sem processo, concorrente vs. você |
| **Tangível** | Resultados concretos, não promessas abstratas |
| **Início e fim** | O cérebro lembra melhor o começo e o fim — comece e termine forte |
| **Visual** | Imagens processadas 60.000x mais rápido que texto |
| **Emoção** | Emoção + contraste = memória permanente |

---

## Neurônios-Espelho e Rapport

O cérebro humano tem neurônios-espelho — estruturas que **simulam** o estado emocional do outro. Quando você sente entusiasmo genuíno, o cliente sente também.

**Aplicação prática:**
- Rapport não é técnica — é estado emocional sincronizado
- Energia do vendedor contamina o lead
- Ambiente físico e postura afetam o estado do comprador

---

## Dor vs. Prazer — O Princípio Fundamental

O cérebro é 2x mais motivado para **evitar dor** do que para buscar prazer.

> Implicação para vendas: desenvolver as consequências do problema (dor) é mais poderoso do que descrever os benefícios da solução (prazer).

**Conexão com SPIN:** Perguntas de Implicação ativam o sistema de evitação de dor — o mais poderoso motivador de compra.

---

## Confiança — O Pré-requisito de Tudo

O cérebro não compra de quem não confia. Confiança é construída por:

1. **Competência percebida** — você sabe do que está falando
2. **Benevolência percebida** — você quer o melhor para o cliente, não só vender
3. **Integridade** — você entrega o que promete
4. **Semelhança** — cérebros confiam em quem parece parecido

---

## A Decisão Antes da Decisão

Pesquisas mostram que quando um comprador diz "preciso pensar", a decisão já foi tomada inconscientemente. O que ele está fazendo é buscando **permissão racional** para agir.

> **Implicação:** Quando o lead hesita, o problema não é lógica — é emoção não resolvida ou confiança insuficiente.

---

## Aplicação em Diagnóstico / Reunião de Vendas

| Conceito | Aplicação |
|---|---|
| Início forte | Primeiros 90s da reunião definem percepção — entre com presença e propósito |
| Dor antes do prazer | Desenvolver o problema antes de apresentar a solução |
| Visual | Usar exemplos concretos, estudos de caso, dados visuais |
| Contraste | "Empresa sem processo vs. com Ignição Comercial" |
| Fim memorável | Encerrar com a transformação e o próximo passo — não com logística |

---

**Ver também:** [[SPIN Selling — Neil Rackham]] | [[Ignição Comercial — Script de Diagnóstico v2]] | [[Mentoria Nimoto — Fundamentos Comercial]]

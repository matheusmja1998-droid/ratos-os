---
tipo: aula
autor: Leonardo Tabari
curso: Tráfego
numero: 5
tema: Segmentação de públicos no Meta Ads
fonte: PDF resumo oficial Turbo Academy
tags: [meta-ads, públicos, lookalike, remarketing, segmentação]
---

# Tráfego Aula 5 — Segmentações e Públicos

[[Leonardo Tabari — Índice]]

> Segmentar é 1/3 do resultado (mensagem certa + pessoa certa + momento certo). Sem isso, desperdiça orçamento.

## Tipos de público

### Públicos Personalizados (Custom Audiences)
Pessoas que já interagiram com a empresa. Base do remarketing.

Fontes:
- **Site** — Pixel rastreia visitantes, páginas específicas (captura, venda, obrigado), ações (compras, cadastros)
- **Lista de Clientes** — CSV/TXT com e-mail/telefone. Meta busca correspondência.
- **Vídeo** — quem viu X% do vídeo (25%, 50%)
- **Conta Instagram / Página Facebook** — engajou (seguiu, curtiu, comentou, salvou, enviou DM)

### Públicos Semelhantes (Lookalike)
Público FRIO gerado pela Meta a partir de uma fonte de qualidade. Meta encontra usuários similares.

- **1%** = mais semelhante, melhor pra orçamento menor
- **2%, 3%...** = pra escalar (verbas R$100k, R$200k, R$300k+)
- Localização geralmente Brasil

### Direcionamento Detalhado
Demografia + interesses + comportamentos + cargos. Pra alcançar novas audiências.

- **Demográficos** — estado civil, ocupação
- **Interesses** — finanças pessoais, ações, tráfego pago, lutas (aba "Sugestões" é útil)
- **Comportamentos** — comportamento de compra, expatriados

## Dores

- Baixo desempenho por público desqualificado
- Desperdício de orçamento
- Dificuldade em escalar (faltam frios qualificados)
- Sem processo pra criar/nomear/testar audiências
- Remarketing fraco (sem PP básicos)

## Causas

- Pixel não instalado/configurado
- Fonte ruim do Lookalike (ex: video view 3s)
- Segmentação muito ampla ou muito restrita
- Sem estratégia de remarketing
- Nomenclatura confusa

## Boas práticas

- Estruturar conta antes das campanhas — criar conjunto fundamental de audiências
- Lookalike a partir de fontes de alta intenção: lista de clientes, compradores (Purchase), 25%/50% de vídeo de vendas
- Começar Lookalike em 1%, escalar conforme verba
- Testar interesses isolados (não misturar muitos no mesmo conjunto)
- Nomenclatura padrão: `[Tipo] - [Fonte] - [Detalhe] - [Período]` (ex: `PP - Site - Visitou PagVendas NÃO Comprou - 15D`)

## O que fazer

- Instalar e verificar Pixel
- Criar PP base: engajamento IG 365D, video view 25%/50% 180D, visitantes do site 180D
- Lookalike a partir de listas de clientes/leads
- Localização correta (Brasil normalmente)
- Explorar "Sugestões" pra novos interesses
- Excluir compradores das campanhas de aquisição

## O que NÃO fazer

- Iniciar sem estratégia de remarketing
- Lookalike de fonte de baixa intenção (curtidas genéricas)
- Empilhar dezenas de interesses num só conjunto
- Ignorar segmentação de idade/gênero/idioma
- Não atualizar listas de clientes

## Exemplos

### Carrinho abandonado
- Site → Visitou `pagina-de-vendas` últimos 15 dias
- Excluir: visitou `pagina-de-obrigado` últimos 180 dias
- Nome: `PP - Site - Visitou PagVendas NÃO Comprou - 15D`

### Lookalike clientes e-commerce
1. PP - Lista - Melhores Clientes - [data] (sobe CSV)
2. LK 1% BR da lista

### Curso de finanças (Direcionamento Detalhado)
- Idade 25–45
- Interesses: finanças pessoais, investimento, ações
- Clicar "Sugestões" → renda variável, bolsa de valores, apps XP/Rico

## Próximos passos

Públicos pra cada etapa do funil C1/C2/C3 → [[Aula 19 — Distribuição C1 C2 C3]]

## Glossário

- **Retenção** — período (dias) que pessoa fica no público após a ação
- **Público-base / Fonte** — audiência original do Lookalike (qualidade da fonte define qualidade do LK)
- **Remarketing** — anunciar pra quem já interagiu (PP)
- **Público Frio** — não conhece a marca (Lookalike, Detalhado)

## Links

- [[Tráfego Aula 1 — Introdução e métricas]]
- [[Tráfego Aula 4 — Pixel e eventos]]
- [[Aula 19 — Distribuição C1 C2 C3]]
- Sobral cobre o tema em [[Live 367 — Como segmentar seus anúncios — Guia definitivo]]

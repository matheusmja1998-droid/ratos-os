---
tipo: aula
autor: Leonardo Tabari
curso: Tráfego
numero: 4
tema: Pagamentos + Pixel + Eventos de rastreamento
fonte: PDF resumo oficial Turbo Academy
tags: [pixel, capi, eventos, hotmart, wordpress, gtm]
---

# Tráfego Aula 4 — Configurações: Pagamentos, Pixel e Eventos

[[Leonardo Tabari — Índice]]

> Pilares técnicos pra operar Meta Ads: método de pagamento + instalação do Pixel + uso estratégico de eventos padrão.

## Conceitos

- **Pixel do Meta** — JavaScript no site que rastreia ações. Ponte de dados entre site e Gerenciador. Crucial pra medir, criar públicos personalizados e otimizar pra conversões.
- **Eventos Padrão** — ações predefinidas reconhecidas pelo Meta: PageView, AddToCart, InitiateCheckout, Purchase. Algoritmo entende melhor que eventos personalizados.
- **API de Conversões (CAPI)** — rastreamento mais robusto, envia dados servidor-a-servidor. Contorna bloqueadores e restrições de privacidade (ATT da Apple).
- **ID do Pixel** — número de identificação. Usado em integrações simplificadas (plugins, plataformas).

## Dores

- Campanhas paradas por falha em pagamento ou falta de fundo
- Impossível medir resultados sem Pixel correto
- Pixel só no site, sem checkout → perde dados de venda
- Bloqueio por falta de permissão (sem "Controle Total")
- Eventos personalizados em vez de padrão → otimização pior

## Causas

- Configuração apressada (fuso horário errado, ciclos de cobrança bagunçados)
- Hierarquia de acessos incorreta (criou conta mas não atribuiu Controle Total)
- Pixel no `<body>` em vez do `<head>`
- Esquecer integração no checkout (Hotmart, Kiwify)

## Boas práticas

- Configurar pagamento antes de qualquer campanha
- WordPress: plugins **"Heads & Footers"** ou Código Personalizado do Elementor Pro
- Profissional: **Google Tag Manager (GTM)** pra escalar
- Priorizar eventos padrão; só personalizar quando não houver padrão
- Verificação dupla — Pixel no site E na plataforma de checkout

## O que fazer

- Verificar permissões — "Controle Total" sobre Conta + Pixel
- Configurar fuso (America/Sao_Paulo) e moeda (BRL)
- Instalar código base no `<head>` de todas as páginas
- Integrar **ID do Pixel** no checkout (Hotmart etc.)
- Usar eventos padrão relevantes: PageView, ViewContent, AddToCart, InitiateCheckout, Purchase
- Validar com **extensão Meta Pixel Helper** no Chrome

## O que NÃO fazer

- Iniciar campanha sem método de pagamento validado
- Atribuir permissões parciais a quem precisa de Controle Total
- Instalar Pixel só na home — tem que estar em todo o site
- Esquecer rastreamento no checkout (onde acontece a conversão)
- Criar conversão personalizada pra ação que já tem evento padrão (ex: criar "compra" custom em vez de usar Purchase)

## Exemplo 1 — WordPress (sem código)

1. Gerenciador de Eventos → seu Pixel → "Continuar a configuração" → "Pixel do Meta" → "Instalar manualmente" → Copiar código
2. WordPress → Plugins → instalar **Heads & Footers**
3. Code Snippets → Header & Footer → colar código no Header → salvar

## Exemplo 2 — Hotmart

1. Obter **ID do Pixel** (número longo no Gerenciador de Eventos, ou dentro de `fbq('init', 'ID_AQUI');`)
2. Hotmart → Ferramentas → Pixel de Rastreamento → escolher produto → "Meta" → colar ID → configurar eventos → salvar

## Próximos passos

- Implementar **API de Conversões (CAPI)** — padrão ouro pra rastreamento robusto

## Glossário

- **Head HTML** — seção de metadados; lugar correto pro código base
- **GTM** — Google Tag Manager
- **Controle Total** — permissão máxima em ativos do Meta Business

## Links

- [[Tráfego — Estruturas oficiais Meta]]
- [[Tráfego Aula 1 — Introdução e métricas]]
- [[Tráfego Aula 5 — Segmentações e públicos]]

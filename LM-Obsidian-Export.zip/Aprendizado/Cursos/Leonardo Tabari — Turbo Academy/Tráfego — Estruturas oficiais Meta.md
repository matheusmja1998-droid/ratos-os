---
tipo: aula
autor: Leonardo Tabari
curso: Tráfego — Estruturas Oficiais
tema: Perfil pessoal + Página + Instagram comercial + Business Manager + 2FA
fonte: PDF resumo oficial Turbo Academy
tags: [meta-ads, business-manager, estruturação, segurança, 2fa]
---

# Tráfego — Estruturas Oficiais Meta

[[Leonardo Tabari — Índice]]

> Configuração da base estrutural pra anunciar no Meta com segurança, sem bloqueios e organizado profissionalmente.

## Ativos fundamentais

- **Perfil Pessoal Facebook** — seu "CPF" digital. Chave de acesso pra criar e gerenciar todo o resto. Sem perfil, não anuncia.
- **Página Facebook (Fan Page)** — "CNPJ" digital. Todo anúncio é associado a uma Página.
- **Perfil Comercial Instagram** — versão otimizada pra negócio. Métricas avançadas, botões de contato, integração total com Meta Ads, "turbinar".
- **Conta de Anúncios** — onde campanhas são criadas, gerenciadas e pagas. Tem ID único.
- **Business Manager (BM)** — "holding" dos ativos. Centraliza múltiplas Páginas, contas, perfis IG, Pixels e permissões.

## Dores

- Bloqueios imediatos de contas e perfis
- Limitação de ferramentas (não dá pra criar públicos avançados, turbinar corretamente)
- Risco de hackeamento sem 2FA
- Gestão desorganizada misturando ativos pessoais e profissionais

## Causas dos erros

- **Perfis pessoais "frios"** — criar perfil hoje e abrir Página/Conta no mesmo dia gera comportamento suspeito pro algoritmo Meta. Comum em nichos black. Resultado: bloqueio preventivo.
- **Instagram em "Pessoal" ou "Criador de Conteúdo"** — limita ferramentas exclusivas do "Comercial"
- **Ausência de BM** — gerenciar tudo pelo perfil pessoal é dependência perigosa. Se bloqueia o perfil, perde tudo.

## Boas práticas

- **Princípio do aquecimento** — usar perfil pessoal antigo, ativo, com amigos, postagens, foto, informações preenchidas. Se não tiver, usar perfil de pessoa de confiança (sócio).
- **Centralização via BM** — criar BM desde o início como dona de tudo
- **Segurança** — **Autenticação de Dois Fatores (2FA)** no perfil pessoal e principalmente na BM
- **Instagram comercial** sempre

## O que fazer

- Usar perfil pessoal maduro e ativo
- Criar Página específica do projeto
- Configurar/converter Instagram pra Comercial
- Criar BM
- Vincular Página, Conta de Anúncios e Instagram à BM
- Ativar 2FA em perfil pessoal e BM
- Se não tem perfil aquecido, usa o de um sócio de confiança

## O que NÃO fazer

- NÃO criar perfil hoje pra anunciar amanhã
- NÃO usar Instagram "Pessoal" ou "Criador" pra campanhas profissionais
- NÃO gerenciar múltiplos ativos direto do perfil pessoal sem BM
- NÃO compartilhar login/senha — usar permissões da BM
- NÃO ignorar 2FA

## Tarefas iniciais

1. Auditoria do perfil pessoal (ativo, informações preenchidas)
2. Criar Página Facebook da empresa
3. Converter Instagram pra Comercial
4. Criar BM em `business.facebook.com/overview`
5. Vincular Página + Conta de Anúncios + Instagram na BM
6. Ativar 2FA pra todos os admins da BM

## Exemplo aplicado (Jardim Urbano — paisagismo)

**Errado:** sócio cria perfil novo "João Marketing Jardim Urbano" → cria Página → tenta abrir Conta de Anúncios no mesmo dia. **Resultado:** Facebook identifica como suspeito → bloqueia perfil e/ou conta.

**Certo:** usar perfil da parceira de negócio (8+ anos, ativo, amigos) → criar BM da empresa pelo perfil dela → criar Página + Conta + vincular Instagram comercial dentro da BM → adicionar o sócio como admin com permissões necessárias → ativar 2FA. **Resultado:** estrutura sob perfil confiável, segura, escalável.

## Glossário

- **Perfil Aquecido** — perfil com histórico genuíno
- **Ativos** — Páginas, Contas, Pixels, Públicos
- **Pixel** (agora "Conjunto de Dados") — código no site que rastreia ações
- **2FA** — autenticação de dois fatores

## Links

- [[Tráfego Aula 4 — Pixel e eventos]]
- [[Tráfego Aula 1 — Introdução e métricas]]
- Conferir paralelo no Sobral: [[Live 333 — Onboarding de clientes — Tutorial à prova de falhas]]

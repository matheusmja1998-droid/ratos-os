---
tipo: aula
autor: Leonardo Tabari
curso: Segredo do ROAS 5X
numero: 21
tema: Estrutura emocional — parar de se sabotar no digital
fonte: PDF resumo oficial Turbo Academy
tags: [mindset, autossabotagem, antifrágil, métricas-reais, foco]
---

# Aula 21 — Estrutura Emocional no Digital

[[Leonardo Tabari — Índice]]

> Mecanismos de autossabotagem que comprometem resultados mesmo com conhecimento técnico. Como construir estrutura emocional sólida, tomar decisões assertivas e criar rotinas que geram crescimento sustentável.

## Conceitos

- **Autossabotagem no digital** — comportamentos/crenças/decisões que impedem resultado mesmo com técnica
- **Estrutura emocional** — capacidade de lidar com altos e baixos, manter foco e clareza
- **Consistência e execução** — repetição disciplinada de ações validadas, evitar mudanças constantes
- **Métricas reais × métricas de vaidade** — lucro/vendas/leads qualificados vs likes/seguidores/views

## Analogias

- **Montanha-russa do digital** — poucos têm crescimento linear, a maioria oscila
- **Funil de plantio e colheita** — resultado não é imediato; plantar pra colher

## Principais dores

- Oscilação de resultados (faturamento alto seguido de queda)
- Frustração / vontade de desistir (prejuízos, lançamentos ruins, críticas)
- Paralisia por análise (planejamento excessivo, busca por perfeição)
- Síndrome do objeto brilhante (troca constante de estratégia)
- Comparação destrutiva
- Vício em cursos sem implementar
- Necessidade de aprovação externa
- Fuga pro operacional (técnico em vez de estratégico)

## Causas

- Decisões emocionais (ansiedade, frustração, euforia)
- Falta de clareza nas métricas (vaidade vs real)
- Não assumir responsabilidade (culpar mercado, equipe, concorrência)
- Sem rotina de análise (não registrar erros)
- Procrastinação produtiva (tarefas secundárias pra fugir das principais)

## Soluções

- **Planejamento simples e direto** — focar no essencial
- **Execução disciplinada** — priorizar ações que geram resultado
- **Registro diário de autossabotagem** — caderno
- **Conversas difíceis** — feedback sincero entre lançadores e especialistas
- **Regras inquebráveis** — compromissos claros, sem negociar consigo mesmo
- **Celebração de microvitórias** — manter motivação (dopamina diária)
- **Foco em métricas reais** — dinheiro no bolso, leads qualificados, dias de execução sem falha
- **Ressignificação do fracasso** — erros como feedback prático
- **Gestão do tempo de colheita** — diferentes nichos têm tempos diferentes

## O que fazer

- Planejar, executar, analisar em ciclos curtos
- Simplificar processos
- Anotar diariamente como se sabotou
- Focar em UMA estratégia até validar
- Celebrar cada venda/lead
- Assumir total responsabilidade
- Estabelecer regras pessoais inquebráveis
- Decisões importantes em estado calmo
- Cortar pessoas tóxicas, hábitos ruins, distrações
- Compartilhar planos só com quem torce a favor

## O que NÃO fazer

- Trocar estratégia antes de validar
- Buscar perfeição antes de lançar
- Consumir curso sem implementar
- Focar em vaidade
- Decidir em ansiedade/euforia
- Compartilhar com negativos
- Fugir do estratégico pro operacional
- Se comparar com outros players

## Ferramentas e práticas

- **Caderno de autossabotagem** — diário
- **Mapa mental de sabotadores** — identificar padrões + plano de ação
- **Checklist de execução** — tarefas essenciais marcadas
- **Rotina semanal de análise** — revisar resultados, erros, acertos
- **Planilha de métricas reais** — vendas, leads, lucro, dias sem falha
- **Reuniões de feedback mensais** — equipe + especialistas
- **Automação** — Hotmart, LeadLovers, RD Station
- **Exercício de ressignificação** — após cada erro, escrever aprendizado e ajustar plano

## Exemplos

### Funil low-ticket
Especialista tentou vender curso R$97, sem vendas. Reduziu pra R$17 → 50–60 vendas/dia, CAC R$13, com lucro. **Lição:** não ter vergonha de testar preço baixo; o importante é validar.

### Registro de autossabotagem
Profissional percebe que procrastinou estratégico pra organizar arquivos → anota → dia seguinte prioriza estratégico.

### Tempo de colheita high-ticket
Mentoria alto valor — 3 a 6 meses pra converter. Exige construção de confiança.

### Regras inquebráveis
Compromete-se a executar uma estratégia por 90 dias, ajustando só detalhes.

## Aplicação no dia a dia

- Implementar registro diário
- Uma estratégia por vez até validar
- Reuniões de feedback e conversas difíceis com equipe
- Métricas reais + ajustar expectativa ao tempo de colheita do nicho
- Rotina de celebração + disciplina

## Próximos passos / temas correlatos

- Gestão emocional e inteligência financeira
- Estratégias de lançamento e funis
- Liderança e comunicação assertiva
- Automação e dados pra escalar

## Leituras

- *Antifrágil* — Nassim Taleb
- *Os Segredos da Mente Milionária* — T. Harv Eker
- *O Poder do Hábito* — Charles Duhigg
- *Mindset* — Carol Dweck

## Glossário

- **Métricas de Vaidade** — likes, seguidores, views
- **Métricas Reais** — lucro, vendas, leads qualificados

## Links

- [[Aula 1 — Funil 8 — Fundamentos]] (mentalidade antifrágil)
- [[Aula 22 — Plataformas e Tributação]]

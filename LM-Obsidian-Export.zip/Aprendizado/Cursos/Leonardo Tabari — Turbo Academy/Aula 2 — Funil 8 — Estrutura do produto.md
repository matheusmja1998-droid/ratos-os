---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 2
tema: Estrutura e criação do produto de R$17 + order bumps + estrutura das 7 aulas
fonte: Transcrição automática do áudio MP3 (faster-whisper)
duração: ~16 min
tags: [funil-8, produto, order-bump, opcell, aulas, antifrágil, seed]
---

# Aula 2 — Funil 8: Estrutura e criação do produto

[[Leonardo Tabari — Índice]]

> Como montar a estrutura do Funil 8 (produto R$17 + 3 order bumps + opcell) e o método pra criar o produto com 7 aulas em sequência de copy.

## Estrutura básica

**4 produtos:**
- 1 produto principal de **R$17**
- 3 order bumps em **escadinha** (pode ser R$62/R$35/R$17 ou R$35/R$26/R$17) — do que vende mais pro que vende menos, sempre 3
- 1 **opcell até R$98** (opcional)

**Opcell** — algo pra comprar sem pensar: ferramenta, conjunto de planilhas, contrato, modelo, superfile, aula ao vivo. Tabari prefere vender **ticket de lançamento pago com desconto especial** no opcell.

⚠️ Cuidado: se a pessoa paga PIX no opcell, não aparece direto na Hotmart click → mandar WhatsApp pra fazer o click.

**Order bumps** — books, outros cursos, qualquer coisa de valor baixo que dispare "preciso disso".

Case: a própria gerente Hotmart entrou no produto da especialista de emagrecimento, foi clicando nos order bumps "preciso disso, preciso disso", comprou os 3 + opcell de lançamento pago. Em reunião disse: "caí na minha própria armadilha". Ticket médio sobe muito.

**Múltiplos Funil 8?** Pode, mas não recomenda nos primeiros 6 meses. Foca em UM Funil 8 até dominar.

## Criação do produto

### Nome
- Nome = **transformação direta**
- Não pode subir nível de consciência ("Método 3Ps", "Protocolo XY14" — não usa)
- Tem que ser claro: "Como perder 5kg em 7 dias", "Como ganhar R$20k limpinho/mês", "Como aprender gestão ágil em 3 dias", "Como economizar 5h de trabalho/dia"
- Padrão: começar com **"Como..."** seguido da promessa direta (à la Pablo Marçal)
- Exceção: público com nível de consciência já alto (ex: "Como aplicar o Funil 8" pra quem já conhece Funil 8)

### NÃO pode ser
- E-book
- Pedaço do curso principal arrancado
- Seus CPLs reaproveitados

### Tempo de produção
- **3 horas** pra gravar o curso completo
- Exceção: nichos com produção manual (confeitaria)

## Estilo do produto — Lançamento Gratidão

- **Entregar muito** — pessoa elogia, comenta, compartilha
- Compra depois por **reciprocidade**
- Mostrar oportunidade clara, tirar da zona de conforto
- Simples — pessoa assiste e pensa "eu dou conta"
- Gerar **muito desejo** de executar
- **Vitória durante o produto** — pessoa sente vitória só de assistir
- Mostrar **próximo passo (seed)** pro produto principal — esteira clara, senão ela compra do concorrente

**Objeção comum:** "Não é ruim entregar demais no produto barato? Não desvaloriza o expert?"

Resposta do Tabari: pelo contrário. A pessoa fica grata, divulga, compartilha. O conteúdo que você já entrega de graça no YouTube/Instagram é mais que isso — só que desorganizado. Quando entrega organizado em curso, gratidão sobe.

## Estrutura das 7 aulas (+ Aula 0)

Sequência lógica, cada aula **10–20 min** (pode 7–8 min em alguns casos, mas não muito curtas).

### Aula 0 — Combinados
Igual à dele: o que a pessoa vai ganhar, pedir Instagram, ficha de matrícula, assistir tudo. → [[Aula 0 — Funil 8 — Boas-vindas]]

### Aula 1 — Fundamentos + Mentalidade Antifrágil
- **Fundamentos lógicos do método** — pessoa sai entendendo a lógica do que vai aplicar
- **Mentalidade antifrágil** — segunda parte da aula. Tabari mandou estudar sozinho no curso dele, mas pro aluno é importante incluir, principalmente público de renda mais baixa. Sem antifragilidade, a pessoa desiste e se sente derrotada.
- Criar **mapa mental com todos os fundamentos** pra não esquecer nada

### Aula 2 — Mão na massa + primeiros passos
- Pessoa começa a executar
- Primeiros passos práticos
- Sair com sensação de alívio ("consigo fazer")
- Mentalidade bem leve

### Aula 3 — Aprofundamento + Primeiro marco
- Aprofundar no método
- Definir **primeiro marco** claro ("nessa aula você já tem que ter perdido 1,5 kg" / "já tem que saber criar seu curso")
- Dar uma meta tangível

### Aula 4 — Superar obstáculos (quebra de objeção) + PrePitch
- Aula de **quebra de objeção** (obstáculo = objeção)
- **Intencional:** fazer **seed pro produto principal**
- **Prepitch** pra deixar pessoa com desejo

### Aula 5 — Segundo marco
- Aprofundar ainda mais no método
- Mostrar otimizações, melhorias, correção de problemas
- **Segunda vitória** — sensação de subir escadinha
- Quase comemoração + fechamento de ciclo

### Aula 6 — Introdução ao método principal
- Aula introdutória ao produto principal
- **Overdelivery** — entrega mais do que esperava
- Pessoa fica com desejo do principal sem você vender

### Aula 7 — Próximo passo natural
- Mostrar produto principal como **jornada natural**
- "Venda sem vender" — pitch sem pitch
- Mostrar toda a esteira
- CTA: link do comercial / WhatsApp / lista de espera

## Material de apoio

Tabari deixa **PDF + mapa mental** abaixo das aulas pra reforçar (sabe que aluno esquece, então tem material físico pra consulta).

## Links

- [[Aula 0 — Funil 8 — Boas-vindas]]
- [[Aula 1 — Funil 8 — Fundamentos]]
- [[Aula 3 — Funil 8 — Estrutura de tráfego pago]]
- Estrutura aplicada em lançamento: [[Tabari — 1M por mês com lançamentos gravados]] (7 aulas no modelo desafio)

## Transcrição completa

`Transcrições/Transcrição — Aula 2 Estrutura do produto.md`

---
tipo: aula
autor: Leonardo Tabari
curso: Segredo do ROAS 5X
numero: 22
data: 2025-09-15
tema: Plataformas e tributação — como escolher e pagar menos imposto legalmente
fonte: Transcrição da live (PDF)
tags: [tributação, lucro-presumido, isbn, hotmart, plataformas, e-book, infoproduto]
---

# Aula 22 — Plataformas e Tributação

[[Leonardo Tabari — Índice]]

> Como economizar imposto legalmente transformando material em produto de imunidade tributária (livro/e-book/audiobook) + critérios reais pra escolher plataforma além da taxa nominal.

⚠️ Aula sensível — Tabari deixa claro: NÃO é sobre sonegar, é sobre estruturação inteligente. Procure tributarista especializado. Ele cita case próprio de multa de R$700k da Receita.

## Tributação — o problema central

Brasil é caro pra quem não domina a legislação. Grandes empresas (Coca, McDonald's) pagam pouco imposto porque investem em tributaristas. **95% das empresas pagam mais imposto que necessário** porque o contador genérico não entende digital.

## Solução geral

Transformar parte dos materiais em **livro/e-book/audiobook/PDF/mapa mental** — material didático tem **imunidade tributária pela Constituição (Art. 150)**.

Decisão STF 08/03/2017: e-book equiparado a livro físico → isento.

## Jornada por faturamento

| Faturamento/mês | Regime | Estratégia |
|---|---|---|
| Até R$10k | MEI | Foco em vender, não otimizar. ~R$70 fixo. |
| R$10k–R$50k | Simples Nacional | Não precisa de e-book ainda. Separar 30% como e-book pra criar histórico (não muda imposto). Registrar no ISBN pra proteger direito autoral. Economiza ~20%. |
| R$50k–R$200k | Lucro Presumido | Estratégia híbrida ~60/40. Tributarista especializado. Economia ~35%. |
| R$200k+ | Lucro Presumido + estrutura completa | Holding patrimonial, time especializado (contador + advogado + tributarista). Economia ~40%. |

Acima de R$600k/ano (R$50k/mês), o Lucro Presumido empata com Simples e vale a pena migrar.

## E-book FAKE × E-book CERTO

**FAKE (multa garantida):**
- Print de slide, PDF de 10 páginas, transcrição crua sem revisão

**CERTO:**
- **Revisado e diagramado** pelo especialista
- Parecer **livro de verdade**: capa, contracapa, conteúdo estruturado, formato eletrônico
- **Registrado no ISBN / Biblioteca Nacional (CBL)** — taxa ~R$100, dá pra fazer sozinho
- Ter audiobook, mapa mental, quiz, materiais de apoio comprovam o didático
- Disponível na plataforma (se fiscal pedir, tem que estar lá)

> Quanto mais parecido com livro, mais fácil da Receita aceitar.

## Proporção produto-imune × serviço

| Tipo de produto | % Imune | % Serviço |
|---|---|---|
| Low-ticket (R$17–R$300) | 90% | 10% (curso curto, sem mentoria) |
| Curso médio (R$2.000) | 75% | 25% (videoaulas + lives gravadas) |
| Mentoria com encontros | 50% | 50% (suporte ativo) |
| Mentoria high-ticket (R$35k) | 35% | 65% (atendimento contínuo) |

Quanto maior o preço, mais serviço agregado tem.

## O que NÃO fazer

- E-book fake (print, PDF cru, transcrição)
- Não registrar no ISBN — primeira coisa que o fiscal pede
- Copiar estratégia genérica (todo mundo com mesmo "70-30" cai junto)
- Não revisar estratégia ao menos 1x/ano
- Mudar proporção bruscamente (vai chamar atenção da Receita)
- Faturar muito e "depois resolver" — depois é mais caro

## Documentação que precisa estar pronta

- ISBN/registro Biblioteca Nacional
- Laudo do contador (se tiver)
- Print da área de membros mostrando os e-books
- Notas fiscais de vendas organizadas
- E-mails de troca com contador
- **Parecer tributário** personalizado pra empresa (não é template — descreve as atividades específicas de cada empresa: o do Bruno é diferente do da Patrícia, é diferente do dele)

Custo do parecer tributário: ~R$40k pra empresa grande; R$15–20k pra empresa menor. Vale pela economia.

## Quem ele indica (sem ganho — só recomendação)

- **Contabilidade pra quem começa:** Acontec (~R$400/mês)
- **Tributarista (case dele):** Igor (a indicação ele forneceu por contato direto na live)

## ICMS, IRPJ, CSLL, PIS, COFINS, ISS

- **ICMS** — só se vender produto físico (camiseta, garrafinha). Infoproduto não tem.
- **IRPJ** — não foge. Lucro presumido = 32% presumido × 15% líquido. ~5%
- **CSLL** — sobre o presumido também
- **ISS** — serviço prestado. 2–5% conforme município (Barueri é mais barato; BH cobra 2%)
- **PIS/COFINS** — federal

Pacote completo no Lucro Presumido sem otimização: ~17%. Com estratégia: ~8%.

## Latam

Venda fora do Brasil não tem ICMS/PIS/COFINS — só imposto de renda se trouxer o dinheiro pro Brasil. Se não trouxer, nem isso.

## Cliente grande com passivo acumulado

Recomendação do Tabari: abrir CNPJ novo, fechar o antigo. A Receita não costuma ir atrás de empresas fechadas — foca nas abertas. Aluno dele atrasou notas, organizou tudo pela Acontec, emitiu 1 partezinha por mês, regularizou em 6 meses sem multa.

## Case extremo

Player grande de Brasília tomou multa de R$35 milhões. Tinha parecer tributário bem feito → no colegiado (5 pessoas), reduziram pra R$1k (uma nota esquecida). **Sem o parecer, teria pago os R$35M.**

Outro case: advogada amiga de BH pagou R$2M de imposto em 2021, R$3M em 2022. Em 2023 quebrou. Tabari diz que se ela tivesse feito 60-40, teria salvado R$3M em caixa — empresa não teria quebrado.

---

# Plataformas

Tabari já testou: Eduzz, Hotmart, Pagar.me + Guru, PagTrust, Kiwify, Edu Monetize, PagTrade, Rubla, TMB.

## Critério REAL pra escolher (não é taxa)

> A pergunta não é "qual é mais barata?". É **"qual me faz ganhar mais?"**.

Pra quem fatura R$200k/mês, 1% = R$2.000/ano. Não vale brigar por isso se outra plataforma converte mais.

## Hotmart — escolha dele

**Taxa:** R$0,99 + R$1/venda no início, escala com faturamento.
- R$50k/mês: ~7%
- R$100k/mês: ~6%
- R$500k/mês: ~5,1%
- R$8M/ano+: negociação individual

**Pra Tabari:** próximo a 5% no produto normal, abaixo de 4% no high-ticket.

**Vantagens:**
- **Gateway próprio + 28 gateways atrelados** — aguenta picos (mil vendas em 5 min, 30 mil em 1h30). Outras plataformas caem em escala (Pagar.me caiu com 30k vendas no Coguru; Ticto caiu no lançamento do FIT).
- **API completa** — não só webhook. Dá pra puxar % assistido do aluno, montar dashboards.
- **Clube + Tutor (área de membros)** — melhor que Cursa Educa, Academe, Arsenal Members, Da Vump. Tutor com IA dentro.
- **IA de vendas automática** — anunciada pra começar (chega pré-preenchida no checkout, IA tenta a venda)
- **Recuperação aprovada de cartão** maior — case real: cliente saiu da Eduzz com R$10M/ano + problemas → Hotmart, virou ~R$30M/ano
- **Não cobra compra cancelada** (outras cobram a taxa mesmo cancelado)

## Outras plataformas — uso específico

- **Kiwify** — 2ª maior do mercado. Dashboard bonito. Eventos top (festas, viagens). Taxa 8,99 + R$2,49/venda. Funciona bem pra quem inicia; pra grande, falta integração.
- **PagTrade** — melhor pra **teste de low-ticket**. Rápido, calcula tudo, link único pro tráfego.
- **Rubla** — boa pra comunidade/grupos de WhatsApp.
- **Eduzz** — taxa mais barata na superfície MAS cobra cancelamento.
- **TMB** — boleto parcelado com negativação/protesto. Bom pra high-ticket. Cancelamento = 20% multa pró-rata. A Hotmart vai liberar similar em breve.

## Combinação ideal do Tabari

> "PagTrade no low-ticket, Hotmart nos valores mais altos e TMB no boleto. Essa é a escolha perfeita se você não tiver contrato de fidelidade."

## Recomendação final por porte

- **Faturando <R$10k/mês** — usa qualquer uma, não faz diferença
- **R$10k+** — vai pra Hotmart criar autoridade lá dentro e ir baixando a taxa
- **Quer escalar de verdade (8M+/ano)** — Hotmart garantido

## Migração TMB → Hotmart

Tabari ainda usa TMB pra parcelamento com negativação. Hotmart deve liberar similar (dia 15 do mês da gravação). Aí migra. Pra cancelamento: contrato de financiamento separado do contrato de pós-graduação — TMB ganha causa no juiz.

## Links

- [[Aula 21 — Estrutura emocional]] (mentalidade pra construir)
- [[Aula 1 — Funil 8 — Fundamentos]] (mentalidade antifrágil)
- Sobral cobre operação cliente em [[Live 333 — Onboarding de clientes — Tutorial à prova de falhas]]

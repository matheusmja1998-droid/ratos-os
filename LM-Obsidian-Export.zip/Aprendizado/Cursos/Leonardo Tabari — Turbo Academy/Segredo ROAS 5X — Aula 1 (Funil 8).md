---
tipo: aula
autor: Leonardo Tabari
curso: Segredo do ROAS 5X
numero: 1
data: 2025-04-01
tema: Funil 8 — estratégia, otimização, criativos, copy
fonte: Transcrição da live (docx)
tags: [funil-8, roas, low-ticket, advantage, criativos, order-bump]
---

# Segredo ROAS 5X — Aula 1 (Funil 8 — 01/04/2025)

[[Leonardo Tabari — Índice]]

> Primeira live semanal "Segredo do Rô 5" (terças 17h/18h). Estratégia que tem funcionado pra Tabari e seus alunos/mentorados. Não é gravada — exclusiva ao vivo, interação via chat.

## Objetivo do Funil 8

- **Comprar leads a custo zero** diante do aumento de custos de lead, CPM e tráfego
- **Monetizar a entrada** com produtos baixo custo (R$17) com cópia eficaz
- Construir **base de compradores qualificados** com produtos interligados
- Servir como **porta de entrada** pra produtos subsequentes

## Tráfego pago + fluxo de caixa

- Tráfego pago **com o próprio funil** = retorno rápido do investimento
- Hotmart paga em 2 dias; outras em 7 dias → fluxo rápido pra cobrir fatura/despesas
- Vender R$100k de low-ticket exige fluxo rápido

## Lucro × Escala

- Lucro é possível (aluno fez R$5k de lucro em março), MAS foco não é lucro imediato
- **ROAS 1,2** = escala sustentável (gastar R$1k/dia, faturar R$1,2k/dia)
- Considerar taxa Hotmart até 8% + Simples Nacional 7–8%

## ROAS e margem

- **1,2** — empate (sem lucro)
- **1,5–1,6** — margem pra escalar; investimento adicional gera aumento proporcional mesmo com ROAS caindo até teto
- **Escala em platôs** — aumenta verba, vê pequeno aumento, otimiza no platô mantendo 1,2

## Entrada × Produto Principal

- Entrada R$17 leva ao produto principal (média R$1.000)
- Conversão 5% de 500 leads = 25 vendas principal = **R$25k sem custo adicional de lead**

## Métricas médias

- 1.000 vendas de tickets/mês (33/dia) = escala razoável
- LTV obrigatório — cliente compra mais de uma vez, sem isso o funil falha

## Produtos de baixo custo — boas práticas

- **Resultado rápido**, não complexo (e-book não gera transformação)
- **Duração máxima 2h**, aulas de 10 min
- "Lançamento de gratidão" gera transformação mas não venda
- Criar **desejo pelo próximo nível** mostrando escadinha de valor

## Origem (referência)

- **Ricardo Massima** — sucesso com low-ticket R$60
- **João Pedro Angeloni** — produtos R$7 pra construir lista massiva
- Funil 8 combina: transformação rápida + otimização contínua

## Estrutura de campanha

- **Campanhas de conversão pra venda** (não lead, não checkout iniciado)
- Pode usar conversão personalizada, mas monitorar diariamente
- **Público frio = escala real**, quente ajuda na conversão
- **Advantage+** pra orçamento ≤R$500/dia (testa 10 criativos simultâneos)
- Acima de R$500/dia: otimização automática com regras

## Regras de otimização (automatizar)

- **8h–20h** — orçamento ajustado por CAC: +20% se CAC < R$17; -10% se CAC > R$20
- **Após 20h** — apenas reduzir (madrugada converte menos)
- Criativo que gastou **R$50 sem conversão** → desativar

## Públicos e criativos

- Incluir públicos quentes na Advantage+ criando público grande com todos os quentes
- **Estáticos com copy forte escalam melhor que vídeos**
- Ferramentas: gama.app, GPT pra imagem e simplificação criativa

## Copy eficaz (restrições de plataforma)

- "Perca 7kg por R$17", "Ganhe R$1.000/mês por R$17" — funcionam
- Instagram **não permite** perda de peso com tempo específico
- Headlines fortes → clickbait sem mentir
- GPT pra otimizar headlines

## Order Bumps

- **3 a 4 order bumps** aumentam ticket médio
- Preços testados: R$17, R$26, R$35
- **Ordem importa** — primeiro é mais vendido
- Conversão: 1º bump >10%, último >5%
- Case: 4.400 unidades "Jejum intermitente — guia completo" em março = R$75k

## Tempo de conversão por nicho

- Pós-graduação R$12k → ~3 meses
- Curso transformação rápida (jejum) → ~30 dias
- Deixar cliente aplicar e ter resultado antes de oferecer próximo produto

## Integração de produtos — análise de tempo

- PROC V no Excel pra calcular diferença entre compras
- IA (GPT, Excel) pra simplificar análise
- Difícil achar tempo médio consistente (varia 15–30 dias)

## Páginas vs Checkouts

- Começar com **checkout rápido** + banners
- Testar A/B páginas (página vs checkout)
- Encontrar página que converta >10% acima do checkout antes de escalar
- Banners do tipo: timer + promessa clara ("perda 30 dias")
- Manter simplicidade — sem complicações desnecessárias

## Upsell

- Eficaz logo após compra de produto baixo
- R$500/R$1k/R$2k precisam de mais tempo
- Jornada do cliente determina velocidade

## Order Bump — boas práticas

- 297 por 17 = oferta forte
- Adicionar IA, planilhas pra aumentar percepção de valor
- Nome do produto deve refletir transformação: "Ganhe 5 mil seguidores/mês", "Perca 7kg em desafio" (não "método" ou "protocolo")
- Especialista E lançador devem assistir o curso completo pra identificar melhorias

## Down-sell win

Aluno teve sucesso ao substituir o principal por um downsell mais desejado.

## Vantagens do low-ticket

- Aquisição de leads gratuitos
- Conhecimento sobre público
- Simplificar processos + automação pra escalar sem aumentar equipe

## Métricas de conversão (todos os produtos rastreados)

- **Low Ticket** → 50% dos compradores entram no evento/TubeXpress
- Dessas, mínimo 5% convertem = **2,5% mínimo de conversão**
- Algumas conversões chegam a 10%
- Exemplo: 1.000 vendas low → 25 vendas principal
- **TubeXpress** — conversão 5–10% (similar ao orgânico em lançamento)

## Desafio de 7 dias (exemplo prático)

- R$29,90 → reduzir pra R$17 (melhor conversão)
- Criativo sugerido: "Perca 7 centímetros de barriga em 7 dias por R$17"
- Não deixar ROAS cair abaixo de 1,2

## Otimização página/checkout

- Foco no banner + order bump no checkout
- Depois melhorar página de vendas
- Documentar alterações pra reverter o que piora

## Criativos imagem × vídeo

- **Imagem escala melhor** (mais barata pra distribuir)
- Meta distribui mais facilmente imagem
- Vídeo exige gravação + análise de retenção
- Vídeo menos eficaz na escala

## Aulas semanais

- 1h/semana, temas variados
- Sugestões via aluno e não-aluno
- Tema revelado no dia, notificação WhatsApp

## Action items (da própria aula)

- Participar das aulas ao vivo
- Considerar player Hotmart se mais de 40 vendas/mês
- Criar aula de dash do Funil 8 (alunos da Estratégia e Mentoria)
- Testar GPT pra Thumbs e criativos
- Revisar copy pra Instagram
- Implementar A/B de páginas
- Configurar Advantage puro + pixel/perfil
- Carrossel como criativo de teste
- A/B de banners no checkout
- Renomear produtos pra refletir transformação
- Ajustar ordem dos order bumps
- Planilhar compras + tempo médio
- Testar upsell e oferta
- Ajustar preços conforme conversão
- Automação + IA pra escalar

## Links

- [[Aula 1 — Funil 8 — Fundamentos]]
- [[Aula 4 — Funil 8 — Otimizando resultados]]
- [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]]
- [[Funil 8 em 1 semana — Implementação rápida]]

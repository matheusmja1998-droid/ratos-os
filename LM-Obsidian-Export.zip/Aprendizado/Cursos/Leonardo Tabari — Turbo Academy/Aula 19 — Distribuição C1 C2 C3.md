---
tipo: aula
autor: Leonardo Tabari
curso: Segredo do ROAS 5X
numero: 19
tema: Método C1, C2, C3 — distribuição de conteúdo estratégico
fonte: PDF resumo oficial Turbo Academy
tags: [c1-c2-c3, conteúdo, funil-consciência, schwartz, reels, carrossel]
---

# Aula 19 — Distribuição C1, C2, C3 (Método Completo)

[[Leonardo Tabari — Índice]]

> Framework de distribuição que guia o público pelo funil de consciência: do desconhecimento à decisão de compra. Transforma investimento em conteúdo em ativo previsível e escalável.

## Base teórica — Níveis de consciência (Schwartz)

1. **Alheio** — não sabe que tem o problema
2. **Consciente do Problema** — sabe do problema, não conhece a solução
3. **Consciente da Solução** — sabe que existem soluções, não conhece o seu produto
4. **Consciente do Produto** — conhece, mas não tem certeza se é a melhor opção
5. **Consciente da Oferta** — pronto pra comprar, só aguarda oferta certa

## Mapeamento C1/C2/C3

- **C1 (Atração)** — Alheio + Consciente do Problema. Boca do funil, atrai em escala.
- **C2 (Qualificação)** — Consciente da Solução. Aprofunda, quebra objeções, apresenta o método.
- **C3 (Conversão)** — Consciente do Produto + Consciente da Oferta. Provas e estudos de caso. Acelera decisão.

## Dores comuns

- Produzir conteúdo sem estratégia ("porque mandaram")
- Atrair muitos seguidores que não engajam nem compram
- Depender de viralização aleatória
- Investir em tráfego pra público frio sem retorno
- "Marketing da esperança"

## Causas

- Falta de diagnóstico do público
- Foco em vaidade (viralização, seguidores) em vez de qualificação
- Comunicação genérica
- Tráfego como muleta de conteúdo fraco

## C1 — CONTEÚDO DE ATRAÇÃO

**Objetivo:** atrair leads qualificados ao menor custo possível.

**Público:** 80–90% do mercado (Alheio + Consciente do Problema)

**Formato:** Reels de 30–90s

**Estrutura (4 partes):**

1. **Gancho (3–5s)** — pergunta forte, afirmação polêmica, visual inesperado. Parte mais importante.
2. **Qualificador (10s)** — filtra o público. "Se você é dentista e sofre com..."
3. **Conteúdo de valor (30–60s)** — dica prática, quebra de mito, nova perspectiva. Gera autoridade.
4. **CTA (10–20s)** — "Toque no meu nome e me siga" ou "Comente X pra receber Y"

**Distribuição:** botão **"Impulsionar"** via navegador (não pelo app iOS — taxas). Testar público "Automático" do Instagram.

## C2 — CONTEÚDO DE QUALIFICAÇÃO

**Objetivo:** transformar frio em morno. Aprofundar conexão, quebrar objeções, demonstrar método.

**Público:** Consciente da Solução (já te seguem após C1)

**Formato:** carrosséis 9–10 cards (com vídeo no último pra criar público de visualização) OU vídeos longos 5–10 min como **Dark Post** (não postados no feed). Carrossel está performando melhor.

**Estrutura:**
- 1º e 2º cards = ganchos fortes (IG pode exibir qualquer um)
- **Storytelling**: Contexto → Conflito/Antagonista → Fundo do poço → Topo da montanha (solução)
- Temas polêmicos / alto interesse do nicho
- **Seed do produto** — mencionar sutilmente o método, sem vender direto

**Distribuição:** Gerenciador de Anúncios → campanhas de engajamento pra públicos mornos:
- Engajou no perfil (30d)
- Visitou perfil (14d)
- Mandou DM (30d)
- Salvou posts (30d)
- 95% dos melhores C1
- Lista de leads / compradores de low-ticket

## C3 — CONTEÚDO DE CONVERSÃO

**Objetivo:** gerar desejo de compra, provar que funciona.

**Público:** Consciente do Produto + Consciente da Oferta (mais quentes, passaram pelo C2)

**Formato:** baseado em provas
- Prints de conversa
- Carrosséis com estudos de caso (antes/depois)
- Áudios de alunos
- Vídeos curtos com depoimentos
- Posts estáticos com legendas detalhando casos

**Estrutura:**
- **Prova visual incontestável** — mostrar, não falar
- **Seed explícito do produto** — "Esse foi o resultado da aluna X com o Módulo 3 do curso Y"
- **Demonstração do método** — passo a passo simplificado

**Distribuição:** públicos mais quentes criados na etapa C2 (quem viu os carrosséis). Não criar públicos novos — ativar decisão nos já qualificados.

## O que fazer

- Ser autêntico — frameworks como guia, não roteiro robótico
- **Gastar mais tempo no gancho** que no resto
- Otimizar por métrica (que C1 trazem seguidores qualificados → impulsionar)
- Consistência — C1 diário, C2/C3 várias vezes/semana
- **Parar tráfego se métrica ruim** — tráfego escala o que é bom, não salva o ruim

## O que NÃO fazer

- Copiar modelo de outro nicho
- Deixar vídeos longos/lives salvas no feed (prejudica métricas)
- Focar só em vender em C1 e C2 (educação primeiro)
- Ignorar qualidade do conteúdo

## Divisão de verba sugerida

- **C1** — 70–80% do orçamento
- **C2** — 15–20%
- **C3** — 5–10%

## Benchmarks de custo por seguidor

- Marketing digital — R$1,50 a R$2
- Odontologia — ~R$1
- Emagrecimento (macro nicho) — R$0,40 a R$0,50

## Exemplo de C1 — Milhas aéreas

- **Gancho (3s):** cartão Black + passagem de primeira classe. "Vou te mostrar o segredo pra viajar de graça pra qualquer lugar."
- **Qualificador (10s):** "Não precisa cartão exclusivo. Se você usa cartão de crédito, pode estar perdendo dinheiro."
- **Conteúdo (40s):** programas de pontos têm parcerias secretas com aéreas → transferir em promoções bonificadas dobra o saldo → R$20 vira R$40
- **CTA (10s):** "Toca no meu nome e me segue"

## Ferramentas

- Gerenciador de Anúncios (C2, C3)
- Botão Impulsionar via navegador (C1)
- IA (ChatGPT) — ganchos, roteiros, estruturas
- App "Edits" (Meta) — finalizar vídeo aumenta alcance orgânico

## Aplicação prática

1. Auditoria de conteúdo — classificar posts em C1/C2/C3
2. Próximo C1 — pensar 5 ganchos diferentes pra mesma ideia
3. Configurar públicos C2 no Gerenciador (engajamento 30d, visitantes 14d)
4. Coletar provas pra C3 ativamente

## Glossário

- **Dark Post** — publicação promovida via Gerenciador, não aparece no feed orgânico
- **Gancho (Hook)** — primeiros 3–5s
- **Seed (Semeadura)** — plantar ideia, mencionar produto sutilmente

## Leituras

- *Breakthrough Advertising* — Eugene Schwartz (níveis de consciência)
- Conteúdos do Pedro Sobral pra aprofundamento em tráfego BR

## Links

- [[Aula 4 — Funil 8 — Otimizando resultados]] (menciona C1/C2/C3 como próximo nível)
- [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]]
- [[Tráfego Aula 5 — Segmentações e públicos]]
- Paralelo no Sobral: [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]] e [[Live 373 — Copywriting para Gestores de Tráfego (Parte II)]]

---
tipo: aula
autor: Leonardo Tabari
curso: Tráfego
numero: 2
tema: Análise de métricas no Gerenciador de Anúncios Meta
fonte: PDF resumo oficial Turbo Academy
tags: [meta-ads, métricas, ctr, cpm, connect-rate, cpv, roas, otimização]
---

# Tráfego Aula 2 — Métricas no Gerenciador Meta

[[Leonardo Tabari — Índice]]

> Métricas primárias (objetivo da campanha) e secundárias (diagnóstico). Otimização guiada pela primária; secundárias explicam o porquê.

## Métricas explicadas

- **Resultado / Custo por Resultado (CPR)** — métrica principal. CPR = Gasto / Resultados. Pra leads é CPL, pra venda é custo por venda.
- **Eventos de Conversão** — ações rastreadas pelo Pixel/API (Lead, Purchase, AddToCart). O "Resultado" da campanha de conversão é a contagem desses eventos.
- **CTR** — (Cliques no link / Impressões) × 100. Termômetro de interesse. Benchmark de partida: 1%.
- **CPM** — custo pra exibir 1.000 vezes. Não é performance direta, é veiculação. Varia muito por nicho. Campanhas de vendas têm CPM maior que reconhecimento.
- **CPC** — Gasto / Cliques. Secundária, apoio.
- **Alcance / Impressões / Frequência** — Frequência = Impressões / Alcance
- **Connect Rate** — métrica personalizada. (Visualizações da página / Cliques no link) × 100. Mede se a página carregou após o clique. Alvo >80%.
- **CPV** — métrica personalizada pra vídeo. Custo por visualização em determinado % (25%, 50%, 75%, 95%, 100%).
- **ROAS** — Receita / Gasto. Geralmente calculado em dashboard externo (Looker, Analytics) mais que no Gerenciador.

## Dores comuns

- CPL/CPR alto
- CTR baixo (criativos não engajam)
- Perda entre clique e página (Connect Rate baixo)
- Dificuldade pra escalar — não saber qual métrica analisar
- CPM elevado sem motivo aparente

## Causas

- **CTR baixo** — criativos desalinhados, mensagem confusa, oferta fraca, fadiga (mesmo criativo muito repetido)
- **Connect Rate baixo** — página lenta (imagens pesadas, scripts, hospedagem ruim). Mobile é >80% do tráfego.
- **CPM alto** — nicho competitivo, público restrito, objetivo de fundo de funil naturalmente mais caro
- **Custo por resultado alto** — consequência de outras etapas

## Boas práticas

- **Foco na métrica primária** — secundárias servem pra diagnosticar
- **Análise de funil** — Impressão → Clique → Visita à página → Conversão. Achar o gargalo.
- **Benchmarking interno** — comparar com seu próprio histórico (CTR ideal varia por nicho)
- **Otimização preventiva da página** — Google PageSpeed Insights >90 (mobile)
- **Criar métricas personalizadas** — Connect Rate e CPV não vêm prontas
- Pra criar CPV 25%: Colunas → Personalizar → Criar métrica personalizada → Gasto / Reproduções de vídeo de 25% → marcar como compartilhada

## O que fazer

- Definir métrica primária antes de criar campanha
- Salvar conjunto de colunas personalizado "Análise Padrão"
- Analisar CTR pra avaliar criativo e segmentação
- Connect Rate >80%
- PageSpeed Insights antes de lançar campanha (mobile entre 90 e 100)
- Habilitar compartilhamento de métricas personalizadas pra equipe
- CPV pra retenção de vídeo (campanhas C2)

## O que NÃO fazer

- Pausar anúncio só por CPC ou CPM alto se o custo por resultado final estiver na meta
- Ignorar Connect Rate baixo (pagar por cliques que não chegam)
- Tratar benchmarks de mercado como regra absoluta
- Analisar sem segmentar por dispositivo (mobile ≠ desktop)
- Confiar que CPC baixo trará melhor resultado (público mais caro pode converter mais)

## Exemplos

- **CPL** — R$1.179 / 31 leads = R$38,06/lead
- **Frequência** — 8.000 impressões / 4.000 alcance = 2

## Ferramentas

- Meta Ads Manager
- Google PageSpeed Insights
- Google Analytics + Looker Studio (ROAS e jornada completa)

## Rotinas

- **Inicial** — criar métricas personalizadas + preset de colunas
- **Diária/Semanal** — primárias e secundárias pra tendências
- **Pré-lançamento** — PageSpeed Insights antes de ativar

## Próximos passos

- Aprofundar Pixel + CAPI → [[Tráfego Aula 4 — Pixel e eventos]]

## Links

- [[Tráfego Aula 1 — Introdução e métricas]]
- [[Tráfego Aula 5 — Segmentações e públicos]]
- [[Aula 4 — Funil 8 — Otimizando resultados]]

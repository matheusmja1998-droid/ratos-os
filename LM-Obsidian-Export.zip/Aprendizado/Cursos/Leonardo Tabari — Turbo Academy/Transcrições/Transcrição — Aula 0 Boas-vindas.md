[00:00] Você tomou a decisão certa, é isso mesmo.
[00:02] Você entrou para o funil oito.
[00:05] De verdade, não tem jeito melhor de você pegar leads a custo zero,
[00:09] escalar o seu negócio e o seu faturamento.
[00:12] Mas antes de tudo, eu queria fazer alguns combinados com você.
[00:16] O primeiro combinado, eu quero te dar esse curso de forma vitalícia.
[00:20] Isso mesmo. Você vai ter acesso a ele para sempre.
[00:22] Inclusive as atualizações.
[00:24] Por quê? A gente sabe que a internet é
[00:27] idade de cachorro, né? Um ano equivalente a sete
[00:31] no mundo real. Então que as coisas são aceleradas.
[00:33] Esse curso vai ser sempre regravado.
[00:36] Teve mudança, ele vai ser regravado.
[00:38] E para você ter acesso a essas mudanças,
[00:41] você vai ter que cumprir alguns combinados.
[00:42] O primeiro combinado, para você ter acesso a vitalício,
[00:45] você precisa seguir no Instagram.
[00:47] É isso mesmo. Eu vou deixar o link aqui abaixo desse vídeo.
[00:50] Você entra no link e começa a me seguir.
[00:53] A gente vai fazer checais.
[00:54] A gente tem uma automação que checa isso de tempos em tempos.
[00:57] E olha se a pessoa está seguindo ou não.
[00:59] Então quando você estiver me seguindo, você tem acesso vitalício.
[01:03] Segundo combinado, eu preciso que você preenche a ficha de matrícula,
[01:06] que também o link está logo aqui embaixo dessa aula.
[01:09] Por quê? Porque nessa ficha de matrícula tem o seu nome,
[01:12] telefone e e o seu Instagram.
[01:14] É isso mesmo. Se eu não sei qual o seu Instagram,
[01:16] como é que eu vou checar?
[01:18] Então eu preciso que você coloque o seu arroba lá
[01:20] para eu saber que você está me seguindo.
[01:22] Então preenche essa ficha de matrícula também.
[01:24] E algumas informações para saber se eu estou no caminho certo
[01:27] para te direcionar cada vez mais.
[01:30] Terceiro combinado, toda terça-feira às 17 e 18
[01:33] eu dou uma aula no Zoom onde eu dou conteúdos como desse curso aqui
[01:37] e até muito melhores que esse.
[01:39] Mas para você receber o link, você tem que estar dentro
[01:41] de um grupo que eu vou deixar o link aqui embaixo também.
[01:43] Chama Segredos do Roa 5x.
[01:46] Se quiser ter acesso a esse conteúdo,
[01:48] fica dentro desse grupo que toda semana eu mando link para você participar
[01:51] e não fica gravado.
[01:53] Quarto e último combinado.
[01:54] Esse é o mais importante de todos.
[01:57] Se você completar esse curso em sete dias,
[02:00] ou seja, assistir todas as aulas é um pouco curtinho.
[02:02] Tem ali um pouco mais de duas horas.
[02:04] Se você assistir todo, todo em sete dias,
[02:07] eu vou liberar de graça para você o meu curso do Tube Express.
[02:11] Que vai te colocar pelo menos 20 mil limpinho no seu bolso
[02:14] todos os meses.
[02:16] Então você assistir ele em sete dias, você vai ter acesso.
[02:19] Ah, Léo, terminei de assistir no oitavo dia.
[02:21] Infelizmente não, isso é automação que vai liberar.
[02:24] Então ele checa sete dias.
[02:26] Se você assistir todas as aulas, tem que dar uma checa em todas as aulas
[02:29] de assistir, você vai ter o Tube Express.
[02:32] Ah, Léo, já comprei o Tube Express.
[02:35] Tudo bem, você entra em contato com a Naceke
[02:37] porque a gente vai te dar outro curso.
[02:39] A gente tem curso de métricas de C1, a gente tem curso de oferta.
[02:42] Tem uns outros cursos também que você pode ter acesso.
[02:45] Então é só entrar em contato com a equipe
[02:47] que você vai ter acesso.
[02:48] Então, no outro caso, já tem o Tube Express.
[02:52] E, Léo, se eu quiser comprar um desses outros cursos também,
[02:55] o que que eu faço?
[02:56] Aí eu vou deixar o nosso contato aqui da equipe aqui embaixo.
[02:59] É só você entrar em contato, você ter a lista, saber o que a gente
[03:02] vem de quais são os nossos outros cursos,
[03:04] como é que você faz para andar na nossa esteira.
[03:07] Mas, de verdade, aproveita muito bem esse curso aqui.
[03:10] Começa a colocar em ação rápida, rápida,
[03:13] porque, cara, vai te dar muito resultado.
[03:16] É resultado garantido.
[03:17] De verdade, se você aplicar tudo isso aqui e não tiver resultado,
[03:21] me manda um direct que eu devolvo seu dinheiro.
[03:23] Não, não precisa preocupar.
[03:24] Eu devolvo seu dinheiro.
[03:26] Ah, já passou 7 dias da ROTMART, não importa.
[03:29] Eu devolvo seu dinheiro.
[03:30] De verdade, porque isso aqui não tem cômodo errado.
[03:33] É só você fazer tudo que eu vou dar nas próximas aulas.
[03:36] Combinado?
[03:37] Então já te vejo na aula 1.

[00:00] Começando a nossa segunda aula.
[00:01] E agora eu vou falar de estrutura e criação do produto.
[00:05] Isso é fundamental na hora de você executar o fone 8.
[00:09] Primeira coisa é estrutura.
[00:10] Como que vai funcionar?
[00:12] Ela é simples.
[00:13] Ela é fácil.
[00:14] Ela é prática.
[00:16] Você vai ter um produto que você vai iniciar e é R$ 17.
[00:19] Você vai ter três ordem bumps com preços em escadinha.
[00:23] Pode ser R$ 62, R$ 35, R$ 17 ou R$ 35, R$ 26, R$ 17.
[00:29] Não importa, mas tem que ser uma escadinha do que vende mais para o que vende menos.
[00:33] Sempre três.
[00:34] E pode ter ainda um opcél de até R$ 98, até pode ser menor que R$ 98.
[00:40] Um opcél é algo que a pessoa possa comprar na hora sem pensar duas vezes.
[00:45] Pode ser uma ferramenta, pode ser um conjunto de planilhas, pode ser um contrato, pode
[00:50] ser um modelo de alguma coisa, um superfile, pode ser uma aula ao vivo para tirar dúvidas.
[00:56] Cara, você pode fazer o que você quiser.
[00:58] E eu, por exemplo, gosto de vender um lançamento pago.
[01:01] Por que não?
[01:02] Vender um ticket de lançamento pago no opcél com um desconto especial para a pessoa.
[01:07] Só cuidado que na hora do opcél, se a pessoa paga no PIX, ele não aparece diretamente
[01:12] no AMBI click.
[01:13] Então, você precisa mandar um WhatsApp para ela fazer o AMBI click no opcél dentro
[01:18] do WhatsApp.
[01:19] Só cuidado com isso.
[01:20] Mas isso aí tem certeza que você já sabe fazer.
[01:23] Para essa estrutura, você vai precisar de quatro produtos.
[01:26] Um produto principal de R$17, que eu vou te ensinar como fazer agora.
[01:30] E três order bumps.
[01:32] Pode ser books, pode ser outros cursos que você tem, pode ser o que você quiser.
[01:36] Mas ele tem que ter valores baixos para a pessoa olhar e falar, cara, eu preciso muito
[01:39] disso.
[01:40] Bom, clica e compra junto.
[01:42] Ter até um caso da minha gerente da Hotmart.
[01:45] É isso mesmo.
[01:46] A minha gerente da Hotmart estava olhando nossos produtos e ela entrou no produto
[01:50] do minha especialista que ensina emagrecimento.
[01:53] Ela gostou tanto de comprar o produto de jejum.
[01:56] Na hora que ela, antes de comprar o produto de jejum, ela entrou para ver.
[02:02] Antes de clicar no comprar, ela estava olhando, ela foi nos order bumps e olhou, nossa, mas
[02:06] eu preciso disso.
[02:07] Pá, mas eu preciso disso também.
[02:09] Pá, ela precisa disso também.
[02:10] Pá, comprou os três order bumps e bom, foi pop-cell, para lançamento opado.
[02:16] Comprou também.
[02:17] Então ela comprou toda a nossa esteira e a gente em reunião ela falou assim,
[02:21] nossa, Léo, eu caí na minha própria armadilha, eu falo para vocês fazerem e eu fui lá,
[02:26] fui olhando quando eu percebeu, já tinha comprado tudo.
[02:28] E aí o Tic-Timed vai para onde?
[02:30] Pum, lá para cima, muito mais dinheiro no seu bolso.
[02:33] Estrutura é básica, é simples é isso.
[02:36] Léo, posso ter mais de um Funio 8 rodando?
[02:38] Pode, mas eu não recomendo no início.
[02:40] Enquanto você não dominar, os seis primeiros meses foquei um Funio 8.
[02:44] É um produto, três order bumps e um op-cell se você tiver.
[02:49] Se você não tiver o op-cell, tudo bem, você não precisa deixar.
[02:51] Mas os três order bumps você vai ter que criar, pensar, formar eles.
[02:55] E agora a parte da criação do produto.
[02:59] Você tem que criar um produto que realmente funciona e entrega aquilo que você está prometendo.
[03:04] Primeira coisa, o nome do produto tem que ser a transformação.
[03:08] Ele não pode ter que subir em nível de consciência.
[03:11] Nada de método 3Ps, protocolo XY14, nada disso.
[03:18] A pessoa não precisa pensar para descobrir o que está vendendo.
[03:21] Tem que ser como perder 5kg em 7 dias.
[03:26] Como ganhar 20 mil reais por mês limpinho na sua conta.
[03:31] Como aprender gestão ágil em apenas 3 dias.
[03:35] Como economizar 5 horas de trabalho por dia com apenas uma mudança na sua rotina.
[03:41] Viu?
[03:42] Vocês são vários títulos.
[03:43] Lembra que todos começam com como?
[03:44] O nome desse curso, por exemplo, é como aplicar o Funio 8.
[03:48] Eu poderia ter simplificado ele mais.
[03:49] Queria como executar um outict de sucesso.
[03:52] Poderia ter colocado isso.
[03:53] Só que o meu público, eu já quero subir o nível de consciência para o Funio 8.
[03:57] Então coloquei como aplicar o Funio 8.
[04:01] Deixei direto ao ponto.
[04:03] Meu público, eu quero que ele já tenha um nível de consciência mais alto.
[04:05] Eu quero que ele já filta.
[04:06] Você não quer o que você faça isso.
[04:08] Eu quero que você faça direto ao ponto.
[04:10] Então começa com o nome.
[04:11] Beleza?
[04:12] Vai começar com o nome do produto como, como diz o Pablo Marçal, tarara, tarara,
[04:17] a promessa direta.
[04:18] Segundo, não pode ser book.
[04:20] Não pode ser um pedaço do seu curso que você arrancou e colocou.
[04:24] Não pode ser os seus CPLs que você colocou.
[04:27] Leo, preciso colocar rápido no A.
[04:29] Beleza, pego CPLs, coloco enquanto isso, sento e gravo.
[04:33] De verdade, você vai gastar umas três horas para gravar esse curso.
[04:35] Não mais que isso.
[04:36] Eu não sei que tem uma coisa muito manual, tipo numa confeitaria, que você tem que
[04:40] criar alguma coisa.
[04:41] Fora isso, três horas você grava um curso aí, completinho, para te atender.
[04:45] E eu vou te dar o passo a passo.
[04:47] Estou te dando o passo a passo.
[04:49] Então define o nome, o seu nome tem que estar ligado à promessa.
[04:52] Aí a gente vai para as aulas.
[04:53] E o que tem que ser, como tem que ser essas aulas?
[04:56] Ela tem que ser no estilo lançamento gratidão.
[04:58] Você já fez um lançamento gratidão?
[05:00] Você sabe o que é isso?
[05:01] Lançamento gratidão é aquele lançamento que você entrega muito.
[05:06] As pessoas adoram, elogiam, vão umas aulas, comentam, compartilham.
[05:11] No final, você abre carinho, vende nada, porque você entregou muito.
[05:15] Esse é o objetivo.
[05:16] Ah, mas eu não quero que ele compre uma misteira.
[05:18] Sim, mas ele vai comprar por reciprocidade.
[05:21] Você vendeu esse produto para ele.
[05:23] Ele ficou tão satisfeito que ele vai andar na sua esteira.
[05:26] Esse produto tem que mostrar oportunidade de forma clara.
[05:30] Ele tem que mostrar o caminho.
[05:31] Ele tem que tirar a pessoa da zona de conforto e fazer ela se mover.
[05:35] Não pode ser nada muito complexo.
[05:36] Tem que ser simples, que ela tem que assistir, olhar, pensar,
[05:40] falar, cara, eu dou conta de fazer isso.
[05:42] E ela vai e faz.
[05:43] Ele tem que gerar muito desejo.
[05:45] Tem que gerar desejo mesmo da pessoa querer executar aquilo ali
[05:49] e dar o próximo passo.
[05:50] E durante o produto, a pessoa já tem que ter uma vitória.
[05:54] Ela já tem que conseguir fazer algo enquanto ela está assistindo ao produto.
[05:57] Cara, isso aqui é muito fácil de fazer.
[05:58] Peraí, papapá, executou.
[06:00] Ou então pensou ali executar.
[06:02] Ou então já criou um plano para executar.
[06:04] Ou então já sentiu que aprendeu que ela está satisfeita.
[06:06] Mas ela tem que ter uma vitória.
[06:08] Ela tem que se sentir vitoriosa só de assistir às aulas.
[06:11] E, logicamente, você tem que mostrar de forma clara
[06:14] o próximo passo.
[06:16] Fazer cidi para o seu produto principal.
[06:18] Fazer cidi da sua esteira.
[06:20] Mostrar que você pode continuar que ele, seu cliente,
[06:23] ele pode continuar comprando outros produtos de você
[06:26] para continuar evoluindo.
[06:28] Que não precisa comprar do seu concorrente.
[06:31] Porque se você não tiver mais nada, ele vai comprar do seu concorrente.
[06:33] Ele quer continuar evoluindo.
[06:35] Uma coisa que sempre me questiona, né?
[06:37] Leão, mas não é ruim entregar demais no produto tão barato de R$17.
[06:41] Não vai desvalorizar o expert.
[06:43] Cara, era uma dúvida que minha ex-pest tinha.
[06:46] Mas quando ela viu o resultado, cara,
[06:48] que pelo contrário, as pessoas ficavam tão felizes
[06:52] em perder-lhes 5 quilos em apenas uma semana
[06:54] que ela vendia muito mais o produto principal
[06:57] e lojiava-o muito mais, divulgava-o muito mais,
[07:00] compartilhava-o muito mais.
[07:02] Então, é tanta reciprocidade que a pessoa fica grata.
[07:06] Ela já vai ter uma vitória.
[07:08] E ela pagou por isso.
[07:09] Ou você acha que o que você está entregando de graça
[07:12] nos seus conteúdos, no seu YouTube, no seu Instagram,
[07:14] não já não é demais.
[07:16] É demais.
[07:17] Só que a pessoa não fica vendo tudo.
[07:19] Quando você entrega organizada em forma de curso,
[07:21] ela fica muito feliz e grata a você.
[07:23] Ela só tem que assistir.
[07:25] Esse é outro trabalho que a gente vai organizar logo à frente.
[07:29] Da primeira hora, a gente vai criar seu curso.
[07:31] Falando das aulas agora, são sete aulas, né?
[07:33] Mais aula zero.
[07:35] Você viu como eu gravei esse curso.
[07:37] Aula zero está lá, você pode copiar a minha, fazer igualzinho.
[07:39] E as outras aulas, elas têm uma sequência lógica.
[07:42] Assim como o lançamento tem uma sequência,
[07:45] os gatilhos têm uma sequência, copem têm uma sequência,
[07:48] essas aulas também têm uma sequência lógica.
[07:51] Essas aulas, elas não podem ser muito longas.
[07:53] Ali, 10, 20 minutos no máximo.
[07:55] Pode ser um pouquinho a menos de 10,
[07:57] ficar ali 8, 7 minutos, mas não faça curta demais.
[08:01] De 10 a 20 minutos é um tempo legal de aula.
[08:04] E essas aulas são divididas em sete partes de copi.
[08:08] Essa você vai ter que trabalhar um pouquinho.
[08:11] Primeira parte, de primeira aula, aula um, tá?
[08:14] Aula zero é aquela que você já viu,
[08:17] aquela que você faz os combinados, o que a pessoa vai ganhar,
[08:20] pedir ela para entrar no seu Instagram,
[08:23] preencher a fecha de matrícula,
[08:25] assistir todo o seu curso.
[08:28] Então você tem esses combinados com a pessoa ali
[08:31] que você quiser combinar com ela,
[08:32] você combina na aula zero.
[08:34] Parte da aula um é conteúdo.
[08:35] Na aula um, você tem que focar em duas coisas, tá?
[08:39] Primeira coisa, entregar todos os fundamentos lógicos do seu método.
[08:45] A pessoa tem que sair da aula um, entender,
[08:47] cara, entender a lógica disso aqui.
[08:49] Agora, como que eu aplico?
[08:51] Essa é a ideia da aula um.
[08:53] Segundo, eu quero que você coloque mentalidade antifragio.
[08:57] Estude um pouquinho no YouTube o que que é isso
[08:59] e você coloca na cabeça.
[09:01] Você, eu mandei você ir lá estudar sozinho.
[09:04] Na minha aula um, mandei.
[09:05] Eu não fiquei te dando aula da mentalidade antifragio,
[09:07] mas para o seu aluno é importante.
[09:09] Principalmente quando você tem um público mais carente
[09:13] ou marrendo um pouco mais baixa,
[09:14] aí você tem que trabalhar ainda mais com sua mentalidade antifragio.
[09:18] Por quê? Porque se uma pessoa vai desistir,
[09:21] ela vai começar e não vai terminar.
[09:23] Ela vai se sentir derrotada o tempo todo.
[09:25] Então, a aula um, você vai dividir duas partes.
[09:28] Fundamentos,
[09:29] fundamento, primeira parte,
[09:31] mentalidade, antifragio, segunda parte.
[09:33] Todos os fundamentos, o passo a passo,
[09:36] criam um mapa mental com todos os fundamentos do seu negócio
[09:40] e do seu método, toda a lógica dele.
[09:42] Para você não esquecer nada.
[09:44] E entrega isso.
[09:45] Combinado? Então essa é a aula um.
[09:47] Teve a aula zero, a aula um.
[09:49] E na aula dois, como que eu vou para a aula dois?
[09:51] A aula dois você vai começar a ensinar a pessoa a colocar a mão na massa.
[09:56] Você vai ensinar ela a dar os primeiros passos ali.
[10:00] Você vai ensinar ela a executar algo.
[10:02] Como nessa aula dois aqui?
[10:04] Nessa aula dois, o que eu estou ensinando?
[10:06] Estou ensinando a criar um produto.
[10:08] Você tem que dar algo para ela que ela consiga fazer e já se sinta aliviada.
[10:13] Então ela já tem que ter noção que ela consegue.
[10:16] A aula dois é isso.
[10:17] Você pode colocar um pouquinho de mentalidade,
[10:19] mas de forma bem mais leve também, tá?
[10:22] Entrar em um pouquinho de mentalidade não vai fazer mal nenhum
[10:26] em todas as aulas.
[10:27] Mas aqui bem mais leve.
[10:28] Aqui o objetivo é o mão na massa mesmo e executar um passo a passo.
[10:32] Aula três, primeiro marco.
[10:35] Você aprofunda ainda mais no método.
[10:37] Você pode aprofundar, entregar mais conteúdo no método,
[10:41] mas você tem que deixar claro o primeiro marco.
[10:43] Por exemplo, você vai ver na aula três que eu vou falar bem,
[10:46] agora você já sabe criar seu curso.
[10:49] Você já criou seu curso?
[10:50] Vai lá e crie agora.
[10:51] Eu vou cobrar isso de você.
[10:53] Lá no curso de emagrecimento, por exemplo, que a gente vende,
[10:57] a gente fala que na aula três ela já tem que ter perdido um quilo e meio.
[11:00] Então tem gente que perdeu um quilo, tem gente que perdeu dois,
[11:03] tem gente que perdeu dois e meio,
[11:04] então a galera perde variada ali.
[11:06] Mas a gente coloca aqui o primeiro marco, se ela fez tudo certinho,
[11:09] era para ter chegado próximo de um quilo e meio.
[11:11] Então eu dou um marco.
[11:12] Na nossa aula três você vai ter que saber como criar seu curso.
[11:16] Ele todo estruturado, seu curso de 17 reais.
[11:19] Então crie o marco e fala-se,
[11:21] nessa aula você tem que dar conta de fazer isso.
[11:25] Isso é a aula três, tá?
[11:26] Mentalidade leve novamente,
[11:29] mas o marco, a primeira vitória ali, é o mais importante na aula três.
[11:33] E aí vamos para a aula quatro.
[11:35] Eu não vou dar muitos spoilers, tá?
[11:37] Que lá na aula quatro você vai entender um pouquinho mais.
[11:39] Mas a aula quatro é a aula de superar obstáculos.
[11:43] O que é que...
[11:45] Por que eu tenho que dar uma aula de superar obstáculos?
[11:47] Porque vai ter dificuldades, vão ter problemas,
[11:49] vão ter coisas que vão acontecer durante a jornada
[11:53] que a pessoa vai dar vontade de desistir
[11:56] e você tem que mostrar como superar esses obstáculos,
[11:59] como transparçar esses obstáculos.
[12:02] Ou seja, é uma aula de quebra de objeção.
[12:05] A pessoa tem uma objeção, que é um obstáculo,
[12:07] você insinda a superar aquele obstáculo quebrando a objeção.
[12:12] Então é uma aula de quebra de objeção, se você quiser,
[12:15] falar na linguagem do marco digital.
[12:17] Mas é uma aula de obstáculos e como superá-los, beleza?
[12:20] E aí nessa aula quatro você,
[12:23] intencionalmente, vai fazer seed para o seu produto principal,
[12:27] você vai fazer um prepit para o seu produto principal,
[12:31] você vai deixar as pessoas com desejo
[12:33] de comprar o seu produto principal
[12:36] quando chegar ao final do curso, quando ela já tiver um resultado
[12:40] com o curso que você está vendendo para ela.
[12:42] Então você tem que mostrar que existe algo a mais.
[12:44] Então tem que ficar isso muito bem claro.
[12:47] Isso aí na aula quatro.
[12:49] E na aula cinco, o que você vai fazer?
[12:51] Segundo o marco.
[12:52] Você tem que mostrar que naquele momento, depois de tanto tempo,
[12:55] a pessoa já tem que ter tido x de resultado.
[12:58] Você pode aprofundar ainda mais no método,
[13:01] mostrar mais detalhes, mais por dentro,
[13:04] mostrar otimizações,
[13:06] mostrar melhorias, correção de problemas.
[13:10] Você é aprofundar ainda mais,
[13:12] mas tem que ter uma segunda vitória.
[13:14] Você vai ver lá quando... Eu não vou dar spoiler também,
[13:16] mas na aula cinco você vai ver a vitória
[13:18] que eu vou falar que você já vai ter.
[13:20] Na aula três você tem uma, na aula cinco você tem outra vitória
[13:23] para a pessoa sentir o quê?
[13:25] Que ela está subindo uma escadinha.
[13:28] Então a aula cinco é uma aula de quase que comemoração
[13:32] e fechamento de sículo ali.
[13:34] Aqui você vai ter o seu resultado.
[13:36] É isso aqui que você pode esperar.
[13:38] Corrigindo todos os pontos, todas as otimizações.
[13:42] E a aula seis? Vamos para a aula seis.
[13:45] A aula seis é uma aula introdutória ao seu método.
[13:49] Então ela já vai um pouquinho para o produto principal.
[13:53] Você dá um overdelivery ali,
[13:54] você entrega mais do que a pessoa estava esperando.
[13:57] Você entrega muito mais.
[13:59] E aí a pessoa já sente o quê?
[14:01] Que ela está dentro do seu curso.
[14:03] Ela fica com o desejo de ter o curso principal.
[14:05] Você já cria isso na aula seis, sem vender nada.
[14:09] E na aula set, que é a nossa última aula,
[14:11] você vai para onde?
[14:12] Para aqui. O próximo nível é um caminho natural.
[14:17] O que que é isso, Leo? De caminho natural.
[14:19] Você vai mostrar o seu produto
[14:21] como uma jornada natural para ela.
[14:24] Que com aqueles resultados que o produto de low tick,
[14:27] o produto do fone oito gerou,
[14:29] ela precisa continuar andando na jornada
[14:32] e comprar o próximo produto.
[14:34] Ela precisa continuar evoluindo.
[14:37] Então tem que ser uma coisa natural.
[14:38] Ou seja, é um pite de vendas sem vender.
[14:41] É o Venda Sem Vender.
[14:43] Ali você vai mostrar todo,
[14:46] todo sua esteira para ela,
[14:47] todo seu produto principal para ela.
[14:50] E deixar um contato do comercial.
[14:52] Deixar um contato do link de WhatsApp
[14:55] para entrar em contato.
[14:56] Deixar em contato do grupo de lista de espera.
[14:58] Aí você aceita com a sua estratégia.
[15:01] Mas você manda ela para algum lugar.
[15:03] Combinado?
[15:04] Então você está pronto para criar seu produto.
[15:07] Te dei aqui o passo a passo das sete aulas.
[15:10] Eu vou deixar aqui embaixo desse vídeo também.
[15:12] O mapa mental, contudo isso.
[15:14] Um PDF também explicando passo a passo sobre essas aulas.
[15:18] Tudo explicadinho e machigadinho.
[15:20] Por quê? Porque você vai escutar, mas vai esquecer.
[15:24] Você veio anotando.
[15:25] Lembra que eu te pedi para anotar?
[15:26] Então seu cérebro já gravou algumas coisas.
[15:28] Mas eu vou te dar um PDF.
[15:30] Por que vai que você pulou alguma coisa?
[15:32] Tem alguma coisa fora do radar.
[15:34] Então, de baixo da aula,
[15:35] estou deixando um PDF aqui também para facilitar
[15:38] sua vida na hora de criar as aulas.
[15:40] Combinado?
[15:40] Então, te vejo na aula 3.

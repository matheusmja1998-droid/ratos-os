[00:00] começando nossa terceira aula e agora eu vou te mostrar na prática como fazer o tráfego,
[00:05] isso mesmo, a estrutura de tráfego.
[00:07] Lógico, que antes eu tenho que te passar os conceitos.
[00:10] Leu, eu não sou gestor de tráfego, não entendo nada, não importa.
[00:14] É bem simples, a gente usa a campanha do tipo ASC.
[00:17] Vocês podem entender um pouquinho mais o que é isso.
[00:19] Então não tem tanto trabalho assim.
[00:21] Leu, tem um gestor de tráfego, então coloca ele para assistir o curso inteiro,
[00:25] não só essa aula.
[00:26] Porque se ele não entender a estrutura, ele vai se perder na hora de fazer campanhas.
[00:31] Por quê?
[00:32] Porque é diferente do que a galera está acostumado a fazer.
[00:34] Isso aqui é a metodologia nossa.
[00:36] Nós criamos essa forma de fazer campanha que é fácil e vai te gerar muito resultado.
[00:42] Como que funciona esse estrutura?
[00:44] Antes de a gente ir para o gerenciador, eu queria te falar que a gente vai fazer uma
[00:46] campanha focada em público frio.
[00:48] O objetivo é isso mesmo, vender 70, 80% para público frio.
[00:52] Mas a gente usa a campanha Advância demais, que é a campanha ASC.
[00:56] Que ASC é a sigla de Advantas demais Shopping Campanhas, desculpa meu inglês, mas ela vem
[01:02] de daí.
[01:03] Hoje, como todo mundo está usando o navegador em português, então não vai ter problema.
[01:08] A campanha de vendas Advantas demais, ela é simples e fácil de usar.
[01:12] Essa campanha você não define conjunto de anúncios.
[01:15] Então ela busca automaticamente seu público quente, seu público frio.
[01:19] A gente trabalha com um público mais aberto.
[01:21] Você pode direcionar, você pode colocar um público, você pode fazer um monte de coisa
[01:26] dentro dessa campanha.
[01:27] Você tem essa liberdade.
[01:29] Só que eu sugiro, no início, deixa tudo padrãozinho.
[01:32] Deixa a campanha gerar inteligência.
[01:34] Essa é uma campanha que ela usa inteligência artificial da meta e ela está cada vez melhor.
[01:39] No início, ela fica um pouco perdida, mas aí ela vai ficando inteligente, inteligente,
[01:43] inteligente.
[01:44] Ela pega uma inteligência crescente, que quanto mais você gasta, melhor ela
[01:48] fica.
[01:49] Então eu acho que eu não vou queimar dinheiro só para ela ficar inteligente, porque senão
[01:52] ela vai entender que você está disposto a queimar muito dinheiro.
[01:55] Se você segura a verbazinha ali, o tempo todo, mantendo as coisas dentro da ordem, ela fica
[02:01] inteligente demais.
[02:02] Então agora, vamos para o geriçador de anúncios colocar a mão na massa.
[02:06] Você vê que não precisa ser nenhum gênio para poder fazer isso.
[02:10] Lógico, eu vou deixar uma aula também do meu gestor de tráfico.
[02:13] No final, com as partes mais complexas, chatas, configuração de pixel, metrificação, algumas
[02:20] coisas bem detalísticas, você não precisa preocupar agora.
[02:23] Vai ser aula bônus, vai ser extra e vai entrar só no final do curso.
[02:27] Mas aí você ia, é uma coisa mais para o seu gestor de tráfico para você.
[02:30] Ponhando agora para o navegador.
[02:32] A navegador não, geriçador de anúncios.
[02:35] Desculpa gente, vamos lá.
[02:36] O que você vai fazer?
[02:38] Tô com o geriçador aberto.
[02:39] Isso aqui é uma conta teste que eu tenho, tá?
[02:43] Você clica em criar.
[02:45] Depois você vai lá embaixo em vendas.
[02:49] Clica em continuar.
[02:51] Esse anúncio aqui é só para avisar.
[02:56] O novo nome é campanha de vendas adivantes demais.
[03:00] As opções manuais ainda estão disponíveis, mas você não vai usar.
[03:05] Lembra disso, você não vai usar, você vai usar só de vendas.
[03:09] Beleza?
[03:10] Você sempre vai aparecer.
[03:12] Você quiser saber mais que liga aqui, ó, que ele vai te ensinar tudo.
[03:15] Foi por aqui que eu aprendi.
[03:17] Dá OK, tá aqui.
[03:19] Nova campanha de vendas.
[03:21] Vamos colocar o nome, tipo teste a SC01.
[03:28] Colocando o nome qualquer, beleza?
[03:31] Tipo leilão, vendas, não mexe em católogo.
[03:34] Osamento a nível de campanha.
[03:36] Osamento diário, começa com 100 reais.
[03:39] Leal, 100 é muito caras, senão ela não vai performar.
[03:41] O mínimo 100, se você tiver dinheiro sobrando, coloca 500.
[03:46] Não mexe em teste a B, relatório, não faz mais nada, nada, nada, nada.
[03:50] Nada de categoria especial, nada.
[03:52] Você só vai avançar.
[03:54] Conjunto de anúncios, não cria conjunto de anúncio, deixa ele diretamente.
[03:59] Local da conversão, site.
[04:01] Ah Leão, mas eu vendo por aplicativo mesmo assim, coloca site.
[04:05] Cara, isso aqui, tudo que você vai mexendo aqui vai piorando o resultado.
[04:09] Então deixa site.
[04:11] Maximizar número de conversões.
[04:13] Aqui a inteligência vai ser o quê?
[04:15] Cada vez mais vender.
[04:17] Se você muda aqui, coloca, maximizar o número de visualizações de página,
[04:21] ele vai trazer um público muito ruim.
[04:23] Então sempre deixa sempre conversão.
[04:25] Não tem pixel, então aqui você tem que criar um pixel.
[04:28] Eu ainda não tenho pixel, tá?
[04:30] Então vou criar um pixel aqui.
[04:33] Pixel teste.
[04:36] É onde ele vai guardar a inteligência.
[04:38] Se você já tiver, usa o que você tem da sua conta.
[04:43] Criei o pixel.
[04:44] Preciso do site.
[04:48] Eu preciso ter um domínio.
[04:50] Vamos colocar o turbo akdm aqui, www.turboacademy.com.br, que é o seu domínio.
[05:00] Pronto.
[05:02] Escrever código agora, retomar a criação do anúncio.
[05:05] Eu não quero o código do pixel agora para colocar na página, tá?
[05:08] Isso aí eu vou deixar na aula bônus lá com a minha equipe fazendo
[05:11] que eles vão saber mais detalhes.
[05:13] E daqui vão retomar o anúncio.
[05:15] Se você já tem pixel, é só colocar o pixel ali, beleza?
[05:18] Conjunto de dados, pixel teste, você vai escolher o seu pixel aqui.
[05:22] Pode ser qualquer um, tá?
[05:24] Evento de conversão.
[05:26] Qual que você vai selecionar?
[05:28] Comprar.
[05:29] Comprar.
[05:30] Esse é o evento de conversão.
[05:32] Leoposto personalizar?
[05:34] Posso fazer um personalizado?
[05:36] Tem vários aqui que você pode fazer, você pode personalizar.
[05:39] Isso aí você deixa pro gestor de tráfico.
[05:41] Se você não sabe, coloca comprar.
[05:44] Meta de custo por resultado.
[05:46] Isso aqui ele é legal quando você tem um orçamento mais definido, mas não coloca.
[05:52] Sabe por quê? Porque senão que ele vai limitar muita capacidade no início.
[05:56] E no início às vezes ele fica um pouquinho mais caro,
[05:58] mas é importante ele ficar mais caro para pegar inteligência.
[06:01] Vamos lá.
[06:04] Limite de gasto?
[06:05] Não coloca, não coloca nada disso aqui.
[06:07] Estratégia de orçamento já está a nível de campanha.
[06:09] Data de início.
[06:11] Sempre coloca para o outro dia.
[06:14] Vamos por aqui, às 5 da manhã.
[06:18] Não coloca na hora.
[06:20] Coloca sempre 5 da manhã.
[06:22] Dérvido, não coloca.
[06:24] Nunca termina, ela só começa.
[06:26] Público, você pode usar um público salvo para começar
[06:29] tipo sua base de alunos,
[06:31] desde que você tenha no mínimo 10 mil pessoas.
[06:34] Se você tiver menos de 10 mil, não usa.
[06:37] Ah Le, posso usar o público de captura?
[06:40] Não.
[06:41] Público de inicio ao checkout?
[06:43] Não, não é um público bom.
[06:45] Usa público de aluno.
[06:46] Se você tiver aluno, coloca aqui público de aluno,
[06:48] no mínimo 10 mil, senão deixa em branco.
[06:51] Sugiram público?
[06:53] Sugestão opcial?
[06:54] Não, sem nada.
[06:56] Ah Le, mas meu público aqui,
[06:58] mulher, 40 mais, beleza.
[07:00] Aí você pode colocar lá.
[07:02] Por exemplo, aqui em trabalho aclima de crescimento feminino.
[07:04] Mulher, 35 mais,
[07:06] 35 a,
[07:08] 60 anos,
[07:10] gênero,
[07:12] mulheres.
[07:14] Direcionamento detalhado, não precisa.
[07:16] Tá, isso aqui, ó.
[07:18] Não funciona mais, já funcionou muito, mas agora não funciona mais.
[07:20] Então você coloca.
[07:21] Mulher de 35 a 60 anos.
[07:23] Ou então, homem de 30 a 45 anos.
[07:26] Ah, adolescente de tal a tal e tal.
[07:29] Cara, só o máximo de público que você vai fazer isso.
[07:32] A menos que você tenha alunos.
[07:34] Lembre-se disso.
[07:35] Posicionamentos,
[07:37] não coloca, deixa livre, livre.
[07:40] Ah, vai ter no trades? Vai, vai ter.
[07:42] Cara, onde estiver vendendo, ele vai mostrar.
[07:45] Então não preocupa, definição ampla.
[07:48] Clique em avançar.
[07:52] Nome do anúncio.
[07:53] Isso aqui é já por criativo, né?
[07:56] Criativo 1.
[07:59] Entendeu?
[08:01] Simples.
[08:02] Não é parceria, identidade.
[08:04] Escolha identidade, aqui eu tenho várias contas, né?
[08:07] Posso colocar a Turbo Academy.
[08:11] Turbo Academy, pronto.
[08:13] Leonardo, meu Instagram, né? Tá puxando no meu Instagram.
[08:15] Meu threads, Leotabar,
[08:17] página Facebook, Turbo Academy.
[08:19] Isso aqui é a página que você vai usar para anunciar.
[08:21] Posso deixar sem Instagram?
[08:23] Cara, antigamente deixava, agora não recomendo.
[08:26] Então deixa pelo menos com Instagram.
[08:28] Pagina pode ser qualquer uma, você pode ter várias páginas.
[08:30] Nós mesmos anunciamos de várias, porque quando bate o limite de anúncio,
[08:34] a gente cria as páginas novas.
[08:36] E threads, se tiver, pode colocar também.
[08:38] Deixa aparecer anúncio.
[08:40] Configuração do anúncio, criar o anúncio.
[08:43] Começar.
[08:44] Bem simples.
[08:46] Tá aqui explicando tudo como que você faz para criar o anúncio,
[08:48] se você não sabe.
[08:50] Tá?
[08:51] Aqui o que a gente vai fazer, o upload manual,
[08:53] carregar imagens ou vídeos manualmente.
[08:55] O formato.
[08:57] Imagem ou vídeo único.
[08:59] Não estou usando o carro-cel.
[09:01] Você pode fazer uma campanha só de carro-cel,
[09:03] teste também é legal.
[09:05] A gente tem feito uns carro-cells bem legais de tirinhas
[09:07] e testado uma campanha separada.
[09:09] Aqui você vai colocar imagem ou vídeo.
[09:11] Sabe qual é a proporção?
[09:13] Você vai colocar entre 10 e 15 imagens.
[09:16] E entre 2 e 5 vídeos.
[09:18] Se você colocar 10 imagens, você vai colocar 2 vídeos.
[09:21] Você vai colocar 15 imagens, você vai colocar 5 vídeos.
[09:24] Por que que tem que ter os dois?
[09:26] Eu já vou explicar isso aí, quando eu for falar de criativos.
[09:29] Aí eu vou explicar o detalhe.
[09:31] Mas sempre isso aí.
[09:32] Entre 10 e 15 imagens, entre 2 e 5 vídeos em todas as campanhas.
[09:36] Nunca menos de 10.
[09:38] Beleza?
[09:39] Então deixe aqui mais ou vídeo único.
[09:41] Anúncio com vários anunciões.
[09:43] Pode deixar.
[09:44] Destino.
[09:45] Aqui é sua página de vendas.
[09:47] www.turboacademy.
[09:53] É a página que você está testando.
[09:56] .com.br.
[09:58] .funil8.
[10:01] Por exemplo, link de exibição.
[10:04] É o link que as pessoas vão ver.
[10:06] Porque aqui, quando eu testo várias páginas,
[10:08] vai ter traço v1, v2, v3, por aí vai.
[10:13] Aí eu posso deixar o link só a primeira parte.
[10:16] Por exemplo, a versão.
[10:18] Então posso deixar só do site.
[10:20] Não tem problema.
[10:22] Mas se você quiser ver prévia aqui,
[10:24] eu não sei se essa página está ativa,
[10:26] então não vou ver prévia.
[10:28] Completar navegador?
[10:29] Nenhum.
[10:30] Eu não quero botão de ligar.
[10:32] Instagram Direct, eu não quero.
[10:33] WhatsApp, eu não quero.
[10:34] Formular instantâneo.
[10:36] Isso aqui eu já testei.
[10:37] Isso aqui funciona, mas dá um trabalhinho extra.
[10:40] Eu não quero que você mexe agora.
[10:42] Então deixa por enquanto nenhum.
[10:44] Nenhum nenhum.
[10:46] Então aqui, criativos do anúncio.
[10:47] Não precisa mexer agora.
[10:50] Criatários do evento opcional.
[10:52] Não precisa.
[10:53] Rastreamento, evento, está pegando o pixel.
[10:56] Se o nome está ativo, porque eu não estou usando
[10:59] a página de teste, se ele estaria ativo.
[11:01] Eventos offline e parâmetros.
[11:03] Aqui é para quem usa o TMS.
[11:05] Também você não remeixer.
[11:07] Eu criei o anúncio?
[11:08] Não, não criei o anúncio.
[11:10] Deixei aqui sem crer o anúncio.
[11:11] Clico em publicar.
[11:13] Ele vai dar o erro pedindo o anúncio.
[11:15] Ah, tem a forma de pagamento.
[11:17] Você pode escolher qualquer um.
[11:19] Deixar aqui boleto.
[11:21] Pode ser cartão ou crédito.
[11:23] Vamos lá.
[11:24] Então estou lá com a campanha.
[11:26] Teste ASC.
[11:27] Ele cria um conjunto de anúncio novo.
[11:29] Poderia criar novos, mas eu só quero um.
[11:31] Eu não quero mais conjunto de anúncio.
[11:33] Eu quero aqui criar anúncios.
[11:36] Então vem aqui em criar teste.
[11:39] Conjunho de anúncio no nome.
[11:41] Não preciso mudar anúncio.
[11:43] Teste imagem.
[11:46] Opa, saiu o Amaz aqui.
[11:49] Continuar.
[11:53] Seleção na página do Facebook.
[11:55] Vou ter que trocar aqui para Turbo Academy.
[11:58] Pronto.
[12:02] Tem que estar aqui com a página bonitinho.
[12:05] O upload manual, imagem ou vídeo.
[12:08] O site de destino.
[12:10] Eu preciso colocar www.turboacademy.com.br.
[12:18] Link de exibição.
[12:21] Pode ser o mesmo.
[12:23] Para aparecer bonitinho aqui do lado aparece.
[12:25] Nenhum.
[12:26] E aqui configurar criativo.
[12:28] Você clica anúncio de imagem.
[12:30] Aqui que você vai subir as imagens.
[12:32] Anúncio de imagem.
[12:35] O RL da fonte.
[12:37] De onde que vai vir.
[12:38] Configurar destaques.
[12:40] Aplicar o site.
[12:41] Está bonitinho.
[12:42] Pode colocar aqui páginas.
[12:46] Roto de exibição.
[12:47] Miniatura para aparecer.
[12:49] Só ficar bonitinho.
[12:51] Não precisa.
[12:52] Só que eu quero avançar.
[12:53] Você vai começar a subir imagens.
[12:55] Você pode pegar imagens por ontem do Instagram.
[12:57] Ou carregar.
[12:59] Você pode vir aqui carregar.
[13:01] Normalmente eu vou carregar e selecionar as imagens que a equipe criou.
[13:04] Mas eu vou pegar aqui só para facilitar o trabalho.
[13:08] Para ir mais rápido.
[13:10] Está aqui a imagem.
[13:11] Apareceu o quadrado.
[13:12] Verticar horizontal.
[13:13] O jeito que ela aparece.
[13:14] Não precisa ficar mudando.
[13:16] Você poderia ficar fazendo em todos os formatos.
[13:18] Aqui a gente está no jogo de velocidade.
[13:20] Avançar.
[13:21] Coloca o texto.
[13:23] Escreva a copy.
[13:26] Essa copy você pega tudo com a título.
[13:29] Fone 8.
[13:32] Ou título que você quiser.
[13:34] Coloque a promessa.
[13:35] É mais interessante.
[13:37] Descrição.
[13:39] Compre agora.
[13:41] Ou você pode colocar uma descrição mais aprofundada do que tem no curso.
[13:45] Você pode ter opção de descrição.
[13:47] Uma outra descrição para ele poder ir alterando.
[13:50] Não precisa.
[13:51] Aqui também teste de copy.
[13:53] Você pode adicionar várias copies de texto principal.
[13:56] Que ele vai ficar trocando automaticamente para ver qual é melhor.
[13:59] Chamada para ação.
[14:01] Normalmente a gente deixa a saiba mais.
[14:03] Mas se você quiser.
[14:05] Você pode colocar agora.
[14:07] Compre agora.
[14:08] Eu prefiro já usar isso aqui.
[14:10] Compre agora.
[14:11] Você está vendendo.
[14:13] Então compre agora.
[14:14] Ele já vai para a página de vendas.
[14:15] Avança.
[14:19] Aprimoradamente.
[14:20] Trans promessa e usa sobreposição para emonta.
[14:23] Não marca nada nada nada nada nada nada.
[14:26] Então eu mais melhoras coisas estão muito ruim.
[14:28] Cara toda vez com isso aqui dá muito ruim.
[14:31] Que era o colocar animação numa imagem não faça isso.
[14:34] Dá muito ruim.
[14:35] Aparece as imagens muito doida.
[14:36] Quando isso aqui ficar bom eu vou regravar esse curso.
[14:39] Eu vou avisar vocês.
[14:40] Mas por enquanto não tá quer colocar música.
[14:42] Já tá então deixa.
[14:43] Aprimorá CTA pode deixar.
[14:45] deixar. Esses dois aqui pode deixar, tá? Esse aqui a gente já usa. Isso ajuda a distribuir
[14:50] mais. Só esses dois, mais nada. Pode vir personalizar só se quiser. Se não, pode concluir
[14:57] e depois em publicar. Você vai fazer isso aqui várias vezes. Ah Lea, mas é tudo igual.
[15:03] O que eu preciso fazer? Você vem e vai duplicando isso aqui, ó. Tá vendo aqui,
[15:08] vou colocar. Pronto. Teste dois. Vai ser quantidade de cópias. Dez. Vou deixar aqui, ó, zero,
[15:22] que ele vai ficar numerando sozinho. Ele vai criar as cópias pra você. O que você vai
[15:29] fazer em cada um deles? Vim trocando o nome e subindo os criativos. Então vem aqui,
[15:39] em parte imagem, zero, dois. Zero, dois. O que que eu venho fazer aqui? Venho aqui e troco a imagem.
[15:49] Eu jogo essa fora, a mídia e adiciono outra imagem. Só isso que você vai vir fazendo pra
[15:55] andar rápido. Vou pegar essa do turbo aqui agora. O resto eu deixo igual. Não quero brincar muito
[16:04] com isso não. Feito no dois, vou pro três. Você pode publicar tudo no final, tá? Precisa
[16:10] uma vez não. Troco o nome, teste zero três. Onde que eu vou? Vou lá na mídia, jogo fora e
[16:21] adiciono um vídeo agora. Agora eu quero um vídeo. Avançar pode ser um vídeo qualquer. Avançar,
[16:28] avançar, concluir. Pronto, vídeo. Aqui como não é imagem, teste vídeo e vai fazendo isso com
[16:40] todos. Todas as cópias. Eu coloquei dez aqui, nós estamos falando aí de T12. Quando fizer isso com
[16:47] todos, você vai lá e clica no publicar. Toda hora vai mandar adicionar fundos, tá gente? Porque
[16:52] essa é uma conta teste. Os criativos vão aparecer todos aqui, tá vendo? Eu posso vir e
[16:59] vim editando todos aqui depois. E aqui depois eu posso vir aqui em cima conferir e publicar
[17:05] todos de uma vez. E pronto. Essa é a parte difícil do tráfego de criação, tá? Isso é o
[17:12] passo a passo para criação. Essa aula foi um pouquinho mais longa do que as outras porque eu
[17:17] tinha que mostrar esse passo a passo, senão você ia ficar perdido aí na hora de criar. Nós vamos
[17:23] ainda ver a otimização e tudo o restante. Legal? Então te vejo na aula quatro.

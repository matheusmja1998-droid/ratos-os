---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 3
tema: Como criar a campanha ASC (Advantage+) no Gerenciador — passo a passo prático
fonte: Transcrição automática do áudio MP3 (faster-whisper)
duração: ~17 min
tags: [funil-8, tráfego-pago, advantage, asc, gerenciador, criativos, pixel]
---

# Aula 3 — Funil 8: Estrutura de Tráfego Pago

[[Leonardo Tabari — Índice]]

> Passo a passo prático no Gerenciador de Anúncios pra subir campanha ASC (Advantage+ Shopping Campaigns) do Funil 8. Metodologia própria — diferente do que gestor de tráfego está acostumado.

## Lógica antes de abrir o Gerenciador

- Campanha **focada em público frio** — 70–80% frio é o objetivo
- Tipo: **ASC** (Advantage+ Shopping Campaigns) — campanha de Vendas Advantage+
- Não define conjunto de anúncios — Meta busca automaticamente quente/frio
- **Público aberto** — deixa padrão no início, deixa gerar inteligência
- Inteligência crescente — quanto mais gasta certo, mais inteligente fica
- **Não queimar dinheiro só pra "alimentar IA"** — se você queima muito, ela aprende que você tolera prejuízo
- Verba contida = otimização melhor

## Passo a passo no Gerenciador

1. **Criar** → Vendas → Continuar
2. Nome da campanha (ex: `teste ASC 01`)
3. Tipo: Leilão / Vendas
4. **NÃO mexer em catálogo**
5. **Orçamento a nível de campanha** — diário começa com **R$100** (mínimo). Se tem mais verba: R$500. Abaixo de R$100 não performa.
6. **Não mexer:** teste A/B, relatório, categoria especial — nada
7. → Avançar

## Conjunto de anúncios

- **Não criar conjunto** — deixa direto
- **Local da conversão:** Site (mesmo se vende por app — qualquer mudança piora resultado)
- **Otimização:** Maximizar número de **conversões** (não visualizações de página — traz público ruim)
- **Pixel** — usar o existente ou criar novo. Necessita domínio (configurar depois, no bônus do gestor de tráfego)
- **Evento de conversão:** **Comprar** (Purchase). Pode personalizar mas pra começar: comprar.
- **Meta de custo por resultado:** NÃO definir (limita capacidade no início; precisa ficar mais caro pra pegar inteligência)
- **Limite de gasto:** não preencher
- **Data de início:** sempre dia seguinte, **5h da manhã**. Não colocar "agora".
- **Nunca termina** (só começa)
- **Público salvo** — só usar se tiver lista de alunos com mínimo 10k pessoas. Senão, em branco.
- **NÃO usar:** público de captura, início de checkout
- **Idade/gênero:** só se faz sentido pro nicho (ex: "Cliama de Crescimento Feminino" — mulher 35–60). Senão, máximo de público.
- **Direcionamento detalhado:** NÃO USAR (não funciona mais como antes)
- **Posicionamentos:** livre / definição ampla — Meta distribui onde converter
- → Avançar

## Anúncios

- Nome: `Criativo 1`, `Criativo 2`...
- Identidade: página + Instagram (recomenda manter Instagram conectado, antes dava pra deixar sem mas agora não)
- Threads: se tiver, anexa
- **Várias páginas** — Tabari roda várias porque quando bate limite, abre página nova
- Configuração do anúncio: **Upload manual**
- Formato: **imagem ou vídeo único** (carrossel pode ser campanha separada de teste)

## Proporção de criativos por campanha (REGRA)

- **10 imagens + 2 vídeos**, OU
- **15 imagens + 5 vídeos**
- **Nunca menos de 10 criativos**
- Sempre os dois formatos (motivo detalhado na aula de criativos)

## Configuração do criativo

- Mídia: imagem ou vídeo (subir manual, escolher carregar)
- Não ficar mudando formato (vertical, horizontal) — jogo é velocidade
- **Texto principal** = copy do anúncio
- **Título** = "Funil 8" ou a promessa (promessa converte melhor)
- **Descrição** = "Compre agora" ou descrição mais aprofundada
- Pode adicionar **múltiplas copies de texto principal** — Meta testa qual converte melhor
- **CTA** = "Compre agora" (Tabari prefere ao "Saiba mais" — já está vendendo)
- URL: página de vendas (`www.dominio.com/funil8`)
- Link de exibição: pode ser só o domínio principal (sem `/v1`, `/v2`)

## O que NÃO marcar (importante!)

- Aprimoramentos transparência e sobreposição → **NÃO**
- Animação em imagem → **NÃO** ("dá muito ruim, aparece imagem doida"). Tabari avisa que vai regravar a aula quando isso melhorar.
- Música → não marcar
- **Aprimorar CTA** → pode deixar
- Os dois aprimoramentos básicos (CTA + algo) ajudam a distribuir — só esses dois.

## Velocidade na criação dos 10–15 criativos

Em vez de criar 1 por 1:
1. Cria o primeiro completo
2. **Duplica em 10 cópias** (ferramenta do Gerenciador) com numeração automática
3. Em cada cópia: **trocar nome + trocar a mídia** (jogar fora imagem, subir nova)
4. Repetir 10–12 vezes pra imagens + 2–5 vezes pra vídeos
5. Quando termina, publicar todos juntos

Vai aparecer "Adicionar fundos" (porque é conta teste, normal).

## Forma de pagamento

Cartão, crédito ou boleto (à escolha).

## Próximos passos

Aula 4 — Otimização (regras automáticas + duplicação + critério de pausar/escalar) → [[Aula 4 — Funil 8 — Otimizando resultados]]

## Detalhes técnicos do gestor

Tabari deixa **aula bônus do gestor de tráfego dele no final do curso** com:
- Configuração de pixel
- Metrificação detalhada
- Eventos offline / TMS
- API de conversões

Cobertura paralela em: [[Tráfego Aula 4 — Pixel e eventos]] | [[Tráfego Aula 1 — Introdução e métricas]] | [[Tráfego Aula 5 — Segmentações e públicos]]

## Pontos-chave a memorizar

- Tipo: **ASC / Advantage+ Shopping**
- Orçamento: **R$100/dia mínimo**, nível de campanha
- Início: **dia seguinte às 5h**
- Público: **aberto** (frio)
- Otimização: **conversão = Comprar**
- Criativos: **10–15 imagens + 2–5 vídeos** (nunca menos de 10 total)
- CTA: **Compre agora**
- Aprimoramentos: **desligar** transparência/sobreposição/animação/música

## Links

- [[Aula 2 — Funil 8 — Estrutura do produto]] (aula anterior)
- [[Aula 4 — Funil 8 — Otimizando resultados]] (próxima — otimização)
- [[Segredo ROAS 5X — Aula 1 (Funil 8)]] (regras de otimização CAC e horário)
- [[Tabari — 1M por mês com lançamentos gravados]] ("Toda campanha é ASC")
- Paralelo Sobral: [[Live 361 — Andromeda, Pmax e Advantage+ — IA das fontes de tráfego]]

## Transcrição completa

`Transcrições/Transcrição — Aula 3 Tráfego pago.md`

---
tipo: aula
autor: Leonardo Tabari
curso: Tráfego
numero: 1
tema: Introdução prática ao tráfego pago + métricas
fonte: PDF resumo oficial Turbo Academy
tags: [tráfego-pago, métricas, pixel, capi, business-manager, lookalike]
---

# Tráfego Aula 1 — Introdução e Métricas

[[Leonardo Tabari — Índice]]

> Conjunto de estratégias pra atrair visitantes qualificados via anúncios pagos (Meta, Google, YouTube). Acelera vendas, valida ofertas, escala.

## Conceitos fundamentais

- **Fonte de Tráfego** — plataforma onde o anúncio é exibido
- **Business Manager (BM)** — ambiente de administração do negócio
- **Conta de Anúncio** — onde campanhas são criadas e métricas consolidadas
- **Métricas-chave** — Leads, CPA/CPL, CTR, CPC, CPM, CPV, Alcance, Impressões, Frequência, Connect Rate, ROAS, Ticket Médio, Taxa de Conversão
- **Pixel + API de Conversões** — Pixel é "informante" do site; API complementa servidor-a-servidor
- **Contingência** — duplicação de BMs e contas pra mitigar bloqueios
- **Público** — interesse, lookalike, personalizado, geolocalização

## Dores comuns

- Não entender métricas → má alocação de orçamento
- Bloqueios de conta e interrupção de campanha
- Configuração ruim de Pixel/API → perda de rastreio
- Baixo CTR e alto CPC por qualidade ruim de criativo
- Segmentação ineficaz desperdiçando verba

## Causas

- Configurações incompletas de BM e contas
- Páginas lentas reduzem Connect Rate
- Criativos desalinhados com público ou estágio do funil
- Falta de rotina de análise e testes A/B
- Não usar contingência

## Boas práticas

- Estruturar BM, conta e ativos antes da primeira campanha
- Implementar Pixel + API via Google Tag Manager
- Segmentações progressivas: **C1 (quentes), C2 (semi-quentes), C3 (frias)**
- Estabelecer ROAS alvo (mín 3, ideal 5) e pausar/escalar conforme desempenho
- Looker Studio pra centralizar relatórios multi-fonte

## O que fazer

- Definir objetivo claro (lead, venda, engajamento) antes de subir
- Monitorar métricas diariamente (campanha + conjunto + anúncio)
- Frequência ≤2 pra públicos frios
- Estrutura de contingência (2 BMs, 2 contas, 2 páginas de backup)
- Otimizar páginas pra carregar <3s

## O que NÃO fazer

- Não anunciar sem Pixel/API
- Evitar criativos genéricos pra todos os públicos
- Não desconsiderar bloqueios; seguir políticas
- Não depender de um único canal ou BM

## Checklist inicial

1. Criar BM e adicionar página
2. Abrir Conta de Anúncio + forma de pagamento
3. Instalar Pixel + API (GTM)
4. Configurar eventos (ViewContent, Lead, Purchase)
5. Criar públicos personalizados e lookalike
6. Primeira campanha teste com budget controlado

## Ferramentas

- Meta Business Manager + Ads Manager
- Google Ads + Central de Clientes
- Google Tag Manager
- Google Analytics
- Google Looker Studio

## Exemplos

- **ROAS** — R$1k investido, R$5k receita → ROAS 5 (manter e escalar)
- **Frequência** — 10 pessoas alcançadas com 20 impressões → frequência 2 (cada pessoa viu 2x)
- **Contingência** — BM1 bloqueada → ativa BM2, duplica campanhas via CSV → no ar em <2h

## Glossário

- **CPA/CPL** — Custo por Ação/Lead
- **CTR** — Click-Through Rate
- **CPM** — Custo por Mil Impressões
- **Connect Rate** — % de cliques que carregam a página
- **ROAS** — Return on Ad Spend
- **Lookalike** — público semelhante gerado a partir de origem
- **Contingência** — estrutura paralela contra bloqueios

## Links

- [[Tráfego — Estruturas oficiais Meta]]
- [[Tráfego Aula 2 — Métricas no Gerenciador]]
- [[Tráfego Aula 4 — Pixel e eventos]]
- [[Tráfego Aula 5 — Segmentações e públicos]]

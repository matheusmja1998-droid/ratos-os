---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 4
tema: Otimização de campanhas — CTR, ROAS, duplicação de escala
fonte: PDF resumo oficial Turbo Academy
tags: [funil-8, otimização, ctr, roas, duplicação, escala, criativos]
---

# Aula 4 — Funil 8: Otimizando Resultados

[[Leonardo Tabari — Índice]]

> Processo técnico de otimização: diagnosticar e solucionar o problema mais comum — falta de vendas apesar do investimento. CTR, taxa de conversão, ROAS como guias de decisão.

## Conceitos fundamentais

- **ROAS** = Receita / Custo. Mais importante pra lucratividade.
- **CTR** = (Cliques / Impressões) × 100. Mede qualidade do criativo. **Abaixo de 1% → pausar.**
- **Taxa de conversão checkout** — alvo inicial >10%, na escala aceita 6–7%. Otimização via banners e IA. A "cabeça" da página (primeira dobra) faz a maior diferença.
- **CAC** = Custo da campanha / Vendas

## Régua do ROAS

| ROAS | Diagnóstico | Ação |
|---|---|---|
| < 1 (ex: 0,5) | Prejuízo claro | Pausar |
| = 1 | Pequeno prejuízo (taxas + impostos) | Analisar e otimizar com urgência |
| 1,1–1,2 | Limite mínimo aceitável → interessante | Otimizar pra melhorar |
| > 1,8–2,0 | Excelente | Preparar pra escalar |

## Principais dores

- Campanhas ativas sem vendas
- ROAS negativo ou baixo
- Incerteza sobre qual elemento está falhando (criativo, página, oferta, público)
- Medo de escalar

## Causas mais comuns

- Criativos com CTR <1% — não geram tráfego qualificado em volume
- Páginas/checkouts com design confuso, copy fraca, sem confiança
- Oferta com baixa percepção de valor (nome ruim, promessa fraca)
- Otimização precipitada (pausar campanha antes dos 7 dias de aprendizado)
- Orçamento insuficiente (<R$100/dia o algoritmo não tem dados)

## Soluções e estratégias

- **Decisão fria, baseada em métricas** — sem emoção
- **Escala segura por duplicação** — NUNCA aumentar o orçamento da campanha original. Sempre duplicar e colocar verba maior na cópia. Preserva inteligência da campanha original.
- **Testes isolados em campanhas duplicadas** — pra testar criativos novos, duplica a melhor, troca os criativos. Vencedores do teste vão pra campanha de escala.
- **Funil de Consciência C1, C2, C3** — campanhas de conteúdo pra diferentes níveis aquecem audiência e melhoram ROAS das vendas diretas.

## O que fazer

- Monitorar CTR, pausar criativos abaixo de 1% consistentemente
- Analisar ROAS pela régua acima
- Otimizar checkout buscando taxa inicial >10%
- Esperar 7 dias antes de conclusões
- Investir mínimo R$100/dia
- Produzir criativos em volume — meta ~50/semana entre vídeo e imagem. O método do curso permite 40 criativos em 15 min.
- Priorizar otimização de criativos sempre que campanha estiver ruim
- Usar orgânico de apoio (link na bio, Stories, Reels) pra gerar caixa
- Buscar ajuda e inspiração — não há vergonha em copiar referências

## O que NÃO fazer

- Não escalar campanha original (alto risco de quebrar otimização)
- Não tomar decisões emocionais (pausar por 1–2 dias ruins)
- Não insistir em produto sem demanda — se R$17 não vende, reavalie nome/demanda
- Não desistir prematuro — sucesso pode levar dias, semanas, meses, até 3 meses
- Não ignorar parte financeira (ROAS 1 = prejuízo após impostos e taxas)

## Ferramentas

- Meta Ads Manager, Google Ads
- IA: ChatGPT, Midjourney (copy, nomes, imagens)
- Minichat (automações Direct)

## Rotinas

- **Diária** — métricas primárias (CTR, custo por compra, ROAS), pausar criativos ruins
- **Semanal** — análise aprofundada, decisões de otimização/escala, planejar criativos
- **Contínua** — A/B em headline e primeira dobra da página, A/B no checkout

## Próximos passos

- Aprofundar em **Funil de Consciência C1/C2/C3** → [[Aula 19 — Distribuição C1 C2 C3]]
- Estudar copywriting e design de página

## O curso Estratégia Turbo (5 ciclos)

1. Funil 8 (este curso)
2. Tube Express (bônus pra quem assistir em 7 dias) → [[Turbo Express — Aula 3 (sistema orgânico)]]
3. C1, C2, C3 detalhado
4. Lançamento Pago (princípios do lançamento gratuito do Érico Rocha aplicados a venda direta de ingresso)
5. Gestão Completa (otimização, financeiro, impostos, equipe) → [[Aula 22 — Plataformas e Tributação]]

## Links relacionados

- [[Aula 1 — Funil 8 — Fundamentos]]
- [[Tráfego Aula 2 — Métricas no Gerenciador]]
- [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]]

---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8 — Implementação rápida
tema: Como construir Funil 8 em menos de 1 semana e otimizar pra escalar
fonte: PDF resumo oficial Turbo Academy
tags: [funil-8, implementação, low-ticket, advantage, order-bump]
---

# Funil 8 em menos de 1 semana

[[Leonardo Tabari — Índice]]

> Implementação acelerada do Funil 8: validar oferta rapidamente, otimizar criativos e escalar com previsibilidade.

## Conceitos centrais

- **Funil 8** — produto entrada R$17, captação de leads qualificados, fluxo de caixa
- **Low Ticket** — produto acessível, foco em volume e validação rápida
- **Ascensão** — levar comprador do entrada pra produto principal
- **ROAS 1** — empate (gerar leads a custo zero); ROAS 1,3+ pra escalar
- **Order Bump** — oferta adicional no checkout
- **Upsell** — oferta após compra inicial

## Dores comuns

- Procrastinação na implementação (excesso de estudo, busca por perfeição)
- Dificuldade em validar ofertas (não saber o que vende)
- Criativos e nomes pouco impactantes
- Baixa ascensão (lead não avança pra produto principal)
- Otimização ineficiente (não trocar criativos com frequência)
- Escala travada (medo de aumentar verba)

## Causas dos erros

- Foco em lucro imediato no low ticket (errado — objetivo é empatar)
- Oferta genérica, sem promessa específica
- Demora pra trocar criativos, banners, nomes, order bumps
- Misturar métricas do Funil 8 com produto principal
- Não preparar lead pra ascensão

## Estrutura do Funil 8

1. **Produto de entrada R$17–R$35** com promessa clara
2. **3 order bumps em escadinha** (ex: R$17, R$26, R$35)
3. **Upsell** opcional
4. **7 aulas gravadas** de 10–20 min cada, com resultado rápido e preparando ascensão
5. **Tráfego pago Meta Ads** com campanha **Advantage+**, público aberto, **mínimo 10 criativos** (8 estáticos + 2 vídeos)
6. **Otimização contínua** de criativos, nomes, checkouts e páginas

## Separação de funis (CRÍTICO)

Métricas do Funil 8 NÃO entram no ROAS do produto principal. Tem que ser conta separada.

## Otimização por métrica

- **Imagem** → otimize pelo **CTR**
- **Vídeo** → otimize pelo **CAC**
- **Order bump** → troque NOME antes de trocar conteúdo

## Validação rápida

Comece R$17. Ajuste nome e criativos até vender. Depois escale preço e teste order bumps.

## O que fazer

- Validar oferta com preço baixo, nome atrativo, promessa clara
- Gravar 7 aulas diretas com resultado rápido
- Criar 3 order bumps em escadinha
- Subir Advantage+ com 10–20 criativos
- Trocar criativos e nomes a cada 2–3 dias até validar
- Otimizar pelo CTR (imagem) e CAC (vídeo)
- Separar métricas
- Usar IA pra produção de criativos e scripts
- Testar banners e checkouts após validar criativos
- Escalar orçamento gradualmente (5%/dia)
- Duplicar campanhas pra novos testes

## O que NÃO fazer

- Focar em lucro imediato (objetivo é empatar)
- Misturar métricas do Funil 8 com produto principal
- Demorar pra trocar criativos
- Usar e-book como produto de entrada (e-book não gera transformação rápida)
- Criar páginas antes de validar criativo e checkout
- Deixar público esfriar entre ofertas
- Escalar sem ROAS mínimo de 1,3

## Ferramentas

Hotmart, Canva, Gama, Sora, Photoshop, IA (ChatGPT, Octa, Tutor Hotmart)

## Tarefas práticas

- Definir e gravar produto e aulas em até **2 dias**
- 10–20 criativos por campanha
- Trocar criativos e nomes a cada **2–3 dias**
- Testar banners e checkouts após validação inicial
- Regras automáticas de otimização ao escalar
- Rotina semanal de criativos + testes de páginas/checkouts

## Métricas a acompanhar

CTR, CAC, conversão de checkout, conversão de order bump

## Exemplos de Funil 8 por nicho

- **Emagrecimento** — "Como perder 5kg em 7 dias" R$17 + order bumps cardápio R$26 / grupo VIP R$35 / lista de compras R$17
- **Crochê** — primeira peça do zero R$17 + receitas avançadas + comunidade
- **Multas de trânsito** — "Como não pagar suas multas" R$17 + modelos de recurso + checklist
- **Confeitaria** — produto entrada com embalagens criativas + receitas exclusivas + planilha de custos
- **Psicologia** — "Identificação dos componentes da ansiedade" R$17 + ferramentas práticas + supervisão em grupo

## Próximos passos

- Lançamento pago e Turbo Express pra escalar → [[Turbo Express — Aula 3 (sistema orgânico)]]
- IA pra criativos e scripts → [[IA para Criativos — Gamma ElevenLabs Flow]]
- Métricas e regras automáticas → [[Tráfego Aula 2 — Métricas no Gerenciador]]
- Copy do entrada → [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]]

## Leituras

- *A Máquina Definitiva de Vendas* — Chet Holmes
- *As Armas da Persuasão* — Robert Cialdini
- *Tráfego e Conversão* — Ryan Deiss & Russ Henneberry
- *Copywriting: Palavras que Vendem Milhões* — Paulo Maccedo

## Mensagem final

> O sucesso depende de ação rápida, testes constantes e foco em entregar resultado imediato. Não espere perfeição: implemente, ajuste e escale.

---
tipo: índice
autor: Leonardo Tabari
empresa: Turbo Academy
tags: [tabari, turbo-academy, funil-8, tráfego-pago, lançamento-pago, índice]
---

# Leonardo Tabari — Turbo Academy

Materiais do curso Funil 8 + Turbo Express + módulo de Tráfego + aulas "Segredo do ROAS 5X" (lives semanais terças 17h–18h). Foco: aquisição de leads a custo zero com produtos low-ticket (R$17 inicial), escala via lançamento pago semanal gravado, gestão profissional de Meta Ads.

Métodos centrais:
- **Funil 8** — produto de entrada low-ticket, ROAS alvo 1,2 (break-even), monetização via esteira
- **Turbo Express** — sistema orgânico recorrente sem tráfego pago, ciclo captação + venda em grupo
- **Lançamento Pago Semanal Gravado** — workshop ou desafio com captação contínua
- **Distribuição C1/C2/C3** — atração, qualificação, conversão (níveis de consciência de Schwartz aplicados)
- **Estratégia Turbo (Copy Turbo, IA, otimização tributária)**

---

## Funil 8 (núcleo do método)

| Aula | Tema | Link |
|---|---|---|
| 0 | Boas-vindas + combinados do curso | [[Aula 0 — Funil 8 — Boas-vindas]] |
| 1 | Fundamentos do Funil 8 (Teoria do 8, ROAS 1.2, antifrágil) | [[Aula 1 — Funil 8 — Fundamentos]] |
| 2 | Estrutura como criar o seu produto (áudio) | [[Aula 2 — Funil 8 — Estrutura do produto]] |
| 3 | Estrutura de tráfego pago (áudio) | [[Aula 3 — Funil 8 — Estrutura de tráfego pago]] |
| 4 | Otimizando resultados (CTR, ROAS, duplicação) | [[Aula 4 — Funil 8 — Otimizando resultados]] |
| 5 | Como acelerar resultados (Copy Turbo + IA) | [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]] |
| — | Construir Funil 8 em menos de 1 semana | [[Funil 8 em 1 semana — Implementação rápida]] |

## Módulo Tráfego Pago

| # | Tema | Link |
|---|---|---|
| Estruturas | Perfil, Página, BM, Conta de Anúncios, 2FA | [[Tráfego — Estruturas oficiais Meta]] |
| 1 | Introdução prática + métricas | [[Tráfego Aula 1 — Introdução e métricas]] |
| 2 | Análise de métricas no Gerenciador (CTR, CPM, Connect Rate, CPV) | [[Tráfego Aula 2 — Métricas no Gerenciador]] |
| 4 | Pagamentos + instalação do Pixel + eventos | [[Tráfego Aula 4 — Pixel e eventos]] |
| 5 | Segmentações e públicos (PP, Lookalike, Detalhado) | [[Tráfego Aula 5 — Segmentações e públicos]] |

## Segredo do ROAS 5X (lives semanais)

| Aula | Tema | Link |
|---|---|---|
| 1 (01/04/2025) | Segredo do ROAS 5X — abertura do Funil 8 | [[Segredo ROAS 5X — Aula 1 (Funil 8)]] |
| 19 | Distribuição C1/C2/C3 — método completo | [[Aula 19 — Distribuição C1 C2 C3]] |
| 20 | Pesquisa com leads e alunos pra aumentar faturamento | [[Aula 20 — Pesquisa estratégica]] |
| 21 | Estrutura emocional — autossabotagem no digital | [[Aula 21 — Estrutura emocional]] |
| 22 | Plataformas + tributação (livro, lucro presumido) | [[Aula 22 — Plataformas e Tributação]] |

## Turbo Express

| Aula | Tema | Link |
|---|---|---|
| 3 | Turbo Express — captação + venda em grupo orgânico | [[Turbo Express — Aula 3 (sistema orgânico)]] |

## Materiais especiais

| Material | Link |
|---|---|
| Apresentação: 1M/mês com lançamentos pagos gravados | [[Tabari — 1M por mês com lançamentos gravados]] |
| Inteligência Artificial para Criativos (Gamma, ElevenLabs, Flow) | [[IA para Criativos — Gamma ElevenLabs Flow]] |

---

## Conexões com Pedro Sobral

Tabari cita Sobral diretamente como referência em tráfego pago no contexto brasileiro ([[Aula 19 — Distribuição C1 C2 C3]]). Pontos de convergência:

- **Funil de consciência** (C1/C2/C3) — Tabari aplica de forma operacional o que Sobral menciona estrategicamente em [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]]
- **Métricas Meta Ads** — CTR, CPM, ROAS, Connect Rate — base comum com [[Live 315 — Como criar campanhas no Google Ads em 2025]] e [[Live 365 — Google Ads 2026 — Como anunciar]]
- **Lead Ad / Advantage+** — Tabari usa Advantage+ como padrão; Sobral detalha em [[Live 381 — Campanhas de formulário nativo no Meta Ads]] e [[Live 361 — Andromeda, Pmax e Advantage+ — IA das fontes de tráfego]]
- **Onboarding profissional** — Tabari fala de estrutura emocional + tributação; Sobral cobre operação cliente em [[Live 333 — Onboarding de clientes — Tutorial à prova de falhas]]

---

## Transcrições brutas

- [[Transcrição — Aula 0 Boas-vindas]]
- [[Transcrição — Aula 2 Estrutura do produto]]
- [[Transcrição — Aula 3 Tráfego pago]]

## Frameworks recorrentes do Tabari

- **Teoria do 8** — preço cujos algarismos somam 8 (R$17, R$35, R$53, R$62)
- **ROAS-régua** — <1 pausar / 1,1–1,2 limite mínimo / >1,8 escalar
- **Escala por duplicação** — nunca aumentar orçamento da campanha vencedora; sempre duplicar
- **5% por dia / semana** — incremento máximo de orçamento sem quebrar otimização
- **3 order bumps em escadinha** — R$17, R$26, R$35 (ou variações)
- **3 ações paralelas semanais** — carrinho passado + lives presente + captação futuro
- **70-30 / 60-40 / 75-25** — proporção produto-imune × serviço pra tributação no lucro presumido

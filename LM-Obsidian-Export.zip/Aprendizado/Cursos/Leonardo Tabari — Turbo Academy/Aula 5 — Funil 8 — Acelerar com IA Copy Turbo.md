---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 5
tema: Copy Turbo — IA pra otimizar funil (copy + criativos + ofertas)
fonte: PDF resumo oficial Turbo Academy
tags: [funil-8, ia, copy-turbo, chatgpt, criativos, copywriting]
---

# Aula 5 — Funil 8: Como acelerar resultados (Copy Turbo)

[[Leonardo Tabari — Índice]]

> Uso da IA "Copy Turbo" (GPT customizado treinado com 35k páginas de transcrições + 1.200 h de análise individual + trabalho do copywriter Emanuel) pra gerar todos os componentes de texto e criativo do Funil 8 e Lançamento Pago.

## Conceitos

- **Copy Turbo** — IA customizada (ChatGPT principalmente, compatível com Claude/Grok/DeepSeek) pra gerar copy persuasiva pra todas as etapas do funil
- **Funil 8** — aquisição via produto baixo (R$17) com ROAS ~1,0 pra alimentar a esteira
- **Lançamento Pago** — mesma lógica de copy do Funil 8, mas vendendo ingresso de evento
- **Criativos** — peças visuais/textuais (não são apenas design, são armas de comunicação)
- **Copy** — todo texto persuasivo (headlines, roteiros, página, checkout, e-mails)

## Dores que a IA ataca

- Aplicar estrutura do Funil 8 mas não vender
- Nome de produto sem atrativo
- Copy fraca e genérica
- Criativos ignorados (baixo CTR)
- Precificação errada (acima de R$17 no início)
- Síndrome do planejamento infinito

## Causas dos erros

- Vender a "ferramenta" em vez do "resultado/transformação"
- Falta de ângulos (sempre o mesmo gancho)
- Desalinhamento com avatar (não fala a língua do público)
- Oferta fraca, sem irresistibilidade

## Como usar

- Adotar como assistente estratégico, não muleta
- Pedir múltiplas variações de: nome, promessa, headline, copy de anúncio, estrutura de oferta de VSL, ideias de order bump
- **Ser específico no prompt** — público, problema, produto. Ex: "criativos pra donos de pequenas empresas frustrados com recusa de crédito"
- **Filtro ético e de veracidade** — IA pode sugerir promessas exageradas. Corrigir e exigir versão alinhada à realidade.
- **Integração com ferramentas** — copy gerada vira input pra design (aula do Thiago) e pra páginas (DeepSite/Elementor, aula do Marcos Túlio)

## Boas práticas

- Começar com R$17 (atrito mínimo, validação rápida)
- Detalhar público e problema na prompt
- Testar nomes de impacto (autoridade, rebeldia, acesso exclusivo) em vez de descritivos genéricos
- Vender transformação, não característica
- Gerar 5–10 variações por gancho
- Validar promessas (factível + ético)
- Executar e otimizar — IA é acelerador da execução

## O que NÃO fazer

- Usar IA pra não pensar
- Aceitar a 1ª sugestão (peça variações)
- Promessas falsas ou exageradas (destrói credibilidade, risco legal)
- Ignorar aulas complementares (criativos + páginas)
- Ter desculpas — com IA, falta de resultado é falta de execução

## Exemplo prático (curso de score de crédito)

**Prompt inicial:** "Preciso de criativos pra empresários que precisam de crédito. Meu produto ajuda a aumentar o score."

**Reenquadramento sugerido pela IA:** Não vender "aumentar score", vender "destravar até R$300 mil em crédito mesmo com score baixo" (validar veracidade).

**Nomes de produto sugeridos:**
- Liberação Bancária Imediata
- Plano Backscore
- Clube dos Aprovados
- Crédito Oculto
- Desbloqueio Empresarial

**Criativos (gancho + copy):**
1. **Inversão de culpa** — "O score não é o que te nega crédito. É a desculpa que o banco usa."
2. **Paradoxo de curiosidade** — "Como um empresário endividado conseguiu R$140 mil em 21 dias sem mudar nada no score?"
3. **Estatística chocante** — "72% dos empresários brasileiros foram reprovados por um único erro no CNPJ"

## Tarefas práticas

1. Acessar link da Copy Turbo
2. Prompt detalhado sobre produto e público
3. Pedir 5 nomes de impacto
4. Pedir 10 ganchos/copies pra anúncio
5. Pedir estrutura completa de oferta matadora pra página
6. Revisar, filtrar, refinar

## Ferramentas

- Copy Turbo (ChatGPT)
- DeepSite, Elementor — páginas
- Ferramentas de design (aula Thiago)
- Tutor Hotmart — dúvidas

## Glossário

- **VSL** — Video Sales Letter
- **Nicho Black** — nichos com restrições de publicidade (emagrecimento, renda extra, relacionamento). Copy mais agressiva.
- **Order Bump** — oferta complementar no checkout

## Leituras

- *$100M Offers* — Alex Hormozi (estruturação de ofertas irresistíveis)
- *Great Leads* — Michael Masterson e John Forde (tipos de lead pra cada nível de consciência)
- *Scientific Advertising* — Claude Hopkins (teste, mensuração, otimização)

## Links

- [[Aula 4 — Funil 8 — Otimizando resultados]]
- [[IA para Criativos — Gamma ElevenLabs Flow]]
- [[Aula 19 — Distribuição C1 C2 C3]]

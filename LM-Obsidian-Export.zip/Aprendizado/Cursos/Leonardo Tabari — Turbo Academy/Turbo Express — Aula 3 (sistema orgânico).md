---
tipo: aula
autor: Leonardo Tabari
curso: Turbo Express
numero: 3
data: 2025-04-15
tema: Turbo Express — sistema de venda orgânica recorrente
fonte: Transcrição da aula (docx)
tags: [turbo-express, orgânico, grupo-whatsapp, manychat, ciclo-vendas]
---

# Turbo Express — Aula 3

[[Leonardo Tabari — Índice]]

> Sistema que gera **R$20k+/mês sem investir em tráfego pago**. Base orgânica, replicável, em ciclos de captação + venda.

## Objetivo

Inspirado em lançamentos relâmpagos / "meteóricos", mas simplificado pra não exigir muito esforço do expert. Vendas orgânicas, rápidas, replicáveis.

## Componentes principais

- **Turbo Express** — sistema de receita constante orgânica
- **C1** — conteúdo de atração (seguidores + convites pro grupo) — obrigatório pra quem não tem alta atratividade orgânica
- **C2** — quebra de objeções, qualificação
- **C3** — prova e resultados, conversão

(Detalhamento do C1/C2/C3 em [[Aula 19 — Distribuição C1 C2 C3]])

## Integração com outras estratégias

- Roda em paralelo com lançamentos, perpétuos e low-ticket
- Pode "pular" ciclos quando o calendário exige outras ações

## Dinâmica do ciclo

### Captação (14 dias ideal, mínimo 7 dias)
- Formar grupo orgânico qualificado
- Chamadas genéricas ("Quer aprender a ganhar dinheiro com seguidores?")
- Automações via Direct → grupo
- Ferramentas: ManyChat, Full Funnel, Unichat
- Campanhas, lives, stories incentivando entrada no grupo

### Fase de venda (gatilho de oferta)

Sequência de mensagens + vídeos:
1. **Vídeo inicial** (5–10 min) — super promessa + explicação do produto
2. **Vídeo curto** reforçando oferta exclusiva no dia seguinte
3. **Abertura do grupo** pra interação e dúvidas

A oferta inclui:
- **Escassez por tempo** (10 min com bônus exclusivos)
- **Escassez por quantidade** (vagas = 10% do grupo)
- Depoimentos, prints, provas
- Mensagens automáticas (ideal 3/dia, máx 4–5)

### Cronograma
- **Dia 1** — vídeo explicativo + aquecimento
- **Dia 2** — abertura do grupo, dúvidas
- **Dia 3** — oferta. Vagas + reforço de urgência. Carrinho aberto 9h–21h.

## Por que existe? — Posição do expert

Experts e lançadores ficam exaustos com excesso de lives e venda contínua. Turbo Express reduz desgaste — execução fica com sistema organizado + equipe. Equipe conduz sem depender da presença constante do expert.

## Aspectos técnicos / Métricas

### Copy das mensagens
- Curtas (máx 5 linhas), linguagem do público
- Testadas e otimizadas conforme respostas (analisar onde perde leads)

### Ferramentas
- ManyChat, Full Funnel, Unichat
- Disparos via planilha

### Métricas-chave
- **Retenção primeiros 3s** (gancho) → indicador de atratividade
- **Retenção 95% do vídeo** → conteúdo
- **Conversão esperada** — 5–10% dos leads do grupo

### Traqueamento
- Entrada, engajamento, conversão no grupo
- Otimizar a comunicação por dados
- Se leads caem no remarketing manual → revisar copy + automação

## Casos práticos

- **Marcos** — vendeu evento presencial ticket R$3.000, faturou R$130k em poucas horas usando Turbo Express
- **Bônus físicos** (livro, camisa, abridor de lata) pra incentivar compra nos primeiros minutos
- Aplicação em: mentorias, low-ticket, perpétuo, lançamento, físico, serviço

## Adaptação

- Flexibilidade na frequência (semana sim/semana não, intervalos de 2–3 semanas) com base em leads/dia
- Adaptar horários e chamadas ao público (cabeleireiras, dentistas, palestrantes...)

## Pra iniciantes

- Investir minimamente se necessário (R$100/dia), mas foco é orgânico via C1
- Meta realista: 10 vendas R$1.000 = R$10k, com potencial de 20 vendas

## Pós-venda e gerenciamento de grupos

- Manter grupos ativos e movimentados
- Criar **grupos de espera** pra quem não converte
- Excluir grupos inativos pra concentrar esforço
- Leads não-convertidos → ciclos futuros
- Oferta pós-lançamento (~15 dias depois) pra não-compradores

## Vantagens

- **Replicável e escalável** — CTRL+C/CTRL+V pros próximos ciclos
- Faturamento recorrente sem grandes investimentos em tráfego
- Otimização contínua das copies, taxas, retenção

## Links

- [[Aula 19 — Distribuição C1 C2 C3]] — C1/C2/C3 detalhado
- [[Aula 4 — Funil 8 — Otimizando resultados]] — cita Turbo Express como ciclo 2 do Estratégia Turbo
- [[Tabari — 1M por mês com lançamentos gravados]] — variação paga do mesmo conceito (lançamento semanal)

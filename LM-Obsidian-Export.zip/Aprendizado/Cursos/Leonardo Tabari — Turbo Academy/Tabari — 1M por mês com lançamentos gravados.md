---
tipo: apresentação
autor: Leonardo Tabari
tema: Como faturei mais de R$1M/mês com lançamentos pagos gravados
fonte: PPTX original (33 slides)
tags: [lançamento-pago, workshop, desafio, advantage, captação, recorrência]
---

# Tabari — 1M por mês com lançamentos pagos gravados

[[Leonardo Tabari — Índice]]

> Apresentação de Leonardo Tabari sobre como faturou consistentemente +R$1M/mês usando estrutura de lançamento pago semanal gravado. Nichos: emagrecimento, odontologia e marketing digital.

## Por que lançamentos pagos semanais

- Casamento perfeito de perpétuo + lançamento
- **Roda sem precisar do expert**
- Dá pra automatizar quase tudo pra rodar no automático

## Resultados consolidados

### 6 meses
- Faturamento: **R$4.481.356,97**
- Investimento: **R$2.769.051,76**
- ROAS: **1,6**
- Lucro: **R$1.712.305,21**

### 3 meses
- Faturamento: **R$2.786.370,59**
- Investimento: **R$1.220.460,39**
- ROAS: **2,28**
- Lucro: **R$1.565.910,20**

⚠️ "A Black estragou meu gráfico" (sazonalidade de Black Friday no período)

## Vantagens do modelo

- Atrai leads mais qualificados e com intenção de compra
- Reduz desistências, aumenta comparecimento
- Entrega resultados reais e rápidos
- Permite escalar com lucro desde a captação
- **Lançamento toda semana = paz de espírito + previsibilidade**

## Dois modelos

### Modelo Workshop
- Formato: **1 dia intenso** com 7 blocos (5 conteúdo + 2 pitch)
- Objetivo: gerar transformação efetiva durante o workshop
- Elementos essenciais:
  - Engajamento constante
  - Seeding em múltiplos momentos
  - Conteúdo implementável imediatamente
  - Divisão em blocos com intervalos
- Cronograma:
  - **Manhã 9–13h** — 3 blocos conteúdo + 1 pitch
  - **Tarde 15–18h** — 2 blocos conteúdo + 1 pitch

### Modelo Desafio / Semana
- Formato: **7 dias** ou **5+1**
- Objetivo: gerar transformação durante o desafio
- Replay das aulas ao vivo toda semana

## Captação — Venda de Ingresso

- **Toda campanha é ASC** (Advantage+ Shopping Campaigns)
- **Valor do ingresso: R$17 a R$98** (investimento bruto = CAC líquido)
- **3 order bumps** — R$62, R$35, R$17
- **ROAS 1,2** pra escalar sem prejuízo

## Aquecimento

- Lives semanais opcionais (usar a live pra vender ingressos)
- **3 conteúdos preparatórios gravados** pra nivelar todo mundo:
  1. Como vai funcionar esse evento
  2. O que você vai precisar pra participar
  3. Qual resultado você pode esperar (mentalidade)

## Estrutura das 7 aulas ao vivo (40–60 min cada)

- **Aula 1** — Fundamentos e Mentalidade Antifrágil
- **Aula 2** — Implementação inicial e pequena vitória
- **Aula 3** — Aprofundamento e primeiro marco
- **Aula 4** — Obstáculos específicos e como superá-los (**primeiro pitch**)
- **Aula 5** — Progresso intermediário
- **Aula 6** — Aula introdutória do produto principal (no modelo 5+1, fica na recuperação)
- **Aula 7** — Apresentar a oferta completa como próximo passo natural

## Como replicar toda semana — 3 ações paralelas

Toda semana acontecem **simultaneamente**:
1. **Abertura de Carrinho** (passado) — segunda-feira abre carrinho do evento da semana passada
2. **Lives do Evento** (presente) — semana atual o evento está acontecendo
3. **Captação** (futuro) — captando pro evento da próxima semana

Exemplo concreto:
- Semana passada: captei pro evento desta semana
- Esta semana: captando pro evento da próxima semana
- Segunda-feira: abro carrinho do evento da semana passada

## O grande desafio

Rodar as 3 estratégias simultaneamente sem ficar louco. Ganhos:
- **Velocidade de conversão**
- **Previsibilidade**
- **Escala sustentável (5% por semana)**

## Métricas e otimizações durante o desafio

- Taxa de presença diária >70% (views únicos) — não pode cair mais de 50%
- Engajamento nas salas extras ao vivo (com equipe) >40% dos participantes entram em pelo menos 1 aula
- Taxa de presença ao vivo diária — 1º dia >30%, 7º dia >15%
- Identificar onde ocorrem mais desistências pra melhorar

## Ponto de atenção

- A retenção durante o evento é o gargalo crítico
- Evento ao vivo às vezes converte mais. MAS impossível com expert humano semana após semana
- Solução: rodar a estrutura que mais converteu (gravada) e de vez em quando fazer ao vivo (senão a vida do expert fica fácil demais e perde tração)

## Por que fazer lançamento pago semanal gravado

- Já começa o lançamento **sem ansiedade** — custos pagos pela captação
- Sem mais estresse com expert (não depende dele semana após semana)
- Automatização semanal sem dor de cabeça
- **Lançamento Pago foi a solução de caixa que funcionou mais rápido**

## Contato

@leotabari

## Links

- [[Aula 1 — Funil 8 — Fundamentos]] (lógica de captação a custo zero aplicada à venda de ingresso)
- [[Aula 4 — Funil 8 — Otimizando resultados]] (cita Lançamento Pago como ciclo 4 do Estratégia Turbo)
- [[Turbo Express — Aula 3 (sistema orgânico)]] (variação orgânica do mesmo conceito)
- [[Aula 22 — Plataformas e Tributação]] (Hotmart como infra pra escala)

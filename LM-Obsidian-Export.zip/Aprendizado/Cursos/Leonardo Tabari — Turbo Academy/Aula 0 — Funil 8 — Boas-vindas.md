---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 0
tema: Boas-vindas + combinados do curso
fonte: Transcrição automática do áudio MP3 (faster-whisper)
duração: ~3 min
tags: [funil-8, onboarding, acesso-vitalício, tube-express]
---

# Aula 0 — Funil 8: Boas-vindas

[[Leonardo Tabari — Índice]]

> Aula curta de abertura. Tabari celebra a decisão do aluno de entrar no Funil 8 e estabelece os 4 combinados pra ter acesso vitalício + bônus.

## Resumo

Acesso ao curso é **vitalício** com atualizações (porque "internet é idade de cachorro — 1 ano = 7"), desde que o aluno cumpra alguns combinados.

## Os 4 Combinados

### 1. Seguir no Instagram
- Link abaixo do vídeo
- Automação checa periodicamente se está seguindo
- Acesso vitalício depende disso

### 2. Preencher ficha de matrícula
- Link abaixo do vídeo
- Coletam nome, telefone, **Instagram (arroba)**
- Sem o arroba, a automação não consegue checar se você está seguindo

### 3. Entrar no grupo "Segredos do Roa 5x"
- Toda terça 17h–18h ele dá aula no Zoom (Segredo do ROAS 5X)
- Link das aulas só pelo grupo, não fica gravado

### 4. Bônus — Completar curso em 7 dias
- Se assistir todas as aulas em 7 dias → **libera Tube Express grátis**
- Tube Express promete "R$20 mil limpinho no bolso todos os meses"
- Automação checa em 7 dias (precisa marcar como assistido)
- Se passou de 7 dias → não libera
- Se já comprou Tube Express → contatar equipe pra trocar por outro curso (métricas de C1, oferta, etc.)

## Garantia

> "Se você aplicar tudo e não tiver resultado, me manda um direct que eu devolvo seu dinheiro. Já passou 7 dias da Hotmart? Não importa. Eu devolvo."

## Observações

- Curso curto — **~2h totais** de conteúdo
- Aluno é direcionado pra aula 1 logo após

## Links

- [[Aula 1 — Funil 8 — Fundamentos]] (próxima aula)
- [[Turbo Express — Aula 3 (sistema orgânico)]] (o bônus prometido)
- [[Segredo ROAS 5X — Aula 1 (Funil 8)]] (lives semanais que ele cita)

## Transcrição completa

Disponível em `Transcrições/Transcrição — Aula 0 Boas-vindas.md`

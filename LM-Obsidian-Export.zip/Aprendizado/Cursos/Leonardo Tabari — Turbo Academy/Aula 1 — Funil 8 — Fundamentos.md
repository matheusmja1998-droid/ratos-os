---
tipo: aula
autor: Leonardo Tabari
curso: Funil 8
numero: 1
tema: Fundamentos do Funil 8 — Aquisição de leads a custo zero
fonte: PDF resumo oficial Turbo Academy (Julho 2025)
tags: [funil-8, low-ticket, roas, teoria-do-8, antifrágil, ltv]
---

# Aula 1 — Funil 8: Fundamentos

[[Leonardo Tabari — Índice]]

> Estratégia de aquisição de leads a custo zero com produtos low-ticket. O objetivo principal não é o lucro imediato, mas zerar o CPL construindo base de clientes qualificados a custo líquido nulo.

## Resumo executivo

O Funil 8 vende um produto de baixo valor (a partir de R$17) cuja receita cobre todos os custos de tráfego, taxas de plataforma e impostos. ROAS alvo aproximado: **1,2** (break-even). O cliente que paga, mesmo valor simbólico, é um lead ultra qualificado — já quebrou a barreira da primeira compra. O lucro real vem do LTV (esteira de produtos mid/high-ticket).

Aplica-se a infoprodutores, especialistas e negócios digitais que buscam escalar reduzindo risco financeiro.

## Conceitos fundamentais

- **Produto Low-Ticket** — porta de entrada da esteira. Não é pra lucrar, é pra converter prospect em cliente.
- **Aquisição a Custo Zero** — receita do low-ticket cobre tráfego + taxas + impostos. ROAS ~1,2.
- **Lead Ultra Qualificado** — cliente pagante > lead de isca gratuita. Já quebrou a barreira da compra.
- **LTV (Lifetime Value)** — verdadeiro lucro vem das vendas seguintes na esteira.
- **Teoria do Número 8** — soma dos algarismos do preço deve dar 8. Ex: R$17 (1+7), R$35 (3+5), R$53, R$62. O número 8 associa-se ao infinito/prosperidade e tem se mostrado eficaz nesse modelo.

## Origem do método

Desenvolvido a partir de testes com perpétuos e low-ticket buscando algo mais escalável. Inspirações:
- **João Pedro Angeloni** — dicas sobre ascensão na esteira
- **Ricardo Máxima** — demonstrou possibilidade de lucro e otimização de páginas
- **Russell Brunson** — base teórica de funis (DotCom Secrets, Expert Secrets)

## Principais dores que o método resolve

- Alto CPL em modelos tradicionais
- Baixo engajamento de leads gratuitos (não abrem e-mail, não comparecem)
- Dificuldade de escala com prejuízo
- Baixa conversão vendendo pra público frio
- Ciclo de fracassos com lançamentos/perpétuos/desafios sem consistência

## Causas dos erros comuns

- Mentalidade de fracasso — desistir nos primeiros obstáculos
- Foco no lucro imediato no low-ticket (descaracteriza a estratégia)
- Execução técnica deficiente (páginas, criativos, copy fracos)
- Falta de ciclo iterativo (testar → escalar → otimizar → repetir)
- Precificação inadequada (ignorar Teoria do 8 ou furar o teto)

## O que fazer

- Definir objetivo principal como **aquisição de leads a custo zero**
- Iniciar precificação em **R$17** pra validar demanda com baixo risco
- Aplicar Teoria do 8 em todos os preços de entrada
- Focar em ROAS 1,2 (break-even após taxas e impostos)
- Adotar ciclo: aplicar, errar rápido, corrigir rápido, escalar
- Mentalidade antifrágil — erros como parte do processo
- Planejar a esteira pra monetizar no LTV

## O que NÃO fazer

- Não buscar lucro expressivo no produto de entrada (compromete escala)
- Não desistir no primeiro obstáculo
- Não ignorar CAC e ROAS
- Não escalar tráfego antes de otimizar conversão
- Não subir preço acima de R$62 abruptamente (conversão cai)

## Escala em patamares

- **R$17** (1+7=8) → validação inicial, menor risco
- **R$35** (3+5=8) → primeira escala, melhora margem
- **R$62** (6+2=8) → escala avançada, teto antes da queda drástica

## Ferramentas recomendadas

- Plataformas de Ads: Meta, Google
- Construtores de página
- Checkout: Hotmart, Kiwify, Eduzz
- E-mail marketing pra nutrir

## Exemplo de diagnóstico

- ROAS 0,5 (R$25 receita / R$50 CAC) → pausar, prejuízo de 50%
- ROAS 1,25 (R$25 / R$20) → saudável, candidato a escala

## Glossário

- **ROAS** — Return on Ad Spend (Receita / Custo)
- **CAC** — Custo de Aquisição de Cliente
- **LTV** — Lifetime Value
- **Antifrágil** — sistemas que se beneficiam de choques, volatilidade e erros (Nassim Taleb)

## Leituras complementares

- *DotCom Secrets* / *Expert Secrets* — Russell Brunson
- *Antifrágil* — Nassim Nicholas Taleb

## Links relacionados

- [[Aula 0 — Funil 8 — Boas-vindas]]
- [[Aula 4 — Funil 8 — Otimizando resultados]]
- [[Funil 8 em 1 semana — Implementação rápida]]
- [[Segredo ROAS 5X — Aula 1 (Funil 8)]]

---
tipo: aula
autor: Leonardo Tabari
curso: Segredo do ROAS 5X
numero: 20
tema: Pesquisa estratégica com leads e alunos pra aumentar faturamento
fonte: PDF resumo oficial Turbo Academy
tags: [pesquisa, avatar, copy, níveis-consciência, segmentação]
---

# Aula 20 — Pesquisa com Leads e Alunos

[[Leonardo Tabari — Índice]]

> Pesquisa estratégica é a base pra criar ofertas, conteúdos e campanhas. Entender o público profundamente personaliza ações e maximiza conversão. Entrega até 90% dos insumos pra campanhas de sucesso.

## Conceitos

- **Pesquisa Estratégica** — coleta e análise pra orientar produto, copy, criativos, campanhas
- **Lead/Avatar** — cliente ideal com dores, desejos, objeções
- **Personalização** — adaptar perguntas e análise por nicho/produto/nível de consciência
- **Níveis de Consciência** — boca, meio, fundo de funil

## Analogias

- Pesquisa é mapa — sem ela, navega no escuro guiado por achismo
- Copy sem pesquisa é receita sem ingrediente — pode sair algo, mas não o melhor

## Dores comuns

- Achismo na criação de produtos e campanhas
- Pesquisa genérica não personalizada
- Não analisar resultados
- Baixa taxa de resposta
- Desconhecimento do nível de consciência

## Causas dos erros

- Copia e cola sem contexto
- Perguntas fechadas (sim/não) sem insight
- Não segmentar (comprador, não comprador, lead)
- Sem incentivo pra responder
- Sem análise estruturada
- Ignorar variações de linguagem no mesmo nicho

## Métodos

- **Estruturação** — objetivo + público-alvo + perguntas-chave
- **Momentos estratégicos** — página de obrigado, onboarding, WhatsApp, e-mail de boas-vindas
- **Segmentação** — separar pesquisa por comprador / não comprador / lead
- **Incentivo** — bônus, materiais exclusivos, sorteios
- **Análise profunda** — planilhas, mapas de palavras, IA pra extrair insights
- **Aplicar respostas reais** — headlines, anúncios, produtos baseados na linguagem do público

## Framework de perguntas-chave

### 1. Descoberta de dores
- Qual sua maior frustração?
- O que mais te incomoda ao tentar [ação]?
- Complete: "Eu ficaria feliz se não tivesse que..."

### 2. Mapeamento de linguagem
- Como você descreveria seu problema pra um amigo?
- Que palavras você usa pra falar disso?

### 3. Validação de oferta/preço
- Quanto investiria pra resolver [problema]?
- Qual formato de solução faz mais sentido?

### 4. Objeções ocultas
- O que te impediu de resolver até hoje?
- Qual seu maior medo em relação à solução?

### 5. Gatilho de compra
- O que te faria decidir hoje?
- Como sua vida mudaria se resolvesse em 30 dias?

## O que fazer

- Personalizar perguntas por nicho/produto/público
- Aplicar em momentos de alta atenção (pós-inscrição, onboarding)
- Incentivar respostas
- Organizar em planilhas
- Usar respostas reais na copy
- Revisar pesquisas periodicamente
- Segmentar por nível de consciência

## O que NÃO fazer

- Perguntas genéricas irrelevantes
- Copiar modelos sem adaptar
- Pesquisas longas e cansativas
- Ignorar análise
- Não dar incentivo
- Misturar públicos diferentes
- Decidir só por achismo

## Ferramentas

Google Forms, Typeform, WordPress Forms, N8N, Google Sheets, IA (ChatGPT, Turbo IA)

## Exemplos práticos

### Emagrecimento
- P: "Qual sua maior frustração ao tentar emagrecer?"
- R comum: "Não consigo usar roupas antigas"
- Copy: "Cansada de evitar festas porque nada serve no armário? Descubra como voltar a usar aquele vestido que você amava."
- Oferta: "Programa de 14 dias pra voltar a usar aquele vestido"

### Compradores
- P: "O que fez você comprar o produto X?"
- R: "Queria solução rápida pra aumentar faturamento"
- Copy: "Acelere seus resultados e aumente faturamento em semanas"

### Não compradores
- P: "O que te impediu de comprar?"
- R: "Comprei cursos antes e me decepcionei"
- Copy: "Mentoria com acompanhamento personalizado pra garantir sua transformação"

### Incentivo
- "Responda a pesquisa e concorra a kit exclusivo / receba e-book grátis"

### Por nível de consciência
- **Boca:** "Você sente que precisa melhorar resultados mas não sabe por onde começar?"
- **Meio:** "Qual seu maior desafio pra escalar o negócio?"
- **Fundo:** "O que te faria decidir investir hoje?"

## Leituras

- *Breakthrough Advertising* — Eugene Schwartz
- *Ca$hvertising* — Drew Eric Whitman
- *Copywriting* — Paulo Maccedo
- *Influence* — Robert Cialdini

## Links

- [[Aula 19 — Distribuição C1 C2 C3]]
- [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]]
- [[Tráfego Aula 5 — Segmentações e públicos]]

---
tipo: aula
autor: Leonardo Tabari (apresentação de Vivendo de Dição)
curso: Inteligência Artificial para Criativos
tema: IA pra design e vídeo — Gamma, ElevenLabs, Gemini, Flow
fonte: PDF de apresentação (Turbo Academy)
tags: [ia, criativos, gamma, elevenlabs, gemini, flow, voice-cloning]
---

# IA para Criativos — Gamma, ElevenLabs, Flow

[[Leonardo Tabari — Índice]]

> Ferramentas e técnicas pra acelerar produção de design e vídeo com IA. Material apresentado por @vivendodedicao na Turbo Academy.

## O que cobre

1. **Gamma.app** — design com IA pra criativos rápidos
2. **Ferramentas de vídeo com IA** — gerar variações de criativo em vídeo, ganchos com voz clonada e imagens de apoio, conteúdos de humor leve/viral

---

## Criativos de design — Gamma.app

**O que é:** ferramenta de design com IA pra apresentações, posts e criativos.

**Case Bruno Reis:**

### Low-ticket 1 — Produto de Adesão
- Criativos 100% Gamma → 49 testes
- Dos 49: **12 validados em escala**, apenas 6 invalidados

### Low-ticket 2 — Produto de Fotografia Odontológica
- Criativos Gamma **mais validados que Photoshop**
- Atualmente **>70% dos criativos** desse produto são Gamma
- Resultados melhores que criativos super-produzidos no Photoshop/Figma
- **Gasta menos tempo, resultado melhor**

---

## Criativos em vídeo — ElevenLabs + imagens de apoio

**Conceito:** voice cloning com IA pra gerar novos ganchos sem regravar.

### Processo (3 passos)
1. Escrever novo gancho pra um criativo já gravado
2. Clonar a voz do expert no **ElevenLabs**
3. Usar imagens de apoio sobre o voice-over no novo gancho

### Opções de imagem
- Banco de vídeo (Pexels, Pixabay, Mixkit)
- Vídeos gerados na IA do Google
- Hooks virais
- Cenas famosas de filme
- Pautas em alta
- Modelo VSL só com letterings + fundo sólido
- Criatividade manda

### Sites e ferramentas
- **Clonar voz** — https://elevenlabs.io/
- **Gerar vídeos com IA** — https://labs.google/fx/pt/tools/flow + https://gemini.google.com/app?hl=pt-BR
- **Hooks virais** — https://transitionalhooks.com/social-media-video-hook-library/13/
- **Banco de vídeo** — Pexels, Pixabay, Mixkit

---

## Conteúdos de humor com IA

Criação de vídeos curtos com personagens gerados por IA.

### Como ter coerência nas cenas
Use a **mesma descrição de cenário e personagens** em cada geração.

- **Cenário** — descreva detalhadamente o ambiente
- **Personagens** — idade, roupas, cabelo, expressões
- **Ações claras** — o que está acontecendo
- **Prompts** — 1 prompt por cena, mas sempre com os mesmos padrões

### Exemplo (conversa de podcast 2 pessoas)

**Cenário base e personagens:**

> Estúdio de podcast moderno, mesa de madeira clara, microfones grandes em braços articulados, luz LED rosa e azul ao fundo. Ambiente limpo, jovem, estilo entrevistas virais.

> Personagem 1 — Nutricionista: mulher 37 anos brasileira, cabelo liso loiro preso em rabo de cavalo, jaleco branco, expressão confiante e empática.

> Personagem 2 — Paciente: mulher 42 anos brasileira, bem acima do peso, cabelos castanhos cacheados presos em coque, blusa rosa. Expressão sincera e um pouco dramática.

**Cena 1 (nutricionista):** "Mas você tem mesmo feito o jejum do jeito certo?"

**Cena 2 (paciente):** "Eu juro, faço jejum todo dia e não emagreço"

**Cena 3 (nutricionista pega caixa de pizza):** "Ó chegou a pizza, quer um pedaço?"

**Cena 4 (paciente em silêncio com fatia em cada mão):** sem fala

> Repete cenário + personagem completo em cada prompt pra IA manter coerência visual entre cenas.

---

## Resumo das ferramentas

| Ferramenta | Uso |
|---|---|
| **Gamma** | Criativos design rápido |
| **ElevenLabs** | Clonar voz |
| **Gemini + Flow** | Gerar vídeos com IA |
| **Sites de hooks** | Memes e humor |
| **Bancos genéricos** | Pexels, Pixabay, Mixkit |

## Dúvidas

@vivendodedicao

## Links

- [[Aula 5 — Funil 8 — Acelerar com IA Copy Turbo]] (Copy Turbo + ferramentas de design)
- [[Aula 4 — Funil 8 — Otimizando resultados]] (produção de criativo em volume)
- [[Funil 8 em 1 semana — Implementação rápida]] (10–20 criativos por campanha)

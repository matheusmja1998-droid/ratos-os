---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 381
tema: Meta Ads — Formulário nativo (Lead Ad) passo a passo completo
status: completa
tags: [tráfego-pago, meta-ads, lead-ad, formulário-nativo, sobral, lead-scoring, lógica-condicional, mit-lead-response, integração, públicos-quentes]
---

# Live #381 — Como criar campanhas de formulário nativo no Meta Ads

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 381]]

> O passo a passo completo da campanha mais subestimada pelos iniciantes (e mais usada pelos avançados). 7 pontos cobertos.

---

## Big Idea

**Cada contato vale dinheiro mensurável.** Lead Ad é a campanha de mensagem mais subestimada. Os avançados usam e abusam.

> "Cada contato é R$X no meu bolso. Só consigo sacar quando tenho todos."

A diferença entre Lead Ad que funciona e Lead Ad que queima dinheiro:
1. **Qualificar via perguntas** (lead scoring na origem)
2. **Velocidade do contato** (pesquisa MIT — cada minuto destrói valor)
3. **Lógica condicional** pra fechar formulário pra leads errados
4. **Encerramento** que reduz o tempo de primeiro contato

---

## OS 7 PONTOS DA AULA

1. O que são formulários nativos / instantâneos
2. Quando usar
3. Vantagens e desvantagens
4. Como criar o formulário (10 etapas)
5. Como criar a campanha em si
6. Metas de desempenho (assunto que pouca gente fala)
7. Pra quais públicos anunciar

---

## 1. O QUE SÃO FORMULÁRIOS NATIVOS

Formulário que abre **dentro do próprio Facebook/Instagram/WhatsApp** quando a pessoa clica no anúncio. Sem sair do app, sem precisar de site.

A Meta **pré-preenche** os campos (nome, email, telefone) com os dados da conta. Atrito mínimo.

**Por que contato vale tanto?**

100 contatos × taxa de conversão 1% × ticket R$10k = R$10.000 → **R$100/contato no bolso**.

2 métricas-rei:
- **Número de leads** (volume)
- **Taxa de conversão da lista** (qualidade)

---

## 2. QUANDO USAR LEAD AD

4 situações:

### A) B2C com ticket médio alto + comercial ativo
B2C = pra consumidor final. Ticket alto. Comercial ativo = time que liga rápido.

**Nichos**: clínicas (emagrecimento, médicas, plásticas), academia, yoga, imobiliária, arquitetura/design de ambientes, móvel sob medida, consórcio, plano de saúde, escola particular, associações de empresa, agência de modelo, **negócios fora do Brasil**.

### B) B2B onde precisa de dados antes do contato
Você precisa qualificar empresa antes do vendedor ligar.

### C) Substituir LP quando já capta leads
Testa Lead Ad em paralelo à LP. Pode vencer.

### D) Lead Ad + LP simultaneamente
Opção nova. Meta decide quem mandar pra cada destino.

---

## 3. VANTAGENS E DESVANTAGENS

### 3 vantagens
1. **Menos resistência** — não sai do app
2. **Tendência a maior volume** que LP
3. **Não precisa de página/site**

### Desvantagens

**1. Pode trazer lead menos qualificado** (atrito menor = entra gente sem pensar)

Exemplo da qualificação: 3 personas do mesmo cadastro:
- Dona Josefa, 74, sem contato com internet → menor potencial
- Maria, social media frustrada com clientes ruins → médio
- Mário, aspirante a gestor, consumiu todos os conteúdos grátis → maior

**Lead qualificado** = mais propensão de compra. Mede-se na **taxa de conversão**. Trazer pessoas ruins faz cair de 1% pra 0,5%.

**2. Leads ficam em planilha da Meta** — você precisa acessar manualmente ou ter automação.

**3. ⭐ Velocidade de contato é crítica — Pesquisa MIT (Lead Response Study)**

A cada minuto que passa, valor do lead diminui:
| Tempo de espera | Multiplicador de conversão |
|---|---|
| **1 minuto** | **391% mais conversão** |
| **5 minutos** | 21× mais chances de qualificar |
| **10 minutos** | cai pra 80% |
| **30 minutos** | **100× mais difícil** fechar contato |

> "Às vezes o cliente reclama 'lead tá desqualificado' — não é o lead. É ELE que tá demorando pra ligar. Isso mata o lead."

---

## 4. COMO CRIAR O FORMULÁRIO (10 ETAPAS)

### Lógica geral
- **Mais etapas** = lead **mais caro** mas pode ser mais qualificado
- **Menos etapas** = lead mais barato mas pode ser menos qualificado
- Lead só conta quando vai até o final

### Acesso
Meta Business Suite → Todas as ferramentas → **Formulários instantâneos** → Criar.

### 4.1 Tipo de formulário (3 tipos)

| Tipo | Quando usar |
|---|---|
| **Maior volume** ⭐ | Use quase sempre primeiro. Lead mais barato. |
| **Maior intenção** | Adiciona etapa de confirmação dos dados. Lead mais caro mas mais qualificado. Use se "tô com volume mas qualidade ruim". |
| **Criativo avançado** | "Meio bosta". Simula LP (depoimento, benefícios, produtos). Vale testar pra **e-commerce**. |

### 4.2 Entrega flexível
Meta varia elementos do formulário. **Só faz sentido se Maior Intenção ou Criativo Avançado.** Não exclui perguntas — só reordena, troca imagem, pula intro.

**Dica**: roda 2 formulários paralelos (com e sem), mantém o vencedor.

### 4.3 Apresentação (imagem + saudação)
- **Imagem de fundo**: opcional, pouco impacta. Se ficar feia replicada, desativa.
- **Saudação**: etapa extra (encarece lead). Só usa em 2 cenários:
  1. Lead muito desqualificado → saudação como filtro
  2. Muita abertura sem preenchimento → saudação como persuasão ("Preencha pra X transformação")

### 4.4 PERGUNTAS ⭐ (etapa-chave de qualificação)

**A etapa mais importante.** Mais perguntas = lead mais caro MAS qualifica.

> "Você nunca vai encontrar na internet uma explicação de lead scoring mais simples do que essa: é você atribuir nota ao lead com base nas respostas."

**Conceito de Lead Scoring**: cada resposta dá uma nota ao lead. Quem responde "tem ensino superior + 5k+/mês de orçamento + quer comprar agora" tem score alto.

**Tipos de pergunta**:
- Múltipla escolha (mais usado)
- Resposta curta
- Hora marcada (raramente usado)

### Lógica condicional (SEMPRE ATIVAR) ⭐⭐

Permite **fechar o formulário** se a pessoa responde algo que descalifica.

**Exemplo carro**:
- "Quer carro novo, usado, novo ou usado, ou não decidiu?"
- Vendo carro novo → "usado" = **FECHAR formulário**

Por quê?
1. Se você não vende usado, lead não te serve.
2. Mais importante: ao fechar, **a Meta entende que esse perfil não conta como conversão → para de buscar gente parecida**.

> "A Meta sabe mais de você do que você. Não duvide do poder da Meta."

**Tipos de pergunta de qualificação:**
- **Orçamento**: "Quanto pretende gastar?" (30k/50k/100k+)
- **Linha do tempo**: "Quando pretende comprar?"
- **Necessidade**: "Quer carro novo ou usado?"
- **Hábitos**: "Com que frequência você compra X?"

**Quando usar perguntas**:
- Quando precisa classificar/qualificar leads
- Quando o comercial precisa das respostas pra qualificar OU pra direcionar pro time certo (ex: time que vende usado vs novo)

### O exemplo do Seu Roberto (vendedor de carro)

Seu Roberto preenche: **cidade=Itupeva, carro=usado, orçamento=R$50k**

Vendedor liga em 1 minuto: "Alô, Seu Roberto. Vi que você é de Itupeva — tenho um primo aí. Vou direto ao ponto: você tá buscando usado na faixa de R$50k. Eu tenho o seu carro aqui. Não sei como já não levaram. Posso levar o carro na sua casa? Vi seu endereço (Fernão Dias 312). Consigo hoje no final do dia. Funciona?"

> "Aqui se eu fosse vendedor de carro era só na jugular do Seu Roberto."

> "90% dos gestores não sabe fazer essa configuração com lógica condicional. Garanto."

### 4.5 Informações de contato
Campos que fazem sentido **pro comercial qualificar**:
- Nome, email, telefone (obrigatório quase sempre)
- Cidade, estado (se for negócio local)
- Outros (data de nascimento, etc) — **só se for usar**, senão é etapa morta

**Dica**: campos opcionais sempre no final.

### 4.6 Política de privacidade (obrigatória)
3 caminhos:
1. **Ideal**: advogado escreve
2. **Aceitável**: pega referência + ChatGPT adapta
3. **Mínimo**: política genérica da internet

### 4.7 Avisos personalizados
Só se o nicho exige consentimento. Quase ninguém usa.

### 4.8 Encerramento ⭐ (esquecido pela maioria)

Texto final + botão. **Aqui é onde você diminui drasticamente o tempo do primeiro contato.**

**Truque do Gabriel Casagrande** (top gestor): texto do botão = "**Pule a fila do WhatsApp**". Todo mundo gosta de pular fila → mais cliques → contato instantâneo.

**4 opções de ação final:**
1. **Visitar site** (LP)
2. **Ver arquivo** (PDF, ebook)
3. **Ligar pra empresa** — pessoa liga direto (zera o tempo de resposta)
4. **Conversar no WhatsApp** (precisa ter WhatsApp vinculado à conta)

**Opção adicional: Conectar leads ao Messenger** — checkbox "Receba updates + comece conversa no Messenger". Vale teste mas encarece. Não começaria por aí.

---

## 5. CRIANDO A CAMPANHA

### Diferença pra qualquer outra campanha
Toda a criação é igual à live 366 (que ensina criar campanha do zero). Só duas grandes diferenças:

**Diferença 1 — Objetivo**: selecionar **Leads** na hora de criar.

**Diferença 2 — Local da conversão** (na etapa do conjunto de anúncio):
- **"Formulários no site e instantâneos"** = ativa LP + Lead Ad simultâneo (opção D que mencionou no início)
- **"Formulário instantâneo"** = só Lead Ad ⭐ (escolha padrão)
- A opção com Messenger Sobral não gosta

Depois aceita os termos e condições da Meta.

---

## 6. META DE DESEMPENHO ⭐ (o ponto que vale ouro)

Selecionar uma das 2 opções afeta MUITO o custo do lead. Sobral gastou **R$60k do próprio bolso** testando.

### Opção 1 — Maximizar número de leads
Mais volume, **possivelmente menos qualidade**.

### Opção 2 — Maximizar número de leads convertidos
Menos volume mas **leads mais qualificados** (potencial de compra maior).

### O teste de R$60k do Sobral

| Métrica | Maximizar leads | Maximizar convertidos |
|---|---|---|
| Custo por cadastro | R$ 2 | R$ 3,30 |
| Volume de cadastros | 16.000 | ~8.000 |

**Análise**: parece que "convertidos" entrega leads mais qualificados, mas **na prática o volume compensa**.

> "100 leads que converte 10% → 10 conversões. 10.000 leads que converte 5% → 500 conversões. O que é melhor?"

### Recomendação prática
- **Começa com "Maximizar número de leads"**
- Se descobrir que tem **leads desqualificados** → primeira coisa, **antes de mexer no formulário**, muda pra "Maximizar número de leads convertidos"

---

## 7. PÚBLICOS

### O básico
- Mesma estrutura da aula de criação de campanha
- Aulas referenciadas: criação de campanha + públicos (linkadas na descrição)

### Públicos quentes (criar lá em Públicos → Criar público personalizado → Formulário de lead)

Janela: até 90 dias. Anuncia pra:
- **Pessoas que abriram MAS não enviaram** o formulário ⭐
- **Pessoas que abriram E enviaram** (lookalike + remarketing pra vender mais)
- Pessoas que se envolveram com seu perfil
- Pessoas que cadastraram em outros formulários/páginas suas
- Pessoas que visitaram seu site
- Listas de email/telefone

### Públicos frios
- **Lookalike** (semelhantes a clientes/lead/engajamento)
- **Interesses** (direcionamento detalhado)
- **Aberto Advantage+**
- **Geolocalizado** (negócio local)

---

## Integrações (depois que rodar)

Os leads ficam armazenados na Meta. Pode baixar manualmente OU integrar com:
- **Google Sheets** ⭐ (recomendação do Sobral — mais fácil, planilha compartilhada com cliente)
- **Gmail**
- **Active Campaign** (o que a agência do Sobral usa)
- Outras ferramentas via integração nativa

---

## Palavra-chave da aula: **pai** ("eu fui um pai de entregar essa aula")

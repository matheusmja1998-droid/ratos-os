---
tipo: índice
autor: Pedro Sobral
canal: Subido
tags: [sobral, índice, tráfego-pago]
---

# Pedro Sobral — Lives do Canal Subido

Lives ao vivo toda terça-feira às 15h. Conteúdo central: tráfego pago, gestão de tráfego, anúncios online e como ganhar dinheiro com isso.

Canal: **Subido** (lives + tráfego) | **Pedro Sobral** (vlogs pessoais)

---

## Lives processadas

### Google Ads

| # | Tema | Link |
|---|------|------|
| 315 | Como criar campanhas no Google Ads em 2025 (passo a passo) | [[Live 315 — Como criar campanhas no Google Ads em 2025]] |
| 323 | Segmentações, públicos e palavras-chave no Google Ads | [[Live 323 — Segmentações, públicos e palavras-chave no Google Ads]] |
| 365 | Google Ads 2026 — Como anunciar (10 passos) | [[Live 365 — Google Ads 2026 — Como anunciar]] |

### Meta Ads / WhatsApp / Lead Ad

| # | Tema | Link |
|---|------|------|
| 367 | Como segmentar seus anúncios — Guia definitivo (7 formas) | [[Live 367 — Como segmentar seus anúncios — Guia definitivo]] |
| 375 | Campanhas de WhatsApp para negócios locais | [[Live 375 — Campanhas de WhatsApp para negócios locais]] |
| 381 | Formulário nativo (Lead Ad) — passo a passo completo | [[Live 381 — Campanhas de formulário nativo no Meta Ads]] |
| 382 | 10k seguidores reais em 60 dias (turbinar + Meta Business Suite) | [[Live 382 — 10.000 seguidores reais em 60 dias]] |

### Estratégia / IA / Carreira

| # | Tema | Link |
|---|------|------|
| 346 | Como começar no tráfego pago (5 passos, MCV, salário-base) | [[Live 346 — Como começar no tráfego pago]] |
| 361 | Andrômeda, Pmax e Advantage+ — IA das fontes de tráfego | [[Live 361 — Andromeda, Pmax e Advantage+ — IA das fontes de tráfego]] |
| 374 | Estratégias de tráfego para negócios locais em 2026 | [[Live 374 — Estratégias de tráfego para negócios locais em 2026]] |
| 383 | Futuro do trabalho digital com IA — 7 verdades | [[Live 383 — Futuro do trabalho no digital com IA]] |

### Comercial / Onboarding / Operação

| # | Tema | Link |
|---|------|------|
| 333 | Onboarding de clientes — 3 ligações + checklist (PDF oficial) | [[Live 333 — Onboarding de clientes — Tutorial à prova de falhas]] |

### Copywriting

| # | Tema | Link |
|---|------|------|
| 372 | Copy pra Gestores de Tráfego — Parte I (Cop + Público + Anúncios) | [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]] |
| 373 | Copy pra Gestores de Tráfego — Parte II (20 pilares de uma boa LP) | [[Live 373 — Copywriting para Gestores de Tráfego (Parte II)]] |

---

## Frameworks recorrentes do Sobral

### Visão de mercado / Estratégia
- **Paradoxo de Jevons** — tecnologia que barateia uma habilidade expande o mercado dela. (L383)
- **AI Blindness** — analogia com banner blindness; público vai ignorar conteúdo com cara de IA. (L383)
- **Pirâmide de Maslow dos negócios** — base = tráfego. Sem fluxo de pessoas, não há negócio. (L383, L382)
- **"O que permanece?"** — antes de "o que muda?", perguntar o que segue igual. (L383)
- **Permaneo** — nome da empresa do Sobral (latim "permanecer"). Superpoder está em permanecer no mesmo lugar enquanto outros mudam de nicho.

### Tráfego pago — Estrutura geral
- **3 níveis hierárquicos** (Campanha → Conjunto de Anúncio → Anúncio). Pasta dentro de pasta dentro de pasta. (L315, L323)
- **Campanha define POR QUÊ e QUANTO** + **Conjunto define PARA QUEM e ONDE** + **Anúncio define O QUÊ**. (L323)

### Tráfego pago — Filosofia
- **"Anunciar = anúncio certo + pessoa certa + momento certo + destino certo"** — fórmula de 4 elementos. (L367)
- **Pago e Orgânico se retroalimentam** — não é dilema. (L382)
- **Frequência + tempo de tela aumentam conversão**. 1 live = 7%, 2 = 10%, 3 = 11-12%. (L382)
- **Colher × Plantar** — Colher = vender. Plantar = atrair audiência (escala). (L382, L374)
- **Gangorra do controle** — saber tráfego em 2026 = saber quanto deixa a ferramenta controlar e quando você toma de volta. (L367)
- **A confusão é o primeiro estágio do entendimento** — quando o iniciante diz "tô perdido", isso é normal.
- **MCV (Menor Conhecimento Viável)** — em vez de MVP, o gestor que começa precisa só do mínimo pra fechar primeiro cliente. (L346)

### Google Ads
- **Lógica do bolo de cenoura fofinho** — palavra-chave pesquisada = aparece no anúncio = aparece no site. (L315)
- **4 quadrantes do Google** — Pesquisa institucional + YouTube + Display (remarketing) + Pmax. (L365)
- **3 correspondências de palavra-chave** — Ampla / Frase / Exata. Pra começar usa Frase + Exata. (L315, L323)
- **3 funções das palavras-chave** (a maioria conhece só 1) — aparecer na pesquisa + em conteúdos com a palavra (YouTube) + pra quem já pesquisou no Google. (L323)
- **AnswerThePublic + Also Asked + Planejador do Google** = pipeline pra montar lista de palavras-chave. (L315, L323)
- **Lista de palavras-chave negativas** — barato, grátis, planilha, modelo, exemplo, como, o que, currículo, sobre, comparação, etc. (L323)
- **Localização "Presença" vs "Interesse"** — sempre Presença pra negócio local (senão aparece pra quem só pesquisou a cidade). (L365)
- **Performance Max é "sugestão de segmentação", não segmentação** — você dá pistas, Google decide. (L361, L365)
- **Pra Pmax: bom pra e-commerce + visitas locais. Ruim pra leads (lead lixo).** (L361, L365)

### Meta — Recursos Advantage+
- **Orçamento Advantage (CBO)** — use em 99% dos casos. Meta decide quanto cada público gasta. (L361, L374)
- **Público Advantage** — bom pra escala. Ruim pra negócio local com região específica. (L361)
- **Direcionamento detalhado agora é SUGESTÃO, não segmentação** — ao adicionar interesse, vira Advantage Plus expandido. (L361, L367)
- **Posicionamento Advantage** — use 80% das vezes. Manual só pra anúncio específico OU qualificação de renda (só Instagram). (L361)
- **Criativo Advantage** — sempre desativar "automaticamente melhorar". Ainda ruim. (L361)

### Meta — Andrômeda (atualização 2024 que virou hype em 2025/26)
- **Recomendação de anúncios por conjunto saltou de 6 → 8-15**. (L361)
- **8-15 anúncios CONCEITUALMENTE distintos**, não variações cosméticas. (L361)
- Diversificar: formato + narrativa + gancho + ângulo + público implícito. (L361)
- Mesmo anúncio com camiseta diferente = Meta detecta similaridade e considera tudo como o mesmo. (L361)

### Copywriting
- **Cop ≠ Copyright** — Copy = "writing" = escrita persuasiva. Copyright = direitos autorais. (L372)
- **5 pilares de copy pro gestor** — entender copy + público + anúncio + página + promessa. (L372/L373)
- **Input antes do output** — antes de escrever bem, ler bem. (L372)
- **4 camadas do público alvo** — definições básicas + níveis de consciência + crenças + atenção. (L372)
- **5 níveis de consciência (Eugene Schwartz, Breakthrough Advertising)** — inconsciente → problema → solução → produto → totalmente consciente. (L372)
- **Crenças** — 3 maneiras de levantar: já viver / conversar com clientes / **Reddit via ChatGPT** (4 buscas: soluções + preconceitos + viabilidade + inviabilidade). (L372)
- **Camada Atenção** — pesquisar nicho no Instagram, ver reels mais virais = referências validadas. (L372)
- **5 elementos de um bom anúncio**: referências + camuflado/explícito + filtro (não ímã) + estrutura GCC + quantidade/qualidade. (L372)
- **Estrutura GCC** — Gancho + Corpo + CTA. Gancho é o 8/20. (L372)
- **3 tipos de gancho** — Falado + Escrito + Visual. **Nunca repetir o falado no escrito** (maior erro). (L372)
- **44% dos usuários do Instagram assistem sem som** — gancho escrito é essencial. (L372)
- **7 fatores de segmentação via copy** — Direta + Conhecimento + Ferramenta + Situação + Comportamento + Crença + Rotina. (L372)
- **Anúncio camuflado × explícito** — camuflado parece conteúdo orgânico (atrai nível baixo de consciência), explícito vende mais pra quem tá pronto. **Use os dois**. (L372)
- **Pipeline de extração de estrutura**: baixar anúncio (Ad Library Cloud) → transcrição visual com Gemini → agente do ChatGPT extrai estrutura → modelo editável. (L372)
- **20 pilares de uma boa LP** — referência, objetivo, público, headline, subheadline, dobra, botões em cada seção, benefício, preço/pagamento, garantias, depoimentos, quebra de objeções, quem somos, escassez, bônus, FAQ, contato, velocidade, comprimento, testes. (L373)
- **3 perguntas mágicas pra colher depoimento** — Como era a vida antes? / O que motivou a comprar? / Como ficou depois? (L373)
- **Maldição do conhecimento** (livro **Ideias que Colam**) — o que você acha óbvio um dia já não foi. Profissional bom esquece como é não saber. (L373)

### Lead Ad / Formulário nativo
- **Cada contato vale R$X** — vendas ÷ leads = valor por lead. (L381)
- **Mais etapa = lead mais caro mas mais qualificado.** Menos etapa = barato mas pode ser ruim. (L381)
- **Lead Scoring** — cada resposta dá nota ao lead. Comercial prioriza score alto. (L381)
- **Lógica condicional** — fechar formulário pra perfis que não convertem. Meta entende e para de buscar gente parecida. (L381)
- **Pesquisa MIT (Lead Response Study)** — 1min de demora = 391% mais conversão. 30min = 100× mais difícil. (L381)
- **Maximizar leads × Maximizar leads convertidos** — Sobral gastou R$60k testando. Começa com "maximizar leads"; se vier desqualificado, muda. (L381)

### WhatsApp / Negócio local
- **3 filtros de qualidade da mensagem** — objetivo + segmentação + anúncio. (L375)
- **CBO vs ABO** — começa CBO. ABO é controle manual de orçamento por público. (L375, L374)
- **Diário vs Total** — Total quando tem horário comercial. (L375)
- **Estratégia de ativação de WhatsApp antigos** — convidar contatos antigos pra "grupo VIP" + disparar oferta em 1 semana. **Gera resultado antes de gastar em ads.** (L375, L374)
- **Cliente Oculto** (Retroativo é o mais valioso) — analisar conversas antigas do cliente, gerar relatório, retém cliente. (L375)
- **19 Regras de Ouro do atendimento WhatsApp** — velocidade, ortografia, personalizar com nome, espelhamento, áudio cadenciado, Pix em mensagem separada, follow-up obrigatório, mensagens automáticas + respostas rápidas + etiquetas no WhatsApp Business. (L375)
- **Follow-up é o maior diferencial** — "não fazer follow-up é o maior motivo dos clientes perderem vendas". (L375)

### Segmentação (geral)
- **2 tipos no Google**: conteúdo (onde aparecer) + pessoas (pra quem aparecer). (L323)
- **10 maneiras de segmentar no Google Ads** — palavras-chave, canais/vídeos, temas, local, demográfico, afinidade, "no mercado + eventos importantes", seus dados, segmentos personalizados, combinados. (L323)
- **Segmentos personalizados são o ouro escondido** do YouTube — listas de URLs de canais/vídeos do concorrente, pesquisas no Google, sites navegados, apps no celular. (L323)
- **7 formas de segmentar (Meta)** — objetivo + automática (com/sem sugestão) + manual + manual de conteúdo + pixel/CAPI + interações passadas + **o próprio anúncio** (mais poderoso). (L367)
- **Estratégia de público**: anúncio é a isca, segmentação é o lago, pixel torna o ímã da isca mais forte. (L367)
- **Públicos super quentes > quentes > frios** — sempre testar nessa ordem. (L367)

### Negócios locais
- **5 perguntas pra montar estratégia** — tipo de negócio + como clientes chegam + investimento + ticket médio + quem atende. (L374)
- **Google = ferramenta de INTENÇÃO. Meta = ferramenta de ATENÇÃO + RELAÇÃO.** (L374, L346)
- **Verba mínima recomendada**: R$1.200/mês. Abaixo, ainda funciona mas com menos resultado. (L374)
- **A profissão vai pro generalismo** — gestor que entrega só tráfego vai até R$10-15k/mês. Pra escalar tem que empilhar habilidades (CRM, dashboards, LP, automação). (L383, L374, L346)

### Carreira / Iniciante
- **Faturamento médio na comunidade Subido**: 1º mês R$1.523 | 1 ano R$10k | 3 anos R$23k | 5 anos R$30k. (L346)
- **Iniciante cobra R$300-500/mês por negócio local**. 10 contas → R$3-5k/mês. (L346)
- **Trabalhando pra agência**: R$100-200 por conta no operacional. 20 contas fácil. (L346)
- **Donos de agência com 100+ pessoas faturam R$100k/mês de mediana**. (L346)
- **A receita rápida**: encontrar o problema primeiro, buscar a resposta depois. Não acumular respostas antes. (L373)
- **Adquirir conhecimento + buscar cliente EM PARALELO**. Se hoje só estudou, errou. (L373)
- **Você nunca vai se sentir 100% pronto.** Aja apesar do medo. (L373)
- **Onde achar primeiro cliente**: seu WhatsApp + seus seguidores + seguidores dos amigos + pessoas que vendem serviço pra você. (L346)
- **Execução nasce da pressão, não da motivação**. (L346)

---

## Conexões com o ecossistema WinVision / L.M

Tudo que envolve tráfego nos meus negócios conecta aqui.

- [[../../../WinVision/WinVision — Visão Geral]]
- [[../../../LM/LM — Visão Geral|L.M Agência]]

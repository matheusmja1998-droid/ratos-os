---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 323
tema: Google Ads — Segmentações, públicos e palavras-chave
status: completa
tags: [tráfego-pago, google-ads, sobral, segmentação, públicos, palavras-chave, youtube-ads, remarketing]
---

# Live #323 — Segmentações, públicos e palavras-chave no Google Ads em 2025

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 323]]

> As 10 maneiras de segmentar no Google Ads, dividida em 2 grandes categorias (conteúdo vs pessoas).

---

## Big Idea

Quando você explora uma nova fonte de tráfego, a primeira coisa a fazer é entender as **estruturas**. No Google Ads tudo gira em torno de **3 níveis** (campanha → grupo de anúncio → anúncio) e o segmento sempre acontece no grupo de anúncio.

> "Segmentar nada mais é do que pegar um pedaço de público pra aparecer só pras pessoas mais interessantes."

No Google existem **2 grandes tipos de segmentação:**
1. **Conteúdo** — escolho ONDE vou aparecer (em qual vídeo, site, pesquisa)
2. **Pessoas** — escolho PARA QUEM vou aparecer (idade, interesse, comportamento)

> "Tão importante quanto escolher para quem anunciar é escolher para quem NÃO anunciar."

---

## As 10 maneiras de segmentar no Google Ads

### Segmentações de CONTEÚDO (1-3)
1. Palavras-chave
2. Canais e vídeos
3. Temas (tópicos)

### Segmentações de PESSOAS (4-10)
4. Local
5. Demográfico + demográfico detalhado
6. Afinidade
7. No mercado e eventos importantes
8. Como interagiram com sua empresa (segmentos dos seus dados)
9. Segmentos personalizados ⭐
10. Segmentos combinados

---

## 1. PALAVRAS-CHAVE ⭐

Escolher para quais pesquisas vou aparecer. Mas serve para **3 coisas** (a maioria só conhece a primeira):

1. **Aparecer na pesquisa do Google** quando a pessoa busca aquela palavra
2. **Aparecer em conteúdos que contêm aquelas palavras** (ex: YouTube identifica palavra dita no vídeo e mostra anúncio no mesmo momento)
3. **Aparecer pra pessoas que já fizeram aquela pesquisa antes** (a pessoa pesquisou "tráfego pago" segunda-feira, eu apareço pra ela no YouTube domingo) — esta é a mais poderosa

### Tipos de correspondência
- **Ampla** (`comprar geladeira`) — Google traz pesquisas semelhantes
- **Frase** (`"comprar geladeira"`) — pesquisa contém essas palavras nessa ordem
- **Exata** (`[comprar geladeira]`) — pesquisa exata

**Pra começar: frase e exata.** Ampla pode trazer pesquisas que viajam (ex: "comprar geladeira" → "comprar ar condicionado que gela").

### Como montar lista de palavras-chave
1. **Cabeça** — o que sua audiência pesquisa
2. **AnswerThePublic** — gratuita, formato "tables" é o melhor
3. **Also Asked** — perguntas que as pessoas fazem
4. **Planejador de palavras-chave do Google Ads** — volume + lance (gratuito)

### Dicas
- **PS1**: pra quem começa, quanto mais específico melhor. Palavras de intenção de compra: comprar, pedir, contratar, arrumar, consertar, técnico, especialista, orçamento, adquirir, agendar.
- **PS2**: monte uma **lista de palavras-chave negativas** (palavras pra NÃO aparecer):
  - sem custo, barato, por conta própria, econômica, caseira, grátis, gratuito, de graça, na faixa, consignado
  - template, planilha, modelo, exemplo
  - como, o que, por que, aonde, quando, qual
  - senha, login, carreira, emprego, contratação, estagiário, estágio, recrutador, currículo
  - sobre, definição, comparação, diagrama, exemplo, história, mapa, amostra, versão

---

## 2. CANAIS E VÍDEOS ⭐ (com truque escondido)

**Uso óbvio (todo mundo conhece):** escolher em quais vídeos/canais aparecer com anúncio.

**Uso escondido (segredinho):** criar **segmento personalizado** de pessoas que **já viram aqueles vídeos**. Por quê?

- Pra rastrear visitante de site, precisa de pixel. Pixel no Google = só seus sites.
- **Mas YouTube é do Google.** O Google sabe quem viu qualquer vídeo do YouTube.
- Você monta lista de URLs de vídeos de concorrentes → cria segmento personalizado com esses URLs → anuncia pra quem viu eles.
- "Tá na sua cara o tempo inteiro, e ninguém usa."

### Como montar a lista
- Concorrentes diretos (seu nicho)
- Não-concorrentes que sua audiência consome (ex: vídeos de motivação se seu público se interessa)
- Gaste **horas** mapeando. Salva URLs em planilha.

---

## 3. TEMAS (tópicos)

Segmentação de conteúdo. Anuncia em conteúdos que falam sobre um tema (não em pessoas com interesse no tema, mas conteúdos que falam dele).

Categorias: comunidades online, recursos de blog, emprego e educação, etc.

---

## 4. LOCAL

Países, estados, cidades, CEP (5 primeiros dígitos), endereço com raio, pin no mapa.

---

## 5. DEMOGRÁFICO + DEMOGRÁFICO DETALHADO

### Demográfico básico (no grupo de anúncio)
- **Gênero**: masculino, feminino, desconhecido (desconhecido = Google não identificou, tem todos os gêneros nele)
- **Idade**: faixas
- **Status parental**: com filho, sem filho, desconhecido
- **Renda familiar**:
  - 10% com maior renda = só o topo
  - 10% a 20% com maior renda = topo + faixa logo abaixo
  - 50% com maior renda = metade mais rica
  - 50% com menor renda = metade mais pobre (cuidado: somando "50% com maior" + "50% com menor" você pega o Brasil inteiro)

**Recomendação**: tirar "desconhecido" quando quer só um gênero/faixa específica.

### Demográfico detalhado
- Status parental detalhado: pais de bebês, criança pequena, pré-escolar, escolar, adolescentes
- Estado civil: solteiro, em relacionamento, casado
- Ensino: estudante universitário, ensino médio, bacharelado, graduação
- Proprietário ou aluga
- Setor de emprego: assistência, construção, educação, produção, tecnologia, financeiro, hoteleiro
- **Tamanho de empresa** (pra dono de empresa): pequeno, grande, muito grande

---

## 6. AFINIDADE

Pessoas com afinidade por temas. **Não estão pesquisando ativamente** — só têm interesse genérico.

Exemplos:
- Compradores: aficcionados por luxo, atentos a custo-benefício, caçadores de desconto
- Por tipo de loja: cliente de hipermercado, conveniência, departamento
- Viagem: aficcionado por viagem, viajante a negócios, viajante de luxo, para área litorânea, em família

---

## 7. NO MERCADO + EVENTOS IMPORTANTES

**No mercado** = pessoas **ativamente buscando** sobre o assunto. Muito específico. Exemplos:
- Conserto e manutenção de automóveis (até de câmbio, de freio)
- Currículos, empregos administrativos

**Eventos importantes** = mudanças de vida acontecendo:
- Vai adotar / adotou um cão ou gato
- Vai começar / começou novo emprego
- Vai reformar / reformou casa
- Vai casar / casou
- Vai se aposentar / aposentou

---

## 8. SEGMENTOS DOS SEUS DADOS (como interagiram com sua empresa) ⭐⭐

**Onde acessar:** Google Ads → Ferramentas → Biblioteca compartilhada → Gerenciador de público alvo.

6 tipos de segmento dos seus dados:

### a) Visitantes do site
Criar um para cada janela: 1, 2, 3, 7, 14, 30, 60, 90, 180, 365, 540 dias.

> **⚠️ Pixel tem memória curta.** Só lembra dos últimos 30 dias. Se você cria o público de 365 dias HOJE, ele só vai começar a coletar a partir de hoje. Por isso: **criar todos os públicos o quanto antes**, mesmo que você não vá usar agora.

Também: criar público de quem visitou uma **página específica** (refinar pela URL contendo certa palavra, ex: `/blog`).

### b) Usuários de aplicativo
Quem baixou o app, comprou no app. Mesma lógica de dias.

### c) Usuários do YouTube
Várias ações × várias janelas de dias:
- Viu qualquer vídeo
- Se inscreveu no canal
- Acessou a página do canal
- Curtiu vídeo
- Adicionou na playlist
- Compartilhou

Nome padrão: `yt_compartilhou_540d`, `yt_inscritos_30d`, etc.

### d) Lista de clientes
Upload de e-mails/telefones (planilha) ou conexão com Salesforce, Shopify, BigQuery, Google Sheets.

### e) Públicos do Google Analytics
Precisa ter GA conectado ao Ads. Permite criar públicos **preditivos** (avançado):
- Prováveis compradores nos próximos 7 dias
- Prováveis usuários inativos nos próximos 7 dias
- Preditivo a partir de comportamento no site (ex: pessoas que visitaram mais de 5 vezes nos últimos 30 dias)

### f) Combinação personalizada
Combinar públicos diferentes criados acima. Exemplo prático: público "envolvimento completo 7 dias" combinando todas as ações do YouTube nos últimos 7 dias.

### Insights de Dados (subitem importante)
Aba `seus insights de dados` → filtrar por um público criado → Google diz **quais outros públicos têm mais chance de funcionar pra você** (com índice de propensão).

Exemplo do Sobral: inscritos do canal 540d aparecem 16× mais propensos a estar no mercado de SEO/SEM.

---

## 9. SEGMENTOS PERSONALIZADOS ⭐⭐⭐ (o ouro escondido)

"Pro YouTube, é o ouro escondido."

4 maneiras de criar (no `Gerenciador de público alvo` → `Segmentos personalizados`):

### a) Intenção de compra / interesses
Lista de termos → Google traz pessoas com intenção/interesse naqueles temas.

### b) Termos que pesquisaram no Google
Lista de palavras-chave (exata ou frase) que a pessoa já pesquisou.

**Dica avançada Sobral**: rode campanha de pesquisa primeiro → descubra quais palavras mais convertem → pegue as **~75 palavras** que mais convertem → crie um segmento personalizado de pessoas que pesquisaram essas palavras. "É explosão."

### c) Sites navegados
Lista de URLs (ex: site do concorrente). Aparece pra quem navegou nesses sites.

### d) Aplicativos no celular
Lista de apps que a pessoa tem instalado.

Exemplos:
- Quer atingir empresário? Itaú Empresas, Santander Empresas, Conta Azul, app de CNPJ
- Quer atingir fotógrafo? Lightroom, Photoshop Express, Foto de [editor]

---

## 10. SEGMENTOS COMBINADOS

Misturar diferentes públicos. Sobral: "Nunca vi funcionar. Tem coisa pra testar antes."

---

## 7 Recomendações finais (subido pra cima)

1. **Campanha de pesquisa**: sempre anunciar com palavra-chave. Investir tempo na lista.

2. **Campanha local no YouTube**: testar anunciar **só pro local** (cidade/CEP). Funciona muito bem.

3. **Campanha de conversão no YouTube** — sempre testar anunciar pra:
   - Pessoas que já visitaram o site mas não converteram
   - **No mercado + eventos importantes** (performam melhor que afinidade)
   - **Não colocar mais de 4 segmentações por grupo de anúncio**
   - **Pessoas que já interagiram com você** (envolvimento completo: combinação personalizada com todas as ações do YouTube em uma janela). 540d e 730d são coringas.
   - **Segmentos personalizados** (pesquisas no Google, sites de concorrentes, apps, canais/vídeos do YouTube)

4. **Confia no poder do óbvio + fuçar e clicar**. Maior erro: não investir tempo abrindo cada menu de segmentação.

5. **Campanha de display**: 100% da energia em **remarketing** (quem já interagiu).

6. **Performance Max**: não é segmentação, é **sugestão de segmentação**. Foco em palavras-chave qualificadas (que geram vendas) + públicos do tipo do resultado que você quer (se quer comprador, sugere comprador). Avançado: usar Google Analytics preditivo.

7. **Teste constantemente.** "Larbos Ordep" (palavra-chave da live, lido de trás pra frente: Pedro Sobral) — "no jogo do tráfego pago ganha quem testa mais. A verdade só será encontrada no experimento do presente."

---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 315
tema: Google Ads — Criação de campanha passo a passo
status: completa
tags: [tráfego-pago, google-ads, sobral, rede-de-pesquisa, palavras-chave, tutorial]
---

# Live #315 — Como criar campanhas no Google Ads em 2025

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 315]]

> Tutorial passo a passo de criação de campanha do zero no Google Ads, focado em rede de pesquisa.

---

## Big Idea

O Google Ads parece assustador na primeira vez ("um novo idioma"), mas a criação de campanha é só uma sequência de **13 passos**. Tudo gira em torno da **"lógica do bolo de cenoura fofinho"**: a palavra-chave pesquisada precisa aparecer no anúncio que precisa aparecer no site de destino. Se você conecta os três, "zerou o jogo do tráfego no Google".

---

## Estrutura organizacional do Google Ads

3 níveis hierárquicos (uma coisa dentro da outra):

1. **Campanha** — define objetivo, rede e orçamento
2. **Conjunto de anúncio** — define palavras-chave (ou público alvo)
3. **Anúncio** — texto, imagem, links

### Nomenclatura recomendada
- **Campanha**: objetivo + data + identificação + rede (ex: `Vendas — 2025 — XYZ — Search`)
- **Conjunto de anúncio**: nome do grupo de palavras-chave ou público alvo
- **Anúncio**: `ad01 — descrição`

---

## Os 13 passos da criação de campanha

### 1. Objetivo de campanha
Opções: vendas, leads, tráfego, promoção de aplicativo, reconhecimento e consideração, visitas a lojas locais e promoções, campanha sem meta.

**Mais usados pra quem começa: Vendas e Leads.** Não muda nada na criação, só na escolha inicial.

Ignorar: visitas a lojas locais (raramente funciona bem) e sem meta.

### 2. Metas de conversão
O que você quer focar (compras, contatos, envio de formulário, etc). Remove o que não interessa. Pra venda → focar em compra.

### 3. Tipo de campanha (onde anunciar)
- **Search (rede de pesquisa)** — aparece quando a pessoa pesquisa no Google. Domina o topo da pesquisa.
- **Performance Max** — aparece em todos os lugares. Bom pra e-commerce na maioria dos casos, mas **precisa testar**. Pra leads vale o teste pra quem está escalando.
- **Geração de demanda** (YouTube + Discover + Gmail) — "lindo na teoria, nem tanto na prática". Vale o teste para escala.
- **Rede de display** — bom pra **remarketing** (aparecer pra quem já visitou o site mas não comprou).
- **Shopping** — bom pra remarketing de e-commerce na pesquisa, focado em lojas online.
- **Vídeo (YouTube)** — gerar inscritos, vendas, fazer conteúdos chegarem a mais pessoas.
- **Aplicativos** — aumentar downloads.

**Foco da aula: Search.** Gera contato/acesso mais qualificado porque a pessoa está pesquisando ativamente.

### 4. Como alcançar a meta
- Levar a pessoa pro site
- Fazer a pessoa ligar
- Fazer a pessoa visitar loja

Pra quem começa: **visita ao site** (precisa ter site ou Google Meu Negócio bem configurado).

### 5. Lances (qual métrica + quanto está disposto a pagar)
- Clique, conversão, valor da conversão
- Mais comum: clique ou conversão
- Custo por ação (CPA): quanto está disposto a pagar por conversão

**Lógica do lance:**
- Lance alto → aparece mais, paga mais caro por resultado
- Lance baixo → aparece menos, paga mais barato por resultado
- Lance de 1 centavo → não aparece pra ninguém

Otimizar pra aquisição de novos clientes: opção nova, pra maioria não faz diferença.

### 6. Redes
- **Parceiros da rede de pesquisa**: manter
- **Rede de display**: tirar (funciona melhor sem)

### 7. Locais (geolocalização)
- Todos os países / Brasil / inserir local
- Local pode ser: estado, cidade, CEP (5 primeiros dígitos)
- **Pesquisa avançada**: raio de X km
- **Modo alfinete**: pino no endereço + raio (ex: 1km em torno do negócio)

### 8. Idiomas
Sempre Português + Inglês + Espanhol.

### 9. Segmentos de público alvo
**Pular no começo.** "Só vai dar nó na sua cabeça."

### 10. Palavras-chave de correspondência ampla
**Desativar.** Funciona melhor desativado.

### 11. Recursos automáticos
**Desativar.** Funciona melhor desativado.

### 12. Outras configurações
- **Data de início e término**
- **Programação de anúncios**: dias e horários específicos (ex: seg-dom das 8h às 18h ou 24h)

### 13. Palavras-chave + anúncio (etapa pesada)

#### A LÓGICA DO BOLO DE CENOURA FOFINHO ⭐

Quando você pesquisa "bolo de cenoura fofinho" no Google, aparece bolo de cenoura fofinho como resultado, e o site é sobre bolo de cenoura fofinho. **Tudo conectado.**

No tráfego: a **palavra-chave pesquisada** = aparece no **anúncio** = aparece no **site de destino**. Se você conecta os 3, "zerou o jogo".

#### Tipos de correspondência de palavra-chave

| Correspondência | Como escreve | Quando aparece |
|---|---|---|
| **Ampla** | `curso de anúncios online` | A pessoa pesquisou termos semelhantes (Google decide o que é "semelhante"). Mais aberto. |
| **Frase** (aspas) | `"curso de anúncios online"` | Pesquisa contém **essas palavras nessa ordem** (com palavras antes/depois ok). Google ignora acento. |
| **Exata** (colchetes) | `[curso de anúncios online]` | Pesquisa é **exatamente** isso. Sem variações. |

**Recomendação Sobral pra quem começa: usar frase e exata.** Vão gerar resultado mais qualificado.

#### Como achar palavras-chave
- Cabeça/cérebro
- Ferramenta: **AnswerThePublic** (gratuita) — formato tables é o melhor
- Por nicho: aulas específicas de seleção de palavras-chave (referenciadas na live)

**Estrutura:** vários conjuntos de anúncio, cada um focado em UM grupo temático (ex: conjunto "gestor de tráfego" só tem palavras relacionadas a gestor de tráfego — não misturar com "meta ads"). Senão **perde a lógica do bolo de cenoura fofinho.**

**Quantidade**: entre 15-20 palavras-chave por conjunto.

#### Anúncio (configuração)

- **URL final**: site de destino
- **Caminho de exibição**: aparece no link visível (só estético)
- **Títulos**: preencher todos os possíveis (30 caracteres). Quanto mais, melhor — desde que **contenham a palavra-chave do conjunto**. Google testa qual converte mais.
- **Descrições**: 4 descrições com gatilho de persuasão / CTA
- **Recursos adicionais**:
  - Imagens (quadrada, retangular deitada, retangular em pé). Não é determinante.
  - Nome da empresa
  - Logotipo
  - **Site links** — sites extras que complementam (ex: "Conheça nossos estudos de caso", "Siga no Insta")
  - Promoções, preço, telefone, mensagem (WhatsApp) — bom pra negócio local
  - Frases de destaque
  - Snippets estruturados (comodidades, cursos, destinos, estilos — depende do negócio)

### Último passo — orçamento diário
Quanto gastar por dia. Google dá previsão de conversões.
- Lance R$30 → invista pelo menos R$30/dia
- Quanto mais aumenta o orçamento, mais conversões **mas o custo por conversão também sobe**.
- Princípio: "investe um valor que se der tudo errado, amanhã você tem mais."

---

## Encerramento — fluxo na prática

Depois de publicar, a campanha aparece no painel. Cada grupo de anúncio mostra:
- Palavras-chave temáticas (todas relacionadas a um único conceito)
- Anúncios com títulos contendo as palavras-chave
- Métricas (gasto, conversões, CPA)

Exemplo real Sobral: uma campanha gastou R$316k, gerou 126k conversões, CPA R$2,50.

> "É exatamente desse simples que você precisa para ter resultado."

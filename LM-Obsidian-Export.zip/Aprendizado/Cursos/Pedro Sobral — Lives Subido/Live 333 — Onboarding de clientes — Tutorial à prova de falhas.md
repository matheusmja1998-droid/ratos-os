---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 333
tema: Onboarding de clientes — 3 ligações + checklist
status: completa (fonte: PDF oficial da Comunidade Subido)
fonte: PDF oficial (não transcrição)
tags: [gestor-de-tráfego, onboarding, sobral, processo, briefing, kick-off, estratégia, expectativas, retenção-de-cliente]
---

# Live #333 — Onboarding de Clientes: tutorial à prova de falhas

[[Pedro Sobral — Índice de Lives]]

> ⚠️ Fonte: **PDF oficial da Comunidade Subido** (resumo curado, não transcrição literal). Original em `winvision/Upload transcricao/cst_live_333_onboarding_de_clientes_tutorial_a_prova_de_falhas.pdf`.

---

## Big Idea

Onboarding de cliente bem feito = **3 resultados que precisam acontecer ao mesmo tempo**:

1. **Alinhamento de expectativas** — "desvender" o serviço e deixar claro que o trabalho não é só seu. Cliente precisa saber o papel dele na parceria.
2. **Segurança** — postura que transmita confiança de que você sabe o que está fazendo.
3. **Encantamento** — o cliente sair com a sensação "Meu Deus, eu nunca vi isso antes!".

> "99% dos gestores está preocupado apenas com vender o serviço. Se o cliente não sair entendendo qual é o seu papel, não sair seguro de que você vai entregar, não sair encantado — você está a um passo de ser demitido ou de ouvir 'mas eu achava que você ia entregar isso também'."

---

## Estrutura: 3 ligações

| # | Ligação | O que é |
|---|---------|---------|
| 1 | **Briefing / Kick-off / Boas-vindas** | 60 min de alinhamento com o cliente |
| 2 | **Reunião interna** | Análise da conta + criação de estratégia (sem cliente) |
| 3 | **Apresentação da estratégia** | Mostra ao cliente o que foi analisado e o plano |

---

## 0. DEVER DE CASA (antes da Ligação 1)

> "A coisa mais óbvia que ninguém faz."

- Revisitar **anotações da ligação comercial** — dores e problemas que o cliente já levantou
- **Análise prévia** — coletar e estudar informações sobre o cliente

### Checklists de análise prévia

#### 1. ICP + Pesquisa de mercado
- Usar IA pra montar perfil de cliente ideal (ferramenta da Comunidade Subido, materiais da live 333)
- **Não delegar 100% pra IA**: ler o que ela retorna, validar, complementar
- ChatGPT com **Deep Research** (modo pensamento profundo, 15-20min) — mas com prompt bem feito, senão sai genérico
- Alternativa: **Manus.im** — transforma descrição em página funcional (HTML/CSS/JS). Útil quando precisa criar LP rápido pro cliente

> "Se você não quer que um robô roube seu trabalho, não faça o trabalho de um robô."

#### 2. Anúncios e sites
- Análise dos anúncios ativos na **Meta**
- Análise se a **landing page está alinhada com os anúncios** (lógica do bolo de cenoura fofinho)
- Análise dos anúncios ativos do **Google Ads**
- Análise da **velocidade de carregamento** das páginas (pagespeed.dev)
- Análise se o site é **mobile friendly**
- Análise de **tags instaladas** (Meta Pixel, Google, Analytics, GTM)
- **Cliente oculto** — fingir ser cliente do prospect e ver o atendimento

#### 3. Análise do perfil do Instagram
- Título do perfil
- Bio
- Link
- Seguidores
- Número de posts
- Curtidas
- Comentários
- Principais publicações
- **Publicações que podem virar anúncios** ⭐

#### 4. Análise do canal do YouTube (se o cliente é produtor de conteúdo)
- Thumbnails
- Títulos buscáveis ou que chamam atenção
- Imagem de capa do canal
- Informações de contato
- Link do botão

#### 5. Análise do Google Meu Negócio
- Nome da empresa
- Endereço, telefone, horário
- Site
- Foto de capa, fachada, produtos
- Resposta de avaliações
- Publicações frequentes
- Formas de contato
- Categorias

### Por que fazer essa análise prévia
Ajuda a saber **o que precisa ser discutido na reunião 1**:
- Precisa explicar que ele tem que postar conteúdo?
- Precisa explicar como preparar o Instagram pra receber tráfego pago?
- Precisa explicar como otimizar o site?
- Precisa explicar melhorias no atendimento?
- Precisa explicar importância de bio/destaques?
- Precisa explicar importância de pixel no site?

---

## LIGAÇÃO 1 — Briefing, Kick-off, Boas-vindas (60 min)

Reunião dividida em **6 partes**.

### Parte 1 — Explicação do seu trabalho na parceria

Listar exatamente o que o gestor entrega:
- Configurar as ferramentas **do cliente** (a conta é do cliente)
- Suporte
- Encontros semanais
- Grupo no WhatsApp (ex: 8h-17h, resposta em até 30min)
- Criação, análise e otimização diária dos anúncios e campanhas
- Entrega de relatórios (1 semanal + 1 mensal robusto)
- Consultoria pra criação de anúncios

### Quem é responsável por cada entrega
Mesmo que seja só você operando, apresentar os "papéis" demonstra organização:
- **Head de tráfego** — elabora estratégias
- **Gestor operacional** — operacionaliza
- **Head de projeto** — garante que operacional está conectado com demandas/prazos
- **Head de sucesso do cliente (CS)** — garante satisfação
- **Analista de sucesso do cliente** — antecipa dúvidas, propõe soluções rápidas

### Parte 2 — Erros no tráfego pago (onde a maioria erra)

Apresentar os erros comuns e mostrar **seu método** como diferencial:

**Erros:**
- Não ter um método claro
- Acreditar que tráfego faz milagre (NÃO é da noite pro dia)
- Acreditar que tráfego SÓ funciona com o gestor

**Apresentar seu método** (exemplo de 6 frentes):
1. Ferramentas
2. Audiência: distribuição de conteúdo
3. Anúncios: como fazer anúncios que convertem
4. Públicos essenciais e diversificação de fontes de tráfego
5. Pesquisa de audiência e mercado
6. Técnica 1234 de otimizar campanhas

### Qual é o papel do dono do negócio (e NÃO do gestor)

Deixar claro o que cabe ao cliente:
1. **Anúncios** (criar imagens/vídeos)
2. **Investimento**
3. **Páginas**
4. **Designer**
5. **Atendimento**
6. **Converter os leads**
7. **Mandar relatórios de venda**

### Parte 3 — Entendimento do negócio do cliente

⚠️ **Sem repetir perguntas já feitas no comercial ou no dever de casa.**

Perguntas pra coletar:
- Ticket médio
- Margem
- Quantas vendas nos últimos 12 meses?
- Faturamento dos últimos 12 meses
- Qual foi o melhor mês de vendas?
- Qual o produto "carro-chefe"?
- Preços, condições, frete grátis, descontos
- Os resultados são medidos? Como?
- Público-alvo
- Qual é a jornada do lead até o fechamento?
- Faz pesquisa com o cliente?
- Já anuncia? Quem produz/direciona criativos?
- Tem equipe? (Copy / Designer / Editor / Social Media)
- Quais dificuldades pra vender mais? Qual o gargalo?
- O que traz resultados? (WhatsApp / Formulário / LP)
- Como funciona a produção de conteúdo?
- Investimento atual em anúncios por plataforma

### Parte 4 — Expectativas do cliente

Onde o cliente quer chegar com a parceria:
- "Quais são suas expectativas?"
- "Como você definiria uma parceria de sucesso no próximo mês? E nos próximos 6 meses?"

### Parte 5 — Solicitações e envios de acesso

Estruturar e pedir:
- Criação do **grupo de WhatsApp**
- Envio da **pasta no Drive**
- Criação do **ClickUp**
- Criação das **planilhas de histórico** do cliente
- Criação da **pasta de criativos**
- Acesso às ferramentas: Google Ads, Meta, GTM, GA4, plataforma de vendas, Google Meu Negócio

**Regras:**
- **Prazo de 24h** depois da ligação 1 pro cliente enviar acessos
- Se ele não souber liberar, **crie tutorial** explicando passo a passo

### Parte 6 — Alinhamentos finais

- Periodicidade das reuniões
- Canal de comunicação padrão
- Informação/explicação sobre liberação de acessos
- Importância do **feedback mútuo** (informar sobre formulários de pesquisa de satisfação)

**Dica importante**: montar a apresentação em **slides (PowerPoint)** e **gravar a reunião**.

---

## LIGAÇÃO 2 — Reunião interna (sem cliente)

> "A análise de conta não precisa ser feita em reunião."

Entendimento dos erros e acertos do cliente + elaboração da estratégia:

### Análise do tráfego
- O que já funcionou
- O que já foi feito
- O que está certo
- O que está errado
- Melhores anúncios
- Melhores públicos
- Boas práticas

### Criação da estratégia
- O que será feito
- Quanto será investido
- Quais são as etapas do processo de venda
- Verba pra conteúdo
- Público necessário
- Tipos de criativos essenciais
- O que é necessário pra implementar

---

## LIGAÇÃO 3 — Apresentação da estratégia (com cliente)

Pauta:
- Apresentação da análise realizada
- Alinhamento da estratégia desenhada com o cliente
- Dúvidas e sugestões do cliente
- Reforço da **relação de cooperação** entre você e o cliente
- **Previsão pra começar a anunciar**
- Recapitulação das **principais ações que o cliente deve tomar**
- Explicação que o tráfego é excelente, **mas não muda o jogo do dia pra noite**
- Mostrar o quão feliz está de trabalhar com o cliente

---

## BÔNUS — Pós-ligação (entregáveis que encantam)

- Print de **todos os públicos** que você criou na conta dele
- Análise de **públicos e anúncios que funcionaram no passado** (cliente já anunciava antes)
- **Swipe File** — banco de anúncios pro cliente modelar
- **Manual de anúncios**
- **Manual de como produzir conteúdos**
- Envio de sugestões e ideias após a ligação

---

## Encerramento

> "Manter um cliente engajado vai muito além de entregar resultados — é preciso unir performance, clareza e atenção aos detalhes."

> "Onboarding é o momento de criar impacto. De gerar aquele sentimento de 'Uau, nunca me explicaram dessa forma antes'."

> "Quem entende a jornada confia no processo. E quem confia, permanece."

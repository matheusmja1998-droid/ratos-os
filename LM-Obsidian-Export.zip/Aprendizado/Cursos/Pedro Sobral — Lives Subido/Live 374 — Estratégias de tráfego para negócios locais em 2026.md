---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 374
tema: Estratégias de tráfego para negócios locais — 8 etapas
status: completa
tags: [tráfego-pago, negócio-local, sobral, estratégia, whatsapp, google-meu-negócio, lead-scoring, públicos-quentes, grupo-vip, cbo, abo]
---

# Live #374 — Estratégias de tráfego para negócios locais em 2026

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 374]]

> Como construir do zero uma estratégia de tráfego pago pra qualquer negócio local em 8 etapas + ferramenta de diagnóstico.

---

## Big Idea

Atender negócios locais é a melhor porta de entrada no tráfego pago. **20 milhões de CNPJs no Brasil + 3 milhões novos por ano + todos precisando de fluxo de pessoas.**

**Estratégia = variação de 3 fatores:**
1. **Verba** (quanto gastar)
2. **Fontes de tráfego** (onde anunciar)
3. **Objetivos** (com criativos + destinos definidos)

---

## A profissão do gestor caminha pro generalismo

Sobral acredita que os profissionais vão ser **cada vez mais generalistas**, não especialistas. Com IA acelerando aprendizado de habilidades novas, dá pra entregar várias coisas pro mesmo cliente.

> "A IA não diminui seu potencial de ganho — potencializa. Mas você precisa dominar as habilidades fundamentais."

E o **núcleo de todas elas é tráfego pago**, porque é o primeiro problema que o cliente quer resolver (trazer mais clientes).

---

## As 5 perguntas pra montar estratégia inicial

(Vão alimentar a ferramenta de diagnóstico que Sobral criou.)

### 1. Qual é o tipo de negócio?
Dentista, coworking, loja, médico, contador, advogado, imobiliária, salão, barbearia, academia, pet shop, etc.

### 2. Como os clientes chegam até esse negócio HOJE?
3 caminhos:
- **Busca ativa (Google)**: encanador, eletricista, detetizadora, dentista, ortodontista, advogado, contador, chaveiro, vidraceiro, serralheiro
- **Descoberta (redes sociais)**: restaurante, hamburgueria, pizzaria, loja de roupa, barbearia, estúdio de tatuagem, floricultura, confeitaria, loja de decoração
- **Híbrido (os dois)**: clínica de estética, academia, pet shop, imobiliária

### 3. Investimento mensal em tráfego pago
3 faixas:
- Até R$ 1.500
- De R$ 1.500 a R$ 5.000
- Acima de R$ 5.000

> "Você não controla a verba do cliente. Mas controla o tipo de cliente que você vai atrás."
>
> Recomendação mínima: R$ 1.200/mês.

### 4. Ticket médio do produto/serviço principal
Quanto a pessoa deixa em média quando compra ali.

### 5. Quem atende os leads?
- Dono atende sozinho
- Recepcionista/secretária
- Equipe comercial

---

## As 4 fontes de tráfego (Google vs Meta)

### Google = ferramenta de INTENÇÃO
Pessoa só vai ao Google quando tá buscando algo ativamente. "Estourou o cano, vou pesquisar encanador."

### Meta = ferramenta de ATENÇÃO + RELAÇÃO
Atrair quem não tá buscando. Construir audiência ao longo do tempo.

### Negócios híbridos
- **Intenção**: "tô com dor de dente, vou procurar dentista" → Google
- **Atenção**: dentista vendendo botox, preenchimento, clareamento → Meta

---

## ETAPA 3 — Campanhas que você TEM que saber rodar

### Meta (4 tipos):
- **Botão turbinar / Impulsionar** — mais simples. Excelente pra trazer seguidores.
- **WhatsApp** — campanha mais usada com negócio local
- **Formulário nativo** (Lead Ad)
- **Engajamento, vídeo, alcance**

### Google (3 tipos):
- **Campanha Smart**
- **Performance Max** (boa pra visitas ao negócio físico)
- **Campanha de pesquisa**

> "Pra fazer isso não precisa nem saber instalar pixel. Se você dominar essas campanhas, sabe fazer tráfego pra negócio local."

---

## ETAPA 4 — Tipos de destino nas campanhas de CONVERSÃO

### WhatsApp (engajamento)
- ✅ Mais volume
- ❌ Menos qualidade

### WhatsApp (vendas)
- ❌ Menos volume
- ✅ Mais qualidade (tendência, não regra)
- ❌ Custo por lead mais alto

### 🔑 Duas dicas-bomba pra qualquer cliente novo (geram resultado antes de gastar em ads)

**Dica 1 — Grupo VIP de WhatsApp:**
- Pega TODOS os contatos de WhatsApp do cliente
- Cria um "Grupo VIP da [marca]"
- Mensagem individual pra cada cliente: "Criamos um grupo VIP, com acesso antecipado a descontos, sorteios, dicas especiais que não estarão em nenhum outro lugar"
- Não enfia todo mundo no grupo direto. Convida um a um.

**Dica 2 — Campanha de reativação:**
- Toda base de clientes inativos há +90 dias
- Disparo com oferta específica de retorno
- "Injeção de caixa imediata" antes mesmo de rodar ad

> "90% dos negócios que a gente pega, fazemos essas campanhas. É grana sem gastar nada em mídia."

### Formulário nativo
- ✅ Mais qualidade
- ✅ Permite **lead scoring** — atribuir notas a cada lead com base nas respostas
- Funciona pra produtos mais caros que precisam de informação prévia

**Explicação simples de lead scoring**: 3 perguntas no cadastro pra classificar quem é o lead. Ex: "Você é zerado, decidiu ser gestor mas não fatura, ou já é gestor?" — vende mais pro 3º.

### Página (landing page)
- ✅ Pré-qualificação direto na página
- ❌ Maior custo por lead de todas as estratégias
- Bom pra: petshop, clínica médica, arquiteto, loja de persiana, empresa de evento, B2B

### Google Ads (envia pra site)
- ✅ Capta demanda específica (alta intenção)
- ❌ Difícil mostrar autoridade só pela página

---

## ETAPA 5 — Campanhas de AQUECIMENTO/Distribuição

Pra que servem: aumentar alcance, engajar novos públicos, fortalecer relacionamento.

### Engajamento / Visualização de vídeo
- Gera volume de interação
- Permite **social selling** — pessoa comentou no post patrocinado, time entra em contato pra vender

### Turbinar publicação
- Traz **muito seguidor** com custo baixo
- ⚠️ Cuidado: público pode não ser qualificado. Patrocinar conteúdo errado dá ruim.

### Campanha de alcance / Reconhecimento de marca
- Bom pra ampliar reconhecimento regional
- Aparecer várias vezes pras mesmas pessoas num mesmo local

> "As pessoas compram das marcas que elas mais veem. Outdoor da Coca não vende uma Coca direto — ocupa espaço na sua cabeça. Negócios locais fazem isso em escala menor pelas redes."

---

## ETAPA 6 — CBO vs ABO

- **CBO (Campaign Budget Optimization)** — Meta/Google decide quanto cada público gasta. **Use isso quando começa.** Ideal pra grande escala + reduzir CPA.
- **ABO (Adset Budget Optimization)** — você decide quanto cada público recebe. Pra teste inicial + validar hipóteses + casos avançados.

**Nomes atuais na Meta:**
- CBO → "Orçamento Advantage" (já vem ativado)
- ABO → "Orçamento do conjunto de anúncio"

---

## ETAPA 7 — Tipos de segmentação

**Pergunta-chave**: o negócio precisa de **autoridade + relacionamento prévio** antes da venda?

- **Cirurgião plástico, tatuador, dentista de procedimento estético** → SIM (você não contrata o primeiro que aparece)
- **Encanador de urgência, chaveiro, fast food** → NÃO (decisão rápida)

### Públicos QUENTES (já te conhecem)
Pessoas que se envolveram com a marca recentemente, interagiram com posts/anúncios, públicos semelhantes, hierarquias de engajamento (1-30 dias, 1-365 dias).

### Públicos FRIOS (nunca viram)
- **Interesses óbvios** no direcionamento detalhado (petshop → cães, gatos, ração)
- **Públicos abertos com geolocalização específica** (1-2 km do negócio)
- **Lookalike** de listas de clientes / seguidores / quem viu 3+ segundos de vídeo nos últimos 365 dias
- **Profissões com maior poder aquisitivo**

---

## ETAPA 8 — Posicionamento (na Meta)

- **Só Instagram** = público mais qualificado, mais poder aquisitivo. Use pra ticket maior.
- **Advantage Plus** = público mais amplo e popular.

---

## Recomendação dos anúncios

> "A resposta de quais anúncios usar está na Live 372 (Copy Parte I)."

Não é o foco desta aula técnica de estratégia.

---

## A ferramenta de diagnóstico

Sobral montou um sistema que responde as 5 perguntas e devolve:
- % de verba pra Google vs Meta
- % de verba pra conversão vs aquecimento
- Número de campanhas
- Quais campanhas específicas rodar
- Matriz completa com todas as estratégias possíveis pra todos os tipos de negócio

**Origem dos dados**: Sobral pesquisou na comunidade de alunos + grupo de gestores que faturam +R$1M/ano + agência própria. Identificou padrões e estruturou.

---

## Palavra-chave da aula: **Respira**

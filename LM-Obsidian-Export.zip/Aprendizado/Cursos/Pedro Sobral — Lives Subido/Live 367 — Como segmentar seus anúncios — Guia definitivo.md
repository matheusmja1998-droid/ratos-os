---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 367
tema: Segmentação de anúncios — Guia definitivo (7 formas)
status: completa
tags: [tráfego-pago, segmentação, públicos, sobral, advantage-plus, remarketing, pixel, gangorra, isca]
---

# Live #367 — Como segmentar seus anúncios: o guia definitivo

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 367]]

> As 7 formas de configurar para quem seu anúncio aparece + framework prático para anunciar em 2026.

---

## Big Idea

O grande segredo do tráfego pago não é querer aparecer pra todo mundo. É chamar atenção de **quem importa** e ser **ignorado por quem não importa**.

Segmentar 2026 é diferente de 2015:
- **Antes** = era preciso testar milimetricamente cada combinação de público
- **Agora** = o próprio anúncio funciona como uma **superisca com ímã** — ele atrai as pessoas certas. A ferramenta (Meta/Google) faz parte do trabalho.

> "Tráfego pago hoje é uma gangorra entre a plataforma e o gestor. Saber anunciar é saber quanto deixa a ferramenta ter controle e quando você toma de volta."

### Analogia da pescaria
- **Segmentação** = lago cheio de peixes (pessoas)
- **Anúncio** = isca que atrai os peixes
- **No passado**: gestor escolhia milimetricamente em qual lago jogar
- **No presente**: o anúncio é uma superisca com ímã. Plataforma atrai as pessoas certas até ele.

---

## Os 6 aspectos que combinam pra formar qualquer público

Não importa o negócio (terapia, poço artesiano, curso de empinar moto, venda de tripé, divulgação de evento). Existe alguém com o celular na mão agora que é a pessoa perfeita pra ver seu anúncio. Os públicos se formam de combinações desses 6 aspectos:

1. **Tipo de conteúdo que a pessoa consome** nas redes sociais
2. **Pesquisas que ela já fez** na internet
3. **Sites que ela visita**
4. **Apps que ela tem no celular**
5. **Interações com a sua marca** (visitou perfil, comprou, agendou consulta)
6. **Dados demográficos**

> "Tudo o que você faz na internet é mapeado. O rastro digital é assustador pra maioria — pra mim é maravilhoso. Sem esse rastro, ninguém anunciaria pra ninguém."

---

## As 7 formas de configurar PARA QUEM aparecer

> "90% dos anunciantes avançados só conhece 2 ou 3. O resto é diferencial."

### 1. SELEÇÃO DO OBJETIVO
O próprio objetivo de campanha já filtra públicos. A ferramenta direciona seu anúncio pra grupos que têm mais chance de **realizar aquele objetivo específico**.

6 objetivos essenciais:
- **Vendas**
- **Cadastros (leads)**
- **Engajamento** (inclui mensagens e visualização de vídeo)
- **Reconhecimento** (alcance)
- **Aplicativo**
- **Tráfego** (envia pra um link)

A pessoa muda dependendo do momento que está na rede social. "Brain rot" (rolagem infinita de meme) é momento diferente de "consumo ativo". Diferentes objetivos pegam diferentes momentos.

### 2. SEGMENTAÇÃO AUTOMÁTICA (Advantage+ / Pmax / Smart)

Você diz pra ferramenta: "Faz aí, encontra as pessoas pra mim."

**2 variações:**
- **Sem sugestão** — ferramenta livre
- **Com sugestão** — você dá pistas (idade, região, interesses). Ferramenta usa como dica, decide no final.

**Recomendação: sempre testar primeiro COM sugestão.** Tende a trazer público mais qualificado.

Existe controle extra na **configuração da conta de anúncios** (Conta → Controle da conta → Controle de público alvo) — você pode forçar a conta a anunciar só em certas localizações/idades.

### 3. ESCOLHA MANUAL DE PÚBLICO ("opções originais de público")

"Como os maias e os astecas faziam, mas a gente ainda usa."

Tipos:
- **Envolvimento** com Instagram/Facebook/YouTube (seguidores, quem mandou mensagem, salvou post, viu vídeo, comentou)
- **Visitantes do site** (e públicos específicos: quem visitou produto, abandonou carrinho, comprou)
- **Lista de e-mails/telefones** (clientes, leads)
- **Interações com formulários de cadastro** nativos
- **Visualizadores de vídeo**
- **Dados demográficos** (idade, gênero, localização, renda)

> "Lojas raramente anunciam pros próprios clientes que já compraram. É um dos públicos que mais funciona — e ninguém faz."

### 4. ESCOLHA MANUAL DE CONTEÚDO

Quando você não escolhe a pessoa, escolhe **quando aparecer** (em qual conteúdo).

Principalmente Google Ads:
- Em qual pesquisa você quer aparecer
- Em quais sites
- Em quais vídeos/canais do YouTube

**Tendência futura:** Sobral aposta que vai começar a ter controle do **sentimento** da pessoa naquele momento (estudo da Netflix sobre anúncios direcionados por humor — filme de ação = animado, documentário = estudioso).

### 5. PIXEL / API DE CONVERSÕES / CONJUNTO DE DADOS

O pixel não é só pra mensurar venda — ele é a **inteligência da conta**.

Pixel bem treinado = ferramenta mais inteligente direcionando anúncios.
Pixel ruim = ferramenta cega.

> "Pixel é como tornar o ímã da sua isca mais forte. O pescador agora sabe exatamente onde tem mais peixe."

### 6. INTERAÇÕES PASSADAS COM SEUS ANÚNCIOS

A meta/Google ativamente entende **quem clica nos seus anúncios** e foca em achar mais gente parecida.

Por isso vale **separar campanhas** se você vende produtos muito diferentes (suplemento + eletrônico). Misturando, o algoritmo confunde o perfil.

### 7. O PRÓPRIO ANÚNCIO ⭐ (maior segmentador)

**O que está escrito/falado no anúncio é o maior direcionador de quem vai vê-lo.**

Exemplo:
- Anúncio 1: "Você vai passar 10h nesse curso pra não passar mais 8h por dia aturando seu chefe chato" → atrai quem quer mudar de carreira
- Anúncio 2: "Você vai demitir seu time de marketing depois desse curso" → atrai dono de negócio

Mesmo público escolhido, anúncios diferentes atraem pessoas diferentes. A plataforma joga a isca em **lagos diferentes** automaticamente.

> "No passado: precisava escolher milimetricamente onde anunciar. No presente: o anúncio com ímã atrai a pessoa certa."

---

## Os 5 passos práticos pra segmentar bem

### Passo 1 — Entender a estrutura
Campanha → Conjunto de anúncio → Anúncio. A segmentação fica no **conjunto de anúncio**.

### Passo 2 — Anunciar constantemente pra públicos quentes e super quentes

**Públicos super quentes** (intenção de compra demonstrada):
- Lista de clientes
- Pessoa que mandou mensagem mas não comprou
- Iniciou compra / adicionou ao carrinho
- Se cadastrou
- Visitou site mas não comprou
- Pesquisa pelo nome da sua marca
- Envolveu-se ou visitou nos últimos 7 dias

**Públicos quentes** (conhece a marca):
- Envolveu-se 1-540 dias
- Localização geográfica
- Listas antigas que não compram há tempo
- Pesquisas relacionadas ao produto/serviço
- Vídeos relacionados ao tema

**Públicos frios** (nunca viu):
- Semelhantes (lookalike)
- Direcionamento detalhado (interesses)
- Público alvo de mercado
- Público de afinidade
- Baseado em apps/sites
- Pesquisas amplas no nicho (não específicas)

### Passo 3 — Sempre ter campanha de teste automatizada
Em paralelo aos controlados, **sempre** rodar campanha Advantage+ / Pmax. **Não colocaria todo dinheiro só nisso**, mas é coringa.

⚠️ Se a campanha não é de venda direta (lead, evento), avaliar qualidade do que chega. Usar **sugestões de público** pra subir a qualidade.

### Passo 4 — Testar públicos frios em paralelo
Manter teste de novos públicos rolando enquanto os quentes seguram resultado.

### Passo 5 — Organizar com 4 a 8 conjuntos de anúncio por campanha
Menos pode funcionar, mais começa a bagunçar.

---

## Dicas finais e resumo

1. **Seu anúncio, pixel e objetivo de campanha** desempenham papel fundamental — nem sempre é a "segmentação clássica" que define.

2. **4-8 conjuntos de anúncio por campanha** é a sweet spot.

3. **Sempre anuncia pro passo anterior ao objetivo.** Objetivo é compra? Anuncia pra quem adicionou ao carrinho. Objetivo é cadastro? Anuncia pra quem chegou na LP mas não cadastrou.

4. **Qualificar = público menor. Escalar = público maior.** Envolvimento de 30 dias é mais qualificado que de 180 dias. Mas se precisa de mais volume, expande pra 365.

5. **Públicos super quentes > quentes > frios.** Sempre testar nessa ordem.

6. **Evita gastar dinheiro em conjunto que a Meta/Google não está gastando.** Se a ferramenta não puxa, tem motivo. Forçar gasto manual quase sempre dá ruim.

7. **Se público gigante não funciona, segmenta um pedaço qualificado dele.** Ex: lista de 1M de cadastros não converte? Pega só os 50k que abrem email. Ou só clientes que gastaram +R$500.

8. **Negócio local: sempre testar anunciar APENAS na localização de atuação**, sem outras camadas. Deixa o anúncio achar a pessoa certa.

9. **Foca nos públicos óbvios.** Se óbvio não funciona, **o problema raramente é segmentação**. Provavelmente é o anúncio ou a página de destino.

10. **Cuidado com público grande demais numa campanha** — ele rouba todo o orçamento, deixa os outros zerados.

11. **Sempre testa automático em paralelo ao controlado.** Boa estratégia é mix, não extremo.

---

## Diferencial em reunião de vendas

> "A maior parte dos gestores de tráfego acha que existem só 2 formas de segmentar: escolher público + mexer na copy. Mas tem 7."

Esse é o argumento que Sobral usa pra fechar cliente quando o cliente reclama de "qualidade dos leads". Mostra autoridade técnica imediatamente.

3 erros que a maioria dos professores de tráfego comete (citados na live):
1. Não ensina fundamentos / parte teórica
2. Valoriza botão acima de pessoas
3. Diz que o gestor não precisa dominar copy criativa

---

## Palavra-chave da aula: **Isca de peixe**

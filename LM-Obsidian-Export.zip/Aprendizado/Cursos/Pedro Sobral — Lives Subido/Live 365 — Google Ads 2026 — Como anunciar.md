---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 365
tema: Google Ads 2026 — Como anunciar (10 passos)
status: completa
tags: [tráfego-pago, google-ads, sobral, rede-de-pesquisa, performance-max, remarketing, youtube-ads, palavras-chave, pixel]
---

# Live #365 — Google Ads 2026: como anunciar

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 365]]

> Os 4 tipos de campanha essenciais do Google Ads e os 10 passos para criar uma campanha de pesquisa do zero.

---

## Big Idea

O Google Ads divide-se em **4 quadrantes** que cobrem o jogo inteiro: pesquisa institucional, YouTube, remarketing no display, e Pmax. Criar campanha é só seguir 10 passos sequenciais.

> "Você não consegue aprender a nadar lendo um livro sobre natação. Mas com o checklist você consegue criar suas campanhas do zero."

---

## Os 4 tipos de campanha essenciais (visualização em X)

| Quadrante | Função |
|---|---|
| **Pesquisa institucional** | Aparece quando pessoa pesquisa nome da marca/negócio. Toda marca precisa ter — quem não tem, perde dinheiro. |
| **YouTube (conversão)** | Anúncio chato de 5 segundos antes do vídeo. Hoje precisa selecionar "Geração de demanda" (Discovery), não mais "Vídeo". |
| **Remarketing no Display** | Aparece em sites da internet pra quem já interagiu (a geladeira que persegue). |
| **Performance Max (Pmax)** | Xudo. Aparece em todos os lugares. Melhor pra e-commerce + visitas a negócio local. Não escolhe segmentação exata — dá indicador. |

---

## Os 10 passos para criar uma campanha no Google Ads

### Passo 1 — Objetivos
Vendas, leads, tráfego, promoção de app, reconhecimento e consideração, visitas a lojas locais.

**O nome diz o que o objetivo faz.**

Pra começar: **vendas** ou **leads**. Se sabe criar venda, sabe criar qualquer outra — venda é a que tem mais opções de configuração.

### Passo 2 — Metas de conversão (precisa do Pixel)

Aqui você diz ao Google em que ação quer focar (compra, contato, formulário enviado).

**O Pixel** faz 3 coisas:
1. **Informante** — lê o que acontece no site e manda pro Google (quem entrou, adicionou ao carrinho, comprou, qual perfil)
2. **Inteligência** — aprende o padrão (todo comprador tem interesse em X, idade Y) → entrega mais inteligente
3. **Cria públicos** — visitante, abandonou carrinho, comprou (pra remarketing)

Sem Pixel, o Google não sabe quando você vendeu → não sabe o que otimizar.

### Passo 3 — Tipos de campanha e segmentações indicadas

| Tipo de campanha | Segmentação indicada |
|---|---|
| Pesquisa | **Palavras-chave** |
| Display | **Públicos quentes** (visitaram, pesquisaram, são clientes, abandonaram carrinho) |
| Shopping | **Quem interagiu com o e-commerce** (precisa **Google Merchant Center** — chamar quem fez o site pra configurar) |
| Vídeo | **Público alvo + palavras-chave + canais/vídeos** |
| Aplicativos | Usuários do aplicativo + público alvo |
| Performance Max | **Indicador de público alvo** (sugestão) |
| Geração de demanda (Discovery) | **Público alvo + palavras-chave + canais** — usar pra conversão no YouTube |

**Detalhe importante**: o Google **mudou recentemente** — agora pra fazer **conversão em vídeo** não usa mais "Vídeo", usa **Geração de demanda**.

#### Públicos coringa pra YouTube (sempre testar)
- Pessoas que **quase converteram** (chegaram no carrinho mas não compraram)
- Pessoas que **viram seu anúncio mas não converteram**
- **Envolvimentos de 1-30 dias** com seu canal
- **Inscritos no canal nos últimos 540 dias**
- **Listas de leads** (e-mails/telefones)
- **Segmentos personalizados** (pesquisas que fizeram no Google + sites navegados + apps no celular)
- **Público alvo no mercado**
- **Palavras-chave ou canais específicos**

### Passo 4 — Nomenclatura

Padrão: `[objetivo] - [tipo] - [subtipo] - [descrição]`
Ex: `Vendas — Pesquisa — Lead Captação Vela Aromática`

### Passo 5 — Estratégia de lance + Orçamento

**Lance** = "em qual resultado quer focar + quanto quer pagar":
- Conversões (mais comum)
- Cliques

**Quanto maior o lance, mais aparece, mais paga por resultado.** Analogia do leilão de quadros.

Lance é seu **acelerador**. Custo caro? Tira o pé. Não tá gastando? Pisa fundo.

### Passo 6 — Redes e formato

Onde aparecer. Pra **rede de pesquisa**: marcar só Google + parceiros da pesquisa. **Desativar rede de display** (ela é uma bosta quando junto com pesquisa, vai funcionar pior).

### Passo 7 — Localização e idiomas
- Locais: país, estado, cidade, CEP (5 dígitos), pin no mapa com raio
- **Importante**: `location options` → escolher **"Presença"** (não "interesse"). Senão um delivery em Londrina aparece pra alguém no Maranhão que pesquisou "Londrina".
- Idiomas: **sempre português + inglês + espanhol**

### Passo 8 — Início e programação
- Data de início e término
- Horários (ex: seg-sex 8h-18h se o negócio tem horário comercial)

### Passo 9 — Segmentação (palavras-chave pra rede de pesquisa)

**3 tipos de segmentação que o Google oferece:**
1. **Público alvo** — características, interesses, comportamentos, ações
2. **Conteúdo** — o que a pessoa pesquisa, acessa ou vê (pra pesquisa = palavras-chave)
3. **Indicador de público alvo** — sugestão pra Pmax

**Pra campanha de pesquisa = palavras-chave.**

#### Tipos de correspondência de palavra-chave
- **Ampla** (`curso de anúncios online`) — Google traz pesquisas semelhantes
- **Frase** (`"curso de anúncios online"`) — contém essas palavras nessa ordem
- **Exata** (`[curso de anúncios online]`) — pesquisa exata

**Pra começar: mais frase e exata.** Mais controle.

#### Como achar palavras-chave
- AnswerThePublic
- Also Asked
- Cabeça (o que sua audiência pesquisa)

**Estrutura**: cada conjunto de anúncio tem um **tema único** (não misturar "trabalho home office" com "vela aromática").

### Passo 10 — Anúncio

- **Títulos** (30 caracteres cada, até 20). Google testa qual converte mais.
- **Descrições** (90 caracteres, até 4)
- **Imagens** (quadrada + retangular deitada + em pé) — opcional, mas enriquece
- **Nome da empresa + logotipo**
- **Site links** (sites extras do mesmo domínio — depoimentos, blog, etc)
- Promoções, preço, telefone, WhatsApp, frases de destaque, snippets

---

## Encerramento — orçamento e publicação

Depois dos 10 passos, Google pede orçamento diário (customizado) e dá revisão.

**Só corre risco de gastar dinheiro quando aperta "publicar".** Pode fazer todo o passo a passo e parar antes — vira treinamento.

### Sugestão para primeira campanha

**Campanha institucional**: anunciar pros termos da sua marca (ex: "Pedro Sobral", "comunidade subido"). É a campanha mais segura de todas. R$5/dia.

---

## A IA do Google atualmente
- "Otimizar campanha com IA" → desativar (ainda não está bom, mas vai melhorar)
- Geração automática de palavras-chave → desativar (não está bom)

---

## Palavra-chave da aula: **Domine o topo**

---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 372
tema: Copywriting para Gestores de Tráfego — Parte I (Cop + Público + Anúncios)
status: completa
tags: [copywriting, copy, sobral, público-alvo, schwartz, biblioteca-de-anúncios, gancho, gcc, fator-de-segmentação]
parte-de: [[Live 373 — Copywriting para Gestores de Tráfego (Parte II)]]
---

# Live #372 — Copywriting para Gestores de Tráfego: como criar bons anúncios (Parte I)

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 372]]
**Continuação**: [[Live 373 — Copywriting para Gestores de Tráfego (Parte II)]]

---

## Big Idea

O gestor de tráfego não pode ser só "apertador de botões da ferramenta". Tem que aprender a **apertar botões das pessoas** — isso é copy.

- **Tráfego pago** = apertar botões das ferramentas
- **Copywriting** = apertar botões das pessoas

> "No final das contas, você será um apertador de botões. Quem só aperta botão da ferramenta vai ficar sem cliente. Quem aperta botão das pessoas pela comunicação digital nunca fica sem trabalho."

---

## Os 5 pilares de copy pro gestor de tráfego

1. **Entender o que é copy** (cobrado aqui)
2. **Saber sobre público alvo** (cobrado aqui)
3. **Copy para anúncios** (cobrado aqui)
4. **Copy para páginas** (vai pra Parte II)
5. **Copy para promessas** (vai pra Parte II)

---

## PILAR 1 — ENTENDER COPYWRITING

**Cop ≠ Copyright.** Copyright = direitos autorais. **Copywriting = "writing" = escrita persuasiva.**

Copy = habilidade de apertar botões das pessoas pela comunicação (falada ou escrita). Já fazemos isso no dia a dia:
- "Priscila, pega água pra mim AGORA, para de falar" ❌
- "Pô vidoca, tô na loucura planejando a live, fiquei até tarde ontem, você não pega uma água pra mim ali rapidinho?" ✅

### Como ficar bom em copy
1. **Aprender com quem faz copy** (curso, professor, observação)
2. **Input antes do output**

**Regra: input antes do output.** Não aprendeu a falar português fazendo exercício de português. Primeiro ouviu por anos, depois reproduziu. Mesma coisa pra escrita — "aprender a **ler e** escrever", nunca "escrever e ler".

> "Não existe quem escreve muito bem que não leia muito. Harry Potter, Trono de Vidro, Senhor dos Anéis, técnicos — qualquer coisa serve."

---

## PILAR 2 — PÚBLICO ALVO (4 CAMADAS)

> "Toda persuasão nasce do pressuposto de você saber com quem está falando."

### CAMADA 1 — Definições básicas (quem é a pessoa)

Idade, gênero, gostos, consumo, medos, dores, desejos, objeções.

Sobral liberou um agente de ChatGPT que faz pesquisa de persona completa. Demo na live (nicho: manicure):

Output do agente pra "Juliana Ferreira" (persona de manicure):
- **Problema principal**: manter unhas bonitas mas sofre com falta de tempo, profissionais inconsistentes
- **Emoções**: frustração quando quebra, raiva de atraso, ansiedade pré-evento, medo de infecção, culpa de gastar
- **Medos**: micose, cutícula machucada, evento com unha feia, pagar caro mal feito
- **Como afeta vida**: irrita-se antes de eventos, desmarca compromisso, discute com parceiro, evita fotos
- **Frases ofensivas que ouve**: "É só unha", "Você já fez essa? Nem parece"
- **Já tentou**: própria, manicure barata, gel, kit profissional
- **Experiências ruins**: atraso de 40min, unha torta, machucaram cutícula, pago caro não dura 3 dias

> "Isso aqui é ouro. A partir disso eu crio copy pra qualquer manicure — e eu não sei nada de manicure."

### CAMADA 2 — Níveis de consciência (Eugene Schwartz)

> "Esse é o conhecimento que eu levaria em toda reunião de vendas com cliente. Impressiona."

Schwartz, no livro **Breakthrough Advertising**, inverteu a tese da época. Antes: o mais importante é saber **com quem** você fala (Camada 1). Schwartz: o mais importante é saber **o que essa pessoa sabe e o que não sabe**.

**Os 5 níveis:**
1. **Totalmente inconsciente** — só tem o sintoma, não sabe o nome do problema
2. **Consciente do problema** — sabe que tem o problema
3. **Consciente da solução** — sabe que existe solução
4. **Consciente do produto** — sabe qual produto/categoria resolve
5. **Totalmente consciente** — sabe a marca/quem entrega

**Exemplo "Seu Zé da padaria"**:
- Não sabe que precisa estar na internet → inconsciente
- Alguém fala "tem que estar na internet" → consciente do problema
- Descobre tráfego pago → consciente da solução
- Descobre cursos de tráfego pago → consciente do produto
- Conhece o Pedro Sobral → totalmente consciente

**Exemplo "bruxismo do Sobral"**:
- Sentia dor de cabeça → inconsciente (só tinha o sintoma)
- Dentista falou "você tem bruxismo" → consciente do problema
- "Tem como amenizar" → consciente da solução
- "Plaquinha noturna" → consciente do produto
- "Meu dentista faz" → totalmente consciente

**Aplicação no anúncio**: se você só fala com nível 4-5 ("Faça sua plaquinha em 48h"), perde quem tem só dor de cabeça e não conhece o nome. Anúncio educacional captura o nível 1-2 (sintoma → problema).

### CAMADA 3 — Crenças

O que a pessoa acredita ou não. 3 caminhos pra mapear:

1. **Já viveu o que essa pessoa vive** — você consegue identificar crenças porque tem (ou teve) elas
2. **Contato direto com clientes** — pesquisar ou perguntar pra base atual do dono do negócio
3. **Discussões públicas na internet** — comentários no Instagram, TikTok, Twitter, e principalmente **Reddit**

**Truque do Reddit via ChatGPT (modo pensamento):**

4 buscas:
- Principais **soluções** que as pessoas acreditam que vão fazer com que alcancem o objetivo
- Principais **preconceitos** sobre o tipo de produto/solução que você vende
- O que elas acham que **é viável** fazer pra resolver
- O que elas acham que **NÃO é viável** fazer

ChatGPT vai pro Reddit, busca discussões reais, traz crenças autênticas. Aplicado pra "ganhar dinheiro na internet" ou "fazer unhas" — funciona em qualquer nicho.

### CAMADA 4 — Atenção

> "Eu, como observador do comportamento humano, vou ver o que ativa o botão dela."

Que tipo de conteúdo chama atenção dessa pessoa.

**Como mapear na prática**:
- Abrir Instagram → lupa de pesquisa → digitar o nicho ("manicure")
- Aba **Posts** → aparecem os reels com mais views (10M, 6M, 9M, 7M views)
- Cada post viral = **referência validada do que ativa atenção naquele público**
- Investir 20-40 minutos salvando links dos vídeos top

**Exemplos encontrados na live (nicho manicure):**
- Vídeo da moça mexendo a mão durante manicure + esmalte borra + tapa de luva = identificação humorada com frustração comum
- Vídeo "passei na prova / hoje é meu aniversário / eu disse sim / comprei meu carro / tô grávida → todos motivos pra ir fazer a unha" = identificação emocional
- Timelapse de unha sendo refeita com música satisfatória

> "Pedro Sobral, depois de 40 minutos fazendo essa pesquisa, eu me sinto 100% apto a escrever melhores anúncios pra qualquer manicure do mercado."

---

## PILAR 3 — ANÚNCIOS

### Elemento 1 — Bons anúncios são baseados em referências

> "Você não precisa ser a pessoa mais criativa do mundo. Tem que ser a mais interessada e pesquisadora."

**2 lugares pra buscar referências:**

#### A) Próprio Instagram (já mostrado na camada 4)
> "Todo produtor de conteúdo do seu nicho está o tempo todo testando anúncios pra você."

Reels com milhões de views = melhores anúncios potenciais já validados. Não copia — recria.

#### B) Biblioteca de Anúncios da Meta
Ferramenta de "espionagem legalizada".

**Passo a passo:**
1. Google: "biblioteca de anúncios" → primeiro link
2. Brasil + categoria "Todos os anúncios"
3. Pesquisar pela página
4. Demo: Pedro Sobral (160 anúncios ativos em uma página), Leandro Ladeira (600 anúncios)

**Truque-chave dos filtros (pulo do gato):**
- **Impressões por data**: filtrar pra ignorar anúncios que só rodaram nos últimos dias (podem ser testes novos, não validados)
- **Veiculação iniciada**: ver quando o anúncio entrou no ar. Anúncio rodando há 2-3 meses = sinal forte de validação ("ninguém deixa anúncio ruim 2 meses no ar")
- **Classificação padrão** mostra primeiro os anúncios com mais impressões → tendência de serem os melhores
- **Filtrar também pelos mais recentes** mas ir até o **final da lista** → os mais antigos com poucas impressões podem ser perlas escondidas (anúncios muito qualificados rodando pra público restrito)

**Ferramenta**: extensão Chrome **Ad Library Cloud** (gratuita) → baixa o vídeo do anúncio.

#### Pipeline completo de extração de estrutura

1. Baixa vídeo do anúncio (Ad Library Cloud)
2. Vai pro **Gemini** (gemini.google.com) — qualquer versão
3. Manda o vídeo + prompt: "Me envie: transcrição do anúncio e descrição visual completa"
4. Gemini retorna tudo (GPT não consegue analisar vídeo, Gemini sim)
5. Copia → cola num **agente do ChatGPT** que Sobral criou ("extrator de estrutura")
6. O agente devolve: roteiro estruturado + direção visual + matriz estrutural + **modelo editável** com lacunas
7. Preenche as lacunas com **sua persona + sua oferta**
8. Sai um anúncio adaptado ao seu negócio, baseado numa estrutura validada

> "Eu não tô chegando pra IA e pedindo 'faz um anúncio pra mim'. Tô usando ela com base numa referência. Tudo isso vem de um conhecimento meio óbvio: bom anúncio é feito de referências."

### Elemento 2 — Anúncios camuflados vs explícitos

- **Anúncio camuflado** = não parece anúncio. Parece conteúdo orgânico. Funciona melhor com nível baixo de consciência (1-2-3).
- **Anúncio explícito** = parece anúncio mesmo. Funciona melhor com pessoa pronta pra comprar (níveis 4-5).

**Não escolhe um — use os dois.** "99% dos anúncios são explícitos. Mas os camuflados são o primeiro contato pra muita gente."

Onde achar referências:
- **Camuflados**: posts virais do Instagram (a pesquisa da Camada 4)
- **Explícitos**: biblioteca de anúncios

Formatos camuflados validados pra adaptar:
- **Talking head** com TV atrás (estilo aula)
- **Vídeo narrado** (estilo Jenny Keller) — várias imagens + voz em off, sem aparecer
- **Opinião polêmica na rua** com plaquinha
- **POV com texto provocativo** ("só a unha não é feia, só manicure que é ruim")

### Elemento 3 — Bom anúncio é FILTRO, não ímã

> "O anúncio foi feito pra ser **ignorado pelas pessoas erradas**. Quem importa para pra prestar atenção."

A meta e o Google interpretam o roteiro/texto do anúncio e entendem pra quem direcionar. **Você não precisa segmentar manualmente** — o que está falado no anúncio direciona.

#### Os 7 fatores de segmentação (mecanismos pra filtrar via copy)

1. **Direta** — "Se você tem delivery em Curitiba e faz mais de 200 pedidos/mês..."
2. **Conhecimento** — "Taxa de recompra abaixo de 30% é o buraco invisível do seu delivery" (só dono entende "taxa de recompra")
3. **Ferramenta/plataforma** — "Se você ainda gerencia pedido por WhatsApp e caderninho..."
4. **Situação** — "Sexta-feira, 19h, chovendo em Curitiba, pedidos explodindo e o motoboy te liga dizendo que não vai..."
5. **Comportamento** — "Você coloca cupom de 20% pra aparecer mais no iFood e no fim do mês não sobra nada"
6. **Crença** — "Não é o iFood que traz cliente pro seu delivery. É seu delivery que sustenta o iFood." (vai contra crença comum)
7. **Rotina** — "Acorda, confere estoque, prepara cozinha, abre app, reza pra chover..."

> "Sempre que o cliente reclama 'leads não são qualificados', e a culpa é do gestor, é porque o gestor não conseguiu colocar fator de segmentação no anúncio."

### Elemento 4 — Estrutura GCC (Gancho + Corpo + CTA)

#### Gancho (primeiros 3 segundos)
> "Para o dedão da pessoa quando ela tá escrollando."

**3 tipos de gancho** (use combinados):
- **Falado** — primeiras palavras ditas
- **Escrito** — texto na tela
- **Visual** — o que aparece visualmente

**Função do gancho falado**: criar sensação de "tão falando comigo" OU gerar contraste/dúvida/curiosidade/surpresa.

**Função do gancho escrito**: NÃO repetir o falado (maior erro das pessoas). Ele deve fazer um **looping** ou dar **spoiler** do que vem.

Exemplo Sobral: vídeo do casamento dele
- Falado: "Vidoca, você sempre esteve comigo nos momentos fáceis e difíceis..."
- Escrito: "O casamento ia ficar muito caro, então tive que colocar anúncios nos meus votos"
- Visual: terno + ambiente claramente de casamento

> "44% dos usuários do Instagram assistem sem som. Nunca subestima o gancho escrito."

**4 tipos de gancho falado**:
1. **Pergunta** — conecta com dor/desejo/situação ("Quantas vezes você já fez a unha e em 3 dias estava descascando?")
2. **Sacada contraintuitiva** — vai contra crença comum ("A melhor maneira de ter unha por mais tempo NÃO é gel")
3. **História** — pessoa se vê na situação ("Uma cliente minha chegou aqui depois de chorar num salão...")
4. **Anúncio segmentado** — fala com público específico desde o início

#### Corpo
O que está sendo divulgado, pra quem, onde, quando.

#### CTA (Call to Action)
Pra onde a pessoa vai — chamada pra ação.

### Elemento 5 — Quantidade + Qualidade

**Não basta um único anúncio.** Produzir muito.

#### O que a ferramenta considera anúncio ruim (Meta/Google):
- Alguém oculta o anúncio
- Alguém oculta todos os anúncios do anunciante
- Oculta devido à repetição
- Denuncia
- Clica e desiste depois (não chega/não interage com a página)
- Vai até a página e fica muito pouco tempo

---

## Palavra-chave da aula: **manicure**

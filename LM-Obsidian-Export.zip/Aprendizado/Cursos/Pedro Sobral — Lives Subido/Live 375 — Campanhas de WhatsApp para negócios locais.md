---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 375
tema: Meta Ads — Campanhas de WhatsApp passo a passo + atendimento + cliente oculto
status: completa
tags: [tráfego-pago, meta-ads, whatsapp, sobral, negócio-local, campanha-de-mensagem, cbo, abo, cliente-oculto, follow-up]
---

# Live #375 — Como criar campanhas de WhatsApp para negócios locais

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 375]]

> Passo a passo da campanha de WhatsApp + análise de dados (gerenciador + WhatsApp Business) + 19 regras de ouro de atendimento + cliente oculto.

---

## Big Idea

> "O grande segredo não tá nos botões do gerenciador, mas no que acontece DEPOIS que a pessoa clicou no anúncio e foi até o WhatsApp."

Reclamação clássica do cliente: "lead não tá qualificado". Sim e não. Existe ponta de verdade pros dois lados. O gestor que vence é o que sabe:
1. Criar bons anúncios com filtro de público
2. Analisar dados (gerenciador + WhatsApp Business)
3. Avaliar atendimento (cliente oculto)
4. Diagnosticar onde o lead morre — no tráfego ou no atendimento

---

## PARTE 1 — Setup técnico passo a passo

### Passo 1 — Acessar gerenciador (conta é do cliente)
Quem é dono da conta = cliente. Cliente libera acesso pro email do gestor.

### Passo 2 — Escolher objetivo da campanha

A Meta tem 6 objetivos. Pra WhatsApp servem **3**:

| Objetivo | Resultado |
|---|---|
| **Tráfego** | Pra mensagem raramente vence. Não começa por aqui. |
| **Engajamento** | ⭐ Melhor pra começar. Mais volume de mensagens, custo mais barato. |
| **Vendas** | Menos volume, **tendência (não regra)** de leads mais qualificados. |

**Recomendação**: começa com **Engajamento**. Quando tiver dado, testa Vendas em paralelo.

### Passo 3 — Manual, não personalizada
Quem sabe manual sabe personalizada. Personalizada = Meta tomando controle. Começa manual.

### Passo 4 — Nomenclatura
Padrão: `[OBJETIVO] - [PROPÓSITO] - [CLIENTE]`
Ex: `[Mensagem] Vendas Delivery XYZ`

> "Parece bobo mas em médio/longo prazo deixa trabalho mais profissional e dados fáceis de ler. Taxonomia."

### Passo 5 — CBO vs ABO

- **CBO (Orçamento da campanha / Advantage)** = você dá um valor, Meta distribui entre os públicos. **Use isso no começo.**
- **ABO (Orçamento do conjunto)** = você define quanto cada público recebe. Pra casos específicos.

### Passo 6 — Diário vs Total

- **Diário**: campanha roda 24h por dia. Recebe mensagem de madrugada.
- **Total**: período + horário específicos (ex: 1 semana × R$20/dia = R$140, seg-sáb 8h-18h).

**Pra negócio local com horário comercial: Total + programação de horário.**

### Passo 7 — Conexão do WhatsApp (vs Direct vs Messenger)
- **WhatsApp** > Direct > Messenger (ordem de eficácia)
- **Direct (Instagram)** vence quando você quer automatizar com **ManyChat**
- **Messenger** é o que menos funciona
- Configurar: país + número + código de verificação

### Passo 8 — Custo e período
- Data início e fim
- Marca quadradinhos de horário e dia da semana (cada quadrado = 1 hora)

### Passo 9 — Públicos

#### Desativar Advantage Plus → ir pra "opções originais de público"

> "Anunciar não é sobre aparecer pra todo mundo, é sobre aparecer pras pessoas certas. Limitar é bom."

**Geolocalização + demográfico (básico):**
- Cidade → mudar de "raio de 40km" pra **"apenas cidade atual"**
- Pra negócio local: **pino no endereço + raio de 1km**
- Idade + gênero conforme público

**Dica avançada**: ativar **"apenas pra quem está conectado a Wi-Fi"** corta turista de passagem.

#### Públicos frios (sempre criar):
- **Semelhantes (Lookalike)** de: lista de clientes, lista de engajamento, lista de quem já mandou mensagem
- **Direcionamento detalhado** (interesses):
  - Óbvios do nicho (barbearia → barba, cabelo)
  - **Alta renda**: viajantes internacionais frequentes, marcas **menos mainstream** (Patek Philippe, Zegna, Estée Lauder, Hermès, Dior, Loubotin, Brunello Cucinelli) — NÃO Louis Vuitton, Rolex, Gucci (todo mundo conhece, perde o filtro)

⚠️ **Cuidado com direcionamento detalhado**: ao adicionar QUALQUER interesse, vira **Advantage Plus expandido** (Meta vai além da sua segmentação). Teste isolado.

#### Públicos quentes:
- Envolvimento (viu anúncio, visitou site)
- Listas (clientes, leads, contatos)

#### 🔑 Estratégia de ativação de WhatsApp antigos (grana sem gastar em ads)

1. Pega contatos antigos do WhatsApp do cliente (clientes inativos, quem já mandou mensagem)
2. Manda mensagem pessoal: "Oi, quer participar do grupo VIP da [marca]?"
3. Lista de benefícios: descontos especiais, serviços exclusivos, horários prioritários
4. Quem aceitar → entra num grupão de WhatsApp
5. **Em uma semana já dispara primeira oferta** pro grupo

E paralelamente: clientes que não compram há +90 dias → oferta específica de retorno no 1:1.

> "Você gera resultado com os ativos que o cliente já tem, antes mesmo de gastar em ads."

### Passo 10 — Posicionamento
- **Advantage** funciona pra começar
- Manual + **só Instagram** quando quer **poder aquisitivo mais alto** ou **qualidade de leads** melhor

### Passo 11 — Criativo
- Imagem ou vídeo (já criado previamente)
- Coloca **5 variações de título + 5 de texto** — Meta combina e descobre o que funciona
- Aproveita **geração de imagens da própria Meta** (gratuita) — mas **revisa texto, IA ainda erra**
- **Desativa todos os "aprimoramentos"** — pioram o anúncio

### Passo 12 — Configurador de conversa (template do WhatsApp)
Quando a pessoa clica, **abre WhatsApp com mensagem inicial automática**.

- **Recomendação: mensagem pronta** (não FAQ — só FAQ se for 2-3 perguntas universais)
- Ex: "Oi, vi o anúncio de vocês e gostaria de agendar um horário"

Salva → confere → publica.

---

## OS 3 FILTROS QUE DEFINEM A QUALIDADE DO LEAD

> "Maior problema #1 disparado de campanha de WhatsApp: anúncio atraindo público errado por falta de filtro."

### Filtro 1 — Objetivo
- Engajamento → mais mensagens, qualidade menor
- Vendas → menos mensagens, qualidade maior (tendência)

### Filtro 2 — Segmentação
- Advantage → abre demais
- Manual com camadas: geo 1km + idade 25-45 + homens + Wi-Fi + só Instagram. **Cada filtro a mais corta público errado.** MAS não pode exagerar — sem ninguém pra aparecer, sem resultado.

### Filtro 3 — O ANÚNCIO (mais importante)

O anúncio precisa:
- **Ser filtro do público certo**
- **Comunicar o que acontece depois que clica**

"Tenho muitos cliques mas pouca gente chamando" = o anúncio não deixou claro o que ia acontecer.

**Frase do Jay Abraham**: "Às vezes a melhor copy pra vender um cavalo é dizer 'cavalo à venda'."

**Exemplo Sobral pra captar dentistas** (resposta a uma DM real):
> "Procura-se dentistas que querem triplicar o número de clientes particulares — sem venda de curso, sem fórmula mágica, sem promessa mirabolante, seguindo todas as normas do CFO/CRO."

3 elementos do anúncio:
- Primeira frase / 3 primeiros segundos do vídeo = falar diretamente com o público
- Descrição simples + título em poucas palavras
- CTA pra pessoa mandar mensagem ("clica aqui e me manda mensagem")

**Aprofundamento de copy**: live de copywriting (372/373) cobre isso.

---

## PARTE 2 — Análise de dados (depois de publicar)

> "Tráfego pago não é sobre apertar botões da ferramenta — é sobre apertar botões das pessoas. Mesmo quem é de humanas consegue."

### Dados do gerenciador
- **Número de conversas iniciadas**
- **Custo por conversa iniciada**
- **CTR** (taxa de clique) → mede o quão atrativo está o anúncio
- **CPM** (custo por 1.000 impressões) → mede o quão caro está aparecer pra essa segmentação

### Dados do WhatsApp Business ⭐ (quase ninguém analisa)
- Mensagens **enviadas**
- Mensagens **entregues** (chegaram nos dois tracinhos)
- Mensagens **lidas**
- Mensagens **recebidas**

### Taxas calculadas
- **Taxa de entrega** = entregues / enviadas
- **Taxa de leitura** = lidas / entregues
- **Taxa de retorno** = recebidas / lidas

> "Mede a eficiência do WhatsApp que a maior parte dos gestores não implementa."

---

## PARTE 3 — As 19 Regras de Ouro do Atendimento WhatsApp

(Sobral chamou de "20 regras de ouro" mas pulou o nº 13 — "porque dá azar")

### 1. Seja rápido
Quanto mais rápido responde, maior chance de fechar.

### 2. Poupe tempo do cliente
Antecipa o que ele quer. **Não faz ping-pong de mensagem.**

> "Oi, vocês estão atendendo?" → "Sim, estamos." → "Têm cardápio?" → "Temos." → "Podem enviar?" → "Sim, enviando."
>
> Errado. Primeira mensagem já manda tudo: "Sim, atendendo. Aqui o cardápio. Pagamento Pix/cartão/maquininha."

### 3. Gramática e ortografia em dia
Usa ChatGPT se precisar. **Evita "vc", "pq"** — fica feio, não profissional.

### 4. Atendimento personalizado
Chama pelo nome, lê histórico das mensagens.

> "Quem mandou mensagem uma vez, é OBRIGAÇÃO ter o nome salvo. Quando responder: 'Oi Pedro, vai querer o mesmo pedido da última vez?' Aquilo já me ganha."

### 5. Conversa como se tivesse olhando no olho
Usa **princípio do espelhamento** — emula a comunicação do cliente. Não enfia figurinha em quem é sério.

### 6. (Sem número claro — Sobral pulou) Evita áudio ou texto muito longo OU muito curto

> "Áudio de 3 segundos? A pessoa acha que o tempo dela é mais importante que o meu. Digita."

### 7. Envia mensagens **cadenciadas**
Não manda blocão. Separa em bloquinhos menores.

### 8. Usa recursos de edição do WhatsApp
Negrito, itálico pra destacar o que é importante. **Maioria escaneia, não lê.**

### 9. Pix, telefone, endereço — UMA mensagem cada
```
Pix:
[próxima mensagem]
[número limpo]

Endereço:
[próxima mensagem]
[rua, número]
```
Não junta tudo. Fica fácil de copiar.

### 10. Seja simples e claro
Não exagera em termos técnicos.

### 11. Não força intimidade
Seja **uma pessoa falando com uma pessoa**, não uma marca falando com uma pessoa.

### 12. Foto do atendente no perfil
Não a logo da marca. Humaniza.

### 14. Foca em resolver o problema do cliente

### 15. ⭐ FOLLOW-UP do cliente que parou de responder
> "Todo mundo erra nisso. Cliente parou de responder, manda 'Opa, viu minha mensagem? Tem alguma dúvida?'"

> "Eu sou péssimo de WhatsApp. Mas é porque ninguém faz follow-up comigo. Se precisar da resposta — encha o saco até responder."

### 16. Seja desenrolado na venda

### 17. Configure mensagens automáticas do WhatsApp Business
- **Ausência**: "Não estamos atendendo. Horário X a Y."
- **Saudação**: continuação da conversa do anúncio
- **Respostas rápidas** (até 50): digitar `/agradecimento`, `/dados`, `/endereço`, `/pix`, `/cardápio`, `/banco`, `/produto`. **Aumenta produtividade 2-3x.**
- **Etiquetas/tags**: novo cliente, novo pedido, pagamento pendente, pago, pedido finalizado

### 18. Tenha controle do funil (CRM)
**Kommo CRM** é o que ele recomenda. Tem curso completo de 51 aulas dentro da comunidade Subido.

### 19. Faz perguntas pra manter conversa fluindo
Não responde tudo com ponto final.

### 20. (Reforço) FAÇA FOLLOW-UPS
> "Não fazer follow-up é o maior motivo dos clientes perderem vendas."

---

## PARTE 4 — CLIENTE OCULTO (superpoder pra fechar e reter cliente)

**Cliente oculto** = fingir que você é cliente do seu cliente. Espião no WhatsApp dele pra ver o que ele faz de certo e errado.

### 2 processos (Sobral entrega como material via DM "live 375")

#### Cliente Oculto Ativo
Você manda mensagem no WhatsApp do cliente fingindo ser comprador. Avalia o atendimento ao vivo.

#### Cliente Oculto Retroativo (análise de conversas antigas) ⭐ Mais valioso

Para clientes que **você já fechou**:
1. Cliente reclama "lead tá desqualificado"
2. Você responde: "Entendo. Muitos gestores não usam as melhores práticas. Vou me esforçar pra entregar lead qualificado. Mas se você não se importar, posso fazer uma **análise dos seus atendimentos do WhatsApp**?"
3. Pega o histórico de conversas antigas (últimas 2 semanas)
4. Aplica o checklist das 19 regras de ouro
5. Encontra um monte de erro (não atende com profissionalismo, sem follow-up, etc)
6. Gera **relatório com pontuação + classificação + exemplos**

### A analogia do Patrick Estrela
> "Cliente liga: 'É do Siri Cascudo?' — 'Não, aqui é o Patrick.' [desliga]. Repete a chamada: 'É do Siri Cascudo?' — 'Não, aqui é o Patrick.' Atendimento péssimo. Mas se você não sabe avaliar o atendimento, o culpado vai sempre ser o tráfego pago."

### Como entregar pro cliente (sem soar arrogante)

Script profissional sugerido pelo Sobral:
> "Olha, eu tomei a liberdade de fazer uma análise do seu atendimento e dos seus atendentes nas últimas 2 semanas. Encontrei vários pontos de melhora. Tem um relatório aqui pra você, se quiser usar pra melhorar o atendimento. Eu sei que você como empresário sabe quão desafiador é ter um bom time de marketing e um bom time comercial. Espero que esse material te ajude."

> "Se tiver interesse de bater um papo sobre como eu poderia te ajudar a gerar melhores resultados nos seus anúncios, segue meu WhatsApp."

**Bonus**: cliente oculto retroativo é também a melhor maneira de **fechar cliente novo** — apontar problemas que o atual gestor não vê.

---

## Palavra-chave da aula: **Sherlock**

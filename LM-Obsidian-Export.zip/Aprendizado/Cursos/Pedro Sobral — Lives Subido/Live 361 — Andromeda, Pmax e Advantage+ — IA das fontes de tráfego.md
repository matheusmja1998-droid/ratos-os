---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 361
tema: IA das fontes de tráfego — Andrômeda, Advantage+, Performance Max
status: completa
tags: [tráfego-pago, meta-ads, google-ads, ia, andromeda, advantage-plus, performance-max, sobral, 2026]
---

# Live #361 — Andrômeda, Pmax e Advantage+: como usar a IA das fontes de tráfego em 2026

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 361]]

> Explicação dos sistemas de IA que automatizam decisões dentro da Meta e do Google, e como usar isso a favor sem ser substituído.

---

## Big Idea

O trabalho do gestor é **dar informações pra plataforma**. A plataforma processa essas informações por meio de inteligência artificial e devolve resultado. Andrômeda (Meta), Advantage+ (Meta) e Performance Max (Google) **não vão te livrar do trabalho** — vão deixar o trabalho 2.0.

> "A gente busca a perfeição da campanha na otimização, não na criação."

> "O jogo muda do saber apertar botão pro saber pensar tráfego."

---

## Como funciona a relação anunciante × plataforma

1. **Gestor dá informações** (objetivo, orçamento, segmentação, criativo)
2. **Plataforma processa** as informações com inteligência artificial
3. **Plataforma decide** onde mostrar o anúncio, pra quem, em qual horário, qual criativo

Cada campo do gerenciador é uma **pergunta** que a plataforma faz. Tudo é informação.

---

## O que é Andrômeda (Meta)

Atualização da infraestrutura de IA da Meta. Foi anunciada em **2024** (artigo em engineering.facebook.com), mas só virou frenesi no fim de 2025. **Já estava afetando suas campanhas antes do anúncio.**

> "Ocorrência ≠ causalidade. Seus resultados caíram porque tá chovendo lá fora?"

### O que a Meta diz sobre Andrômeda
3 parágrafos relevantes do artigo oficial:

1. **A IA prevê qual anúncio cada pessoa vai achar mais interessante** — vai cada vez mais colocar o anúncio certo na frente da pessoa certa.

2. **Vai aumentar significativamente o número de criativos recomendados por sistema.** Tradução: **mais anúncios por conjunto de anúncio** (antes: limite de 6 → agora pode chegar a 8-15).

3. **Andrômeda melhora a performance e maximiza o retorno por gasto.**

### Para o gestor de tráfego
- Mais performance "de graça"
- Advantage+ fica mais inteligente
- Criativos gerados por IA começam a escalar de verdade
- Segmentação preditiva mais forte
- Menos dependência de "escolher segmentação perfeita"
- Entrega mais estável e previsível
- Vantagem competitiva pra quem sabe estratégia (não botão)
- Mais volume de anúncios qualificados → mais chance de escalar

---

## A grande mudança: conceitos distintos vs variações

**A Meta agora detecta similaridade visual + narrativa.** Se você gera 50 variações do mesmo anúncio só trocando cor de camiseta ou ordem de palavras, **ela considera tudo como o mesmo anúncio**.

### Recomendação atual: 8-15 anúncios **conceitualmente distintos** por campanha

Como diferenciar de verdade:
- **Formato**: vídeo + carrossel + estático no mesmo conjunto
- **Narrativa**: transformações diferentes, desafios diferentes, bastidor do produto
- **Gancho**: pergunta, segmentação implícita, urgência, dor, desejo
- **Ângulo**: dor diferente do mesmo problema, desejo diferente, profissão específica
- **Público implícito**: anúncio segmentado por subnicho (ex: professor de medicina vs professor de área específica)

### Exemplo do Sobral (vendendo livro sobre andragogia)
- **Anúncio com dor**: "Já se viu em situação onde explicou um conceito simples e ninguém entendeu?"
- **Anúncio com desejo**: "Lembra daquele professor que toda a turma admirava? E você quer ser admirado pelos seus alunos."
- **Anúncio com segmentação implícita**: "Por acaso parte do seu trabalho é passar conhecimento pra outras pessoas?"
- **Anúncio com contraintuitivo**: "A pior maneira de ensinar alguém é explicar."
- **Anúncio com urgência**: "Você só tem 1 semana pra garantir o livro pelo menor preço."

---

## Antes × Depois da Andrômeda

### Antes
- Muitos públicos de interesse, lookalikes, "cebola" de microssegmentações
- Muitas campanhas e muitos conjuntos de anúncio (estrutura complexa)
- Pequenas variações de anúncio (mudar CTA, fundo)
- Crescimento dependia de refinamento meticuloso

### Depois (Andrômeda)
- **Segmentação mais ampla** (Meta recomenda menos fracionamento)
- **Estrutura mais simples** com mais anúncios em um único conjunto
- **Diversidade real de conceito** (visual, narrativa, formato, gancho, ângulo, perspectiva)
- **Automação permite escalar mais rápido** e testar mais rápido

---

## O que NÃO mudou
A Meta ainda precisa de informações. Você ainda:
- Seleciona objetivo
- Define orçamento
- Faz segmentação (ou dá sugestão)
- Cria anúncios que conversam com dores, desafios, desejos

**Para de achar que Andrômeda/Advantage+/Pmax te livram do trabalho.**

---

## Campanhas automatizadas — o que elas automatizam

4 áreas:
1. **Segmentação** (pra quem aparecer)
2. **Posicionamento** (onde aparecer)
3. **Testes de anúncio** (carrossel × vídeo × imagem)
4. **Alocação de verba** entre os diferentes anúncios/públicos

---

## Os 4 recursos Advantage+ da Meta (+ campanha completa)

### 1. Orçamento Advantage
**Use em 99% dos casos.** Antes era ABO (você decide quanto cada público recebe). Agora a campanha decide.
- Foco em escala
- Não precisa controlar orçamento por público
- Não entende otimização de orçamento manual

### 2. Público Advantage
**Use quando:**
- Foco em escala / aparecer muito
- Não está anunciando em região extremamente específica
- Essa campanha complementa uma estratégia maior

**Não use quando:**
- Negócio local com região específica (Advantage anuncia fora da região)

### Segmentação vs Sugestão de segmentação ⭐
- **Segmentação** = você escolhe pra quem aparecer (define)
- **Sugestão de segmentação** = você dá dicas, mas a Meta decide

Hoje:
- Direcionamento detalhado (interesses) **agora é sugestão, não segmentação**
- Ao adicionar qualquer interesse, a Meta exibe "Direcionamento detalhado Advantage+ aplicado" — ela expande seu público

**Recomendação Sobral**: sempre testar sugestões de segmentação com **públicos quentes** (pessoas que já interagiram com sua marca).

### 3. Posicionamento Advantage
**Use em 80% dos casos.** Não use quando:
- Tem anúncios específicos pra um posicionamento (ex: anúncio que fala "se você tá vendo esse story...")
- Quer qualificação de renda (público com mais grana). Quem usa Facebook desktop costuma ter menos dinheiro — não é preconceito, é dado. Pra renda alta, usar manual com **só Instagram**.

### 4. Criativo Advantage
**Sempre desativar** o recurso de "automaticamente melhorar seus anúncios". "Ainda é muito ruim. Quando melhorar eu aviso."

Sempre colocar **múltiplos títulos, descrições e imagens** dentro do anúncio.

### Campanha Advantage (completa)
Quando todos os recursos estão ligados → você recebe 100% de pontuação da campanha. **Não significa que você sempre tem que usar isso.**

---

## Performance Max (Pmax — Google)

O **tudo em 1** do Google. Aparece em:
- Pesquisa do Google
- YouTube
- Gmail
- Discover
- Sites parceiros (GDN — Google Display Network)
- Apps no Google Play

### O que você fornece
- Indicador de público alvo (sugestão)
- Anúncios de texto, vídeo, imagem (precisa dos 3 pra todas as plataformas)

### O que ela automatiza
- Escolha de palavras-chave
- Segmentação de público
- Alocação de verba por canal (Google, YouTube, Gmail, Discover, GDN, Apps)
- Criativo (título, descrição, imagem, vídeo)

### Quando usar Pmax
- **Sempre que quer escalar** pra **e-commerce** → maravilhoso
- **Negócio local pra visitas presenciais** → "palhaçada de boa"
- Pra geração de lead → **cuidado, pode trazer lead lixo**

---

## 8 regras de ouro das automatizações

1. **Combo > Solo** — usa Advantage mas mantém **campanhas paralelas mais controladas** (remarketing, públicos quentes específicos)

2. **Não funcionou no passado ≠ não vai funcionar agora.** Teste regularmente o que rejeitou antes.

3. **Use cada recurso como um teste.** Ativa, observa o resultado, desativa, compara. Se piorar, volta.

4. **Se você é iniciante e só quer vender → começa rodando só Advantage**. Pode ser um bom teste pra começar.

5. **Se a campanha não vende direto (gera lead) → sempre avalia a qualidade do lead que vem**.

6. **Cuidado com Advantage de público pra negócio local.** Você pode anunciar fora da região de atuação.

7. **Se o seu criativo é uma bosta, Advantage não salva.** Volta pro criativo.

8. **Pixel mal instalado mata tudo.** Sem pixel trazendo dados, a Meta demora pra entregar pras pessoas corretas (e pode nem entregar). Pixel correto = fator determinante.

---

## Regras complementares

- **Reserva** (modo de compra): só usar em raros casos. Você "reserva" o CPM de hoje pra anunciar no futuro (ex: outubro reserva pra Black Friday em novembro). Limitado a objetivos de **reconhecimento e engajamento**.
- **Antes**: aulas sobre "relevância estatística" eram comuns. Hoje esse termo já não é mais relevante.

> "A inteligência artificial veio pra deixar o seu trabalho turbinado 2.0, não pra roubar."

---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 346
tema: Como começar no tráfego pago — Tutorial simples e prático
status: completa
tags: [tráfego-pago, gestor-de-tráfego, carreira, sobral, prospecção, iniciante, faturamento]
---

# Live #346 — Como começar no tráfego pago: um tutorial simples e prático

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 346]]

> Os 5 passos para começar a ganhar dinheiro com gestão de tráfego do zero, com dados reais de quanto gestores faturam.

---

## Big Idea

A melhor maneira de ganhar dinheiro na internet começando do zero é **prestando serviço de tráfego pago para outras empresas**. Toda empresa precisa anunciar. Logo, toda empresa precisa de um gestor de tráfego.

> "Eu vendo a coisa mais fácil do mundo: eu vendo dinheiro. Não vendo um custo — vendo um serviço que coloca mais dinheiro no bolso do cliente do que ele me paga."

---

## Os 5 Passos para começar

1. Entender como o tráfego pago funciona
2. Saber como ganhar dinheiro com isso
3. Dominar as habilidades mínimas
4. Encontrar o primeiro cliente
5. Saber o que fazer depois de fechar (ou não)

---

## PASSO 1 — Como o tráfego pago funciona

### A moeda mais valiosa é a atenção

Google/Meta valem bilhões porque detêm **a atenção das pessoas**. Negócios são construídos em cima da atenção.

Exemplos offline: o vendedor de milho na praia gritando, o carrinho de picolé com buzina — pegando atenção.

### Marcas chamam atenção de 2 maneiras
1. **Organicamente** (publicações sem pagar)
2. **Tráfego pago** (pagando pra aparecer)

### Como uma marca paga (6 passos)
1. **Cliente cria conta** no gerenciador de anúncios (gratuito)
2. Cliente escolhe **objetivo de campanha**
3. Cliente define **quanto vai gastar**
4. Cliente seleciona **para quem aparecer**
5. Cliente **sobe os anúncios**
6. Cliente **paga** toda vez que o anúncio é mostrado ou alguém clica

### Pontos importantes
- **A conta de anúncios é sempre do cliente**, não do gestor. Cliente libera acesso para o e-mail do gestor.
- **Gestor de tráfego não cria anúncio** (imagem/vídeo). Quem cria é o cliente. Se cliente não sabe, contrata alguém — pode ser outro gestor da própria comunidade Sobral fazendo o serviço.
- Hoje celular substitui câmera profissional pra criar anúncio.

---

## PASSO 2 — Como ganhar dinheiro com tráfego pago

O cliente paga o gestor pra **operar as fontes de tráfego** (Google, Meta, TikTok, LinkedIn) e **criar estratégias** que coloquem dinheiro no bolso dele.

> "Quanto mais dinheiro eu ponho no bolso dos outros, mais dinheiro eu ganho."

### Dados de faturamento (base: 55k alunos Sobral)

| Tempo na profissão | Faturamento médio/mês | Nº médio de clientes |
|---|---|---|
| <1 ano | R$ 6.304 | 4 |
| 1 ano | R$ 10.000 | — |
| 2 anos | R$ 16.000 | — |
| 3 anos | R$ 23.000 | — |
| 4 anos | R$ 27.000 | — |
| 5 anos | R$ 30.000 | — |
| **Primeiro mês** | **R$ 1.523,12** | — |

> "Quase batendo o salário mínimo no primeiro mês — esse é o sonho com gestão de tráfego."

### Cobrança média por tipo de cliente

| Tipo | Média/mês |
|---|---|
| Negócio local | R$ 1.000 |
| Perpétuo (infoproduto) | R$ 1.000+ |
| E-commerce | R$ 1.700 |

### Iniciante (zerado)
- Negócio local: **R$ 300–500/mês** por cliente
- Atende ~10 contas com facilidade → **R$ 3.000–5.000/mês**
- E-commerce: R$ 500–1.000, 7-10 contas

### Trabalhar pra agência (cargo "Juninho")
- Grupo de donos de agência consultado (100+ pessoas, faturamento médio R$100k/mês):
- Pagam **R$ 100–200 por conta** pro iniciante operacional
- 20 contas tranquilamente
- Você não faz prospecção/comercial, só operacional

### Comparativo de salário mínimo
- 2025: R$1.518
- Gestor cobra **menos do que um salário mínimo** mas é "o prestador de serviço que mais coloca dinheiro direto no bolso do cliente". Comparar com função como limpeza (super importante, mas não traz cliente direto).

---

## PASSO 3 — MCV (Menor Conhecimento Viável)

Inspirado em MVP (Minimum Viable Product). Sobral cria o conceito de **MCV** = o mínimo que você tem que saber pra começar.

### Os 7 conhecimentos mínimos:
1. **Criar conta de anúncio** e configurar formas de pagamento (mesmo que seja do cliente)
2. **Mínimo sobre persona** — saber descrever o público com quem está falando
3. **Configurar segmentações** — saber escolher pra quem aparecer
4. **Pesquisar referências de anúncio** na biblioteca de anúncios
5. **Criar campanhas básicas**: mensagem pro WhatsApp + rede de pesquisa + usar botão turbinar de forma inteligente
6. **ABC de otimização**: entender funil de métricas, mexer orçamento, pausar público ruim, pausar anúncio ruim
7. **Conseguir clientes**

> "Se você não tem cliente, não é gestor de tráfego. É um entusiasta, um estudante, um hobby — mas não é gestor."

---

## PASSO 4 — Onde achar o primeiro cliente (fácil)

> "Se eu sento do seu lado por 10 minutos, eu saio dali com a próxima reunião marcada. Executando o simples."

O primeiro cliente está em **um destes 4 lugares**:
1. **Seu WhatsApp** (contatos)
2. **Seus seguidores do Instagram**
3. **Seguidores dos seus amigos**
4. **Pessoas que vendem serviço pra você**

### Exemplo prático do Sobral
Naquele dia viu o barbeiro dele tirando uma tatuagem. Poderia mandar mensagem: "Ô Gui, vi que tirou tatuagem. Tá em alta uma galera tirando. Tô trabalhando com anúncios online, você não me passa o contato dessa pessoa pra eu sondar interesse?"

### O obstáculo
"Tenho vergonha." → "Aí você vai ser um pobre envergonhado."

> "Sabe o que vão pensar quando você tiver ganhando R$10/15/20k por mês? Vão dizer: 'Pra fulano foi fácil. Teve sorte. Foi da noite pro dia.' Essas são as frases do sucesso."

### Exercício
Abrir lista de contatos do WhatsApp. Ler nome por nome. Identificar quem é dono de negócio, quem trabalha em empresa, quem pode indicar.

> "99,9% das pessoas nunca vão fazer isso. É tão simples que é fácil de não fazer."

---

## PASSO 5 — O que fazer depois (investir em você)

### Quanto custa sua hora?
- Sobral hoje: R$ 20.000/hora em consultoria
- Sobral no passado: R$ 7/hora (estágio, 48h/mês por R$ 360)

> "Se a sua hora não está cara como você gostaria, é porque você não investiu o suficiente em você."

### A diferença entre quem ganha e quem não ganha: pressão

> "A execução não nasce da motivação. Não nasce da vontade. Nasce da pressão."

Pergunta-teste: "Qual a chance de você faturar R$1M em 12 meses?" → "Pô, 5%, 10%."

Agora: "Se você não faturar R$1M em 12 meses, sua família morre estilo jogos mortais." → **Automaticamente surge pressão → execução**.

> "Pressão é um privilégio das pessoas que decidem executar."

### Por que pagar pelo curso
"Surra de boleto." Você se compromete financeiramente → vira pressão real → executa.
- Rodízio de sushi: "Vou dar prejuízo"
- Sem compromisso financeiro: procrastina, vira mais um item na lista

---

## A Comunidade Subido (estrutura mencionada na live)

6 cursos dentro:
1. **Tráfego pago do zero** (Meta, Google, TikTok, LinkedIn, bloqueios e contingência, SOS Tráfego)
2. **Prospecção e vendas** (com SOS Prospecção pra fechar rápido)
3. **Especialização** (negócio local, e-commerce, lançamento, perpétuo, Google Meu Negócio, branding, Merch Center)
4. **Habilidades complementares** (automações, CRM em breve, IA pra gestores)
5. **Dados, traqueamento e relatórios** (Tag Manager, Analytics, Looker Studio)
6. **Lives + lives temáticas por nicho** (100+ nichos: imobiliária, estética, petshop, dentista, delivery, hamburgueria, floricultura, agência de modelo, viagem, autoescola, marmitaria, etc)

### Funcionalidades de IA dentro do produto
- **Subido Cast**: áudio diário que expira em 24h
- **A** (IA por aula): tira dúvida sobre o conteúdo, cria provinha, analisa conhecimento
- **ABC** (Apertando Botões Comigo): tutorial passo a passo onde o aluno clica em cada botão guiado pelo sistema
- **Rota de Estudos**: questionário inicial → IA define quais aulas assistir em cada dia → PDF baixável
- Material de apoio em PDF por aula

### Estrutura de inscrição
- Acesso de 1 ano
- Inscrições abrem ~1× por ano (próxima na semana seguinte à live)
- Pré-inscrição garante R$300 de desconto

> "Quem só tem hobby tem entretenimento. Quem tem cliente tem profissão."

---

## Palavra-chave da aula: **Jabuticaba**

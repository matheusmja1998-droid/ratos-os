---
tipo: transcrição
live: 346
tema: Como começar no tráfego pago — Um tutorial simples e prático
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #346

> Como começar no tráfego pago — Um tutorial simples e prático

Resumo e aplicação: [[Live 346 — Como começar no tráfego pago]]

---

Bem-vindos, bem-vindos à nossa live número 346, como começar no Tráfego
Pago. Um tutorial simples e prático. Pedro, eu já sei tráfego pago, eu
já até entendo um pouco de tráfego, já tenho clientes. Essa live vai
servir para mim, vai servir para você também. Por quê? Porque por mais
que você entenda de tráfego pago, por mais que você tenha clientes, a
maneira com a qual eu vou simplificar o tráfego pago aqui vai te ajudar
e muito a vender o tráfego pago pros seus clientes. E você que tá
começando agora aí, você tá na live certa para começar com o pé direito,
porque eu vou te trazer todo o passo a passo, vou esclarecer todas as
dúvidas que você tem, até as dúvidas que você nem sabe que você tem, ou
é, é aquilo, né? Tem as coisas que eu sei, tem as coisas que eu não sei
e tem as coisas que eu não sei que eu não sei. E a gente vai abordar
esses três pontos aqui, as dúvidas que você tem, as dúvidas até mesmo as
que você não tem. E se você tá se perguntando, sim, nós estamos a 346,
terças-feiras, todas as terças às 3 horas da tarde, entregando conteúdos
sobre tráfego pago e anúncios online aqui neste nosso querido canal do
YouTube. E uma das perguntas que eu mais recebo de longe de todo mundo
que quer começar a ganhar dinheiro com tráfego pago é: Pedro, como que
eu começo no tráfego pago? Qual é a melhor maneira de começar no tráfego
pago? Como que ganha dinheiro com isso? Eu ainda não entendi. Como que
ganha dinheiro através do digital, através da internet? E quando a gente
tá falando de como ganhar dinheiro através da internet, existem várias
maneiras de você fazer isso. Eu posso, por exemplo, eh, prestar serviço
para outras empresas. Eu posso vender produtos para outras empresas.
Esses produtos podem ser digitais. Por exemplo, eu vendo um produto
digital para outras empresas, um curso online, um e-book, mas a maioria
das pessoas que estão começando na internet, para elas, eu digo uma
única resposta, que é a melhor maneira de você começar ganhando dinheiro
na internet é você prestar serviços para outras empresas. Pedro, como
assim prestar serviço para outras empresas? Imagine o seguinte, existe
um ambiente físico, o offline, e existe um ambiente onde as empresas
estão, o online. Quando a empresa tá no online, ela ela precisa de uma,
sei lá, de um alguém que vai limpar a empresa, contratar um serviço de
limpeza no online? Não, ela não precisa. Por quê? Porque o online não
suja. Mas quando a empresa está no online, ela provavelmente vai ter que
contratar talvez alguém para divulgar as suas redes sociais, vai ter que
contratar alguém para criar cópias, ou seja, textos persuasivos para
enviar no WhatsApp pros clientes. Então, tem diversos serviços que
quando uma empresa está no online, ela precisa contratar para fazer com
que a empresa funcione, para fazer com que a coisa rode, para fazer com
que a empresa aconteça. E quando nós estamos começando a querer ganhar
dinheiro com a internet, o a menor barreira de entrada que existe para
você começar a ganhar dinheiro é justamente através do desenvolvimento
dessas habilidades que as empresas precisam. E uma coisa é certa, toda a
empresa precisa anunciar na internet. Toda empresa precisa anunciar na
internet. Por quê? Porque anunciar na internet é sobre fazer a empresa
aparecer mais. Anunciar na internet é sobre fazer a empresa conquistar
cada vez mais clientes para o seu negócio. E toda empresa quer aparecer
mais, toda empresa quer conquistar mais clientes. Então o tráfego pago,
ele é a primeira escolha, a mais óbvia de gastos que eu vou ter dentro
da minha empresa quando eu quero entrar na internet, quando eu quero
crescer dentro da internet. E essas empresas vão precisar de um gestor
de tráfego. E aí eu já garanto para você, não existe um caminho mais
fácil e mais rápido para você começar no tráfego pago, para você
desenvolver essa habilidade do que a comunidade subido de tráfego.
Pedro, que que é a comunidade subido de tráfego? Comunidade subido de
tráfego é o meu produto de tráfego pago, tá? Então, como eu falei para
vocês, eu tenho um curso online, é a comunidade subido de tráfego. Aqui
você encontra tudo que você precisa para aprender tráfego pago. Putz, eu
sabia que ele já queria me vender alguma coisa nessa aula, só quer me
vender. Pode ficar tranquilo que se você tem o sentimento de que eu só
quero te vender, não compre nada meu nesse momento, tá? Porque você vai
ver que eu vou te entregar sim conteúdo de graça, de extrema qualidade,
que na maioria das vezes nem nos cursos que você paga você consegue ter
acesso. Mas por acaso, no momento que eu tô fazendo essa live número
346, na próxima terça-feira, 3 horas da tarde, quando eu fizer a minha
live número 347, eu vou abrir as inscrições para a comunidade subido de
tráfego. Então, nós vamos abrir as inscrições na próxima terça-feira e a
pré-inscrição para você garantir a sua entrada na comunidade subido com
desconto já está disponível. Onde que a pré-inscrição já tá disponível?
Ela tá aqui na descrição desse vídeo. Inclusive, se tem alguém aí que
não é meu aluno, mas vai virar meu aluno, já tá certeza que vai virar
subido, manda no chat aí, por favor, um #s subido. Manda aí para mim,
porque eu tenho certeza que tem uma galera aqui. Nós temos mais de
55.000 pessoas, alunos ativos dentro da nossa comunidade de alunos. Ó,
já tem uma galera aí que vai virar subido. Pedro, mas o que que tem
nessa comunidade? Eu tô chegando agora, eu nem sei se vale a pena, não
sei se é para mim. Pode ficar tranquilo que no final da aula aqui eu dou
uma boa explicada para você sobre o que que é a comunidade. Mas se você
tem interesse em construir carreira na gestão de tráfego, ganhar
dinheiro com essa parada com o que eu vou te ensinar aqui hoje, saiba
que o link tá na descrição para você fazer sua pré-inscrição com R$ 300
de desconto. Beleza? Tá, Pedro, vamos lá. Mas eu que tô meio indeciso
ainda, não sei que história que é essa de comunidade subido, como é que
eu começo agora no tráfego pago? Tudo que você precisa são de cinco
passos, Pedro. Só cinco passos. Só cinco passos. Você tem que entender
como é que o tráfego funciona. Você tem que saber como que você ganha
dinheiro com isso. Você tem que dominar ali determinadas habilidades
para você começar. Você tem que encontrar o seu primeiro cliente e você
tem que saber o que fazer depois que você fechou ou que você não fechou
esse primeiro cliente. Então, nós temos que dominar estes pontos aqui.
Se a gente souber esses pontos aqui, você sabe como começar no tráfego
pago. E o ponto número um, por mais óbvio que ele seja, por mais simples
que ele seja, para quem já sabe tráfego pago, é, você precisa prestar
atenção nisso. Porque eu falo assim, ó, que uma das habilidades que você
tem que desenvolver na vida é a habilidade de roubar a didática alheia.
Que que eu quero dizer com roubar a didática alheia? É o seguinte, se eu
falar para você assim: "Putz, você sabe o que que é?" Alguém aqui no
chat que já é gestor de tráfego já ganha dinheiro com isso? Se eu
perguntar assim, você entende como que o tráfego pago funciona? Que que
você me responde no chat? Pode me responder? Você entende? Para qualquer
pessoa que tá aqui no chat, você entende como que o tráfego pago
funciona? Sim, acho que sim. Sim. Nada. Não. Sim. Sim. Beleza. Agora,
para você que entende como que o tráfego pago funciona, imagina que você
acabou de encontrar ou você que não sabe como o tráfego pago funciona.
Imagina que você acabou de encontrar um cliente e esse cliente, um
possível cliente, ele fala assim: "Pô, como é que o tráfego pago
funciona?" Aí você vai, como é que você explica isso para alguém? Como é
que de maneira lógica, didática, metodológica, você transfere esse
conhecimento que tá na sua cabeça, porque você sabe ele. Quando eu
explicar aqui para você, você vai dizer: "Ah, mas isso eu já sabia e eu
sei que você sabe." Só que a questão é: não basta saber. A gente tem que
saber estruturar aquele conhecimento de tal maneira que a pessoa que
está do outro lado, você entenda aquilo também. Então, observa a
explicação e fala assim: "Eu gostei dessa maneira que ele explicou. Eu
gostei dessa explicação. Eu já expliquei na minha vida, pô, sei lá,
centenas, talvez milhares de vezes como que o tráfego pago funciona.
Cada vez eu vou adaptando um pouco. Por quê? Porque eu planejo a aula
sempre do zero aqui para dar entregar esse conteúdo para você. Então, a
cada planejamento vai mudando um pouco e você pode falar assim: "Putz,
eu gostei dessa maneira que ele explicou. Eu vou pegar isso daqui para
mim. Vou colocar isso aqui no meu arsenal de explicações, tá? Então,
para você entender como que o tráfego pago funciona com os meus olhos,
você tem que conseguir me responder essa primeira pergunta. Qual é a
moeda mais valiosa que existe? Alguém sabe qual que é a moeda mais
valiosa que existe? Que que será se a gente for lá no Google, né, e
pesquisar no Google a moeda mais valiosa que existe? Deixa eu dar um
zoom aqui. Ele vai dizer que vale três vezes mais que o dólar. É o dinar
do Quite. Será que é essa a moeda mais valiosa que existe no mundo? O
tempo? Hoje, na minha opinião, a moeda mais valiosa que existe é a
atenção. A atenção das pessoas. Por que que o Facebook, o Instagram, o
Google são empresas avaliadas em bilhões? O próprio chat GPT, porque
eles detém não só a tecnologia, claro que é valioso por causa da
tecnologia, mas eles detém a atenção das pessoas. O que que é a atenção
das pessoas? A atenção das pessoas são os olhos e ouvidos das pessoas.
Não tem nada mais valioso do que isso. Por quê? Porque se eu vou vender
algo para alguém, eu preciso dos olhos e dos ouvidos dessas pessoas. Se
eu tenho nesse instante a sua atenção, ou seja, você tá aqui me vendo,
às vezes você não tá me vendo, você me colocou numa outra aba e você tá
achando que você é o único ser humano do mundo que consegue fazer duas
tarefas ao mesmo tempo. Você tá vendo um story ou sei lá, você tá me
vendo agora, você tá me vendo e me ouvindo, agora eu detenho a sua
atenção. E ter a sua atenção é tudo que eu preciso para vender para
você, para fazer dinheiro, para construir um negócio. Negócios são
construídos em cima da atenção das pessoas. Alguém aqui já foi na praia
e já viu alguém vendendo milho? Como é que o cara vende milho? O você tá
lá na praia de boa, deitado, lendo seu livrinho e aí tá o cara lá
gritando: "Olha o milho, olha o milho." Que que ele tá fazendo? Pegando
a sua atenção. Ou você, sei lá, tá lá na praia e passa o car o tiozinho
com o carrinho do picolé e p Isso. Se você não entendeu o barulho de uma
buzina. Então ele vai lá e p aperta a buzini e fala lá o cara do picolé
ou o carro do ovo. Na sua cidade tem o carro do ovo também. E aí tem
aqui tem. Você tá aqui daqui a pouco tá assim. Está passando na sua rua
o carro do ovo? Imagina se eu lançasse o carro do subido. Está passando
na sua rua o carro do subido? Na próxima terça-feira abriremos as
inscrições paraa comunidade subido. Faça sua pré-inscrição clicando no
link da bio. Então, o que que o que que tá todo mundo fazendo? Tá todo
mundo querendo a sua atenção, gente pegando a sua atenção. Tá beleza,
Pedro? Entendi. O tempo inteiro as pessoas querem a minha atenção, mas
você precisa entender que existem dois universos onde as marcas estão.
Já falei isso para você aqui. Existe o universo offline e existe o
universo online. Uma marca, ela chama a atenção no online de duas
maneiras. Ela pode fazer isso, deixa eu copiar aqui. Ela pode fazer isso
organicamente, ou seja, a empresa vai lá no Instagram, no TikTok, ela
faz a publicação e aparece para você. Ou não. Aí ela a pessoa vai
entender quais são as melhores práticas para fazer as publicações, pra
publicação chegar em mais pessoas, etc, etc. E a gente tem a segunda
maneira da marca aparecer na internet, da marca chamar a atenção na
internet, que é pagando para aparecer na sua frente. Isso daqui também é
conhecido como tráfego pago. Então, para chamar a atenção, uma marca tem
que colocar as suas publicações no ar, sejam publicações de anúncios ou
orgânicas. Não importa o formato, vídeo, imagem, carrossel, anúncio na
pesquisa do Google. Não importa se uma marca quer chamar atenção no
online, ou ela vai fazer isso organicamente, ou ela vai fazer isso
através do tráfego pago. E aí o detalhe é o nome é tráfego pago por um
motivo, porque as marcas têm que pagar, elas têm que pagar para ter os
seus anúncios veiculados. E como que uma marca paga para aparecer?
Porque o dono do negócio, ele poderia chegar para você e falar assim:
"Tá, entendi. Então eu posso aparecer publicando no Instagram e eu posso
pagar para aparecer e aí eu vou querer o quê? Eu quero atenção das
pessoas. Porque é com a atenção das pessoas que eu consigo vender.
Ótimo. Mas para quem que eu pago? Eu vou ligar pro Facebook e vou pedir
para ele: "Facebook, eu quero botar meu anúncio na frente das pessoas."
Não, não é assim que funciona. Como que a marca vai pagar? É o seguinte,
primeiro a marca ela vai criar uma conta no gerenciador de anúncios.
Pedro, o que que é o gerenciador de anúncios? Gerenciador de anúncios é
essa ferramenta aqui que parece quase um painel de um helicóptero, de um
avião, tá? É uma ferramenta onde nós vamos aqui, ó, configurar as nossas
campanhas. Esse daqui é o gerenciador de anúncios dentro do Google. Olha
só, inclusive dentro do Google na minha conta de anúncios, eu já gastei
R$ 16.94.000. R 16.94.109,25, tá? Eu já apareci com os meus anúncios
online no Google para mais de 1 bilhão. Meus anúncios já apareceram mais
de 1 bilhão de vezes. Isso aqui é só minha conta de anúncio. Isso daqui
é meu meu dinheiro que foi gasto aqui, não é o dinheiro dos meus
clientes, tá? Então eu posso aparecer através dos anúncios do Google,
mas existem várias fontes de tráfego. Eu posso fazer os anúncios através
da plataforma do Google Ads. Aqui eu vou aparecer no Google, vou
aparecer no YouTube. Mas se eu quiser aparecer no Instagram, Pedro, aí
se você quiser aparecer no Instagram, você vai utilizar o gerenciador de
anúncios da meta. Só pra gente pegar aqui por curiosidade. Deixa eu
filtrar aqui o quanto que gastou dentro da meta. Vamos só na meta eu
tenho várias contas de anúncio, não são muitas, são umas quatro, mas
vamos ver é que ele tá carregando aqui, ó. Será que ele já Não, ele não
carregou não, ele tá tá carregando. São muitas campanhas, mas eu chuto
que deve ser parecido, tá? Deve est um pouquinho mais do que o Google.
Acho que deve ser uns 20 milhões aqui que eu gastei, tá? Então, mais uma
vez, eu sei que é uma informação simples, mas essa informação simples
que eu tô te trazendo e te explicando dessa maneira, cara, é depois de
investir muito dinheiro em anúncios online para chegar aqui e poder te
trazer esse conteúdo mastigadinho, tá? Então, o cliente ele vai criar
uma conta no gerenciador de anúncios. E aí já fica a primeira pergunta
do gestor de tráfego. Pedro, a conta do gerenciador de anúncios, eu que
vou criar, gestor de tráfego ou é o cliente que cria? A conta de
anúncios? Quem que é o dono dela? sempre o cliente, sempre, ah, eu
preciso da senha do cliente para entrar na conta de anúncios, para
acessar esse ambiente aqui, onde eu vou criar as campanhas, onde eu vou
criar os anúncios. Não, ele libera pro seu e-mail e ele pode tirar o
acesso do seu e-mail também. Então, primeira coisa que ele vai fazer é o
quê? Cria conta de anúncios. Isso é de graça? Isso é de graça. Ele não
vai pagar ainda. Depois ele vai escolher o objetivo de campanha dele, o
objetivo publicitário. O que que ele quer com aquela publicidade, o que
que ele quer com os anúncios online. Aí ele define o quanto que ele vai
gastar, ele seleciona para quem que ele quer aparecer, ele sobe os
anúncios na plataforma. E aí já fica uma dúvida aqui. Coloquei até um
asterisco aqui de propósito, que é o quê? Quem faz os anúncios? Quem que
é o responsável? o gestor de tráfego, é o gestor de tráfego que faz
isso, né? Não, o gestor de tráfego não faz os anúncios. Ele não cria as
imagens, os vídeos, etc. Não é o trabalho dele. Quem faz os anúncios
normalmente é o cliente. Ah, e se o cliente não souber fazer? Se ele não
quiser fazer, aí você faz e cobra por isso. Ah, Pedro, e se eu não sei
fazer? contrata alguém que sabe fazer isso. Isso é uma das coisas mais
comuns dentro da nossa comunidade de alunos, que são alunos contratando
outros alunos. Vou dar um exemplo. Vamos dizer que o seu cliente ele
quer, sei lá, ele quer, ele quer fazer um pacote de anúncios. Tem alguém
aí no chat que vende isso? Tipo assim, se eu, Pedro Sobral, quisesse
contratar um pacote de anúncios pro meu cliente, aí eu falo aqui para
para esses gestores de tráfego que estão aqui, pô, quem aqui vende
anúncio que poderia vender para mim para eu vender pro meu cliente? Tem
alguém aqui que vende esse serviço? Aí tem uma galera que vende esse
serviço de putz, eu faço os anúncios, eu faço os anúncios, eu posso
fazer, eu faço as imagens, eu sou designer, ó, tem uma galera, sempre
vão ter várias pessoas e é mais fácil do que você imagina encontrar
esses profissionais e fazer a ponte pro seu cliente. Aí aquilo: Eu vou
comprar um pacote, sei lá, de 10 anúncios por R$ 200 e eu vou vender pro
meu cliente 10 anúncios por R$ 500, tá? Mas normalmente as pessoas elas
têm uma câmera profissional para gravar anúncios. Pedro, isso daqui uma
câmera profissional igual essa? Não, as pessoas têm isso daqui, ó,
celular. Elas podem gravar os seus anúncios, ó, é elas mesmas. Então
elas podem gravar os anúncios, elas podem falar na frente da câmera.
Claro que às vezes algum, muitas vezes os clientes não vão ter tanta
familiaridade, mas hoje em dia, se a pessoa já tem um posicionamento no
Instagram, se ela já publica, se ela já tem as publicações, quem faz
publicações pro orgânico pode fazer anúncios, tá? Então, quinto ponto,
ela sobe os anúncios na plataforma. Sexto ponto e último, ela paga toda
vez que o anúncio é mostrado ou que alguém clica no anúncio. E quem é
que paga pelos anúncios? Quem paga pelos anúncios é o cliente, tá? Então
é assim que funciona pro cliente pagar no tráfego pago. Ele cria a
conta, ele escolhe o objetivo, ele define o quanto que vai gastar,
seleciona para quem vai aparecer, sobe os anúncios e paga toda vez que o
anúncio é mostrado, tá? E aí vem a pergunta, Pedro, entendi agora, como
é que eu posso ganhar dinheiro com essa parada? Quem é que vai me pagar?
É o Google, é a meta? Quem? Como que eu ganho dinheiro com isso? Alguém
aqui tem essa dúvida assim de putz, mas eu não entendi. Eu saquei como é
que o cara vai subir os anúncios lá pra barbearia dele, pra loja, sei
lá, para o estúdio de pilates dele, pro produto digital. Mas eu, como é
que eu ganho dinheiro com isso? Se alguém ainda fica com essa dúvida
assim, putz, eu não consigo entender ainda como é que esse dinheiro vai
chegar para mim. Beleza, uma galera tem. Agora vem a parada que é o
seguinte, o cliente ele paga alguém para operar as fontes de tráfego,
tá? O que que são as fontes de tráfego? São essas ferramentas aqui. Ele
paga alguém para usar essas fontes de tráfego e criar estratégias
eficientes para colocar dinheiro no bolso dele, do cliente. O gestor de
tráfego, ele vende a coisa mais fácil do mundo de vender, que é o quê?
Eu vendo dinheiro. Eu não tô vendendo, sei lá, putz, eu vou vender para
você aqui uma garrafa d'água. Uma garrafa d'água não vai, vai te gerar
mais saúde, vai. Mas essa garrafa d'água vai colocar mais dinheiro no
seu bolso? Não vai. Então eu vou te vender um negócio que é um custo. Ó,
mas essa garrafa d'água aqui, pô, ela tá escrito aqui, ó, more life,
porque ela vai te trazer mais vida. E essa garrafa d'água aqui tem
1,800. Se você tomar essa garrafa d'água aqui, duas dela por dia, já
era. Você sabe que você tomou toda a água do dia que você deveria tomar,
mas ela vai custar aqui para você hoje R$ 300. é um custo. Agora, quando
eu vou vender o serviço de tráfego pago, eu estou vendendo pro cliente
um serviço de operar as fontes de tráfego e criar as estratégias para
ele. Eu vou vender este serviço para ele e ele vai contratar esse
serviço. Por quê? Porque esse serviço vai colocar mais dinheiro no bolso
dele do que ele vai me pagar. Essa é uma das lógicas universais do
dinheiro, que é quanto mais dinheiro eu boto no bolso dos outros, mais
dinheiro eu ganho. O meu trabalho, eu sou um professor, mas o meu
trabalho é colocar dinheiro no seu bolso. Por quê? Porque eu sou a Madre
Teresa de Calcutá, porque eu sou um bom samaritano, não. Que eu sou um
empresário sanguinário capitalista. E eu sei que quanto mais dinheiro eu
boto no seu bolso, mais dinheiro eu ganho também. Mas a minha empresa
cresce. Então o gestor de tráfego, ele ele vende dinheiro, tá, Pedro?
Mas e quanto de dinheiro que um gestor de tráfego ganha? Quanto em média
ganha um gestor de tráfego pago? E aí eu trouxe um dado para você que
não é um dado tirado do sovaco para não falar outro lugar. Eu tenho hoje
ativos dentro do meu produto de tráfego pago 55.000 alunos, mais de
55.000, acho que dá 55.500. E nós temos os dados dessas pessoas. Nós
entendemos quem são eles, quanto que eles faturam. E eu trago e eu tenho
esse produto, ele não nasceu hoje, né? Ele já existe há esse produto já
existe há mais de 5 anos. O mesmo produto, não igualzinho como era no
passado. A gente tá sempre regravando e atualizando ele. Inclusive tem 3
meses que a gente regravou 100% das aulas. Então o curso tá
completamente atualizado. Vou lembrar aqui você que nós abrimos
inscrições pro curso na semana que vem, tá? Se você quer fazer a
pré-inscrição, o link tá aqui na descrição do vídeo. Mas vamos ao que
interessa. Isso daqui são os dados dos gestores que estão dentro do meu
produto, tá? Não tô falando de quem tá fora, tô falando de quem tá
dentro do meu produto. O que que nós temos aqui? Isso é o faturamento
médio por mês. Por mês. Então, a pessoa que tá a menos de um ano no
produto, em média por mês, ela fatura R$ 6.304,98. Qual que é o número
médio de clientes que essa pessoa tem? Quatro clientes. Ah, por que que
tem vírgula? Porque é uma média. Se a pessoa tá em média a 1 ano dentro
do produto, ela já tá faturando 10.000. 2 anos, 16.000. 3 anos, 23. 4
anos, 27. 5 anos, 30.000. Pedro só cresce? Olha, aparentemente sim. Ano
que vem eu digo para você aqui como é que a gente vai estar com as
pessoas que estão há 6 anos dentro do produto. Mas quanto mais tempo
você passa fazendo tráfego pago aí nessa carreira, mais isso vai
deixando de ser uma renda extra, um mecanismo de transição de carreira.
Tem muita gente que usa o tráfego como isso, um mecanismo para trocar de
carreira. Por quê? Porque no tráfego pago eu consigo ter o trabalho
paralelo de gestor de tráfego enquanto eu tenho meu trabalho. Eu não
preciso sair do meu trabalho e começar a ser gestor de tráfego, não.
Você pode fazer isso aos poucos, tá, Pedro? Mas e a pessoa que tá
começando, a pessoa que tá ali, pô, primeiro mês, mas o primeiro mês
focado, o primeiro mês assim comprometido, fazendo acontecer. Mais uma
vez, isso é a base de dados dos meus alunos, tá? Mais de 55.000 alunos.
Então, o faturamento médio no primeiro mês como gestor de tráfego é de
R$23 e 12 centavos, tá? Agora isso aqui é muito louco porque tá assim, a
gente tá quase batendo o meu, eu quero superar o salário mínimo. Esse é
meu sonho com a gestão de tráfego. É tipo assim, falar: "Não, no
primeiro mês da gestão de tráfego você chega ganhar mais do que um
salário mínimo". Que hoje eu peguei o dado aqui, já vou colocar para
vocês, tá? Pedro, e quanto que um gestor de tráfego ele cobra eh por um
negócio, tá? E aí, mais uma vez, dado geral de todos os alunos. Eu
peguei por tipo de negócio aqui, então, por tipo de serviço, um gestor
de tráfego que atende um negócio local, ou seja, uma barbearia, um
dentista, um médico, uma clínica de estética, uma imobiliária, uma um
petshop, uma loja que vende ração, uma loja de material de construção,
qualquer negócio que vende localmente, cobra em média R$ 1.000 por mês.
Perpétuo é quando eu vendo infoprodutos, ou seja, produtos digitais. que
estão vendendo o tempo inteiro. Não é o meu exemplo. Eu não tô vendendo
o tempo inteiro o meu produto. Eu faço o que chamamos aqui no mundo dos
produtos digitais de lançamento. O que que é lançamento? Eu abro e fecho
as inscrições do meu produto. Então, eu vou abrir as inscrições do meu
produto na próxima terça-feira, mas elas vão fechar na sexta-feira. E
aí, para você entrar ter R$ 300 de desconto, tem o link na descrição
para você fazer sua pré-inscrição. E se eu atendo e-commerces, que são
lojas online, a média que é que um gestor ganha é R$ 17.700 por negócio.
Tá, Pedro, mas por que que alguém pagaria isso para um gestor de
tráfego? Eu te eu que te pergunto, por que que alguém não pagaria isso?
Como assim, Pedro? O cara ele vai subir os anúncios. Sim, exatamente. O
gestor de tráfego, ele vai subir os anúncios para que o cliente ganhe
mais dinheiro. Então, o meu serviço, a minha habilidade que eu tenho faz
o cliente ganhar mais dinheiro. Hoje, quanto que custa pro cliente, pro
dono de um negócio, contratar qualquer colaborador? Se a gente pegar o
salário mínimo, ó, quanto que foi o reajuste, o salário mínimo de 2025
será reajustado para R$518. Então, o gestor de tráfego, na maioria das
vezes, principalmente para quem tá começando e vai atender negócios
locais, você vai cobrar menos do que um salário mínimo e você vai ser o
prestador de serviço daquele cliente que mais coloca dinheiro no bolso
dele. Então, você tem uma função que não é um custo para ele. Sei lá, eu
vou contratar, sei lá, na minha empresa lá eu tenho eh, a gente tem uma
empresa e aí, deixa eu pensar numa função da minha empresa, tem uma
pessoa que que tá ali na é a secretária da empresa. Secretária da
empresa, pô. Secretário da empresa tem um papel super importante, máximo
respeito para todas as secretárias, mas a secretária da empresa, ela não
é a pessoa que vai diretamente estar buscando clientes paraa minha
empresa. Pelo menos a secretária da minha empresa não faz isso. Ah, eu
vou, eu tenho que contratar alguém para uma, eu tenho que eu contrato
uma empresa que faz a limpeza da minha empresa. Então eu contrato alguém
para fazer a limpeza. Super importante. Se não tá limpo, pô, vai virar
um caos, ninguém vai querer trabalhar, vai baixar a produtividade da
galera. Mas eu gasto mais do que um salário mínimo para alguém limpar.
Mas essa pessoa que limpa, ela traz clientes para mim, ela bota dinheiro
diretamente no meu bolso? Ah, mas indiretamente coloca. Sim,
indiretamente coloca. Eu não tô querendo dizer aqui que existe uma
profissão mais importante do que outra. Não, não tem nada disso. Mas a
questão é, tem profissões que têm um impacto financeiro maior no bolso
do empresário. E essas são as profissões que normalmente dão mais
dinheiro. Isso não te ensinam na faculdade, não te ensinam na escola, na
faculdade, no MBA, que é você buscar ter uma habilidade que vai fazer
com que você coloque mais dinheiro no bolso dos outros. Ah, mas eu acho
isso injusto porque eu tô trabalhando e quem tá ganhando mais dinheiro é
o fulano. Você vai viver nessa mesquinha para sempre, você vai ficar
pobre para sempre. Sinto te dizer, o o dinheiro ele é feito para girar.
A gente tem que fazer dinheiro, a gente tem que colocar dinheiro no
bolso dos outros. O que eu mais quero é que você compre o meu curso e
que você faça 100, 200, 300, 1000 vezes o valor que você investiu lá
dentro. Porque você vai colocar um pouco de dinheiro no meu bolso, eu
vou colocar muito dinheiro no seu bolso. É isso que eu tô buscando, tá,
Pedro? E quanto que um iniciante cobra para fazer o tráfego pago? Um
iniciante, alguém que tá começando zerado, vai cobrar em média de R$ 300
a R$ 500 por negócio local. Ah, mas eu já vi iniciante cobrando 1000.
Fulano falou que tem que cobrar no mínimo 3.000. Tudo bem, pode ir do
fulano. Eu tô falando de acordo com a minha experiência. Alguém que tá
começando cobra de R$ 300 a R$ 500. Aí hoje, cara, foi engraçado, o cara
no Instagram e falou assim: "Não, porque uma agência queria me contratar
e queria me pagar R$ 500 por mês". Aí eu abri o perfil da pessoa. A
pessoa tinha três seguidores, seguia acho que duas pessoas, não tinha
foto de perfil, era um perfil fake, a pessoa não quis falar comigo com o
perfil dela. Ela falou assim: "A pessoa, o dono da agência quer me pagar
R$ 500 para cuidar dos do para para me contratar". Claramente era alguém
iniciante. Claramente, pela fala da pessoa era alguém iniciante. E aí
ele tava assim, eu que eu eu planejo ter família grande, eu planejo ter
filhos, como é que eu vou me sustentar com R$ 500? O cara tava
planejando ter filhos, cara. Um filho demora 9 meses para nascer. Não
sei se você sabe como é que funciona o filho, como é que faz filho, mas
demora pelo menos nove. pode nascer um pouquinho antes, às vezes 7,
oito, mas vai demorar pelo menos isso. Em média 9 meses para nascer um
filho. Pô, em 9 meses não é que você vai ficar com aquele ganhando R$
500 para sempre. Você passa de um iniciante para um intermediário no
tráfego pago, pô, em papo de 6, 8 meses de trabalho, você já tá ali
voando. E aí o detalhe é isso daqui você vai ganhar por conta, tá? Por
negócio local, por mês. E você atende umas 10 contas fácil, tá? Então,
se eu atendo 10 contas, dá para tirar de 3 a R$ 5.000 por mês no início
da minha carreira, tá? De 3 a 5.000 por mês no início da minha carreira.
Se eu for atender uma agência, como assim uma agência, Pedro? Tem alguém
aqui no chat que tem uma agência? Manda eu aí no chat, por favor. Tem
uma galera que tem agência de tráfego. Eu tenho um grupo de de donos de
agências de tráfego pago. São mais de 100 pessoas que estão nesse grupo.
A média de faturamento dessa galera é de R$ 100.000 R$ 1.000 por mês.
Então é o povo que fatura 1 milhão por ano vendendo serviço de tráfego
pago. Eu perguntei para eles, eu falei assim: "Cara, quanto que vocês
cobram hoje é quanto que vocês pagam para alguém que está iniciando,
para alguém que tá e indo trabalhar com vocês pela primeira vez e a
pessoa é muito iniciante?" Eu vou até tirar o print aqui. Eu vou tirar
agora o print e vou colocar aqui para vocês, ó. Quanto que vocês pagam
para um gestor, Juninho? Juninho, Juninho mesmo. Juninho é alguém que tá
começando agora, ó. A maioria das pessoas paga entre 150 e R$ 200, tá?
Entre R$ 150 e R$ 200. E o que que é isso daqui? Você vai trabalhar para
alguém que já tem uma agência. Você vai atender essas essas pessoas, mas
você vai ser pago por conta, tá? Então é de 100 a R$ 200 por conta de
uma agência. Quantas contas você consegue atender numa agência? 20
contas com tranquilidade. Pedro, mas por que que eu consigo atender
mais? Porque se você tá sozinho aqui, você tem que fazer suporte, você
tem que cuidar de todo o resto. Aqui você tá só fazendo a parte
operacional, tá? E aí você pode cobrar de R$ 500 a R$ 1.000 para
e-commerces no início, atendendo até vou botar menos aqui, vou botar
R50, atendendo de 7 a 10 contas com facilidade, assim, dependendo do
tipo de negócio. Mas para você que tá começando, eu falaria assim: "Foca
aqui, ó, foca no início da sua carreira em encontrar uma agência para
você trabalhar, para você adquirir experiência. Foca em atender negócios
locais. Tá, Pedro? Entendi. Existe uma oportunidade. A galera, pelos
números que você me mostrou, ah, você pode manipular os números? Posso.
Manipulei? Não, claro que não. Eu tenho, eu faço as pesquisas com os
alunos e eu tô aqui para trazer os dados do mercado para você. Agora,
como que eu começo nessa parada? O que que eu tenho que saber para
começar? Porque até agora eu não entendi o que que eu tenho que saber.
Você falou, ah, operar as fontes de tráfego, montar as estratégias, mas
o que que é isso na prática? Tem alguém aqui que sabe o que que é um
MVP? Fala para mim no chat. MVP. Alguém aqui sabe o que que é um MVP?
Pode falar para mim o que que é o MVP? Tem tem um delay aqui entre o que
eu falo e o que chega para vocês. Alguém escreveu League of Legends.
Produto produto mínimo viável. Mínimo produto viável. MVP é uma sigla em
inglês para minimal viable product. Pedro, que que é essa sigla? Você tá
aí se aparecendo no seu inglês, não é? O menor produto viável. O que que
é o menor produto viável? É o seguinte, deixa eu copiar essa imagem
aqui. Vou jogar ela aqui para vocês. Um MVP, a melhor maneira de te
explicar é essa é com essa imagem. Pedro, o que que é um MVP de um
carro? Um MVP de um carro é eu fazer uma roda, não. Duas rodas, depois a
lataria, depois o carro pronto. Não. Um MVP de um carro, de um meio de
locomoção, seria eu fazer primeiro um skate, depois um patinete, uma
bicicleta, uma moto, um carro. Então, o que que é o a menor versão
daquele produto que funciona, que entrega aquilo que eu estou
prometendo? Por que que eu tô falando isso para você? Porque eu criei um
conceito que eu chamo de MCV. Que que é o MCV? É o menor conhecimento
viável. O menor conhecimento viável é tudo que você precisa para ter
resultado? Não. É tudo. É tudo que você tem que aprender. Não. Mas ele é
tudo o que você tem que saber, o menor conhecimento possível que você
precisa para iniciar, para dar o primeiro passo, para começar a fazer. o
seu trabalho como gestor de tráfego. O que que você tem que aprender
para começar? Você tem que saber criar uma conta de anúncio e configurar
formas de pagamento. Ah, mas não é a conta de anúncio, não é do meu
cliente, como você falou, é do seu cliente, mas você precisa saber pelo
menos instruir ele como que ele cria essa conta caso ele não tenha. Você
tem que entender o mínimo do mínimo sobre persona. Que que é persona? é
você saber com quem que você tá falando nos seus anúncios. É você saber
descrever o público com o qual você quer falar. Então, quem que é a
pessoa que compra um serviço de tráfego pago? Quem que é essa persona,
quem que quem que ela é? Como quantos anos ela tem? Quais são os
interesses dela? Qual que é a situação de vida dela? Eh, ela ganha
quanto? Ela mora onde? Então, saber o mínimo do mínimo sobre definir uma
persona. Depois, você tem que saber configurar as suas segmentações.
Então, é você saber entrar na plataforma e escolher para quem que você
vai anunciar. Você tem que saber pesquisar referências de anúncios na
biblioteca de anúncios, que por mais que não você não seja a pessoa que
vai criar o anúncio de fato, você tem que ter referências de bons
anúncios. E aí, para isso, você pode ir lá no Google e você pode
pesquisar biblioteca de anúncios. Veio aqui no Google na biblioteca de
anúncios, vai entrar aqui, ó, no primeiro link. Aqui eu consigo
encontrar todos os anúncios de todos os anunciantes que estão rodando
dentro do Facebook. Então, eu venho aqui e quero todos os anúncios e eu
digito aqui Pedro Sobral. Que que eu vou encontrar aqui? Todos os
anúncios do Pedro Sobral. que estão rodando nesse instante, que estão
aparecendo nesse instante. Eu vou usar esses anúncios para mim? Não, mas
eu posso utilizá-los como inspiração. Eu vou ver o que que ele tá
fazendo e vou falar: "Putz, isso aqui é uma boa ideia de anúncio, eu
posso utilizar". Você tem que saber fazer esse trabalho de pesquisar
referências. Número cinco, você tem que saber criar uma campanha de
mensagem pro WhatsApp, uma campanha da rede de pesquisa. Vou adicionar
mais uma coisa aqui, peço desculpas. criar uma campanha de mensagem pro
WhatsApp, uma campanha e usar o botão turbinar de maneira inteligente,
tá? Não é simplesmente apertar o botão lá e uma campanha na rede de
pesquisa, tá? Então você não tem que dominar todos os tipos de campanha
quando você tá começando para você iniciar. Você tem que saber o Babá, o
básico, o ABC de otimização de campanhas. Então você tem que entender um
pouquinho sobre funil de métricas, sobre o orçamento, sobre pausar
público ruim, sobre pausar anúncio ruim. Se você souber esses quatro
pontos aqui, como que as métricas funcionam e conversam entre elas,
mexer nos orçamentos das campanhas para usar um público que não tá
funcionando, para usar um anúncio que não tá funcionando, tá lindo,
maravilhoso. E número sete, você tem que saber como conseguir clientes.
Nossa, Pedro, parece coisa demais. De perto parece que é muita coisa. De
longe parece que tá de perto. Eu sei. Você que tá começando, talvez eu
tenha falado várias coisas que você não sabe o que que é. E aí você, a
sua cabeça já falou para você assim: "Ah, esse negócio não é para você,
esquece". Ah, isso é muito complicado. Isso aí só funciona para quem já
começou há muito tempo. Negativo. Isso aqui funciona só para você ser
bom no tráfego pago. Você não tem que ser bom em nada. Só tem que ser
bom em uma coisa. Uma coisa. Você tem que ser bom em começar e não
parar. Não tem uma pessoa, não conheço uma pessoa até hoje, nesses 10
anos como gestor de tráfego, 8 anos ensinando tráfego pago, que começou,
não parou e não conseguiu ter resultado, não conseguiu ganhar dinheiro,
não conseguiu crescer na profissão. São várias palavrinhas novas, são
vários conceitos novos. Se esse é o seu primeiro contato, não entre em
desespero. A pessoa que já assistiu aqui, fala para mim, você que tá no
chat, você que já assistiu aí umas quatro, seis aulas e tá aqui mais ou
menos na sua quarta, sexta aula, como é que era a sensação na primeira
aula e como é que é a sensação agora? Na primeira aula parece que assim,
cara, nunca vou entender isso. Mas aí você já tá aqui há quatro, se oito
semanas, você fala assim: "Pô, várias palavras, várias coisas que ele tá
falando aqui, eu já escutei mais de uma vez. Eu já tô começando a
entender o que que é". Claro, a sua cabeça ela foca naquilo que você não
entende. Você vai ficar preocupado com: "Meu Deus, eu não sei o que que
é isso que ele falou". Mas a gente tem essa tendência a sempre focar
naquilo que a gente não tá entendendo. É normal porque a gente quer
descobrir aquilo, mas você nem tá percebendo o quanto que você avançou
ao longo da jornada, o quanto que você evoluiu ao longo do tempo, tá? o
quanto que você evoluiu ao longo do tempo. Peguei um comentário
aleatório aqui de uma pessoa falando: "Muito difícil agência contratar
iniciante. Se você é um iniciante que estuda faca na caveira, que tá ali
sentando a bunda na cadeira e fazendo a coisa acontecer, não é difícil.
Não é difícil. É difícil talvez porque você não esteja se esforçando o
tanto que você tinha que se esforçar, tá? Então, ó, maor galera aí
falando, pô, esse negócio é não é difícil, tem que acreditar, evoluir
muito. Tô começando a entender os criadores de cursos que ganham muito.
Ganhamos mesmo. Ganhamos mesmo. Ganhamos mesmo. Quem quem vende curso
ganha um monte de dinheiro, mas isso não quer dizer que você também não
pode ganhar um monte de dinheiro trabalhando como gestor de tráfego. Se
você sempre olhar e falar assim, quem ganha muito é não sei quem. Você
sempre vai passar sua vida inteira nessa nessa amargura. Quem ganha
muito é o fulano, quem ganha muito é o belrano. Sempre vai ter alguém
que ganha mais do que você, que ganha muito mais do que você. Só que o
problema é o quê? O cara tá, ele passa, ele tá 10 passos na sua frente,
você tá 10 passos atrás. Você quer comparar sua realidade hoje com um
cara que tá 10 passos na sua frente? Nada a ver. Ah, Pedro, mas você não
ganha dinheiro como gestor de tráfego? Ganho. Eu tenho uma agência que
fatura múltiplos milhões por ano, vendendo serviço de tráfego pago.
Vendendo serviço de tráfego pago. Ah, mas você é você. Beleza? Quando eu
comecei, eu não era ninguém, não gravava aula, não aparecia, eu comecei
como gestor de tráfego. Não tô te trazendo algo aqui que eu não vivo,
algo que eu não sei. Eu já vi milhares de alunos falharem, milhares de
alunos terem resultado. Que eu tô falando com para você aqui, não é? Não
comecei esse negócio ontem, comecei ensinar tráfego pago ontem, tá?
Então, voltando aqui, que que você tem que dominar? E aí usa isso daqui
como um checklist, não como um tá, não sei essas coisas, ferrou, vou
embora, vou desistir. Adeus, é isso. Valeu, pessoal, fui. Não olha para
essas coisas e pensa assim: "Putz, isso é um checklist. Eu tenho que
dominar cada uma dessas paradas aqui. Eu tenho que aprender cada uma
dessas coisas aqui. E você tem que aprender como é que você consegue
cliente. Porque se você não tem cliente, você não é gestor de tráfego.
Você é um estudante, você tem um hobby, você é um entusiasta do tráfego
pago, mas você não é gestor de tráfego pago, tá? E onde que eu encontro
fácil o meu primeiro cliente? Onde que você vai encontrar fácil? Não é
difícil, é fácil. A palavra tá até em maiúscula aqui. Fácil. Vou até
botar um sublinhado nela. Fácil o seu primeiro cliente. Ah, não tem
primeiro cliente fácil. Tem. Se eu pegar hoje você, chego do chego do
seu lado e falo assim: "Vamos encontrar o seu primeiro cliente fácil. Eu
eu saio dali de 10 minutos que eu fico junto com você. Eu saio dali com
a próxima reunião marcada, com seu próximo cliente. Pedro, como que você
vai fazer isso? Eu vou fazer isso fazendo uma coisa que a maioria de
vocês não vai fazer, executando o simples. Você não tropeça nas pedras
grandes, vocês tropeçam nas pedras pequenas. O seu cliente, ele tá aqui,
ele tá aqui, ó, em um desses lugares. Ele tá no seu WhatsApp, ele tá nos
seus seguidores do Instagram, ele tá nos seguidores dos seus amigos. Ele
pode ser uma pessoa que conhece quem você conhece ou ele é uma pessoa
que vende um serviço para você. O seu seguidor, ele tá aqui em algum
desses lugares. Por exemplo, hoje eu tava no meu Instagram e eu vi um
amigo meu removendo uma tatuagem, que por acaso esse amigo meu é meu
barbeiro também. Eu vi esse amigo removendo uma tatuagem. Eu poderia
falar com o meu barbeiro para eu fazer o tráfego pago dele. Eu poderia
falar com o meu barbeiro e falar assim: "Ô, Gui, me desculpa, ouvir que
você tirou sua tatuagem, tal. Vi, tem uma coisa em alta agora que é uma
galera tirando tatuagem". Eu falei assim: "Pô, você não, cara, eu tô
trabalhando com anúncios online, você não consegue me passar o contato
dessa pessoa que que fez a retirada da tatuagem, talvez até falar de mim
para ela ali que eu tô trabalhando com isso, dá uma sondada se ela tem
interesse. Ai, Pedro, mas eu tenho vergonha. Aí você vai ser um pobre
envergonhado. Aí vão olhar para você, ó lá, pobrezinho envergonhado. Tem
que ter vergonha. Vergonha do quê? Vergonha de ir atrás do seu. Vergonha
de querer crescer, vergonha de est fazendo o seu corre. Não tem que ter
vergonha, você tem que ir atrás. Ganha no mundo do tráfego pago quem vai
atrás. Se você fica preocupado demais com que os outros vão pensar, o
que que vão pensar de mim, como é que vai ser, você vai travar o tempo
inteiro. Sabe o que que as pessoas vão pensar de você? Você não sabe,
nem eu sei. Mas sabe o que que elas vão pensar de você quando você tiver
lá ganhando seus 10, 15, R$ 20.000 por mês? Todos os meses? Elas vão
falar, sabe o que que elas vão pensar? Elas vão falar assim: "Ah, paraa
fulana foi fácil. A fulana, o fulano teve sorte da noite pro dia. Não,
ele tá envolvido com essas coisas de internet. Foi da noite pro dia, foi
fácil. Ele teve sorte. Essas são as frases do sucesso. Quando você tem
sucesso, é isso que você escuta das pessoas. É isso que as pessoas têm
que pensar de você. Você tem que querer que as pessoas acham, achem que
foi fácil, que você teve sorte, que foi da noite pro dia, mas você vai
ter que vencer esses seus demônios internos de insegurança, de medo, de
vergonha. Mas se eu, por isso que eu falei para você, se eu sentar do
seu lado hoje 10 minutos, eu falo assim: "Abre sua lista de contatos do
WhatsApp, vamos pegar todos os seus contatos. Pega a sua lista de
contatos". Então, vou pegar aqui os meus contatos. Aí eu vou começar a
ler aqui os meus contatos. Tem o Rodrigo, Alexandre, Paula, Rilon Grace
Academia. Hum. Teve uma época que eu treinava na Hillon Grace. Putz, que
massa. Eu treinei na Hillon Grace um tempo. Eu poderia mandar uma
mensagem lá para ver se eles estão precisando de anúncio. Acústica
Brasil. Acústica Brasil é uma empresa que faz o trabalho de isolamento
acústico. Pô, eles já me atenderam, talvez eu possa falar com eles. Eh,
tem um cara chamado, tem C do Gabriel. O Gabriel, eu sei que o Gabriel é
dono de uma empresa de aduana online. Hum. Esse cara deve fazer anúncio
na internet, Pedro. Isso é besta demais para ser verdade. Sim, 99,9% das
pessoas nunca vão fazer isso. Nunca. Por E você tá aí agora falando:
"Ah, não pode ser só isso ah, não é tão fácil assim. Não é tão simples
assim". É, é, é tão simples assim, só que é tão fácil de fazer que
também é fácil de você não fazer. E aí você vai lá e não faz. Então, no
seu WhatsApp, nos seus seguidores, no seu círculo social das pessoas que
te conhecem e das pessoas que conhecem quem te conhece, ali estão seus
clientes, ali estão seus três, quatro, cinco primeiros clientes, tá,
Pedro? E o que que eu tenho que fazer depois de fechar ou não fechar o
meu primeiro cliente? Você vai fazer uma coisa, você vai investir mais
em você. Por quê? Quanto custa a sua hora hoje? Quanto custa sua hora
hoje? Quanto custa? Quanto é que você cobra hoje por uma hora? Quanto
você cobra hoje por uma hora? Se alguém tentar contratar uma consultoria
minha hoje, alguém pega assim: "Pedro, eu quero uma consultoria pro meu
negócio, uma hora do seu tempo. Quanto que você cobra?" Eu, Pedro
Sobral, cobro R$ 20.000 uma hora. Isso é o preço da minha hora. R$
20.000. Ah, isso é injusto. Tem gente que ganha muito menos. Eu construí
o preço dessa hora. Teve uma época que eu me ferrava de trabalhar por
mês. Trabalhava assim, não me ferrava, que eu era estudante, trabalhava
em paralelo, mas 8 horas de trabalho por mês, por dia, desculpa, ganhava
R$ 890 por mês. 8 horas de trabalho ganhava R$ 890 por mês. Tinha uma
época que eu era estagiário na faculdade, recebi uma bolsa R$ 360, eu
tinha que entregar 12 horas por semana. Então, 12 horas por semana vezes
4 dava 48 horas por 48 horas no mês. 48 horas no mês para ganhar 360.
Então, custo por hora R$ 7 eu ganhava por hora. Então, minha hora era R$
7, ela agora ela é R.000. Por que que a sua hora ficou mais cara, Pedro?
O que que eu tenho que fazer pra minha hora ficar mais cara? Investir
mais em você. Porque quanto mais você investe em quanto mais eu invisto
em mim, mais cara vai ficando a minha hora. Se a sua hora, presta
atenção nisso, se a se a sua hora ainda não tá cara como você gostaria,
é porque você não investiu o suficiente em você. Simples. Essa é uma
verdade de autorresponsabilidade. Você tem que se encarar no espelho,
mas saber, não, cara. Você não investiu o suficiente em você. Ah, é que
eu não tive oportunidade. A oportunidade não apareceu porque você não
investiu tanto que você tinha que investir em você. Ah, mas é que para
mim foi mais difícil. Para você foi mais difícil. E tem gente que é mais
ferrada que você, mais [ __ ] que você, menos inteligente que você, com
menos recurso, com menos oportunidade, que hoje tem a hora mais cara do
que a sua. Por quê? Porque fez. Ah, mas as chances não são iguais para
todo mundo. Não são. Que que você vai fazer? Vai ficar reclamando ou vai
fazer alguma coisa em relação a isso? Pô, vai fazer alguma coisa em
relação a isso. Eu não vim de um berço de ouro. Meu pai é produtor
rural, minha mãe é professora de espanhol, dava aula em cursinho. Não tô
aqui para contar minha história triste para vocês, que, pô, vocês não
vão me ver fazendo isso na internet para ganhar, sei lá, a pena dos
outros ou nossa, olha que bonito, ele é um homem que se construiu
sozinho. Ninguém se constrói sozinho. A gente precisa de pessoas perto
da gente, mas você precisa investir em você. Repito, se a sua hora não é
cara como você gostaria que ela fosse, é porque você não investiu o
suficiente em você. Pedro, você tá falando de dinheiro? Tô falando de
dinheiro. Tô falando de dinheiro. Tô falando de tempo. Tô falando de
energia. Eu mostrei o dado da comunidade das pessoas que quanto mais
elas investiram nelas, mais elas faturaram. Se eu pego os dados das
pessoas que estão na minha comunidade, quanto mais tempo a pessoa tá,
mais dinheiro ela ganha. Por quê? Porque ela tá investindo mais nela.
Ela tá pagando para continuar lá dentro da comunidade do que é o que é o
meu produto de tráfego pago. Ela tá vendo mais aulas, consumindo mais
conteúdos, se especializando. Então você tem que investir em você. Ah,
Pedro, eu posso fazer uma carreira sozinho na gestão de tráfego,
aprender só com o conteúdo gratuito e ter resultado? Pode. Isso é
provável que vai acontecer? Eu não quero te desencorajar se você não tá
com as condições financeiras agora, mas a real é extremamente improvável
de você ter resultado. Por quê? Porque nós seres humanos, a gente
funciona, não é nem com a água batendo na bunda, é com a água batendo no
queixo. É com você tem que tomar uma surra de boleto. Que que é uma
surra de boleto? Surra. Ah, não. Surra de boleto é ótima. Você tem que
tomar uma surra de boleto. Você tem que ver o boleto chegando todos os
meses para você falar assim: "Agora brasileiro é brasileiro é fogo."
Você vai na pizzaria rodízio, você fala assim: "Eu vou dar prejuízo
aqui. Olha só, você quer dar prejuízo para um estabelecimento? Vai no
rodío de sushi, vou dar prejuízo nessa bagaça. Vai no peso, contratou lá
o negócio do o bifet que você pode comer à vontade. Vou dar prejuízo.
Agora que eu paguei, eu vou usar. E se a gente não tem essa pressão, se
a gente não coloca nesse ambiente de pressão de putz, eu me comprometi,
agora eu vou executar, você não executa, você amolece, você deixa para
depois, você procrastina, vira mais uma coisa na sua lista interminável
de coisas que você ia fazer, acabou não fazendo. Vira mais uma coisa.
Por quê? Porque você não tem a pressão necessária para você fazer. A
pressão é o que faz você agir. A pressão é o que faz você acontecer. Se
eu perguntar para você assim, qual que é a chance, a probabilidade de
você faturar R 1 milhão deais com o tráfego pago nos próximos 12 meses?
Você que tá começando agora, e eu mostro, cara, é difícil o cara que tem
gente que tá há 5 anos e não fatura R 1 milhão deais ainda no ano, né?
Faturar 1 milhão no ano, 100.000 por mês, qual que é a probabilidade?
Qual que é a chance? Muita gente vai dizer assim: "Pô, é zero. Ah, é 5%,
é 10%, é 50%". Agora, se eu falasse assim: "Cara, se você não faturar R
1 milhão deais no próximo ano, nos próximos 12 meses como gestitor de
tráfego, toda sua família vai morrer de forma extremamente dolorosa,
horrível, tipo assim, estilo jogos mortais, filme de terror. As pessoas
que você mais ama vão sofrer, assim, infinitamente, vão morrer se você
não alcançar isso em um ano, automaticamente o que que você tem?
pressão. E se você tem pressão, existe execução. A execução nasce da
pressão. A execução não nasce da motivação. Ela não nasce da sua
vontade. A a execução não nasce do seu querer. Ah, eu quero faturar
mais. Pô, você quer faturar mais há anos e você tá aí na mesma pindaíba
de sempre. Tem gente que quer ser gestor de tráfego aqui há meses e tá
na mesma pindaiba de sempre, achando que é ver mais. A aula ela te
ajuda, ela te impulsiona, ela te leva pro próximo passo, mas o que faz
você sair, levantar a bunda da cadeira, enfrentar os desconfortos, de
aprender coisas novas, de abordar os seus clientes, é o quê? É a
pressão. E pressão é um privilégio das pessoas que decidem executar, que
decidem investir em si mesmas. Então, se você quer ser uma pessoa que
vai investir em você mesmo, eu tenho mais uma vez um convite para te
fazer. Próxima terça-feira eu vou abrir as inscrições paraa comunidade
subido de tráfego. Não tem uma comunidade de gestores de tráfego, um
produto com mais gestores de tráfego do que o nosso no mundo. Nós somos
o maior produto de tráfego pago, que forma gestores de tráfego pago, que
ensina anúncios online do mundo inteiro. Do mundo inteiro. Ninguém forma
mais profissionais de anúncio online do que nós. Ninguém formou mais
profissionais do que a gente formou. E o conhecimento que eu trago de
lá, trago pr esse produto, é um conhecimento prático do campo de
batalha. O curso tá completamente atualizado. Todas as aulas foram
regravadas nos últimos 2 tr meses. O curso é extremamente moderno. Você
tem o acompanhamento de inteligência artificial ao longo de todas as
aulas, todos os conteúdos. Eu vou dar só uma palhinha aqui para vocês
rapidamente, ó. Esse daqui é a visão que você tem quando você entra no
produto, tá? Todos os dias você tem um subido cast, que é um áudio que
expira depois de 24 horas, tá? Então todo dia tem um áudio diferente
aqui para você. Tem a nossa playlist aqui, as nossas aulas de início.
Então aqui eu te explico como que funciona, como que quais são as aulas,
como que você vai fazer para ter acesso ao conteúdo, enfim, tem todo
esse passo a passo inicial. E aí você vai pros conteúdos. Aqui nós temos
seis grandes cursos dentro da comunidade, tá? Nós temos o curso de
tráfego do zero, Meta, Google Ads, TikTok Ads, LinkedIn Ads, todas as
ferramentas de anúncio. Nós temos o curso de prospecção e vendas, que é
para você fechar e vender pros seus clientes. Nós temos os cursos de
especialização de tráfego. O que que é isso daqui? Ah, eu quero me
especializar em tráfego para negócios locais. Tenho as aulas específicas
para negócio local. Ah, eu quero me especializar em tráfego para
e-commerces. Tem as aulas específicas para e-commerces. Eu quero me
especializar em tráfego para lançamentos. Tem aula de tráfego para
lançamentos. Quero me especializar em tráfego para perpétuo. Tem aula de
tráfego para perpétuo. Ah, eu não sei no que que eu quero me
especializar. Quando você chegar aqui, você vai saber, porque você já
vai ter visto os módulos anteriores. Temos o curso de habilidades
complementares, que por enquanto nós temos aqui o curso de automações,
tá? Então, para você automatizar processos com com IA, sem IA, com
ferramentas de automação para os seus clientes, estão entrando aqui nos
próximos meses o curso de CRM, atendimento comercial, inteligência
artificial para gestores de tráfego. Temos o curso de dados,
traqueamentos e relatórios. Então, como que você traqueia os dados do
seu cliente? como é que você cria relatórios, dashboards automatizados e
a gravação de lives e eventos. Então, as aulas, essa live que você tá
assistindo aqui, na próxima terça-feira ela sai do ar e você pode ter
acesso à gravação das lives, eh, que a gente faz aqui. E além da
gravação das lives, nós temos as as lives com os nossos alunos, tá? Que
essas são incríveis, porque nós fazemos lives temáticas. Então, tráfego
paraa imobiliária, para estética, para petshop, para dentista, tráfego
para delivery, para pizzaria, paraa hamburgueria, tráfego para
floricultura, pra agência de modelo, agência de viagem, só para você ter
uma noção, são mais de 100 dessas. Então, tem live para todos os nichos,
ó. Então, para autoescola, para vender produto de de tatame, de de luta,
para sexy shop, para marmitaria, para assistência técnica, tem de todos
os tipos de negócio aqui um passo a passo de tráfego para esse nicho
específico, tá? Então, você tem acesso a esses cursos, são seis cursos.
Dentro do curso, como é que funciona? Você tem os módulos aqui. Então,
cada curso tem a sua divisão dos seus módulos. Ao entrar aqui dentro do
módulo, vou pegar um exemplo aqui, Metaedads, por exemplo, a gente vai
desde o zero aqui com você, trazendo, por exemplo, recursos para criar
anúncios na meta. Aí você vai clicar aqui. Isso daqui é a aula, tá?
Então você vai dar play aqui, você vai ter um vídeo aqui extremamente
Deixa eu tirar a legenda aqui que senão vai ficar repetitivo. Opa, como
é que eu tiro a legenda? Aí saiu, tá? Então você vai ter um vídeo aqui
extremamente bem editado, com múltiplas câmeras, com o lettering na tela
que tem o auxílio visual, enfim, esse daqui é a aula no maior no ápice
da didática para você aprender. O aqui a gente tá no básico de Facebook,
tá? Então assim, o que que é uma página no Facebook? Além da aula, você
tem o que nós chamamos de a. O que que é a a? Aa é a inteligência
artificial dessa aula. Então, cada aula tem uma inteligência artificial.
Esta inteligência artificial, esta a que você tá aqui, você pode
perguntar à vontade para ela sobre o conteúdo da aula, ela vai saber
tudo sobre recursos para criar anúncios na meta. Então eu posso chegar
aqui, pô, me explica de maneira mais simples o que é uma página
profissional. Não entendi a diferença para um perfil pessoal. Pode ser a
dúvida mais básica, mais boba do mundo. Ela vai responder para você
aqui. Eu posso pedir para ela avaliar o meu conhecimento. Ela cria tipo
uma provinha com perguntas para eu escolher as respostas e ela e ela
analisa o meu conhecimento. Enfim, a gente tem uma inteligência
artificial embutida aqui, ó. Claro. Vamos simplificar isso com analogia
divertida. Imagina perfil pessoal do Facebook é como se fosse seu RG,
sua identidade pessoal. Aí ele, pô, vai me dar toda a explicação aqui,
tá? Então a gente tem a aula, temos a a ter a aula e a a nós temos o
ABC. Que que é o ABC? O ABC tá aqui, ó, no próximo botãozinho. Vou
apertar aqui, ó. Olha o meu mouse aqui. Apertei. Que que é o ABC? O ABC
é a parte operacional daquilo ali que a gente tá ensinando. Então, ABC
quer dizer apertando botões comigo. Por isso que é ABC, apertando botões
comigo. Nós temos esse sistema aqui que você vai clicar no seu mouse, ó,
e aí ele vai falar: "Ah, para criar sua conta, você vai acessar o
gerenciador. Aí tem o link aqui para você abrir." Aí você vai apertar
continuar. Primeira coisa, você tem que clicar aqui. Aí você clica. Ah,
agora você vai clicar em criar uma nova conta. Clicou aqui. Ah, agora
você vai colocar suas informações aqui. Cliquei. Ah, aqui você vai
colocar o seu código. Agora você tem que apertar em OK. literalmente
você vai apertando, ó, onde ele diz para você apertar, você vai
apertando. Então, eu tenho um sistema em que você vai apertar em todos
os botões para criar campanhas, configurar sua conta de anúncio. Eu tô
clicando aqui, ó, em cada um deles aqui, ó, um clique e ele tá indo e
ele vai me ajudando a fazer essa configuração para eu fazer junto com a
ferramenta. E aí depois você faz no seu computador, tá? Então, nós temos
a aula, nós temos a a nós temos o ABC e nós temos os materiais de apoio,
tá? Então, toda aula ela tem um material de apoio, tá? Então, assim, pô,
alta qualidade nos materiais de apoio aqui. Um material de apoio super
bonito, super bem estruturado, que ele pode substituir a aula pra pessoa
que já entende um pouco mais daquele assunto, ela quer rapidamente
consumir aquele conteúdo ali, tá? E aqui você vai ter além de desses
recursos, né, temos o recurso de busca para você buscar alguma aula
específica. Enfim, isso daqui é só a parte de interface de assistir aos
conteúdos. Aqui nós temos os módulos desse curso que é o curso de
tráfego pago de introdução, o método subido de tráfego, onde eu te trago
todo o método subido, como que ele funciona, o meu método de fazer
tráfego pago. Depois temos Meta Google Ads, otimização de campanhas, um
módulo só de estratégia de tráfego pago, um módulo só de TikTok ads, um
módulo só de LinkedIn Ads, um módulo só de bloqueios e contingência e um
módulo que a gente chama de SOS tráfego pago, que é quando você quer
muito rápido aprender tráfego pago, porque, sei lá, você fechou um
cliente e agora você tem que aprender rápido tráfego pago, tá? Isso é só
o curso subido de tráfego. Aí no curso subido de prospecção, mesma
lógica, tá? Tudo tem aula, a material de apoio. Aqui eu vou te explicar
o que que é o seu serviço de tráfego pago que você vende, como que você
prepara a casa, como é que você prospecta, como é que você faz uma
proposta comercial. Te entrego tudo exatamente o que você tem que fazer.
Te dou script do que é falado na reunião, te ensino a fazer tráfego para
conseguir cliente de tráfego pago e te explico como é que você escala o
seu negócio. E também tem o módulo SOS prospecção, que é: "Quero fechar
um cliente muito rápido, vou pro módulo SOS prospecção porque eu tenho
que fazer o dinheiro da comunidade muito rápido." Aí tem o curso de
especialização, que é o que eu falei para você. Aqui vai ter tráfego
para negócio local na meta, tráfego para negócio local no Google. que é
focado em um tipo de negócio. Aí tem um curso que é de Google Meu
Negócio aqui para você aprender a usar o Google Meu Negócio. Tem um
curso de branding para e-commerce, Google Merch Center para e-commerce,
tráfego para lançamento, tráfego para perpétuo, tudo extremamente é
conciso aqui, porque as aulas elas têm de 10 a 20 minutos, são aulas
mais curtas, super bem explicado, super didático, é o caminho mais
rápido para você dominar o tráfego pago, tá? Aí temos o curso de
habilidades complementares, que como eu falei para você aqui, temos o de
automações. Depois do curso de habilidades complementares, temos o curso
de Google Tag Manager, Google Analytics e Google Locker Studio, que é os
é o curso de dados, traqueamentos e relatórios. Pedro, parece conteúdo
demais, pois é, mas você tem aqui o que a gente chama de rota de
estudos, tá? Que que é a rota de estudos? Deixa eu reiniciar minha rota
aqui. A rota de estudos, basicamente, nela eu vou responder um
questionário. Ah, eu quero fazer tráfego para outras empresas. Eu quero,
não tenho clientes ainda. Eu quero aumentar minha carteira de clientes,
eu quero focar em negócio físico ou não sei, meu nicho é sensível? Não é
um nicho sensível. Quanto tempo eu tenho para estudar por dia? Ah, eu
tenho uma hora por dia, tenho 30 minutos por dia. Você vai apertar em
continuar. Aqui o que que o sistema vai fazer? O sistema ele vai
entender quem que é você, qual que é o seu perfil, o que que você quer.
E ele vai criar todos os dias quais aulas você tem que assistir. Dia um,
tem que assistir essa aula. Dia dois, dia tr, aliás, dia um, tem que
assistir essas aulas aqui. Ah, próximo dia, amanhã eu tenho que assistir
essas outras aulas aqui. Próximo dia, amanhã eu tenho que assistir.
Depois eu tenho que assistir essas aulas aqui. Eu posso baixar minha
rota de estudos, tá? Ele vai gerar um PDF para mim. Ó, ele gerou aqui o
PDF. Opa, ele gerou o PDF. Será que Ah, agora foi. Ele não tinha, ele eu
não abri ele, ó. Então, o primeiro desafio que é ver o curso subido, ó,
aparece muita coisa, mas em uma hora por dia você termina ele em 11
dias. Então, em 10 dias você terminou o curso. Se você der um gás um
pouquinho maior, em 29 dias você concluiu toda a rota de estudos. Ah, e
acabou, não tenho mais o que estudar depois. Não, claro que você tem o
que estudar. Por quê? Quanto mais você investe em você, mais cara fica a
sua hora, tá? Pedro, como é que eu faço para ter acesso à comunidade?
Vou abrir as inscrições na próxima terça-feira. Clica no link que tá na
descrição, tá? E faz a sua pré-inscrição para você participar da
comunidade. Seguinte, povo, para você ter acesso a esse PDF aqui, lembra
que eu falei para você? Putz, é um checklist, né, com todos os itens
aqui. Então, para você ter acesso a este material que eu fiz aqui
durante a aula, nós vamos fazer uma coisa diferente hoje. Nós vamos
fazer um teste, um teste que não nunca tinha não foi feito por mim
ainda. Você vai fazer o seguinte, ó. Na descrição deste vídeo, deixa eu
abrir aqui a aula onde a gente tá, você tá vendo agora essa aula aqui,
ó. Tá? Então, onde a gente tá, você tá vendo essa aula aqui, você tá
aqui em cima. Deixa eu dar um zoom, ó. Você tá aqui em cima, ó, no chat,
tá? Na descrição deste vídeo, nós temos algumas coisas. Primeiro, você
pode fazer a sua pré-inscrição gratuita com R$ 300 de desconto, clicando
aqui, faz a sua pré-inscrição. Para ganhar os R$ 300 de desconto, coloca
o seu nome, seu e-mail. Aqui na página tem toda a explicação sobre o que
que é a comunidade subido, tá? Você pode dar uma olhada. Esse é o
primeiro link. O segundo link é para você receber este PDF de hoje, tá?
Você vai clicar aqui e você vai chamar o meu time lá no WhatsApp. Manda
lá mensagem para eles: "Oi, quero meu PDF". PDF? Cadê meu PDF? Me libera
o PDF. E eles vão mandar para você o PDF, tá? Eles mandam para você o
PDF maroto da aula. Pedro, o que que é essa lista de presença que tem
aqui embaixo? Tá. Eu preciso de uma palavra-chave paraa lista de
presença. Já tô pensando. Calma, deixa eu pensar. Deixa eu mandar aqui.
Pô, alguém me dá uma ideia de palavra-chave aí pra lista de presença.
Deixa eu pegar o usar a criatividade de vocês. Jabuticaba, vai ser essa,
a primeira que eu encontrei, tá? Então, a palavra chave da aula de hoje
é jabuticaba. Por quê? Porque foi a palavra que me chamou atenção.
Pedro, para que que serve essa palavra-chave? É o seguinte, na descrição
aqui do vídeo, você vai ter o link, deixa eu voltar aqui, ó, você vai
ter o link da lista de presença. Acessa aqui o link da lista de
presença. Você vai cair nessa página aqui. Você vai colocar seu nome, um
e-mail, seu WhatsApp. Você vai escolher a palavra-chave da aula. Que é
qual? Já buticaba. Por quê? Porque a gente é meio aleatório. Por que que
você deveria fazer isso? Porque uma vez por mês nós temos um sorteio,
tá? Um sorteio aqui de diversos prêmios. E quanto se o seu nome for
sorteado, a gente vai ver quantas lives você já viu, quantas lives você
tem presença. Quanto mais lives você tiver presença, melhores são os
prêmios que você vai ganhar. Então, se você viu quatro lives, você pode
ganhar uma caneca. Se você viu 52, você pode ganhar um computador. Se
você viu 32, você pode ganhar uma vaga na comunidade subido de tráfego.
Então assim, marque a sua presença aqui, povo. O mapa mental das últimas
aulas, Pedro, que mapa mental que é esse? Eu não tava aqui. O mapa
mental das últimas aulas. Cadê? Que você falou que você ia fazer, daí
fez. Aí ficou ruim. Não dava para dar zoom no mapa mental. Vou pedir pro
meu time colocar na descrição agora. Já era para estar na descrição.
Time comida de rabo em vocês. Pô, estamos fazendo esse mapa mental há
semanas. Eu tô há semanas brigando com esse mapa mental. Como é que
vocês não colocaram na descrição? Vamos colocar na descrição o mapa
mental agora, Pedro. Nem sei que mapa mental é esse. Eu não vi as lives
anteriores. É a primeira vez que eu tô aqui. Vai na descrição do vídeo e
baixa o mapa mental também. Por quê? Porque é um baita mapa mental. Pode
ser que você não entenda tudo que tá lá, mas assim, eu fiquei até meio
relutante de entregar esse negócio de tão bom que é esse mapa mental,
tá? Que é tão bom que é esse mapa mental, tá? Ó, o meu time me falou,
está na descrição da última live, mas colocando na de hoje, ó. Então, na
descrição da última live que já vai sair do ar, tá lá, mas eu vou
colocar na live de hoje, só para o povo não dizer que, ah, mas não
avisou, ia ser nessa live, não sei o quê. Então, ó, só vou dar, vou
atualizar aqui para mostrar para vocês. Calma aí. Não sei quê, deixa eu
pegar aqui, ó. Mapa mental. Tá aqui, ó. Mapa mental da última da última
aula, ó. Das faz duas aulas, né? Olha como que ficou bonito. Eles
capricharam. Eu reclamei. O time compareceu aqui fazendo mapa mental,
tá? Então aqui tem toda a explicação de quais são os públicos, quais
métricas você tem que focar para cada tipo de negócio. Baixa o mapa
mental. No futuro vai ter gente no meu direct falando: "Ai, eu perdi o
mapa mental. Eu vou falar perdeu o playboy." Baixa o mapa mental. Essa
aula de hoje fica disponível só até a próxima terça-feira e manda
mensagem lá no WhatsApp. Não importa quando você esteja vendo essa essa
aula aqui, tá? Manda mensagem lá no WhatsApp pedindo o seu PDF que a
gente manda para você todas as anotações aqui da aula de hoje, tá? Não
tá na bill. Que que não tá na bill, minha querida? Que que é que que é
que bill? Que bill? Ninguém falou de bill. É a descrição do vídeo. Isso
aqui é a descrição do vídeo, tá? Então você está neste vídeo aqui, ó.
Essa live. Você está aqui. Eu estou aqui nessa na minha na minha live.
Os links estão na descrição do vídeo. Ainda não está na descrição. Como
que não tá? Eu tô vendo aqui como que não tá. Eu estou vendo. Ah, para
mim não apareceu. Atualiza a tela que ele aparece, tá? Atualiza a tela
que ele aparece. O curso fica com acesso durante quanto tempo? O acesso
do curso é de um ano. Na próxima terça-feira eu vou explicar tudo sobre
o curso em muito mais detalhes do que eu expliquei aqui. Eu vou passar
por cada uma das aulas, eu vou passar por todos os pontos, vou
reexplicar o que eu já expliquei aqui. Então na se você tem interesse,
vem aqui na próxima semana que vai ter toda a explicação passo a passo
bonitinho para você. E na página que a gente divulga na semana que vem,
que eu libero na próxima terça-feira, ela também vai ter todas as
informações sobre o curso, tá? Então, se você falar assim: "Putz, não
vou poder assistir a aula, tá tudo certo, a gente vai abrir as
inscrições na terça, elas vão fechar na sexta, tá? Então faz a
pré-inscrição, povo." Agora aqui, que que você vai fazer saindo daqui?
Pré-inscrição. Faz a pré-inscrição, vai lá, garante a sua pré-inscrição
agora. Fechou, minha gente? Tamo junto. Vejo vocês na próxima
terça-feira, 3 horas da tarde, na aula em que nós vamos abrir as
inscrições para a nossa queridíssima comunidade subido de tráfego. Até
lá. Valeu, fui.

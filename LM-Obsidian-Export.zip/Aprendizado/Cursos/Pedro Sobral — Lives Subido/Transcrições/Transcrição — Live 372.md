---
tipo: transcrição
live: 372
tema: Copywriting para Gestores de Tráfego — Parte I
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #372

> Copywriting para Gestores de Tráfego — Parte I

Resumo e aplicação: [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]]

---

Meu Deus, que nervoso que eu tava passando aqui. Estamos ao vivo.
Bem-vindos, bem-vindos à nossa live número 372. Hoje, senhoras e
senhores, falaremos sobre copywriting para gestores de tráfego pago. E o
que eu preparei para você aqui nessa aula vai deixar você assim, ó. Eu
comecei a transmissão ao vivo aqui 4 minutos, 5 minutos atrasado.
Comecei. A culpa foi minha? Provavelmente foi. Mas é porque hoje eu
tinha duas opções com essa aula ao vivo. Eu poderia pegar o conteúdo de
uma aula muito parecida com a que eu vou te dar hoje aqui e simplesmente
copiar e colar o conteúdo. E aí ia ser muito fácil para mim, porque eu
não ia ter que planejar nada. Afinal de contas, eu já dei essa aula no
passado, mas eu tinha uma segunda opção, que era pegar todo o conteúdo
da aula e planejar ele do zero para você, estruturar tudo aquilo que
você precisa saber sobre copywriting. Claro que eu não vou reinventar a
roda aqui, mas a questão é o seguinte: eu preparei para você a melhor
aula sobre copywriting para gestores de tráfego da sua vida. E eu
garanto para você que no final dessa aula aqui, se você pegar o que eu
vou te ensinar aqui hoje e você colocar isso no seu cento de utilidades
de gestor de tráfego pago, isso aqui tem o poder de mudar a sua carreira
na gestão de tráfego pago. Porque hoje a gente sabe, tem mais gestores
de tráfego no mercado e só saber sobre anúncios não é mais o
diferencial. Você tem que saber, aliás, só sobre saber sobre ferramentas
não é mais o diferencial. Você tem que dominar as ferramentas, mas a
gente tem que ir além das ferramentas. A gente tem que dominar a parte
de criar anúncios, boas páginas e saber o que vai ser ensinado aqui para
você hoje. Já te coloca ali no 1% dos gestores de tráfego pago do
mercado. Então, bem-vindos, bem-vindos à nossa live número 372.
Bem-vindos, bem-vindos ao bloco do Sobral, porque, pô, estamos em
carnaval, pleno carnaval, e você decidiu estar aqui comigo terça-feira,
3 horas da tarde estudando sobre tráfego pago. Eu garanto que eu vou
fazer o seu tempo valer a pena. Você que tá aqui ao vivo comigo, seu
tempo vai valer a pena. Eu vou te entregar aqui conteúdos hoje que você
poderia facilmente ter que pagar para ter acesso a esses conteúdos, tá?
Você tá vendo que nós estamos aqui com um cenário diferente, né? A gente
tá, esse aqui, na verdade, assim, eu tô falando que ele é diferente, mas
daqui a pouco você vai entender que esse daqui é o cenário padrão, né?
Esse aqui é o cenário do dia a dia. E se você nunca me viu na vida, né,
então talvez esse seja o cenário padrão para você, mas saiba que nós
estamos aqui no nosso canal do YouTube, Canal Subido, fazendo lives,
aulas ao vivo há 372 semanas. Pedro, mas eu entrei ali no seu canal do
YouTube, vou até abrir meu canal do YouTube aqui na sua frente. Eu
entrei ali no seu canal do YouTube e lá no seu canal do YouTube eu não
consegui encontrar aqui 372 lives. Eu encontrei aqui alguns outros
conteúdos. Eu vim aqui na aba ao vivo, eu encontrei algumas aulas
disponíveis aqui, muitas aulas, dig, diga-se de passagem, mas não 372
lives. Você está mentindo este número? Não, nós fazemos um conteúdo aqui
no nosso canal que nós chamamos de conteúdo perecível. O que que é o
conteúdo perecível? Toda terça-feira, não importa se é carnaval, Natal,
Ano Novo, meu aniversário, tem uma aula ao vivo aqui para você. Algumas
das semanas, eu diria que talvez seja mais ou menos, sei lá, 2% das
vezes que eu faço aulas ao vivo, eu às vezes não consigo fazer aula ao
vivo porque, sei lá, tinha um voo e o único horário do voo que eu
conseguia fazer era terça-feira, 3 da tarde. Nesse caso não tem live,
não. Nesse caso tem live, mas aí o que que eu faço? Eu gravo a aula o
mais perto possível que eu consigo horário da transmissão. Então, muitas
vezes, que que eu acabo fazendo? Terça-feira eu tenho um compromisso
inadiável. 3 da tarde. Terça-feira eu acordo de eu acordo de manhã. A
primeira coisa que eu faço é gravar aula e aí eu faço a transmissão
dessa aula ao vivo para você. Pedro, hoje é o caso, você tá pulando
carnaval? Não, eu tô ao vivo aqui mesmo com você, tá? Então, uma coisa
eu garanto que toda terça-feira você vai chegar aqui nesse canal e vai
ter um conteúdo de tráfego pago de altíssima qualidade que você poderia
pagar para ter acesso. E você pode assistir minhas aulas anteriores e
ver isso com seus próprios olhos ou assistir essa aula aqui comigo e
você vai ver tudo aquilo que eu vou te entregar no que diz respeito ao
assunto copywriting para gestores de tráfego pago. Toda semana que você
vier aqui vamos ter uma aula diferente com tema diferente. As aulas não
são sequenciais. Volte aqui nessa aula, na aula da semana que vem, live
número 373 ou não sei quando você tá vendo esse conteúdo e você vai ter
uma aula diferente, com um tema diferente, mas sempre com este nível de
qualidade. Pois bem, o que que vamos ver aqui na nossa aula de hoje?
Vamos falar sobre copywriting para gestores de tráfego, como que você
vai criar bons anúncios. Aqui nessa aula a gente vai desvendar, a gente
vai descobrir basicamente cinco grandes conceitos de COP, né? Quais são
os pilares que você precisa dominar como gestor de tráfego pago sobre
copywriting? Pedro, eu nem sei ainda o que que é copywriting. Calma que
a gente já vai falar sobre isso. Mas existem basicamente cinco pilares
que você como gestor de tráfego precisa dominar sobre COP, que é você
entender sobre COP, é você saber sobre público alvo, como é que você
define um público alvo, é você entender COP para anúncios, você saber
COP para criação de páginas e COP para fazer boas promessas. No meu
ponto de vista, o que me tornou um dos maiores gestores de tráfego pago
do mercado foi ser um gestor de tráfego que não entendia somente sobre
ferramentas, sobre botões, mas eu entendia como apertar os botões na
cabeça das outras pessoas. Então, não é só sobre você saber apertar
botões nas ferramentas, é sobre você saber apertar os botões das
pessoas. Sabe quando você tá falando com alguém, sei lá, todo mundo aqui
tem um familiar, um irmão, um parente, um marido, uma esposa que você
fala assim: "Essa pessoa aperta os meus botões". Sabe quando você sabe
que aquela pessoa, você é quase inabalável, mas aquela pessoa te irrita,
aquela pessoa sabe falar aquela coisinha que, nossa, te dá uma raiva
daquela pessoa, sabe? Então, alguém aqui já teve essa sensação de putz,
essa pessoa sabe apertar os meus botões. Alguém aqui já sentiu isso na
vida? Por favor, fala comigo no chat. Não fique tímido nesse carnaval.
Canal subido. Eu já ouvi isso aqui. Pois é, a gente já falou de
copyright para gestores de tráfego. Eu já expliquei esses cinco pilares,
mas você vai ver que a maneira que eu vou preencher diferente. Então
você tá indo lá comer o biscoito traquinas. É traquinas, biscoito. Nem
sei se é mais biscoito, né? Bolacha, biscoito, sei lá. Você tá indo
comer a bolachinha recheada. O recheio aqui vai ser diferente. O sabor é
surpresa. Ó, sim, meus gatilhos, sem dúvidas. Todo mundo aqui já sentiu
alguém apertando seus botões. A minha mulher, a minha esposa, meu
marido, todo mundo tem isso. Pois é. Você como gestor de tráfego pago, a
sua principal habilidade não é saber apertar os botões das ferramentas,
é saber apertar os botões das pessoas. Esse conhe isso aqui que eu tô te
falando agora, talvez seja uma das coisas mais poderosas de tráfego pago
que eu nunca coloquei dessa maneira numa live. Você tem que aprender a
apertar os botões das pessoas. E copywriting é sobre aprender a apertar
os botões das pessoas. Tráfego pago é sobre saber apertar os botões das
ferramentas. Copywriting é sobre aprender a apertar os botões das
pessoas. No final das contas, você será um apertador de botões. Tem
gente que fala assim: "Não existe mais espaço para os apertadores de
botões. Não existe espaço para as pessoas que sabem apertar somente os
botões das ferramentas. Agora, aquelas que sabem apertar os botões das
pessoas através dos anúncios, através da comunicação digital, essas
pessoas nunca vão ficar sem trabalho, nunca vão ficar sem dinheiro,
nunca vão deixar de serem contratadas. Tá fazendo sentido isso aqui que
eu tô trazendo para você? Eu sei que é algo conceitual, mas é a partir
deste conceito que nós vamos construir o nosso conhecimento de
copywriting por aqui, tá? E aí, só um detalhe importante, não estou
vendendo nada para você aqui, mas você que é subido, saiba que dentro da
comunidade subido de tráfego, que é o nosso portal de conteúdos e de
aulas, você tem aqui dentro no curso de habilidades complementares, você
tem aqui dentro o nosso curso de técnicas de copywriting, tá? Então aqui
temos um curso inteiro de técnicas de copywriting. Não deixe de de
assistir esse curso. Esse daqui é um dos assuntos mais relevantes para
tornar você é um profissional que cada vez se destaca mais dentro do
mercado. Ai Pedro, mas eu não tenho acesso. Que que eu faço? Você vai
assistir a aula aqui e eu vou te ensinar o que você precisa saber sobre
copywriting. Mas você que tem acesso, é claro que lá tem o conteúdo um
pouco mais profundo, um pouco mais detalhado do que a gente consegue
entregar aqui em 1 hora, 1 hora e meia de aula. Beleza? Primeiro passo
que a gente tem que dar para dominar copy. Nós temos que entender sobre
copywriting e você já vai e e se você já vai sacar isso daqui que é
escreva copywriting e não copyright, tá? Tem um monte de gente que acha
que copywriting se escreve assim: copyright. Copyright é de direitos,
tá? Isso aqui é direitos autorais. Copywriting é escrita. Writing é
escrever. Então o que que é o copywriting? O copywriting, como eu já
falei para você, é a habilidade de apertar os botões das pessoas. Só que
a gente faz isso através da comunicação. Essa comunicação, ela pode ser
falada, como eu estou fazendo agora. Ela pode ser uma comunicação
escrita, como eu também faço aqui com você. Então eu posso através das
minhas palavras faladas ou escritas convencer você apertar os seus
botões para que você faça algo. Como por exemplo, eu posso falar o
seguinte: "Putz, e agora eu tô falando real aqui com você?" Cara, você
tá aqui nessa live, eu vou te entregar algumas inteligências artificiais
aqui nesse conteúdo. Eu vou te entregar um conteúdo que eu não tenho nem
no meu curso gravado. Eu vou te esse conteúdo tá aqui, tá disponível
ainda. Eu vou te entregar iso de graça aqui. Isso não mere por sério
mesmo, isso não merece o seu like aqui nessa live, pô. Eu tenho certeza
que merece. Então, pô, pega o seu dedinho, aperta no botão do like deste
vídeo, por favor, aperte no botão de like, curte esse vídeo aqui para
esse conteúdo chegar até mais pessoas. Faz isso por mim. Não, a verdade
não é nem faz isso por mim, faz isso por você, pô. Demonstra o quanto
que você está aim aprender esse conteúdo. Solta o dedo nesse like. Ó,
quando eu comecei a falar isso tudo aqui para você, o botão de like
deste vídeo estava assim, com 100 likes. Agora eu tô batendo o olho
aqui, já estamos com 672 likes. O que que eu acabei de fazer? Eu acabei
de utilizar um recurso de copywriting com você. O que que recurso que eu
utilizei? Eu apertei um botão seu. Eu fui lá e falei para você: "Pô, vou
te entregar um baita conteúdo. Isso aqui não merece que você aperte o
botão". Eu fiz uma chamada paraa ação para você realizar uma ação. Então
eu utilizei o copywriting. A gente utiliza o copywriting todos os dias.
Se você chegar paraa sua esposa e falar assim: "Eu vou chegar pra minha
esposa, Priscila, vou falar assim: "Ó, ô Priscila, pega lá uma água para
mim agora, por favor." É uma coisa. Agora você falar assim: "Piscila,
vai lá pegar uma água. Para de falar, vai lá pegar uma água". Imagina se
eu falo isso para ela ou eu chego para ela e falo assim: "Pôvidoca, tô
na loucura aqui planejando a minha live de hoje. Tô montando um baita
conteúdo. Você sabe que eu fiquei até tarde de ontem lá trabalhando, por
isso que não deu tempo de planejar a aula ontem. Você não consegue pegar
uma água para mim ali rapidinho?" Copywriting, maneiras diferentes de
apertar os botões das pessoas para conseguir aquilo que a gente quer.
Beleza? Como que eu faço para ficar bom na arte de copy? Copywriting?
Você pode comprar um curso de COP, você pode assistir essa aula, você
pode ser aluno da comunidade subido de tráfego, você pode ser um subido
e ter acesso ao nosso curso. E você pode aprender isso com outras
pessoas. Sim, essa é a primeira maneira, é aprender com pessoas,
aprender com quem faz copy, com pessoas que escrevem, que fazem a, que
tem a habilidade da persuasão através das palavras escritas e faladas.
Você pode, mas a você tem que entender que para que você saiba se
expressar bem, para que você saiba escrever bem, para que você saiba
falar bem, o passo anterior a escrever e falar bem é você ouvir bem e
você ler bem. O que que eu quero dizer com isso? Eu quero, eu quero
falar aqui, o input é o primeiro passo para o output. Pedro, não entendi
nada do que você quis dizer com input e output. É o seguinte, o primeiro
trabalho que eu tive como gestor de tráfego na vida foi fazendo tráfego
pago para um professor de inglês. Esse professor de inglês, Mairo
Vergara, ele tem um método de aprendizado de inglês em que ele ensina
que o input é o primeiro passo pro output. Basicamente, a lógica dele é
o seguinte: quando você era criança, você não aprendeu a falar português
fazendo exercício de preencher colunas de palavras em português. Você
não aprendeu a falar português? escrevendo em português. Você não
aprendeu a falar português. Fala eh você não aprendeu a falar falando
português. Ah, Pedro, não, eu aprendi a falar falando. Não, mas presta
atenção. Antes de você falar, antes de você escrever, primeiro você
passou um tempão da sua vida escutando o português. Antes de falar, você
ficou escutando. Sua mãe chegava para você e ficava falando: "Mamãe,
mamãe, papai". Eu vou falar para meus filhos assim: "Subido, subido,
você ficou ouvindo, repetindo, ou seja, input. Input é tudo aquilo que
entra". Então lá ele, você ficou primeiro ouvindo um monte de informação
para que depois você conseguisse reproduzir. Na hora que você for
aprender a escrever, mesma coisa. A gente sempre fala aprender a ler e
escrever. Você nunca vai ouvir assim, aprender a escrever e ler, porque
você não escreve depois ler, não. Primeiro você aprende a ler, depois
você aprende a escrever. Então você consumir é sempre o primeiro passo
para você produzir. O consumo vem antes da produção. E isso é a lógica
base para você aprender copywriting. Porque copywriting nada mais é do
que você deixar de ser um consumidor e você passar a ser um produtor.
Você passar a ser a pessoa que coloca informação para fora. Então, o
primeiro passo para você ser um bom copywritter é você ler, é você ter
referências, é você consumir. Não existe ninguém que escreve muito bem,
que não leia muito bem. Ah, mas ler o quê? Claro que você pode ler
conteúdos que falam de copywriting, mas você também pode ler, sei lá, a
série do Harry Potter. Você pode ler o Trono de Vidro, você pode ler a a
trilogia, que não é uma trilogia, são cinco livros, mas não saíram os
dois últimos da quarta asa. Você pode ler Senhor dos Anéis, você pode
ler, cara, sei lá, você pode ler livros técnicos, você pode ler, você
pode ler qualquer coisa, você lê, você ter contato com a escrita, a, com
a leitura, desculpa, vai desenvolver cada vez mais em você uma
habilidade melhor de escrever, de escolher as palavras, de saber colocar
as informações para fora. E essa é uma dica péssima que eu tô dando para
você, né? Porque ela é uma dica que, putz, ela demora para ela fazer
efeito. E a verdade é essa, que para se para você se tornar um bom
comunicador, alguém que tem uma boa habilidade de output, ou seja, de
escrita e de fala, você precisa antes consumir muito conteúdo. Todas as
pessoas que escrevem bem, elas leem muito. Todas as pessoas que falam
bem, elas consomem muito conteúdo. E depois elas se preocupam em trazer
aquilo ali para fora, tá? Então, para você dominar o copywriting, para
você dominar a escrita persuasiva, a gente tem dois grandes caminhos.
Aprender com quem faz copia, e é por isso que você tá aqui nessa aula,
porque eu faço cópia o tempo inteiro, mas também entender que nunca você
vai ser um bom copywritter se você não colocar é densidade, profundidade
dentro dos seus conhecimentos. E aí eu não tô falando de você consumir
um tema específico, ler livros sobre desenvolvimento pessoal, livros
sobre copywriting, não é isso. É sobre você ter essa rotina de consumo
de conteúdo. Beleza? Esse é o passo um, simples assim, não vamos
aprofundar nisso daqui porque é o que é. Passo número dois, entenda o
seu público alvo. Toda persuasão, toda a habilidade de clicar nos botões
de alguém nasce a o pressuposto é você saber com quem que você está
falando. E existem basicamente quatro camadas que a gente tem para
entender com quem que a gente tá falando. Nós temos as definições
básicas, os níveis de consciência, as crenças e a atenção. Vamos passar
por cada um desses pontos. Camada número um, definições básicas. Vou
falar dela primeiro aqui. Quem é essa pessoa? Então, qual que é a idade
dessa pessoa? Qual que é o gênero dessa pessoa? Do que que essa pessoa
gosta? Do que que essa pessoa não gosta? O que que ela consome? O que
que ela não consome? Eh, que tipo de pensamentos que essa pessoa tem,
quais são os medos, as dores, os desejos, as objeções dessa pessoa? Como
que a gente faz isso hoje em dia? No passado, eu falaria para você fazer
uma pesquisa. Se você é gestor de tráfego pago, conversar com o seu
possível cliente de tráfego pago para ele te trazer essas informações.
Hoje nós temos inteligências artificiais que fazem isso pra gente, tá?
Então eu vou liberar no final dessa aula, na descrição dessa aula, este
agente de do chat GPT que faz essa parte de estudo de persona para você.
Basicamente como que ele funciona? A gente vai apertar aqui em começar e
aí você vai definir aqui, ó, qual é o nicho sobre o qual você deseja
fazer uma pesquisa de mercado e um mapeamento de persona. E aí eu
pergunto para você agora que qual o nicho eu deveria fazer aqui nessa
aula de hoje? Manda aí para mim que a gente trabalha um nicho específico
aqui junto. Pode me dar qualquer exemplo no chat. Manicuri. Vou pegar o
primeiro que mandaram aqui. Manicuri. Acho que não foi o primeiro, mas
foi o primeiro que eu bati o olho. Então, pessoas que querem contratar
uma manicure. Toma. Enviei aqui pessoas que querem contratar uma
manicure. E aí a pessoa fez uma pesquisa de mercado. Então eu botei aqui
ó, Juliana Ferreira, uma breve descrição sobre a Juliana, onde que ela
está. Eu poderia ter definido isso previamente. Ah, pessoas que querem
contratar uma manicure em Curitiba. Qual que é o problema principal?
Então, quer manter as unhas bonitas e bem cuidadas, mas ela sofre com a
falta de tempo. Profissionais inconsistentes experiências ruins. O que
que impede de alcançar o que ela deseja? Encontrar uma manicure
confiável, pontual, cuidadosa e constante. Emoções em torno do problema.
Frustração quando a unha quebra logo após fazer. Raiva de atraso.
Ansiedade antes de eventos importantes. Medo de infecção ou falta de
higiene. Culpa gastar dinheiro em algo que não dura. Medos: pegar uma
micose, ter uma cutícula machucada, inflamada, ir para um evento com a
unha feia, pagar caro num serviço mal feito, ficar dependente de uma
profissional que vive desmarcando. Como que isso afeta a vida dela? Fica
irritada antes de eventos sociais, desmarca compromisso quando a unha tá
feia, discute com parceiros sobre gastos superérflos, evita fotos em
eventos, se compara com as amigas que estão sempre impecáveis. Que que
ela já ouviu de frase ofensiva? É só unha, para que gastar com isso?
Você já fez essa unha? Nem parece. Nossa, já tá descascando. Não sei
como você tem coragem de deixar alguém mexer na sua cutícula. Isso é
frescura. Que que ela tentou no passado? fazer a própria unha, ir na
maricure mais barata do bairro, testar alongamento em gel, comprar kit
profissional, usar o o esmalte em gel caseiro. Que que ela já tentou no
passado? Ah, já fui numa manicura que atrasava 40 minutos, já saí com a
unha torta, já me machucaram feio tirando a cutícula. Já paguei cara e
não durou três dias, tentei fazer sozinha, mas não tenho coordenação.
Mas isso aqui, isso aqui é o ouro, tá? Isso. A partir disso daqui, eu
crio cópia para qualquer manicure. E eu nem sei, nem sabia nada de
manicure. O que que essas pessoas não querem fazer? Esperar horas no
salão e toda semana retocar, ficar refédo uma agenda cheia. Elas não
querem eh trecho do que? Que que não querem? Então, não quero perder o
sábado no salão, não quero sair sangrando, não quero esmalte
descascando, não quero profissional mal humorada, não quero ambiente
sujo. Que que ela deseja? Solução perfeita. Como que isso aqui impacta o
relacionamento dela? Quem que ela culpa pelos problemas que ela tem?
Quais são as objeções que ela tem? O que que encoraja os sonhos de
alguém que quer fazer a unha perfeita? O que que justifica os erros? O
que que alivia os medos? Confirma suspeitas? Quais são os culpados que
ela aponta? E os níveis de consciência que essa pessoa tem. Já vamos
falar sobre esse assunto aqui. Que que eu quero dizer com tudo isso aqui
para você? Pô, isso aqui é uma palhaçada, tá? Você conseguir hoje de
graça fazer isso daqui é incrível. Ai, Pedro, e pro meu nicho, eu vou
colocar o link para você ali depois você vai jogar ali, ele vai dar o
mesmo nível de resultado para você, pro seu negócio, tá? Então assim,
quem aqui não sabe nada de fazer tráfego para uma manicure, anúncios
para uma manicure e só de dar uma lida ali, você já se sente um pouco,
não tô dizendo 100%, mas um pouco mais confortável de desenvolver algum
anúncio para uma manicure só com o que você leu ali, hein? Fala para
mim, por favor. Ó, eu eu eu e eu eu, pô, eu me sinto eu me sinto mais
confortável. Pode, pode, pode, pode falar comigo no chat, não fique com
vergonha. Beleza? O que, por que que a gente se sente mais confortável?
Porque eu começo a entender mais de com quem que eu estou falando. Mas
essa é só a camada um. Essa é só a superfície. Normalmente as pessoas
elas vão ficar aqui nessa superfície. Aí a gente vai para uma camada
número dois. O que que é a camada número dois? A camada número dois são
os níveis de consciência, tá? todo curso, todo o conteúdo de COP que
você for consumir, vão falar para você dos tais níveis de consciência. E
isso daqui, presta atenção, é esse é um dos conhecimentos que se eu
fosse você, eu levaria ele em toda reunião de vendas para os seus
clientes. Ai, Pedro, mas eu nem sei tráfego pago direito. Eu nem sei.
Uma, eu vi uma mensagem no chat, ai, para quem não sabe tráfego pago,
como é que eu vou aplicar isso? Você tá construindo seus conhecimentos.
Você tem que entender que isso aqui é uma live, não é um curso. Então
você não tá na aula um do curso. É como se você tivesse lá na aula 39 do
curso quando eu tô falando de copywriting para você. Ah, mas então eu
vou embora, não vou ver esse conteúdo porque ele não serve para mim.
Não, esse daqui é um conteúdo extremamente valioso. Aprende ele e depois
você vai preenchendo os bloquinhos que você ainda não sabe, tá? Mas em
todo o curso de COP que você for fazer, vão te ensinar isso daqui. Eu tô
te ensinando isso aqui agora de graça. E a minha dica para você, o
asterisco que eu coloco para você aqui como gestor de tráfego, ensinando
algo para alguém que quer ganhar dinheiro com gestão de tráfego, é esse
daqui. É típica explicação que eu trago em todas as reuniões de vendas
dos meus clientes. Eu impressiono o cliente e mostro para ele que eu sei
do que eu tô falando, tá? Então eu sempre faço essa pergunta. Você já
ouviu falar nos cinco níveis de consciência do Eldin Schwartz? Quem que
é esse cara, Pedro? Eu sei que parece uma coisa meio, não sei, ele tá se
achando lançando uns termos em inglês, mas o Eldin Schwartz, ele tem um
livro, tá? Que se chama Breakthrough Advertising, deixa eu até colocar
aqui na tela, ó. E Schartz, Eugudini, Eugênio Schartz, tá? Então o Eldin
Schwartz, que é esse carinha aqui, ele é um copywritter famoso
americano, ele é um escritor americano de um um publicitário americano.
E o Eugene Schwartz, ele tem esse livro que se chama Breakthrough
Advertising, onde ele explica os cinco níveis de consciência.
Basicamente o que que esse cara traz de conceito nesse livro e como que
você vai explicar isso aqui pro seu cliente? Você vai falar o seguinte:
"Olha, tem um cara que se chama Eugen Schwartz, ele tem um livro e
quando ele escreveu esse livro, na época se acreditava no seguinte, que
a coisa mais importante para você vender para alguém era você saber com
quem você tá falando." Ou seja, você acreditava que o mais importante
era você dominar a camada um, era você saber isso daqui. Quem que é a
pessoa? Quem que é a Juliana Ferreira? Com quem que eu tô falando? se
acreditava nisso. Só que aí o Aldin Schwartz, ele chega e fala assim: "A
coisa mais importante para você vender para alguém não é saber com quem
você tá falando, é você saber o que que essa pessoa sabe e o que que
essa pessoa não sabe". E aí o Eldin vem e ele desenha, ele cria os cinco
níveis de consciência. Quais são eles? Nós temos a pessoa totalmente
inconsciente, nós temos a pessoa consciente do problema, nós temos a
pessoa consciente da solução, nós temos a pessoa consciente do produto,
nós temos a pessoa totalmente consciente. O que que é a pessoa
totalmente inconsciente? Eu vou pegar um exemplo aqui dentro do universo
do da gestão de tráfego pago e depois a gente volta pra manicure, tá?
Então, a pessoa totalmente inconsciente é o seu Zé dono da padaria. Ele
tem uma padaria de bairro. E vocês já viram algum meme na internet? Eu
até fiz um post disso daqui outro dia. Deixa eu ver se eu consigo achar
ele aqui rapidamente para mostrar para você. sobrar algum segundo. Acho
que vai ser fácil de achar. Pera, pera. Tô encontrando, tô encontrando.
Achei. Ó, o meme era esse daqui, ó. Então, seu João, você gostaria de
leades entrando no seu funil todos os dias? Faz sentido para você? E aí
a imagem de um senhorzinho num boteco que é a cara do Brasil, tá? Então
isso daqui é o quê? E eu falo nesse vídeo sobre níveis de consciência,
inclusive isso daqui é um lead totalmente inconsciente. É uma pessoa que
tem um negócio, mas ela nem sabe que ela tem que estar na internet, ela
nem sabe o que que é lead, ela nem quer ter Instagram para tá pensando
em vender mais através da internet. Então, totalmente inconsciente é o
seu Zé dono da padaria, nem sabe que precisa da internet para vender. Só
que aí o seu Zé, pô, as vendas começam a cair e alguém fala para ele:
"Ó, seu Zé, você tinha que tá na internet". Aí ele se torna consciente
do problema. Eu sei agora que eu tenho um problema. Putz, eu preciso
estar na internet para vender. Aí, só que ele não sabe como. Aí o seu
Zé, ele vai lá e descobre um dia numa conversa que existe um tal de
tráfego pago que vai fazer ele vender mais. Então agora ele sabe que
existe uma solução pro problema dele, que é vender mais. E aí o seu Zé,
ele se torna depois disso consciente do produto, tá? Que é, pô, beleza,
eu sei que existe tráfego pago para eu vender mais, mas eh como é que eu
faço para fazer tráfego pago para vender mais? Ele não sabe que existe
alguma coisa, um produto que resolve isso, que entrega tráfego pago para
ele. E aí o seu Zé, ele descobre que existem cursos que ensinam tráfego
pago. Pô, existem cursos. Então ele sabe que tem vários cursos na
internet que ensinam isso, mas ele não sabe exatamente qual comprar. E
aí entrou totalmente inconsciente que ele descobre que o produto do
Pedro resolve o problema dele, tá? Então eu poderia fazer esse exemplo
aqui de outras maneiras. Então, por exemplo, eh a pessoa que ela é
totalmente inconsciente, e eu fui totalmente inconsciente uma época que
eu sentia muitas dores de cabeça. A pessoa que é totalmente
inconsciente, presta atenção nisso, normalmente é a pessoa que tem
somente um sintoma. Ela não sabe que ela tem um problema. Então, no
passado, eu sentia muitas dores de cabeça. Eu sempre fui uma pessoa
super saudável, mas eu tinha dor de cabeça. Aí um dia eu tava lá na na
cadeira do meu dentista lá, ele tava fazendo uma limpeza nos dentes e aí
eu falei para ele, pô, comentei com ele que eu tinha dores de cabeça e
tal, aí no meio da consulta ele fala assim para mim: "Ah, você tem
bruxismo?" Eu era totalmente inconsciente. Acabei de virar consciente do
problema. Ele falou assim: "Você tem bruxismo? Você tem um problema." Aí
eu falei: "Tá beleza, eu tenho um problema. bruxismo. Aí eu perguntei
para ele qual que é a solução desse problema? Porque lembra, o terceiro
passo aqui é a consciente da solução. Eu sei que eu tenho um problema,
bruxismo, eu nem sei direito o que que é, mas eu quero saber a solução
do meu problema. Ele fala: "Ó, não tem solução." Aí eu me tornei
consciente da solução, porque eu sei que não tem solução, mas existem
maneiras de você minimizar o bruxismo, o bruxismo que está te causando o
seu sintoma, que é a dor de cabeça. Aí eu falei: "Tá beleza, quais são
as maneiras?" Aí ele falou assim: "Ah, você pode usar uma plaquinha
todos os dias antes de dormir, me tornou consciente do produto. Agora eu
sei que tem um produto que me traz a solução do meu problema ou ameniza
no caso." E aí eu falei: "Tá, mas onde que eu mando fazer essa
plaquinha?" E ele falou assim: "Ué, o dentista faz essa plaquinha para
você, ou seja, eu vendo isso para você." Meu dentista me falou. Então eu
fui de totalmente inconsciente a consciente total de totalmente
inconsciente para totalmente consciente em apenas uma conversa. Então
imagina que eu faço um anúncio e esse anúncio ele diz o seguinte: "Faça
eh faça sua plaquinha de bruxismo em menos de 48 horas". A pessoa que só
sente dor de cabeça, ela nunca vai clicar nesse anúncio, porque ela nem
sabe que ela tem bruxismo. E às vezes você faz os anúncios focando só em
quem sabe já que o seu produto existe, que o seu produto resolve a dor
dela. E muitas vezes você tinha que trazer algo mais informativo, por
exemplo, mostrar para aquela pessoa que a dor de cabeça que ela sente,
os dentes dela que desgastam, ela ranger os dentes de noite, tudo isso
são sinais de que ela tem um problema, bruxmo. E aí depois você resolve
o problema da pessoa, tá? Nesse agente de chat GPT que eu vou mandar
para você, ele já traz para você os níveis de consciência, tá? Então
você vai ver que aqui no final ele traz, ó, na no caso aqui a gente tá
falando da manicure, né? Então, totalmente inconsciente. A pessoa sente
que algo tá feio, mas ela não entende o impacto disso na autoestima
dela. Segundo nível de consciência, consciente do problema, percebe que
as unhas mal feitas estão prejudicando a imagem dela. Aí ela se torna
consciente da solução. Pô, eu preciso de uma manicure profissional e
fixa. Aí ela vira consciente do produto. Ela entende as diferenças entre
os produtos. o esmalte comum, gel, blindagem, blé blé blé, não sei o que
que é nada disso. E totalmente consciente, tá pronta para agendar com
uma manicura específica que transmite a confiança, tá? Então as pessoas
elas passam por esses níveis de consciência. Que que acontece? A maioria
das pessoas que vai fazer anúncios para uma manicure, elas vão falar com
esses três níveis de consciência. a pessoa que já tá buscando uma
manicure profissional, a pessoa que já sabe o que que é esmaltação, o
que que é gel, o que que é blindagem, ou a pessoa que, pô, já tá aqui,
ela já contratou quase no número cinco, né? Mas a gente não fala
normalmente nos nossos anúncios com esses dois níveis de consciência
diferentes aqui. E eu tenho que saber quais são os níveis de consciência
das pessoas com as quais eu vou falar. Beleza? Isso daqui é a camada
dois. Então, a camada um é entender quem é a pessoa, com quem que eu tô
falando. A camada dois é o saber o que que essa pessoa sabe, o que que
essa pessoa não sabe em cada um dos estágios onde ela está. Agora, a
camada três é são as crenças. É o que que essa pessoa acredita ou não.
Como que você vai levantar as crenças dessas pessoas? Isso daqui é um
pouco mais complicado, tá? Por que que é um pouco mais complicado?
Normalmente, para você entender o que que essa pessoa acredita ou não,
você tem três caminhos. Caminho número um, você já viveu o que essa
pessoa tá vivendo. Então, crenças, eu durante um tempo da minha vida, eu
achava que ganhar dinheiro na internet, a única maneira de ganhar
dinheiro na internet era vendendo curso na internet. E não é, eu ganhei
muito dinheiro sendo gestor de tráfego. Ah, mas hoje você vende curso?
Sim, porque eu sempre quis ser um professor e esse é o meu trabalho. Mas
eu tinha essa crença. Eu sei que a pessoa que quer ganhar dinheiro na
internet, às vezes ela pensa a mesma coisa. Então, eu já vivi o que uma
pessoa que quer ser um gestor de tráfego já viveu. Eu consigo
identificar algumas crenças. Segunda maneira da gente identificar as
crenças, tendo contato direto com os clientes ou fazendo pesquisas com
os clientes. Então, se eu tenho contato direto com a persona, com a
pessoa, com a com a Juliana Ferreira que eu tô vendendo no dia a dia ali
como manicure dela, eu vou conseguir entender o que que essa pessoa
acredita ou não. E é muito importante que isso seja feito de maneira
estratégica. Quando a gente tá falando de apertar os botões das pessoas,
a gente precisa ter uma cooperação entre o marqueteiro, nós gestores de
tráfego e o dono do negócio para que a gente busque essas informações. E
aí tem uma terceira maneira que é a gente utilizar as discussões da
internet sobre aqueles determinados assuntos para entender o que que
essas pessoas acreditam ou não. Então, onde que é o melhor lugar para
você encontrar discussões na internet sobre determinados assuntos?
Comentários de redes sociais, tá? Então assim, comentários de ah,
viralizou um vídeo sobre manicure. No comentário, a pessoa ela fala a
verdade, quem ela é, ela expressa o que que ela acredita. Twitter, então
comentário de Instagram, TikTok, Twitter, onde as pessoas fazem posts
sobre os assuntos, mas nem sempre vai ser fácil de você encontrar posts
sobre determinados assuntos. E por último e não menos importante, uma
ferramenta que se chama Reddit. O Reddit ele escreve assim, Redit, deixa
eu colocar aqui na tela. O Reddit ele é uma ferramenta, é um fórum na
internet. O que que você pode fazer? Você não precisa você ficar
buscando lá no Reddit. Você pode colocar o chat GPT para buscar para
você. E aí você vai fazer quatro buscas no chat GPT. Então eu vou eu vou
colocar o seguinte: busquem em comentários de Reddit os as ou as
principais soluções, opa, desculpa, as principais, ficou escrito errado
mesmo, as principais soluções que as pessoas acreditam que vão fazer com
que elas alcancem o objetivo do público alvo. Então, eu posso ir lá no
meu chat GPT e falar para ele o seguinte: eu posso colocar aqui o modo
de pensamento, né, para ele pensar durante mais tempo. E aí eu vou
colocar aqui, ó, busca em comentários do Reddit as principais das
pessoais soluções que as pessoas acreditam que vão fazer com que elas aí
eu vou apagar aqui o alcance porque não vai fazer mais sentido, mas com
que elas ganhem dinheiro através da internet. E aí eu vou mandar aqui,
eu posso colocar um um para para ele pensar. Ele vai pensar aqui
normalmente por alguns minutos, mas ele vai buscar em sites da internet.
Insites não, ele vai buscar no Reddit sobre esse tipo de comentário.
Então ele tá buscando no Reddit e ele vai ver o que que as pessoas estão
discutindo sobre esse determinado assunto. Isso daqui é uma prática que
a maioria das pessoas quando ela vai escrever um anúncio, quando elas
vão escrever uma página, elas ignoram, tá? E o que eu tô te passando
aqui é assim, segue esse passo a passo, vai na camada um, usa o chat
GPT, vai na camada dois, define muito bem os níveis de consciência, vai
na camada três, que é a mais difícil de ser feita, mas entende o que que
as pessoas estão falando sobre aquilo ali, tá? Então assim, as pessoas
vão me trazer as crenças aqui e aí vão me trazer as maneiras que elas
acham que dá para ganhar dinheiro na internet. Isso daqui vem com base
em discussões das pessoas. Eu consigo inclusive clicar aqui, ó, e ver as
discussões das pessoas. Aqui tem tanto Brasil quanto fora do Brasil. eu
posso deixar mais restrito ou mais aberto. E aí eu vou aí eu vou
pesquisar por soluções que as pessoas estão buscando, preconceitos que
as pessoas têm sobre o que que elas acham que dá para fazer, ou seja,
viabilidade, e o que que elas acham que não dá para fazer, ou seja,
inviabilidade. São as quatro principais pesquisas que eu gosto de fazer
para entender crenças das pessoas. Mas mais uma vez, você pode usar Iá,
mas você pode ir do jeito mais profundo, que é você parar e pensar como
que eu já caminhei nos, se eu já caminhei nos sapatos daquela pessoa,
quais são as crenças daquela pessoa. Ah, Pedro, mas eu sou gestor de
tráfego, eu tô trabalhando para alguém. Beleza, você vai perguntar isso
para essa pessoa, pra manicure, pô, você já buscou uma manicure? Que que
você acreditava e ter de solução para ficar com as unhas feitas? Então
vou buscar solução. Que que você tinha de preconceito de contratar
alguém para fazer suas unhas? Quais são os possíveis preconceitos que
alguém tem? O que que a pessoa acha que dá para fazer para ficar sempre
com a unha bem feita? E o que que ela acha que não dá para fazer? É
isso. Vou perguntar isso daqui pro pro GPT para ele pesquisar no Reddit,
mas eu posso perguntar pro profissional e posso buscar as discussões da
internet para entender mais sobre isso. Isso é uma etapa do processo de
pesquisa. Ela é a etapa mais importante de todas, porque eu tô
entendendo tudo sobre para quem que eu vou escrever, com quem que eu vou
estar falando. Uma vez que eu domino isso com profundidade, vai
acontecer aquilo que aquilo que a o sentimento que você teve quando eu
mostrei para você a pesquisa de público alvo, que eu falei assim, ó:
"Você se sente agora mais confortável para você se sente agora mais
confortável para escrever um anúncio para uma manicure". Você falou: "Me
sinto." Só que a gente só tinha passado pela camada um. Aí, uma vez que
a gente entende os níveis de consciência, uma vez que a gente entende os
preconceitos que a pessoa tem de contratar uma manicure, o o os o que
que ela acredita ser viável, as soluções que ela quer para ter as unhas
perfeitas, o que que ela acredita não ser viável. Uma vez que eu entendo
tudo isso, pô, eu já tô muito mais preparado para conseguir escrever
para esse público alvo, falar com esse público alvo, tá? Vou até colocar
um exemplo de manicure aqui, ó. Busque em comentários de Reddit os
principais preconceitos que as pessoas têm eh tem quando tentam eh
quando o assunto é fazer as unhas, contratar uma manicure, ter as unhas
bem feitas. Vamos ver. Eu eu acho que pro Reddit ele não vai encontrar
esse tipo de discussão, mas vou deixar ele pensando um pouquinho aqui.
Daqui a pouco a gente a gente volta aqui para continuar, tá? Pra gente
não pra gente não travar aqui. Vamos paraa camada quatro. O que que é a
camada quatro? A camada quatro é a gente entender que tipo de conteúdo
funciona e chama a atenção dessa pessoa, tá? Então, presta atenção. Na
camada um, eu entendi, pô, quem é essa pessoa. Então, lá nas definições
básicas, fui lá, vou até colocar de azulzinho aqui, ó. Entendi quem é
essa pessoa. Na camada dois, eu vou entender o que que essa pessoa sabe
e o que que essa pessoa não sabe. Na camada três, eu vou entender o que
que essa pessoa acredita ou o que que ela não acredita, que preconceitos
que ela tem. Na camada número quatro, eu quero entender o que que que
ativa o botão dela, que tipo, tipo assim, eu tô eu tô num jantar, eu tô
num jantar com você e a, sei lá, você e o seu marido ou você e a sua
esposa, a gente tá no jantar, a gente saiu, a gente é amigo, a gente se
conhece há um tempo já. Aí a gente tá lá, sei lá, comendo um sushizinho
de noite, a gente tá batendo papo, aí daqui a pouco o seu marido, a sua
esposa faz um comentário para você, você fica visivelmente puto ou
visivelmente brava, tá? Visivelmente aquilo ali incomodou você, aquela
implicânciazinha que aquela pessoa soltou com você, apertou o seu botão.
Nessa hora, eu, como um observador do comportamento humano, eu vou olhar
e vou falar assim: "Hum, isso incomoda essa pessoa". Agora, o que que eu
tenho que fazer quando eu tô falando da internet? Eu tenho que entender
o que que chama a atenção da pessoa com a qual eu quero falar. Então,
por exemplo, como que nós vamos fazer isso daqui? Nós vamos fazer isso
da seguinte maneira. Deixa eu, Nós vamos fazer isso da seguinte maneira.
Eu vou vir aqui no Instagram e vou pesquisar. Putz, eu não sei se dá
para fazer pelo computador. Tudo bem. Se não der para fazer pelo
computador, eu faço pelo celular aqui e consigo te mostrar. Eu vou
pesquisar manicure e vou apertar enter. Não, não vai dar para fazer aqui
pelo computador. Tudo bem, eu faço pelo celular, tá? Deixa eu
compartilhar aqui só a câmera com você. Deixa eu tirar a luz do meu do
meu celular. Meu Instagram no meu celular ele é bloqueado por um
aplicativo, então eu tenho que desbloquear ele antes aqui. Ele vai pedir
para eu respirar durante 5 segundos para eu me acalmar e não cair no
vício de mexer no meu celular sem querer mexer no meu celular. Mas eu
vou dar o pause aqui de 15 minutos. Agora sim. Vamos lá. Então, o
seguinte, eu vou vir aqui no meu Instagram, eu vou apertar aqui embaixo
na lupinha de pesquisa, ó. Então, aqui embaixo tem uma lupa de pesquisa.
Vou apertar aqui na lupa de pesquisa. Aqui em cima, no pesquisar, ó, tem
aqui a parte, tem o pesquisar aqui em cima, eu vou digitar manicure, tá?
Que é o meu exemplo, tá? E aí eu vou apertar no na busca aqui, Vou
apertar nesse botãozinho azul de buscar. Apertei em buscar. Que que ele
vai aparecer aqui para mim? Ele vai aparecer aqui para você, tá? Que é
essa primeira aba, contas, áudios, tags e locais. Eu vou olhar
principalmente nos posts. E o que que eu vou encontrar aqui nos posts?
Eu vou encontrar os posts que mais deram resultado, tá? Então, perceba
aqui, ó, que esse primeiro post dessa moça, ele tem 10.6 6 milhões de
visualizações. O outro post tem 6 milhões, 9 milhões, 7 milhões. Ou
seja, as pessoas que viram esses posts, elas se identificaram com aquilo
ali que tá passando, ó. Então, olha só esse post aqui, ó. Olha como é
que era o vídeo. Pera aí que eu vou ter que diminuir a luz, senão você
não vai conseguir ver, ó. Vou voltar aqui, ó. É a moça mexendo a mão e a
manicure borrando a unha. E aí depois aparece a marca de luva na no
rosto dela, como se ela tivesse levado um tapa. Então eu já sei que as
manicures vão se identificar com isso daqui. Eu sei que as pessoas que
pintam a mulheres, por favor, me diz se isso daqui é uma coisa, tá? Tipo
assim, se é uma coisa que acontece às vezes, tipo, você mexeu a mão e a
manicure borra. Eh, você acha que isso daqui é algo comum? Aí eu vou
encontrar aqui, eu vou ler os comentários, eu vou ver o que que as
pessoas estão falando. Então eu eu não sou manicura, eu não sei nada
sobre manicure. Eu não sei nada sobre pintar unha, não, eu não sei lá,
eu já tirei a cutícula porque minha esposa me obrigou basicamente. Mas
como você pode perceber pela minha mão, a minha mão tá sempre destruída,
principalmente porque eu passo um monte de magnésio na mão, minha mão
fica toda seca. Mas eu vou encontrar aqui conteúdos que aceito. E meu
amor, vou encontrar aqui conteúdos que de alguma maneira vão fazer com
que eu entenda o que que chama a atenção daquela pessoa. Ó, esse aqui é
um postozinho de transição. Então, chamou a atenção da pessoa, vê o v a
unha antes, cai o pinguinho do esmalte e como que é depois. Tem aqui um
timeelapse de alguém fazendo uma unha que aparentemente tá mais
destruída do que a minha com uma musiquinha. E isso daqui, sei lá, é
satisfatório para alguém. Estamos na minha live vendo vídeos de unha
sendo feitas [música] e talvez poderia ser alguma coisa que que chama a
atenção das pessoas. Então eu começo a entender um pouco mais sobre o
que que ativa a atenção das pessoas e guarda essa informação aqui sobre
a gente pesquisar o nicho no Instagram, porque isso daqui vai ser útil
já pra gente, tá? Então que que eu faço? Eu entendo que tipo de conteúdo
e chamo a atenção dessa pessoa. Eu tô fazendo isso daqui numa busca
rápida. Eu tô vendo dois, três vídeos. Você quando for fazer conteúdo,
quando você for criar anúncios para um profissional que trabalha nessa
área, você vai fazer essa pesquisa aqui durante 20, 30, 40 minutos
procurando e salvando os links dos vídeos que mais chamam a atenção do
público alvo. E aí quando a gente termina de fazer isso, a gente começa
a estar apto para escrever para esse tipo de público. Eu, Pedro Sobral,
só de fazer isso daqui que eu fiz agora com você aqui rapidamente. Eu já
me sinto 100% apto a escrever e criar excelentes anúncios para qualquer
manicure, provavelmente muito melhores do que qualquer pessoa do mercado
vai conseguir criar, tá? Então vamos fazer isso agora juntos. Aqui eu
vou te mostrar como que eu vou fazer isso. Para escrever um anúncio, eu
entendo que existem cinco pilares de de um bom anúncio. Um bom anúncio,
ele é primeiro baseado em referência. Você não precisa ser a pessoa mais
criativa do mundo para fazer um bom anúncio. Você tem que ser a pessoa
mais interessada e pesquisadora para fazer um bom anúncio. Agora,
existem basicamente dois grandes lugares onde a gente vai criar bons
anúncios, onde nós vamos, aliás, onde nós vamos buscar referências de
bons anúncios. Qual que é o primeiro lugar? Fala para mim, eu já mostrei
ele para você nessa live aqui. Qual que é o primeiro lugar? Deixa eu
ver. Instagram. Instagram no próprio Instagram. Então, vou dar um
exemplo. Isso daqui que a gente viu aqui, ó, de exemplo de vídeo, é, ó,
vou pegar um outro exemplo aqui de vídeo, ó. Passei na prova, a pessoa
indo fazer a unha. Hoje é meu aniversário, a pessoa indo fazer a unha.
Eu disse sim, indo fazer a unha. Vou fazer minha primeira viagem, indo
fazer a unha. Comprei meu carro, vou fazer a unha. Tô grávida, fiz a
unha. Todos são motivos pra pessoa ir fazer a unha. Isso daqui é o quê?
Isso daqui é um vídeo que chamou a atenção das pessoas, provavelmente
mulheres, que se identificam e que, pô, toda situação da minha vida, eu
busco, eu busco fazer eu busco fazer a unha. Então isso daqui é uma
referência. Uma outra referência é um pouco mais engraçadinha, é, é um
pouco mais engraçadinha, mas isso daqui é uma outra referência. É um
vídeo que mostra o que que toda mulher, toda manicure detesta, que é
quando a pessoa mexe a mão e borra. Aí depois tem o senso de humor
atrás. Mas eu poderia conectar isso daqui depois com uma chamada paraa
pessoa agendar um horário, paraa pessoa não passar por aquilo, etc, etc.
Então o que que eu tô fazendo aqui? Eu tô utilizando, presta atenção, eu
tô utilizando as próprias ferramentas que existem na internet, os
produtores de conteúdo na internet para testarem os anúncios e conteúdos
por mim. Todo produtor, eu vou escrever isso aqui, ó, todo produtor de
conteúdo do seu nicho está o tempo todo testando anúncios para você.
Você tem que desenvolver, e eu sei que é meio fake falar assim: "Ah,
você tem que desenvolver esta mentalidade", mas sim, você tem que
desenvolver essa mentalidade. Isso aqui tem que clicar na sua cabeça,
que as pessoas elas estão testando as coisas para você. Elas estão
testando e validando. Se eu pegar aqui os vídeos de manicura, eu vou
encontrar centenas, milhares de vídeos de manicure. E eu tenho certeza
absoluta, absoluta que eu vou encontrar aqui nessa lista de vídeos que
tem milhões de visualizações, os meus melhores anúncios. Os meus
melhores anúncios, eles estão aqui. Eles eles foram testados pelas
outras pessoas. Ah, mas eu vou roubar esse vídeo aqui. Não, você não vai
roubar. Você vai recriar esse vídeo aqui, mas ele tá sendo feito com
base numa referência, tá? Segundo lugar, onde nós vamos encontrar os
nossos melhores anúncios é numa ferramenta chamada biblioteca de
anúncios. O que que é biblioteca de anúncios? Tem gente que vai dizer
que a biblioteca de anúncios ela é uma ferramenta de espionagem. Que que
é? Como assim? Uma ferramenta de espionagem. Basicamente é o seguinte,
você vai entrar aqui, ó, no Google, tá? E aí você vai digitar aqui no
Google Biblioteca de anúncios. O primeiro link que vai aparecer aqui
para você é a o link da biblioteca de anúncios, tá? Você vai entrar aqui
dentro dele e aqui você vai colocar Brasil, você vai colocar a categoria
do anúncio, todos os anúncios. Você pode pesquisar aqui pelo nome da
pessoa que você quer ver os anúncios. Então eu posso clicar aqui e botar
Pedro Sobral. E aí vão aparecer aqui as o meu perfil, né? Então aqui, ó,
Pedro Sobral Subida, eu vou clicar aqui no meu perfil e aqui você vai
encontrar todos os meus anúncios que estão rodando. Aqui nessa página
são poucos, né? Eu tenho várias páginas rodando anúncios, por isso que
você vai ter que entrar em mais de uma para encontrar os anúncios que
estão ativos. Ó, nessa página aqui, ó, Pedro Sobral, Comunidade Subida,
eu tenho 160 anúncios ativos. Então aqui eu vou encontrar todos os meus
anúncios que estão sendo veiculados ultimamente. Eu posso, sei lá,
pesquisar lá pelo Leandro Ladeira. Deixa eu pegar a página do Ladeira
aqui. Vamos ver o que a gente encontra, ó. Vou pegar a página do
ladeirinha. 600 anúncios ativos. Ele tá concentrando mais anúncios numa
única página. Então aqui eu encontro todos os anúncios do ladeira. Que
que eu posso fazer? Eu posso assistir os anúncios do ladeira aqui. Então
eu posso dar play no anúncio do ladeira e assistir o anúncio dele para
entender se esse esse é para entender a estrutura do anúncio dele, tá,
Pedro? Mas lá no Instagram, presta atenção aqui em mim agora que aqui
veio o grande pulo do gato. Lá no Instagram eu consigo ver as
visualizações dos vídeos. Então, todos esses vídeos que estão aparecendo
para mim de manicure aqui, eles foram validados porque ele tem eles têm
muita visualização. Agora aqui quando eu entro na biblioteca de anúncio,
eu não tenho essa validação. Correto? Não. Incorreto. Você tem essa
validação, sim. Aqui, como que você vai fazer isso aqui? Quando eu
pesquiso os anúncios de alguma pessoa ou de um determinado tema, eu
tenho a parte aqui de filtros, tá? Então eu posso filtrar pelo idioma,
pela plataforma onde o anúncio tá aparecendo, pelo tipo de mídia, pelo
status eh do anúncio, se ele tá ativo ou se ele tá inativo. E eu posso
colocar impressões por data. Ou seja, que que eu posso fazer aqui? Eu
posso jogar aqui os anúncios que não tiveram, aliás, que que não estavam
rodando ou que que tiveram impressões somente do dia de 17 de fevereiro
de 2019 até a semana passada. Por que que eu faço isso? Porque eu tô
dizendo basicamente pra meta aqui, ó. Eu não quero os anúncios que
apareceram aqui nesses dias. Ah, por que que eu não vou querer os
anúncios que apareceram nos últimos s dias aqui? Porque pode ser que os
anúncios que apareceram nos últimos 7 dias sejam novos anúncios que o
ladeira tá colocando no ar. E aí eu vou pegar os anúncios mais novos que
eu não sei se estão funcionando, eu não sei se foram validados. E aí eu
vou aplicar o filtro aqui. Agora o que que eu tô vendo? Eu só tô vendo o
anúncio que tá tendo impressão da semana passada para trás e ainda assim
tem muito anúncio. E aí eu vou fazer ainda mais um pulinho do gato. Eu
vou classificar por, aliás, eu vou classificar por mais recentes. A
classificação padrão mostra as os anúncios que estão tendo mais
impressões até os que estão tendo menos impressões. Que que eu quero
dizer com isso? A classificação padrão, ela vai mostrar primeiro os
anúncios que mais estão recebendo tráfego. A tendência, presta atenção,
é que os primeiros sejam os melhores, tá? Dessa maneira. Então, os
primeiros anúncios aqui é onde ele tá gastando mais dinheiro, é os que
estão aparecendo mais. Provavelmente esses daqui são os melhores
anúncios, tá? Então, se eu pegar aqui, ó, esse videozinho aqui dele, eu
vou eu vou pegar um vídeo que provavelmente tá gerando muito resultado
para ele. Detalhes que mostram que um anúncio é bom também, a
veiculação, quando que ela foi iniciada? Tá vendo que esse anúncio aqui
começou a rodar no dia 20 de novembro de 2025? Isso aqui foi ano
passado, faz 2, 3 meses que esse anúncio tá no ar. Ninguém que sabe o
que tá fazendo deixa um anúncio no ar por 2, tr meses. Esse aqui é um
bom anúncio. Agora, o que que vale a pena você fazer? Não só ver os que
mais têm impressões, porque pode ser que ele esteja gastando pouco
dinheiro num anúncio, mas ele tá funcionando muito. Aí, por que que ele
tá gastando pouco dinheiro num anúncio que tá funcionando muito? Porque
pode ser que ele esteja anunciando para um público muito restrito. Então
é um baita anúncio, tá funcionando super bem, mas pelo público para o
qual ele tá anunciando ser restrito, ele não tá recebendo muita
impressão. Que que eu gosto de fazer? Eu gosto sempre de pegar aqui os
10 últimos, os 10 anúncios na classificação por impressões, mas eu
também gosto de filtrar pelos mais recentes. E aí vão aparecer primeiro
os anúncios novos dele aqui. E aí eu vou fazer o quê? Eu vou até lá
embaixo na listagem dos anúncios. Por quê? Porque eu quero os mais
antigos, eu não quero os mais recentes. Então eu vou até o final. E aí
os que aparecerem por último, por mais que eles estejam com poucas
impressões, que eles não estejam aparecendo muito, normalmente são
anúncios que estão gerando resultado para aquela pessoa, tá? Então aqui,
ó, eu vou até o fim e aí eu vou pegar os 10 últimos, que normalmente ali
eu vou encontrar bons anúncios que estão fora do radar da maioria dos
anunciantes. Faz sentido isso daqui que eu tô te trazendo? E assim, eu
tô realmente, ah, é uma biblioteca de anúncio, eu já conheço, tá beleza,
mas você tá usando ela de que jeito? Você tá usando ela do jeito certo?
Você tá só vindo aqui de maneira aleatória ou você tá fazendo um
trabalho pensado? Tá? Ah, Pedro, e aí o que que eu faço aqui? Minha
sugestão para você, você consegue baixar os vídeos da pessoa ou as
imagens da pessoa, como existem extensões do Google Chrome que fazem
isso, tá? Eu utilizo essa daqui que é o Adr Library Cloud, tá? Eu vou
deixar no final da aula, na descrição desse vídeo, o link da extensão,
ela é gratuita. E aí, basicamente, o que que eu consigo fazer aqui? Eu
consigo pegar o vídeo e apertar em baixar. Aqui eu aperto em download
media mídia e aí ele vai baixar o vídeo para mim. E agora esse vídeo tá
no meu computador, tá? Que que eu faço com esse vídeo aqui? Eu vou
copiar ele? Não, mas a gente vai extrair deste vídeo a estrutura dele, o
por que esse vídeo funcionou bem, tá? E como é que eu vou extrair desse
vídeo a estrutura dele? Calma, meu querido, eu tô aqui para te entregar
o ouro. É o seguinte, eu montei para você aqui um agente de chat GP. Oi,
quase que eu cliquei no link errado. Deixa eu pegar o link aqui. Eu
peguei, eu criei para você aqui um agente de chat GPT que extrai a
estrutura. Ele é o extrator de estrutura, tá? Então, deixa eu só mudar
aqui o modo do meu chat GPT. Eu vou apertar aqui em começar e aí ele vai
me pedir na hora aqui, ó, envio o material bruto, transcrição do
anúncio, descrição visual completa. Aí você vai falar assim: "Pedro,
putz, mas eu vou ter que transcrever, vou pegar aqui, ó, todo esse vídeo
do ladeiro aqui, eu vou ter que transcrever todo ele. Como é que eu vou
descrever visualmente o que que tá nesse vídeo aqui? Isso aqui é
difícil. Você vai fazer o seguinte, você vai abrir o Gemini, tá? O
gemini.google.com, Google.com, tá? Você pode ter a versão paga ou a
versão gratuita, tanto faz. Eu vou apertar aqui no maisinho do Gemini e
eu vou enviar o arquivo pro Gemenai. Então eu vou pegar aqui o vídeo do
ladeira. Opa. Vou pegar aqui o vídeo do ladeira e vou enviar o vídeo do
ladeira aqui para ele, tá? No caso é o exemplo que eu tô usando aqui
para você. Ué, não enviou por algum motivo. Ah, ele tá baixando. Acho
que eu peguei. Agora vai dar certo. Aí, agora foi. Tá aí, subias vezes.
Ih, cagata. Pera aí. Deu, subiu o vídeo do ladeira. Aí eu vou falar para
ele o seguinte. É, vamos pegar aqui exatamente transcrição do anúncio e
a descrição visual. Aí eu vou mandar para ele o arquivo e vou falar
assim, ó. Me envie. a dois pontos, transcrição do anúncio e a descrição
visual completa. Vou enviar para ele isso daqui. A própria ferramenta de
A, ela vai gerar para mim isso daqui que eu preciso, tá? Então ela vai
analisar, vai entender, vai pensar, vai abrir a análise de vídeo que o
GPT não consegue fazer, mas ela consegue fazer aqui e ela vai me trazer
todas essas informações. Uma vez que ela me trouxe essas informações, ó,
então ela tá me trazendo aqui, ó, toda a transcrição, transcrição exata
do anúncio, descrição visual completa, tudo, tudo, tudo, tudo, tudo,
tudo sobre o anúncio. Vou pegar isso daqui, vou dar contrl C, vou ir lá
no agente do chat GPT, que eu vou liberar para você depois e vou dar
conttrl V aqui, ó. Vou mandar para ele, ó, tudo aquilo que ele me trouxe
aqui. Mandei para ele. Aí ele vai reestruturar o roteiro para mim, tá?
Como que ele vai reestruturar? Ele já vai deixar o roteiro mais pausado
da maneira que é falada dentro do vídeo, tá? Então ele monta para mim,
me manda todo o roteiro de volta aqui. Isso aqui vai servir até para ele
nos ajudar depois, tá? Então ele vai mandar, ele vai me dar uma direção
visual de edição. Então qual que é o estilo predominante? como que tá a
edição. Ele vai fazer uma, ele vai ele vai fazer uma, uma exploração,
ele vai extrair completamente a estrutura do vídeo, tá? Beleza? Fez a
extração aqui, ele vai ficar, ele vai mandar mais respostas, tá? Então,
ele vai fazer toda a extração para mim. Depois que ele fizer a extração,
ele vai me pedir algumas informações do meu negócio para que eu para
para eu fazer um roteiro igual aquele ali, tá? Então ele me mandou aqui,
ó, no final, e é isso daqui que a gente realmente quer, o modelo
editável. Eu nunca vi alguém ensinar blé. Na hora você vai pensar, é por
isso que porque nada deixa você tão quanto saber. Tanã, ele vai fazer
toda, ele vai montar para mim os espaços vazios. Aí ele vai me perguntar
quem é minha persona, qual que é o resultado que essa persona deseja. Aí
eu posso pegar, por exemplo, a minha persona de manicure e mandar para
ele. E aí ele vai fazer o roteiro aplicado a Juliana. Você já saiu do
salão três dias depois, unha descascando, já pagou caro, mesmo assim não
durou nenhuma semana, ou pior, já saiu com a cutícula machucada,
ardendo, inflamada? Não é só unha, é a forma como você se sente. É
quando você olha, a forma como você se sente quando olha pra própria
mão. Porque quando a unha tá feia, você evita foto, evita close, evita
evento. O problema não é você, não é frescura. O problema é que a
maioria dos salões trabalha por volume, encaixa cliente, atraso, pressa,
material duvidoso e você paga a conta. Preço baixo quase sempre sai
caro. Profissional vive atrasando e não respeita sua rotina. O esmalte
que dura três dias não é técnica, é descuido. Existe uma diferença entre
fazer unha e ter um padrão. Atendimento pontual, material esterilizado,
técnica que preserva sua cutícula, a esmaltação que dura até 15 dias sem
descascar. O cliente que antes dizia: "Já me machucaram feio", hoje diz:
"Faz duas semanas e continua perfeito, sem sangrar, sem correr para
retocar, sem perder sábado interno do salão. Imagine para um evento e
não pensar na sua mão, tirar foto e se sentir impecável. Isso não é
luxo, isso aqui é padrão. Se você quer uma maniacuri fixa, pontual,
cuidadosa, com padrão de higiene real, clica no link abaixo e agenda o
seu horário. As vagas são limitadas porque eu não atendo por volume, eu
atendo por qualidade. Clica e garante sua vaga. Pô, isso daqui é um
baita anúncio. Ainda tem até uma direçãozinha aqui de como é que vai,
você vai estruturar esse anúncio. Pô, você tá de palhaçada para mim se
isso daqui não vale ouro. Porque eu não tô simplesmente chegando pra
inteligência artificial e falando para ela assim: "E ah, faz um anúncio
para mim. Não, eu tô chegando pra inteligência artificial e eu tô usando
ela de maneira estratégica, eu tô usando ela de maneira inteligente, eu
tô usando ela com base numa referência. E tudo isso vem de um
conhecimento que é meio óbvio. Ah, um bom anúncio é feito a partir de
referências. Beleza. Como que você faz isso daqui no seu dia a dia? Como
que você faz isso aqui no dia a dia? faz. Ah, isso aí todo mundo sabe. É
beleza. Mas como que você pega esta merda desta informação e você
transforma isso daqui em ação? É isso daqui que é sobre isso que são as
lives de terça-feira aqui. Não é só sobre a informação, não é só sobre
te falar: "Ah, é baseado em referências". Ótimo, se vira aí para fazer,
não. É baseado em referências. Agora, como que você vai implementar
isso? É esse passo a passo, tá? Esse passo a passo aqui que você tem,
isso aqui é nível sobral de conteúdo, tá? Isso aqui é subido. Isso aqui
é subido. Isso aqui, se você acha que isso aqui é bom, é porque você não
viu o nosso curso completo, tá? É porque você não viu o curso completo.
Isso aqui é o grátis, tá? Então, passo número um, primeiro ponto,
lembra? A gente tá falando o quê? Sobre criar um bom anúncio. Um bom
anúncio é baseado em referências. Ponto número um. Ponto número, opa,
ponto número dois, um bom anúncio, ele é camuflado ou ele é explícito?
Que que eu quero dizer com isso? Tá, esse é um conhecimento que eu já
trouxe, mas eu quero te dar mais exemplos para isso ficar claro na sua
cabeça. Existem dois tipos de anúncio. O que que é um anúncio camuflado?
É um anúncio que foi feito para não parecer um anúncio. Tem pessoas que
vão te falar assim: "A única, a melhor, a única maneira de você fazer um
bom anúncio é se ele não parecer um anúncio. O seu anúncio não tem que
parecer um anúncio. Eles estão certos?" Não. Eles estão errados? Também
não. O seu anúncio, ele pode não parecer um anúncio. Só que você tem que
ter também anúncios que parecem com anúncios. Por quê? Porque os dois
funcionam. O anúncio que não parece com anúncio, normalmente ele vai
conversar melhor com uma pessoa que ainda não te conhece, uma pessoa que
tá num nível de consciência mais baixo, que não sabe que tem um
problema, mas que tem um sintoma, ou que sabe que tem um problema, mas
não sabe que existe uma solução para aquele determinado problema. Então,
o anúncio camuflado aquele anúncio que ele é um e ele é um anúncio que
se sente conteúdo, né? Então assim, ele é um anúncio, mas ele se
identifica como conteúdo. Ele normalmente vai falar melhor com esse tipo
de público. Agora, um anúncio que parece um anúncio, ele vai funcionar
melhor com a pessoa que tá pronta para comprar, pronta para receber a
oferta. Agora, como que você vai fazer anúncios camuflados? Presta
atenção, porque tudo que eu tô te explicando aqui vai ser utilizado.
Lembra que a gente pegou o nosso Instagram? Pera aí que eu vou ter que
desbloquear meu Instagram de novo. Lembra que a gente pegou aqui o nosso
Instagram e a gente procurou os vídeos de manicure? O que que você vai
encontrar lá? Lá você vai encontrar a sua lista, sua referência, sua
lista de referências de anúncios que não parecem um anúncio, ou seja,
anúncios camuflados. Todos esses daqui são seus anúncios camuflados.
Não, exatamente o mesmo vídeo, mas você vai encontrar aqui o que que tá
funcionando, tá? Então esse aqui é o primeiro lugar local. Que que você
pode fazer? Você pode pegar esses anúncios aqui, que são os camuflados,
tá? esses conteúdos, esses conteúdos que deram certo, você pode pegar
eles e você pode ir lá no Gemini, presta atenção, você vai lá no Gemini
e você vai pedir para ele, olha, transcreve este anúncio, este conteúdo
e me dá a descrição completa desse vídeo. Aí ele vai transcrever e me dá
a descrição completa do vídeo. Pá, trouxe tudo para mim, toda
transcrição, toda, tudo bonitinho ali para mim. Ótimo. Que que eu posso
fazer? Eu posso pegar isso daqui e eu posso jogar isso daqui lá no nosso
agente de chat GPT. Aí eu vou jogar isso daqui lá no extrator de
estrutura e ele vai trazer para mim aquela estrutura ali para que eu
possa replicar. Só que às vezes você nem precisa fazer isso, tá? Às
vezes, só de bater o olho no vídeo aqui, só de olhar esse vídeo que tá
aqui, você já sabe porque é o que que fez, que que aquele vídeo tem de
bom, o que que aquele vídeo é como que você pode replicar aquilo ali.
Mas você não só pode ficar aí, você pode pegar formatos que são
validados na internet. Então, por exemplo, eu posso pegar aqui aquele
formato que é tipo um formato de palestrinha. Então, ó, PV, como o meu
cérebro funciona? Ele tá dando tipo uma aula na frente de uma TV. Eu
poderia como pedir para uma manicure gravar isso daqui. Por que que você
deveria contratar eh uma manicure do salão blá blá bléu? Aí aparece a
primeiro ponto, a gente não atrasa. Segundo ponto, não sei o quê.
Terceiro ponto, n l n. Que que eu posso fazer? Eu posso baixar esse
vídeo, eu extraio a estrutura desse vídeo e eu adapto ele pra manicure.
E aí o que que eu vou fazer? Eu vou fazer no mesmo formato com a TV
atrás de mim, a manicure falando que que é isso daqui? é o melhor
anúncio do mundo, só ele vai ser a solução para todos os meus problemas.
Não, mas é um baita de um anúncio. É um baita de um anúncio. Por quê?
Porque ele é camuflado. Ele parece aquilo que as pessoas já estão vendo
na internet. Ele parece com aquilo que o algoritmo do orgânico tá
valorizando. Vou pegar um outro exemplo. Eu posso fazer um vídeo
narrado, um anúncio narrado. O que que é um anúncio narrado? Tem essa
moça que ela chama Jenny Keller. Cara, os conteúdos dela são incríveis,
tá? A Jenny Keller, ela não, ela tá narrando o vídeo, são várias imagens
e ela tá, tem o a voz dela no fundo falando, mas ela não tá no vídeo ela
falando na frente da câmera. Eu posso fazer um anúncio que é parecido
com esse formato. Eu posso pegar outro formato. Deixa eu pegar aqui. Eu
salvei alguns. Eh, esse aqui não vai ficar tão bom no exemplo. Vou pegar
esse daqui, ó. Ai, meu Deus, foi mal, eu abri o link errado. Ó, uma
opinião polêmica. Aí a pessoa tá aqui uma opinião polêmica com uma
plaquinha na rua e aí uma mãe veio dar uma opinião polêmica. Eu posso
até fazer um que seja fake. Eu posso fazer um vídeo que é uma manicure
escrito assim: "Só a unha não é feia, só manicure que é ruim. me prove o
contrário. E aí a manicure aí chega uma pessoa revoltada falando alguma
coisa com ela. O quanto que isso não chamaria mais atenção do que um
vídeo padrão que tem por aí. E o que que eu tô fazendo? Eu tô pegando
uma estrutura. Eu tô pegando um uma estrutura de vídeo e eu estou
inserindo nessa estrutura de vídeo o quê? Quem é essa pessoa? O que que
ela sabe? O que que ela não sabe? o que que ela acredita, quais são as
crenças dela e o que que chama a atenção dessa pessoa. Eu tô pegando
aquela primeira parte do trabalho que eu fiz e eu tô inserindo aqui
dentro. Quando eu tenho aquela primeira parte num documento organizada,
bonitinha, eu chego para Iá e falo assim: "Iá, essa daqui é a estrutura
do vídeo. Eu quero falar com essa pessoa aqui junto os dois. Eu tô, eu
não tô fazendo um trabalho que um robô faria, não. Por quê? porque eu
estou trabalhando junto com a inteligência artificial para que ela faça
o trabalho para mim. Então, todos os dias que você tá na internet e você
vê o mesmo estilo de vídeo, aquele mesmo formato de conteúdo que tá
funcionando, que tá bombando, aparecendo para você, aquilo ali são
exemplos de anúncios. Por quê? Porque todo produtor de conteúdo do seu
nicho tá o tempo todo testando anúncios para você. Todo produtor de
conteúdo do seu nicho tá o tempo todo testando anúncios para você. E não
só do seu nicho, todo produtor de conteúdo. Ponto. Tá testando anúncios
para você. Tudo aquilo que tá funcionando tá sendo testado para você.
Tudo, tá? E aí depois disso daqui a gente tem o quê? Nós temos o
anúncio. Então, o anúncio camuflado, deixa eu escrever aqui, é o anúncio
que se parece com o tipo de conteúdo que está dando certo nas redes
sociais. Ponto. Agora, o anúncio explícito são os outros 99% dos
anúncios que parecem com anúncios. Eu não devo fazer o explícito, ele é
pior do que o camuflado? Não. O explícito, na maioria das vezes, vai
vender mais do que o camuflado. Mas o camuflado vai ser o primeiro
contato que muitas vezes as pessoas vão ter com você para no futuro elas
comprarem de você através de um anúncio explícito, tá? Então, primeiro
elemento de um bom anúncio, ele é baseado em referências. Segundo
elemento de um bom anúncio, ele é camuflado ou então ele é explícito.
Terceiro elemento de um bom anúncio. Um bom anúncio ele é um filtro e
não um imã. Um bom anúncio não é feito para falar com todas as pessoas,
ele segmenta. No passado eu dei uma aula que se chamava Como fazer
anúncios impossíveis de serem ignorados. Eu me arrependo de ter colocado
esse título nessa aula, porque eu acho que todo o anúncio foi feito para
ser ignorado pelas pessoas erradas. As pessoas com quem eu quero falar,
elas têm que parar para prestar atenção no anúncio. E a gente como
anunciante tem que entender o seguinte, que cada vez o que diz mais se o
meu anúncio vai ter sucesso ou vai ter fracasso é a minha habilidade de
no roteiro do meu anúncio, naquilo que tá sendo falado no meu vídeo,
naquilo que tá escrito no meu anúncio, ou seja, é a minha habilidade de
copywritter, de falar com o público, correto, porque a meta, o Google,
eles interpretam o meu anúncio e eles entendem para quem que eu tenho
que enviar esse anúncio. Então, eu não preciso ir lá necessariamente. Eu
posso fazer isso, mas eu não preciso necessariamente ir lá na meta e
colocar: "Esse anúncio é pra manicure". Esse anúncio é para mulheres que
tm interesse em ficar com a unha bonita. Por que que eu não preciso
fazer isso? Porque a ferramenta é inteligente. Se eu entro aqui no meu
Instagram, venho aqui, deixa eu dar um refresh aqui, pô. Não vai
atualizar, na moralzinha. Se eu venho aqui no meu Instagram e eu venho
na minha aba explorar, eu não falei pro meu Instagram que eu quero ver
conteúdos sobre o que tá aparecendo aqui para mim. Eu não fui lá e falei
assim: "Ah, eu quero ver conteúdo sobre relógio Instagram". Eu não fui
lá pro meu Instagram e falei para ele: "Instagram, eu quero ver conteúdo
sobre sobre treino, sobre academia, sobre ficar plantar bananeira". Eu
não falei isso pro meu Instagram. Eu estou consumindo conteúdo sobre
esses assuntos e o meu Instagram entendeu que eu quero consumir conteúdo
sobre aquilo e ele me direciona mais. Os anúncios funcionam igual.
Aquilo que você consome é aquilo que vai aparecer de anúncio para você.
O fato de você tá aqui me assistindo, me prova de que tem anúncio meu
aparecendo para você. Você quer saber de tráfego pago. Agora o anúncio,
você tem que dar no seu anúncio intencionalmente o sinal de para quem
que esse anúncio vai aparecer. Faz sentido isso para você? Por favor,
diz que faz. Diz que você tá entendendo, que o seu anúncio manda em para
quem que ele vai aparecer e para quem que ele não vai aparecer. Diz para
mim que faz sentido. Se não fizer, por favor, fala no chat que eu vou
explicar isso de 60 maneiras diferentes até isso daqui entrar na sua
cabeça, porque isso é uma é a coisa mais importante do tráfego pago em
2026. Faz sentido. Faz sentido. Faz sentido. Beleza. Como que nós vamos
fazer isso? Isso aqui não é aleatório. Tem método para tudo. Tudo que é
tudo que é o assunto tráfego pago, você pode falar assim: "Sobral, não
entendo isso. Eu crio um método e te explico. Vamos lá. Como que eu faço
pro meu anúncio conversar com um público específico? Alguém tem alguma
ideia? Fala no chat. V, vamos, vamos ver o que vocês têm de ideia sobre
o assunto. Carnaval, povo, vai se medo de ser feliz. Não tem ninguém te
julgando nesse chat além de você. Você é a única pessoa se julgando.
Como que eu faço isso? A cópia do criativo. Tá, mas como que eu altero
essa cópia do criativo? Repetir, por favor. Não, não, entendeu? Todo
mundo entendeu. Volta um pouquinho o vídeo e assiste de novo aquela
parte ali. Falar diretamente com eles, tá? Ó, para quem não entendeu, eu
vou abrir o parênteses a última vez. Presta atenção. É o seguinte,
porque eu sei que você tava fazendo outra coisa. Não tem como você não
ter entendido e você tava prestando atenção, mas eu, como seu professor,
eu dou essa colherzinha de chá para você e te explico mais uma vez. O
que diz para quem o seu anúncio vai aparecer é o que você fala ou o que
você escreve no seu anúncio. Então, se no meu anúncio, e aí eu vou usar
um exemplo, eu falo o seguinte: você que é dono de um restaurante
delivery em Curitiba e que fatura mais de R$ 50.000 R$ 1.000 por mês e
não tá alcançando as suas metas de vendas. Se eu falo isso no meu
anúncio, a meta, o Google, as ferramentas de anúncios online, elas
interpretam isso que foi falado e elas falam assim: "Beleza, eu sei para
quem que eu tenho que direcionar esse anúncio aqui. Eu vou direcionar
esse anúncio para quem? Para caminhoneiros que moram no Acre. Não, eu
vou direcionar esse anúncio para donos de restaurante delivery que moram
em Curitiba. Ah, mas pode ser que a meta não mostre só para essas
pessoas. Sim, ela não vai mostrar só para essas pessoas, ela vai testar.
Mas aquilo que é falado no meu anúncio diz para quem que meu anúncio vai
aparecer. Beleza? Funciona no orgânico? Claro que funciona. O orgânico
funciona assim. Aquilo que é falado filtra para quem que vai aparecer,
tá? Agora existem maneiras e maneiras de eu fazer isso. A primeira
maneira e a mais óbvia de todas e a que normalmente funciona menos e que
todo mundo faz é o e eu chamo isso aqui de fator de segmentação, tá? A
primeira maneira é a segmentação direta, que é o quê? Se você tem um
delivery de Curitiba e faz mais de 200 pedidos por mês, tô fazendo uma
segmentação direta. o início do meu anúncio já, pá, já conversa
diretamente com a pessoa. Mas existem outras maneiras de fazer isso. Eu
posso fazer, por exemplo, uma segmentação por conhecimento. Eu posso
falar o seguinte no anúncio, taxa de recompra abaixo de 30% é o buraco
invisível do seu delivery. O dono do delivery, ele sabe o que que é taxa
de recompra. Se eu quiser fazer um anúncio que fale com o gestor de
tráfego, eu poderia falar o seguinte, o gestor de tráfego um pouquinho
mais avançado. O seu cliente te dá churnta de habilidade operacional,
mas é por causa da sua falta de habilidade de atendimento. Agora, eu
acabei de falar, o seu cliente te dá ch. Tem um monte de gente aqui no
chat que não sabe o que que é turne. Esse anúncio não era para você.
Esse anúncio é para alguém, um gestor de tráfego, que sabe o que que é
chy. Cherne é a métrica de quando o cliente quebra o contrato com você,
ele te demite. Eu tomei um ch. Ou poderia falar no anúncio, semana
passada eu tomei um churne por um erro que 70% dos gestores de tráfego
cometem, mas que com esse vídeo você vai aprender como não cometer mais.
Ponto. Todo mundo quer saber sobre o que eu tô falando. Todo mundo que
sabe o que que é ch. Então eu segmentei por conhecimento. Eu não tive
que falar: "Ah, esse anúncio aqui é para gestores de tráfego pago que já
tentes e não querem perder os seus clientes". Não, eu fui menos óbvio,
eu fui numa camada mais profunda. Ah, mas a meta vai conseguir entender
isso? Vai. Por quê? Porque as pessoas que vão reagir à aquele anúncio
vão dar sinais paraa meta, pro Google de para quem que ela tem que
enviar mais aquele anúncio. Faz sentido? Faz sentido o que eu tô te
dizendo? Fala comigo nesse chat, por favor. Eu preciso do seu da da eu
preciso da do do do da sua conversa aqui hoje. Tá beleza? Só que essa
não é a única maneira. a gente pode fazer de forma direta e ela não é
ruim, tá? Ela não é ruim, mas eu também posso fazer por eh ferramenta ou
plataforma. Então eu peguei todos os exemplos aqui para donos de
delivery, tá? Então, se você ainda não gerencia o pedido, se você ainda
gerencia o pedido pelo WhatsApp e anota em caderninho, você tá deixando
dinheiro na mesa todo dia. WhatsApp e caderninho são as ferramentas que
um dono de um delivery mais amador vão utilizar para gerenciar pedido.
Eu não tô falando que é com dono de delivery aqui. Eu não falei você que
é dono de delivery e faz mais de 200 pedidos por mês, não. Qual que é a
ferramenta, que plataforma que aquela pessoa utiliza? Se eu for falar
com manicure, sei lá, eu posso falar da marca do esmalte. Se você ainda
compra o esmalte Blebly Blovsks, você tá perd, você tá, sei lá, aí eu
não sei, tem que pensar, mas perdendo dinheiro não. Mas você tá deixando
a sua unha vez mais fraca. Eu tô falando com a mulher, eu não tô falando
a você que é mulher e que cuida das suas unhas, não. Eu tô falando você
que é mulher e que usa o esmalte e tal, você que é mulher e usa o blé
blá, alguma coisa, alguma ferramenta, alguma coisa que só aquela pessoa
sabe que é. Eu tô segmentando pelo anúncio. Posso fazer essa segmentação
também por situação. Se que situações que aquela pessoa passa
sexta-feira, 19 hor da noite, chovendo em Curitiba, pedido explodindo e
o motoboy te liga dizendo que não vai. Isso é o quê? Uma situação que
essa pessoa passa. Se eu pegar lá no meu GPT, eu posso encontrar aqui
situações que essa pessoa passa. Então, ó, já fui no manicure que
atrasava 40 minutos, paguei caro e não durou 3 dias. Você paga caro, vai
até o salão, faz a unha, fica com a cutícula toda ferrada. Três dias
depois sua unha tá descascando. Situação, não tô falando você que é
mulher, mora em Curitiba e quer fazer a unha, não. Situação, o que que
essa pessoa passa? Segmentação por comportamento. Que que aquela pessoa
faz no dia a dia? Você coloca cupom de 20% para tentar aparecer mais no
iFood, no final do mês não sobra nada. Não tô falando com dono de
delivery, mas só dono de delivery vai olhar para isso daqui. Outra que
eu poderia fazer, eu poderia falar assim: "É, você todo mês você muda o
cardápio achando que o problema é o produto, mas o problema não é o
produto. O problema é a sua estratégia de marketing digital. Ponto.
Falei com o cara que muda o cardápio todo mês. Quem é que muda cardápio
todo mês? Quem é dono de restaurante? Posso fazer uma segmentação por
crença. O cara acha, por exemplo, que é o iFood que traz o cliente pro
delivery dele. Aí eu posso falar, não é o iFood que traz o cliente pro
seu delivery, é o seu delivery que sustenta o iFood. Então a pessoa tem
uma crença, o dono do restaurante que o iFood traz o cliente para mim.
Não, não é. É você que traz o cliente pro pro iFood, é você que tá
sustentando o iFood. Eu posso fazer outra. Quem depende 100% do iFood de
marketplacer, não tem um negócio, tem um emprego disfarçado. Crença, tô
falando com crença. Posso fazer uma segmentação por rotina. Então, como
que é o dia a dia daquela pessoa? Acorda, confere o estoque, prepara a
cozinha, abre o aplicativo, reza para não chover ou sei lá, para não
chover. Para chover, porque as pessoas pedem mais comida. Reza para
chover e essa é sua rotina. Se essa é sua rotina, a gente precisa
conversar. Então, o que que aquela pessoa passa no dia a dia? Sabe
aquela reclamação clássica do do de dono de negócio? Putz, eu não tô
trazendo as pessoas qualificadas. Na maioria das vezes, isso não é culpa
do gestor de tráfego pago, mas sempre que aquilo ali é culpa do gestor
de tráfego pago, é porque o gestor de tráfego pago não tá conseguindo
incluir no seu anúncio o fator de segmentação. Eu não tô conseguindo
colocar no meu anúncio algo que filtre somente as pessoas certas e fazer
com que a meta com que o Google leve os meus anúncios para as pessoas
certas. Ah, Pedro, então se meu anúncio ele é filtro, ele não é íã, isso
quer dizer que eu tenho sempre que eu eu não tenho que me preocupar em
atrair o máximo de pessoas possível, não. Você tem que se preocupar em
atrair as pessoas. E aí é para isso que existe o que eu chamo de
estrutura GCC, tá? Que é a estrutura que eu sempre uso para fazer os
meus anúncios. Existem várias dessas estruturas na internet, tá? Tem
gente que vai falar do modelo Aida. Tem gente que vai falar de você
fazer eh promessa, mecanismo único, blé bleu e CTA. Tudo funciona. Não
vou dizer que as outras não funcionam, tudo funciona. Eu só acho que a
que eu ensino aqui é um pouco mais simples, tá? Que que é o GCC? GCC é
gancho, corpo, call to action. Gancho. Primeiros 3 segundos do anúncio.
É o que para o dedão da pessoa quando ela tá lá escrolando a tela.
Corpo. Corpo divulgando. É o que, o quando, o onde, o para quem, é o que
tá sendo divulgado. E o CTA é para onde a pessoa vai, é a chamada para
ação. É quando eu olho para você e digo assim: "Pô, e agora eu tô
falando com você aqui real. Se depois de tudo isso daqui que eu já te
entreguei de graça, você não vai curtir esse vídeo, não vai se inscrever
no canal, eu não sei mais o que que vai fazer com que você curta o
vídeo, se inscreva no canal. Se a partir de agora, toda terça-feira,
você não vai ter um despertador no seu celular para estar aqui ao vivo
comigo, eu não sei mais o que vai fazer você estar aqui toda terça-feira
com despertador ao vivo comigo. Tu tá doido, não tem como. Aí me deu uma
vontade de espirrar. [risadas] É real, pô. Cadê o seu despertador? Toda
terça 3 da tarde a gente tem um compromisso, tá, Pedro? Mas como que eu
faço essa estrutura GCC na prática? Vamos lá. Primeiro, gancho. Existem
três tipos de gancho. Existe o gancho falado, existe o gancho escrito e
existe o gancho visual. São três tipos de gancho. Vou te dar um exemplo.
Vou pegar um conteúdo aqui do meu perfil do Instagram. Deixa eu pegar um
que é bem aqui, ó. Ganjo falado. As primeiras palavras que eu falei
nesse vídeo. Deixa eu desmutar e atualizar. Ah, ele, o meu Instagram ele
tá traduzindo para outro idioma porque ele tá em inglês, tá? Mas eu
começo o vídeo falando assim: "Vidoca, você sempre esteve comigo nos
momentos fáceis e nos momentos difíceis". Isso daqui é um gancho porque
eu tô a pessoa, o que mais chama atenção nesse anúncio não é o gancho
falado, mas é o gancho visual, porque eu tô de terno, eu tô claramente
num casamento e eu tenho o meu gancho escrito aqui em cima que é o
casamento ia ficar muito caro, então tive que colocar anúncios nos meus
votos. Vou te explicar para que que serve cada uma das coisas. O gancho
falado, ele tem que criar na sensação de que o anúncio tá falando com a
pessoa e ou tá, ele faz isso ao mesmo tempo que ou ele faz isso, ele
para o scroll. Que que é o scroll? É o dedão da pessoa, tá? Ele vai
criar a sensação de que o anúncio tá falando com a pessoa ou ele vai
gerar na pessoa contraste, dúvida. curiosidade ou surpresa. Às vezes só
o gancho falado não vai fazer isso sozinho. Por isso que a gente também
tem aqui o gancho escrito. Para que que serve o gancho escrito? O gancho
escrito ele não é para Tem muita gente que escreve no gancho escrito.
Esse é o maior erro que eu acho que as pessoas cometem. Elas escrevem no
gancho escrito a mesma coisa que tá no gancho falado. Isso é cagada. o
seu gancho escrito, ele vai servir para fazer um looping ou fazer um ou
dar um spoiler do que que vai ser dito. Então você quer saber como é que
aquele gancho se desenrola no vídeo. Então, por exemplo, esse vídeo que
eu te mostrei aqui, eu eu boto um spoiler. O casamento ia ficar caro,
então eu tive que colocar anúncios nos meus votos. Pô, fiquei curioso.
Eu quero saber como é que são os anúncios nos votos. Esse é o spoiler.
Você sabe o que vai acontecer? Já tem anúncios nos votos. Como que isso
vai ser entregue para você? É por isso que você fica com vontade de ver
o vídeo. E o gancho visual, ele chama a sua atenção, não só através do
que é falado e tá sendo escrito, mas do que tá acontecendo, tá? Então,
do que que tá acontecendo ali. Nem sempre você vai usar o gancho visual.
Por exemplo, naquele anúncio lá que a gente pegou do ladeira, que eu
mostrei para você aqui, ele não tem um gancho visual, ele é um talking
head, é uma pessoa falando com a câmera. Eu gravo muitos anúncios que
não tem um gancho visual. Isso quer dizer que você sempre tem que fazer
dessa maneira? Não. Mas não tem certo, não tem errado. Tem um anúncio
que funciona, tem um anúncio que não funciona. Mas algumas vezes você
vai precisar do gancho visual para te ajudar no seu anúncio, tá? Tá?
Então, a gente tem esses três tipos de gancho que eu vou colocar no meu
anúncio. E aí, detalhe, nunca subestima o gancho escrito, tá? Nunca
subestima. 44% dos usuários do Instagram assistem o Instagram sem som.
44%. Então, se eu não tenho nada que gera curiosidade pra pessoa ligar o
som no seu no celular, ela meu anúncio vai passar muitas vezes batido.
Agora, existem algumas maneiras da gente fazer esse gancho falado, tá?
Eu ensino no meu curso várias maneiras, mas aqui eu vou te trazer as
quatro mais simples, que é através de uma pergunta, através de uma
sacada contrainttuitiva, de uma história ou de um anúncio segmentado.
Pergunta. Eu vou fazer uma pergunta que se conecta com algo que aquela
pessoa já passou, com alguma dor, com algum desejo, com alguma situação
que aquela pessoa já passou na vida. Sacada contrainttuitiva. Eu vou ir
contra uma crença comum. ou a favor contra uma crença comum, tá? Então,
se a pessoa acha que a melhor maneira de fazer unha é indo na manicura,
eu vou dizer para ela que não é. Se a pessoa acha que a melhor maneira
de ter a unha feita por mais tempo é usar unha de gel, eu vou dizer que
não é. Se a pessoa acha que você não deve usar esmalte barato porque vai
machar sua unha, eu vou dizer pra pessoa que ela tem que usar esmalte
barato. Então eu vou sempre ir contra algo que a pessoa acredita.
história. O, no próprio nome já diz, eu vou contar uma história onde
aquela pessoa se identifica. Então, eu quero, eu vou falar da vida da
pessoa, mas falando de outra situação. Então, eu vou fazer a pessoa se
ver naquela situação, mas eu não vou est falando dela. Sabe? Você já viu
uma uma parada na internet que as pessoas falam assim: "Nenhuma
experiência é realmente individual". Sabe quando alguém te conta alguma
coisa assim, tipo, ah, alguém te conta, ah, uma curiosidade sobre mim,
eu faço isso. Aí você fala assim, cara, eu também faço isso? Tipo, outro
dia eu postei no meu no meus no meu close friends um meme que era assim,
eu discutindo com uma pessoa e pensando, discussão encerrada, não vou
mais falar sobre esse assunto. 5 minutos depois eu me lembro de mais
alguma coisa que eu tenho que falar para aquela pessoa. Eu volto e falar
assim, ó, mais o seguinte aqui que eu tenho que te dizer, tipo assim,
você acabou a discussão, mas aí você lembrou de alguma coisa ou tipo, se
eu falar para você que, sei lá, você fica ensaiando no chuveiro uma
resposta que você deveria ter dado para uma pessoa numa discussão.
Nenhuma experiência individual. Todo mundo passa pelas mesmas coisas.
Todo mundo que tá prendendo tráfego pago passa pelas mesmas coisas. Todo
mundo que teve algum problema na manicure passa pelas mesmas coisas. É
sobre você contar essas histórias. E o segmentado é sobre você fazer
anúncios para públicos específicos, tá? Eu poderia, e eu detesto falar
isso nas aulas porque parece que eu deveria entregar esse conteúdo nessa
aula, mas eu realmente poderia fazer uma aula só sobre ganchos. Posso
marcar da gente fazer uma aula só sobre ganchos, tá? Posso marcar
inclusive. Mas para facilitar sua vida aqui, eu tenho um agente de chat
EPT que ele cria os anúncios para você, tá? E ele é muito bom, tá? Então
eu vou apertar aqui em começar, ele vai me vai me pedir umas perguntas.
Então, o que que eu tô anunciando? Ah, tô anunciando o serviço de uma
manicure, para onde que a pessoa vai depois de clicar no anúncio para o
meu WhatsApp, qual ação que você deseja que a pessoa faça no destino
final, agende um horário e o detalhamento de persona. Então, eu vou
pegar esse essa descrição aqui da Juliana Ferreira, que é a nossa
persona, e vou enviar isso daqui lá pro GPT. no outro agente, tá? Mando
aqui para ele e aí ele vai montar os anúncios para mim dentro do GCC que
eu te falei aqui, tá? Então, quantas vezes você já fez a unha e em menos
de três dias ela tava descascando? Se você com a maioria das mulheres
que trabalham fora, tem rotina, reunião, evento, compromisso e se quer
se sentir mais feminina, arrumada, impecável, você sabe o quão
frustrante é pagar por um serviço e ver o esmalte sair antes do final de
semana. E o pior, sair do salão com a cutícula ardendo, torcendo para
não inflamar depois. A verdade é que não é só unha, é autoestima, é
segurança para tirar foto, é confiança para apertar a mão de alguém, é
tá pronta para qualquer ocasião. Eu sou manicure especializada em
atendimento cuidadoso higiênico pontual. Trabalho com esterilização
adequada dos materiais, organização de agenda e técn técnicas que
aumentam a durabilidade do esmalte para até 15 dias. Aqui você não perde
o sábado inteiro, você não sai sangrando, você não fica refém do atraso,
você tem um horário respeitado, um ambiente limpo, um atendimento que
prioriza a qualidade no volume. Se você quer parar de testar manicure
nova todo mês e finalmente tem uma profissional fixa e confiável, clica
no botão de saba mais e me chama no WhatsApp para agendar o horário.
Anúncio dois, gancho de história. Uma cliente minha chegou aqui depois
de sair chorando de um salão, porque machucaram tanto a cutícula dela
que ela não conseguia nem lavar o cabelo direito. Não sei se é uma
situação que as pessoas passam, mas se for vai gerar identificação. Eu
poderia pedir pr para ele gerar outras histórias. Ó, o anúncio de
história ficou uma merda, ficou ruim. Cria três variações dele. Aí eu
vou pedir para ele criar três variações do anúncio de história aqui. Eh,
mais forte, emocional, identificável. Ela tinha um casamento no sábado,
fez a unha na quinta, na sexta o esmalte começou a descascar. Ela me
mandou mensagem desesperada. Tinha comprado vestido novo, marcado o
cabelo, mas a unha tava feia. Sabe o que que ela me disse? Eu me sinto
deslechada quando a unha tá assim. Não é sobre esmalte, é sobre se
sentir pronto. Aí ele tá dando uma repetida. Eu posso dizer: "Pô, você
tá sempre repetindo esses pontos aqui". Mas enfim, excelente cópia,
baita anúncio. Melhor do que 99% das manicure vai rolar de anúncio por
aí na internet. Se eu pegar a biblioteca de anúncio e colocar aqui
manicure, você pode ter certeza que eu não vou encontrar anúncios tão
bons quanto esses daqui que eu tô te mostrando. Ó, eu vou comentários
dos preconceitos que as pessoas têm quando o assunto é fazer unha.
futilidade, vaidade vazia, luxo idiota jogar dinheiro fora, eh, alta
manutenção. Se sua unha tá feita, você não trabalha de verdade. Acrílico
e ao longo é nojento, brega brega, é antiigiênico. Eh, mulher, pressão,
sexismo, homem com a unha feita, questionamento de masculinidade, salão
de unha, sei lá, vai ter de tudo aqui. Você vai ter que filtrar o que
que faz sentido, o que que não faz sentido, tá? Mas moral da história,
por que que eu fiz isso daqui? Não me lembro, tá? Moral da história, com
esse agente você consegue gerar bons anúncios para você, tá?
Principalmente essa parte do gancho, que são os três primeiros segundos,
onde que você vai encontrar bons ganchos também? Aí eu volto lá naquela
primeira explicação que eu te dei. Você vai encontrar bons ganchos nos
anúncios alheios, tá? Então, lá na biblioteca de anúncio, digitei aqui,
ah, manicura, era isso que eu tava fazendo. Olha, aqui na biblioteca de
anúncio, eu vou encontrar bons ganchos. Como? Seguindo aquele método que
eu te falei, fazendo o filtro correto, olhando para pessoas que têm bons
anúncios. E o outro lugar principal onde eu vou encontrar bons ganchos é
indo lá no meu Instagram e fazendo a pesquisa. Deixa eu compartilhar a
tela aqui grande de novo, desculpa. é indo lá no meu Instagram e meu
Deus e fazendo a pesquisa aqui dos conteúdos. O que tem aqui são bons
ganchos. Nenhum vídeo viraliza, nenhum vídeo fica com muita visualização
se ele não tem um bom gancho. Às vezes esse gancho vai ser escrito, às
vezes esse gancho vai ser visual, às vezes esse gancho vai ser falado.
Eu posso utilizar esse tipo de anúncio ao meu favor para que eu consiga
ter eh para esse o conteúdo já feito ao meu favor, para que eu pegue
aquele gancho e utilize para mim. Ah, mas não é uma cópia. Não, não tô
copiando. Eu tô pegando uma uma estrutura, um gancho que funcionou. E aí
eu tô adaptando para mim, pro meu negócio, para aquilo que eu tô
divulgando, tá? E aí depois dessa parte, isso aqui não tem muito que
explicar, a gente tem o corpo, que é o que que eu tô divulgando, e o
call to action, que é para onde que eu tô levando a pessoa depois que
ela vai no meu anúncio, que são elementos que sempre vão estar presentes
no meu anúncio. E o quinto elemento, lembrando, primeiro elemento de um
bom anúncio, ele é baseado em referências. Segundo elemento, ele é
camuflado ou explícito. E eu vou utilizar os dois na minha estratégia.
Terceiro elemento, um bom anúncio, ele segmenta. Quarto elemento, ele
segue a estrutura GCC, sempre tendo um gancho falado, escrito visual, um
corpo que eu digo o que que eu tô divulgando, para onde que a pessoa
vai, para quem que é aquele anúncio e o CTA, que é o final das contas,
para onde que a pessoa vai depois que ela clica no meu anúncio. E o
quinto elemento é a quantidade e qualidade, tá? Tá? Então, eu não posso
fazer poucos anúncios. Eu não tenho que apostar em um único simples
anúncio. Eu tenho que apostar em quantidade e qualidade de anúncios.
Então, eu tenho que produzir e tenho que produzir muitos, tá? Segundo as
ferramentas, o que que é um anúncio ruim? Isso é uma coisa boa de você
entender. Segundo meta, segundo o Google, um anúncio ruim é quando
alguém oculta o seu anúncio, quando alguém oculta todos os anúncios do
anunciante, se a pessoa oculta o anúncio devido à repetição, se ela
denuncia o anúncio, se ela desiste depois que ela clica no seu anúncio,
ou seja, ela clica no seu anúncio, vai até a sua página e desiste de
permanecer na sua página, ou se ela vai até sua página e fica muito
pouco tempo lá. Todos esses são sinais que a ferramenta que que os
usuários dão paraa ferramenta para dizer se um anúncio ele é bom ou se
um anúncio não é bom. Povo, é o seguinte, eu tô aqui 1 hora 40, eu
planejei mal essa aula. Eu pensei que ia dar tempo de falar para você
sobre páginas e fazer boas promessas. Que que eu vou fazer, tá? Que que
eu vou fazer? Eu vou deixar como continuação na semana que vem outra
aula sobre copywriting para gestores de tráfego, tá? Então vai ser
copywriting para gestores de tráfego, parte dois, como fazer boas
páginas. Nessa aula, eu também vou te entregar alguma alguma coisa de
inteligência artificial para que você domine a criação de páginas na
internet. vai ser uma continuação desse conteúdo. Posso contar com você
de que você estará aqui na semana que vem pra gente seguir esse conteúdo
de copywriting para gestor de tráfego. Normalmente eu não faço isso, tá?
Eu não dou, não faço conteúdos que t continuidade. Posso contar com você
porque aí senão eu vou exagerar na mão na quantidade de conteúdo e você
vai parar de absorver. Eu já sei que você tá bugando a cabeça aqui de
tanta coisa que eu tô te entregando, tá? Então, a gente volta na semana
que vem com esta aula, tá? Eh, para a gente encerrar aqui, tenho que
passar para você a palavra-chave dessa aula. Pedro, o que que é a
palavra-chave da aula? É o seguinte, você está agora, ai, agora que eu
vi que eu tô com umas uma barrinha preta e em cima do meu vídeo aqui,
né? Vou ajustar antes tarde do que nunca. Calma. Ai, me perdi. Não vou
conseguir ajustar. Ai, meu Deus, que caos. Não vou conseguir ajustar.
Vou voltar para onde eu tava. Vou ficar aqui. Vou ficar quieto depois.
Ah, não. Eu vou, se eu aumentar aqui, ele vai. Toma, toma. Deu agora
sim. Desculpa, fiquei com toque. Tá seguinte, você está agora nesta live
aqui, tá? Isso aqui é a minha live de hoje, onde a gente tá agora. Na
descrição deste vídeo temos alguns links, tá? Tem o link para você
entrar na lista de espera da nossa comunidade de tráfego, tá? Comunidade
subido de tráfego pago, onde você tem todos os nossos cursos. E temos
aqui o link da nossa lista de espera da live, tá? Lista de espera da
live. Você vai clicar aqui na lista de espera da live, vai abrir este
site na clicar aqui na lista de espera da live. Nosso áudio de hoje tá
bem zoado da live, né? Foi cagada minha que eu não instalei meu
microfone aqui ainda. Tá, mas aqui você vai colocar seu nome, vai
colocar um e-mail, seu WhatsApp e você vai escolher a palavra-chave da
aula que é manicure, tá? Porque a gente usou manicure, de exemplo a aula
inteira. E aí você vai confirmar sua presença. Por que que você deveria
fazer isso? Porque uma vez a cada mês mais ou menos a gente faz um
sorteio aqui. E quanto mais aulas você tem de comparecimento, aí eu tô
compartilhando a eu pensei que eu tava compartilhando a tela errada. Tô
compartilhando a tela certa, tá? Quanto mais lives você comparece,
melhores são os prêmios que você ganha se você for sorteado. Tá bom, meu
povo? Foi um grande prazer estar aqui com você. Espero que você tenha
gostado do conteúdo. Vou colocar na descrição desse vídeo as
inteligências artificiais e o link da extensão do Google Chrome para
você baixar os vídeos na biblioteca de anúncios. Fechou? Tamos junto. E
a gente se vê então na próxima terça-feira, 3 horas da tarde, na nossa
próxima aula ao vivo. Valeu, fui. Amanhã não, próxima terça, a parte
dois. Foi

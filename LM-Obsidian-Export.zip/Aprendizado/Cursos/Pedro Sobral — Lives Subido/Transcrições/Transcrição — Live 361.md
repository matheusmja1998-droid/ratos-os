---
tipo: transcrição
live: 361
tema: Andromeda, Pmax e Advantage+ — Como usar a IA das fontes de tráfego em 2026
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #361

> Andromeda, Pmax e Advantage+ — Como usar a IA das fontes de tráfego em 2026

Resumo e aplicação: [[Live 361 — Andromeda, Pmax e Advantage+ — IA das fontes de tráfego]]

---

Bem-vindo, bem-vinda, bem-vinda à nossa live número 362. Andrômeda,
Advent Plus, Pmax. Como que você vai utilizar a inteligência artificial
das ferramentas? Vai automatizar suas campanhas para que você tenha
menos trabalho e mais resultado em 2026. E sim, nós estamos a 362
terças-feiras. toda terça-feira às 3 horas da tarde fazendo aulas ao
vivo sobre tráfego pago e anúncios online. Pedro, mas eu entrei lá no
seu canal do YouTube e eu não encontrei lá 362 lives. Onde é que estão
essas lives então que você tá falando aí? Olha, se você entrar aqui no
meu canal do YouTube, na aba ao vivo, você vai encontrar aqui mais ou
menos 20 horas de conteúdo. Eu chamo esses conteúdos aqui de conteúdos
base. Eles são os conteúdos que você precisa para começar a atuar no
tráfego pago. Seja como um gestor de tráfego pago que vai cuidar dos
anúncios online de outras empresas, seja como alguém que vai cuidar dos
seus próprios anúncios da sua própria empresa. Independente da sua
situação, esse canal aqui ele serve para você. Independente do seu
nível, esse canal aqui ele serve para você, tá, Pedro? Mas e as outras
lives? Eu falo aqui que a gente segue um modelo de conteúdo que eu chamo
de conteúdo perecível. Que que é o conteúdo perecível? É o seguinte,
toda terça-feira, 3 horas da tarde, a gente tem uma live. Terça-feira da
semana seguinte eu tiro esta aula do ar e eu coloco, faço, né, mais uma
live às 3 horas da tarde. Isso em 99,9% das terças-feiras. Pedro, como
assim 99,9%? Acontece que em algumas terças-feiras, por acaso, pelo
acaso do destino da agenda, eu não posso estar ao vivo às 3 horas da
tarde. Quando isso acontece, o que que eu faço? Eu faço o que eu estou
fazendo agora aqui com você, que eu pareço que eu tô ao vivo, mas eu não
estou ao vivo, tá? Isso daqui é uma gravação e eu fiz essa gravação na
segunda-feira de manhã. O meu compromisso com você é sempre fazer a
gravação o mais perto possível do horário da live. Então, tô fazendo a
gravação aqui, ó. São 9:57 agora. Eu tenho que sair de casa às 11 horas
da manhã para pegar o meu voo. Então, tô com tudo pronto para gravar
esse conteúdo aqui para você. Vai ser uma hora de conteúdo e você vai
ver que de maneira rápida e simples eu vou te explicar tudo sobre
Andrômeda, PMX, Advent Plus para que você domine melhor estes conceitos,
tá? Então, vamos começar já. Já vou botar o elefante branco na sala, né?
Vamos falar dessa ferramenta que é a Andrômeda. Para você que tá
começando aí no universo do Tráfego Pago, você tem que entender o
seguinte. Existem basicamente duas grandes plataformas onde a gente
gerencia os anúncios online. Uma delas aqui é o Metaads, que é a
plataforma de anúncios da Meta. Outra plataforma é o Google Ads, que é a
plataforma de anúncios do Google. Nós gestores de tráfego pago, pessoas
que anunciamos na internet, nós utilizamos essas ferramentas para que a
gente faça o anúncio aparecer na frente de alguém. Sempre que um anúncio
apareceu na sua frente, é porque alguém utilizou essas ferramentas aqui.
Ai, Pedro, essa explicação ela tá muito básica. Sim, você que já é mais
avançado, você tem que observar como que eu explico, porque parte do seu
trabalho como gestor de tráfego é também explicar isso daqui para os
seus clientes, paraa pessoa que não sabe o que que é o tráfego pago, não
sabe como que ela funciona. Então, presta atenção nessas explicação
explicações e vai aos poucos roubando como um artista essas explicações
para você, tá? Então, nós temos essas duas grandes plataformas. Que que
acontece? o nosso trabalho nessas plataformas. E é importante que você
que quer entender a Andrômeda, o Advantage Plus, o Pmax a fundo, entenda
isso. O nosso trabalho nessa plataforma é dar informações para essa
plataforma. Então, é como se a plataforma me fizesse várias perguntas.
Por exemplo, quando eu vou criar a minha campanha, a plataforma ela vai
me fazer a primeira pergunta que normalmente a gente ignora, que é o
tipo de compra, leilão ou reserva. Em 99,99% dos casos, a gente vai usar
leilão, tá? A gente só vai usar reserva. O que que é reserva? Reserva. E
aí que vem uma explicação para um pouco mais avançada. Acho que eu acho
que eu não tenho uma aula minha que eu expliquei isso daqui, mas reserva
é quando eu estou comprando o tráfego do futuro hoje, Pedro, não
entendi. Imagina o seguinte, tem uma métrica que se chama CPM. CPM.
Pensa que anunciar na internet é como se fosse comprar uma ação na bolsa
de valores. Essa ação na bolsa de valores tem um valor X hoje. Esse
valor é medido pelo CPM. É o custo por 1000 impressões, o custo para
você aparecer. Quando eu seleciono reserva, o que que eu tô dizendo?
Olha a meta, eu quero o custo de hoje da plataforma, só que eu vou
anunciar só daqui a 2 meses. Então, daqui a 2 meses, se o custo tiver
mais caro, não tô nem aí. Por quê? porque eu já reservei no passado. Só
que quando eu uso reserva, eu só posso anunciar com com reconhecimento e
engajamento. São meus únicos objetivos, tá? Quando que isso aqui
funciona legal? Por exemplo, na Black Friday. Então, se eu sei que a
Black Friday vai chegar, que eu vou ter um novembro em que o custo é
muito mais caro, em outubro eu já posso criar algumas campanhas de
reserva. Isso se eu for utilizar uma estratégia em que eu tenho muitas
campanhas de reconhecimento e engajamento, tá? Mas enfim, voltando aqui
à explicação do modo simples para todo mundo que tá começando e para
quem já é mais avançado também, a gente tem a ferramenta nos pedindo
informações. Isso sempre vai acontecer, independente da inteligência
artificial ou não, então, e do desenvolvimento das plataformas. Então, a
ferramenta, ela tá me perguntando: Escolha o tipo de compra, escolha um
objetivo. Cada escolha é uma informação que eu tô dando pra campanha.
Conforme eu vou entregando essas informações para as campanhas, a
ferramenta ela vai meio que pensa que é um robozinho que ele tá ficando
inteligente, ele tá entendendo aquilo que eu quero e ele vai buscar me
entregar isso. Então, se eu selecionei aqui como, por exemplo, o
objetivo de engajamento, ele já vai me mostrar o meu anúncio para
pessoas que tm o maior potencial de engajar. Aí eu já tenho uma outra
opção. Putz, eu posso selecionar uma campanha com configurações
recomendadas ou uma campanha de engajamento manual. Ah, vou começar pela
campanha de engajamento manual. Mais uma informação. Agora eu vou
colocar o nome da minha campanha. Eu vou selecionar se eu quero, vou
dizer se eu quero utilizar o orçamento Advent Plus ou se eu não quero.
Eu vou selecionar o orçamento diário ou o orçamento total. Se eu
selecionar o orçamento total, eu posso selecionar a programação do do de
conjunto de anúncios ou não? Tudo isso são informações que eu tô dando
pra plataforma, informações que eu estou dando pra ferramenta. Beleza?
Então, parte número um do trabalho do gestor de tráfego, da pessoa que
vai anunciar, é colocar essas informações, é criar a melhor campanha
possível. Detalhe, não existe campanha perfeita. campanha perfeita, ela
vai surgir conforme a gente botar a nossa campanha no ar, botar os
nossos anúncios no ar. A ferramenta vai nos dizer o que que tá
funcionando, o que que não tá funcionando naquela campanha e eu vou
fazendo os ajustes até essa campanha ficar, entre aspas, perfeita,
porque a gente vai buscar a perfeição da campanha na otimização, tá? E
não na criação, tá? Essa essa frase ficou boa, né? Nós vamos buscar a
perfeição da campanha na otimização e não na criação. Não existe criar
campanha perfeita, tá? Mas a gente tem boas práticas aqui para criar as
campanhas que você vai aprender inclusive nas outras aulas aqui do
canal. Então, voltando aqui, nós temos então e o processo de dar as
informações pra plataforma, dar as informações pra ferramenta. O que que
a ferramenta vai fazer? ela vai processar essas informações. O que que é
essa tal de Andrômeda, Pedro? Andrômeda é uma atualização da meta, tá?
Então você pode pesquisar, eu vou deixar na descrição aqui o link, tá?
Ele tá lá na parte de engenharia da meta. Mas eu quero que você perceba
o seguinte, olha só, detalhes importantes. Criou-se um caos no final de
2025,26 sobre essa tal dessa Andrômeda. Mas presta atenção no seguinte,
a matéria da Andrômeda, olha quando que ela foi publicada, olha o link.
Engineering.facebook.com 2024. Foi lá em 2024 que isso aqui foi
publicado, tá? E provavelmente eles estão usando aqui eh ano, dia e mês
e eu não tenho certeza, tá? Eu até posso ver se agora isso daqui era uma
informação que eu tinha que ter puxado antes. Será que tem aqui embaixo
a data da publicação? Não achei. Tá, mas enfim, moral da história, nós
temos aqui uma matéria que foi publicada em 2024, tá? Pode ter sido em
dezembro, pode ter sido em fevereiro, eu acredito que foi em dezembro,
na verdade, que gerou um alvoroço só agora, né, no final de 2025. Por
que que esse alvorooso todo aconteceu? Porque a plataforma ela, quando a
a time de engenheiros da meta cria uma feature, né, um recurso novo,
eles testam esse recurso durante vários meses e foi isso que eles
fizeram. A Andrômeda, ela já estava afetando as suas campanhas antes
mesmo desse frenesia acontecer. Outro dia um aluno me falou: "Ah, meus
resultados caíram por causa da Andrômeda". Eu falei: "Nas desde quando
seus resultados caíram?" "Não, foi bem no dia do lançamento." Eu falei:
"Em 2024". Aí ele falou: "Não, mas lançou agora". Eu falei: "Não,
negativo". Então, a gente não pode achar que ocorrência e causalidade
são a mesma coisa, porque algo ocorreu não quer dizer que é causal, não
quer dizer que é por causa da Andrômedra. Pode ter sido ocorrência.
Quando começou a saírem as notícias da Andrômedra, por acaso aconteceu
da sua campanha ter menos resultado? É a mesma coisa que eu olhar pra
rua e falar assim: "Putz, tá chovendo hoje, minha campanha caiu o
resultado." É, esse é o problema? Não, mas a Andrômeda, então, ela é
essa ferramenta de processamento. Então eu dou as informações pra
plataforma, a plataforma tem que processar essas informações. E o que
que a Andrômeda ela faz? A Andrômeda nada mais é do que uma nova
ferramenta de processamento embída cada vez mais com inteligência
artificial. Então é a meta dizendo o seguinte pra gente: "Olha, nós
estamos muito melhores e entender os seus anúncios. Nós estamos muito
melhores e entender aquilo que você anunciante quer." Aí você vai me
dizer assim: "Pô, Pedro, então Andrômeda é um negócio bom. É um negócio
bom. Não tem nada de ruim pra gente, Andrômeda. E se a gente pegar aqui
o texto, né, mais uma vez vou deixar na descrição. Eu não sei porque que
ele traduziu para português agora, mas se a gente pegar esse texto, ele
tem para mim aqui três parágrafos extremamente relevantes que a gente
precisa ler, tá? Vou tá em inglês aqui, mas eu faço a tradução para
você. A inteligência artificial tem um importante papel no sistema de
anúncios da meta ao alavancar o poder do machine learning, né, da do
aprendizado das máquinas para prever quais anúncios uma pessoa vai achar
mais interessante. Então, o que que a meta tá dizendo? A inteligência
artificial, ela já está na meta. Não é que a inteligência artificial vem
só para vem roubar o seu trabalho. Ela vai fazer o trabalho por mim.
Não, a inteligência artificial ela vem para deixar o seu trabalho
turbinado 2.0. A gente tá entrando na era dos anúncios 2.0, dos anúncios
turbinados por inteligência artificial. Então, mais uma vez, a
inteligência artificial, ela tem um importante papel no sistema de
anúncios da meta, porque ela alavanca o poder de da ferramenta, do
processamento da ferramenta ser maior e isso vai te vai ajudar a
ferramenta a prever qual pessoa vai achar o anúncio mais interessante.
Ou seja, a meta vai cada vez colocar mais o anúncio certo na frente da
pessoa certa. É isso que é Andrômeda. Aí lá no final ele vai dizer o
seguinte: "Finalmente, com a adoção de poderosas novas ferramentas
baseadas em IA generativa para criação e otimização de conteúdo
criativo, o número de anúncios na de o número de anúncios recomendados
na no sistema da meta é esperar a a gente espera que ele cresça
significativamente." Que que quer dizer esse parágrafo aqui? É o
seguinte, se você voltar 360 lives atrás minhas e você assistir a todas
as lives, você vai ver que em dezenas dessas lives, eu falo para você, a
meta recomenda seis anúncios por grupo de anúncio. Pedro, tô começando
agora. O que que é um grupo de anúncio? Imagina que uma campanha é como
se você fosse criar uma caixinha. Então, dentro de uma caixinha, eu vou
colocar a min, é a minha campanha. Isso daqui, na minha campanha, eu vou
definir o quanto de dinheiro que eu vou gastar e eu vou definir o meu
objetivo. São as duas principais coisas que eu vou definir dentro da
campanha. Depois eu vou colocar aqui dentro os meus conjuntos de
anúncio. O que que é o meu conjunto de anúncio aqui? Basicamente eu vou
definir para quem que eu vou aparecer, onde que eu vou aparecer para
essa pessoa, se vai ser no stories, se vai ser no real, se vai ser no
feed. Então aqui eu defini o porqu e o quanto. Aqui eu for aqui eu vou
definir o para quem e o onde, tá? Então são as duas definições. Então
dentro da campanha eu posso ter vários conjuntos de anúncios diferentes.
Dentro do conjunto de anúncio, por sua vez, eu tenho os meus anúncios.
Os anúncios é o que que eu vou mostrar para a pessoa. Essa é a
explicação. No passado, a meta recomendava que a gente colocasse em cada
um dos nossos conjuntos de anúncio seis diferentes anúncios. Ou seja, eu
tenho um público e para este público eu vou colocar para para anunciar
para ele seis diferentes anúncios. Pedro, por que que eu vou fazer isso?
Porque a meta vai entender melhor, ela vai descobrir para mim através da
inteligência artificial, através do machine e learning qual anúncio
performa melhor para esse público para o qual eu tô anunciando. Só que
eu tenho que dar várias opções pra meta conseguir fazer isso de maneira
eficiente. E a gente sempre teve esse limite de seis anúncios. Ter um
limite maior é melhor para nós. E é isso que a Meta tá dizendo aqui. Vou
reler para você. Ela tá dizendo, finalmente, com a adoção de poderas
poderosas novas ferramentas baseadas na IA generativa para criação e
otimização de conteúdos criativos, o número de de criativos de anúncios
dentro da dentro do sistema de recomendação da da meta é esperado, é a
gente se espera que ele cresça significativamente. Ou seja, a meta tá
dizendo: "Olha, você vai poder colocar mais anúncios dentro de cada
conjunto de anúncio." E por que que isso é bom para nós gestores de
tráfego? Porque isso aumenta o nosso potencial de testar. E aí o último
parágrafo, que para mim ele resume o poder da Andrômeda, para nós
gestores de tráfego, ele diz o seguinte: "A Andrômeda, Andrômeda, a
Andrômeda melhora a performance dos anúncios do sistema de anúncios da
meta ao entregar anúncios mais personalizados para os usuários, para os
visualizadores e maximizar o retorno que você tem de gasto nos seus
anúncios". Então, basicamente, ele tá dizendo assim, ó: "A Andrômedra
vai melhorar a performance do sistema de anúncios da meta. A Andrômeda
vai fazer com que o retorno dos seus anúncios ele seja cada vez maior."
Pedro, a Andrômeda, então, é um negócio bom. Sim, a Andrômed deu um
negócio bom, mas ela não é a salvadora da pátria, não é a bala de prata,
não é ela que vai mudar todos os anúncios online da noite pro dia. Os
anúncios online, o tráfego pago, ele muda o tempo inteiro. Mas quando eu
digo que ele muda, não quer dizer que é uma mudança brutal, que nossa,
agora é tudo diferente da noite pro dia. Não, a maior parte das coisas
segue igual e as mudanças elas vão vindo de forma gradativa, tá? Então,
o que que a gente tem que entender hoje com a Andrômedra? O grande
resumo, se você lê essa matéria aqui, eu recomendo que você leia se esse
daqui é o seu trabalho. Mesmo que você não entenda tudo, faça esse
exercício. Você pode, inclusive pegar todo esse texto aqui, jogar na
inteligência artificial e perguntar pra inteligência artificial, olha,
através desse texto aqui, diz para mim como que a Andrômedra vai ajudar
os gestores de tráfego. Vamos fazer isso agora, né? Por que não? Então,
ó, através desse texto, me diga como a Andrômeda vai ajudar os gestores
de tráfego. E aí ele vai me trazer aqui uma explicação de como que a
Andrômedra vai me, ó, beleza, sobrar o meu GPT me conhece, né? Vou te
dar uma resposta que um gestor de tráfego real precisa. sem papo
técnico, engenheiro da Nvidia e sem resumir o texto. Aqui vai como
Andrômeda, ajuda, muda o jogo na prática de quem anuncia. E aí ele vai
me trazer, ó, mais performance de graça, sem você ter que mudar nada. O
Advantage Plus fica mais inteligente. Criativos gerados pela IA começam
a escalar de verdade, segmentação preditiva mais forte, menos
dependência de eu escolher a segmentaçãozinha perfeita, entrega mais
estável e previsível. Então a gente não vai ter tanto imprevisibilidade,
tanta variação nos nossos resultados. Vantagem competitiva para quem
sabe estratégia e não botão. Sete, mais volume de anúncios qualificados,
mais chance de escalar. Então, mais uma vez, a meta dizendo pra gente,
ó, eu consigo testar mais, eu consigo dar conta de aprender mais rápido.
Quem usa estratégia baseada em diversificação de criativos vai ganhar
muito mais. Resume estilo sangue no olho, que é esse daqui. O meu meu
GPT ele é subido. [risadas] Mais ruas, mais estabilidade, mais escala,
mais testes, menos trabalho manual, menos dependência de público, mais
impacto do criativo e mais chances de ganhar do concorrente. O jogo muda
do saber apertar no botão, no botão para saber como pensar tráfego. E é
isso que eu tô te trazendo aqui. Eu não tô apertando nenhum botão, quer
dizer, eu apertei um botão outro na sua frente, mas eu tô falando muito
menos de botão e muito mais de tráfego. E a pessoa fala assim: "Ah, mas
cadê a parte prática? Ele não vai mostrar como é que cria a campanha?" A
gente tem aulas sobre isso. Inclusive, eu não sei quando que você tá
assistindo esse vídeo, mas a gente vai liberar agora todas as aulas de
como fazer anúncios em 2026. Então, como fazer anúncios na meta em 2026,
no Google em 2026, onde a gente vai nessa parte de botões, porque os
botões eles também importam, tá? Assim que essas aulas estiverem
disponíveis, eu vou colocá-las aqui na descrição. Mas para mim, o grande
superper da Andrômeda para nós gestores de tráfego é a gente entender
duas principais coisas. Primeiro, a a recomendação do número de novos
anúncios. Isso daqui muda o jogo. Isso daqui melhora ou piora muito seus
resultados se você não segue essa recomendação? Então, primeiro, a meta
recomenda agora algo como de 8 a 15, conceitos totalmente distintos por
campanhas e não apenas variações. Pedro ferrou. Que que é conceito
totalmente distinto? Esse papo meio esquisito. Vamos lá, vamos dizer. Eu
tô com um livro aqui, ó, sobre aprendizado, é o visual learning, tá?
Então, tô estudando como que nós, seres humanos aprendemos, porque esse
é meu trabalho como professor, tá? Então tô nessa fase agora,
provavelmente eu devo passar uns 5 meses aí focado só em estudar a
andragia, o aprendizado dos adultos, tá? Então, vamos dizer que eu tô
vendendo esse livro e aí eu quero fazer um anúncio para vender esse
livro. Se eu fizer um anúncio falando assim: "Olha, acabei de lançar o
meu livro Visible Learning e a ciência de como que a gente aprende, se
você quer saber como que nós adultos adquirimos conhecimento, não deixa
de clicar no botão de saber mais e comprar o seu livro agora. Aí vamos
dizer que eu vou lá e eu troco de camiseta, eu pego o mesmo livro e falo
o seguinte: "Tô passando aqui só para te falar que eu acabei de lançar o
meu livro Visible Learning e a ciência de como que nós aprendemos. Se
você quer entender mais sobre como que nós adultos aprendemos, clica no
botão de saber mais e garante seu livro. Agora a meta, ela vai olhar
para esses dois anúncios e ela vai encarar esses dois anúncios como
sendo a mesma coisa. Por quê? Porque o conceito é o mesmo. Eu só troquei
de blusa. O que eu falei no vídeo é a mesma coisa. Eu preciso agora
fazer cada vez mais anúncios que conversem com dores, benefícios
específicos que a minha audiência precisa. Então, por exemplo, eu vou
falar com pessoas que querem eh ensinar. Então, eu posso fazer um
anúncio falando o seguinte: "Alguma vez você já se viu nessa situação?
Um conceito parecia extremamente simples na sua cabeça, mas na hora de
explicar pros seus alunos, você simplesmente não conseguia fazer com que
eles compreendessem. Eu já senti a mesma coisa que você". E aí eu fui
pesquisar e eu descobri andragogia, que é basicamente a ciência de como
que as pessoas, como que os adultos aprendem. E eu complei todo esse
conhecimento em um livro que se chama Visual Learning and the Science of
How we learn. Aqui eu coloquei todo o meu conhecimento de mais de 10
anos como professor e eu te ensino aqui o passo a passo de como que as
pessoas aprendem para que você nunca mais fique preso nessa situação de
saber alguma coisa, mas não saber como explicar paraos seus alunos. Se
você é professor e quer aprender um pouco mais sobre esses conceitos,
clica aqui no botão de saba mais e dá uma olhada nesse livro. Fiz um
anúncio. Então, nesse anúncio, eu tô falando com um problema. O anúncio,
ele conversa com o anúncio, ele conversa com pessoas, o anúncio ele
conversa com problemas, o anúncio ele conversa com desejos, o aluno ele
conversa com dilemas. Então, vamos fazer um anúncio que conversa com um
desejo. Aí falou assim, vou vou fazer um exemplo. Você lembra de ter
algum professor na sua vida que você admirava ele? Todos os alunos da
sala adoravam ele. A didática dele era incrível. Ele conseguia explicar
qualquer coisa de maneira extremamente simples e prática. E foi
provavelmente, foi provavelmente por causa desse professor que você
também se tornou um professor. E você também tem esse desejo de ser
admirado, admirado pelos seus alunos. você ter uma didática de respeito
digna de elogios, em que tudo aquilo que você explica as pessoas
compreendem. Sabe por que talvez você ainda não tenha chegado nesse
nível de didática? Por um motivo simples, porque você não entendeu como
que as pessoas aprendem. Você estudou tudo sobre o que você sabe. Você
só não estudou sobre como que você passa esse conhecimento para outras
pessoas. E eu tenho a solução para isso aqui nas minhas mãos. E aí eu
desenrolo meu anúncio. Mas a questão é o que que eu tô fazendo aqui? Eu
estou atacando ângulos diferentes. Ora eu tô falando com um problema,
ora o problema da pessoa não conseguir explicar. Eu tô falando com o
desejo de ser admirado. Eu vou falar no outro anúncio com professores de
uma área específica. E o que que eu estou fazendo? Eu estou criando
conceitos distintos de anúncio e não simplesmente alterando a primeira
frase do anúncio, não simplesmente trocando a cor da minha camiseta do
subido para uma camiseta branca, não simplesmente mudando um pouco o
ângulo do meu anúncio. Se o meu anúncio é de imagem, eu não tô
simplesmente mudando a cor. A meta está me dizendo, eu sou mais
inteligente, eu entendo muito mais agora sobre qual anúncio performa e
qual anúncio não performa. Só que eu quero que você me entregue anúncios
diferentes. Porque se você anunciante me entregar tudo igualzinho,
vários anúncios, mas tudo repetido, eu vou considerar tudo uma única
coisa, porque agora eu sei ver quando você tá tentando me enganar. Isso
é o que a meta tá dizendo pra gente. Então, o que que nós temos que
fazer como gestores de tráfego? Primeiro, a gente tem que diferenciar os
anúncios e apostar cada vez mais em volume de anúncios. E a frase que eu
falo desde a minha live número um se torna cada vez mais verdade, que o
segredo dos anúncios online são os anúncios online. Então nós temos que
diferenciar o quê? O formato. Então eu tenho que variar o formato que
vai ter dentro da minha campanha. Não tem mais isso de, ah, será que
vídeo funciona melhor, foto funciona melhor, carrossel funciona melhor?
Não. O melhor é você ter todos os formatos disponíveis pra meta
anunciar. Então, eu tenho que ter vídeo, eu tenho que ter carrossel, eu
tenho que ter anúncio estático, eu tenho que alterar a narrativa, eu
tenho que falar de diferentes transformações que o meu produto causa,
diferentes desafios que o meu, que aquilo que eu estou divulgando, o meu
serviço faz a pessoa superar. Eu tenho que mostrar os bastidores por
trás do meu produto, do meu serviço. Eu tenho que mudar o gancho, o que
que vai chamar a atenção da pessoa logo no início do meu anúncio. Então,
eu tenho que fazer ganchos de pergunta, eu tenho que fazer ganchos que
conversem com determinados públicos. Então, eu posso fazer uma pergunta.
Por acaso você já se viu numa situação e que você tá tentando explicar
alguma coisa pra sua turma de alunos? Você tenta colocar o conteúdo para
fora, mas você olha paraa cara de todo mundo e tá claramente ninguém
está conseguindo entender aquilo que você tá explicando. Você já passou
por essa situação? Pergunta: posso fazer um anúncio segmentado? Por
acaso parte do seu trabalho é passar o seu conhecimento para outras
pessoas? Se a resposta for sim, eu tenho um convite para te fazer.
contrainttuitivo. A pior maneira de você ensinar algo para alguém é
explicando um novo conceito para alguém. Sei lá, urgência. Você só tem
mais uma semana para garantir o meu novo livro pelo menor preço
possível. público implícito. Dei esse exemplo nos anúncios que eu gravei
anteriormente. Então, anteriormente ficou claro que os anúncios que eu
estava fazendo eram para professores. Então, eu posso falar com
professores da área da medicina no meu anúncio. Isso está implícito no
meu anúncio. Posso falar com pessoas que têm infoprodutos, que t cursos
online dentro do meu anúncio. Isso vai estar implícito no meu anúncio.
Então, eu estou criando essas diferenciações. Por quê? Porque a
Andrômeda, ela tem o superper agora de avaliar a similaridade visual e a
narrativa dos anúncios, entendendo que se os anúncios são muito
parecidos, ela vai considerar isso como o mesmo anúncio. Qual que é o
resumão do antes e depois da Andrômeda? É o seguinte, antes o que que eu
tinha na Andrômeda. Antes eu tinha quatro grandes coisas. Eu tinha
muitos públicos de interesse, Lucales, Cebola, se você não sabe o que
que é isso, nem precisa saber mais. dezenas, às vezes centenas de
microssegmentações. Existia, e você vai ver que isso é uma herança que
vai perdurar durante muito tempo, mas existia uma grande preocupação em
você encontrar o público certo. Entende o seguinte, não é mais você que
encontra o público certo. Quem encontra o público certo é o seu anúncio.
Segunda, segunda coisa que a gente tinha antes, antes nós tínhamos
várias campanhas. O volume de campanhas dentro da nossa da nossa conta
era imenso. Eu tinha muitas campanhas, muitos conjuntos de anúncio. Eu
segmentava tudo de forma extremamente separada. Terceiro, eu tinha
pequenas variações, então eu pegava um anúncio e eu criava 50 variações
mudando algo simples. Então eu mudava o o call to action, eu trocava o
fundo do anúncio e isso era o suficiente. E quarto, o crescimento ele
podia, não é que ele dependia, mas ele podia depender de um refinamento
meticuloso. É o Pedro Sobral ensinando Tráfego Pago em 2000 e 17, 2018,
na época em que você mexer em cada parafusinho era o que mais importava.
Hoje em dia não é mais. Isso é excelente porque abre espaço para que a
gente, nossos gestores de tráfego, para que a gente fique cada vez
melhor nas áreas que mais importam. E agora com a Andrômeda, quais são
as grandes mudanças? Vamos lá. Primeiro, segmentação mais ampla. A meta
recomenda menos fracionamento de público. Ah, Pedro, isso quer dizer,
então que é só eu anunciar para todo o Brasil e já era. A meta vai
encontrar o público para mim? Olha, em algumas situações específicas,
talvez sim, mas na maioria não. A gente ainda tem que dar informações
pras ferramentas. Entenda o seguinte, para de achar que a Andrômeda, o
Advent Plus, o PMEX, que são as ferramentas de automatização das
campanhas da Meta e do Google, respectivamente, são ferramentas que vão
te livrar de todo o seu trabalho. Não. O trabalho do gestor de tráfego
ainda é entregar os inputs, as informações para as perguntas que a
campanha nos faz. Então, se existe, por exemplo, se eu estou anunciando
uma loja, um negócio local, não faz muito sentido eu colocar uma
segmentação a nível Brasil, porque eu tenho que dar o input para
ferramenta, de onde que meu negócio está, qual que é a minha região de
atuação, até onde que o meu delivery entrega, tudo isso são informações
essenciais e que a ferramenta Andrômeda, o Advent Plus, não tem como
adivinhar, mas a gente vai dar essas informações pra ferramenta.
Segundo, nós temos hoje uma estrutura mais simples. Então, eu tenho
menos anúncios, aliás, eu tenho uma estrutura mais simples. Isso era
para ter uma setinha. Eu tenho mais anúncios e muito mais criativos em
um único conjunto de anúncios. Lembra da explicação? Eu tenho a minha
campanha, tenho os meus conjuntos de anúncio e agora eu tenho muito mais
anúncios aqui dentro. Terceiro, agora você precisa ter uma diversidade
real de conceito visual, narrativa, formato, gancho, ângulo,
perspectiva. Lembra dos diferentes anúncios que eu mostrei para você? Eu
tenho que apresentar esses diferentes anúncios. E último, e não menos
importante, a automação vai permitir que eu escale mais e que eu consiga
me movimentar mais rápido. O que que é me movimentar mais rápido? vai
permitir que eu consiga testar mais rápido, descobrir mais rápido o que
que funciona. Eu não preciso ter mais tanto dinheiro paraa meta
conseguir testar os meus anúncios como era no passado. No passado eu
dava aulas sobre relevância estatística. Eu nunca mais falei esse termo
na vida em nenhuma aula. E você não tem mais que saber isso. Por quê?
Porque são conceitos que então são mais aplicáveis no dia de hoje. Ah, o
tráfego de hoje é 100% diferente do tráfego de 2015? Não. A gente ainda
seleciona objetivos, orçamentos, segmentações, cria anúncios, conversa
com dores, com desafios, com desejos, mas a gente, a maneira como a
gente se faz isso, ela mudou completamente. Mas o tráfego ele não muda
na noite pro dia, como as pessoas vendem para você. Agora tudo é
diferente. Ou se adapta ou morre. Não. Se você tiver aqui terça-feira,
uma horinha da sua semana vendo uma aula de tráfego pago, 1 hora da sua
semana, entende que 30 minutos é 2% do seu dia, 1 hora é 4% do seu dia.
Eu tô pedindo 4% de um dia da sua semana. Esse compromisso que você tem
que fazer. Não tem como você não aprender tráfego pago se você tiver
aqui toda semana. Entenda que as atualizações que precisam ser faladas
de tráfego pago vão estar aqui nessas aulas para você, tá? Então, a
Andrômeda, até me estendi mais do que eu esperava aqui na explicação,
mas a Andrômeda, ela é essa nova ferramenta de processamento das
campanhas mais automatizadas. E aí vem a grande pergunta, né? O que que
são as campanhas automatizadas? O que que são as campanhas Advantage
Plus? e Pemex são nomes que você vai ouvir muito. Então, campanhas
automatizadas são campanhas que automaticamente escolhem para você, ou
seja, elas automatizam o quê? suas segmentações, então para quem que o
seu anúncio vai ser mostrado, seus posicionamentos, ou seja, onde que o
seu anúncio vai ser mostrado. Ela automatiza para você os testes de
anúncios, então carrossel, vídeo e imagem, e ela automatiza para você a
alocação de verba entre os seus diferentes anúncios. Então, no passado,
eu tinha que lá escolher cada segmentação. Hoje isso não é mais
necessário. Não quer dizer que isso não seja mais possível, não quer
dizer que não seja mais recomendado, mas não é necessário. Eu posso
anunciar sem ter que escolher segmentação. Depois eu tenho que escolher
os meus posicionamentos. No passado, eu era obrigado a escolher onde que
eu ia aparecer. Hoje a ferramenta olha para mim e fala assim: "Deixa
comigo, deixa comigo que eu escolho o melhor lugar para mostrar o seu
anúncio." No passado, eu tinha que fazer testes de criativos
extremamente isolados, estruturas de campanhas que iam testar os meus
anúncios. Hoje você não tem mais que fazer isso. Isso quer dizer que
você nunca tem que fazer isso? Não. Em estratégias de tráfego pago mais
avançadas. e não veja estratégias de tráfego pago avançadas como sendo
algo a tenho a estratégia iniciante que é ruim e a avançada que é boa.
Não. Avançada quando você tem muito dinheiro para gastar, quando você
produz anúncios quase que infinitos, aí tudo bem, a gente pode ter
estruturas de campanhas mais robustas que vão testar os nossos anúncios,
tá? Aí você vai ter estruturas de campanhas 1 xx, tá? Então aqui assim é
um uma portinha avançada no meio da aula, tá? Mas para cada conjunto de
anúncio que eu vou ter, na verdade eu vou eu vou dizer, não vai nem ser
1 xx, vai ser 1 x 8. Então, a cada conjunto de anúncio que eu criar, eu
vou ter oito anúncios dentro desse conjunto de anúncio e eu vou fazer
várias vezes o mesmo público. Vou fazer várias vezes o mesmo público
para testar diferentes anúncios. Pedro, não entendi nada. Tá tudo bem,
segue o jogo. Não era esse conhecimento para você. Agora, antes eu tinha
que escolher quanto que eu ia gastar de dinheiro em cada público. Eu
tinha que escolher isso. Ah, vou gastar R$ 50 nesse público, 40 nesse,
30 nesse. No outro dia eu olho e falo assim: "Putz, esse público que eu
tô gastando 30, ele tá muito bom. Vamos colocar mais dinheiro nele."
Então eu fazia a realocação da verba. Hoje eu não tenho mais que fazer
isso. Então, as ferramentas de automação, elas escolhem essas coisas pra
gente, principalmente esses quatro pontos. Tem gente que acha, nossa,
automatizou tudo não. Tem várias escolhas que ainda sou eu que tenho que
fazer. Agora, essas ferramentas, elas funcionam? Sim e não, Pedro, como
assim? Sim e não. Sim, porque elas fazem, elas fazendo parte da sua
estratégia, elas funcionam muito bem. Não, porque se só elas forem a sua
estratégia, eu não julgo que essa seja uma estratégia boa. Ah, Pedro,
mas eu testei dezenas de tipos de campanhas e as únicas que estão
funcionando são as campanhas Advente. Ótimo, você tá fazendo um bom
trabalho. Agora, Pedro, eu só botei a campanha de ventage para rodar e
tá dando certo. Eu nunca testei mais nada. Acho que você tá fazendo um
trabalho porco. Pedro, eu não acredito em campanha de ventag. você tá
viajando na maionese, você tem que ter a campanha Advent, a campanha
Pemex, como parte da sua estratégia, tá? Agora, quando a gente tá
falando de advantage, eu vou falar dos dois aqui. Advantage é a
automatização da meta. Pmex é a automatização do Google. Quando eu tô
falando da meta, eu tenho cinco, opa, copiei errado. Eu tenho cinco
recursos advantage dentro da meta. Quais são eles? Vamos lá. Eu tenho a
campanha advantage, que é quando eu tenho todos os recursos advantage
utilizados. Depois eu tenho quatro recursos advantage na meta, que são
essas automatizações aqui. Então eu tenho o orçamento advantage, que a
sua campanha decide em que grupo de anúncio ela vai gastar dinheiro. Eu
tenho o público advantage. A meta vai encontrar o seu público alvo para
você. Eu tenho o posicionamento advented, que a meta vai escolher o
melhor local para veicular o seu anúncio. E eu tenho o Criativo Advente.
Ele vai vai trazer otimizações automáticas e vai escolher títulos,
descrições e até mesmo imagens para você. Quando eu estou com todos os
recursos advented ligados, eu vou receber ali dentro da meta, eu vou ver
uma janelinha parecida com isso daqui. Pera aí que eu copiei, às vezes
demora um pouquinho para copiar. Enquanto isso eu tomo uma água, ó.
Quando você ativar todos os recursos advented, é isso daqui que você vai
ouvir. Você tem 100% da pontuação de campanha. Você está usando a nossa
configuração recomendada, você está usando o orçamento de campanha, você
está utilizando o público adventage, os posicionamentos advantage. Então
isso daqui que vai aparecer para você quase que um parabéns, você tá
mandando muito bem. Você sempre tem que utilizar isso, não. Em algumas
situações, propositalmente nós não vamos utilizar alguns desses
recursos, tá, Pedro? Então, quando que eu uso e quando que eu não uso os
recursos advented? Para cada pergunta que você tem, eu te trago uma
resposta, meu querido. Primeiro, orçamento adventar em 99% das vezes.
Por quê? Se eu tenho foco em escala, se eu não quero ter o controle de
quanto que eu tô gastando em cada público e eu não entendo nada sobre
otimizações de orçamentos, vai de orçamento advented, vai ser feliz. No
passado eu dava horas de aula só sobre otimização de orçamento. Era um
caos, quase ninguém entendia, as pessoas travavam nisso daqui, deixavam
de ter resultado por causa disso. Hoje este problema está resolvido.
Bota o orçamento advent. Segundo tipo de otimização, público advente. Se
eu estou buscando escala, se eu consigo avaliar rápido eh a qualidade,
não tanto, eu vou eu vou pular esse ponto, desculpa, eu ia colocar um
ponto aqui, eu eu vou ignorar ele. Se eu não estou anunciando numa
região extremamente específica e se essa campanha complementa uma
estratégia maior, eu posso utilizar o público advented. Ou seja, tô
buscando escala, tô buscando aparecer muito. Usa o público advented. Não
tô anunciando numa região extremamente específica. Usa, Pedro. Eu tô
anunciando numa região específica. Eu anuncio em determinados bairros da
cidade de São José dos Campos. Não usa campanha Advente. Por quê? Porque
o Advent vai anunciar para pessoas fora do da sua região. Então não usa.
Se você é um negócio local, provavelmente você não vai utilizar nesses
casos. Terceiro, essa campanha complementa uma estratégia maior. Eu
sempre gosto de dizer que o adventage ele tem que fazer parte da sua
estratégia e ele não tem que ser a sua estratégia, tá? Então isso daqui
que é o público advented. Um detalhe importante, você tem que entender
que existem, aqui eu vou dar uma complicada, tá? Existem dois tipos de
segmentação. Existe a segmentação e existe a sugestão de segmentação.
Segmentação é quando eu escolho para quem eu vou aparecer. Sugestão de
segmentação é quando eu dou dicas para a meta de para quem eu quero
aparecer. Deixa eu sair aqui da de baixo para quem eu quero aparecer.
Mas a meta no final das contas define para quem eu vou aparecer. É isso.
Então, eu posso fazer, presta atenção, eu posso fazer anúncios.
Desculpa, faltou um, são três, eu errei. Deu. Agora sim, eu sabia. Eu
falei: "Ué, tá faltando alguma coisa". Então, eu posso fazer
segmentação, que eu escolho para quem que eu vou aparecer. Eu posso
fazer o adventage sem sugestão de segmentação, que é basicamente eu
dizendo meta, escolhe aí para quem eu vou aparecer. E eu posso fazer o
adventage com sugestão de segmentação. Então eu dou dicas paraa meta de
para quem eu quero aparecer e a meta no final das contas define para
quem eu vou aparecer. Pedro, mas na prática, como é que eu faço isso? Na
prática, isso daqui vai selar durante a configuração da sua campanha,
quando você tiver aqui apertando os botões. E aí é o que eu falei para
você, nós temos aulas específicas onde a gente ensina sobre isso. Então,
ó, vai chegar o momento aqui, ó, que você vai ter que selecionar e você
vai ver que é muito intuitivo, tá? A própria meta vai te perguntar, ó,
quero colocar ou não quero colocar uma sugestão de público, tá? Mas
lembrando, assim que essas aulas estiverem no ar, o link delas vai estar
aqui na descrição de como que você cria as campanhas na prática. Aí você
vai aprender a parte dos botões. Aqui eu tô te ensinando a pensar
tráfego pago, tá? Qual que é a minha a minha visão sobre esses tipos de
segmentação? É o seguinte, sobre as sugestões de segmentação. Sempre
teste, sempre teste a sugestão de segmentação, principalmente dando
sugestões de públicos quentes. O que que é um público quente? alguém que
já interagiu com a sua marca, alguém que já interagiu com o seu negócio.
Então eu vou dizer pra meta, ó, a minha sugestão é que você vá por esse
caminho, que você tente tente encontrar pessoas parecidas com essa
galera aqui. Um grande cuidado que você tem que ter hoje, muitas pessoas
vêm aqui na configuração da campanha, aí elas vão lá e falam assim:
"Não, eu vou escolher a minha segmentação". Então elas vão clicar aqui
em mudar para as opções originais de público. Elas vão usar o público
original ao invés do público advantage. Repara eh que vai mudar aqui a
estrutura de como que eu tô criando a minha campanha. E aí eu vou
selecionar aqui para quem que eu vou aparecer. Muitas pessoas podem
chegar aqui e utilizar os direcionamentos detalhados. Que que é o
direcionamento detalhado? É o famoso interesse, tá? Então, vamos dizer
que eu quero ter uma barbearia. Aí eu vou colocar aqui barba. Ah, então
quero anunciar para quem tem interesse em barba. Quando eu coloco
interesse barba, você vai receber essa mensagem: o direcionamento
detalhado advended plus foi aplicado. Que que isso quer dizer? que se
você seleciona um direcionamento detalhado, um interesse, você está
transformando o seu público num público advented. Então eu já quando eu
uso direcionamento detalhado, eu tô falando meta, pode escolher para
quem que você vai anunciar, tá? Então, no passado, antes direcionamento
detalhado era segmentação. Hoje direcionamento detalhado é sugestão.
Então, quando eu uso direcionamento detalhado, eu estou sugerindo uma
segmentação. Eu não estou segmentando. Beleza? Terceiro tipo de recurso
de venta de quando a gente utiliza ele. Lembrando, ó, a gente tá falando
de quando que eu uso esses recursos. Eu já falei do orçamento advantage,
do público advantage. Agora, terceiro recurso advantage, posicionamento
advantage. Vou utilizar 80% das vezes. Quando que eu vou utilizar?
Quando eu não tenho anúncios extremamente específicos para cada
posicionamento. Então, por exemplo, se eu tenho um anúncio que eu falo
assim: "Se você tá vendo esse story aqui, é porque, pô, se eu tô
falando, se você tá vendo esse story, eu eu tenho que aparecer no
stories. Então, eu vou colocar aquele anúncio somente nos stories. Eu
não tô buscando uma qualificação de renda do público. Por que uma
qualificação de renda? Porque quem tem menos dinheiro normalmente usa o
Facebook. Não é preconceito, são dados. Terceiro ponto, não tenho ideia
do que tô fazendo e tô começando agora. Usa posicionamento advantage.
Quarto ponto, quero escala, usa o posicionamento advantage, tá? Então,
essas são as situações em que você vai utilizar o posicionamento
adventade. Ele vai ser configurado aqui, ó, no final do seu grupo de
anúncio, ó. Ele já está ativado aqui, ó, posicionamento advantage. Se eu
quiser mudar ele, se eu não quiser o posicionamento advantage, eu vou
apertar em editar e vou mudar para o posicionamento manual, tá? E aí eu
vou fazer a seleção aqui de onde que eu quero aparecer. São mais
configurações, mas é uma é uma configuração que em algumas situações vai
fazer sentido. Quarto tipo de recurso advantage é o criativo advantage,
tá? Quando você vai subir o seu anúncio, sempre desativa o recurso de
otimização automática dos seus anúncios, tá? Então, sempre aqui não é
nem não é nem recomendação, tá? sempre desativa o recurso de
automaticamente melhorar os seus anúncios. Por quê? Porque é muito ruim
ainda. No futuro vai melhorar. Quando melhorar eu vou falar que
melhorou, tá? E aí sempre coloca múltiplos títulos, descrições e imagens
no seu anúncio. Ah, Pedro, beleza. E a campanha da Pemex do Google, qual
que é a diferença? O Pemex é um tudo em um do Google. Então, quando eu
vou fazer anúncio aqui no Google Ads, eu vou fazer anúncio onde? Eu vou
fazer anúncio no Google, eu vou fazer anúncio no YouTube, eu vou fazer
anúncio no Gmail, eu vou fazer anúncio no Discover, que é uma uma
ferramenta do Google, eu vou fazer anúncio nos sites parceiros do
Google. Leia-se, 90% dos sites da internet, eu vou fazer anúncio nos
aplicativos que estão no Google Play, todo mundo que usa Android, ou
seja, eu apareço na internet inteira, só que eu posso criar anúncios
específicos pro Google, eu posso criar anúncios específicos pro YouTube,
eu posso criar anúncios específicos pro Gmail, eu posso criar anúncios
específicos pro Discover, eu posso criar anúncios específicos pros sites
parceiros, eu posso criar anúncios específicos pros aplicativos que
estão no Google Play. Só que quando eu uso a campanha de Pemex, o que
que eu tô fazendo? Eu tô colocando tudo no mesmo balaio. Quando eu faço
a campanha do Google, eu vou vou colocar o que lá dentro? O que que ela
me pede de informação? Nessa campanha Pemex, ela me pede um indicador de
público alvo, ou seja, uma sugestão. Ela tá me dizendo: "Ah, me dá uma
sugestão de quem que é o seu público." Ela me pede um anúncio de texto,
ela me pede um anúncio de vídeo, ela me pede um anúncio de imagem. Por
quê? Porque eu preciso dos anúncios de texto, vídeo e imagem para
aparecer em todas as plataformas. E aí, o que que essa ferramenta
automatiza pra gente? Ela automatiza a escolha das palavras-chave.
Então, para quais termos que eu vou anunciar? Ela automatiza a
segmentação de público. Ela automatiza a alocação de verba por canal, ou
seja, Google, YouTube, Gmail. Os sites parceiros a gente chama de GDN,
que é a Google Display Network, tá? Vou colocar o nome certinho aqui. Os
anúncios de aplicativo, os anúncios de discover. É discover ou
discovery, eu nunca lembro. Eu acho que é discover, tá? Se alguém
souber, manda no chat aí, por favor. Então, a gente tem aqui, eu não
escolho mais o quanto que eu vou gastar em cada um desses daqui, não
nesta campanha, mas eu vou ter outras campanhas onde eu escolho quanto
que eu vou gastar em cada um desses daqui. E ela automatiza para mim. o
criativo, título, descrição, imagem do vídeo, etc. Aí eu olho para essa
campanha e falo pro Google: "Voa, voa, meu querido, bate asas,
passarinho, vai para cima". E aí, quando que eu vou utilizar isso daqui?
sempre que eu quero escalar para e-commerces, essa campanha é linda,
maravilhosa. Para negócios locais que querem visitas ao seu negócio
local, presenciais físicas, essa campanha é uma palhaçada de boa. Melhor
campanha que existe para isso. E para quem tá gerando lead, cuidado com
a qualidade dos leads. Então, quando você tá gerando lead, cuidado,
porque pode vir muito lead lixo através desta campanha, tá? Pra gente
finalizar, regras de ouro das essa aula aqui é a Bíblia das
automatizações, não tem como. Para finalizar, regras de ouros das
automatizações. Regra de ouro um, o combo é melhor do que o solo. Usa os
recursos advantage, mas sempre tenha campanhas paralelas com estruturas
mais controladas, campanhas que vão anunciar para remarketing, ou seja,
pessoas que já interagiram com seu negócio, campanhas que vão focar em
públicos quentes, campanhas que conversam especificamente com públicos
quentes. Regra de ouro, lembrei de uma agora. Regra de ouro que Regra de
ouro. Deixa eu colocar aqui. Regra de ouro que eu lembrei agora.
[risadas] Rega, quem sabe faz ao vivo. Não demonize as automatizações,
tá? Não demonize e também não coloca elas num pedestal. Não é 8 nem 80.
Regra de ouro dois. Tá? Então a regra de ouro dois. Regra de ouro número
dois. Vamos lá. Não é porque não funcionou no passado que não vai
funcionar agora. Deixa eu mudar aqui. Deixa eu botar isso daqui como
dois, isso aqui como três. Não é porque não funcionou no passado que não
vai funcionar agora. Então, se uma automação não funcionou no passado,
não quer dizer que você não tem que testar ela de novo depois de alguns
meses. Constantemente você tem que testar aquilo que não funcionava no
passado. Regra de ouro número três. Use os recursos como um teste. Olha
pro seu, pra otimização de orçamento. Isso é um teste. Pode ativar e
desativar. Isso é um teste. Olha pro seu público com sugestão, sem
sugestão, usando a sugestão como público frio, usando a sugestão de
público como público quente. Isso é um teste. Olha pra parte de
posicionamento, ativar e desativar o recurso advantage como um teste. O
que que é um teste? Se eu ativo, como é que fica o resultado? Se eu
desativo, como é que fic? Aí se piorar é só mudar de novo para como
estava antes e olha para as otimizações de criativos como um teste.
Quando a gente coloca dessa maneira, a gente percebe que as automações
não são de tantas coisas, não, tá? É a locação de verba entre públicos,
para quem eu vou anunciar, onde que eu vou aparecer e os meus anúncios.
Regra de ouro número quatro. Se você não tem ideia do que você tá
fazendo, você tá começando agora, tá, e você só quer vender, pode ser um
bom teste para você começar só rodar campanha de ventag para você
começar a rodar só ter a campanha de ventag. Regra de ouro número cinco.
Pô, são muitas regras de ouro, né? Então não é tanto ouro assim, mas
regra de ouro número cinco. Se você não for vender com essas campanhas,
sempre avalia a qualidade do público que tá vindo. Pedro, como assim? Se
essa campanha for trazer leads, o que que é lead? alguém que me deu
e-mail, o telefone e ela, essa pessoa não vai comprar no ato da campanha
logo depois que ela viu o anúncio, você tem que avaliar se esse público
que você tá atraindo através dessas campanhas Advent Pemex são públicos
bons. Regra de ouro número seis. Cuidado com adventa de público para
negócios locais, porque se eu tô automatizando o público para negócio
local, eu posso acabar anunciando para fora da região de atuação. Regra
de ouro número sete: Se o seu criativo ou os seus criativos forem
horríveis, uma bosta, não é o adventage que vai salvar. E regra de ouro
número oito e muito importante, se o seu pixel não te trouxer dados, ele
vai demorar para entregar os seus anúncios para as pessoas corretas. E
pode nem entregar os seus anúncios para as pessoas corretas. Terxel
corretamente instalado no seu site é o fator determinante para o sucesso
das suas campanhas advento, se você tá levando as pessoas pro seu site,
tá bom? Live Expressa, que acho que eu nunca entreguei tanta informação
numa única live. Perceba, você não encontra isso aqui em curso pago da
internet neste nível de organização. Isso aqui tá maravilhoso,
maravilhoso. Pedro, então você entrega tudo de graça? Sim, toda
terça-feira, 3 horas da tarde você encontra aqui neste canal uma aula ao
vivo sobre tráfego pago e anúncios online. Coloca na sua agenda, coloca
o celular para despertar, reserva esse horário da sua vida, o seu
horário de aprendizado, porque lembra, quanto mais você investe em você,
mais cara fica a sua hora. Isso daqui é um investimento que você tá
fazendo em você. Fechou, meu povo? Estamos junto. E a gente se vê agora
na próxima terça-feira, 3 horas

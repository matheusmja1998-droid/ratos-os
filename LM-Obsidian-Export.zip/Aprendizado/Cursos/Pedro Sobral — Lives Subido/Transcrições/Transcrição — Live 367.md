---
tipo: transcrição
live: 367
tema: Como segmentar seus anúncios — O guia definitivo
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #367

> Como segmentar seus anúncios — O guia definitivo

Resumo e aplicação: [[Live 367 — Como segmentar seus anúncios — Guia definitivo]]

---

Bem-vindos, bem-vindos à nossa live número 367. Como segmentar as suas
campanhas no tráfego pago, ou seja, como que a gente vai garantir que os
seus anúncios apareçam pras pessoas corretas? Há um tempo atrás, acho
que pô, umas 200 lives atrás, eu lembro que eu dei uma live que o título
era Como fazer anúncios impossíveis de serem ignorados. E aí uma pessoa
me questionou naquela live, depois que a live acabou, ela disse assim:
"Pedro, mas você não ensinou a fazer anúncios impossíveis de ser
ignorados. Você ensinou a fazer os anúncios que vão ser ignorados pelas
pessoas que a gente não tem interesse em aparecer." Aí eu me liguei que
o grande segredo não era querer aparecer para todas as pessoas, querer
chamar a atenção de todas as pessoas. Não é isso que caracterizava um
bom anúncio online, um bom tráfego pago, mas o que caracteriza um bom
tráfego pago, um bom anúncio online é você chamar a atenção de quem
importa. E dentro deste chamar a atenção de quem importa, nós temos que
saber escolher para quem nós vamos aparecer. Como que eu faço para
aparecer para as pessoas que têm o maior potencial de que eu realize o
meu objetivo como anunciante? É isso que a gente vai aprender aqui na
nossa live número 367. E ó, antes da gente iniciar aqui o conteúdo,
quero deixar duas coisas claras aqui para vocês, dar dois recados para
vocês. A primeira é que nós estamos com as inscrições abertas para o
nosso curso gratuito de tráfego pago, que é o desafio da gestão de
tráfego. Neste momento, você está aqui, ó, no meu canal do YouTube, você
está assistindo a esta live aqui, tá? Então eu tô aqui falando que você
tá assistindo essa live e aqui na descrição do vídeo você tem o primeiro
link onde você consegue participar do nosso curso gratuito que é o
desafio da gestão de tráfego. Pedro, o que que é o desafio da gestão de
tráfego? Resumindo para você aqui são 10 horas de conteúdo, mais acesso
a algumas inteligências artificiais, mais acesso ao materiais PDF,
tutoriais extras de todas as aulas. Nessas 10 horas de conteúdo, você
vai aprender o que que são e como é que funcionam os anúncios online,
como anunciar no Instagram para vender o que você quiser, como que você
faz para dominar o topo da pesquisa do Google com anúncio online, como
que você vai encontrar, precificar e fechar os melhores clientes com
tráfego pago, de tráfego pago, aliás, e um plano prático para você fazer
R$ 10.000 R$ 1000 por mês com anúncio online. Esse curso gratuito que a
gente faz, a gente já teve algumas versões passadas do desafio da gestão
de tráfego e eu consigo garantir para você, não existe um intensivão
melhor para você começar 2026 com o pé direito tendo resultados no
tráfego pago. Se eu pudesse, se alguém me pergunta, pô, qual que é o
melhor início do tráfego pago, melhor conteúdo que eu tenho que assistir
para começar? Eu com certeza diria que é o desafio da gestão de tráfego,
tá? Então você pode clicar no link, tá na descrição, você pode se
cadastrar. O desafio começa lá no dia 26 e as aulas do desafio elas
acontecem ao vivo, só que ao invés das aulas serem às 3 da tarde, como
as aulas de terça-feira, elas acontecem às 8 horas da noite. Mas eu
falei para você que eu tinha duas coisas para te falar. A primeira é
sobre o desafio da gestão de tráfego e a segunda é sobre as nossas lives
de terça-feira, porque muitas vezes eu falo aqui que nós estamos fazendo
lives há 300 e tantas semanas, né? Hoje é a nossa live número 367. Eu
tenho um apego especial por todas as lives que terminam em sete, porque
parece que o número é muito grande quando termina em sete. E realmente
367 semanas já é um número bem impressionante. E aí você pode falar
assim: "Pô, Pedro, mas eu entrei lá no seu canal do YouTube, fui lá me
inscrever no desafio da gestão de tráfego e eu não encontrei 367 lives.
Isso é porque a gente segue um modelo de conteúdo aqui que eu chamo de
conteúdo perecível. Que que é o conteúdo perecível? Toda terça-feira, 3
horas da tarde, tem uma live. Terça-feira da semana seguinte, eu tiro
aquela live do ar e a gente entrega um novo conteúdo. Algumas aulas
ficam disponíveis por tempo indeterminado, mas a maior parte das aulas
fica disponíveis, ficam disponíveis somente por 7 dias, assim como as
aulas lá do desafio da gestão de tráfego que vão ficar disponíveis
somente durante o nosso evento. Depois não adianta chorar, esperar,
pedir meu Deus, libera aula, não tem como, tá? Mas temos esse conteúdo
pela frente aqui. Temos mais ou menos uma hora de conteúdo hoje na nossa
live número 367. Pedro, como é que você sabe que é uma hora de conteúdo
se você está ao vivo? Porque eu já dei muitas lives, né? Então, pelo
tamanho do planejamento da minha aula, eu consigo já dizer mais ou menos
quanto tempo que vai durar aqui esse conteúdo da nossa live de hoje
aqui. Essa é a primeira live de Essa é a primeira live de 2026. Nossa, é
verdade, porque a última foi dia 30, né? A live do dia 30 foi para os
fortes, mas essa é a nossa primeira live de 2026, pô. Muito bom. Então,
bem-vindos à nossas lives de 2026. E o que que a gente vai falar hoje
aqui na primeira live de 2026? Vamos falar da parte da segmentação dos
anúncios. Então, antes de mais nada, como eu já tava dando um pequeno
spoiler aqui para você, segmentar é você escolher para quem os seus
anúncios vão aparecer ou até mesmo onde que os seus anúncios vão
aparecer. Então, é você escolher para quem ou onde que os seus anúncios
vão aparecer. Pensa o seguinte, pra gente já iniciar aqui com pé direito
no conteúdo. Pensa que dentro de cada plataforma eu tenho infinitas
combinações para encontrar o meu público alvo, tá? E essas infinitas
combinações, elas são baseadas em seis aspectos diferentes. Aspecto um,
para eu encontrar o meu público alvo no tipo de conteúdo que ele consome
nas redes sociais. Aspecto número dois, nas pesquisas que essa pessoa já
fez na internet. Aspecto número três, nos sites que essa pessoa visita.
Aspecto número quatro, nos aplicativos que essa pessoa tem no celular.
Aspecto número cinco, nas interações de marca que ela tem. Então, se ela
já interagiu com a minha marca, se ela já interagiu com o meu Instagram,
se ela já interagiu com o meu site, se ela já se cadastrou no meu site,
se ela já fez alguma compra na minha loja, se ela já agendou uma
consulta comigo, se ela já comprou um produto, contratou algum serviço
que eu presto. E o aspecto número seis, nos dados demográfico dessa
pessoa. Então, com base nesses seis grandes aspectos, eu posso fazer
infinitas combinações para encontrar o meu público alvo. Não importa
qual seja o negócio, não importa o que que você vende, pode ser, sei lá,
consulta de terapia, pode ser venda de poços artesianos, pode ser curso
de como empinar motocicleta, pode ser vendas de tripés, vendas de
câmeras, vendas de um curso gratuito. Não é, não é venda, né? pode ser a
divulgação de um curso gratuito de tráfego pago, que eu garanto para
você que você nunca vai ter acesso a tanto conteúdo gratuito com tanta
qualidade assim quanto no desafio da gestão de tráfego. Lembrando que o
link tá na descrição, mas não importa o que você vai divulgar, existe
alguém nesta internet, existe alguém agora, neste exato momento, que tá
com o celular na mão, que é a melhor pessoa possível para você colocar o
seu anúncio na frente dela. Qual que é a grande diferença? E eu vou
falar muito disso com você lá na aula número um do desafio da gestão de
tráfego, a diferença da publicidade do passado pro presente. Existem
várias diferenças, eu não vou dar o spoiler aqui de todas elas para
você, mas uma das grandes diferenças da publicidade do passado paraa
publicidade dos dias atuais é que nós temos muito mais controle de para
quem nós vamos aparecer. No passado, se eu colocasse um anúncio numa
revista, num jornal, no rádio, eu até poderia ter algum tipo de
segmentação. Por exemplo, o horário que eu vou aparecer, eu posso
aparecer para um público que tem uma característica mais X versus um
público que tem uma característica mais Y. Só que dentro das fontes de
tráfego, dentro das redes sociais, a gente tem esse poder num nível
absurdo. Tem gente que há quem diga, né, que as redes sociais sabem mais
sobre nós do que a gente mesmo sabe sobre os nossos interesses, sobre
aquilo que a gente gosta, sobre aquilo que a gente não gosta. O que que
você encontra dentro do seu explorar do Instagram diz muito sobre você.
Então, se eu abrir aqui o meu explorar do Instagram, eu vou encontrar
aqui, ó, yoga surf. fotografia e música. Essas daqui são basicamente as
coisas que eu que eu eu consumo dentro do que eu estou consumindo dentro
do Instagram. Se a partir de agora eu começar a ver vídeos de
motocicletas, vai começar a aparecer vídeo de motocicleta aqui para mim.
Se eu começar só consumir memes, eu vou abrir aqui o meu Instagram, meu
algoritmo vai só enviar para mim memes. Me responde aqui no chat o que
que tem no seu explorar do Instagram, quais são os seus interesses? O
que que a rede social, a sua rede social diz sobre aquilo que você
gosta, diz sobre aquilo que você consome? Hoje em dia, nós somos
mapeados em tudo aquilo que a gente faz. Há quem diga que os nossos que
os nossos celulares eles nos escutam e a verdade é que sim, de alguma
maneira eles escutam todos os sinais sociais que a gente tem, que a
gente faz. Então toda vez que você para para ler uma publicação, o
Instagram sabe que você parou. Toda vez que você dá play num vídeo, o
YouTube sabe que você deu play num vídeo, que você faz uma busca na
internet, que você arrasta pro lado para ver um carrossel, que você
assiste um story, que você compartilha uma publicação do Facebook com um
amigo, que você pega um post que você viu no Instagram e você manda no
WhatsApp do grupo da família, tudo isso tá sendo mapeado. Existe um
rastro digital que a gente deixa o tempo inteiro na internet por estar
usando as redes sociais. E isso pode ser absolutamente assustador paraa
maioria das pessoas, mas para mim não é assustador não. Para mim isso é
absolutamente maravilhoso. Por quê? Porque é somente por causa desse
rastro que nós deixamos na internet que nós vamos utilizar ferramentas
como o Metaads e o Google Ads para que a gente consiga aparecer para as
pessoas. Tô colocando aqui o MetaS e o Google Ads na sua frente. Então,
é só por causa desse rastro digital que a gente vai conseguir utilizar o
Google Ads e o Metaads para que a gente possa aparecer na frente das
pessoas certas, para que os nossos anúncios, os anúncios dos nossos
clientes, eles performem, tá beleza, Pedro? Tô entendendo a parte
conceitual da coisa aí, mas ainda assim é um pouco distante para mim
saber como é que eu vou segmentar os meus anúncios, como é que eu vou
escolher para quem que eu vou aparecer. Vamos fazer uma analogia simples
aqui. Imagina que cada segmentação é como se fosse um lago cheio de
pessoas. Então, pega comigo o exemplo. Eu posso anunciar para um grupo
de pessoas que tiveram algum envolvimento com o meu Instagram, que já
interagiram com alguma publicação, já me seguiram, já viram algum vídeo,
já me mandaram alguma mensagem, já curtiram, comentaram, compartilharam
em alguma publicação do meu Instagram. Então eu posso pegar o público de
todo mundo que já teve alguma interação com o meu Instagram nos últimos
365 dias. E aí eu vou ter, imagina que essas pessoas elas estão todas
elas dentro de uma piscina, né? Um piscinão de ramos. Então uma
segmentação é essa piscina, um lago, um lago cheio de pessoas. Se a
segmentação é este grande lago cheio de pessoas, o meu anúncio nesse
cenário, ele é a isca que vai atrair estas pessoas. Então eu posso pegar
esse grande lago cheio de pessoas e vou colocar um anúncio na frente
delas. Nesse anúncio, eu vou falar para elas o seguinte: você vai passar
10 horas assistindo a esse curso gratuito para que você não tenha mais
que passar 8 horas por dia aturando seu chefe chato. Nesse curso
gratuito, você vai aprender o que são e como funcionam os anúncios
online, como anunciar no Instagram para vender o que você quiser, como
que você domina o topo da pesquisa do Google com anúncios online, como
encontrar, precificar e fechar os melhores clientes de tráfego pago,
mesmo que você esteja começando agora. E um plano prático para você
fazer R$ 10.000 R$ 1.000 por mês, ainda em 2026, através do tráfego pago
e dos anúncios online. Para você se cadastrar nesse curso gratuito, é só
você apertar no botão de sa mais. Vamos dizer que por acaso eu botei
esse anúncio aqui, que eu soltei ele do nada aqui na sua frente, sem
segundo as intenções de você clicar no link que está na descrição, mas
vamos dizer que eu solto esse anúncio para este mar, este lago cheio de
pessoas. eu vou acabar atraindo algumas pessoas e outras pessoas eu vou
acabar não atraindo. Se eu, se esse anúncio aparecer para uma pessoa
que, por exemplo, tenha um chefe chato, essa pessoa tem muito mais
chance de interagir com o meu anúncio do que se eu aparecer, por
exemplo, para um empreendedor, alguém que é o seu próprio chefe. E aí a
pessoa pode até se considerar meio chata. Eu mesmo me considero meio
chata às vezes e eu sou o meu próprio chefe. Na verdade, minha chefe é
minha esposa, né? Mas é, deixa eu me iludir aqui sozinho comigo mesmo.
[risadas] Mas a questão aqui é o seguinte, a segmentação ela nada mais é
do que esse lago cheio de peixes, que são as pessoas. E o anúncio ele é
a isca que fisga os peixes. Não é à toa que nós chamamos os primeiros
segundos do anúncio ou a frase que vai escrita no nosso anúncio de
gancho, porque eu tenho que fisgar, eu tenho que roubar a atenção da
pessoa para mim. Agora, se você pegar as minhas aulas antigas de tráfego
pago, se você for lá na minha, acho que, se eu não me engano, foi a
minha terceira ou segunda aula live de tráfego pago que eu fiz na vida
há mais de 365 semanas atrás, você vai ver eu ensinando sobre
segmentações de uma forma muito mais milimétrica. Que que eu quero dizer
com isso? que no passado você precisava milimetricamente testar cada
segmentação. Então o lago onde eu estava pescando, ele importava tanto
quanto a isca. Eu precisava saber exatamente para quem que eu queria
aparecer. E eu tinha que testar esses seis aspectos aqui. Eu tinha que
fazer combinações entre esses seis aspectos, infinitas combinações para
descobrir o público alvo, correto. Ou seja, eu tinha que pegar as minhas
iscas, os meus anúncios, e eu tinha que colocar essas iscas em vários
lagos diferentes para ver se os peixes, as pessoas se interessavam por
aquela isca ou não. Eu tinha que fazer isso no passado. Agora no
presente o negócio mudou. Por quê? Porque no presente a meta, o Google,
ela transformou o seu anúncio em uma superisca que atrai os peixes
certos para perto dela. Que que eu quero dizer com isso? Que os anúncios
online de hoje em dia, eles são muito mais poderosos do que os anúncios
online de 11 anos atrás, quando eu comecei a anunciar na internet lá em
2015. Ou seja, eu posso colocar minha isca em lagos que tem mais pessoas
e a própria meta e Google vai atrair as pessoas paraa minha isca. É como
se eu tivesse um íã das pessoas corretas na minha isca agora. Então a
minha isca ela não tem mais só que fisgar os peixes. As próprias
ferramentas vão fazer com que a minha isca, o meu anúncio apareça pras
pessoas corretas. Aí você vai falar assim: "Ô, beleza, Pedro? Então é
isso, valeu, muito obrigado, até a próxima terça-feira, porque a
resposta para eu segmentar os meus anúncios é só deixar a meta e o
Google fazer o trabalho sozinho e eu não me preocupo com mais nada, né?
E a resposta é que sim e que não, [risadas] tá? Por que que a resposta é
que sim e que não? Porque sim, a meta ela é boa demais para encontrar os
anúncios para você. Ela é muito boa. A Meta, o Google, eles são
incríveis em encontrar, desculpa, o público certo para você. Então, se
eu deixo eles tomarem conta do trabalho, muitas vezes eu vou ter
excelentes resultados. Mas a resposta também é não. Por quê? Porque em
várias situações específicas, e elas são constantes na vida de qualquer
anunciante, você deve tomar o controle. Tem algumas coisas no mundo do
tráfego pago que mudam toda semana. Então, toda semana você vai ver
mudanças, alterações. Eu gosto de falar que o fim do tráfego pago, ele
acontece todos os dias. O fim do tráfego pago, como ele é, e o
renascimento de um novo tráfego pago, que é a habilidade que você tem
que ter como gestor de tráfego, pessoa que vai cuidar dos anúncios de
outras empresas ou do seu próprio negócio, tá muito mais ligada à
adaptação do que acúmulo de conhecimento do passado. Mas tem alguns
fundamentos, algumas coisas que não vão mudar. nunca. E uma delas é que
o tráfego pago ele é como se fosse uma gangorra. Alguém aqui já andou de
gangorra quando você era pequeno? Sabe quando você tá brincando de
gangorra com alguém e aí você resolve deixar outra pessoa de castigo?
Porque a gangorra ela é um brinquedo do dos brinquedos do parquinho, ela
é o brinquedo mais tóxico que existe, né? Porque existe uma relação de
confiança ali na gangorra de que você vai descer, aí você vai subir, a
pessoa vai te colocar para baixo, mas às vezes você tá lá embaixo na
gangorra, você subiu e a outra pessoa te deixou de castigo. Pois é, quem
está dos dois lados da gangorra, do tráfego pago, de um lado estão as as
plataformas, as ferramentas. E eu tenho que deixar essas plataformas e
as ferramentas trabalharem. Ou seja, eu tenho que deixar elas terem um
pouco de controle, mas eu não posso deixar só elas terem controle,
porque se só as plataformas têm controle, eu acabo ficando de castigo lá
em cima. Então, o tráfego paga uma gangorra entre as plataformas e entre
o operador, o gestor de tráfego, a pessoa que tá ali por trás operando
as ferramentas de anúncios online. Eu gosto de dizer que saber anunciar
em 2026 é sobre o quanto que você deixa a ferramenta ter controle e
quando você toma o controle de volta. Isso daqui que é a grande
habilidade do anunciante moderno, dos do anunciante dos dias de hoje. E
aí você vai falar assim: "Tá OK, tô entendendo conceitualmente bonito
visão da gangorra, mas pouco prático ainda. Como que eu sei quando eu
escolho para quem que eu quero aparecer ou quando a ferramenta deve
escolher por mim?" E aí você tem que entender que existem sete formas de
configurar para quem nós vamos aparecer. E esse daqui, vou até pedir um
segundo aqui para você ligar meu ar condicionado, que eu tomei um café
aqui para dar uma acordada, tá me dando um calor, deu. Agora sim,
existem sete formas da gente escolher para quem a gente vai aparecer. E
a maioria dos anunciantes não domina isso daqui. A maioria que eu digo
assim, se você perguntar para 90% dos anunciantes avançados, como que
você consegue configurar para quem que o seu anúncio vai aparecer ou
para quem que ele não vai aparecer? Como que você configura isso? A
maioria das pessoas vai te dar dessas sete formas de configurar para
quem tiver aparecer duas, talvez três, dificilmente quatro, tá? Se você
quiser, inclusive chutar, achar quais que você acha que são no chat,
pode mandar para mim. No passado eu ensinava quatro, mas aí depois eu
descobri que eram cinco, seis, hoje sete. Quem sabe no futuro eu não
ensine que são oito formas de você configurar para quem você quer
aparecer. Mas a questão aqui é o seguinte, quando eu apresento essas
formas, a maioria das pessoas que já sabem anunciar, elas fala assim:
"Ah, mas isso é óbvio: "Ah, mas eu já sabia disso daí. Eu só não tinha
respondido isso". E você tem que tomar cuidado com isso, porque quando a
gente tá falando de conhecimento, de adquirir conhecimento, uma das
coisas que garante que a gente consiga ter profundidade naquilo que a
gente tá executando, naquilo que a gente tá fazendo, é o nível de
clareza que a gente tem sobre os assuntos. Então, por mais que a aula
aqui seja extremamente simples, talvez até introdutória sobre como
segmentar os seus anúncios, essa provavelmente é uma das aulas mais
importantes. Eu falo que as aulas mais importantes para as pessoas mais
avançadas assistirem são justamente as aulas mais introdutórias. Por
quê? Porque o meu grande exercício aqui como professor é pegar um
conhecimento que ele é complexo, porque o tráfego pago, por mais que
esteja cada vez mais simples, ele é um assunto com uma diversidade
gigantesca de de novas informações que a gente tem que adquirir para que
esse conhecimento seja aplicável e para que ele coloque dinheiro no
nosso bolso. Então, por mais que o tráfego pago ele seja algo mais
simples, o meu trabalho como professor é pegar essas complexidades do
tráfego pago e explicar elas das maneir da maneira mais simples
possível. Isso daqui que eu tô prestes a te explicar aqui é a típica
coisa que eu levo na reunião de vendas com meu cliente, eu explico para
ele e o meu cliente me contrata e deixa de contratar outros gestores de
tráfego pago. Por quê? Eu vou falar. E aí, mais um spoilerzinho aqui de
algo que eu vou te ensinar lá na aula número quatro do desafio da gestão
de tráfego. Uma das melhores maneiras de você mostrar o seu diferencial
numa reunião de vendas não é você falar que você é melhor do que os
outros, mas é você apontar de maneira extremamente elegante, é claro,
onde que as outras pessoas erram. Se eu chego para você e falo assim,
todos os professores de a maioria dos professores de tráfego pago erra
em três grandes aspectos quando vai te ensinar tráfego pago. Primeiro,
eles não te ensinam os fundamentos e a parte teórica, porque eles acham
que o aluno só quer ver a parte prática. Eles têm razão, o aluno só quer
ver a parte prática. Mas se o aluno não domina o fundamento, a parte
teórica que pode ser ensinada em uma, duas horas, qualquer atualização
da ferramenta deixa o aluno perdido. Segundo, os professores valorizam
mais os botões do que entender sobre pessoas. E anunciar online é muito
mais sobre pessoas do que sobre botões. E terceiro, os professores eles
dizem que não é responsabilidade do estudante, do gestor de tráfego
iniciante dominar a habilidade criativa de fazer bons anúncios, por mais
que ele não vai aparecer na frente da câmera. Eu discordo disso. Se você
domina os fundamentos, se você entende sobre pessoas e se você entende o
raciocínio racional por trás de um bom anúncio, você tem tudo que você
precisa para dominar o tráfego pago. E é aqui que a maioria dos
professores de tráfego pago erra. Eu não tenho que eu não tenho o que
dizer para você que eu ensino essas três coisas. Isso fica subentendido
na minha fala. Se eu tô falando que os outros erram, logo eu acerto. No
tráfego pago é igual. Quando eu vou vender o meu peixe pro cliente, um
problema que o cliente sempre vai ter em relação aos leads, as pessoas
que estão chegando ali no WhatsApp dele, que estão se cadastrando, é
qual? Fala para mim no chat. Fala para mim no chat. Deixa eu atualizar a
tela aqui que o meu chat está com delay. Relacionamento com os leads,
fechamento, qualidade do lead. 99% das reuniões que você vai fazer na
sua vida com donos de negócio que já anunciam na internet, vão reclamar
com você sobre a qualidade do lead, ou seja, a qualidade das pessoas que
tá chegando no WhatsApp. Eles vão falar assim: "Olha, tá até chegando
gente aqui no tráfego pago, mas elas não são muito qualificadas. O que
que eu faço quando eu vou entrar na reunião de venda com cliente?" Eu já
chego para ele e falo o seguinte: "Olha, eu imagino que um dos grandes
problemas que você tem no seu tráfego pago é a qualidade dos seus leads.
Só que o que que ninguém na internet vai te contar sobre aparecer para
as pessoas certas que são seus leaders de qualidade?" A maioria dos
gestores de tráfego acha que existem duas maneiras de segmentar os seus
anúncios. É escolher o público certo e mexer na copinha lá no texto do
seu anúncio. Mas na verdade tem sete formas da gente escolher para quem
que a gente vai aparecer. E quando a gente combina essas sete formas, é
que a gente realmente consegue aparecer pro público mais qualificado.
Quais são elas? Agora deixa eu te explicar quais são elas. Então, forma
número um da gente escolher para quem a gente vai aparecer está na
seleção do nosso objetivo. E isso daqui, por mais óbvio que seja depois
que falado, é ignorado por muitas pessoas. Quando a gente tá falando de
objetivos, existem essencialmente seis grandes objetivos: vendas,
cadastros e engajamento. Aqui dentro eu tenho junto com ele o objetivo
de mensagens e visualização de vídeo, reconhecimento, que é o nosso
objetivo para alcançar mais pessoas, aplicativo, que são é o objetivo
que faz as pessoas baixarem, instalarem aplicativos e interagirem com os
aplicativos. e tráfego, que é simplesmente o objetivo de enviar as
pessoas para um link. Dependendo do objetivo que você seleciona, a
ferramenta ela vai direcionar os seus anúncios para grupos de pessoas
que têm mais chance ou menos chance de realizar aquele objetivo. Pensa
no seguinte, pensa em você como usuário de rede social. Tem momentos que
você tá na rede social que, como diz um grande amigo meu, Pedro Calabrz,
que você está na boborreia mental. Que que é a boborreia mental? É
aquele momento que você tem até uma expressão em inglês que é brain rot,
que é tipo o cérebro podre, que é aquela aquele momento que você tá
simplesmente ali navegando em vídeos, memes, videozinhos engraçados.
Você nem vê o tempo passado, daqui a pouco você tá 30 minutos no
celular. Quando você se afasta do celular, você chega a se sentir até
meio tonto, desnorteado. Agora, tem momentos que você tá no celular que
você não tá nesse fluxo de vídeos seguidos. Você tá usando a rede
social, você tá navegando um pouquinho no feed, você tá vendo as coisas
que estão aparecendo, aparece um carrossel para você, você assiste, você
engaja, você interage. A ferramenta, a meta, o YouTube, não importa a
ferramenta, o Google, não importa a ferramenta que a gente tá falando
aqui, mas a ferramenta ela consegue compreender o seu padrão de uso, o
seu modos operand naquele momento que você tá na ferramenta. E de acordo
com o seu padrão de uso, você vai ter mais chances de se cadastrar, de
engajar, de comprar alguma coisa. Então, depende do momento que você tá
na rede social. E o que vai dizer o momento que o seu anúncio vai
aparecer? Porque anunciar a internet é sobre você colocar o anúncio
certo na frente da pessoa certa, no momento certo e enviar a pessoa pro
local certo. Se eu tenho esses quatro pontos aqui, eu dominei o tráfego
pago. Então, para eu anunciar pra pessoa no momento certo, as pessoas
elas são diferentes em diferentes momentos. Às vezes você é, sei lá,
marido da sua esposa e às vezes você é pai dos seus filhos. São momentos
diferentes da sua vida, por mais que seja a mesma pessoa. Eu tenho o
Pedro Sobral, que tá conversando com os amigos. Eu tenho o Pedro Sobral,
que tá dando aula para você. Eu tenho o Pedro Sobral, que tava sentado
no sofá com a esposa agora depois do almoço ali tomando um cafezinho.
São pessoas diferentes, quase que personalidades diferentes dentro de
uma mesma pessoa. Mas aparecer pra pessoa correta também é aparecer para
as pessoas no momento correto e o objetivo certo vai mandar muito nisso.
Segunda maneira que nós temos, segunda forma que nós temos de segmentar,
de configurar a nossa segmentação. Nós podemos configurar a nossa
segmentação de forma automática, tá? Como assim, Pedro? De forma
automática. Dentro das plataformas de anúncio online, nós temos os
chamados na meta recursos Advantage Plus. Dentro do LinkedIn, recursos
Smart, dentro do Google Ads, performance Max. Cada plataforma vai dar um
nome em inglês bonito para tentar dizer que esse recurso ele é muito
bom. Moral da história, toda plataforma hoje em dia tem recursos em que
você é anunciante não precisa escolher exatamente qual que é a sua
segmentação. Você simplesmente diz pra ferramenta: "Faz aí o seu
trabalho, encontra para mim as pessoas, tá aqui o anúncio, tá aqui a
minha isca. Acha as pessoas que vão ser atraídas por essa isca". Quando
nós estamos anunciando de forma automática, com a segmentação
automática, nós temos dois tipos de segmentação automática: sem sugestão
e com sugestão. Como assim sem sugestão e com sugestão? Sem sugestão sou
eu dizendo pra ferramenta: "Se vira, dá os seus pulos, se vira, dá o seu
jeito, vai dar certo, você consegue, eu confio em você". com sugestão. É
quando eu digo pra ferramenta, olha, eu iria por esse caminho aqui. As
pessoas que eu quero atingir, elas moram nessa região X, elas têm essa
idade, elas têm esses interesses, elas fazem essas pesquisas. Então, eu
estou dando sugestões. A ferramenta pode pegar as minhas sugestões e
jogar ela fora e falar assim: "Você não sabe nada, você é burro. ou ela
pode pegar essas sugestões e ter ajuda ali para elas. Inclusive, hoje eu
postei até um vídeo no meu no meu Instagram sobre como que você pode
deixar e essa segmentação automática um pouquinho mais inteligente, tá?
E é basicamente o seguinte, aqui você vai ter que decorar esse caminho,
não tem muito o que fazer, tá? Mas basicamente você vai entrar aqui
dentro do seu gerenciador de anúncios. Você vai acessar aqui esse menu
lateral de todas as ferramentas. Aqui você vai acessar a configuração da
conta de anúncio. Aqui, ó, no menu publicidade. É a primeira opção.
Depois você vai acessar o controle de público alvo, que vai aparecer
aqui, ó, controle da conta. Desculpa, controle da conta, não é de
público alvo. E aqui você vai agora sim acessar o controle de público,
tá? E aqui você pode dizer que a sua empresa anuncia somente em
localizações específicas, países específicos. Eh, você pode excluir
pessoas que estão em outras localizações, você pode escolher a idade
para para aparecer para essas pessoas ou restringir a sua publicidade.
Enfim, você pode explorar isso daqui que é para você aparecer somente
para um grupo de pessoas. Isso daqui seria um controle extra que você
tem dentro da sua conta de anúncios, tá? Para algumas contas de anúncio,
você só vai conseguir fazer o controle de público por país. Para outras,
você consegue fazer por região. Depende. As contas de anúncio, elas
estão sempre sendo atualizadas. A todo momento a ferramenta tá
atualizando, mas pensa o seguinte, eles não atualizam tudo ao mesmo
tempo. Eles atualizam primeiro algumas, eles vêm se tem algum problema,
se tá dando tudo certo, depois atualizam outras, depois outras, depois
outras. Ah, se a minha está desatualizada, o que que eu posso fazer?
Absolutamente nada. Eu passei um ano com a minha conta de anúncio. Um
ano não, foram 8 meses com a minha conta de anúncio com uma interface
antiga, esperando a atualização para poder regravar algumas aulas com
essa versão nova da do gerenciador. Mas era só pela uma questão de
interface mesmo, tá? Mas moral da história, que que você precisa
entender aqui? Primeira forma de escolher para quem eu vou aparecer
através do meu objetivo. Segunda forma é automaticamente eu posso fazer
sem sugestão ou com sugestão dentro das da dos meus testes que eu faço
aqui com sugestão tende a funcionar melhor e a trazer pessoas mais
qualificadas, tá? Então já fica aqui a minha sugestão para você de
testar primeiro com sugestão, principalmente porque a tendência é trazer
pessoas mais qualificadas. Terceira forma, e aqui é como fazer os maias
e os astecas, mas a gente ainda faz desse jeito, que é a escolha manual
do público alvo, também conhecido como opções originais de público. Aqui
eu posso escolher para quem eu vou anunciar. Então eu posso escolher
para quem eu vou anunciar baseado no envolvimento com o meu Instagram,
com o meu Facebook, com o meu YouTube. Então eu posso ir lá e aí assim
essa parte aqui, no passado eu iria entrar nesse detalhinho técnico
aqui, abrir cada menu com você, mas é extremamente intuitivo. Na sua
conta de anúncio, você vai acessar aqui a aba públicos. Aqui você vai
apertar em criar público depois que carregar a página aqui. [música]
Sempre na minha live as coisas demoram um pouquinho mais para carregar.
Quando eu não tô ao vivo, carrega instantaneamente. É um negócio quase
que mágico. Aí, agora sim, aqui dentro você vai criar deu. Aqui dentro
você vai apertar no botão de criar público, público personalizado. E
aqui eu posso criar todos os tipos de público, pessoas que se envolveram
com a minha conta do Instagram. Aí vou apertar em avançar. Aí é só você
ler o que tá escrito, da onde, qual que é a origem do envolvimento. Ah,
é com a conta do do Instagram Pedro Sobral. O que que essas pessoas
fizeram? interagiram, que seguem essa conta profissional, que visitaram
o perfil da minha conta profissional, que interagiram com qualquer
publicação ou anúncio, que enviaram uma mensagem para essa conta
profissional, que salvaram um post ou um anúncio dessa conta
profissional. Então, eu consigo fazer vários tipos de segmentações aqui.
A que você mais vai utilizar são pessoas que interagiram com a sua conta
profissional, que aí conta qualquer tipo de interação aqui, tá? Mas
quando eu escolho o público de forma manual, eu posso escolher pessoas
que já interagiram com as minhas redes sociais. Segundo, eu posso
escolher pessoas que já visitaram o meu site. Então, pessoas que foram
até o meu site. Por exemplo, eu tenho um e-commerce, eu tenho um
e-commerce de mel, tá? É verdade, esse e-commerce é meu, é da minha
família. É, chama abelheiro, tá? Inclusive, se você quiser dar um
presente legal para alguém, você nunca vai provar um mel tão bom na sua
vida. Olha como vem bonitinho, vem na caixinha, vem com pratinho, enfim,
eu tenho e-commerce de mel. Eu consigo anunciar para quem chegou até o
site do Abelheiro, eu consigo chegar para as pessoas que visitaram o
produto. Eu consigo anunciar para as pessoas que eh apertaram no botão
de comprar, que adicionaram o produto no carrinho, que foram até o
checkout, que já compraram, que quase compraram, mas não compraram.
Então eu consigo anunciar para quem já visitou o meu site. Depois eu
consigo anunciar para uma lista de e-mails e telefones. Então vamos
dizer que eu tenho uma lista de pessoas que já comprou no meu
e-commerce. Eu tenho todos os e-mails dessas pessoas. Eu consigo
anunciar para essas pessoas caso eu vá vender, sei lá, um novo produto.
Vamos dizer que amanhã, amanhã eu deixo de vender só mel e vendo também
própolis, vendo também, sei lá, velas de cera de abelha. Aí eu posso
anunciar paraa minha lista de clientes que já confiou em mim, já comprou
o meu produto para eles comprarem de novo de mim. Isso é uma coisa que
pouquíssimos negócios locais fazem, por mais que seja óbvio. Sei lá
quantas vezes você já recebeu anúncios da pizzaria que você sempre pede
pizza. Muito raro. Ah, por quê? Porque não funciona? Não. Esses são os
anúncios que mais funcionam. Inclusive, já eu vou falar sobre isso para
você aqui, sobre quais públicos que você deve focar em anunciar que
normalmente vão gerar mais resultado para você, mas é algo que
pouquíssimas lojas fazem, pouquíssimos negócios fazem, tá? Quinta
maneira da gente segmentar nossa, nossos públicos de maneira manual são
interações com formulários de cadastro. Isso daqui é um pouquinho mais
avançado, tá? Você que tá começando, talvez, pô, tô com uma dúvidazinha
ou outra, foca aqui só em sair com mais conhecimento do que você chegou.
Formulário de cadastro é o seguinte: eu consigo fazer anúncios,
principalmente dentro da meta, no Google também, mas em que a pessoa
clica no meu anúncio e ao invés de abrir um site, ela clica no meu
anúncio e dentro do próprio Instagram, do próprio Facebook, do próprio
Google, abre um formulário onde a pessoa coloca o nome, e-mail, telefone
e qualquer outro dado que eu queira pedir para aquela pessoa. E aí
dentro da própria plataforma, a pessoa já me manda aqueles dados e eu
recebo os dados daquela pessoa sem a pessoa sair do Instagram, sem ela
sair do Facebook, sem ela sair do Google. Formulário de cadastro
funciona e funciona muito nos anúncios. Eu inclusive agora tô rodando
campanhas de formulário de cadastro lá pro desafio da gestão de tráfego,
tá? Então assim, tudo aquilo que eu falo para vocês aqui são coisas que
eu aplico no meu dia a dia, tá? Então, nada do que eu tô falando aqui
para você é um negócio que eu, sei lá, eu li num livro de tráfego pago,
mas eu não tô implementando. Se eu pegar minha conta de anúncio aqui
hoje, com certeza a gente já gastou uma nota aqui só divulgando o
desafio da gestão de tráfego. A gente até pode ver juntos aqui, ó,
quanto que já gastou hoje. Deixa eu pegar aqui, ó. Hoje essas campanhas
começaram a rodar meia-noite do dia de hoje. Deixa eu ver aqui, ó. Ó, só
hoje aqui eu tô na frente. Só hoje gastou R$ 26.000, tá? Ah, isso daí
você pode editar no código, tudo bem, eu atualizo a página para você,
não tem problema, tá? Então, ó, só hoje aqui, ó, R$ 26.000 em campanhas,
em anúncios, para convidar você para participar do desafio da gestão de
tráfego. Então, você vê o quanto que eu quero que você se cadastre. Tá
valendo R$ 26.000 o seu cadastro. Você pode falar assim: "Pô, Pedro,
então me faz o Pix, né? Me manda os 26.000 que eu me cadastro aí, tá
tudo certo". Tá. Então, voltando aqui, interações com o formulário de
cadastro são pessoas que se cadastraram. Pô, eu pulei uma letra aqui,
né? Pulei agora que eu vi. A, B, C, E. O cara não sabe nem o alfabeto e
sabe tráfego pago. É sinal que você vai conseguir também. Então,
interação com formulários são pessoas que interagiram com esses
formulários que aparecem dentro das plataformas. Eu consigo anunciar
para visualizadores de vídeos, então pessoas que já assistiram algum
vídeo meu nas minhas redes sociais, no YouTube, no Instagram, no
Facebook e também para dados demográficos, tá? Que são basicamente as
segmentações de idade, localização, gênero e renda. Essa daqui são umas
das mais importantes, principalmente para negócios que atuam eh de
maneira local, né, que atua numa região específica, tá? Alé, e aí, como
eu mostrei para você, esse tipo de configuração das segmentações, ele é
extremamente simples e intuitivo, tá? Então você vai aqui, ó, dentro das
plataformas, acessar a aba de públicos. E aí você vai ver que a
plataforma ela não fez isso daqui para ser complicado para você. Ela fez
para ser simples, para você saber exatamente onde que você tem que
clicar, qual que é o botão que você tem que ir apertando. E aí tudo que
você fica em dúvida, se você coloca o mouse em cima, ele faz uma
explicação para você. Então eu não vou investir uma hora do meu tempo,
do seu tempo, aqui te explicando como é que você cria cada um deles. Até
mesmo porque lá no desafio da gestão de tráfego, você já vou dar um
spoiler aqui, uma das coisas que você vai receber como PDF é um PDF que
explica essa criação de públicos extremamente no detalhe, tá? Essa parte
mais técnica, operacional vai ser explicada lá, tá? Mas você consegue
fazer de forma intuitiva aqui, sem dúvida nenhuma. Isso aqui, tanto na
meta quanto lá no Google Ads, tá? No Google Ads, só para você saber,
para você encontrar essa aba de públicos, você vai acessar aqui
ferramentas aqui do lado, tá? O meu tá em inglês, mas ferramentas. E aí
você vai entrar em biblioteca compartilhada e aí você vai clicar no
gerenciador de audiências. E aqui você vai criar os seus públicos, tá?
Só apertar no botãozinho azul aqui, ó, de mais. E aqui você vai criar os
seus públicos de quem visitou o seu site, interagiu com o seu YouTube,
lista de e-mails, etc, etc. Tá? Então você vai fazendo esse esse passo a
passo aqui. Então forma número três de você definir, configurar para
quem você vai aparecer na escolha manual. forma número quatro, na
escolha manual de conteúdo. E aqui entra uma distinção que pouca gente
faz, porque eu posso anunciar para as pessoas, presta atenção em mim
aqui, eu posso anunciar para as pessoas baseado nas características
delas e nos comportamentos delas, ou seja, com base nos envolvimentos,
nos sites que ela visitou, nos cadastros que ela fez, nos vídeos que ela
assiste, nos interesses que essa pessoa tem. ou eu posso anunciar paraas
pessoas de forma manual. Eh, aliás, eu posso anunciar paraas pessoas
baseadas no conteúdo que ela está consumindo ou que ela está indo
consumir. Isso daqui, principalmente no Google, tá? Então, se na forma
três de segmentação eu estou dizendo para quem eu quero aparecer, aqui
eu estou dizendo quando eu quero aparecer para essas pessoas,
principalmente para quando, em qual pesquisa que eu quero aparecer pras
pessoas, em quais sites e em quais vídeos, tá? Então isso daqui é uma
segmentação principalmente do Google Ads, tá? Vou até colocar aqui, ó,
Google Ads. Vou colocar aqui em verdinho. Então, dentro do Google Ads,
eu escolho não só para quem eu quero aparecer, mas quando que eu quero
aparecer, que tipo de pesquisa que aquela pessoa tá fazendo, que site
que aquela pessoa tá visitando, que vídeo ou canal do YouTube que a
pessoa está assistindo no momento que o meu anúncio aparece para ela.
Inclusive, saiu um grande estudo da Netflix. Até fiz um vídeo que tá no
meu Instagram sobre isso, inclusive veja mais os meus vídeos do
Instagram. Fiz um vídeo no meu Instagram sobre isso, que uma uma grande
pesquisa da Netflix e da ferramenta de anúncios da Netflix, defendendo
que nos anúncios da Netflix, que não são disponíveis ainda para todo
mundo anunciar, mas que nos anúncios da Netflix você não só escolhe para
quem que você quer aparecer, quantos anos a pessoa tem, onde que aquela
pessoa mora, mas você escolhe o tipo de sentimento que aquela pessoa tá
sentindo quando o seu anúncio aparece para ela. Basicamente eles
defendem que você consegue aparecer pra pessoa, por exemplo, num momento
em que a pessoa tá mais animada, porque ela tá vendo um filme de ação,
um filme inspirador, num momento que a pessoa tá numa vibe mais
estudiosa vendo um documentário, no momento que a pessoa tá mais se
divertindo vendo, sei lá, um dorama. Não sei. [risadas] Mas a questão é
o quando você aparece, ele importa. Eu acredito que cada vez mais, isso
assim é é um achismo, tá? Mas pros próximos anos, uma das grandes
mudanças que a gente vai ver nas ferramentas de anúncio online é a gente
justamente conseguir ter um pouco mais de poder para escolher o tipo de
sentimento que a pessoa que tá no celular está tendo, que tá na
internet, está sentindo quando o nosso anúncio aparece para ela. Ah, de
que forma que isso vai acontecer? Não, não tenho clareza absoluta, mas
acredito que é um dos grandes próximos passos que a gente tem sobre
controle de segmentação. Não só escolher para quem eu vou aparecer, em
que pesquisa, em que site, em que vídeo, mas até mesmo o tipo de
sentimento que aquela pessoa tá dentro da rede social quando meu anúncio
aparece para ela. Beleza? Próximo ponto aqui, viagens à maionese à
parte, forma número cinco de escolher para quem eu vou aparecer. através
do meu pixel, conjunto de dados e API de conversões. Se você pegar aqui
no meu canal do YouTube, tem aula aqui sobre pixel, API de conversões,
eh conjunto de dados e o pixel ele é basicamente um código que é
colocado dentro do nosso site. E esse código, ele vai informar a meta,
vai informar o Google de tudo aquilo que tá acontecendo no meu site.
Ponto. É para isso que serve o Pixel, o conjunto de dados e a API de
conversões. Só que dentro das funções do pixel, do conjunto de dados e
da pões, que é basicamente a mesma coisa, uma das grandes funções deste
recurso é entender quem é o meu público alvo e direcionar os meus
anúncios para essas pessoas. Então, o pixel ele é como se fosse um
cérebro, a inteligência da sua conta de anúncios. E se o pixel ele está
bem treinado, ele consegue direcionar cada vez os seus anúncios para as
pessoas mais corretas. Então, lembra do exemplo do lago e dos da e da do
lago de peixes, né, de pessoas e das iscas? Então, nesse exemplo, o
pixel ele tornaria a nossa a o poder de magnetismo da nossa isca ainda
melhor. Então, é como se eu tenho um pixel mais bem treinado. É como se
o pescador ele soubesse exatamente onde que ele tem que jogar o anzol,
porque naquele lugar vão ter mais peixes. Então, ele é mais inteligente
nessa escolha de para quais pessoas que os meus anúncios vão aparecer.
Forma número seis de você segmentar os seus anúncios é através das
interações passadas com seus anúncios, tá? Então, por exemplo, eh,
algumas pessoas me perguntam: "Ah, Pedro, eu tenho uma marca que divulga
produtos completamente diferentes. O que que são produtos completamente
diferentes? Pô, sei lá, eu vendo suplemento e vendo eletrônicos no meu
site. São coisas diferentes, normalmente pessoas diferentes que vão
comprar esses diferentes produtos. Não é como o Mercado Livre. Mercado
Livre. Se você é dono do Mercado Livre, tá aqui me assistindo, pode me
patrocinar, inclusive. Mas se você [risadas] é dono do Mercado Livre, o
Mercado Livre ele já tem por padrão ser uma loja, um um um local onde
eles vendem todos os tipos de produtos possíveis. Então eles são
conhecidos por isso, pela variedade. Eles vendem variedade. Agora, se
você não vende variedade, mas você vende dois produtos separados, muitas
vezes é melhor você ter estruturas separadas de divulgação. Por quê?
Porque a interação passada com o seu anúncio importa para dizer para
quem o seu anúncio vai ser mostrado no futuro. A meta, o Google, eles
ativamente entendem, eles entendem quais são as pessoas que interagem
com o seu anúncio e ele foca em levar o seu anúncio para mais pessoas
como elas. Então, se eu tenho um perfil de pessoas X que tá clicando no
meu anúncio, cada [aplausos] vez a meta vai pegar mais pessoas que tm
esse mesmo perfil. a meta, o Google vai pegar mais pessoas que tm esse
mesmo perfil e vai direcionar os meus anúncios para elas. E a forma
sete, né, última maneira aqui da gente segmentar os nossos anúncios é
através do nosso anúncio, tá? Então, o que tá sendo escrito, o que tá
falado no seu anúncio, é o maior direcionador de para quem o seu anúncio
vai ser mostrado. Então, se eu tenho um anúncio que eu falo: "Você vai
passar 10 horas assistindo esse curso gratuito para não ter que passar
mais 8 horas por dia aturando seu chefe chato." E eu tenho um outro
anúncio em que eu falo o seguinte: você vai demitir o seu time de
marketing depois que você assistir esse curso gratuito, porque nele eu
vou te ensinar em 10 horas o que que você precisa para gerenciar os seus
próprios os anúncios do seu próprio negócio. Eu gravei dois anúncios
diferentes. Um fala com uma pessoa que vai fazer uma transição de
carreira, que tem um chefe, que quer um novo trabalho. O outro tá
falando para alguém que contrata um time de marketing, alguém que é dono
de um negócio. Só de falar isso nos anúncios, eu estou atraindo públicos
diferentes, eu estou atraindo pessoas diferentes. A meta, o Google, eles
vão colocar essa isca, este anúncio em lagos diferentes. A meta vai
fazer isso por mim. Então, o anúncio, aquilo que tá sendo falado, é o
maior segmentador que existe. Então, lembra quando eu falei para você
que no passado a gente tinha que escolher milimetricamente para quem a
gente ia aparecer. No presente é como se nós tivéssemos uma superisca
que ela meio que tem um íã que atrai as pessoas certas, tá? Então para
para pensar no seu dia a dia. Mais uma vez, o que que tem lá na sua aba
explorar do Instagram hoje e o que que tinha lá há se meses? Então, pô,
na minha aba do Instagram de hoje tem muito daquilo que eu tô consumindo
hoje. Então, pô, eu tava fazendo uma viagem para fazer kite surf. Então,
ó, tá vendo esse videozinho aqui, ó? o cara fazendo kite surf. Tem vídeo
de yoga, tem vídeo de exercício, tem vídeo de música, tem vídeo de
câmera, porque eu tô na vibe de fotografia. Então, se eu sigo rodando
aqui, ó, no meu na minha aba explorar, é isso daqui que vai aparecer
para mim. Câmera, música, mais kite surf aqui em cima. Então, o que que
tá aparecendo hoje para mim? Tá aparecendo isso daqui. Você acha que
aparece anúncio do que para mim? No meu Instagram aparece anúncio de
Kite Surf. Hoje eu caí num anúncio de Kite Surf e eu fiquei navegando
ali num carrocel no anúncio de equipamento de kite surf. Mas se eu
começar a pesquisar agora nesse instante, se eu começar a curtir vídeo
sobre moto, vai começar só a aparecer vídeo de moto para mim. Você já
reparou que às vezes você começa a ver um tipo de meme, algum amigo seu
manda um vídeo para você, um humor mais duvidoso, um humor mais bobo, um
humor mais negro e aí ele manda aquele meme para você, manda aquele
vídeo para você, você segue rolando o feed depois daquele vídeo e tudo
que aparece são mais coisas parecidas com aquilo. Tem um comentário que
é muito bom que aparece em alguns vídeos, que é: "Eu construí este
algoritmo tijolo por tijolo". Então a pessoa constrói o que que tá
aparecendo para ela dentro do Instagram. Eu acho muito engraçado quando
as pessoas falam assim: "Ah, mas no Instagram só aparece besteira para
mim". Eu falo: "Porra, você só consome besteira". Então você só tá vendo
conteúdo merda. Só aparece conteúdo merda para você. Você consegue
inclusive no seu Instagram resetar o seu algoritmo. Não sei se você
sabe, mas lá no seu Instagram, não sei exatamente onde que é agora, mas
basicamente você vai vir aqui nessas eh nesses três pontinhos aqui de
cima. Então, aqui nesses três pontinhos, nas suas configurações de
atividade, aqui em algum desses menus aqui, você consegue eh resetar a
maneira que você usa aqui os seus o seu algoritmo para fazer ele voltar
a ser diferente. Mas se você começar a interagir com conteúdos
diferentes, automaticamente vão começar a aparecer conteúdos diferentes
para você. Se os meus conteúdos não estão aparecendo tanto para você,
vai lá no meu perfil, curte quatro, cinco vídeos, me manda uma mensagem,
compartilha alguma coisa comigo, curte dois, três stories, você vai ver
que os conteúdos eles começam a aparecer. Muitas vezes eu faço isso
intencionalmente, tá, Pedro? Beleza, eu entendi. Existem seis formas,
sete formas, desculpa, de escolher para quem que meu anúncio vai
aparecer. Mas na prática, como é que eu vou segmentar os meus anúncios?
Eu entendi as formas, mas como é que eu faço isso acontecer de verdade
dentro da ferramenta, dentro do gerenciador? Para isso, a gente vai
seguir cinco passos, tá? Então, são cinco passos para você garantir que
você vai segmentar os seus anúncios da maneira correta. Passo número um,
entenda como criar um anúncio nas plataformas de anúncios online. Por
quê? Porque quando você entende como é que você cria um anúncio nas
plataformas de anúncio online, você vai sacar o seguinte, que dentro das
plataformas de anúncio online, eu sempre que eu vou fazer um anúncio
aparecer para as pessoas, eu vou criar uma o que a que a plataforma
chama de campanha. Dentro dessa campanha que eu tô representando aqui
com essa caixinha, eu vou ter os meus grupos de anúncio que eu estou
representando aqui com estas carteiras. Então, dentro da minha campanha,
eu vou ter aqui os meus grupos de anúncio. Os meus grupos de anúncio são
as estruturas onde eu vou colocar as minhas segmentações. E dentro dos
meus grupos de anúncio, que mais uma vez estão dentro de uma campanha,
eu vou ter representado aqui por esses cartões os meus anúncios,
diferentes anúncios, tá? Então, entendendo essa estrutura de campanha,
grupo de anúncio e anúncio, a gente sabe que os nossos anúncios vão ser
colocados dentro dos nossos grupos de anúncio. Pedro, ainda tá meio
nebuloso para mim e vai ficar nebuloso até que você assista um conteúdo
onde a gente fala especificamente sobre a criação de campanhas, tá? onde
você vai entender, por exemplo, ó, deixa eu pegar um exemplo aqui, deixa
eu pegar um que vai ser um bom exemplo aqui. Aqui, ó, eu tenho aqui uma
campanha, tá? Então, essa daqui é uma campanha onde eu estou captando
pessoas para o meu evento, para o desafio, né, para o nosso curso
gratuito, tá? Então essa campanha aqui, ela já gastou R$ 2.600. Eu estou
de R$ 5.000 que ela vai gastar hoje, eu tô pagando R$ 6 por cada um dos
meus cadastros aqui nessa campanha, tá? Então isso é uma campanha.
Dentro desta campanha, deixa eu abrir aqui os conjuntos de anúncio. Eu
tenho os meus conjuntos de anúncio, que são os públicos para os quais eu
estou anunciando. Eu posso ter mais de um público dentro de cada
conjunto de anúncio ou um só. dentro dos conjuntos de anúncio, eu vou
ter o quê? Vou abrir aqui na próxima aba, ó. Eu vou ter os meus
anúncios. Então, aqui dentro eu tenho diversos anúncios para os quais eu
estou anunciando. Essa é uma estrutura de campanha. Campanha, conjunto
de anúncio e anúncio. Você precisa entender isso. Onde que você vai ter
o entendimento muito mais intensivo sobre isso? Claro, o desafio da
gestão de tráfego, que é esse curso gratuito que eu tô falando a aula
inteira para vocês de 10 horas de duração. Como que você se cadastra?
Clicando no link que tá na descrição e garantindo o seu lugar. Simples
assim. Então, clica e se cadastra. Passo número dois, você vai focar
sempre em anunciar de maneira controlada e constante para públicos super
quentes e públicos quentes. O que que são públicos super quentes e
públicos quentes? Cada pessoa vai chamar isso daqui de um jeito, mas
esse daqui é o famoso remarketing, é anunciar para quem já teve contato
com a sua marca. Públicos super quentes são pessoas. E mais uma vez lá
no desafio da gestão de tráfego, a gente aprofunda nisso daqui. Públicos
super quentes são pessoas que já tiveram alguma intenção de compra com o
seu produto, com você. Então, uma lista de cliente, pessoa que mandou
mensagem, mas não comprou, que iniciou a compra, adicionou o produto no
carrinho, se cadastrou no seu site, visitou o seu site, mas não comprou,
pesquisou, está pesquisando pelo nome da sua marca, se envolveu ou
visitou ali os seus perfis, seu site nos últimos s dias. Esses daqui são
os públicos que normalmente você vai anunciar para eles e eles vão
comprar de você. Depois nós temos os públicos quentes, que é a segunda
categoria, que são as pessoas que já conhecem a sua marca. Então,
pessoas que se envolveram ou visitaram seu site de um até 540 dias,
públicos de localização geográfica, listas de clientes mais antigas que
faz tempo que não compram de você, pesquisas relacionadas ao seu
produto, serviço, curso ou vídeos relacionados ao seu produto, serviço
ou curso. São pessoas que estão com muito interesse ou já demonstraram
interesse naquilo que você vende, naquilo que você divulga, naquilo que
você faz, mas que recentemente não deram sinais de que olha, tô a fim de
comprar de você aqui alguma coisa. E aí por último e não menos
importante, nós temos os públicos frios, tá? que são pessoas que nunca
viram você, que não tiveram contato com você, que são os públicos
semelhantes, direcionamento detalhado, público alvo de mercado, público
de afinidade, baseados em aplicativos e sites e que fizeram pesquisas
sobre o que você vende, mas não especificamente sobre o produto, serviço
que você vende, nem sobre a sua marca. Pedro, é um monte de informação,
é um monte de nome. O que que é o direcionamento detalhado? O que que é
o público alvo de mercado? Que que é o público de afinidade? Tudo isso
daqui eu ensino para você nas aulas que eu dou especificamente sobre as
ferramentas. Então, tem aulas que eu falo de públicos no Google Ads. Lá
eu vou falar de todas as opções de públicos no Google Ads. Públicos no
Metaads, eu falo especificamente das segmentações do Meta. Essas são
aulas mais eh mão na massa dos anúncios online. Você mais uma vez vai
ter todo esse conhecimento lá no desafio da gestão de tráfego. É só se
cadastrar, tá? Mas focando aqui no passo dois, foca sempre em anunciar
de maneira controlada e constante para públicos super quentes e quentes.
Você sempre tem que estar anunciando para esses dois carinhas aqui,
porque eles são os que mais vão gerar resultado para você. Passo número
três, tenha sempre uma campanha de teste anunciando pros públicos
automatizados, né, segmentações automáticas, que é o Advantage Plus na
meta, Pemex no Google. Sempre tenha uma campanha testando anunciar de
maneira automatizada. Por quê? Porque isso funciona. Eles funcionam
muito bem. Tem muitos gestores de tráfego que vão falar: "Olha, eu
coloco a maior parte do meu dinheiro em campanhas automatizadas, porque
é lá que eu tenho mais resultados". Eu colocaria todo o meu dinheiro
nesse tipo de campanha? Não. Por quê? Porque sempre vale a pena você ter
dinheiro de maneira controlada e constante em públicos super quentes e
públicos quentes. Cuidado que você tem que tomar aqui nesse passo número
três. Se a sua campanha não for de venda, não for de venda, verifica a
qualidade das pessoas que estão chegando desse público automatizado,
porque pode ser que a qualidade não seja tão boa, mas lembra, insira
sugestões de público para buscar, tentar aumentar a qualidade do
público, tá? Então, lembra que o público automatizado, eu posso fazer
ele com sugestão ou sem sugestão. Minha sugestão é que você insira
sugestões para testar. Passo número quatro. Em paralelo a você estar
anunciando para público super quente, tá anunciando para público quente,
vai testando públicos frios e vendo se eles funcionam para você. Passo
número cinco, organize os seus públicos em campanhas que vão variar de
quatro a oito conjuntos de anúncio, tá? Então, busca não ter mais do que
isso numa campanha. Então, eu tenho uma campanha, lembra aqui que a
campanha é essa caixinha. Dentro dessa campanha eu vou ter os meus
conjuntos de anúncio. Cada conjunto de anúncio é um público ou um
conjunto de vários públicos. Busca ter então de quatro até oito
conjuntos de públicos dentro dessa campanha, tá? Então separa bonitinho.
Não muito mais do que isso. Menos pode funcionar. Pode funcionar. Eu
tenho campanha com dois, às vezes um conjunto de anúncio, mas de quatro
a oito é uma recomendação que funciona bem para você. Dicas e resumo
final aqui dos públicos. Vamos lá. Essa parte tá é o onde a gente fecha
todos os pontos. Primeiro, seu anúncio, pixel e objetivo de campanha
desempenha um papel fundamental na segmentação da sua campanha. Sempre
tenha isso em mente. Segundo que eu acabei de falar para você, busca ter
campanhas com quatro, oito conjuntos de anúncio por campanha. Terceiro,
sempre anuncia pros públicos dos passos anteriores ao seu objetivo.
Pedro, o que que é o passo anterior ao meu objetivo? Vamos, vamos pegar
o meu exemplo aqui. Você tá assistindo essa aula e o meu objetivo é que
você venha nesta página aqui que tá na descrição e que você se cadastre
no desafio da gestão de tráfego. Se você chegou nessa página, fechou a
página e não se cadastrou, esse é o passo anterior ao meu objetivo, que
é você chegar na página. Se eu tô pegando meu e-commerce, qual que é o
passo anterior ao meu objetivo? O meu objetivo é que a pessoa compre o
passo anterior, é a pessoa adicionar o produto no carrinho. Então eu
sempre vou anunciar pro passo anterior ao meu objetivo. Sempre. Próximo
ponto, para tentar qualificar os seus públicos, deixa eles menores. E
para tentar escalar os seus públicos, deixa eles maiores. Que que eu
quero dizer com isso? Se eu tô anunciando para as pessoas que se
envolvem envolvimento com o meu perfil do Instagram nos últimos 180 dias
e eu não tô com um público muito qualificado. O que que eu posso fazer?
Eu posso anunciar paraas pessoas que se envolveram com o meu perfil do
Instagram nos últimos 30 dias, ou seja, eu vou deixar esse público
menor. Ao invés de pegar todo mundo que se envolveu aí nos últimos seis
meses, eu vou pegar quem se envolveu só no último mês. Eu vou deixar ele
menor para deixar o público mais qualificado. Agora, se eu tô anunciando
para quem se envolveu com o meu perfil no Instagram nos últimos s dias,
na última semana, e eu tô precisando escalar, ou seja, colocar mais
dinheiro, o que que eu posso fazer? Eu posso deixar esse público maior,
eu posso aumentar ele para 14 dias, eu posso aumentar ele para 30 dias,
para 60 dias, 90 dias, até 365 dias, tá? Quanto maior o público, a
tendência é que ele seja menos qualificado, mas ele também vai ser um
público onde eu vou conseguir gastar mais dinheiro, porque ele vai ser
maior, né? Se eu quero escalar, eu preciso de mais gente no meu lago e
de peixes, no meu lago de pessoas. Próximo ponto, públicos quentes
tendem a semelhar. Eu vou até eu vou coloquei a nomenclatura diferente
aqui, peço desculpas. Públicos super quentes tendem a ser melhor do que
públicos quentes e públicos frios, tá? Então, foca nos públicos super
quentes primeiro. Ah, eu não tenho público super quente porque eu tô
começando a anunciar agora. Tá tudo bem. Aos poucos eles vão ser
formados ali na sua base e aí você vai anunciando para esses públicos
super quentes, mas a tendência é que eles sempre performem muito melhor.
Outro ponto, evita gastar dinheiro em grupos de anúncio que a meta e o
Google não tá gastando. Então, às vezes, eu até posso tentar achar um
exemplo real aqui, mas às vezes na sua campanha, ó, a meta não vai est
colocando dinheiro em algum dos públicos aqui, como é o caso aqui, tá?
Ela não tá gastando dinheiro nesse primeiro público aqui, nesse primeiro
conjunto de anúncio. Tá vendo que ela gastou zero? Tem gente que vai
tentar forçar o gasto aqui. Se você tentar forçar o gasto onde a meta, o
Google não tá colocando dinheiro, na maioria das vezes vai dar ruim. Se
um público ele é muito grande e ele se um público muito grande não
funcionar, tenta segmentar um pedaço mais qualificado dele. Que que eu
quero dizer com isso? Eu tenho, por exemplo, uma lista de mais de 1
milhão de cadastrados nas minhas aulas ao vivo. Eu posso anunciar para
esse público aqui de 1 milhão de cadastrado nas minhas aulas ao vivo.
Ele não tá funcionando. O que que eu posso fazer? Eu posso pegar o meu
público é da lista de, sei lá, de 50.000 1000 pessoas que abrem os meus
e-mails que eu envio. Então, dessas 1 milhão de pessoas, 50.000 abrem os
meus e-mails. Eu tô pegando um segmento mais qualificado de um público
maior. Ah, eu tô anunciando para uma lista de clientes que é muito
grande. Eu posso anunciar para uma lista de clientes que gastou mais de
R$ 500 no meu site. E aí aqui eu tenho uma lista 10 vezes menor, mas é
um segmento mais qualificado daquele público mais amplo para o qual eu
tô anunciando para negócio local. sempre testa anunciar somente para
localização de atuação, tá? Então, sem ficar enfiando um monte de
segmentação, só anuncia ali na região que você atua, na região que você
vende, e deixa o seu anúncio encontrar as pessoas corretas. Deixa a meta
trabalhar para você. Quando a gente tá falando de anunciar para
públicos, não viaja na maionese, foca nos públicos óbvios. E se um
público óbvio não funcionar, o problema tá em outro lugar e não público,
tá? Raramente você não tá vendendo, você não tá tendo resultado, o seu
tráfego tá ruim porque você errou na segmentação. Raramente você tem que
seguir algo muito distante daquilo que eu mostrei aqui nessa aula para
você, para isso dar errado. Normalmente, se não tá vendendo, se não tá
dando resultado, o problema ou tá no seu anúncio, ou então o problema tá
no destino final, para onde você tá enviando a pessoa depois que ela
clica no seu anúncio. Cuidado com públicos grandes demais, tá? Se eu
tenho um público grande demais, ele pode roubar todo o orçamento da
minha campanha. Então, se eu tenho aqui na minha campanha um público um,
que ele é gigante, e aí eu tenho aqui um público dois, público três,
público quatro. E aí, esse público um é grandão, ele tem muita gente
nele, ele é um lago muito grande e os outros públicos são muito
pequenininhos. Pode ser que todo o dinheiro seja gasto aqui e aqui não
gaste nada, tá? aqui vai gastar R$ 0, R$ 0, R$ 0, R$ 0. Então, cuidado
com públicos grandes demais numa campanha e sempre teste segmentações
automáticas em paralelo à segmentações controladas, as segmentações que
eu estou escolhendo onde eu quero anunciar. Uma boa estratégia de
segmentação não é uma estratégia só de automático, só de campanha
controlada, não é você testar e ter um mix dos dois. Tá bom? Essa foi a
nossa live número 367. Falei para você que duraria uma hora aqui. Eu
tava bom na minha na minha previsão aqui. Se você quiser ter acesso a
esse material dessa aula aqui, tudo aquilo que eu escrevi, salvar esse
material para você com todas essas informações, o que que você vai
fazer? Seguinte, você vai lá no meu perfil do Instagram Pedro Sobral e
você vai me enviar uma mensagem, não é para comentar na minha
publicação. Você vai me mandar uma mensagem escrito o quê? Você vai me
mandar uma mensagem escrito live 367, tá? Exatamente como está aqui.
Você não vai escrever por extenso, você só vai me mandar live 367. É
isso daqui que você vai me mandar lá. Não é para me mandar aula, não é
para me mandar, sei lá, outro número aleatório, não. Live 367. Eu mando
para você o material desta aula aqui. Mas claro, para você receber o
material, você tem que estar cadastrado lá no desafio da gestão de
tráfego. O link para você se cadastrar no desafio está aqui na
descrição. Clica no link, tá na descrição, se cadastra no desafio da
gestão de tráfego. Eu garanto que você não vai se arrepender de jeito
nenhum. E na descrição do vídeo aqui, nós também temos a lista de
presença da nossa live. O que que é a lista de presença? É o seguinte,
uma vez por mês a gente faz um sorteio, mais ou menos uma vez por mês a
gente faz um sorteio aqui, um, dois sorteios. E quanto mais aulas você
assiste aqui nas terças-feiras, putz, eu não tô conseguindo dar zoom
aqui, não vai dar certo, mas quanto mais aulas você assiste, melhores
são os prêmios que você ganha. Então você pode ganhar desde uma caneca
até um computador, dependendo do número de aulas que você assistiu. Para
você marcar sua presença, é só colocar o seu nome, um e-mail, seu
WhatsApp e escolher a palavra-chave da aula. E a palavra chave da aula
de hoje é isca de peixe, tá? bem bem específico aqui com com o que a
gente tá falando. Então é só selecionar a palavra-chave aqui isca de
peixe e confirmar a sua presença para participar do dos nossos sorteios
de uma vez por mês aqui nas nossas aulas de terça-feira, beleza? Próxima
terça-feira, 3 horas da tarde, temos mais uma aula ao vivo. Aguarde
ansiosamente por essa aula. Espero você aqui. Coloca o seu celular para
despertar aí já para despertar toda terça-feira, 10 pras 3, 3 da tarde
você tem um compromisso marcado aqui comigo com os melhores conteúdos de
tráfego pago dessa internet. Foi um prazer ter você aqui. Não esquece de
me mandar lá no meu Instagram, Live 367, para garantir o material dessa
aula. Vou mandar ele para você lá no seu Instagram e se cadastre no
desafio da gestão de tráfego, fechou? Estamos junto. Até a próxima
terça-feira. Valeu, é nós. Fui.

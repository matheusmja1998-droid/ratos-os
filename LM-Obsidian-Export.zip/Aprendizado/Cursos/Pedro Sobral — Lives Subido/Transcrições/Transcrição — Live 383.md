---
tipo: transcrição
autor: Pedro Sobral
live: 383
tema: IA + Gestão de Tráfego
tags: [transcrição, sobral, ia, tráfego-pago]
---

# Transcrição — Live #383

> O futuro do trabalho no digital com IA: 60 minutos que podem mudar sua carreira

Resumo e aplicação: [[Live 383 — Futuro do trabalho no digital com IA]]

---

Até minha câmera também não tá mais reta desse mundo. Você está ao vivo. Bem-vindos, bem-vindos à nossa live número 383, senhoras e senhores. 38. Esse número tá bonito, né? 383. O cara tá me dando um nervoso esse abajú aqui. Acho que ele vai ficar torto mesmo. Você vai ficar nervoso comigo a live. Depois eu arrumo, tá? Mas, pô, 383 semanas, todas as terças-feiras, 3 horas da tarde, fazendo aulas ao vivo sobre tráfego pago, gestão de tráfego pago, anúncios online e principalmente como que você vai colocar dinheiro no seu bolso através das habilidades que nós ensinamos aqui. Eu tô meio saudosista hoje olhando para esse número 383, porque, pô, 383 semanas é semana demais. Faz muito tempo que a gente tá fazendo aulas ao vivo e a gente passa aqui, né, pelos mais diversos temas de aulas ao vivo e hoje falaremos sobre um dos temas mais desejados pela audiência aqui, um dos temas que a galera mais pede para eu falar. Pedro, fala sobre inteligência artificial. Qual que é o futuro da gestão de tráfego pago com a inteligência artificial? O que que eu tenho que ficar de olho? O que que é hype? o que que é de verdade, com o que que eu deveria me preocupar, onde que eu deveria estar colocando meu tempo para melhorar, para me manter vivo dentro desse mercado. Pois bem, hoje na nossa live número 383, a gente vai falar exatamente sobre isso. Falaremos então sobre o futuro do trabalho no digital com a inteligência artificial. Vão ser 60 minutos aqui e eu garanto para você que esses 60 minutos eles vão transformar a maneira que você vê a inteligência artificial e vão dar um pouco mais de clareza, um pouco talvez apaziguar um pouco os corações de algumas pessoas aqui sobre o que que você, onde que você deveria estar olhando, para onde que você deveria estar vendo o movimento do mercado. E sim, se você tá me assistindo aqui pela primeira vez, nós estamos a 383 terças-feiras, todas as terças 3 horas da tarde, fazendo aulas ao vivo sobre tráfego pago e anúncios online.

Pedro, eu entrei lá no seu canal do YouTube e eu não consegui encontrar lá as 383 lives que você falou, tá? Entrei aqui no seu canal, inclusive vi que você tem dois canais. Pois é, eu tenho dois canais. Eu tenho o canal subido, que é onde você está agora, que é o canal que nós fazemos os nossos conteúdos aqui, as nossas lives de toda terça-feira 3 horas da tarde. Temos também o canal Pedro Sobral, tá? Canal Subido é um canal sobre tráfego pago, gestão de tráfego pago e lives. Canal Pedro Sobral é um canal sobre a minha vida. Então você vai encontrar vlogs, você vai encontrar outros conteúdos meu que vai meus que valem a pena também, valem a pena também serem assistidos. Mas se você entrar aqui no canal subido, como eu tava dizendo para você, se você vier aqui na aba ao vivo, você não vai encontrar aqui 383 lives, mas verdade seja dita, você vai encontrar aqui mais ou menos umas 20 horas de conteúdo, que é bastante conteúdo. E esse conteúdo, eu diria que é o conteúdo necessário para você começar a ganhar dinheiro com anúncios online. Seja você alguém que vai cuidar dos anúncios do seu próprio negócio, seja alguém que vai cuidar dos anúncios online de para outras empresas e vai ser pago, vai ser muito bem pago por isso. Mas você pode assistir que essas 20, 25 horas de conteúdo, elas estão completamente bagunçadas, eu diria. Você vai ter aulas que não estão numa determinada ordem, elas não têm início, meio e fim. A live número 383, ela não é o complemento da 382, não. Os conteúdos eles são mais bagunçados. Só que se você quiser o conteúdo mais eficiente possível para você ganhar dinheiro com os anúncios online, mesmo que você não saiba nada sobre isso, aí o que que você tem que fazer? Você tem que se cadastrar no link que tá aqui na descrição desse vídeo, tá? Que é o link para você participar da nova gestão de tráfego.

[... promoção do evento Nova Gestão de Tráfego — 5 aulas de 2h, dia 18 ...]

E hoje a gente vai falar sobre um conteúdo específico aqui que eu tenho grande gosto de falar, que é falar sobre inteligência artificial. Eu sou uma pessoa que hoje eu até tava dando uma entrevista eh para uma pro Estadão. Estadão, Estadão, tava dando uma entrevista pro Estadão e aí eles me fizeram uma pergunta sobre inteligência artificial, né? Quais você usava muito inteligência artificial? Aí eu falei assim que eu era um certo tarado pelas inteligências artificiais. Eu tô sempre usando. Mas aí a pessoa me pergunta: "Ah, qual que você acha que é a melhor, o melhor uso da inteligência artificial? O que que é a melhor coisa que alguém pode fazer com a inteligência artificial? E aí a minha resposta pra pessoa, não foi muito bem o que ela esperava, mas é a mesma resposta que eu dou para você. **O melhor uso da IA é você saber quando que você usa inteligência artificial e quando você não usa inteligência artificial.** O problema é que as pessoas é é aquilo, né? Para quem só tem, para quem só tem martelo, tudo é prego.

---

## VERDADE 1 — O tráfego pago vai se tornar mais acessível

A verdade número um que assusta muitas pessoas é que o tráfego pago ele vai se tornar mais acessível para as empresas. E isso normalmente é interpretado pelas pessoas como algo negativo. O cara fala assim: "Pô, antes eu sabia fazer tráfego pago, o dono da barbearia não sabia fazer tráfego pago, agora ferrou. Perdi meu trabalho porque o dono da barbearia sabe fazer tráfego pago e ele não vai me contratar mais."

Só que se eu te falar que a tendência ela é justamente o contrário, se eu te falar que na verdade isso normalmente quando algo se torna mais barato e mais acessível, isso normalmente tem a a o poder, né, a tendência a potencializar a demanda pelos profissionais na área. E aí eu não vou falar isso daqui com para você com base em vozes da minha cabeça, né, porque eu sou muito envasado para falar isso. Vou falar para você sobre isso de acordo com o paradoxo que é conhecido como **paradoxo de Jevons**.

Pedro, o que que é o paradoxo de Jevons? Tem um cara que se chama James Bessen, ele é um professor da Universidade de Boston e ele fez basicamente toda a pesquisa dele sobre o paradoxo de Jevons. A ideia do paradoxo de Jevons, ela é extremamente simples. Ele diz que **quando uma tecnologia fica mais barata, quando uma tecnologia fica mais acessível e isso torna uma habilidade mais acessível, mais barata para as pessoas, o mercado de quem domina essa habilidade quase sempre se expande e não se encolhe**.

Vou dar um exemplo fácil de você entender. Câmera digital. Desde 2010, todo mundo tem uma câmera no bolso. A sua avó, a sua mãe, a sua tia, você tem uma câmera profissional no seu bolso. Isso na teoria para acabar com o fotógrafo, porque a gente tornou a habilidade de tirar fotografias muito mais fácil e acessível para as pessoas. Mas o que que aconteceu? Aconteceu o contrário. Isso não acabou com o fotógrafo. O mercado da imagem ele explodiu. Ah, mas tem pessoas que vão deixar de contratar porque agora a tecnologia ela é mais acessível. Sim, mas para cada pessoa que deixa de contratar, porque a tecnologia é mais acessível, tem novas pessoas que estão aderindo à tecnologia e delegando esse serviço para outras pessoas. Gosto muito de uma frase que fala que imagina se todos os donos de restaurante fechassem seus negócios porque as pessoas têm fogão em casa. Uma coisa não elimina a outra. A acessibilidade ela expande o mercado, ela deixa mais fácil e isso faz com que o mercado se expanda no final das contas.

---

## VERDADE 2 — A oportunidade da mineração de contexto

Verdade número dois que nós temos que entender com a gestão de tráfego. E talvez essa daqui seja a mais importante. Verdade número dois, **a oportunidade da mineração do contexto**. Acredito que a gente tem duas grandes oportunidades de ganhar dinheiro com a inteligência artificial. Para isso, a gente tem que entender o contexto de que a internet ela vai ser uma terra de anúncios e páginas genéricos.

Então, hoje em dia, quem aqui, por favor, manda um eu no chat, por favor, se você já percebe que um texto foi feito com IA, tipo assim, pô, eu percebo, eu bato o olho num texto e eu sei que aquele texto foi feito com IA. Agora, se você vê uma imagem e você sabe que as imagens são feitas com IA. A maioria das pessoas já consegue perceber. E é muito fácil para quem produz conteúdo na internet cair na armadilha de usar IA de modo desenfreado.

Vou dar dois exemplos para você. Exemplo número um. Hoje um amigo meu me mandou uma mensagem já tem alguns dias, mas eu consegui parar para responder hoje. Um amigo meu do mercado digital, super conhecido, falou para mim: "Cara, tô querendo começar a fazer aulas semanais. Que que você me dá de dica?" Aí eu falei para ele, vou te dar a melhor dica de todas. **Sempre que for planejar uma aula, preenche a aula a partir de uma página em branco. Não usa inteligência artificial para te dar ideias. Não usa uma aula antiga para te dar ideias, não. Planeja do zero.** Faz o exercício de pensar do zero naquele conteúdo.

Porque hoje em dia tudo a gente faz com IA. Outro dia tava com um amigo meu, ele tá solteiro e aí ele tava discutindo com a menina lá no WhatsApp. E aí ele pegou e abriu o chat GPT mandando as mensagens da menina e perguntando o que responder. Eu falei: "cara, a gente perdeu, a gente se perdeu como humanidade num determinado ponto, porque é muito mais fácil você usar IA para pensar para você".

Outro dia eu tava indo viajar para Barcelona, Cany e Paris. Voltando aqui e aí eu ia viajar no domingo. No dia que eu ia viajar, eu tinha que gravar duas lives em espanhol. Então eu tinha que fazer a gravação de duas lives em espanhol, 1 hora e meia cada uma. E eu tinha que gravar uns 20, 30 anúncios e eu tinha que gravar seis vídeos pro meu canal do YouTube. Seis vídeos. Caos na terra. Eu tinha conseguido planejar cinco, só que eu tinha que entregar seis pro meu time. Aí o que que eu fiz? Cheguei no último vídeo e falei: "Ferrou, tô cansado". Vou pegar o Cloud, vou pegar o roteiro de uma live que eu já fiz. Então eu peguei uma live minha, copiei este roteiro, mandei pro cloud, fiz um promptizão com vários exemplos de vídeos meus do YouTube. E aí ele foi lá e gerou. O conteúdo do roteiro estava com a minha cara, porque fui eu que fiz a partir da live. Mas era o último vídeo, eu tava moído, gravei o vídeo, mandei pro time, publicamos o vídeo. E aí foi muito engraçado porque tinha uns quatro comentários no vídeo de gente falando assim: "Cara, é impressionante como que esse vídeo tá soando como inteligência artificial". Eu tirei o vídeo do ar inclusive depois porque eu prezo muito pela qualidade do conteúdo e regravei o vídeo.

E aí, existem maneiras inteligentes de você usar inteligência artificial. Eu, por exemplo, vou te dar um exemplo de como que eu faço para fazer um roteiro de vídeo de YouTube que não se parece com IA, mas com IA. Eu vou pegar o tema do vídeo. Eu vou gravar um vídeo agora essa semana sobre como parar de acumular e começar a executar o que você aprende nos cursos. Quando eu for fazer esse vídeo, **eu vou pegar o meu celular, eu vou dar play no áudio e eu vou sair caminhando pela minha casa, falando em voz alta sobre aquele tema**. Eu vou fazer um download mental, uma bagunça de pensamentos meio assim, totalmente bagunçado, quase que sem início, meio e fim, um caos de pensamentos. E eu vou pegar aquele caos de pensamentos e vou gravar aquele baita áudio assim de 15, 20, 25 minutos. Como se eu tivesse conversando com um amigo.

Depois que eu tenho 20 minutos de download mental sobre o assunto, aí eu uso a IA só para me ajudar a organizar os pensamentos, mas sem deixar ela inserir os termos dela, maneira dela de construir os pensamentos. A construção tem que ser minha, mesmo que caótica, porque nós, seres humanos, nós somos meio caóticos.

Existe um conceito que se chama **banner blindness**. A cegueira dos banners. Nós estamos tão acostumados, o nosso olho, nosso cérebro tá tão acostumado a ver anúncios que você entra num site e naturalmente o seu olho é treinado para ignorar tudo aquilo que é anúncio. Pois é, eu estou dizendo aqui que nós vamos viver uma era da **AI Blindness**. A cegueira da inteligência artificial, onde cada vez mais nós vamos ignorar tudo aquilo que se parece com inteligência artificial e nós vamos desejar conteúdos reais e autênticos. Tem uma palavra em inglês que é **craving**. É uma necessidade, não é um desejo. Nós vamos ter essa necessidade de conteúdos reais.

E aqui que mora a oportunidade. Tem uma única palavra que faz com que a inteligência artificial funcione do jeito certo e não seja genérica: **CONTEXTO**.

O que que é contexto? Contexto são as informações que eu dou paraa inteligência artificial antes de pedir alguma coisa para ela. A diferença entre quem faz um bom trabalho com IA e quem faz um trabalho porco mal feito e que vai ser ignorado é **a coleta e a organização de contexto do negócio**.

A IA é absolutamente genérica sem contexto. E aí você precisa ter processos para coletar o contexto:
- Processo para coletar contexto com base no conteúdo do cliente
- Processo com base no posicionamento do cliente
- Processo com base nas reuniões com o cliente
- Processo com base nas pesquisas do cliente

Processo é um passo a passo que é sempre executado. Por exemplo, todas as noites quando eu vou dormir, eu tenho o mesmo processo: tomo banho escovando os dentes, deito, tomo suplementos, pingo 4 gotas de melatonina na língua, leio uma página e meia no Kindle e apago. Faça chuva, faça sol.

E quando você vai atender uma empresa, você tem que ter processos para coletar o contexto. Imagina que você tenha acesso a um sisteminha onde para cada cliente você vai documentar: Instagram, site, Google Meu Negócio, endereço, grupo do WhatsApp, pasta do Drive, descrição, valores, diferenciais, produto, serviço, comunicação, tom de voz, público alvo, mercado.

Tem poucos lugares que as pessoas são mais verdadeiras, expressam mais o contexto de quem que elas são, do que dentro de **reuniões**. Toda reunião com o seu cliente é oportunidade para você extrair contexto.

---

## VERDADE 3 — Aplicações e softwares vão virar as novas landing pages

No passado, eu poderia chegar para você e mostrar planilha. Hoje em dia eu crio uma identidade visual legal, eu crio todo um sistema onde você já baixa tudo pronto, onde tudo que você tem que fazer é só preencher. Hoje você abre o **Lovable**, manda um áudio falando o que quer criar, qual que é a sua ideia. Só mandar um áudio, ele faz nascer para você.

Cada vez mais a gente vai ver profissionais vendendo softwares feitos exclusivamente para determinadas marcas com determinadas necessidades. Quais são as oportunidades mais óbvias?
- Sistema de dashboard central de dados dos clientes
- CRM de gerenciamento e atendimento ao cliente
- Sistema para gerenciamento interno de backoffice (contrato, finanças)
- Produto low ticket pro meu cliente revender

Só que aqui é onde as pessoas viajam: **no jogo da IA não ganha dinheiro quem tem o conhecimento da IA. Ganha dinheiro quem tem o cliente.** O conhecimento vai se tornar cada vez mais acessível. Quem é que vai conseguir ganhar dinheiro com essa habilidade, já que todo mundo vai ter? Quem já tem o cliente. E eu acredito que o gestor de tráfego sai na frente, porque anunciar na internet ainda é a melhor maneira de abrir a porta para um negócio.

Pega um aluno meu que vende anúncios online e pega alguém que é especialista em criar sistemas com IA, vibe coding. Vamos ver quem fecha mais negócios. O cara da IA não vai conseguir competir. Por quê? Porque os anúncios online são a necessidade básica dos negócios. **Pirâmide de Maslow dos negócios: na base está tráfego.** Não tráfego pago — tráfego. É gente entrando no negócio, mandando mensagem, entrando em contato. Se um negócio não consegue gerar fluxo de pessoas, ele não existe.

Existe negócio sem organização, sem CRM, sem processos? Existe. Dá para fazer dinheiro sem ter organização. Só que essas habilidades estão tão acessíveis que quem vai acabar abraçando elas como próximo passo é o gestor de tráfego.

---

## VERDADE 4 — Prestadores de serviço vão acumular mais funções

No início da sua carreira, a cagada é falar: "tenho que aprender tudo, tenho que me sentir 100% pronto em todas as habilidades para ganhar dinheiro". Não. Quando você começa, se você sabe somente fazer anúncios online, isso hoje te leva até **R$10–15k por mês**. Daqui um ano, saber só fazer anúncio online vai te levar até R$5–8k por mês.

Não tô romantizando. Não tem porque você só saber fazer gestão de tráfego. Você tem que saber outras habilidades, porque adquirir habilidades hoje é muito fácil. A IA acelera a aquisição de habilidades.

Habilidades que se empilham:
- Criação de conteúdo
- Posicionamento
- Criação de anúncio
- Copywriting
- Criação de oferta
- Tráfego pago
- Landing page
- Relatórios e dashboards
- Traqueamento comercial
- Automações
- CRM

No meu tempo, tudo isso era mato. Você passava anos para dominar uma coisa antes de aprender outra. Hoje em dia, em horas você já se torna apto para entregar uma nova habilidade pros clientes.

---

## VERDADE 5 — A disseminação do medo vai só aumentar

Uma vez que a inteligência artificial tá mudando tudo o tempo todo... humanos odeiam mudança. Essa é a oportunidade. É muito fácil vender medo em tempos de incerteza. Mas enquanto você se distrai com medo, **tem gente ganhando dinheiro**. Enquanto você fica ponderando "será que já passou o momento, será que saturou", desde 2020 eu escuto isso. E todo ano um moleque de 19 anos começa no tráfego pago e termina 12 meses depois ganhando R$10k por mês. Todo ano. Não vai ser diferente. Tem pessoas assistindo esse conteúdo hoje que em maio de 2027 vão tá ganhando R$10k.

---

## VERDADE 6 — Muito gestor de tráfego vai quebrar por não saber se adaptar

Quatro grandes características de quem NÃO tem que se tornar gestor de tráfego pago:
1. Se você não quer ter contato com outros seres humanos
2. Se você não tem o mínimo de autonomia para decidir e agir sem um chefe no seu cangote
3. Se você não consegue organizar as suas demandas e prazos
4. Se você não tá OK de reaprender a sua profissão de novo a cada 6 meses

Outro dia entrevistei uma menina na rua, ela falou: "minha mãe me dizia: ninguém nunca pode tirar o que tá dentro da minha cabeça". É, mas o que você tem na cabeça pode se tornar velho e desatualizado. Isso acontece com a gestão de tráfego a cada 6, 12 meses. Não 100%, mas uma parte se torna velha.

---

## VERDADE 7 — Muita gente vai tirar o olho da vaca leiteira

Desde que eu comecei a ensinar tráfego, o tanto de gente que começa a ensinar tráfego e depois de 3, 4, 6 meses muda de nicho... Hoje a maioria que ensinava tráfego já não ensina mais, ensina você a ser especialista em IA. O cara tá sempre surfando a nova onda. Ele não permanece no mesmo lugar.

Existe um superpoder de você permanecer no mesmo lugar. Desde a minha primeira aula eu defendo uma bandeira: tráfego. Todo negócio precisa de tráfego. Isso nunca vai mudar. Isso é o que permanece. O nome da minha empresa é grupo **Permaneo**. Permaneo em latim é permanecer.

Sempre que eu vou olhar para um mercado, antes de me perguntar "o que muda no tráfego pago?", eu me pergunto: **"o que permanece? O que sempre vai ser igual?"** São esses os pontos que eu tenho que focar. Aí mora o fundamento. O que muda o tempo todo é onde eu tenho que estar de olho para reaprender.

Tem muito gestor de tráfego que se perdeu olhando pra IA e deixou de cuidar da vaca leiteira — fazer os anúncios pros clientes, prospectar. Muito dono de negócio se perdeu olhando para IA e deixou de cuidar do que mais importava: campanhas, novos anúncios, conteúdo, audiência.

Se eu pudesse ter um único poder na vida, eu teria o poder de fazer tudo aquilo que eu falei que ia fazer. Mas o meu poder número dois seria o poder de **sempre saber o que priorizar para chegar no meu objetivo**. Se você sempre sabe qual a melhor ação para chegar mais próximo do seu objetivo, é só questão de tempo até chegar lá.

A IA é uma distração para muitas pessoas. Você tem que saber utilizar do jeito certo. Tem que saber onde colocar o seu tempo como gestor de tráfego pago.

---

Palavra-chave da live: **Jevons**

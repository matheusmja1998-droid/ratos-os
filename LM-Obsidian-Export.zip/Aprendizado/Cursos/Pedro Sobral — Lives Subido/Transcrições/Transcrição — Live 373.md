---
tipo: transcrição
live: 373
tema: Copywriting para Gestores de Tráfego — Parte II
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #373

> Copywriting para Gestores de Tráfego — Parte II

Resumo e aplicação: [[Live 373 — Copywriting para Gestores de Tráfego (Parte II)]]

---

sa ao vivo agora ao vivo. Bem-vindos, bienvenidos, bienvenidos a nuestra
live 373 hoamente del México e solamente vamos a espanhol todo el
contenido não vai ter como. Não consigo, eu acho que eu não consigo
ainda sustentar uma live de uma hora em espanhol, mas bem-vindos,
bem-vindos à nossa live número 373. Sim, diretamente do México. Estou
aqui num evento, acabei de sair aqui, deu bem o intervalo do evento que
eu estou 2 horas atrás. Então eu estou aqui onde eu tô é 1 hora da
tarde, você tá no futuro. Aí são 3 da tarde, mas a live é às 3: da tarde
daí, não daqui. Mas a gente tá, tô aqui no, tô no passado, né? Eu tô a
uma aqui 1 hora da tarde, acabou de dar um intervalo pro almoço. Vim
aqui para um evento das maiores contas de infoprodutores da latino eh
dos dos não é da Latinoamérica porque o Brasil é país latino-americano
também, mas eh dos espanablantes. Então viemos aqui num grande evento,
as 30 maiores contas, vim palestrar aqui. Palestrante internacional, né?
Me respeita. Quem é você? Vou colocar lá no meu Instagram. Palestrante
internacional. Vou palestrar hoje, vou gastar um pouquinho do meu
espanhol ali na palestra. É, mas é claro que a gente tinha que honrar o
compromisso aqui da nossa live de terça-feira, 3 horas da tarde. Toda
terça-feira, 3 horas da tarde, aqui nesse canal do YouTube, você
encontra um conteúdo ao vivo sobre tráfego para anuncio, não tem jeito,
eu não posso estar ao vivo. Sei lá, se eu tivesse agora nesse momento
num voo, eu não conseguiria estar ao vivo com você, mas aí nesse caso,
eu teria gravado o conteúdo e você estaria assistindo uma transmissão ao
vivo do conteúdo feito e sempre muito próximo, né? Na maioria das vezes
no mesmo dia em que a live acontece. Mas via de regra, toda terça-feira
3 horas da tarde aqui nesse canal do YouTube você encontra os melhores
conteúdos de tráfego pago desta internet. Pedro, mas eu entrei lá no seu
canal do YouTube e eu não consegui encontrar lá no seu canal do YouTube
373 lives. Eu entrei lá no seu canal do YouTube, na verdade tinham menos
aulas do que isso. Lá no seu canal do YouTube eu achei, sei lá, umas 20
aulas, o que deve dar aqui mais ou menos umas 20, 30 horas de conteúdo.
Pois é, nós fazemos um tipo de conteúdo aqui no canal do YouTube que eu
chamo de conteúdo perecível. O que que é o conteúdo perecível? Toda
terça-feira, 3 horas da tarde, temos uma aula ao vivo. Terça-feira da
semana seguinte, eu tiro aquela aula do ar e entrego um novo conteúdo.
Ah, mas como é que eu vou assistir se você tira a aula do ar? Porque as
aulas, na maioria das suas vezes, não tem continuidade. Por que que eu
estou frisando na maioria das suas vezes? Porque diferente da maioria
das semanas, esta aula de hoje é a continuação da live número 372 que
fizemos na última semana, tá? Então, hoje a gente vai falar sobre
copywriting para gestores de tráfego, como é que você vai criar bons
anúncios, parte dois. E pra gente começar essa parte dois, eu vou,
Pedro, eu não vi o que aconteceu anteriormente, eu não vi a outra aula,
eu vou ver ela antes. Não faça isso, tá? Você vai ter tempo para
assistir a outra live do que eu fiz na semana passada, live número 372.
Mas todavia, entretanto, você pode agora ter uma recapitulação rápida da
live 372 e focar comigo aqui na live número 373, que complementa o
conteúdo da live da semana passada. Pois bem, o que que nós vimos na
semana passada? Eu vim trazer para você aqui conceitos importantes de
copywriting para gestores de tráfego e eu falei que existem basicamente
cinco grandes pilares que todo gestor de tráfego precisa dominar sobre
cópia. A gente tem que entender um pouco sobre COP, temos que saber
sobre públicos alvo, temos que entender sobre criação de anúncios,
criação de páginas e fazer boas promessas. Nas na aula da semana
passada, a gente falou primeiramente sobre esses três pontos aqui, tá?
Então, a gente falou sobre entender sobre COP, falamos sobre público
alvo e falamos sobre anúncios. Foram esses os pontos que a gente
conseguiu falar durante a aula, que eu consegui aprofundar bastante
neles, tá? Então, falei para você eh que você para você aprender
copywriting, você tem que consumir muito conteúdo, porque o copywriting,
o ato de escrever. O que que é o copywriting? A escrita persuasiva, o
ato de convencer por palavras. Então, para você aprender a convencer com
palavras, primeiro você tem que ser um bom consumidor de palavras, um
bom consumidor de palavras escritas e um bom de um bom consumidor de
palavras faladas. Então você primeira primeiro precisa ler e ouvir para
que você possa então escrever e falar bem, tá? Essa é a lógica do
copywriting. Toda a minha base de copywriting, ela nasce deste
conhecimento básico de que se você é um cabeça de vento, ou seja, você
não tem conteúdo nenhum na sua cabeça, você não vai conseguir colocar
conteúdo para fora. Mas aí para isso que existem essas aulas, para isso
que você pode estudar, para isso que você pode se aperfeiçoar. E aí a
gente foi falar do passo número dois, né, que é você entender o seu
público alvo. E aí eu trouxe quatro camadas em que você pode compreender
o seu público alvo. A gente pode compreender o público alvo com
definições básicas, entendendo quem é essa pessoa. Para isso, eu liberei
para você na semana passada agentes de inteligência artificial que te
ajudam a fazer essa definição aqui de com quem que eu estou falando. No
exemplo da semana passada, a gente inclusive usou o exemplo de uma
manicure, tá? Então, ah, eu vou vender um serviço de manicure. Se eu
fosse vender o serviço de manicuri, como é que eu mapeio quem é a pessoa
que contrata um serviço de manicure? Depois a gente foi pra camada
número dois, que é o nível de consciência, que é entender o que que essa
pessoa sabe e o que que essa pessoa não sabe. Aí eu falei que tem cinco
níveis de consciência. Expliquei a teoria lá do Eugen Schwartz no livro
Breakthrough Advertising. Ele fala sobre os cinco níveis de consciência,
que são as pessoas que não sabem que tem um problema, elas só tem um
sintoma, ou seja, totalmente inconsciente. As pessoas que sabem que tem
um problema, sabe que esse problema tem uma solução, sabe que tem um
produto que entrega para ela essa solução desse problema que resolve
esse sintoma e sabem, totalmente consciente, são as pessoas que sabem
que existe uma marca que entrega esse produto, que resolve essa que
entrega essa solução, que resolve esse problema, que sana, eh, vai sanar
este sintoma que a pessoa tem. Isso daqui tudo a gente tá falando sobre
entender o público algo. Aí eu te aí eu te trouxe outras duas camadas.
Camada número três, crenças. no que que essa pessoa acredita, no que que
essa pessoa não acredita. Aí te trouxe aqui pequenos promptes que eu
utilizo até no meu próprio chatt aquele com aquele recurso de pesquisa
profunda para entender o que que meu público alvo acredita. Eu quero
principalmente entender o que que o meu público alvo acredita ser
solução pro problema que eles têm, quais são os preconceitos que o meu
público alvo tem com a tipo com o tipo de solução de produto que eu
vendo. O que que eles acreditam que é possível fazer para solucionar o
problema deles e o que que eles acreditam que não é possível fazer para
solucionar o problema deles. E aí a gente foi pro último passo, que é a
camada da atenção, que tipo de conteúdo funciona e chama atenção dessa
pessoa. E aí eu te mostrei na prática como é que eu pego facilmente nas
próprias redes sociais os conteúdos que funcionam, os conteúdos que não
funcionam e como que eu utilizo isso ao meu favor. Aí a gente entra no
terceiro ponto que são os anúncios. E aí eu te trouxe os principais
pilares de um bom anúncio, que ele é baseado em referências. E aí falei
para você que o melhor lugar de você encontrar referências é com quem já
tá fazendo bons conteúdos, bons anúncios na internet. Te expliquei de
uma maneira que eu tenho certeza que você não viu em outro lugar como
que você usa a biblioteca de anúncios de uma maneira um pouco mais
estratégica. Falamos sobre os anúncios camuflados e explícitos, que
ambos são muito funcionais, e falamos sobre o fator de segmentação, que
é o que vai dizer se o seu anúncio vai trazer o público qualificado ou
se ele não vai trazer o público qualificado. Te trouxe alguns fatores de
segmentação, como direta, conhecimento, ferramenta, situação,
comportamento, crença e rotina. E aí te expliquei sobre a estrutura GCC,
que é a minha estrutura que eu sempre utilizo. Existem várias, mas essa
daqui é que eu mais utilizo para criar os meus anúncios na internet. E
aí falei que o gancho que é o que que é estrutura GCC, gancho, corpo e
CTA, que o gancho ele pode ser, ele pode acontecer, ele pode, ele vai
acontecer, aliás, de três maneiras. falado que ele tem que criar na
pessoa a sensação de humo tá falando comigo. Ele pode vir de maneira
escrita. Então a o que tá escrito no seu anúncio, ele tem que ser um
looping, o um spoiler do que que vai ser dito para que a pessoa tenha
vontade de assistir mais. E ele pode ter o recurso visual que chama a
sua atenção, eh, não só através do que que tá escrito ou do que que tá
falado no seu anúncio que você colocou no ar. E aí, corpo e call to
action são as partes mais fáceis do anúncio. O gancho ele é o 8020. Que
que é o 8020? É a menor parte que mais gera resultado. Pois bem,
acabamos a última aula aqui neste momento, tá? Então, só pra gente fazer
uma recapitulação rápida, tem gente que já tá assim: "Caraca, isso aí é
tipo um curso que o cara entregou em uma aula." Sim, foi uma aula de
mais ou menos 1 hora: 40 minutos. A aula de hoje vai ser mais curta, que
a gente tá com a parte final do conteúdo, mas eu também não queria
exagerar e trazer aquilo lá, porque a maioria das pessoas não ia tá
retendo e nem entendendo nada. Inclusive, quem aqui estava presente na
aula da semana passada e tá aqui de novo, por favor, manda um eu no
chat. Deixa eu pegar aqui o chat porque eu tô com um delayzinho maroto
aqui entre o que eu falo. Ó, tem uma galera que estava aqui na semana
passada e voltaram. Muito obrigado, meu. Vocês são demais. vocês são
demais, tá? Então vamos seguir em frente. Quais são as outras, os outros
dois conhecimentos que um gestor de tráfego precisa ter quando o assunto
é copywriting, um dos serv, uma das coisas que vai fazer você escalar no
tráfego pago é você assim, quem aqui não fatura nada como gestor de
tráfego manda para mim no chat zerado. Quem aqui já ganha alguma coisa,
manda assim, começando. E quem já tá buscando ganhar ainda mais, manda
assim, escalando zerado. Começando, eu tô zerado. Começando, zerado.
Nada zerado. Escalando. Tem um escalando, dois, três escalando. Beleza.
Vamos lá fazer explicação marota aqui para vocês. Para você que tá
zerado, não tenho nada de resultado, tô começando agora, não tenho
cliente. Seu único foco deve ser adquirir conhecimentos para que e
somente para você conseguir vender seus serviços com mais segurança.
Ponto. Repara. E por favor, não me interpreta errado. Eu não falei aqui
que você tem que adquirir conhecimentos para que você esteja 100% seguro
na hora que você for vender. Isso não vai acontecer. Você sempre vai
ficar inseguro na hora de vender. Você sempre vai achar que você não tá
pronto. Você sempre vai achar que você não sabe o bastante. Você sempre
vai sentir que não é o momento certo. Isso é uma realidade. Você pode
agora tá pensando assim: "Ah, não, mas é que eu sei, eu entendi isso aí
que você tá falando, Pedro, mas é que eu eu realmente não tô pronto. Eu
realmente não tô pronto. E eu sei que você vai pensar que para você é
diferente, que você tá numa situação diferente, mas você não tá, você
não tá. Você precisa o quanto antes ir atrás de conseguir os seus
primeiros clientes, se mover, sair do zero. Ai, mas como que eu vou
fazer isso se eu não sei tráfego direito, se eu não me sinto pronto, se
eu não me sinto preparado? O segredo do gestor de tráfego que tá
começando ter as respostas para todos os problemas, mas é encontrar os
problemas e saber onde buscar as respostas para esses problemas. E eu
sei que parece a mesma coisa, mas não é uma coisa. É você primeiro
acumular todas as respostas para que quando chegar o problema em você,
você já sabe resolver. Isso é o que a maioria das pessoas fazem. É assim
que a maioria do mundo opera, te ensinaram a fazer isso a vida inteira.
Você se prepara para fazer a prova. Você primeiro acumula o conhecimento
e na hora da prova a prova e sem consulta. Você tem que fazer o que tá,
você tem que responder as perguntas ali com conhecimento que tá na sua
cabeça. É assim que a gente foi educado. Mas no mundo do tráfego pago,
para quem tá começando, a receita mais rápida para você colocar dinheiro
no seu bolso é primeiro você encontrar o problema. Então é como se eu
primeiro fosse pegar a prova com as perguntas que eu não sei responder e
a partir da prova das perguntas que eu não sei responder, eu vou
encontrar as respostas. Então o que que você precisa ter? Você precisa
ter um local onde você encontra as respostas para esses problemas. Onde
que pode ser esse local? Pode ser a o Google, pode ser o YouTube, pode
ser o meu canal do YouTube, pode ser a comunidade subido de tráfego.
Deve ser a comunidade subido de tráfego se você for meu aluno. Então
você tem que ter o local onde você vai encontrar aquelas respostas e aí
todo o problema que jogar em você, você vai conseguir resolver, tá,
Pedro? Mas e eu que não sei nada, nada, nada, nada. Essa é a primeira
live que eu tô vendo, eu tô absolutamente zerado. Aí você tem que
adquirir um conhecimento base para que você comece, tá? Onde que você
encontra esse conhecimento base? Pô, eu não tô te falando aqui que eu
dou aula toda semana, eu não sei o que que eu tô fazendo aqui e que no
meu canal do YouTube tem umas 20 horas de conteúdo. Esses conteúdos que
estão aqui, eles não são à toa. Vai ter conteúdo aqui atualizado, ó.
Como criar campanhas no Metaedads em 2026. como que você anuncia no
Google Ads em 2026, como trabalhar com digital, como segmentar os seus
anúncios. Tem conteúdos aqui para que você justamente dê esses primeiros
passos. Para você que tá começando, seu foco tem que ser esse. Mas
presta atenção, enquanto você tá estudando, você tá buscando executar.
Enquanto você tá estudando, você tá buscando seus primeiros clientes. Aí
é para aí que você tem que tá olhando. Ponto. Acabou. Adquirir
conhecimento, buscar cliente. Adquirir conhecimento, buscar cliente em
paralelo. Se hoje, terça-feira, a única coisa que você fez em relação a
tráfego pago foi estudar, tá errado. Você tá ficando para trás, você tá
perdendo tempo. Ninguém gosta de perder tempo. Você tá perdendo tempo.
Não, não, não jogue seu tempo fora. Ah, estudar é importante, é, mas
estude com propósito. propósito de enquanto eu estudo, eu vou
executando. Enquanto eu estudo, eu coloco a mão na massa. Enquanto eu
estudo, eu fecho os meus clientes. Ah, mas eu não tô pronto, mas eu tô
com medo, mas eu me sinto despreparado. Tudo bem, você e todo, toda a
torcida do Corinthians, todo mundo que começou passou por isso. A
questão é o quão rápido você vai agir, apesar destes medos e dessas
inseguranças, é o que vai dizer o quão rápido você vai ganhar dinheiro.
Você pode escolher encarar isso hoje ou encarar isso daqui a um ano. A
diferença de você de hoje para daqui um ano, você vai achar que você
sabe mais tráfego pago, mas no fundo, no fundo, você só vai saber
tráfego pago quando você colocar a mão na massa, tá? Por que que eu tô
dizendo isso? Você que tá na fase dois, que é a fase do tô começando,
você vai começar a notar que os seus clientes têm diferentes
necessidades. Então assim, ah, eu encontrei um cliente que precisava do
serviço de tráfego pago, eu tô prestando esse serviço de tráfego pago
pro meu cliente. Ótimo, maravilhoso. No meio desse caminho, o seu, você
vai ver que o seu cliente, sei lá, ele contratou alguém para fazer
cuidar do Google Meu Negócio dele. E essa pessoa que tá cuidando do
Google, meu negócio do cliente, ela é horrível, porque o trabalho tá
sendo muito mal feito. Aí você vai começar a anar, putz, eu fecho, sei
lá, com eu sou uma eu, eu eu escolhi trabalhar nichado, não tem certo,
não tem errado, mas eu escolhi trabalhar com um nicho específico. Eu
atendo restaurantes de delivery em Curitiba. Vamos pegar um exemplo que
eu dei na última aula. Então eu atendo restaurantes de delivery em
Curitiba. Ótimo. Aí eu percebo que todo restaurante delivery em Curitiba
que eu atendo tem um problema de Google Meu Negócio. O Google Business
Profile desses restaurantes é horrível. Aí eu falo assim, tá? Vou me
especializar nessa determinada habilidade para entregar esse serviço.
Esse é um caminho. Ou vou encontrar um parceiro, um outro gestor de
tráfego, alguém que entende de Google Meu Negócio e vou fazer uma
terceirização desse trabalho para entregar isso aqui pro meu cliente.
Ótimo. dentro do universo do tráfego pago, dentro do universo de
soluções que um gestor de tráfego entrega. Claro que o tráfego pago é a
primeira, mas a segunda solução que os clientes mais contratam é a
solução de criação de landing pages. O que que é uma landing page?
Landing page é uma página de aterriçagem, tá? é a página que a pessoa
cai depois que ela clica no seu anúncio. Quando eu vou explicar para as
pessoas mais leigas o que que é anunciar na internet, eu sempre falo
assim: "Cara, anunciar na internet é sobre você colocar o anúncio certo
na frente da pessoa certa, no momento certo e enviar a pessoa pro
destino certo. Eu tenho que enviar a pessoa pro local em que ela vai, em
que eu vou conseguir alcançar o meu objetivo publicitário." Então, o
destino certo ele importa muito. Qual que é o problema? O problema é que
eu falo para as pessoas assim: "Ah, mas você vai o o segundo serviço que
os gestores de tráfego mais vendem eh o primeiro serviço, né, depois do
tráfego pago, é a criação de landing pages." Aí a pessoa, meu Deus, mas
eu não sei criar site, eu não sei criar página, eu não sei nada disso.
Aí que tá. Você não precisa saber criar tudo isso. O que que você
precisa saber para criar uma boa página? Você tem que entender de
copywriting, porque uma boa página nada mais é do que texto. Texto
escrito persuasivo que faz a pessoa tomar uma ação. Pedro, eu que tô
começando, então isso aqui não serve para mim. Aí que você se engana.
Por quê? Porque a maior parte dos donos de negócio tem landing pages
completamente cagadas. E uma grande oportunidade que você como gestor de
tráfego tem para fechar clientes é você analisar coisas que não tem a
ver com o tráfego pago especificamente. Pedro, como assim? Se eu vou
abordar um cliente, eu quero vender o meu serviço de tráfego pago, é
mais fácil abordar esse cliente e falar para ele da organização do
perfil do Instagram dele, do tráfego orgânico dele, do que falar de
tráfego pago. Se eu vou abordar um cliente, eu quero vender meu serviço
de tráfego pago, é mais fácil eu conseguir fechar esse cliente
analisando a página dele, a landing page dele. Por que que isso
acontece? É um motivo óbvio que a maioria das pessoas não conseguem
enxergar. O motivo é simples, porque eu não consigo ter acesso ao
gerenciador de anúncios do cliente sem que ele me dê esse acesso. Agora,
se existisse um mundo, tá? Vamos dizer que existe esse mundo em que todo
mundo consegue acessar o gerenciador de anúncios alheio. Então, eu
consigo abrir o gerenciador de anúncios das outras pessoas. Vamos dizer
que você consegue abrir o meu gerenciador de anúncios e você consegue
vir aqui, ó, e fuçar nas minhas campanhas. Você consegue mexer nos meus
anúncios, você consegue ver o que que eu tô fazendo aqui. Esse mundo ia
ser maravilhoso. Por quê? Porque eu, gestor de tráfego, eu ia analisar
os gerenciadores de anúncios dos clientes, ia chegar nos clientes e
falar assim: "Cara, esse trabalho tá mal feito, esse trabalho tá bem
feito, isso daqui tá dando certo, isso aqui não tá dando certo, olha
aqui, aqui tem uma oportunidade de melhora para você". Então, como que
eu gestor de tráfego faço para mostrar a competência do meu trabalho
para alguém sem que eu possa olhar o gerenciador de anúncios daquela
pessoa? Você vai analisar recursos públicos. Que que é um recurso
público? A página da pessoa é um recurso público. O Instagram da pessoa
é um recurso público. Os anúncios das redes sociais daquela pessoa são
recursos públicos. porque eu consigo visualizá-los dentro da biblioteca
de anúncios. Então, ah, como é que eu faço para fechar um cliente sem
ter experiência prática? Você tem que ter experiência de conhecimento. E
uma das melhores habilidades que você pode adquirir desde o início da
sua vida como gestor de tráfego pago é a habilidade de saber criar uma
boa página, de criar uma boa landing page. Por quê? Porque isso vai
fazer você vender mais, porque você vai conseguir apontar mais
problemas, mais erros, gerar mais valor pros clientes que eu for abordar
e prospectar. Eu vou aumentar o meu nível de conhecimento acima da média
dos gestores de tráfego que não sabem analisar COP. E em paralelo, eu já
começo a me preparar para quando eu tiver saindo da fase, começando e
indo paraa fase escalando, eu já consigo ter a habilidade para vender as
landing pages para os meus clientes. Por quê? Porque eu não preciso
saber fazer o site, a parte de design. Tudo que eu preciso é a parte de
COP, ainda mais no mundo que a gente vive hoje com inteligências
artificiais. que um lovable, um manus, um bolt da vida, que são
ferramentas de a, criam para você a página. Só que eles vão criar para
você a página com base no quê? Nas suas instruções. Quais são as
instruções mais importantes que você vai dar para uma ferramenta de a?
As instruções de cópia, o que que tem que tá escrito na página, quais
vão ser as sessões dessa determinada página. Até para mandar na
inteligência artificial, você tem que ter inteligência natural. Então,
ai a IA vai roubar o trabalho das pessoas que fazem página. Não, a IA
vai pegar, a IA vai dar mais poder paraas pessoas que sabem criar
páginas. Você sabe criar uma página hoje? Não sei. Você sabe quais são
as principais sessões de uma página boa? Não, não sei. Como é que você
vai ir para IA então e pedir para ela fazer uma página boa para você?
Você não vai. Mas a partir de hoje isso muda, tá? Então vamos lá. Ponto
número quatro aqui da nossa da nossa aula de copywriting para gestores
de tráfego são páginas. Os 20 pilares de uma uma página boa. Primeiro
pilar de uma boa página, assim como assim como um anúncio, uma boa
página ela é feita a partir de referências, tá? Então assim, toda boa
página foi criada a partir de referências. Existem ferramentas,
extensões do Google Chrome, como o Fire Shot. O que que o Fire Shot faz?
O Fireshot ele tira prints das páginas, tá? Então, por exemplo, deixa eu
entrar aqui na minha aula e pegar minha página aqui da, ó, pegar essa
página minha aqui, tá? Isso aqui é uma página. Se eu tirar ela do ar
amanhã, quantos de vocês conseguem acessar ela? Só quem já salvou ela.
Tá aí. Eu vou pegar aqui as minhas extensões. Putz, eu tô sem o fir shot
aqui só porque eu fui dar o exemplo, né? Tá aqui, ó. Deixa eu ativar ele
aqui. Deu, ó, Fire Shot, tá bom? Fir shot. Cliquei aqui nele, ó, e
aperto aqui, ó, capturar a página inteira. Que que ele vai fazer? Ele
tá, eu nem tô mexendo. Olha minhas mãos aqui, ó. Ele tá fazendo a
captura dessa tela para mim, dessa página inteira para mim. Então ele
vai fazer toda a captura dessa página e salvou isso daqui num arquivo.
Ó, esse arquivo é meu. Por quê? Porque isso daqui são as referências.
referências para que eu utilize no futuro, para que eu veja, pô, qual
headline que o Pedro utilizou, quais são as sessões que tem dentro dessa
página aqui. Ah, quero, vou atender um dentista, pô. Em quantos, seja
honesto comigo, quantas páginas de dentistas você acha que você consegue
salvar no seu computador procurando uma hora? Uma hora procurando na
internet páginas de dentista? Quantas páginas você acha que você
consegue salvar? A câmera balança, avisem ele. É que tá em cima da mesa.
Aí quando eu bato assim, ela vai dar uma balançada. Não tem muito jeito.
Mas tá tudo bem, vocês vão sobreviver. Uma 120 mais 10 não, mais de 100.
Que isso? Eu vou no Google e pesquiso dentista em São Paulo, vão
aparecer 50 sites de dentista, eu vou só abrindo e salvando as melhores.
Em minutos eu pego 50 páginas. Claro, aí você vai fazer uma seleção, mas
imagina que eu vou atender um determinado mercado e isso é a coisa mais
idiota que eu tenho que falar pros gestores de tráfego. É a coisa mais
idiota. Mas isso tem valor. Isso tem valor. Você vai, pô, vou atender um
cliente de um determinado nicho. O que que eu vou fazer? Vou fazer uma
pesquisa sobre aquele determinado nicho. Vou fazer uma pesquisa com os
agentes de A que o Pedro liberou para mim. Eu vou fazer uma pesquisa com
os prompts que o Pedro ensinou na última aula. Eu vou entender o público
alvo, vou fazer uma pesquisa de anúncios, vou baixar os anúncios lá da
biblioteca de anúncios, eu vou montar um banco de referências, porque
isso vai me dar muito mais segurança para atender aquele cliente. E eu
sei que isso parece bobo, eu sei que isso parece óbvio, porque é bobo e
é óbvio, mas você não tropeça nas pedras grandes, você não tem eh
resultado no tráfego pago, não é porque você não sabe técnicas
avançadas, é porque você não faz o básico bem feito, tá? E a primeira
coisa é sempre ter referência. Referência vai te dar muita segurança.
Segundo elemento de uma boa página, objetivo claro, é aquela frase, né?
Para quem não sabe para onde tá indo, qualquer lugar serve. Então, se
você tem uma página que não tem um objetivo, um objetivo claro, o seu
lead vai ser caro. Página sem, objetivo claro, lead caro. E aí você tem
que saber responder isso. Qual é o principal objetivo da sua página? É
tipo a pessoa que fala assim: "Ai, essas são as minhas prioridades."
Prioridades não existe. Priori vem de um, é uma, não é uns. Aí eu tenho
uns, umas prioridades, não. Prioridade de uma coisa só. Qual que é a sua
prioridade hoje? Ah, minha prioridade hoje é ir treinar e no dentista. Ã
ã, negativo. Só um. Qual que é o principal objetivo da sua página? Tem
que ter. Isso é a primeira coisa que a gente tem que perguntar para
alguém quando a gente vai criar uma página. Então vai ser o quê?
Solicitar um orçamento, agendar uma consulta, vender o produto X, fazer
um pedido no WhatsApp, agendar uma consultoria, se cadastrar para um
evento, baixar um e-book, vender um melhor produto de tráfego pago do
mercado, como é o meu caso, quando eu vou criar uma página. Você tem que
definir isso. Definido isso, parte número dois, público. Quem quer falar
com todo mundo não fala com ninguém, tá? Então assim, eh, é aquela
pessoa que vai, aquela pessoa que tem dificuldade de tem gente que quer
abraçar o mundo. Então, assim, eu quero ajudar você que é iniciante, eu
quero ajudar você que é intermediário, que é avançado, eu quero ajudar
você, eu quero ajudar todo mundo. Eu quero ajudar quem tem o negócio, eu
quero ajudar quem não tem o negócio, eu quero ajudar quem nem quer ter
um negócio. Eu quero te convencer que teu negócio é bom. Então assim, a
pessoa ela quer o mundo inteiro. Quanto mais abrangente você for na sua
comunicação dos seus anúncios e da sua página, pior vai ser. Lembra? O
seu anúncio ele tem um gancho, ele tem um fator de segmentação. O seu
anúncio, ele começa uma conversa. A página é a continuação dessa
conversa. Então você sabe quem você tá atraindo através do seu anúncio.
Continue conversando com essas pessoas. Tá? E assim, você pode falar com
mais de um tipo de pessoa. Por exemplo, eu ajudo donos de negócio e
ajudo pessoas que querem se tornar profissionais na área de tráfego pago
a ganharem dinheiro através dos anos online. Mas a minha comunicação é
clara. Por quê? Porque no final das contas eu falo sobre gestão de
tráfego pago. É isso daqui que eu entrego as pessoas para as pessoas,
tá? Então você tem que conseguir responder essa pergunta. Quem vai cair
nessa página? Você tem o controle disso daqui? Quem que vai cair lá?
Quais pesquisas que a pessoa fez para ver o seu anúncio, se você tá
anunciando no Google? Qual segmentação que você selecionou na meta? Qual
é o público que o seu anúncio tá atraindo? Que fator de segmentação eu
utilizei? Eu tô segmentando por quê? Por crença, por plataforma. Quanto
mais a minha página continua a conversa do meu anúncio, melhores vão ser
os resultados dos meus anúncios. Quarto elemento, headline. Que que é a
headline? Quando eu entro na página, é a primeira coisa que tá escrita.
Ops, as inscrições paraa comunidade subido estão fechadas. É a primeira,
é a impressão que fica quando a pessoa chegou na minha página, tá?
Então, a primeira impressão é a que fica. Esse, sem dúvida, é um dos
elementos mais importantes da sua página. Por quê? Porque é a headline
que convida a pessoa que cai nela a se identificar com o que tá escrito
e continuar ali. Se você não tem uma boa headline na sua página que
chama atenção e que faz com que a pessoa queira continuar ali, ela vai
embora no primeiro minuto. Ninguém chega na sua página, lê toda a sua
página e decide se fica ou não. Não. A pessoa decide se fica ou não logo
no primeiro momento que ela chegou aqui na sua página. Quinto elemento,
subheadline. Então a subheadline é a segunda voz da headline, é o
marrone do Bruno, tá? Então [risadas] então assim, elas são a a dupla
sertaneja da conversão. É a primeira e a segunda voz. É o arroz com
feijão, é o pão com manteiga, o queijo goiabada. Então é o que que vem
abaixo? Então é o complemento, ó. Faça sua pré-inscrição gratuita para
ser avisado sobre a próxima abertura e se prepare para ser um subido.
Isso daqui é a continuação dessa headline que veio logo aqui em cima.
Número seis, botão na primeira dobra. O que que é a dobra? Eu vou
apertar num botãozinho aqui, ó, que o que vai eu vou eu vou ter a
visualização do mobile dessa página, tá? Eu sei que ficou pequeno para
algumas pessoas, mas eu só quero te explicar o que que é a primeira
dobra. Primeira dobra é o seguinte, você abriu o seu celular nessa
página, tá? Eu fui lá, tô no meu celular, deixa eu tentar ficar nesse
cantinho aqui. Acho que vai ficar melhor. Aí fiquei um pouquinho maior.
Você abriu o seu celular, tá? que eu tô, eu tenho um outro celular aqui
para fazer de exemplo. Pera, você abriu a página no seu celular. A
primeira dobra é o que que aparece na tela do seu celular sem que você
tenha que scrollar para baixo. Então, abri uma página, o que que aparece
sem eu ter que ir para baixo? Isso é a primeira dobra que a gente chama.
O que que você sempre tem que ter na primeira dobra? O botão. Sempre na
primeira dobra já tem que ter o botão pra pessoa se cadastrar, pra
pessoa comprar, pra pessoa realizar a ação que você quer que ela deseje,
tá? Então assim, o botão na primeira dobra é o poder do call action, tá?
só ganha o jogo quem chuta pro gol e você precisa conduzir a sua
audiência a comprar, a clicar, a se cadastrar, a você realizar o seu
objetivo publicitário. Então assim, não adianta nada você ter boas, você
ter boas chamadas na sua página, uma boa headline, você ter um layout
lindo, maravilhoso, se você não manda sua audiência comprar de você, se
você não executa isso, se você é tipo aqueles jogos de futebol, sabe?
Tipo, super lindos, super bonitos, mas ninguém finaliza, ninguém chuta
pro gol, ninguém faz gol. A gente não quer só jogar bonito, a gente quer
o resultado final. Então, tem muita página bonita por aí que não entrega
o resultado por um simples motivo, falta de botão. E não só na primeira
dobra, mas falta de botão também nas outras sessões. Depois de cada
sessão da sua página, você tem que dar oportunidades pra pessoa clicar.
Então, se eu pegar aqui a minha página, ó, eu tenho esse botão aí. A
pessoa tá rolando aqui para baixo, ó, tem mais um botão. A pessoa tá
vindo aqui para baixo, mais um botão. A pessoa tá vindo aqui para baixo,
mais um botão. A pessoa tá vindo aqui para baixo. Mais um botão. Tá
vindo aqui para baixo. Aqui falta um botão, ó. Mais um botão. Tá vindo
aqui para baixo. Mais um botão. Quantos botões tem? Ah, mas não é botão
demais, não é? Porque as as sessões da página elas têm que se bastar,
tá? O que que são as sessões? As sessões é como se elas fossem capítulos
do seu site, tá? Então assim, aqui eu tenho uma sessão com pequenos
depoimentos. Aqui eu tenho eh deixa eu pegar uma outra sessão específica
aqui, ó. Aqui eu tenho uma sessão de o que que você recebe quando você
entra na comunidade subido. Então é uma sessão de entregáveis. Então
aqui tem tudo que tem dentro do curso subido, uma sessão inteira de
entregáveis. Aí tem o botão, tá? Então sempre que possível você oferece
uma oportunidade pra pessoa se cadastrar. Por quê? Você não pode deixar
a sua audiência se perder na página, tá? Se a ideia é fazer gol, ou
seja, vender, a todo momento, você tem que escancarar na frente da
pessoa a oportunidade dela comprar. Tipo assim, é é igual quando você
vai num restaurante, o garçom, o bom garçom, ele não te oferece a bebida
só quando você chega. Ao longo do jantar ele fica te oferecendo mais
água. Se o vinho acabou, ele vai perguntar se você quer mais uma
garrafa. Ele tá o tempo inteiro fazendo o quê? colocando um botão de
compre na sua frente. Um bom garção, ele faz isso. Ele constantemente
coloca o botão de compre na sua frente. Um bom garç deixar o seu copo
vazio. Ele vai ficar enchendo seu copo para você. Por quê? Porque ele
sabe que quanto mais rápido você termina a garrafa, mais você tem chance
de comprar outra garrafa. Agora, se chegou ao final do jantar e ainda
tem meia garrafa disponível, você não vai comprar outra. Então ele o
tempo inteiro fica te dando a opção de compra. Número oito, benefício do
seu produto. Tá no final do dia tá todo mundo se perguntando que que eu
ganho com isso, tá? E o que que tem nisso daí para mim? Quando a gente
tá falando de criar uma relação comercial, você nunca pode se esquecer,
ganha dinheiro no mundo dos negócios quem sabe resolver problemas para
as pessoas ou quem ajuda as pessoas a conquistarem um sonho muito grande
que elas têm, tá? Ninguém eh tira o escorpião do bolso só na
camaradagem. Ter um negócio não é caridade. Então assim, pô, quero
ganhar muito dinheiro, aprende a ser útil. Que que você pode fazer para
facilitar a vida das pessoas? Como que você pode tornar a vida dos seus
clientes melhor, mais fácil? Responde essas duas perguntas na página,
tá? Então, o que, ó, vou até colocá-las aqui, ó. O que fazer? Pera aí
que eu não tô compartilhando a tela. O que você pode fazer para
facilitar a vida das pessoas e como você pode tornar a vida dos seus
clientes? melhor e mais fácil. Eu sei que isso são coisas óbvias, eu sei
que isso são coisas simples, mas eu tenho certeza absoluta que 90% das
pessoas que criam páginas na internet não param para responder perguntas
simples, mas que vão te dar o insumo necessário que você precisa para
responder, para criar uma página. E aí você pode ir além, você ainda
pode responder isso daqui, ó. Qual transformação o meu produto ou
serviço causa na vida das pessoas? E por que a vida delas vai mudar
depois que elas comprarem de mim? E isso daqui já é um bom exercício
para você que é gestor de tráfego. Ah, eu não tenho cliente ainda. Faz
esse exercício com você mesmo. Finge que você tá fazendo esse trabalho
para alguém. finge que você tá atendendo, sei lá, um dentista, um
delivery, e você tem que responder isso daqui para um negócio. Eu te
garanto que se você já pegar, ó, eu já te passei oito pontos aqui, se
você pegar esses oito pontos de uma boa página, você já tem capacidade
de analisar, julgar e encontrar problemas na grande maioria das páginas
que estão sendo divulgadas hoje na internet. Número nove, nossos
serviços, preço e forma de pagamento. Sempre lembra disso, falta de
clareza barra conversão. Se a pessoa chega na sua página e ela não
consegue ter clareza dos principais pontos, ela não converte. Sabe
aquela história do você chega no directa, pergunta quanto que é o preço
e a pessoa não quer te contar? Você tem que saber explicar de maneira
simples e clara. exatamente o que que você oferece paraos seus clientes.
Isso daqui eu tô falando que o dono do negócio, o dentista, às vezes ele
não sabe fazer isso, mas você tem que extrair isso daqui dele, tá? Tem
um livro que chama Ideias que Colam. Nesse livro ele fala sobre um
conceito chamado a maldição do conhecimento. O que que é a maldição do
conhecimento? que é aquilo o que muita gente acha que é óbvio, um dia já
não foi óbvio para você. Então, por exemplo, eu chego aqui nessa live e
eu falo para você: "Ah, você tem que montar na sua página uma sessão em
que você fale dos seus serviços, do preço e formas de pagamento. Será
que todo mundo que tá aqui sabe o que que é formas de pagamento?"
Probabilidade que sim. Mas se você não sabe, formas de pagamento é, por
exemplo, você ter lá as condições. A pessoa pode comprar no Pix, ela
pode comprar no cartão, ela pode pagar no boleto, ela pode parcelar o
boleto, ela pode fazer um parcelamento inteligente no cartão que não
consome o limite dela. Isso são formas de pagamento. Que que eu acabei
de fazer? Eu acabei de verificar a minha própria maldição do
conhecimento, que é aquilo, a gente tá tão acostumado a saber as coisas
que a gente não lembra mais como é que é saber as coisas. E isso muitas
vezes é um sintoma de um bom profissional, um bom dentista, um bom
médico, um bom nutricionista. A pessoa não sabe mais como é que é não
saber aquelas coisas. Então você precisa aprender a descrever de maneira
simples, como se você tivesse explicando para uma criança o que que você
faz. E você pode pedir isso pro dono do negócio, porque ali você vai
encontrar vários detalhes que você vai olhar pro dono do negócio, vai
falar assim: "Cara, ninguém nunca me explicou isso desse jeito? Putz, eu
não sabia que era assim que funcionava." E aí é esse tipo de informação
que você vai colocar na sua comunicação, porque quanto mais claro fica
pro público alvo o que que exatamente você oferece, melhor, mais ele vai
converter. E aí você pode responder três perguntinhas mais uma vez,
fácil, simples, mas a página, principalmente se ela tá vendendo o
produto, ela tem que responder isso daqui. Quais são os produtos e
serviços que você oferece? Quanto que eles custam? Quais são as formas
de pagamento? E aí cuidado na a sua página, ela não tem que vender
muitas coisas, tá? A sua página, ela tem que ter um foco. Lembra que eu
coloquei aqui para você, ó, que a página ela tem um objetivo claro, uma
prioridade clara. Uma landing page boa, normalmente ela vai converter
mais quando ela tem um único foco, fala de um único produto, de um único
serviço e é nele que você tem que focar. Número 10, garantias. Tá?
Então, aproveitar que eu tô na Espanha, né? E lançar um aqui. La
garantia no la garantia não pode ser solamente tu. A garantia não pode
ser só você. Você oferece alguma garantia? Vou te dar um exemplo. Outro
dia, outro outro dia eu fui contratar um serviço, tá? Aí não vem, não
vem ao caso qual que é o serviço, mas fui contratar um serviço na
internet, aí tava falando com a Priscila, falei assim: "Putz, quanto que
você acha que a gente vai pagar nesse serviço?" Aí ela, o cara vai,
ficou de mandar a proposta pra gente. Aí Priscila falou assim: "Ah, não
sei". Aí eu falei: "Putz, eu ouvi a pessoa falando que ele cobra R$
50.000. Aí a Priscila, ah, não, 50.000 eu não pagaria. No máximo R.000.
Aí eu concordei com ela, eu falei: "Beleza, até 10.000 a gente paga".
Que que aconteceu? O cara veio e fez a proposta para mim. Quanto que
veio a proposta? 100.000. 100.000? Aí eu falei: "Ah, não vai rolar. 10
vezes mais caro do que eu queria pagar". Só que aí o cara falou para mim
assim: "100.000, mas eu vou te dar uma garantia de resultado." Que que é
uma garantia de resultado? Se em 3 meses você não fizer pelo menos 10
vezes esse valor, eu devolvo 100% do seu dinheiro. Naquele momento eu
falei: "Tá, agora eu vi sentido. Agora eu tô disposto a pagar 100.000."
100.000 é caro ou barato? Depende. Vou falar para você, 100.000 é caro
ou barato? Você vai dizer: "Ah, é caro porque eu não tenho 100.000
hoje". Mas se eu te falar assim, ó, eu vou te dar 100.000 hoje, você vai
me pagar 100.000 hoje e daqui a um mês eu vou te dar 1 milhão. Você acha
que você não consegue? esse dinheiro, você consegue, você pede um
empréstimo, você vai fazer o cálculo, né? Quanto que eu vou ter que
pagar pro banco para pegar esses 100.000 para sacar o meu 1 milhão daqui
a um mês. É a garantia. E isso daqui importa, importa muito. E a maioria
das pessoas não coloca isso no seu serviço, tá? Eu, como gestor de
tráfego, eu nunca prometi resultado pros meus clientes, mas eu sempre
falava o seguinte, ó. E a gente tem uma garantia aqui que é o seguinte:
se em 30 dias você achar que o trabalho que a gente tá fazendo aqui não
tá sendo um bom trabalho, que ele não tá dando resultados para você, que
ele não é um trabalho que tem potencial de crescer muito o seu negócio,
a gente pode cancelar o contrato sem multa contratual nenhuma. vai cada
um pro seu lado, porque eu sempre vendi contratos de tráfego pago de tr
a se meses. Então eu vendo o contrato maior, o cliente não pode sair.
Mas eu colocava essa cláusula aqui de em 30 dias ele poderia sair. É uma
espécie de garantia. Eu tô garantindo para ele. E quando que alguém
pediu essa garantia? Nunca. Nunca. Mas é um argumento de venda poderoso
até para você que é gestor de tráfego pago, que muitos ignoram. Número
11, depoimento de clientes, tá? É o gatilho da prova social. É aquele
negócio, pô, você passa na frente de um restaurante, tá cheio. Aí você
pensa: "O quê? Esse restaurante deve ser ruim, não?" Você pensa, pô,
isso aqui deve ser bom, quero vir aqui um dia experimentar. Então assim,
eh, ou talvez, tá, isso pode acontecer, ou talvez você seja igual a
minha esposa, tá? que é mesmo quando a gente contrata, sei lá, uma uma
agente, uma agência de viagens, toda vez que a gente vai viajar, a
Priscila entra naquele sites lá do Booking, Trip Advisor, e ela lê todas
as avaliações das pessoas que foram lá. Tipo assim, ela lê tudo, ela lê
absolutamente todas as avaliações de todos os restaurantes, de todos os
estabelecimentos, porque ela quer ter certeza que onde a gente tá indo é
bom. depoimento de cliente. Então assim, você vê que tem pessoas que já
experimentaram produto ou serviço e que aprovaram, traz segurança pro
seu público, mostra que o negócio é confiável, mostra que o produto
funciona, mostra que gera resultado. E assim, uma das coisas mais legais
de quem trabalha com o público final é que você pode impactar
positivamente a vida das pessoas. Então, pedir, deixar os seus clientes
mandarem depoimento é bom, não só para as pessoas que estão na dúvida
entre o produto ou serviço, que estão na dúvida se o produto ou serviço
funciona ou não, mas vai ser bom para você ter um termômetro do que que
as pessoas que confiaram em você têm a dizer sobre você, tem a dizer
sobre o seu trabalho. Tem muita gente que tem medo de pedir depoimento
do cliente, mas quando você tem um bom um bom serviço, um bom
atendimento, você consome um bom produto, você não tem vontade de
indicar aquilo para as pessoas. E aí o depoimento ele pode ser, presta
atenção, ele pode ser em texto, print de WhatsApp ou em vídeo, tá? Qual
que é melhor? O melhor é você ter todos. Agora, quando você vai colher
depoimento, você sempre vai colher ele com as mesmas três perguntas. E
mais uma vez, ah, isso daqui é um conteúdinho bobo, é um conteudinho
simples. É, mas eu garanto para você, nenhum cliente seu de negócio
local colhe depoimento dessa maneira. E essa daqui é a melhor maneira de
colher depoimento. Vai gerar os melhores depoimentos para você. Você vai
perguntar como é que era a sua vida. Então, a pessoa contratou, sei lá,
um alinhamento dental. um um tratamento de alinhamento dos dentes. Eu
pergunto pra pessoa, pô, como é que era a sua vida antes de contratar o
nosso serviço de alinhamento dental? Aí depois eu pergunto pra pessoa:
"O que que te motivou a comprar o nosso serviço de alinhamento dental?"
Aí depois a pessoa vai me dizer, aí eu pergunto pra pessoa, como que
ficou sua vida depois de comprar o alinhamento dental? Por que que eu
faço isso daqui? Porque isso daqui gera um depoimento que gera
identificação com a pessoa que vai assistir esse depoimento. Isso daqui
faz com que a pessoa venda o meu produto, porque ela vai dizer os
benefícios, o que que chamou a atenção dela, o que que era muito bom. E
ela vai me mostrar como é que é a vida dela transformada. Então, até
para pedir depoimento tem técnica para fazer isso daqui direito.
Copywriting. Número 12, sessão de quebra de objeções, tá? O que que é a
quebra de objeções? Você tem que ter uma metralhadora de quebra de
desculpa, tá? Então, todo mundo sempre tem uma boa desculpa para não
comprar de você. O ser humano é uma máquina de inventar boas desculpas
para não agir. Você é uma máquina de fazer isso. Todo mundo faz isso. A
sessão de quebra de objeções, ela é justamente o momento em que você vai
mostrar pra pessoa que todas as, presta atenção, a sessão de quebra de
objeções é o momento em que você vai mostrar pra pessoa que todas as
desculpas que ela tem são pequenas demais quando comparadas ao resultado
e a transformação que elas vão ter a comprar o seu produto. Isso é a
sessão de quebra de objeções. é você já antecipar, pô, por que que
normalmente alguém deixa de comprar? Que que essa pessoa fala? Ela fala
do preço, ela fala do tempo de espera. Qual que é a objeção que ela
normalmente tem? As objeções, elas são quase sempre universais. Falta de
tempo, medo de não funcionar para mim, falta de dinheiro. Você tem que
ter uma parte da sua página que conversa com essas objeções específicas.
Número 13, quem somos nós, tá? É aquilo, pessoas se conectam com
pessoas. Mesmo que a sua você esteja divulgando uma marca que não é uma
pessoa, por trás daquela marca existe alguém, existe valores, existem
princípios. Então, uma descrição da empresa, tempo de mercado, essa hora
aqui você vai abusar muito do gatilho da autoridade para mostrar que é
que é bom, tá? Então assim, pô, ah, eu sou, sei lá, eu sou dono de uma
agência de tráfego pago, faço tráfego pago, já gerenciei mais de R$ 400
milhões deais em anúncios online, tenho mais de R50 colaboradores na
minha empresa, já passaram mais de 120.000 pessoas pelo meu principal
treinamento de tráfego pago, hoje temos mais de 55.000 alunos ativos.
Enfim, sou eu mostrando quem eu sou falando de mim. Número 14, escassez
e urgência, tá? Esse daqui são o, vou falar que são os temperos de uma
receita que converte, tá? Ele é tipo sal e pimenta, sabe? Toda página
tem que ter. Que que é urgência? Você tem que agir agora, não pode
deixar para depois. O que que é escassez? Tá acabando a janela de
oportunidade, tá? Então assim, exemplos de escassez e urgência na
prática, que que você pode fazer? Oferta por tempo limitado, apenas
hoje. Oferta válida só por mais duas 2 horas. Aproveite antes que seja
tarde, válido só por essa semana. Outra maneira, quantidade limitada.
Então, somente 10 unidades disponíveis, últimas unidades, estoque
reduzido, edição limitada e terceiro, exclusividade. Ah, apenas pros
cinco primeiros, tá? Então, isso daqui são maneiras de você ativar esse
gatilho na cabeça das pessoas. 15. bônus é aquilo, todo mundo gosta de
presente no final das contas. Então, tem algum serviço ou produto extra
que você pode colocar a mais no pacote. Muitas vezes qualquer coisa já
gera essa sensação de ganho na pessoa. 16 perguntas frequentes. Tá aqui
é o quê? É você, é você sair na frente. Como assim sair na frente?
Normalmente, dificilmente alguém tem uma pergunta nova que nunca foi
perguntada antes. A maioria das perguntas elas são iguais, tá? Então,
exemplos de FAC que você vai colocar e aí quase sempre vai funcionar,
tá? Opa, copiei errado aqui. Deixa eu pegar o contrl C aqui que são
várias perguntas, ó. Quais são as opções de pagamento? Funciona para XY,
Z? Como saber qual serviço o produto escolher? Como que funciona o
processo de contratar o serviço? Quanto tempo leva? O serviço tem algum
tipo de manutenção? Qual que é o prazo de entrega? Como rastrear meu
pedido? Vocês aceitam devoluções? O produto tem garantia? Posso trocar o
produto se eu não tiver satisfeito? Como entro em contato com suporte?
Como altera as minhas informações de entrega? Posso acompanhar o status
do meu pedido? É necessário criar uma conta para fazer uma compra? Quais
são as medidas de segurança para proteger os dados? Vocês oferecem
suporte técnico? Posso solicitar um orçamento personalizado? E aí, mais
uma vez, pô, você pode ir lá na minha página, deixa eu sair desse modo
aqui, você pode ver na minha página, você vai encontrar aqui o quê?
Perguntas frequentes. Como faço para mim escrever? Quais são as formas
de pagamento? Serve para quem quer anunciar em outros países? Quando e
onde vai chegar o seu acesso? Quanto tempo dura o seu acesso? Posso
fazer o curso pelo celular? Todas as perguntas frequentes estão aqui. A
maioria das páginas tem elas. Se você vai acumulando referências, isso
fica fácil para você. Número 17, informações de contato, tá? Todo mundo
gosta de ter para quem perguntar. Isso é real. Então assim, e-mail
comercial, WhatsApp, telefone, redes sociais, chat na página, sempre
tenha isso. Número 18, velocidade de carregamento, tá? Então, eh, toda
página ela tem uma velocidade que ela carrega. Quando eu entro na minha
página aqui, ela tem um só porque eu fui mostrar agora, ela vai demorar
para carregar. É filha da mãe, né? Deu algum problema esse negócio?
Porque ela não demora para carregar assim. Agora foi. Tá. Então, ó.
Quando eu entro na minha página aqui, olha a velocidade que ela carrega,
é menos de 1 segundo, tá? Milésimos de segundo aqui para ela carregar. A
não ser, ó, tô atualizando ela todas as vezes aqui. Então, você tem que
testar a velocidade de carregamento da sua página. Existem sites que
fazem isso, tá? Tem o pagespeed.dev, tá? Então, se eu pegar essa minha
página aqui e jogar ela aqui no pagespeed.dev e colocar um analyze, ela
vai analisar o quanto que essa página demora para carregar, tá? No
computador, no celular. Ela vai me trazer diversos dados aqui e ela vai
me trazer um diagnóstico. Ah, eu não entendi nada desse diagnóstico. O
que que você pode fazer? Copia e cola isso daqui no chat GPT, pede para
ele explicar para você. Mas qual que é a questão aqui? A maior parte dos
seus clientes, dos seus possíveis clientes tem páginas lerdas, tá? Uma
pergunta que as pessoas sempre fazem sobre página. Pedro, faço uma
página mais longa ou mais curta? Faça uma página com ou sem vídeo? Isso
é uma questão assim, eh, tem uma resposta fácil para isso daqui. Quais
são os princípios para você decidir? Primeiro, ticket. Eu tô vendendo um
carro e numa página e em outra eu tô vendendo uma caneta. Será que eu
preciso trazer tantas informações para vender uma caneta? Às vezes não.
Ah, depende da caneta, sim, depende da caneta. Tem caneta que é cara,
mas via de regra, eu se eu tem produtos que precisam de mais esforço
para vender e tem produtos que precisam de menos. Tem produtos que são
mais complexos para explicar o que que eles são do que outros. Então, a
complexidade para explicar o que você vende também conta. O número de
objeções e dúvidas que aquele produto gera, tem produto que é
naturalmente confuso, que as pessoas vão ter muitas dúvidas, isso vai
exigir uma página mais longa, tá? Mas quais são as consequências?
Páginas longas e com vídeo convertem menos. Via de regra, não é? Não é
assim sempre, mas via de regra, uma página longa e com vídeo converte
menos, mas tem uma qualidade maior de quem converte. Página curta e sem
vídeo convertem convertem a um custo mais barato, mas eles podem trazer
pessoas menos qualificadas. Então assim, não tem certo e não tem errado.
A real é, se você tá vendendo algo que é complexo de ser explicado, que
tem um ticket mais alto, normalmente você vai precisar de uma página
mais longa, você vai precisar de um vídeo, você vai precisar quebrar as
objeções. Mas no final das contas, o último elemento, elemento 20, são
os testes. Por quê? Porque só os testes eles dizem a verdade no final
das contas, tá? É só testando páginas e mais páginas e mais páginas,
fazendo variações que você vai conseguir testar todos os seus produtos,
testar todas as suas páginas e descobrir aquilo que funciona melhor e
aquilo que não funciona, aquilo que funciona melhor, aquilo que funciona
pior. A gente tá constantemente fazendo dezenas de testes de páginas
aqui. O tempo todo a gente tá variando sessões, variando headlines,
variando eh descrições, variando eh subheadline, variando texto do
botão, criando várias e várias e várias variações pra gente descobrir
aquilo que funciona melhor. Mas existem boas práticas, é isso que eu
quero dizer aqui para você. E essas boas práticas, elas foram todas
explicadas aqui. Se você pegar o conteúdo dessa aula aqui, na hora que
você for criar uma página e você pedir pra página que for criada seguir
o que eu expliquei aqui para você, pô, eu garanto para você, você tá na
frente de assim mais de 100% das pessoas que nunca fez uma página na
vida, de 100% das pessoas que nunca se deu ao trabalho de pesquisar, de
buscar, putz, o que que é uma boa página, como que se faz uma uma uma
página que funciona. E isso é a maioria das pessoas, isso é 100% dos
donos de negócios locais que não vão ficar vendo uma aula sobre como é
que faz uma página, que convenhamos, não é o assunto mais divertido do
mundo, mas, pô, você precisa desse conteúdo. Até para mandar uma
inteligência artificial fazer um bom trabalho, você precisa saber o que
você tá pedindo. Você precisa saber quais são os elementos de uma boa
página. E eu garanto para você, você compra curso da internet aí que
fala sobre construção de página. O que eles vão te ensinar lá, tá aqui,
ó, 20 pilares de uma boa página. Pega isso daqui, pede pra pessoa que
vai criar sua página, pede pra inteligência artificial criar a página
com base nisso daqui que eu te falei, não tem jeito, vai dar resultado,
vai dar resultado, vai dar resultado, tá? E aí temos o último elemento
de todos, né, que é o elemento da promessa, o último elemento do
copywriting. E a verdade é que eu perguntei pra Priscila, minha esposa,
como é que ela ensina promessas para as pessoas. E ela falou assim:
"Putz, para ensinar promessa para alguém, eu preciso de pelo menos uma
hora de conteúdo. Para ser mais exato, 1 hora 3 minutos e 40 segundos."
E aí eu tenho uma aula da Priscila que não tá disponível, que ela fala
sobre como que você faz promessas e chamadas que dão resultado, tá? Não
tá disponível essa aula, mas eu peguei essa aula e eu vou deixar ela
disponível para você na descrição desse vídeo, tá? Então, além da live
de hoje, você vai ter acesso a mais esse material para você virar um
mestre, uma mestra na criação de promessas e chamadas, tá povo? Me
despeço por aqui. Essa foi, nossa, parece até que a live foi curta, né?
Deu uma horinha, não tô acostumado a fazer a live curta. Me dispço por
aqui. Essa foi a nossa live número 373. Lembrando que essa é a live, a
continuação da live 372. Se você não viu a live 372, ela tá disponível
lá no meu canal do YouTube. Na descrição desse vídeo, você vai encontrar
o link para você assistir essa aula sobre promessas que eu vou enviar.
Meu time vai editar agora o vídeo e lembrando que você pode e deve
preencher o seu nome aqui na nossa lista de presença, tá, Pedro? O que
que é a lista de presença? Basicamente toda terça-feira, 3 horas da
tarde a gente tem uma aula ao vivo e a gente tem uma lista de presença
aqui nas nossas lives, tá? Inclusive, acho que eu vou fazer o sorteio na
semana que vem, mas toda terça-feira a gente tem um conteúdo e quanto a
gente faz um sorteio uma vez por mês e se o seu nome for sorteado, eu
consigo ver quantas presenças você tem em lives. Quanto mais presenças
você tem, melhores são os prêmios que você ganha, tá? A palavra-chave de
hoje é México, porque estamos aqui no México dando essa aula ao vivo
aqui, honrando o nosso compromisso de terça-feira às 3 horas da tarde.
Tá bom, meu povo? Tamo junto. Astaego. Nos vemos na próxima terça-feira
às 3 horas da tarde. Valeu, falou. É nós. Muito obrigado,

---
tipo: transcrição
live: 323
tema: Segmentações, públicos e palavras-chave no Google Ads em 2025
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #323

> Segmentações, públicos e palavras-chave no Google Ads em 2025

Resumo e aplicação: [[Live 323 — Segmentações, públicos e palavras-chave no Google Ads]]

---

let's go let's go let's go você está ao vivo bem-vindos bem-vindos à
nossa Live número [Música] 323 hoje senhoras e senhores subidos e
subidas dominaremos absolutamente todas as possíveis segmentações do
Google ADS e se você já me viu ensinando alguma vez na vida qualquer
conteúdo sobre tráfego pago você não só sabe você tem que saber que eu
sempre falo que um dos princípios um dos pilares do tráfego pago é a
gente escolher para quem vamos anunciar porque afinal de contas anunciar
o tráfego pago né a gestão de tráfego nada mais é do que a gente colocar
o anúncio certo na frente da pessoa certa no momento certo e levar essa
pessoa pro destino certo então se a gente consegue cumprir essas quatro
etapas do tráfego pago nós conseguimos Alcançar os nossos objetivos e
hoje falando de Google ADS nós vamos entender como que a gente faz para
organizar e criar todas as nossas segmentações Quais são as
possibilidades de segmentações que nós temos mas antes da gente
prosseguir quero saber se vocês estão me ouvindo em alto e bom som tá
funcionando aí tem gente perguntando se eu tô ao vivo seim eu tô ao vivo
eu tô sentindo que a minha câmera tá com um pouco de zoom demais será
que eu consigo tirar esse zoom aqui deixa eu ver ó ó tecn ô meu Deus a
tecnologia não tá tão boa agora ficou bom ficou melhor ficou melhor eu
gostei da eu tava tava me sentindo muito espremido aqui eu tava me
sentindo muito ah socorro E aí minha gente povo vamos lá né eu tô eu
semana passada eu eu tenho um Eu tenho um uma história para contar para
você se você tá chegando aqui pela primeira vez eu vou só pedir uma
muito breve para Não antes antes de eu pedir a licença muito breve só
para eu deixar a explicação Clara aqui sim essa daqui é a nossa Live
número 323 sim isso daqui está acontecendo ao vivo se você tá vendo a
gravação disso aí nós não estamos ao vivo né você tá vendo o a reprise a
gravação e se você entrar no meu canal do YouTube você pode perceber que
você não vai encontrar ali no canal do YouTube 323 lives você vai entrar
lá no canal do YouTube Espera aí que tô minha ferramenta para eu mexer
nos compartilhamentos de tela ela não tá não tá ligada não tá ligada vai
vai ficar desligada vai não tem problema vou fazer manualmente ah não
agora ligou ó então se você entrar aqui no meu canal do YouTube você não
vai encontrar 323 lives Mas você vai encontrar aqui mais ou menos umas
15 20 aulas gratuitas que a gente deixa disponível sempre no canal do
YouTube Pedro Por que que não estão todas as as aulas disponíveis porque
a gente tem um formato de conteúdo né um tipo de conteúdo que eu gosto
de chamar de conteúdo perecível o que que é o conteúdo perecível é o
seguinte toda terça-feira 3 horas da tarde temos uma aula ao vivo
terça-feira da semana seguinte a aula ao vivo da semana anterior sai do
ar e eu coloco no ar mais uma nova aula ao vivo né entrego ao vivo aqui
mais um conteúdo um detalhe importante os conteúdos eles não são
sequenciais Ou seja a Live 323 não é a continuação da 322 por mais que a
323 é 322 eu peguei um exemplo ruim porque elas são bem complementares
mas na maioria das vezes elas não são complementares as lives elas são
independentes e o conteúdo aqui serve Tanto para quem tá começando
quanto para quem já tá mais intermediário mais avançado na jornada por
quê Porque o foco aqui é você sempre sair da aula sabendo mais do que
você chegou se você fizer isso daqui por mais ou menos umas 8 12 semanas
o que vai dar umas 24 horas de conteúdo mais ou menos porque as aulas TM
entre 1 hora e meia e 2 horas você com certeza já vai ter nas suas mãos
muito mais conhecimento sobre tráfego pago e anúncios online do que 99%
das pessoas que já anunciam na internet porque as pessoas são
preguiçosas elas não querem estudar elas não estão dispostas a pagar o
preço ai Pedro mas você tá 5 minutos is aqui ainda você não entrou no
conteúdo sim mas é importante que a gente fique todo mundo numa mesma
página ah e tem como eu assistir as lives que já aconteceram no passado
tem aí para isso nós temos a nossa queridíssima comunidade de Sobral de
tráfego né comunidade de subido de tráfego onde você não só tem acesso à
gravação das lives como os nossos diversos cursos né cursos de tráfego
de meta e Google ADS curso de prospecção dados tracos relatórios tráfego
para negócio local tráfego para infoproduto tráfego para e-commerce e
muito mais não vou vender nada para você aqui por quê Porque as
inscrições não estão abertas Mas se você tiver interesse em saber sobre
a comunidade Sobral temos um link de lista de espera aqui embaixo
inclusive aqui embaixo você também pode deixar o like nesse vídeo se
inscrever no canal porque essas são maneiras muito fáceis de você sempre
ser avisado das aulas ao vivo eu garanto para você não é fácil fazer
aulas ao vivo todas as terças-feiras 3 horas da tarde hoje mesmo no
momento que eu tô gravando esse conteúdo eu cheguei de um voo cheguei eu
tava passei 14 horas no no avião cheguei em casa almocei rapidinho e tô
aqui ó pronto para te entregar esse conteúdo porque esse é meu
compromisso e eu sei que a vida acontece Às vezes você putz tem agenda
complicada acontece o imprevisto você não consegue estar aqui mas se
você tiver esses lembretes das aulas sempre ativado se você tiver
inscrito aqui no canal Isso facilita muito e outro canal interessante
também para você receber essa comunicação é o nosso canal de transmissão
do Instagram é basicamente uma conversa comigo no Instagram onde sempre
antes entrar ao vivo eu mando o o link da aula mas também acabo mandando
muitas vezes materiais extras exclusivos para quem tá aqui assistindo a
aula na semana que a aula aconteceu tá bom Agora sim sem mais delongas
vamos em frente e vamos começar aqui a nossa Live número 323 Como que
você faz para escolher para fazer as suas segmentações criar as suas
segmentações de públicos e palavras-chave no Google ADS em 2025 tá e eu
já deixei esse spoiler aqui para você no início mas a verdade é que um
dos grandes poderes do tráfego é a gente escolher para quem que a gente
vai anunciar para quem que os nossos anúncios vão aparecer quando a
gente tá aprendendo a anunciar em qualquer fonte de tráfego Pedro o que
que é uma fonte de tráfego Vamos dar um passo atrás né uma fonte de
tráfego nada mais é do que uma plataforma como por exemplo essa daqui
que você tá vendo Onde eu consigo subir os meus anúncios online e a
gente tem plataformas dessas de diversas ferramentas eu tenho a
plataforma e do Google ADS que vai ser a plataforma que a gente vai
trabalhar hoje temos a plataforma do meta ads temos a plataforma do
LinkedIn ads temos a plataforma do Twitter ads temos a plataforma do
Pinterest ads temos a plataforma do tiktok ads temos temos diversas
plataformas de anúncios online cada uma delas é responsável por fazer
anúncio em um determinado local Beleza beleza para você criar sua conta
nessas plataformas isso é completamente gratuito tá você não gasta nada
o que a gente paga é pra gente anunciar agora o que que eu quero que
você entenda tá E talvez esse seja um conceito bem básico para você que
tá assistindo que já entende um pouco sobre tráfego mas acho legal a
gente sempre reforçar toda vez que eu entro dentro de uma plataforma de
anúncios online nós temos que explorar a estrutura desta plataforma
Pedro Como assim a estrutura dessa plataforma por exemplo se eu entrar
lá no meta ads ou no Google ADS eu vou ver que eu tenho três grandes
estruturas para colocar o meu anúncio no ar eu tenho campanha dentro da
campanha eu tenho grupos de anúncio e dentro do grupo de anúncio Eu
tenho meus anúncios é como se fosse uma pasta dentro do seu computador
então eu tenho uma pasta maior Onde tá a campanha dentro dessa pasta
maior eu tenho vári as pastas menorzinhas que são os grupos de anúncio e
dentro dessas pastas Menorzinha eu tenho outras pastinhas que são os
anúncios cada uma dessas estruturas é responsável por uma coisa então o
que que a campanha ela é responsável quando a gente tá falando de Google
ADS quando a gente vai criar a nossa campanha a gente vai definir por
exemplo o porquê que nós estamos fazendo aquele anúncio Qual que é o
nosso objetivo eu vou definir o quanto que eu vou gastar e eu vou fazer
uma eu vou fazer a def ição das configurações Gerais então por exemplo
em que horário que o meu anúncio vai aparecer Qual que é a minha
estratégia de lance detalhes menores tá E aí fica já a indicação aqui
para você a Live número 322 ela vai ficar disponível aqui no nosso canal
do YouTube durante um tempo você que tá assistindo a este conteúdo aqui
você pode acessar na descrição o link da Live número 322 porque nela eu
faço uma bela de uma explicação sobre quatro tipos de campan e eu
acredito se quiser eu crio quatro campanhas na sua frente aqui durante
essa aula então é uma aula bem prática mesmo para você ter o primeiro
contato com essas campanhas do Google ADS tá então toda essa parte de
como fazer essas configurações tudo isso é explicado Foi explicado nessa
Live que você tem acesso com o link na descrição agora o grupo de
anúncio eu vou fazer a definição do para quem então para quem que eu vou
anunciar e o anúncio É claro é o que que eu vou anunciar então quando a
gente você pode esquecer por enquanto das configurações Gerais fica
muito fácil da gente identificar as estruturas e entender para que que
cada uma serve a campanha eu vou definir o por e o quanto o grupo de
anúncio eu vou definir o para quem e o anúncio eu vou definir o o qu e
isso daqui eu tô falando de Google ADS e tô falando de meta ads também e
tô falando de tiktok ads também Pedro e LinkedIn ads já é um pouco
diferente por quê Porque o Linkedin ele quis meter uma de diferentão E
aí ao invés de de ter a campanha e o grupo de anúncio ele tem a campanha
e o conjunto de campanhas assim desnecessário Desnecessário mas é
basicamente a mesma coisa que que eu quero dizer para vocês isso é um
conceito um pouquinho mais e não não avançado mas é um pouquinho mais
intermediário que é quando você vai explorar uma nova fonte de tráfego
pago Qual que é a primeira coisa que você tem que fazer você tem que
entender as estruturas dessa fonte de tráfego pago assim quando você
começa a entender que essas estruturas elas são bem repetidas em todas
as plataformas você entende que você consegue subir anúncios em qualquer
plataforma porque a base o princípio é o mesmo a fundação é a mesma Você
tá entendendo Tá fazendo sentido para você ou eu tô indo muito longe
viajando muito na maionese o fuso horário na minha cabeça você não tem
noção na minha cabeça agora são 8 horas da noite no fuso horário que eu
tava e e eu tava me adaptando ao fuso horário chegou a hora de voltar
para casa mas táa fazendo sentido essa exploração das estruturas amanhã
se eles lançarem Sei lá o Apple ads os anúncios da Apple do iPhone Sei
lá eu vou dominar os anúncios em poucos minutos poucos minutos
literalmente minutos porque Qual que é a primeira coisa que eu vou fazer
quando eu explorar uma fonte de tráfego nova eu vou entender as
estruturas agora eu tô aqui para te explicar essas estruturas e deixar
isso muito mais fácil para você e aqui no caso a gente não tá falando
hoje sobre criação de anúncios e nós não estamos falando sobre campanhas
a gente tá falando sobre 13 aqui do processo de anunciar na internet que
é escolher o nosso Para quem para quem nós vamos anunciar para quem que
os meus anúncios vão aparecer se a gente conseguir definir isso com
maestria a gente já tá assim é 1/3 do caminho andado a gente pode dizer
isso porque são três estruturas agora quando a gente tá falando de
Google ADS e eu vou botar a mão na prática aqui com você já já tá eu vou
abrir aqui vou vou entrar nas ferramentas na biblioteca compartilhada no
gerenciador de público alvo vou brincar aqui vou te explicar tudo como é
que funciona como é que você cria suas segmentações e quais você deve
utilizar agora pra gente entender isso vamos desenvolver juntos uma base
teórica por quê Porque se eu desenvolvo com você uma base prática já
saio clicando nos botões e Ah beleza agora eu sei criar segmentações se
eu já saio clicando nos botões que que acontece você vai virar um
papagaio que que um papagaio sabe fazer sab imitar ah clica aqui clica
aqui clica aqui clica aqui clica aqui o papagaio Ele só sabe reproduzir
ele só sabe reproduzir aquilo que foi ensinado agora quando a gente
entende a base prática essas segmentações elas podem mudar no futuro e
você ainda assim vai saber mexer em todas elas por quê Porque você
entendeu a base teórica Qual que é a base teórica é o seguinte no Google
a gente tem dois tipos de públicos que existem tá então segundo Google
ADS a gente pode encontrar as pessoas de duas formas diferentes primeira
maneira é através do conteúdo que eu escolho onde que eu quero aparecer
Pedro Como assim ao invés de escolher Ah eu quero aparecer desculpa para
mulheres que tê entre 25 e 35 anos moram na cidade de Campinas e
adotaram um cachorro recentemente Eu quero aparecer para essas pessoas
responde para mim responde no chat eu estou dizendo onde que eu quero
aparecer eu tô dizendo E assim eu não tô falando que eu quero onde que
eu digo não é na na na região de Campinas não é a localização física mas
na internet eu tô dizendo em qual vídeo que eu quero aparecer eu tô
dizendo Em qual site que eu quero aparecer eu tô dizendo em qual
pesquisa que a pessoa tá fazendo eu quero aparecer não eu tô só dizendo
o público que eu quero atingir quero atingir mulheres de 25 a 35 anos
que estão na região de Campinas agora se essa mulher vai est vendo um
vídeo sobre culinária um vídeo sobre moda ou um sei lá um um vídeo de
tráfego pago eu não sei o que tipo de conteúdo que ela tá vendo Então eu
não tô segmentando pelo conteúdo quando eu segmento pelo conteúdo eu
escolho onde que eu quero aparecer eu escolho assim pô ao invés de falar
Ah eu quero aparecer para mulheres de 25 a 35 anos que moram em Campinas
e tão sei lá eh adotaram um cachorro recentemente eu vou escolher o
seguinte Olha eu quero aparecer em conteúdos que tem essas determinadas
palavraschave Eu quero aparecer em canais e vídeos determinados canais
de vídeos em vídeos que falam sobre X em vídeos que falam sobre y Eu
quero aparecer Emer e em conteúdos que falam sobre determinados temas Eu
quero aparecer em determinados site então eu tô escolhendo a localização
de onde o meu anúncio vai ser mostrado Então vamos dizer que eu tenho
uma marca e de produtos Pet Eu posso sei lá aparecer num vídeo de qual é
a melhor ração ao invés de Querer aparecer para pessoas em uma com uma
um determinado perfil eu posso aparecer no vídeo do nove melhores rações
para comprar em 2025 porque a pessoa que tá vendo esse vídeo aqui ela
tem interesse Ela deve ter um um cachorro Ela deve ter adotado um
cachorro recentemente então eu tô indo no conteúdo que essa pessoa tá
pesquisando eu posso aparecer na pesquisa do Google de Qual ração
comprar para e Golden sei lá e aí vai vai aparecer aqui para mim ó
poderia ter um anúncio aqui não tem aliás tem alguns patrocinados aqui
do Google shoping mas poderia ter algum anúncio aqui para eu aparecer
nessa pesquisa então eu não tô escolhendo Para que tipo de pessoa que eu
quero aparecer eu tô escolhendo em que tipo de conteúdo que eu vou
aparecer a seg segmentação de conteúdo presta atenção em mim ela é uma
segmentação que a gente chama internamente né não é o nome que o Google
dá mas que eu chamo de intenção porque eu vou aparecer em conteúdos que
demonstram uma determinada intenção do meu público alvo e esse daqui é
um dos grandes superpoderes que o Google tem e que nenhuma outra
plataforma tem o Google é a ferramenta que mais consegue segmentar
através de conteúdo agora o Google não é só conteúdo o Google também tem
o segundo tipo de segmentação que é a segmentação de pessoas o que que é
a segmentação de pessoas se no conteúdo eu escolho onde eu vou aparecer
com a segmentação de pessoas eu vou escolher para quem eu vou aparecer
então aqui sim eu vou fazer por exemplo uma segmentação demográfica Vou
definir idade gênero Que setor que a pessoa trabalha Qual que é a
formação dela se ela tem filho se ela não tem filho renda quanto que
essa pessoa ganha Vou definir interesses que a pessoa tem então há
pessoas que estão interessadas no assunto x que estão interessadas no
assunto Y comportamentos que a pessoa tem abriu uma empresa recentemente
adotou um cachorro se casou se mudou recentemente que que essa pessoa tá
fazendo na vida dela pessoas que já interagiram comigo então eu por
exemplo você que tá assistindo esse vídeo aqui já vou te dizer um
negócio sinto muito você vai ver os meus anúncios não não tem jeito não
tem como fugir não tem como fugir eu vou aparecer para você porque você
tá interagindo com um conteúdo meu e eu anuncio para pessoas que já
interagiram com algum conteúdo meu e posso aparecer também para
determinados segmentos personalizados que que são segmentos
personalizados eu posso aparecer para todas as pessoas que já fizeram
uma busca X no Google eu posso aparecer para todas as pessoas que
acessaram um determinado site pode ser do meu concorrente eu posso
aparecer para todas as pessoas que tem um determinado aplicativo no
celular então aqui eu estou escolhendo eu não vou aparecer no aplicativo
do celular eu não tô escolhendo Ah eu quero aparecer nesse aplicativo
não eu tô escolhendo aparecer para pessoas que tem esse aplicativo no
celular tá fazendo sentido fala para mim conversa comigo por favor que
eu tô carente faz tempo que eu não faço na semana passada eu tava voando
no momento da Live eu tive que que eu gravei a aula um dia antes para
transmiti-la para vocês hoje eu tô ao vivo tô com saudade de vocês tá
fazendo sentido tá fazendo sentido ótimo fechou Beleza então temos os
dois tipos de segmentação Agora presta atenção em mim agora quando nós
estamos falando quando nós estamos falando de Google ADS nós temos 10
tipos de maneiras que eu consigo segmentar conteúdo 10 tipos de maneiras
que eu aliás é 10 tipos de maneiras que eu consigo fazer segmentações de
conteúdo e de pessoas Pedro Como assim olha eu posso fazer uma
segmentação baseada em afinidade eu posso fazer uma segmentação baseada
em segmento personalizado eu posso fazer uma segmentação baseada em e
dados DDD né que eu gosto de chamar dados demográficos detalhados eu
posso fazer uma segmentação só por dados demográficos eu posso fazer uma
segmentação por público alvo de mercado eu posso fazer diversos tipos eu
posso fazer uma segmentação de palavraschave eu posso fazer diversos
tipos de segmentações O que que é uma segmentação alguém me responde no
chat e é importante que você Gere essa clareza a gente tá aqui
justamente para aprofundar nos conceitos básicos porque o tráfego quando
você olha básico é escolher objetivo é definir orçamento são as
configurações Gerais é definir para quem que nós vamos anunciar e o que
que a gente vai anunciar trfego é isso a gente consegue Ruz o trfego
aisas bsicas só que o interessante é é a gente saber o básico com
profundidade o que que é a segmentação ó eu gostei da resposta do luí
panizo panizo panizo não sei como é que fala deixa eu vou colocar aqui ó
é um filtro é um filtro é o direcionamento gostei gostei identificar
tipos de pessoas segmentar é definir detalhes do público alvo é
direcionar os leads ó o que que pensa na Essência O que que é um
segmento um segmento é um pedaço não é um pedaço Ah um segmento por
exemplo eu vou tirar um segmento deste papel aqui eu eu tenho todo esse
papel aqui vamos dizer que isso daqui é o público de pessoas do Brasil
esse papel representa todas as pessoas do Brasil o que que é segmentar
segmentar nada mais é do do que eu pegar por exemplo um pedacinho deste
público e ao invés de anunciar aqui ó tá me vendo eu sou uma criança ao
invés de anunciar para todas essas pessoas aqui de olho no buraco do
Sobral ao invés de anunciar para todas essas pessoas aqui eu vou
anunciar para um segmento dessas pessoas por quê Porque eu não vou
desperdiçar o meu dinheiro aparecendo para todo mundo eu quero aparecer
para as pessoas certas Eu quero aparecer para as pessoas deixa eu tentar
dar o foco aqui pô Olha esse foco olha esse foco Caraca tá dando foco
até no meu relógio Ó que bonito tá então isso é um segmento é a gente
filtrar é eu escolher uma pegar um determinado pedaço de público para
aparecer somente para as pessoas mais interessantes agora existem existe
no Google ADS existem ou existe no Google ADS tem 10 maneiras de nós
segmentos Então tá vendo que eu peguei esse segmento aqui eu tenho
outras maneiras eu tenho várias maneiras de escolher este segmento aqui
E é isso que eu vou te ensinar agora como é que a gente faz na prática
beleza Qual que é a primeira maneira e para mim assim é você tem que
dominar isso daqui você você precisa não é que assim você você vai
anunciar na internet você leva o tráfego pago a sério não tem como você
não saber fazer uma boa segmentação de palavras-chave não tem como ai
Pedro mas eu já sei fazer pô mas aí que tá toda vez toda vez toda na
minha vida quando eu dou consultorias de tráfego pago a pessoa vai lá e
me paga R 100.000 uma consultoria de tráfego pago vou lá fazer a
consultoria pra empresa chego junto com a empresa vou olhar o que ela tá
fazendo ela falou assim não Google ADS a gente Domina quando eu entro
sempre tem problema nas palavraschave e é sempre problema básico é
problema da pessoa que não revisou com tanta intensidade esse
conhecimento tá e quando a gente tá falando de palavraschave nada mais é
do que a gente escolher para quais pesquisas nós vamos aparecer então eu
vou escolher para quais pesquisas eu vou aparecer e aí eu posso aparecer
presta atenção agora eu vou complicar sua cabeça eu posso aparecer no
momento da pesquisa ou seja isso é uma segmentação de conteúdo porque eu
eu tô escolhendo em qual conteúdo que eu quero aparecer eu quero
aparecer no momento da pesquisa ou presta atenção eu posso escolher
aparecer no eu posso escolher aparecer é em conteúdos que contém
determinadas palavras também é uma segmentação de conteúdo ou eu posso
aparecer agora eu vou segmentar pessoas eu posso aparecer para pessoas
que fizeram determinadas buscas só que eu não tô escolhendo Ah eu vou
aparecer quando a pessoa tá fazendo essa busca não a pessoa pesquisou
tráfego pago alguma vez na vida eu vou aparecer para ela no YouTube
depois de amanhã quando ela tiver vendo sei lá a música da María
Mendonça vai aparecer meu anúncio para ela e ela pesquisou sobre tráfego
pago tem sete dias semana seguinte eu tô aparecendo para ela então eu
não tô segmentando o conteúdo eu não escolhi quero aparecer no vídeo da
Marília Mendonça não eu escolhi quero aparecer para a pessoa que já fez
essa pesquisa tá então aqui é uma segmentação de público alvo tá
explicação Zinha rápida só para você entender o qu quando eu aprendo a
segmentar palavras chave eu vou escolher para quais pesquisas eu vou
aparecer eu vou escolher em quais conteúdos eu vou aparecer porque eu
posso aparecer para determinados conteúdos que estão no YouTube Eu não
sei se você já viu cara eu ontem aconteceu uma coisa muito louca eu fui
no YouTube e eu tava eu tava pesquisando sobre visual Hook aí eu digitei
visual Hook E aí ele apareceu esse vídeo desse cara aqui para mim E aí
só que ag agora não aconteceu acho que é porque eu tô na porque eu já vi
o vídeo não porque eu tô na aba anônima mas ele me levou exatamente pro
lugar do vídeo onde a pessoa falava sobre visual Hook exatamente ou seja
o YouTube leu que no vídeo da pessoa tinha aquela determinada palavra
ele entendeu que no meio do vídeo o cara falava essa determinada palavra
E aí eu cliquei no vídeo e ele me levou pro exato momento vídeo onde o
cara tava falando sobre o assunto que eu tava pesquisando bizarro então
se eu coloco a palavra eh visual Hook no meus no meu na minha
palavra-chave eu posso aparecer no vídeo desse cara porque eu tô
escolhendo em quais conteúdos eu vou aparecer eu quero aparecerem
conteúdos que contém aquela determinada palavra e eu vou escolher também
para Quais pessoas que já fizeram uma pesquisa eu vou aparecer então
segmentar palavra-chave é muito mais do que que anunciar só no Google é
muito mais do que aparecer só aqui na rede de pesquisa é muito mais
porque a gente vai aparecer no YouTube a gente vai aparecer em todos os
lugares o poder de segmentação de palavra-chave ele é brutal agora como
que a gente segmenta palavra-chave Existem três tipos de palavra-chave
ampla palavra-chave de frase e palavra-chave exata tá são os três tipos
de palavra-chave antigamente tinha mais uma né eu a chave elá melhor de
todas mas o Google sei lá porque ele tirou fora acho que as pessoas não
sabiam usar Mas qual que é a diferença desses três tipos de palavra
chave é na maneira que eu vou colocar elas dentro do Google ADS então eu
posso anunciar para comprar geladeira posso anunciar para comprar
geladeira entre aspas e posso anunciar para comprar geladeira entre
colchetes quando eu anuncio a palavra-chave Ampla eu tô dizendo pro
Google Google encontra e anuncia para palavras chaves semelhantes à
minha então eu tô falando eu tô dando uma ideia para ele ó é comprar
geladeira Então se alguém pesquisar Comprar geladeira Eletrolux eu posso
aparecer se alguém pesquisar Comprar geladeira eu posso aparecer se
alguém pesquisar comprar refrigerador eu posso aparecer tudo que tá em
verde aqui o que eu posso aparecer agora o que que é a a a
correspondência de palavra-chave de frase é quando eu digo encontra
pesquisa que contenham a minha palavra-chave nesta ordem ou seja se a
pessoa pesquisar Comprar geladeira Eletrolux eu posso aparecer porque na
busca dela tinha Comprar geladeira se a pessoa pesquisar comprar
refrigerador eu não vou aparecer se a pessoa pesquisar geladeira comprar
eu não vou aparecer por qu porque tem que ser Comprar geladeira e não
geladeira comprar então não vou aparecer se a pessoa pesquisar quero
comprar geladeira grande eu posso aparecer por quê Porque tem que
comprar geladeira no meio da pesquisa da pessoa se a pessoa pesquisar
somente Comprar geladeira eu posso aparecer porque tem que comprar
geladeira na pesquisa da pessoa tá então é é só para você entender como
que isso daqui funciona agora a correspondência exata é a mais simples
né é encontre pessoas que pesquisaram exatamente a minha palavra-chave
então a pessoa tem que ter pesquisado Exatamente isso daqui e aí eu vou
aparecer para comprar geladeira Eletrolux vou aparecer para comprar
geladeira vou aparecer Aliás não vou aparecer para comprar geladeira
Eletrolux Desculpa vou aparecer para comprar geladeira porque a pessoa
digitou exatamente a minha palavra-chave não vou aparecer para comprar
refrigerador não vou aparecer pra geladeira comprar não vou aparecer
para quero comprar uma geladeira grande então a palavra-chave Ampla Por
que que ela é boa ela é boa por qu porque o Google vai me dar ideias de
pesquisas que eu nem tinha pensado então tem gente que tá anunciando
geladeira mas não se ligou que ao invés de geladeira você poderia usar a
palavra refrigerador E aí o Google vai vai mostrar você numa pesquisa
que é boa só que quando a gente tá começando e a gente tá sem dinheiro
você tem que fazer o quê focar nas palavras Ch de frase e exata por
Porque da mesma maneira que o Google pode me mostrar para comprar
refrigerador Ele pode aparecer para mim para comprar um freezer ou
comprar um ar condicionado que gela posso aparecer ele pode viajar na
maionese e me mostrar para coisas que não tem nada a ver então da mesma
maneira que ele funciona pro bem ele funciona pro mal né com grandes
poderes vem grandes responsabilidades uncle Ben então assim aqui para
quem tá começando o ideal é ir de palavras exatas e palavras de frase
como que a gente cria uma lista de palavras chave tá eu poderia passar
assim duas horas falando sobre isso mas eu vou ser o mais simples
possível aqui pra gente ganhar tempo Primeiro Use a cabeça o que que a
sua audiência pesquisa o que que eles Digitam no Google segundo use o
answer the Public tem outra ferramenta que chama also ased USA eh tem
uma que chama same Rush que são ferramentas que vão te ajudar a montar
essa lista de palavraschave para mim não tem melhor do que o answer the
Public é muito bom o o new patel que foi o cara que comprou essa
ferramenta ele é gênio porque você entra aqui no answer the Public Tá eu
vou mandar o esse link lá no meu canal de transmissão do do Instagram o
link para entrar no canal tá na descrição E aí aqui eu vou colocar ó
Comprar geladeira aí eu boto a palavra-chave Brasil português pesquisar
joguei aqui ó e ele vai começar a compilar para mim o que que as pessoas
estão pesquisando sobre Comprar geladeira tá então como tem 1081
resultados talvez demore um pouquinho ele quer que eu me cadastra agora
não quero me cadastrar ó ele vai me mostrar aqui ó Comprar geladeira 110
ou 220 Comprar geladeira branca ou inox Comprar geladeira nova é melhor
geladeira aí ele vai me dar tudo aqui ó tudo aquilo que as pessoas
pesquisam sobre esse assunto tudo tá eu gosto muito do tables aqui acho
que essa daqui é esse daqui para mim é o melhor de ver porque ele
aparece aqui ó todas as pesquisas de comprar geladeira com como como
comprar geladeira barata como comprar geladeira direto na fábrica como
comprar geladeira no carnê Então imagina que a pessoa pesquisa como
comprar geladeira direto na fábrica aparece meu anúncio para ela
procurando geladeira nova com preço de fábrica Pô acabou ganhei o clique
E aí todas as pesquisas que as pessoas fazem e ainda o Google Med o o
answer the Public né a versão eh gratuita dele ele vai mostrar em alguns
lugares se você fizer o cadastro ele mostra em mais mas eu consigo aqui
ó pegar aqui por exemplo Putz Cadê meu mouse tá aqui deixa ver deu eu
consigo pegar aqui por exemplo Ixe Descarregou o meu trackpad tudo bem
mas eu consigo ver aqui ó que é o quanto que custa para anunciar para
essa palavra-chave esse valor tá em dólar tá mas eu tenho o custo aqui
tem alguns que não vão aparecer e aí eu tenho que começar o teste
gratuito mas para mim o melhor dessa ferramenta são as ideias de busca é
infinito qualquer pessoa que sentar aqui gastar 20 minutos colhendo boas
palavras chaves para anunciar Pô você vai fazer você vai ter uma lista
de palavras chaves melhor do que 99% dos anunciantes profissionais que
estão anunciando Comprar geladeira tá temos também o also ased que é o
também perguntado né E aqui ele vai nos dar ideias é de Pesquisas então
eu posso jogar aqui ó Comprar geladeira ele fala para eu jogar uma
palavra só ou duas Pera aí que eu não me lembro tá tá certo aí eu vou
mudar aqui para português vou mudar pro Brasil E aí eu vou dar uma
pesquisada aqui e aí ele vai me entregar pesquisas é perguntas que as
pessoas fizeram na internet sobre Comprar geladeira ele demora um
pouquinho aqui mas ele vai carregar tá Ah não agora ele foi foi rápido ó
qual geladeira mais barata e boa então ele vai me dar aqui ó todas as
pesquisas que as pessoas estão fazendo sobre isso Qual a nova regra do
nova regra do governo para gel Qual a melhor marca de geladeira que não
dá problema ó que legal geladeira que não dá problema já sei que é uma
pesquisa que as pessoas fazem Quais são as três melhores marcas de
geladeira tá aqui isso aqui é muita ideia de conteúdo também Mais até do
que de pesquisa ideia de palavra-chave tá aqui no no answer the Public
isso daqui para mim é é bizarro e você pode usar o próprio Google ADS O
próprio Google Ad Por que tem umas palavras que ficaram pequenas palav
ficaram grande Agora sim você pode O próprio Google ADS quando você
entra lá no Google ADS você vem aqui na parte eh de ferramentas Opa
entra aqui na na aba lateral ferramentas planejamento aí você vem no
planejador de palavra-chave abriu aqui o planejador de palavra-chave ele
vai abrir aqui duas opções descobrir novas palavras-chaves ver volumes
de pesquisa então sabe esse volume de pesquisa aqui ó isso aqui são é o
número de buscas feitas tá então volume de buscas por deve ser por mês
isso daqui e o quanto que custa para anunciar essa palavra-chave o
Google me entrega isso aqui de graça tá então se eu jogar aqui ó Comprar
geladeira e eu posso colocar um site para filtrar palavras-chaves
relacionadas então ó Comprar geladeira geladeira nova geladeira inox E
aí eu vou inserir aqui palavraschave um site eu posso colocar o site do
meu concorrente aqui aí eu vou ver resultados e ele vai gerar para mim ó
quantas busc estão sendo feitas por essas palavras e aí ele vai me dizer
ó média de Pesquisas mensais e lance na parte superior da página maiores
valores então quanto que eu tenho que botar de lance na minha campanha
para aparecer e aí ele vai começar a me dar várias outras ideias ó
ideias e mais ideias aqui ó ele tá me dando 5874 ideias é que ele tá
mostrando 10 linhas eu posso botar para me mostrar 500 linhas aqui ó e
aí ele vai me dar infinito eu posso ordenar pela média de Pesquisas
mensais Ah eu vou ver primeiro só o que mais tem pesquisa geladeira em
promoção promoção geladeira geladeira na promoção geladeira frost free
inox geladeira inox Frost Free geladeira Casas Bahia ó Casas Bahia tá
bombando número de litros de geladeira e aí eu vou jogando aqui ó aí eu
posso refinar ó com marca ou sem marca Ah não eu não quero marca na
minha palavra-chave não eu quero marca ó brast TR Eletrolux ele vai me
dar um um monte com monte um monte um monte um monte de sugestão para eu
ir filtrando as minhas palavras-chave é só você investir alguns minutos
30 40 50 minutos que você investe você consegue montar uma lista boa de
palavraschave com isso daqui tá E aí fica aqui é um um dois PSS né PS1
quando tiver começando quanto mais específico melhor então ah ao invés
de jogar dentista você vai anunciar para dentista em sei lá Campinas
dentista em São Paulo em Moema em Londrina comprar XY Z contratar
orçamento arrumar então você vai e usar palavras que demonstram o quê
uma intenção de compra Então você vai usar palavras como comprar pedir
contratar arrumar consertar técnico especialista orçamento adquirir
endar obter serviço agendar porque são palavras que estão demonstrando
que a pessoa quer comprar e PS número 2 cria uma lista de palavras
chaves negativas tá então eu tenho uma lista aqui que eu venho
colecionando ela ao longo dos anos tá então vai ter aqui e sem custo
barato por contra própria Econômica caseira grátis grátis gratuito de
graça gratuitamente na faixa na faixa consignado template planilha
modelo exemplo como o que o que por que aonde quando Qual senha login
carreira emprego a contratação estagiário estágio emprego recrutador
recrutamento currículo sobre definição comparação diagrama exemplo
história mapa amostra modelo versão O que é qual onde aí você tem que
ver o que que faz sentido pro seu negócio mas ess essas daqui são
normalmente palavras chave que Muitas delas você vai criar como negativa
por quê Porque tão importante presta atenção nisso tão importante quanto
escolher para quem anunciar é escolher para quem não anunciar tão
importante Quando escolher para quem anunciar é escolher para quem não
anunciar e a gente tem que fazer essa definição quando eu consigo fazer
essa definição bem feita pô ficou horrível essa cor né Acho que azul e
vermelho vai ficar melhor eu vou botar pretinho mesmo e vou botar só um
não em vermelho Esse sou eu conversando comigo mesmo no meio da aula
agora sim é que ele ficou Agora vai ficar melhor não não tá bom ainda né
achei que ficou talvez agora acho que agora ficou bom acho que ficou
mais organizado tá então tão importante Quando escolher para quem
anunciar é escolher para quem que você não vai anunciar E aí com isso a
gente monta uma lista de palavras-chave para quê para aparecer na
pesquisa do Google não ag a partir de agora quando alguém te perguntar
para que que serve uma lista de palavraschave isso daqui povo Eu garanto
para você eu assim ó eu boto a minha mão no fogo você pergunta para
qualquer pessoa que já anuncia no Google montar uma boa lista de
palavraschave serve para quê a maioria das pessoas vai parar aqui ó
maioria das pessoas vai parar aqui ó escolher para quais pesquisas eu
vou aparecer mas Não é só isso eu monto lista de palavra-chave para
escolher para quais conteúdos eu vou aparecer e para Quais pessoas que
já fizeram uma pesquisa que eu vou aparecer que para mim é o mais
poderoso e ninguém fala sobre isso a maioria das pessoas não usa isso é
muito louco é muito louco que a maioria das pessoas não sabe que isso
que isso serve para isso por isso que elas não tem resultado no Google
tá então ela serve para essas três coisas vou até botar aqui ó 1.1 1.2 e
1.3 só que a mesma lista de palavras-chave que eu criei para o 1.1 que
eu vou usar pro 1.3 Beleza Pedro acabou por aí não por quê Porque eu vou
pro segundo tipo de segmentação que é a segmentação de canais e vídeos
Qual que é a sugestão que eu dou para você aqui a sugestão é crie uma
lista de vídeos e canais de primeiro concorrentes segundo não
concorrentes mas a sua audiência consome Sei lá eu descobri uma época
que a minha audiência consumia muito conteúdo é de vídeo de motivação na
internet aí eu passei a colocar os meus anúncios não só em concorrentes
que falavam de tráfego pago Mas comecei aparecer também nos vídeos de
motivação porque eu sabia que a minha audiência consumia muito aquele
tipo de conteúdo então é monta uma lista dos canais mais óbvios que
falam sobre o assunto que você fala e aí quando digo monta uma lista é
assim ó gaste horas fazendo isso gaste um bom tempo mapeando todos os
canais que falam sobre aquilo que você fala todos os canais que falam
aquilo sobre aquilo que você fala e aí vou te dar um exemplo no passado
por exemplo eh eu anunciava um curso de inglês e aí eu lembro que um dos
vídeos que mais fez a gente ganhar dinheiro foi um vídeo do Felipe Neto
sobre aprender inglês e eu não anunciava no canal del ele mas eu
anunciava nesse vídeo aqui nesse vídeo aqui eu rodei muito anúncio
especificamente então eu posso montar uma lista de canais e de vídeos Ah
se eu quero aparecer em todos os vídeos de um canal só o canal basta se
eu quero aparecer somente em um vídeo daquele canal o link do vídeo e aí
você monta tudo isso numa planilha e isso vai ser útil Para quê Para que
que vai Isso aqui vai ser útil para eu fazer a segmentação e aqui Aqui
tá o segredinho Esse é o segredinho esse aqui é o segredinho que você
não encontra nos cursos de tráfego pago que é o seguinte para que que
serve a segmentação de canais e vídeos a maioria das pessoas vai parar
aqui ó 2.1 escolher em quais vídeos Eu quero aparecer Isso é uma
segmentação de qu de conteúdo eu tô escolhendo em quais vídeos Eu quero
aparecer beleza mas olha aqui olha olha olha ol a rataria a malícia a
sagacidade eu posso fazer o seguinte eu posso criar anúncio eu posso
criar uma segmentação que chama segmento personalizado aqui ó eu vou
rapidamente mostrá-la para você então e a gente já vai entrar aqui no
gerenciador de público alvo mas aqui no gerenciador de público alvo eu
posso abrir aqui os segmentos personalizados e eu posso criar um público
de segmento personal de pessoas que navegam por determinados sites eu
posso anunciar pessoas que navegam em determinados sites o que que
acontece eu tava pensando o seguinte um dia PR o Google saber qual o
site que a pessoa navega essa pessoa ela tem que ter instalado no seu
próprio site vou aí um pouquinho mais avançado agora aqui com você pra
pessoa e pro Google saber em qual site que a pessoa navegou a pessoa
precisa ter instalado no seu próprio site O quê Fala para mim no chat o
que que ela tem que ter instalado no próprio site o Pixel o Pixel do
Google exatamente o Pixel mas aí eu parei e pensei o seguinte ué mas o
YouTube não é do Google o YouTube é do Google aí o eu parei e pensei o
seguinte hã E se eu pegar todos os links de vídeos dos Meus concorrentes
e eu criar um segmento personalizado com os links dos vídeos do meu
concorrente Porque o Google não precisa ter pixel no Google o Google é o
Google o Google é dono do Google então o que que eu faço e é uma das as
melhores segmentações eu tô te entregando aqui tá eu eu crio um público
de pessoas que já visualizou determinados vídeos e é uma segmentação de
público alvo então eu eu não vou anunciar nos vídeos não vou aparecer no
vídeo mas eu vou anunciar para todo mundo que já viu aquele vídeo Porque
o Google é o Google o Google é dono do Google o Google sabe a pessoa que
acessou aquele determinado vídeo E aí eu falei Ah beleza isso na teoria
é lindo mas na prática Funciona porque é exatamente isso que eu faço em
várias das minhas segmentações eu pego canais por exemplo Ó você vai ver
aqui ó canais de tráfego e marketing digital aí eu tenho um público que
tem todos os links dos canais de tráfego e marketing digital todos eles
estão aqui e aí quando eu vou ver a segmentação é exatamente o público
que eu quero atingir e é um dos meus públicos que mais converte bizarro
é bizarro tá aqui tava na sua cara o tempo todo tá então montar uma
lista de canais e vídeos não é só escolher em quais vídeos eu vou
aparecer mas muito mais interessante é criar um público de todo mundo
que já viu aqueles vídeos instalar de dedos ah mas eu não tenho canal do
YouTube beleza seu concorrente tem você pode anunciar para todo mundo
que viu os vídeos dele o Google é muito filho da mãe o Google é o filho
da mãe e eu acho genial e tá aqui na sua cara o tempo inteiro vamos lá
próximo tipo de público é o público de temas que que é o público de
temas o público de temas ele é um público de conteúdo é uma segmentação
de conteúdo tá então lembra dos dois tipos de segmentação é uma
segmentação de conteúdo porque eu vou eh escolher dentro de uma lista
assuntos de vídeos e conteúdos onde eu quero aparecer então lá quando eu
for criar a minha campanha Deixa eu só abrir aqui numa numa outra aba
quando eu vou criar minha campanha no Google ADS E aí eu não vou te
ensinar a criar a campanha aqui agora mas eu vou só fazer um exemplo
aqui para para mostrar como é que fica quando eu vou criar a minha
campanha aqui vai chegar um momento que eu vou ter que escolher a minha
segmentação E aí quando eu vou escolher minha segmentação aqui no Google
ele vai me dizer Olha você quer fazer sua segmentação por público alvo
ou por conteúdo e aqui no conteúdo eu tenho temas né que antigamente se
chamava tópicos então eu vou escolher aqui eu tenho uma lista de vários
temas Nos quais eu posso anunciar então eu posso anunciar ó em
comunidades online que que é comunidades online é compartilhamento de
vídeos e fotos Fórum de bate-papo mercadoria online mundos virtuais
recursos de serviços de blogs emprego e educação eu posso anunciar em
conteúdos que falam sobre emprego sobre recursos e planejamentos de
carreira então eu vou aparecer em todos os conteúdos que falam sobre
esse assunto isso é a segmentação de temas é eu escolher o tipo de
conteúdo que eu vou aparecer eu não tô escolhendo eu não tô tô dizendo
Ah eu quero aparecer para pessoas que tem interesse nesse assunto não eu
quero aparecer em conteúdos que estão falando sobre esse assunto então
eu quero aparecer no vídeo que fala sobre isso e aí a gente vai ver aqui
ó 150 a 200 milhões de pessoas estimativa com Brasil tá então aqui eu
vou vou montar essa lista de temas E aí é você pesquisar e ver o que faz
mais sentido para você quarto tipo de segmentação segmentação de local
aqui na segmentação de local eu posso segmentar para países estados
cidades CPS ou localizações específicas então eu posso escolher anunciar
por exemplo para todo mundo que tá num bairro posso escolher anunciar
para todo mundo que tá num CEP todo mundo que tá numa cidade todo mundo
que tá num estado todo mundo que tá num país e isso é feito também lá na
criação da campanha então quando eu for criar minha campanha vai chegar
o momento aqui que eu tenho que escolher o local e aí eu vou escolher
aqui o Brasil todos os países e territórios ou eu vou inserir um local
aí quando vou inserir o local eu vou botar aqui o Estado então Paraná
Opa Paraná aí vai tá aqui ó estado do Paraná ah não vou anunciar só no
Paraná não vou anunciar na cidade de Londrina só na cidade de Londrina
Ah não vou anunciar só no cpep E aí o CEP São só os primeiros cinco
dígitos tá então só um CEP da cidade de Londrina Ah não eu quero fazer
uma pesquisa avançada eu quero inserir um local eu quero ver e um eu
posso inserir o endereço do local ou até mesmo as coordenadas Então eu
tenho muito poder de segmentação aqui eu tenho muito poder de
segmentação aí eu posso adicionar vários locais aqui restringir um local
enfim é são essas as opções bem simples tá não tem muito mistério depois
nós temos o público e agora vai o bicho vai começar nós temos o público
e eu eu esqueci de fazer um parênteses para você aqui tá o parênteses é
o seguinte esses três primeiros segmentação de calma aí que tá tem
bastante coisa escrita segmentação de palavra-chave segmentação de
canais segmentação de temas são as três segmentações Então as três
segmentações acima são segmentações que podem ou não ser de conteúdo Ou
seja eu vou escolher no o conteúdo que eu vou aparecer as segmentações
abaixo são segmentações de público alvo tá então são segmentações que eu
vou escolher para qual público eu vou aparecer aqui no caso eu tô
escolhendo eu vou aparecer para pessoas que estão nessa cidade el elas
estão nessa cidade eu não sei se elas estão vendo o vídeo da Marila
Mendonça do Pedro Sobral se elas estão vendo vídeo sobre tecnologia
sobre crochê sobre culinária eu não sei o que tipo de site que elas
estão acessando mas eu vou aparecer para pessoas que estão numa
determinada cidade beleza e agora a o quinto tipo de segmentação é a
segmentação de demográfico e demográfico detalhado Tá o que que é o
demográfico e o demográfico detalhado quando a gente Tá criando a nossa
campanha nós vamos lá na parte de criar o grupo de anúncio é aqui que a
gente vai definir a nossa segmentação quando eu tô aqui eu vou fazer a
definição do meu público alvo e aí na definição do público alvo eu tenho
as informações demográficas Tá o que que são as informações demográficas
são basicamente quatro configurações que eu vou fazer primeira
configuração gênero né sexo feminino masculino desconhecido desconhecido
é o seguinte o Google não conseguiu identificar Qual que é o gênero
daquela pessoa não é que a pessoa não se identifica como masculino ou
feminino sei lá não binários etc mas é que o Google não conseguiu
identificar então se eu quero anunciar somente para homens e nada além
de homens nada além de pessoas que se identificam com o gênero masculino
tira fora O desconhecido tá tira fora o desconhecido Porque aqui no
desconhecido também tem mulheres na idade é mes mesma coisa eu só quero
anunciar para pessoas que T entre 25 e 44 anos não quero aparecer para
outras pessoas tira fora o desconhecido ah tanto faz mantém o
desconhecido aí a gente tem a idade então que são que vão em faixas
status parental com filho sem filho desconhecido e a renda familiar aí a
renda familiar Tem uma galera que se confunde que é o seguinte se eu
coloco 10% com maior renda a 10% com maior renda eu tô pegando o topo da
pirâmide de pessoas que mais T dinheiro é só os pega o Brasil inteiro e
pega os 10% mais ricos é isso daqui Ah não eu quero os 20% mais ricos
Então é os 10% com maior renda A 20% então eu não tô pegando só os 10%
mais rico eu tô pegando os 10% mais rico e os 10% um pouquinho menos
rico aí se eu botar 30 a mesma coisa eu tô pegando os 10% mais rico os
outros 10 um pouquinho menos os outros 10 um pouquinho menos 40% eu tô
pegando agora se eu botar 50 eu tô pegando a metade do Brasil mais rica
é a metade do Brasil que mais tem dinheiro agora se eu botar 50% com
menor renda é todo Brasil porque eu tô pegando quem mais tem dinheiro e
quem menos tem dinheiro todo mundo agora se eu botar só 50% com menor
renda 50% com menor renda eu tô pegando Só a galera que não tem dinheiro
é só não é que não tem dinheiro é que tem menos dinheiro tá e o
desconhecido ele vai pegar aí todo mundo ah eu quero anunciar para quem
tem mais poder aquisitivo minha recomendação faça isso ah não o meu meu
meu o que eu tô anunciando é absolutamente muito caro Beleza então você
pode ir aqui pro 40 pro 30 pro 20 pro 10 Cuidado para não ficar muito
pequeno a segmentação aqui tá só uma sugestão eu vou deixar aberto aqui
porque eu tô te dando só o exemplo Tá e isso daqui é o demográfico mas
tem mais segmentações demográficas por quê Porque elas ficam aqui ó em
interesses e informações demográficas então eu vou abrir aqui interesses
e informações demográficas E aí eu vou vir em procurar e aqui em
procurar ele vai ter categorias que é no mercado e eventos importantes
que eu categorizo eles dois juntos informações demográficas detalhadas
afinidade e interesse personalizado o interesse personalizado é o
segmento personalizado Pedro você tá dando um Nozinho na minha cabeça eu
tô com vontade de ir embora e de ó a confusão é o primeiro passo do
entendimento é normal primeira vez que você tá vendo um monte de
informação até a metade do conteúdo ali eu tava no rasinho eu tô
começando a ah pancada de conteúdo não tem jeito é porque é bastante
informação mas não quer dizer que você não tá não tá entendendo quer
dizer que o seu cérebro tá criando uma Resistência é tipo você na
academia pô Tô cansando Vou parar não você tem força para fazer mais
umas cinco repetições para de frescura engole o choro e vem para cima tá
engole o choro vem vem para cima para para de moleza para de moleza
Beleza então demográficos eu vou abrir aqui ó o interesses e informações
demográficas vou clicar aqui vou apertar em procurar e vou abrir
informações demográficas detalhadas e aqui eu tenho status parental E aí
o que que eu tenho no status parental eu tenho detalhes não é só se a
pessoa é pai ou não eu consigo anunciar para pais de bebês pais de
criança pequena pais de de crianças pré-escolar crianças em idade
escolar pais de adolescentes estado civil eu consigo pegar aqui ó
solteiro e um relacionamento casado ensino consigo pegar aqui estudantes
universitários eh se a pessoa tá formada no ensino médio bacharelado
graduação status proprietário a pessoa aluga ou ela é dona do imóvel
emprego Opa emprego Qual que é o setor que a pessoa trabalha Ah é
assistência construção educação produção tecnologia financeiro hoteleiro
tamanho de empresa isso aqui é para donos de empresa então a pessoa é
dono de uma empresa de pequeno porte ela é dono de uma empresa de grande
porte dono de uma empresa de muito grande porte então isso aqui se você
quer anunciar para donos de negócio tá então isso aqui são os
demográficos detalhados tudo tá aqui tá é só você explorar no
demográfico detalhado E aí você vai anunciar pro que tem mais sentido
para você beleza próximo tipo de segmentação afinidade o que que é a
segmentação de afinidade ela vai tá aqui também ó nessa mesma aba de
interesses e informações demográficas eu vou clicar aqui vou abrir vou
procurar e vou abrir aqui ó afinidade aqui em afinidade eu vou encontrar
pessoas que têm afinidade por determinados temas então assim ah essa
pessoa aparentemente ela gosta disso ela tem afinidade com esse assunto
não quer dizer que ela tá pesquisando isso ativamente Mas quer dizer que
ela tem interesse nisso aí o que que você vai fazer aqui H compradores
aficcionados por compras de luxo apaixonados por compras atentos a custo
benefício caçadores de desconto e clientes por tipos de loja vou abrir
por tipo de loja cliente de hipermercado loja de conveniência loja de
departamento de supermercado e aí eu vou procurar aqui tem 1 milhão de
tipos viagem aí eu vou abrir aqui viagem o que que são as afinidades
aficcionado por viagem Viajantes a negócios então pessoas que
frequentemente viajam a negócios então principal eles ficam voando
vários dias da semana e aí normalmente uma pessoa que tem um poder
aquisitivo maior pessoas que viajam para local com neve viajante de luxo
gente que viaja para área Litorânea gente que viaja em família tudo isso
daqui tá dentro de afinidade mas a afinidade não é a pessoa que tá
pesquisando ativamente sobre um assunto ela só tem afinidade com aquilo
ali quem tá pesquisando ativamente por um assunto é o n e eventos
importantes no mercado e eventos importantes ele tá aqui ó no mercado e
eventos importantes no mercado São pessoas que estão ativamente buscando
sobre esses assuntos então a pessoa tá ativamente buscando sobre
conserto e manutenção de automóveis sobre conserto de câmbio sobre
conserto e manutenção de freio é muito específico é bizarro o poder que
a gente tem para anunciar hoje em dia aí você vai abrir todos os menus
aqui ó e você vai encontrar o que tem mais a ver com o seu negócio vai
encontrar o que tem mais a ver com o seu negócio emprego vamos ver o que
tem no emprego currículos e portfólios empregos administrativos a pessoa
tá buscando isso daqui ativamente e para mim isso aqui é bizarro tá não
sei para você tá mas não é só o no mercado tem os eventos importantes os
eventos importantes para mim é é idiota porque eu sempre dou o exemplo
do animal de estimação e ele tem aqui ó novo animal de estimação deixa
eu vir para esse ladinho aqui ó para te mostrar que eu vou apertar nessa
setinha ó novo animal de estimação vai adotar um cão vai adotar um gato
adotou um cão adotou um gato recentemente mudança de emprego vai começar
um novo emprego começou emprego novo recentemente reforma da casa Vai
reformar reformou isso são o quê são os eventos importantes da vida da
pessoa casou vai casar vai se aposentar já se aposentou tudo isso daqui
tá tá nesses dois tipos Aqui tá o que que eu quero que você entenda isso
daqui todos esses daqui estão no que eu chamo de listas prontas listas
prontas O que que é uma lista pronta esses três aqui é uma lista pronta
Por que lista pronta Porque é uma lista eu só tenho que pesquisar nessa
lista e encontrar o que tem mais sentido pro meu negócio mas assim como
eu posso fazer isso meu concorrente também pode fazer isso ele vai fazer
ele não vai por quê Porque as pessoas são preguiçosas elas esperam
chegar aqui na live que eu vou entregar para elas o que eu vou te falar
no final que é ai usa esse tipo de segmentação esse esse esse mas aí na
hora que você vai fazer você não sabe nem por onde começar porque você
não entendeu a lógica você não entendeu que tem dois tipos de maneira de
segmentar o seu público você não você você ficou no Raso você ficou no
papagaio que só sabe repetir o mesmo botão que o professor aperta não é
para isso que a gente tá aqui beleza esse é o número sete número oito e
esse daqui para mim é um dos mais importantes é o como que eles
interagiram com a sua empresa também com conhecido tá ele tá mudando de
nome e quando eu digo ele tá mudando de nome porque ele o Google muda o
nome das coisas aos poucos tá então em alguns menus ele ainda chama como
interagiram com a sua empresa em alguns menus ele chama de seus dados ó
seus dados ó seus dados Então como que as pessoas interagiram com a
minha empresa e aqui na criação dos públicos ele vai chamar de seguimo
dos seus dados tá então o que que é esse tipo de segmentação Vem comigo
que eu vou te mostrar quando a gente tá dentro do Google ADS normalmente
você vai abrir o Google ADS ele vai abrir nessa aba aqui você vai clicar
aqui no menu esquerdo de eh ferramentas tá então ferramentas aqui no
menu esquerdo você vai abrir aqui a biblioteca compartilhada Então você
vai clicar aqui nessa setinha e vai abrir o gerenciador de público alvo
e aqui no gerenciador de público alvo você já vai cair no menu segmentos
dos seus dados e aí você vai vai apertar no botãozinho mais e você vai
ter aqui um Total de seis opções de tipos de segmento dos seus dados
para anunciar tá então o que que a gente tem aqui dentro eu posso
anunciar para pessoas que visitaram o meu site eu posso anunciar para
pessoas ó deixa eu abrir aqui ó porque aí eu vou te mostrando que ele tá
na ordem então ó visitantes do site eu posso anunciar para usuários de
aplicativo então aqui ó segundo item usuários de aplicativo posso
anunciar para usuário do YouTube então pessoas que viram determinados
vídeos pessoas que se cadastraram pessoas que compartilharam pessoas que
curtiram determinado vídeo posso para anunciar para uma lista de
clientes uma lista de e-mails uma lista de telefones então tá aqui ó
lista de clientes posso anunciar para o público Opa eu apaguei sem
querer que droga ter que digitar eu posso anunciar para o público de
Google Analytics tá então pessoas que visitaram meu site ele é parecido
com com visitantes do site mas ele me dá um pouco mais de opção de
criação e eu posso anunciar pro público de combinação personalizada tá
que é eu combinar diferentes públicos que eu criei acima Pedro como é
que a gente faz para criar eles vou ser honesto com você Essa é a parte
mais fácil que tem por quê Porque é papagaio que que é papagaio é só
clicar no botão então ah quero criar um público de quem visitou o meu
site mas Anes do site ele vai abrir a página de criação e aí ele vai me
perguntar qual que é o nome do segmento que eu tô criando Ah o nome do
segmento é E aí eu vou colocar o nome aqui eu vou te dar sugestão do que
que você deve criar aqui você deve criar o público de quem visitou o seu
site nos últimos um aí você vai criar outro público de quem visitou o
seu site nos últimos dois nos últimos três 7 14 30 60 90 180 365 540
Dias presta atenção eu tenho o site Pedro sobral.com.br né Ten o meu
site aqui ó meu site deixa eu entrar aqui no meu site aqui ó entrei no
meu site tá ISS aqui é o meu site vamos dizer que eu tenho esse site
aqui há 5 anos tá então 5 anos dá 5 x 365 meu site existe h 1825 dias eu
tenho um monte de gente que acessa esse site aqui se presta atenção se
eu não criar o meu público de quem visitou o meu site no último 1 ano e
eu vou lá e crio agora Ah vou criar agora o público de quem visitou meu
site o Google não vai conseguir se lembrar de quem visitou o meu site no
último ano Ah não entendi é isso mesmo o Google ele tem memória curta
ele tem a capacidade de se lembrar só o que aconteceu nos últimos 30
dias então ele só vai conseguir mapear quem visitou o seu site nos
últimos 30 dias Claro se o seu Pixel sempre esteve lá no site porque a
maneira que o Google tem de se comunicar com o seu site é através do
Pixel a como é que eu instalo Pixel Vou deixar um link na descrição de
uma aula que ensina só sobre Pixel tá só sobre a tag do Google então se
você tem o Pixel instalado no seu site você estabeleceu uma fonte de
comunicação entre o Google e o seu site o Pixel é isso ele conecta essas
duas coisas o Pixel serve só para isso não o público o Pixel serve para
mapear as vendas que acontece no seu site ele serve para criar os seus
públicos ele serve para trazer inteligência pro Google ADS tá então o
Pixel tem mais de uma função mas uma das funções é criar os seus
públicos então o Pixel é essa fonte de comunicação entre o seu site e o
Google só que o Pixel ele tem memória curta ele não consegue se lembrar
do que que aconteceu há mais de um mês atrás ele só se lembra do último
mês tá Pedro mas como é que eu anuncio para quem visitou o meu site no
último ano aí que tá o Pixel tem memória curta mas se eu aviso ele Pixel
você tem que se lembrar para sempre agora de quem visitou meu site no
último ano aí ele vai falar assim beleza eu só consigo me lembrar de
quem visitou no último mês mas a partir de agora eu não vou mais
esquecer e aí ele acumula informação durante um ano ou seja quanto antes
você cria os seus públicos do Google ADS melhor porque ele só vai
Popular o público se você criar o público então eu tenho que vir aqui ó
no nome do segmento aí eu vou colocar aqui ó é site E aí é uma sugestão
você pode botar o nome que você quiser mas eu vou botar aqui ó site
visitou o site 365d então pessoas que visitaram meu site nos últimos 365
dias ele pede aqui para mim e adicionar tipos de clientes então o tipo
de cliente ajuda a definir grupos de clientes isso aqui é útil é quer
dizer não não é muito ainda mas se o Google inseriu essa informação eu
gosto de colocar tá então assim mas ele vai ter aqui ó todos os clientes
compradores clientes de alto valor clientes desinteressados Lead des
qualificados leads convertidos inscrições em programas de fidelidade
pessoas que abandonaram o carrinho de compras nenhum desses tipos de
cliente se enquadra nisso daqui por quê Porque isso aqui não é um
cliente não é um tipo de cliente isso daqui é só quem visitou o meu site
tá aí ele vai me perguntar Qual que é a minha tag Então qual que é a tag
que eu tô usando é a minha ação de conversão que você vai aprender na
aula de pixel que o link vai ficar na descrição aí eu vou botar usuários
do segmento pessoas que visitaram páginas não web nos últimos E aí eu
vou colocar aqui ó 365 dias eu posso excluir determinadas pessoas criar
mais condições então ah ou visitou meu site ou fez tal coisa eu posso
limitar mas enfim eu não vou abrir esse pares Sem Fim aí a opção de
preenchimento eu vou sempre manter aqui ó preencher automaticamente com
pessoas que atenderam as as condições nos últimos 30 dias isso é o Pixel
dizendo ó eu consigo me lembrar do último mês quer que eu já comece
preenchendo o último mês você vai falar quero eu posso colocar uma
descrição normalmente Eu não coloco E aí eu vou apertar em criar
segmento depois que eu criei esse segmento eu vou criar outro aí eu vou
criar aí eu vou e o ideal Na minha opinião é você criar todos esses
daqui tá todo mundo que visitou o seu site além de criar público de quem
visitou o seu site eu posso anunciar para quem visitou uma página
específica do meu site Então quem visitou uma página que conha uma tag
específica eu posso colocar eh eu posso clicar aqui em refinar ação e aí
eu quero a que a quero que as pessoas que visitaram uma página que
continha uma determinada palavra então eu quero todo mundo que visitou o
meu blog E eu sei que em todas as vezes que alguém cai no meu blog tem a
palavra blog na URL a URL é isso daqui é o endereço do site então eu
posso pegar aqui ó blog Barra blog toda vez que tiver a palavra barra
blog eu quero essa pessoa então aqui eu tô criando o público de quem
visitou o meu blog nos últimos 30 dias e aí eu posso criar esse público
também então você pode criar o público de quem visitou todo o seu site e
você pode criar o público de quem visitou uma determinada página uma
página importante sua que você gostaria de saber as pessoas que
visitaram essa página tá E esse números esses números de dias aqui são
sugestões para você beleza usuários do aplicativo eu não consigo dar o
exemplo para você aqui porque eu não tenho o aplicativo para fazer deixa
deixa eu apertar em cancelar aqui mais usuários do aplicativo Ah não ele
liberou não não liberou Tá mas eu consigo anunciar aqui para quem já
baixou meu aplicativo para quem já comprou no meu aplicativo e aí você
vai colocar o nome aqui ó app baixou aí você vai criar todos esses
números de dias aqui também app comprou pessoas que fizeram compras no
aplicativo E aí você vai ver o que que tem de interessante ali para você
e você vai criando todos esses dias aqui tá Quando eu vou pro próximo
item ali que é os usuários do YouTube vai ter uma mudança que é o quê
aqui aqui nos usuários do YouTube Eu vou dar o nome do segmento tá E aí
no nome do segmento eu gosto de começar sempre colocando yt que é de
YouTube tá então yt e aí eu vou colocar a ação então eu posso anunciar
para quem eh viu qualquer vídeo eu posso anunciar pros inscritos no meu
canal eu posso anunciar para quem acessou o meu canal a pessoa que
visitou meu canal eu posso anunciar para quem curtiu os vídeos do meu
canal para quem adicionou o meu vídeos da playlist para quem
compartilhou os vídeos e aí eu vou criar todos esses daqui todos esses
números de dias dá um baita trabalho dá um baita trabalho mas você já
fica com os públicos todos criados bonitinhos prontos para serem usados
inclusive Isso é uma das quando eu fecho algum cliente de tráfego pago
Isso é uma das primeiras coisas que eu faço na conta dele e eu faço
questão de mostrar para ele depois tudo que foi feito porque essa
organização fica pro pro cliente para sempre tá E aí eu vou colocar aqui
o nome do segmento então por exemplo é compartilhou nos últimos 540 dias
aí tem aqui o tipo de cliente não faz sentido pra gente aqui porque não
estamos anunciando para cliente aí eu seleciono e o canal ou o
selecionar um vídeo feito por um criador de conteúdo essa opção é nova
ainda não tá disponível E aí eu vou buscar o meu canal aqui ó canal
subido e aí eu vou pegar as aqui ó Então as ações viu o vídeo e se
inscreveu no canal Acessou a página do canal curtiu adicionou na
playlist compartilhou aí eu venho no compartilhou 540 Dias desculpa
continuar e é isso para cima let's go Exatamente esse passo a passo aqui
tá então eu vou fazer isso daqui para todos esses tipos de públicos é um
trabalho bem repetitivo é um trabalho bem repetitivo tá Depois temos a
lista de clientes que eu vou utilizar aqui uma lista de e-mails para
subir no Google tá então eu vou apertar no mais lista de clientes origem
dos dados eu posso conectar uma fonte dados então eu posso puxar os
e-mails de algum lugar então do Sales Force da shopify Big query de um
Google sheets então eu posso ter uma planilha do Google que F fica o
tempo inteiro puxando esses dados eu posso fazer o upload do arquivo
manualmente vou apertar em continuar E aí eu vou subir aqui ó eh vou
subir aqui uma uma planilha e aí o Google ele libera tipo um tipo não
ele libera um modelo de como que essa planilha tem que ser por que que
ele não abriu aqui ainda Ó daí ele libera o modelo mas é basicamente 1
E5 embaixo do outro tá 1 e meio embaixo do outro numa planilha você sobe
ela aqui bonitinha para anunciar no Google tá então é basicamente isso
daqui depois temos os públicos de Google Analytics tá E aí aqui eu tenho
que encontrar eh você tem que ter o Google Analytics conectado com o seu
com a sua ferramenta de com o seu Google ADS você aperta em continuar
aqui Putz Será que ele vai bugar deu um erro interno tudo bem você pode
presta atenção mais avançado isso daqui tá você pode entrar lá no seu
Google Analytics deixa eu abrir aqui o meu Ah ele já abriu até a aba ó
Mas você vai entrar aqui no Google Analytics você vai abrir a aba aqui
embaixo administrador entrou aqui em administrador você vai abrir aqui ó
exibição de dados deixa eu dar um zoom né que senão Ninguém merece você
vai abrir aqui ó eh exibição de dados você vai abrir aqui público alvo
aqui em público alvo novo público e aqui você consegue criar um público
do zero ou usar sugestões sugestões do Google e aí algo que eu ainda não
testei tá Não testei mas que começou a liberar na minha conta aqui é o
preditivo Então o Google ele ele cria uma lista para você de prováveis
pessoas que vão comprar nos próximos 7 dias prováveis usuários inativos
dos dos próximos 7 dias então pessoas que estão prestes a desengajar não
vão visitar o min o meu site nos próximos 7 dias aí tem uns aqui que ele
não liberou para uso para mim ainda mas ó prováveis compradores dos
novos dos próximos 7 dias ão pessoas que nunca compraram e que são muito
prováveis de comprar prováveis pessoas que compraram e que vão ficar
inativas nos próximos 7 dias então e aí Tem vários tipos aqui tá aqui
você tem que fazer uma exploração porque é infinito é um pouco mais
avançado você pode fazer criações zero eu posso criar por exemplo
público de pessoas eh baseado eh nas sessões que ela tiveram no meu site
quanto tempo ó Quanto tempo que ela ficou no meu site então número da
sessão então eu vou criar o público de pessoas que eh visitou meu site
mais do que cinco vezes e aí ele vai criar esse ó dentro de 30 dias
então tem 97 pessoas que visitaram meu site mais de cinco vezes nos
últimos 30 dias e aí eu vou vou dar um nome para esse público Vou salvar
ele e ele vai aparecer lá na minha conta e ele vai est lá na minha conta
do Google ADS eu vou ter ele disponível para anunciar dentro do Google
ADS tá então assim bizarro completamente bizarro tá é um detalh mais
avançado É mas eu não podia deixar de mostrar aqui para você tá então e
por último agora eu pensei que era pensei que tinha acabado mas tem mais
um temos o público de combinação personalizada que nada mais é do que a
gente combinar diferentes públicos que já que estão e que a gente criou
anteriormente uma coisa que eu gosto muito de fazer por exemplo é
combinar públicos de YouTube então eu vou pegar por exemplo eh todo
mundo que teve algum tipo de envolvimento com o meu YouTube nos últimos
7 dias então eu vou pegar todo mundo que se envolveu com o meu canal do
YouTube nos últimos S dias e vou criar um público dessas pessoas então
eu vou ter um super envolvimento S dias então vou pegar aqui ó adicionou
vídeo na playlist curtiu compartilhou se inscreveu viu algum vídeo e
visitou o canal todos esses daqui Coloquei todos eles concluído aí eu
vou criar o quê o nome do público YouTube e eu gosto de chamar ele assim
envolvimento completo D tá deixa eu só botar o nome aqui esse aqui é o
CDs deu E aí eu crio o segmento Opa Ah eu já eu já fiz esse público Tá
mas é porque o nome vai ficar repetido não vou criar duas vezes mas é
basicamente isso daqui aí eu tenho um público que une todos aqueles
outros públicos ali e eu posso fazer infinitas combinações beleza esses
daqui são os públicos de seus dados é o mais chatinho faz tá essa aqui é
a verdade é o mais chatinho por porque aí aqui eu sei que eu já perco
deixa eu ver já tem uma galera que foi embora eu sabia porque o conteúdo
mais denso ele é mais técnico mesmo mas pô não tem a gente tem que
passar por isso e o ideal mais uma vez povo eu vou falar para você o
ideal o ideal vou falar assim a única maneira de você aprender a criar
seus públicos é colocando a mão na massa Coloca a mão na massa vai fazer
vai fazer Ah fiquei um pouco confuso Socorro se eu não estou 100% seguro
eu não faço eu travo eu prefiro ficar sem fazer nada eu prefiro eu não
consigo entender que um é maior do que zero vai lá e trabalha com o que
você tem nas suas mãos que é assim que você vai aprender É assim que
você vai dominar a ferramenta é assim que você vai dominar a ferramenta
Quer moleza igual o nosso amigo falou no chat aqui ó Quer moleza Senta
no Colo do vovô ai que horror essa frase ai que horror eu não acredito
que eu repeti isso vz alta os públicos podem ser usados em qualquer
campanha em qualquer campanha beleza vamos seguir são 10 a gente tá no
número oito número nove segmentos personalizados esses daqui para mim
são os queridinhos tá o que que que são os segmentos Ah não não calma aí
calma aí calma aí faltou uma coisa faltou uma coisa faltou uma coisa
coisa muito importante que pouca a gente te fala é sobre os seus
insights de dados o que que são os seus insights de dados presta atenção
uma vez que eu criei os meus públicos aqui de meus dados esses que a
gente aprendeu a criar agora nós vamos acessar essa aba aqui ó seus
insites de dados seus insites de dados aqui em meus insights de dados o
que que eu consigo fazer eu consigo filtrar um determinado público então
por exemplo eu consigo pegar aqui usuários do YouTube Deixa eu pegar
aqui esse aqui não vai Popular aqui ó Putz não pegou Ai Deus tudo que eu
queria era um público que funcionasse calma deixa eu jogar um 540 aqui
que vai dar certo é que tem uns aqui que eu não quero mostrar os dados
desculpa Essa é a verdade aqui inscritos inscritos no canal vai dar
certo tá agora deu então o que que eu vou fazer eu vou jogar aqui um
público desses que eu acabei de criar E aí o que que o Google vai fazer
ele vai me dizer quais públicos alvo tem maior chance de funcionar para
mim então ele vai entender Quem são os inscritos do canal do Pedro dos
últimos 540 dias e aí ele vai me dizer aqui ó o meu índice o que que é o
índice as pessoas que estão em YouTube subscribers subscribers 540 dias
estão 16 vezes mais propensas a estar no mercado de seo e s em
comparação à população geral Ou seja eu tenho muita chance de encontrar
o meu público alvo anunciando para esse Público aqui aqui que é o
público alvo no mercado que eu te mostrei anteriormente eu ó eu tenho
aqui ó desenvolvimento de websites web design serviço de publicidade e
marketing empregos técnicos na área de TI sinalização pô sinalização
você acha que eu ia fazer um anúncio para sinalização alguma vez na vida
jamais mas depois de olhar para isso daqui eu começo a a pensar que pô
talvez tenha gente do meu público que tá aqui aí eu tenho o segmento no
mercado e o segmento de afinidade você vê que o segmento de afinidade o
índice é muito menor tá 2.5 2.2 tá aqui eu vou ter insites de públicos
para os quais eu posso anunciar beleza agora sim número nove segmento
personalizado isso daqui para mim é o ouro escondido do YouTube tá como
que você faz você vai apertar em mais e Aqui nós temos três tipos de de
público de segmento personalizado primeiro tipo de público pessoas com
qualquer um desses interesses ou intenção de compra então pessoas que t
intenção de compra em sei lá eh aía vai comprar a geladeira então São
pessoas que T interesse em comprar geladeira São pessoas que estão
demonstrando Olha só olha aqui olha aqui ó até os temas já apareceu aqui
ó geladeiras e freezers equipamentos de cozinha compras e varejistas
fogões cooktops e fornos aparelhos domésticos ele já filtra para mim e
eu vou jogando mais termos aqui então é refrigerador e aqui que entra a
palavra-chave aqui que vai entrando a palavra-chave Porque quanto melhor
for a minha lista de palavras-chave melhor é esse público tá então esse
daqui eu chamo de SP que é segmento personalizado não é São Paulo
intenção de compra ou interesses tá e a gente tem o segundo tipo que é
pessoas que pesquisaram qualquer um desses termos no Google então aqui
eu vou encontrar vou montar uma lista de pessoas que já pesquisou no
Comprar geladeira e aqui eu posso colocar a palavra-chave exata Comprar
geladeira eu posso jogar palavra-chave de frase eu vou e aí eu vou
jogando várias tá aqui O legal é você preencher com várias palavras
chaves diferent e a dica é quando você presta atenção dica essa aqui é
avançadinha quando você já tá rodando uma campanha da rede de pesquisa
você vai descobrir na sua campanha quais palavras que mais convertem
você vai pegar as palavras que mais convertem e você vai criar um
público de pessoas que já pesquisou essas palavras no Google você vai
rodar uma campanha na rede de pesquisa você vai descobrir olha Essas são
as palavras que mais convertem você vai pegar essa lista eu já testei
aqui o número que para mim melhor funcionou são 75 quando eu tenho 75
palavras-chaves que mais convertem eu pego essas palavraschave jogo
dentro dessa campanha aqui bum é a desse desse Público aqui é a explosão
é explosão é explosão é explosão explosão explosão tá então eu posso
criar o público de intenção de compra eu posso criar o público de termos
de pesquisa e aí já fica um detalhe aqui o Google ele tá adicionando um
novo tipo de público aqui ó quando eu tô criando as minhas campanhas
aqui eu tô na criação de campanha tá quando eu tô na criação de campanha
tem aqui ó outros segmentos de público alvo o Google colocou termos de
pesquisa personalizados Na minha opinião o Google vai mudar o nome eu
acho tá achismo mas eu acho que ele vai mudar o nome do segmento
personalizado eu acho que ele vai começar a chamar de termo de pesquisa
personalizado E aí o que que tem aqui no termo de pesquisa personalizado
tem os públicos alvo de segmento personalizado tá mesma coisa que a
gente tá fazendo aqui ó mesma coisa que a gente tá fazendo aqui agora tá
só que eu posso criar com base na pesquisa que a pessoa fez eu posso
criar Com base no sites que a pessoa navegou eu posso criar Com base no
aplicativo que a pessoa tem então por exemplo se a pessoa tem o
aplicativo do meta ads no celular eu vou aparecer para ela se você tem o
aplicativo do Google ADS no celular eu vou aparecer para você ah eu
quero aparecer para empresário o que que todo empresário tem no no
celular só pensa Qual o aplicativo que todo empresário tem no celular
Itaú empresas Santander empresas aplicativo de banco Empresarial é
aplicativo de controle financeiro da empresa sei lá conta Azul a pessoa
tem o aplicativo do Asa a pessoa tem um aplicativo de mei de CNPJ
consulta de CNPJ não sei aí eu vou pensar eu tenho que entender quem é
meu público para criar quero aparecer pras pessoas que T esses
aplicativos no celular pô eu tinha um cliente na moral ele era fotógrafo
a gente começou a anunciar para todo mundo que tinha o light room no
celular Como é que escreve Lightroom não é assim Lightroom foto e vídeo
editor aí a gente jogou Lightroom Photoshop ah mas tem gente que não é
fotógrafo que tem esse esse aplicativo no celular Claro que tem mas tem
muito mais fotógrafo que tem que do que não tem aí eu vou entender o que
que todo todo mundo que é fotógrafo tem no celular ó Photoshop Express
foto de E aí eu vou começar a procurar aqui vou começar a jogar para
criar o meu público com base nos aplicativos tá então eu consigo fazer
quatro tipos de segmentações aqui consigo anunciar para quem tem uma
determinada intenção de compra para quem pesquisou qualquer um termo no
Google para quem navegou por determinados sites para quem usou
determinados aplicativos E aí lembra que lá na campanha de de vídeo
esses públicos esse da aqui ó o 9.2 ele tá começando a vir aqui ó termo
de pesquisa personalizado por quê Porque funciona muito e as pessoas não
usam as pessoas não usam é bizarro E aí agora sim por último e não menos
importante temos os segmentos combinados que que são segmentos
combinados é eu combinar públicos diferentes Que Eu Já criei é a
mistureba final é você unir uma coisa com a outra é misturar o público
alvo de mercado com quem interagiu com seu YouTube com quem já pesquisou
alguma coisa no Google é a bagunça é a eu não vou falar essa palavra
feia mas começa com f termina com uruba e aí você pode vir aqui no
segmentos combinados e aqui você clica em mais segmento combinado E aí
você vai misturar todo tipo de público que você já tem todos esses que
eu mostrei para você todos esses a gente combina um com o outro aqui
Pedro você já viu isso funcionar nunca nunca vi nunca vi por quê eu acho
que você tem tanta coisa para testar antes de sair usando o segmento
combinado que seria uma das últimas coisas que eu testaria tá agora
recomendações rápidas subidas para você que venceu que chegou comigo
aqui até o final desse conteúdo recomendações subidas primeiro campanha
da rede de pesquisa você sempre vai anunciar com palavra-chave missão
número um da sua vida é montar uma lista de palavra-chave é investir
tempo porque você vai usar isso daqui para muita coisa número dois
campanhas para negócios locais no YouTube sempre devem testar anunciar
somente para o local então lembra lá segmentação número quatro que eu te
passei tá aqui ó local então anuncia só pra cidade só pro CEP funciona
muito bem campanha de YouTube para negócio local número três campanhas
de conversão no YouTube Então você quer vender pelo YouTube sempre deve
testar anunciar para quem deixa eu copiar o YouTube assim que fica mais
bonitinho sempre deve testar anunciar para quem primeiro pessoas que já
visitaram seu site mas não converteram segundo público alvo no mercado e
eventos importantes tendem a performar melhor do que os de afinidade tá
procura não colocar mais do que quatro segmentações por grupo de anúncio
então eu posso ter um grupo de anúncio e colocar dentro dele cinco
público alvo no mercado três é eventos importantes começa a ficar muito
bagunçado não tá funcionando bem e você não sabe porquê tá então busca
não colocar mais do que quatro pro grupo de anúncio esse daqui é um
número legal para você se basear 3.3 sempre anuncia para quem já
interagiu com a sua empresa principalmente os envolvimentos completos tá
lembra do envolvimento completo que você vai criar aqui ó segmento dos
seus dados maizinho combinação personalizada e aqui você vai adicionar
todo mundo que se envolveu nos últimos é um dia depois 2 dias 3 dias 4
dias 5 dias 7 dias 30 60 90 680 365 540 faz os envolvimentos completos
eles funcionam muito bem tá principalmente esses daqui que eu coloquei
aqui 730 e 540 esses daqui são assim os mais Coringas para mim 3.4
segmentos personalizados são o poder pessoas que pesquisaram coisas no
Google site dos seus concorrentes aplicativos lista de canais ou vídeos
do YouTube tá isso daqui é Arma Secreta usa ela quem não tá vendo essa
Live tem gente que não assiste a Live porque falar ass eu já sei tudo
cara eu juro para você você passa 1 hora e meia aqui comigo eu tô
acabando agora 1 hora me aqui comigo é uma coisinha nova que você
aprende quando você já sabe tráfego pago paga o tempo que você passou
aqui às vezes ouvindo coisas que você já sabia mas que faz parte porque
eu não tô ensinando só para você senão o nome disso era consultoria você
tá me pagando é de graça eu tô ensinando para quem tá começando agora e
para quem já tá mais avançado e você que tá começando agora não se
desespera quando eu soltar uma coisa mais avançada e você não entender
só não tá no seu momento no futuro vai chegar o seu momento você vai
entender aquilo 3.5 confia no poder do Óbvio e do fusar e clicar nas
segmentações o maior erro que as pessoas cometem quando vão anunciar no
YouTube é não investir tempo fazendo isso daqui ó clicando abrindo o
menu procurando clicando vendo o que que tem dentro das segmentações
Putz eu posso anunciar para isso eu posso anunciar para aquilo eu posso
anunciar para software para software de contabilidade Hum quem usa
software de contabilidade será que é contador ou dono de empresa também
usa software de contabilidade software de desenho software de produção e
edição de vídeo Hum gostei desse daqui ó produtividade comercial Hum
legal tô gostando beleza aí eu vou fuçando eu vou vendo o que que tem em
cada um deles porque esses interesses eles vão sempre mudando e ganha
quem tá mais atualizado quem tá quem tá fuçando E clicando mais e foca
na segmentação óbvia naquilo que tem mais sentido pro seu negócio tá
isso daqui lembra eu tô falando de campanha de conversão no YouTube usa
sempre esses cinco tipos de público campanha de display tá E mais uma
vez na descrição desse vídeo tem o link da aula que eu dei na semana
passada não sei quant você tá vendo esse vídeo mas tem o link da aula
onde eu ensinei a criar quatro tipos de campanha uma delas é a campanha
de display aqui 100% da sua energia tem que tá em anunciar para quem já
interagiu com você 100% fora disso daqui é perda de tempo outra campanha
que eu expliquei na Live 322 que o link tá na descrição campanha de
performance Max tá na campanha de performance Max eu não vou falar pro
Google qual é a minha segmentação eu vou dar uma sugestão de segmentação
então eu vou sempre focar aqui em palavras-chaves qualificadas o que que
é palavra-chave qualificada quav palavra-chave qualificada igual
palavras que geram vendas e vou focar em públicos de pessoas que
demonstraram o sucesso da sua campanha então se eu tô buscando mais
comprador eu vou colocar lá minha segmentação de comprador pro Google
entender olha ele tá buscando comprador porque a campanha de performance
Max eu não faço uma segmentação não é segmentação aqui aqui é sugestão
de segmentação sugestão de segmentação tá então é sugestão eu tô
sugerindo ó vai por esse caminho tá então aqui é legal se eu tô buscando
comprador bota lá a lista de comprador se eu tô buscando Lead bota lá a
lista de Lead porque que pro Google entender Olha esse é o público que
essa pessoa tá buscando Pedro não tenho ideia do que você tá falando tá
tudo bem atropela essa dúvida não é o momento de você entender isso tá E
aí número seis pô se você já for mais avançadinha então pô pessoas que
estão prontas para comprar que vão começar a ficar inativos esses
públicos aqui não tem ninguém usando isso aqui é 0,01% dos anunciantes
do Google estão utilizando isso daqui hoje hoje em dia e o número sete
não menos importante nunca deixe de passar uma semana sem testar e
anunciar para um novo tipo de segmentação no jogo do tráfego pago ganha
quem testa mais larbos ordep frase desse famoso filósofo tá famosíssimo
famosíssimo Inclusive essa essa daqui vai ser a palavra-chave da aula de
hoje larbos ordep tá larbos ordep então no jogo do tráfego pago ganha
quem testa mais não é sobre você ter muito dinheiro não é sobre você ter
investido muitos milhões mas é sobre você ser a pessoa que tá sempre
testando que tá sempre colocando uma nova segmentação para rodar eu
conheço pessoas que T muito menos dinheiro e sabem muito mais de Google
ADS tem muito mais do que resultado no Google ADS do que pessoas que T
muito dinheiro por quê Porque de nada adianta você tem muito dinheiro no
tráfego pago e você ser preguiçoso você tem que botar a mão na massa tem
que explorar segmentações porque não importa eu Posso sugerir e te
explicar como é que você cria tudo agora para você ter resultado mesmo
tem que testar porque só os testes só quem testa só quem só quem testa
sabe a verdade e a verdade vos libertará eu te abençoo em nome de subido
é isso mas é isso é isso é isso só quem testa sabe a verdade e você tem
que botar para rodar tem um monte de Guru de tráfego pago que fica te
dizendo não esse público é o melhor esse público é o melhor não no final
é tudo sugestão é baseado na minha experiência do passado mas o que vai
mandar mesmo é o seu experimento do presente ó que poético que ficou
isso daqui né Isso é baseado na minha experiência do passado mas a
verdade só será encontrada no experimento do presente maravilhoso para
encerrar essa aula de hoje povo é o seguinte se você quiser olha só não
é sempre que eu faço isso mas se você quiser ter acesso ao material
dessa aula tá não sei quant você tá vendo esse vídeo talvez você esteja
vendo muito tempo depois ele não tá disponível mas se você tá vendo esse
vídeo no momento que ele foi ao vivo na semana que ele tá indo ao vivo
você pode encontrar o material desta aula aqui especificamente lá no meu
canal de transmissão do meu Instagram Pedro que canal de transmissão que
é esse é o seguinte você vai entrar lá no YouTube você vai digitar aqui
ó Pedro Sobral entrou aqui no meu YouTube você tá vendo agora esse vídeo
aqui nós estamos ao vivo aqui você vai entrar aqui no meu canal na nessa
aula que você tá vendo você vai abrir aqui na na descrição nós temos
alguns links importantes link importante número um nós temos o link do
subido ao vivo que que é o subido ao vivo Pedro subido ao vivo é o nosso
evento presen tá a gente vai abrir a venda de ingressos aqui agora nos
próximos dias mais uma vez não sei quando você tá vendo esse vídeo mas
em 2025 esse evento acontece nos dias 22 23 e 24 de Agosto vai ser no
Rio de Janeiro Ah vou esperar para ser em São Paulo não espere o Rio
Centro no Rio de Janeiro é a casa de subida ao vivo é lá que a gente faz
o subida ao vivo sempre porque o ambiente é maravilhoso esse é um evento
onde você vai aprender tudo sobre negócio estratégia ferramenta
mentalidade networking é o evento para quem tá levando a gestão de
tráfego a sério é isso é isso é o evento para quem tá levando a gestão
de tráfego a sério tem todas as informações na página você pode fazer
aqui já a sua pré-inscrição beleza vamos abrir a venda com os ingressos
no menor preço agora na próxima semana segundo link que temos aqui lista
de presença que que é a lista de presença basicamente é o seguinte mais
ou menos uma vez por mês eu acho até que é na próxima aula que tem
sorteio de novo mais ou menos uma vez por mês nós temos um sorteio aqui
tá porque que que é ou menos porque às vezes é mais às vezes é menos mas
a gente tem um sorteio e quanto mais aulas você vê quanto mais aulas
você tem presença melhor é o prêmio que você ganha Então vamos dizer que
você seja sorteado mas você viu só quatro lives Você vai ganhar uma
caneca vamos dizer que fo você foi sorteado e você viu sei lá 32 lives
você pode ganhar um ingresso do subido ao vivo ou uma vaga na comunidade
Sobral de tráfego tá então quanto mais lives melhor agora Como que você
vai fazer para colocar sua presença você vai colocar seu nome vai
colocar o e-mail vai colocar seu WhatsApp e vai escolher a palavra-chave
da aula sempre tem que preencher essas três informações iguais e aí você
escolhe a palavra-chave da aula qual que é a palavra da palavra chave de
hoje é larbos ordep larbos ordep o famoso filósofo contemporâneo tá
colocou a palavra-chave aqui confirma a minha presença sua presença vai
ser computada beleza Além disso nós temos o canal no Instagram dos
subidos tá então você vai clicar aqui ó no canal no Instagram do subidos
e vai abrir aqui o nosso canal de transmissão aqui pera aí que eu tô
vendo se ele tá abrindo deu abriu vai abrir aqui o nosso canal de
transmissão e a gente vai colocar aqui no canal de transmissão o link do
material aqui para você baixar quando que vai colocar daqui a pouco
daqui a pouco porque eu tenho que mandar pro meu time eu acabei de ter
essa ideia eu vou mandar o link do material aqui para você baixar e faça
parte do nosso canal dos subidos no Instagram eu só mando bons conteúdos
aqui tá só mando B conteúdos aqui inus nós vamos iniciar ag presta
atenção nisso a gente vai iniciar nesse umó inito nessa internet eu nem
vou falar eu nem falar que senão alguém vai roubar minha ideia é isso já
me arrependi comei a falar me arrependi esteja no canal Essa é a melhor
dica que eu tenho para você vou mandar o material da aula bonitinho lá
para você tenho certeza que você não vai se arrepender de estar no canal
você vai se arrepender de perder os conteúdos lá do canal tá então povo
era isso muito obrigado por você que participou comigo aqui da nossa
Live número 323 só uma última lembrança aqui para você tá Para que você
não esqueça na próxima semana o tema da aula ele tá quentíssimo tá a
gente vai falar sobre como que é isso não tá errado Tá certo tá errado
Tá certo não sei a gente vai falar sobre a melhor forma de você ganhar
dinheiro na internet em 2025 Tá então vamos falar sobre Claro um
pouquinho sobre a gestão de tráfego Mas vamos trazer um pouquinho mais o
aspecto da profissão Como que você ganha dinheiro de verdade Quais são
as possibilidades de ganhar dinheiro através da gestão de tráfego em
2025 fechou minha gente tamo junto e a gente se vê agora na próxima
terça-feira às 3 horas da tarde não esquece de curtir esse vídeo de se
inscrever no canal e de deixar o seu comentário aqui embaixo do que que
você achou desse conteúdo O que que você não gostou O que que você
gostou eu leio sempre todos os comentários aqui do meu canal do YouTube
fechou tamo junto e até a próxima terça-feira valeu falou

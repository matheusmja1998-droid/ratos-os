---
tipo: transcrição
autor: Pedro Sobral
live: 382
tema: Geração de seguidores
tags: [transcrição, sobral, seguidores, instagram, turbinar]
---

# Transcrição — Live #382

> Como eu colocaria 10.000 seguidores reais em qualquer perfil em 60 dias

Resumo e aplicação: [[Live 382 — 10.000 seguidores reais em 60 dias]]

---

Todo dia que você entrar aqui no meu canal do YouTube, 8 horas da noite, vai ter um vídeo novo. Bem-vindo, bem-vindo, bem-vinda, bem-vinda. Bem-vindos, bem-vindos à nossa live número 382. Nessa live você vai aprender tudo que você tem que saber para gerar seguidores qualificados por uma conta do Instagram através do tráfego orgânico, ou seja, sem gastar nenhum real e também através do tráfego pago. Eu garanto aqui que você vai ter uma aula melhor do que você encontra na maioria dos cursos da internet, quando o assunto é gerar seguidores do Instagram.

E sim, nós estamos a 382 semanas, todas as terças-feiras, 3 horas da tarde, fazendo aulas ao vivo sobre tráfego pago, anúncios online, como que você ganha dinheiro prestando serviço na internet ou cuidando dos anúncios do seu próprio negócio. E aqui eu já te dou um spoiler, tem basicamente duas maneiras de você ganhar dinheiro com que eu vou te ensinar aqui. Uma delas é você prestar esse serviço para outras empresas. A outra maneira é você utilizar os anúncios pro seu próprio negócio, seu produto, seu serviço que você já vende para impulsionar ainda mais as suas vendas.

[... apresentação do canal e do evento Nova Gestão de Tráfego, mesmo formato das outras lives ...]

E sim, estou com uma voz de uma senhora de idade que fuma derby há 50 anos. Eu tô rouco, é o clima da Europa, né? Muito chique. Eu peguei algum tipo de alergia aqui. Minha garganta tá um pouco muito irritada, então tô usando alguns remédios. Tô me até cortisonando para conseguir fazer essa live aqui com você. E quero te dizer que eu não estou ao vivo. Eu tô gravando essa aula aqui na segunda-feira às 3 horas da tarde, porque eu tô em Cannes, vim aqui num evento receber uma premiação. Eu faço parte do 0,01% dos produtores de conteúdo que ganham dinheiro vendendo cursos online. A gente tem mais de 120.000 alunos que já passaram pelos nossos treinamentos. Hoje são mais de 50.000 ativos.

---

## DUAS GRANDES VERDADES INICIAIS

**Primeiro: seguidor não é sinônimo de audiência.** A audiência é basicamente um público que te acompanha de forma repetida, sabe quem é você, conhece a sua marca e tá te acompanhando durante um período de tempo. Seguidor não é audiência. **Seguidor também não é sinônimo de cliente.**

Existem **três tipos de públicos**:
1. **Audiência** — seus clientes estão todos aqui. A pessoa que vira seu cliente faz parte da sua audiência. Uma pessoa que minimamente te acompanha.
2. **Pessoas que te conhecem** — seus seguidores podem estar aqui. Tem seguidor seu que é audiência, mas tem seguidor seu que não é. Mas ele te conhece, já te viu, decidiu receber mais conteúdos quando te seguiu.
3. **Pessoas que não te conhecem** — a grande maioria.

---

## TRÁFEGO PAGO OU ORGÂNICO?

No jogo da criação de audiência, **o tráfego pago cria o tráfego orgânico e o tráfego orgânico cria o tráfego pago**.

Quando você publica organicamente no Instagram, TikTok, YouTube, você não tá pagando por aquele resultado. Mas aquelas pessoas que viram aquele conteúdo, quando você anunciar para essas pessoas depois, vai ser muito mais barato e eficiente. Então, o tráfego orgânico ajuda o tráfego pago.

O contrário também é verdadeiro. Quando eu tô fazendo anúncios online, pessoas vão ver os meus anúncios, vão acabar indo até o meu perfil, vão acabar me seguindo, e se essas pessoas se interessarem por aquilo que eu produzo de conteúdo diariamente, elas vão acabar interagindo organicamente comigo.

A gente não tá na quinta série aqui em que um tem que ser melhor do que o outro. As duas coisas, e cada vez mais elas andam juntas.

---

## CENÁRIO ATUAL

- **O alcance orgânico é cada vez menor e vai ser cada vez menor.**
- Eu e uma pessoa do meu time fizemos um exercício, voltamos até a primeira publicação que eu fiz no Instagram. É impressionante como que percentualmente e até quantitativamente a gente tinha mais engajamento no passado do que hoje.
- Isso se deve ao fato de que temos mais pessoas produzindo conteúdo e o número de pessoas entrando na rede social não acompanha. É lei de oferta e demanda.
- Ano após ano, o Instagram apresentava 5% de aumento no número de novas publicações. **De 2024 para 2025, esse aumento foi de 20%.** A IA inundou a plataforma.
- O Moss, uma das cabeças do Instagram, fez uma publicação visivelmente frustrado no ano novo dizendo que eles não estavam dando conta de lidar com as publicações feitas por IA.

**Outros pontos do cenário:**
- Tráfego pago cada vez mais caro.
- Público frio com taxa de conversão menor. Antes eu aparecia para 100 pessoas e 5 mandavam mensagem. Hoje, com 10, 20, 30 anunciantes disputando, são 2.
- 50% dos brasileiros adultos estão endividados. Cenário macroeconômico desafiador.

**A solução**: criar audiências qualificadas com alto potencial de conversão que só o seu negócio tem acesso.

---

## FREQUÊNCIA E TEMPO DE TELA AUMENTAM CONVERSÃO

Anota isso: **a frequência de aparição aumenta a conversão**.
- Se essa for a primeira live minha que você assiste, você tem 7% de chance de comprar um produto meu.
- 2 lives → 10%
- 3 lives → 11-12%
- E vai crescendo.

**Segundo ponto: tempo de tela aumenta a conversão.** Se você assiste 1 vídeo de 1 min, é uma coisa. Se você assistiu a live de 1h + um vídeo de 20min, você tem 1h20 de tempo de tela comigo. Quanto mais tempo me assistindo, maior o potencial de conversão.

Não é que público frio não converte. Ele converte, mas percentualmente menor. Se eu apareço pra 100 pessoas que viram uma live minha, vendo pra 7. Se eu apareço pra 100 pessoas frias, vendo pra 1. **Vendo 7x mais pra quem me conhece.**

O público frio de hoje é o público quente de amanhã. Todo negócio chega numa escala em que não pode só colher — tem que plantar.

- **Colher** = campanhas que focam em vender. Principalmente no começo, os primeiros anúncios.
- **Plantar** = campanhas que focam em atrair as pessoas.

E aí a gente entende o papel do gestor de tráfego: profissional responsável pelas **estratégias de atração e de conversão** de um negócio.

---

## TRÁFEGO PAGO DIMINUI MEU ALCANCE ORGÂNICO?

Sim e não.

**Por que diminui:** quem vem do tráfego pago engaja menos do que quem te conhece organicamente. A Maria, sua amiga, viu seu conteúdo, clicou no perfil, gostou, te seguiu. Ela vai interagir mais do que alguém que viu um anúncio, clicou no perfil e te seguiu.

**Por que não diminui (na prática):** o que é melhor — 1% de engajamento em 1.000 pessoas (10 pessoas) ou 0,2% em 100.000 (200 pessoas)? Eu prefiro 200 que engajam e compram. **Não é sobre taxa de engajamento, é sobre quanto dinheiro eu faço.**

Esse é o argumento pra levar pro cliente: o alcance orgânico vai ser cada vez menor. Não dá pra jogar só esse jogo.

**Não se apegue a engajamento percentual.** Olhe número total e conversão em dinheiro.

---

## COMO GERAR VOLUME DE SEGUIDORES RÁPIDO

O **botão turbinar** é de longe a melhor estratégia para gerar volume de seguidores pro seu Instagram.

A maior variável: **o nível de atração que as suas publicações vão ter**.

⚠️ **Cuidado crítico**: a qualidade do seguidor e o potencial de atração da publicação são **inversamente proporcionais**.

> Quanto mais uma publicação atrai novas pessoas, normalmente essa publicação vai atrair pessoas menos qualificadas, porque foi genérica.

**Exemplo:**
- Vídeo perguntando se a pessoa rasparia a sobrancelha por R$ 10.000 → viralizou, 15k seguidores. Público desqualificado.
- Vídeo analisando abordagem de tráfego pago → 1.000 seguidores, mas muito mais propenso a comprar.

Outro exemplo prático:
- Vídeo sobre Niet, 1M de views, 70% das pessoas que viram não me seguem ainda → **8.930 novos seguidores**
- Vídeo analisando uma prospecção fria → 198k views (5x menos), gerou **129 seguidores**, mas qualificadíssimos

**Principal fator que mata o seu alcance orgânico com tráfego pago: selecionar mal as publicações que vão receber dinheiro.**

---

## EXEMPLO DO VANES

Tenho um amigo, Vanes. Ele é pago mais de R$ 15.000/mês por uma indústria de molho de tomate. Ele foi no supermercado, pegou o pacote, atrás tinha o número do SAC. Ligou, mandou WhatsApp, fechou. A empresa só quer uma coisa: que ele **gere seguidores**. Sonho deles: conta com 100k seguidores.

O dono do negócio nem o botão turbinar sabe apertar. **Você é pago pelas informações que você tem.** O Vanes fatura mais de R$ 100k/mês como gestor de tráfego. E começou num curso gratuito.

---

## USA META BUSINESS SUITE, NÃO O BOTÃO TURBINAR DO APP

4 motivos:
1. **Localizações mais específicas** — essencial pra negócio local
2. **Anunciar para públicos quentes** — alguém que já teve contato com você
3. **Boost via iPhone paga 30% a mais** — só essa economia já paga seu contrato. Se o cliente gasta R$5k/mês, é R$1.500 de economia.
4. **Não precisa do acesso ao Instagram do cliente** — ele só libera acesso pro seu email e pode tirar quando quiser

---

## COMO ENCONTRAR BONS CONTEÚDOS

**1. Uso diário**: ver o que funciona e "roubar como um artista" pro seu negócio.

**2. Pesquisa no Instagram (sacada simples mas ninguém faz):**
- Aperta no botão de buscar
- Digita o nicho (ex: "velas aromáticas")
- Aparecem as principais publicações — conteúdos validados que viralizaram
- Replica com o seu produto

Depois:
- Pesquisa **nichos similares** ("aromaterapia")
- Pesquisa **em outros idiomas**: "aromatic candle" em inglês, espanhol, tailandês, chinês, coreano
- Aparecem publicações que não tinham aparecido na sua busca em português

Funciona com reel, carrossel, post estático. Reel normalmente traz mais seguidor.

**3. Engenharia reversa:**
- Baixa o reel (uso a ferramenta `save`)
- Transcreve (pode ser ChatGPT, grava áudio, qualquer ferramenta)
- Joga numa IA que extrai a estrutura: roteiro estruturado, direção visual, engenharia de persuasão, matriz estrutural, modelo editável
- Aí você replica a partir de algo que já funcionou

[Ferramenta liberada via Instagram mandando "Live 382"]

---

## FRAMEWORK DOS 6 ELEMENTOS (3 PARES)

### Validação + Seleção
- **Validação (objetiva)**: o que tá trazendo mais resultado, o que o orgânico já validou. Não tive que gastar nada — o orgânico me diz o que funcionou.
- **Seleção (subjetiva)**: usar a cabeça e ver qual conteúdo tem mais potencial de atrair público qualificado. **Ali eu coloco mais dinheiro.**

### Descoberta + Aquecimento
- **Descoberta**: anunciar pra quem não te conhece. Vai visitar o perfil e seguir.
- **Aquecimento**: anunciar pra quem já te conhece. **Quase ninguém turbina pros próprios seguidores.** A pessoa que já te segue clica no link do anúncio (não no perfil) e converte.

Seguidor não vira audiência sozinho. Tem que aparecer repetidas vezes pra essa pessoa.

### Diversificação + Variação
- **Diversificação (formatos de anúncio)**: a gente vicia em reel porque traz mais seguidor. Mas tem que turbinar carrossel e estático também. Porque conteúdo de reel atrai gente que vê reel. Se você só anuncia reel, seus carrosséis morrem.
- **Variação (objetivos de campanha)**: além do botão turbinar, no Gerenciador você tem campanhas de Engajamento (curtida, salvamento, compartilhamento) e dentro dela visualização de vídeo. Cada objetivo gera resultado diferente.

Se eu só foco num tipo de publicação no tráfego pago, eu mato meu orgânico aos poucos.

---

## ENCERRAMENTO

Próxima terça-feira tem live (será sobre o **futuro do trabalho digital com IA** — a Live 383). Na outra semana, sobre se o tráfego é pra você ou não. Depois, evento Nova Gestão de Tráfego (10h).

Palavra-chave: **Live 382**

---
tipo: transcrição
live: 381
tema: Como criar campanhas de formulário nativo no Meta Ads
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #381

> Como criar campanhas de formulário nativo no Meta Ads

Resumo e aplicação: [[Live 381 — Campanhas de formulário nativo no Meta Ads]]

---

Bem-vindos, bem-vindos à nossa live número 381. [limpando a garganta]
Como criar as suas campanhas de formulário nativo no Metaeds? Quero
saber antes de mais nada, vou conferir aqui se vocês estão me ouvindo em
alto bom som. Ah, vai melhorar agora o som. Pera aí que eu vou fazer ele
melhorar. Agora sim. Vocês estão me ouvindo bem? Vou fazer de novo a
minha introdução. Bem-vindos, bem-vindos à nossa live número 381. Eu não
sei se é 381 ou 382. Eu já tô perdido aqui no número de lives. Deixa eu
ver aqui. Vou abrir numa numa nova aba só para ter só para ter certeza.
381. É isso. Então, bem-vindos, bem-vindos à nossa live número 381. como
fazer campanhas de formulário nativo no Metaedads. Hoje você vai
aprender uma das campanhas mais subestimadas pelos gestores de tráfego
iniciantes e que os gestores de tráfego pago um pouco mais avançados
usam e abusam para todos os seus clientes. Eu vou te explicar todas as
melhores práticas aqui nessa live de hoje. Quero dizer que hoje nós
estamos aqui numa live internacional. Então você vai perceber aqui que
quando eu começar a compartilhar minha tela com você, o horário que está
aparecendo aqui para mim, deixa eu compartilhar a tela. Compartilhar a
tela. Compartilhar a tela inteira. Agora sim. Você vai perceber aqui, ó,
no canto superior, o horário está 8:1. Pedro, você não tá ao vivo? Não,
eu tô ao vivo, só que nós, eu estou agora aqui em Barcelona. Estamos em
Barcelona, pero não vamos haar espanhol hoje. Aqui nesta live teremos
uma live em espanhol, eh, como em 2 horas vamoser um live espanhol.
Então, eu tô fazendo a live aqui em português, daqui a 2 horas eu tenho
minha live em espanhol. A live em espanhol ela vai ser, ela foi gravada,
né? Eu já gravei ela antes de sair de casa, porque eu sabia que ia ser
um pouquinho mais complexo fazer live muito mais tarde aqui de noite,
porque eu tô num fuso horário muito diferente do fuso horário do Brasil.
Tô com 5 horas a mais de fuso horário. Então são 3 da tarde aí, 8 horas
da noite aqui. Sim, estamos meio que de férias, estou com uma vista para
o mar aqui, mas, pô, para você, para vocês ver assim o quanto que eu
gosto e o quanto que eu tenho compromisso com essas lives de
terça-feira. Tem um restaurante aqui em Barcelona que eu tenho sonho de
ir, mas eu não consegui reserva. Aí alguns minutos atrás a mulher me
ligou, falou assim: "Senhor, eh, a gente, a gente viu que você tá na
lista de espera, surgiu uma reserva para hoje." Eu falei: "Que horas,
moça?" Me diz que é às 9:30. Me diz que é às 9:30, porque 9:30 eu
consigo chegar. Aí ela falou assim: "É às 8 horas da noite". Eu falei:
"Não, moça, não posso. Desculpa, o restaurante Michelan, eu tenho
compromisso com os subidos e subidas, quase subidos e quase subidas aqui
neste meu canal. do YouTube todas as terças-feiras, 3 horas da tarde do
Brasil ou 8 horas da noite de Barcelona. E povo, tô muito ansioso paraa
live de hoje. Planejei esse conteúdo assim com muito carinho. Eu faço
sempre todo o planejamento das minhas lives para tentar mastigar o
máximo conteúdo para você e para que a gente consiga ter uma aula com
muita profundidade aqui. Eu gosto de eh eu gosto de fazer as aulas aqui
de tal maneira que dificilmente você vai encontrar uma aula mais com
conteúdo mais profundo e mais denso sobre o assunto da live. Você nunca
vai encontrar isso em nenhum lugar, nenhum curso pago da internet. As
lives elas foram feitas para isso, para que a gente explore ao máximo os
conteúdos, tá? E eu queria começar esse conteúdo de um jeito diferente.
Eu queria começar esse conteúdo falando para você de outro conteúdo.
Pedro, como assim você vai começar o conteúdo falando de outro conteúdo?
Olha só, talvez você não saiba, mas eu tenho dois canais no YouTube. Eu
tenho o meu canal Subido, que é o meu canal onde a gente faz os
conteúdos sobre tráfego pago, e eu tenho o canal Pedro Sobral. Ó, o
canal Subido é o que você tá agora, tem 1.3 milhões de inscritos e a
gente tem o Pedro Sobral com 122.000 inscritos. No canal Pedro Sobral,
eu posto conteúdos mais relacionados à vida, sobre leitura, sobre minha
visão de mundo. E eu soltei aqui, ó, este conteúdo que é o POV, né,
ponto de vista, rotina de um empreendedor milionário de 30 anos. Então,
esse conteúdo aqui, ele é um vlog, então mostrei todo o meu nesse
conteúdo. Recomendo muito depois que vocês assistam. Vou deixar o link
dele na descrição aqui desse vídeo. Acho que vocês vão curtir bastante
esse esse formato de conteúdo que vai começar a sair lá no outro canal.
E se você não é inscrito lá no outro canal, pô, por favor, se inscreva.
Beleza? Agora, sem mais delongas, vamos ao conteúdo da live de hoje.
Deixa eu compartilhar a minha tela com você aqui. Deixa eu. Putz, como é
que eu vou fazer agora para me ajustar nesse cantinho aqui? Calma. Calma
que eu vou eliminar o número dois aqui. Tem um Deixa, deixa eu me
organizar. Deu. Tô no lugar correto. Salvar. Deixa eu ver se deu certo.
Deu. Deu certo. Agora sim. Ficou com essas barrinhas laterais aqui, mas
não tem problema, tá? A gente faz assim. Vai, vai, vai, vai dar bom, vai
dar bom. Eu acabei nem vendo a resposta de você se o áudio tá bom, mas
eu acho que tá. Eu acho que tá bom. Tá bom. Muito obrigado. Deu, fechou.
Desculpa, eu não tinha. É que aqui eu tô com menos telas do que o
normal, então eu fico mais atrapalhado. Mas beleza, vamos ao conteúdo.
Hoje a gente vai falar aqui sobre sete grandes pontos, tá? Povo? Eu vou
engatar a segunda marcha aqui agora porque eu quero levar minha esposa
para jantar e eu quero te entregar esse conteúdo de maneira muito
organizada e estruturada. Então não vou ficar olhando muito pro chat
hoje porque eu não tô com muitas abas. Eu vou tentar. Hoje nós vamos
falar aqui basicamente sobre sete grandes pontos. O que que são os os
formulários nativos ou instantâneos? Quando que você utiliza vantagens e
desvantagens, como que você cria eles? Como é que você cria as campanhas
de formulário nativo, metas de desempenho, um assunto que pouca gente
fala e para quais públicos nós devemos anunciar. Beleza? Então nós vamos
explorar esses sete pontos aqui. Você vai ver que essa vai ser uma live
rápida e eficiente. O que que são formulários nativos? Formulários
nativos são formulários que abrem direto nos aplicativos da meta quando
alguém clica no seu anúncio. Pedro, não entendi nada. Você tá lá
navegando no Instagram, no Facebook, no WhatsApp, no Stories, no ReS,
apareceu um anúncio para você. Você clica no anúncio. Clicou no anúncio,
o que que acontece? Ao invés de você ser levado para um site, o próprio
Facebook, o próprio Instagram, o próprio aplicativo abre na sua frente
de forma nativa, um formulário. O que que é um formulário? Formulário é
um lugar para você colocar nome, e-mail, telefone, suas informações de
contato. Por que que as empresas, e aí desculpa aí pro nível básico
aqui, mas eu sei que tem gente que tá começando, por que que as empresas
valorizam tanto o contato das pessoas? Porque o contato das pessoas é o
primeiro passo para que a gente venda para essas pessoas. Imagina o
seguinte, eu tenho uma lista de 100 contatos, eu sei que eu consigo
vender um produto de, sei lá, R$ 10.000 para 1% dessas pessoas. Então eu
sei que cada contato, ó, eu tenho uma lista de 100 contatos e eu sei que
para essa lista de 100 contatos eu vou fazer pelo menos uma venda de R$
10.000. Então, se eu pegar R$ 10.000 R$ 1.000 e dividir por 100, quer
dizer que cada contato nessa lista vale R$ 100. Então é como se cada
contato que eu tô conseguindo eu tivesse colocando R$ 100 no meu bolso.
Cada contato é R$ 100 no meu bolso. Só que eu só consigo sacar esse
dinheiro quando eu tenho todos os contatos. Então aí a gente já tem
algumas métricas, alguns dados importantes. Tem gente que complica
demais o tráfego pago. Tráfego pago é simples. Quando a gente tá falando
de leads, que são esses contatos, essas pessoas que me deram as
informações de contato delas, eu tenho que sempre olhar para o número de
leads, então quantas pessoas eu tô trazendo. E eu tenho que olhar pra
taxa de conversão desses leads. Que que é a taxa de conversão? É esse
percentual. Quantos por cento dessas pessoas, desses contatos, compram
um produto meu? Se eu sei quantos por c, se eu sei o valor do produto,
eu consigo fazer o cálculo de quanto que cada contato vale para mim. Que
que eu quero dizer com tudo isso? Contatos valem dinheiro. E se você
sabe gerar contatos para outras empresas ou paraa sua própria empresa,
você tem nas suas mãos o quê? uma máquina de imprimir dinheiro. E as
campanhas de formulários instantâneos são campanhas em que as pessoas
estão navegando pelo Instagram, pelo Facebook, clicaram no seu anúncio
plu, instantaneamente, sem ter que carregar, sem você ter que ter site,
sem você enviar as pessoas para uma página, abre na frente delas um
formulário para elas preencherem as informações delas. Muitas vezes o
próprio Instagram já sabe o nome, o e-mail, o telefone da pessoa e
preenche paraa própria pessoa, tá? Então são isso que são os formulários
nativos. Beleza? Estamos ficando entendido? Se você já tá aqui nessa
live pela primeira vez e tá falando assim: "Caraca, esse maluco ele tem
uma maneirinha meio louca de explicar, mas ele explica as coisas. Eu
entendi, eu não sabia nada sobre esse assunto. Talvez fique um terminho
ou outro ali que você tá com dúvida, mas normal. O nosso mantra aqui é a
confusão. É o primeiro passo do entendimento. A gente vai descomplicando
a sua cabeça. Eu vou colocando tráfego pago nessa sua cabeça para você
ganhar dinheiro. Se isso aconteceu, já vai deixando o like aqui no nosso
vídeo. Beleza, Pedro? Entendi o que que são os formulários nativos. Eu
vou te mostrar na prática daqui a pouco o que que são eles de maneira
mais visual. Pode ficar tranquilo, tudo aqui tá planejado. Número dois,
quando que você vai utilizar esses formulários nativos? E aqui que vem
as três, as quatro situações. Eram três, eu acabei de inventar mais uma
porque quem sabe faz ao vivo. Então quando que a gente vai utilizar?
Primeira situação, eu vou utilizar quando eu tiver buscando por leads
qualificados. Lembrando, o que que é o lead? Lead é o contato, é a
pessoa que deixou o nome, e-mail, telefone, as informações pra gente
entrar em contato com a pessoa. Então, quando eu estou buscando por um
lead qualificado, B2C, Pedro, o que que é B2C? é business buzines to
consumer. Então é negócio para o consumidor. É alguém que vende pro
consumidor final. Uma barbearia vende pro consumidor final um dentista,
um delivery, um restaurante. Tudo que é negócio que vende pro cliente
final é B2B. Pedro, mas que outro tipo de negócio que não vende pro
cliente final? um negócio que a gente chama de B2B. Que que é B2B? B2B é
business to business. Business to. A gente usa o dois, né, para dizer
que é para business to business. Isso quer dizer que é negócio para
negócio. Por exemplo, eu tenho uma empresa de serviço de limpeza, só que
eu não faço faxina na sua casa, eu faço faxina em indústrias. Então, o
meu cliente final é uma outra empresa. Eu sou uma empresa vendendo para
uma empresa. Agora, eu sou uma empresa que faz faxina na casa das
pessoas. Nesse caso, eu sou uma uma empresa B2C. Então, quando eu tenho
um negócio que eu tô buscando um que eu tô que eu tô B2C, mas um ticket
médio alto, o que que é o ticket médio? É na média quanto que custa o
serviço? Então eu tenho um negócio que vende pro consumidor final e o
ticket médio ele é alto e eu tenho um comercial ativo. Pedro, o que que
é comercial ativo? Nessa frase aqui que você soltou, eu já não tinha
entendido o que que era lead. Eu já não sabia o que que era B2C. Eu já
não sabia o que que era ticket médio, mas a coisa tá tá acontecendo, o
conhecimento tá entrando na sua cabeça. Então, lead é o contato, B2C é
um negócio que vende pro consumidor final, ticket médio é o valor médio
do contrato e time comercial ativo é o time que recebi o lead. Toma
ligação, vou falar com você. Você já se cadastrou alguma vez em algum
lugar e a pessoa te ligou de volta na hora? Cadastrei lá num site em
algum lugar, putz, me ligaram na hora. comercial ativo. A pessoa tá indo
atrás de você ativamente, você fez o cadastro, ela vai atrás de você. Se
essa é a situação, você tá fazendo tráfego para um negócio B2C, ticket
médio alto, e eles têm um comercial ativo, usa a campanha de formulário
inativo. Vai dar bom, vai dar bom. Confia em mim. exemplos de negócio
que utilizam isso, clínicas no geral, clínica de emagrecimento, eh,
clínica de médicos, clínica de cirurgia plástica, academia usa isso
muito, aula de yoga, imobiliária, pessoas que trabalham com arquitetura,
eh, designer de ambientes, arquiteto, gente que trabalha com móvel sob
medida também é um nicho que isso funciona muito, rede de consórcio,
plano de saúde, escola particular, associações de empresas, agência de
modelos, negócios fora do Brasil, negócios no exterior. Todos esses são
excelentes exemplos de negócios para você utilizar eh dentro dessa
categoria aqui os formulários nativos. Só que a gente também vai usar o
formulário nativo para B2B, quando eu preciso de informações da empresa
antes de fazer o contato. Então, lembra para que que serve o formulário
nativo? para eu colher informações, nome, e-mail, telefone e eu posso
até fazer outras perguntas ali no meio. A gente já vai falar sobre isso.
Então eu estou, quando eu preciso ter dados da empresa antes de falar
com a empresa, antes de tentar vender paraa empresa, eu vou utilizar o
formulário nativo. E por último e não menos importante, penúltimo, né,
que eu falei que adicionei mais um como teste alternativo para quem já
capta leads com landing page. Vamos lá. Landing page, Pedro, que que é
isso? landing page nada mais é do que uma página. Por exemplo, agora
nesse instante você está aqui, ó. Deixa eu abrir o meu canal do YouTube
aqui na sua frente. Ô meu Deus, não consigo digitar meu próprio nome.
Você está aqui neste canal agora, nessa live aqui, ó. Você tá aqui nesse
Não, tô na live errada. Tô na live errada, desculpa. Fui no lugar
errado. Agora sim. Você está aqui, ó. Essa daqui é a live que você tá.
Se você for na descrição dessa live, você vai encontrar aqui, por
exemplo, um link para você entrar na lista de espera da comunidade
subido, que é o nosso curso. Isso daqui nada mais é do que o quê? Isso
aqui é uma landing page, é uma página que eu tô pegando seu nome, seu
e-mail, seu WhatsApp. Isso aqui é um, eu tô pegando seus dados de
contato. Então, ao invés de te enviar para essa página, eu poderia fazer
um anúncio, poderia testar fazer um anúncio em que eu estou te enviando
para o formulário nativo. Então, se você já faz captação de leads, você
pode testar isso. Pedro, qual que é a última alternativa que você falou
que tinha mais uma? A última alternativa é você utilizar ao mesmo tempo
o formulário nativo e a landing page. Isso daqui é uma opção que a Meta
colocou não faz tanto tempo, mas você pode utilizar os dois ao mesmo
tempo. Então, se você já tem um site e você tá levando as pessoas pro
site, faça esse teste, configura lá a meta e eu vou te mostrar como é
que você faz. configura a meta para ela enviar as pessoas que têm mais
chance de ir para sua página e converter paraa página e as pessoas que
têm mais chance de ir pro formulário e converter no formulário. Qual que
é a diferença dos dois? A diferença é que uma pessoa vai até o seu site,
outra pessoa vai abrir o formulário dentro da própria ferramenta.
Beleza? Beleza. É aí que eu vou utilizar agora vantagens e desvantagens
que nós temos. Quais são as grandes vantagens? São três. Primeiro, a
gente tem menos resistência. a pessoa não precisa ir até a página e a
gente tem uma tendência, não é uma certeza, mas é uma tendência de ter
maior volume de leads do que na landing page. Então, provavelmente eu
vou ter mais pessoas se cadastrando do que na página. E o terceiro ponto
é que, pô, não precisa de página, então assim, não precisa fazer página,
não precisa fazer site. Tudo bem que isso é uma coisa muito fácil hoje
de fazer um site com inteligência artificial, você faz um site em poucos
cliques, tá? Mas não é algo que a gente precisa para gerar resultado com
tráfego pago. Se tiver é melhor. Desvantagens. Pode trazer um lead menos
qualificado. E aqui a gente já começa a entender um grande conceito, que
é um conceito de qualificação de lead. Pedro, o que que é a qualificação
do lead? Imagina o seguinte, eu tô divulgando um produto de tráfego
pago. Aí agora eu quero eu quero que você me responda no chat, tá? Eu tô
divulgando um produto de tráfego pago, ele se chama Comunidade Subido de
Tráfego. Lá você tem acesso a seis cursos completos. Você tem acesso a
uma centena de ferramentas de inteligência artificial que te ajudam a
fazer, a aprender, a botar o tráfego pago dentro da sua cabeça. Tem
curso do zero até o avançado de meta, Google Ads, TikTok Ads, LinkedIn
Ads, otimização de campanhas, estratégias de tráfego pago, curso de
prospecção, relatórios. Aí tem live sobre cada e para live de tráfego
para cada um dos nichos que existem. Enfim, é o curso mais completo que
existe no universo sobre tráfego pago. Vamos dizer, exemplo hipotético,
que eu vendo esse curso. Não quer dizer que eu venda ele, mas vamos
dizer que eu vendo. Aí tem duas pessoas que eu cadastrei de interessadas
nesse curso. A primeira pessoa é a dona Josefa. Dona Josefa tem seus 74
anos de idade, nada, não tem problema com a idade. Tem gestores de
tráfego, gestoras de tráfego. Conheço uma que o o Instagram dela é a
vovó do tráfego. Ela tem começou com 62 anos e ganha super bem. Mas a
dona Josefa, 74 anos, não teve nenhum contato com a internet. A
[roncando] dona Josefa cadastra no meu anúncio, eh, e ela coloca lá, ela
responde uma pergunta ali na no meu formulário dizendo que ela não tem
interesse nenhum em aprender tráfego pago. Eu não sei porque que ela
cadastrou, mas a dona Josefa cadastrou no meu anúncio. E aí eu tenho uma
segunda pessoa, então dona Josefa, pessoa A. Aí eu tenho uma segunda
pessoa, a pessoa B. Pessoa B é a Maria. A Maria ela é social mídia, só
que a Maria não consegue gerar vendas pros clientes dela. Ela começou a
sentir que ela tá com um monte de cliente ruim e que ela poderia estar
cobrando mais. por cada cliente se ela aprendesse tráfego pago. Aí a
Maria coloca lá que ela tem super interesse em aprender tráfego pago. E
aí eu tenho uma terceira pessoa que é o Mário. Aí o Mário ele já é
aspirante a gestora de tráfego. Ele não tem nenhum cliente, mas ele
consumiu todos os meus conteúdos gratuitos e ele tá muito disposto a
comprar o meu produto. Col o Mário é a pessoa C. Coloca no chat a ordem
das pessoas que mais tem chance de comprar. Talvez alguém vai dizer que
é o B primeiro, talvez alguém vai dizer que é o C, mas provavelmente a
gente vai ter as respostas como C, B e A. O que que quer dizer C, B e A?
Essa ordem. Eu tenho ali uma qualificação dos meus leads. Tem pessoas
que se cadastram e não é pessoal, mas é de acordo, a gente tá falando de
negócios aqui. Tem pessoas que se cadastram que t menos qualidade do que
outras pessoas. E aí a gente vai medir essa qualidade onde? na taxa de
conversão da lista. Hum, não entendi nada. Que que é esse negócio de
taxa de conversão da lista? Lembra o exemplo que eu te dei? Eu tenho 100
leads. Um lead comprou. Isso quer dizer que 1% compra. Essa daqui é a
taxa de conversão. Taxa de conversão igual a 1%. Se eu trago pessoas
ruins, essa taxa de conversão, ela vai diminuir. Pode ser que a minha
taxa de conversão ela seja de 05%. Agora 0% compra. Minha taxa de
conversão é de 05%. Então uma um lead mais qualificado é um lead que tem
tendência a comprar mais. É um lead que tem tendência a ter uma taxa de
conversão maior. Estamos entendidos? Sim ou não? Fala para mim no chat,
por favor. Estamos entendidos? Preciso do seu feedback em relação a isso
pra gente seguir em frente. Deixa eu pegar meu garrafão d'água aqui.
Sim, entendido. Entendido, entendido. Entendido, entendido. Maravilhoso.
Vamos para cima, então. Então, essa daqui é a primeira desvantagem.
Segunda desvantagem, você vai levar esses leads serão armazenados em uma
planilha. E aí você pode utilizar como ferramentas de automação para
levar esses leads de uma planilha até outro lugar, mas você vai precisar
constantemente acessar essa planilha ou ter uma ferramenta de automação.
Se você é nosso aluno lá na comunidade subido, vale lembrar que a gente
tem um curso de habilidades complementares. Lá a gente fala de CRM e lá
a gente fala também, tem um curso só de automações lá. Esse curso
resolve esse problema para você, tá? Mas se você não tem acesso, tá tudo
bem. Você consegue acessar todos esses leads, porque imagina, a pessoa
vai cadastrar, mas esse e-mail, esse telefone, esses dados vão para
onde? Eles vão para uma uma planilha. Que que é automação? Automação é
automaticamente toda vez que a pessoa cadastrou, tá? O nome dela lá lá
lá na planilha, você pega aquele dado e você manda para outro lugar, pro
WhatsApp do cliente. Você manda para uma ferramenta que armazena os
contatos. Isso é automação, mas você pode fazer isso manualmente também,
dependendo do volume, é super viável. E o terceiro grande ponto aqui é
que se os leads, se forem leads que você entra em contato, você precisa
ser rápido. O que que eu quero dizer com leads que você entra em
contato? Vou te dar um exemplo. Vamos dizer que você cadastrou para um
evento gratuito que eu vou fazer. Inclusive, povo, agora nas próximas
semanas a gente começa a divulgar eh um evento gratuito que a gente vai
fazer. É um evento super diferente, a gente nunca fez antes esse evento
gratuito. Vai ser uma pancadaria de conteúdo e vai ser muito legal
porque a gente vai falar muito de uma gestão de tráfego com um olhar
para cenário de 2026, tá? Então, não sei agora se você tá vendo isso
aqui ao vivo, não tá disponível, mas se você tá vendo a gravação, talvez
no futuro, provavelmente o link já está na descrição para você se
cadastrar no nosso evento, tá? Então fica a chamada aqui. Por enquanto
não tá disponível, mas no futuro vai estar. Usando o meu evento, como
exemplo, você cadastrou no meu evento, eu não tenho que ligar para você
para vender nada para você. Eu não vou ligar para você para vender nada
para você, porque eu só quero que você vá no evento. Então eu não tenho
que entrar em contato para te vender. Mas se eu tivesse jogando você,
por exemplo, lá para as pessoas que lista de espera, tá? Pessoas que
estão interessadas no meu produto, joguei você aqui paraa lista de
espera. Inclusive, se você quiser cadastrar na lista de espera, pode
cadastrar, tá? Joguei você aqui paraa minha lista de espera para você
fazer o seu cadastro. Assim que você cadastrar, eu o quanto antes eu
entrar em contato com você, maior é a probabilidade de eu vender para
você. maior é a probabilidade. A gente tem uma tem um pesquiso uma
pesquisa feita pelo MIT que ele fala que a cada minuto de demora o valor
do lead diminui. Então a qualidade do lead ela decaio que eu demoro para
ligar pra pessoa. Se eu demoro mais de 30 minutos depois do cadastro
para entrar em contato, é duas vezes mais difícil de eu vender para você
do que se eu entrasse em contato com você logo nos primeiros 30 minutos.
Então essa velocidade que a pessoa olha a planilha com este contato e
liga pro lead, ela é muito importante. Isso é legal você saber porque
esses esses dados até vou ter até vou colocar aqui para você, ó. Deixa
eu compartilhar minha tela. Esses dados tem é a curva. Au, eu cortei o o
nome da pesquisa do MIT. Deixa eu apagar aqui. Vou botar de novo com o
nome, ó. Então, lead response study. Dá para depois pesquisar a
pesquisa, tá? É uma pesquisa bem legal. Então, basicamente, ela fala o
seguinte, que se se eu entro em contato com a pessoa no primeiro minuto,
eu tenho 391% a mais de conversão. 5 minutos, 21 vezes chances, 21 vezes
mais chances de qualificar. 10 minutos essa essa probabilidade da pessoa
ser qualificada já cai para 80%. 30 minutos é 100 vezes mais difícil de
fazer contato com a pessoa. Então, às vezes você tá gerando tráfego pago
para um cliente e ele tá dizendo: "Ah, o lead tá desqualificado". E não
é ele que tá demorando para entrar em contato. Isso tá matando o lead.
Porque o lead ser qualificado ou não, não depende só da pessoa que
preencheu, depende da velocidade que o atendente entra em contato com
ela, porque a nossa curva de atenção sobre os assuntos, ela cai com o
passar do tempo. Beleza? Entendido? vantagens e desvantagens. Número
quatro, como é que a gente cria esses formulários nativos? Eu vou ir pra
prática agora com você, mas primeiro vamos estabelecer uma lógica
simples aqui. A lógica básica é o seguinte. No meu formulário eu posso
colocar várias etapas diferentes. O que que são etapas? Perguntas, eh
mensagens. Eu posso, eu posso colocar 50 perguntas num formulário ou 10.
Um formulário com 10 perguntas vai ter mais pessoas preenchendo ele até
o final do que com 50. Então, quanto mais eu tenho, o lead é mais caro.
Então, o preço que eu pago pra pessoa cadastrar até o final é mais caro,
porque eu tô jogando um monte de gente lá dentro, mas tem um monte de
gente indo embora no meio do caminho. Eu só considero lead, eu só
considero contato a pessoa que foi até até o final, até a etapa final.
Beleza? Então, eu só vou considerar o lead o cara que foi até o fim. Só
que o lead ele pode, não é certeza, tá? Ele pode ser mais qualificado.
Isso aqui é quase um sabor mais qualificado. Eu acho péssimo esse meme,
mas você vai entender. Agora, se eu tenho menos etapas, eu tenho um lead
mais barato e ele pode ser menos qualificado, tá? Isso aqui é a lógica
básica, isso daqui é o ABC da qualificação dos leads que você tem que
entender, tá? Então, se eu coloco muita etapa, vai ficar caro demais. Se
eu coloco pouca etapa, eu tenho que cuidar com a qualidade do lead. Não
é certeza que ele vai ser menos qualificado, mas ele pode ser menos
qualificado, tá? Vamos em frente. Como que a gente vai criar esses
formulários? É o seguinte, você vai precisar de uma conta aqui no
gerenciador de anúncios. O gerenciador de anúncios, você vai criar sua
conta aqui completamente de graça. Não tem que pagar nada para criar a
conta de anúncio aqui no gerenciador de anúncios. E é aqui dentro. E aí
eu recomendo assim que você crie a conta porque não vai gastar nada, não
vai ter nenhum problema você criar uma conta no gerenciador de anúncios.
Se você gestor de tráfego, até tava no começo da live aqui, eu vi alguém
perguntando quantas lives vocês demoraram para começar a prospectar. Não
é questão de número de lives que você viu, é o tanto que você o tanto
que você tangibilizou o conhecimento das lives. Então você pode vir aqui
e você pode assistir o conteúdo e achar muito legal, sair daqui com
aprendizado ou outro, mas o ideal mesmo é que você coloque a sua
mãozinha na massa durante o processo, tá? Então vamos aqui, você vai
clicar aqui em todas as ferramentas, no seu gerenciador de anúncios e
aqui em Metabusiness Suitch você vai ter os formulários instantâneos.
clicou aqui em formulários instantâneos, você vai ouvir muita gente
chamando eles de formulários nativos e formulários instantâneos. Eles
vão se abrir aqui na sua frente, tá? Se abriram aqui na sua frente, você
vai clicar nesse botão de criar um formulário. E aqui nós temos 10
etapas para criação de um formulário, tá? Nossa, é muito, é só seguir o
passo a passo, não tem erro, tá? Então, a gente vai criar um formulário
do zero. Vou avançar aqui com o meu formulário. Sempre coloque um nome
que você saiba o que que é aquele formulário, tá? Daí vai para vai de
cada um e a gente vai pra etapa número um, que é a definição do tipo de
formulário. Nós temos basicamente três tipos de formulário. Nós temos
maior volume, nós temos maior intenção, nós temos criativo avançado. E
aqui, povo, é engraçado, eu vejo muitas vezes umas pessoas criando um
apocalipse na internet de a gestão de tráfego pago vai acabar. Aí eu
falo assim, cara, alguém vai ter que decidir o tipo de formulário,
alguém vai ter que fazer as configurações, alguém vai ter que fazer as
escolhas corretas para cada tipo de negócio. E aí esse alguém é o gestor
de tráfego. A IA vem para te dar um super poder. Ela vem para expandir
as suas habilidades de gestor de tráfego e não para roubar o seu
trabalho de gestor de tráfego. Beleza? Vamos em frente. Então, nós temos
os três tipos de formulário, ó. Eu vou selecionar aqui maior volume,
maior intenção ou criativo avançado. Quando é que você vai utilizar cada
um deles? Maior volume, começa por ele. É o que você vai usar quase
sempre, tá? Lad mais barato. E aí cuidado, não é certeza que ele não vai
ter qualidade, mas cuidado com a qualidade do lead. Maior intenção vale
o teste. Qual que é a diferença da maior intenção? é que quando eu uso
Maior Intenção, ao final do formulário, a pessoa tem que confirmar que
aqueles dados são realmente dela. É isso. Ah, mas isso não é bom. É bom,
mas mais lad mais caro, custa mais caro pra pessoa confirmar até o
final. Um monte de gente abandona. Ah, mas é só uma etapinha mais. Sim,
mas as pessoas abandonam e não terminam o cadastro, tá? Então assim,
vale o teste e aí o cuidado aqui é com o custo por cadastro, porque ele
pode acabar ficando mais caro do que você tava imaginando, tá? E aí, usa
esse daqui, eu gosto de deixar ele para depois, por isso que eu começo
com maior volume. Usa se você tem muita gente eh preenchendo o
formulário, mas não tá dando retorno. Então assim, pô, tô tendo
preenchimento, mas cara, não tá vendendo, não tá botando dinheiro no
bolso, a qualidade não tá legal, dá uma olhada, testa a maior intenção.
E aí o criativo avançado, cara, esse aqui ele é meio bosta, tá?
Desculpa, mas ele simula uma landing page, ele simula uma página, você
pode colocar depoimento, pode colocar produto, pode colocar diversas
informações. Aqui vale o teste para e-commerce, tá? Vale o teste para um
e-commerce. Eu testaria para tentar vender alguma coisa, pegar o lead da
pessoa, mas também não é minha primeira opção, tá? Não é assim, nossa,
com certeza. Então é isso daqui que eu vou utilizar agora. Beleza? Ponto
número um. É isso ai. Qual que é a diferença? Não tem. Você selecionou
aqui o maior intenção, ó. Tá vendo? Olha aqui do ladinho aqui, ó. Olha o
meu mouse aqui, ó. Quando eu boto em mais volume, tem política de
privacidade e encerramento. Se eu seleciono maior intenção, surge aqui a
tela de avaliação. Então, é só a tela pra pessoa validar se as
informações dela são aquelas informações, tá? Então, não muda nada.
Agora, se eu boto criativo avançado aqui na apresentação, que é a
próxima etapa, eu vou poder selecionar imagem, eu vou poder colocar um
título, eu vou poder colocar os benefícios do que que eu tô entregando
para as pessoas, eu posso contar a minha história, eu posso falar como
funciona, eu posso colocar os meus produtos, eu posso colocar eh
comprovante social, incentivo, eu posso colocar um monte monte de coisa
aqui, tá? Então fica um negócio mais completo. Ah, Pedro, mas isso não é
bom nem sempre, tá? No geral a gente vai começar com mais volume mesmo.
É aqui que a gente vai ter mais resultado. Beleza? Agora vamos pra
próxima etapa. Então, número dois, contrtrl C. A gente vai aqui para
baixo, ó. Então, tipo de formulário é a primeira etapa. Aí, vim aqui
para baixo, eu tenho o quê? Eu tenho a entrega do formulário flexível.
Pedro, o que que é a entrega do formulário flexível? É o seguinte, a
meta ela vai variar os elementos do meu formulário para buscar um melhor
desempenho. Quando que você vai utilizar isso daqui? Faz sentido você
ativar isso daqui se você usar o criativo avançado ou maior intenção.
Então, se eu tô usando maior intenção ou criativo avançado, eu acredito
que vale muito teste, tá? Ele não vai excluir perguntas do meu
formulário. Ele pode mudar a imagem de fundo, ele pode pular a
introdução e as perguntas podem ser reordenadas, mas não retiradas. As
perguntas opcionais podem não aparecer porque elas são opcionais. E a
mensagem pros leads pode ser removida ou exibida num local diferente,
tá? Então ele vai brincar com o meu formulário. Eu gosto de deixar o
manual aqui, deixar tudo selecionado, sei lá, porque eu tenho toque, tá?
Mas só vou usar isso daqui se eu for de maior intenção ou criativo
avançado. Caso contrário, maior volume não faz sentido deixar isso aqui
ligado, porque maior volume não vai ter muito o que a meta ficar
variando a ordem das coisas ali para mim, tá? Se quiser deixar ativado,
vai mudar nada na sua vida, tá? Ponto número dois é esse. Eh, e aí minha
sugestão para você é o seguinte. Se você vai rodar uma campanha, vai
usar o criativo avançado ou maior intenção, roda, bota para bota para
rodar dois formulários em paralelo. Um formulário com essa opção ativada
e uma sem essa opção ativada. Vê o que funciona melhor. Não precisa
fazer um teste super bem estruturado, não. Roda o mesmo anúncio, uma com
formulário, outra com outra. O que funcionar melhor, deixa ativo. O que
não funcionar, pausa e let's go. Depois, apresentação. Nós temos aqui a
imagem de fundo. Ela é opcional, mas minha minha resposta para ela é que
ela é meio inútil, tá? Não muda muita coisa. Pode colocar. Se você for
colocar, eu recomendo que você eh utilize uma imagem do tamanho correto,
tá? Então assim, eh, a ele vai replicar a imagem do seu anúncio e aí às
vezes vai ficar horrível a imagem do seu anúncio aqui. Aí se ficar
horrível desativa. E para você subir uma imagem aqui, carregar uma
imagem, você tem que colocar uma saudação que também não tem nada a ver,
que é inclua detalhes relevantes e explique melhor o por que as pessoas
devem preencher o formulário. Isso aqui não não me ajuda em nada. Isso
aqui é só mais etapas. Mais, lembra o que que acontece? Mais lead mais
caro, pode ser mais qualificado. Nesse caso, ele não vai ser mais
qualificado porque eu tô colocando só uma uma saudação, tá? E aí essa
apresentação, né, que é essa saudação aqui, deixa eu, eu botei a
apresentação, mas é saudação. Escrevi errado, desculpa. Essa saudação,
ela é uma etapa mais igual lead mais caro. Eu só usaria ela, tá? só
usaria ela em duas situações. Primeira situação, se eu tô com muito lead
desqualificado, pô, tá muito ruim mesmo, eu tô tentando de tudo e o
negócio não tá virando, aí eu utilizaria aqui a saudação. Ou segunda
opção, se eu tô com muita abertura do formulário e pouco preenchimento,
porque a saudação ela pode servir como um incentivo pra pessoa se
cadastrar. Aí eu vou jogar uma cópia aqui. Preencha o formulário para
transformação X YZ. Aí eu vou vender o meu formulário paraa pessoa aqui,
tá? E aí eu vou botar o por que a pessoa deveria se cadastrar nesse
formulário aqui. Então eu vou deixou vou dar um incentivo, eu vou
convencer a pessoa. Então eu só usaria a saudação como uma ferramenta de
qualificação de leads ou então como uma ferramenta de persuasão, tá?
Esse essas seriam as situações que eu usaria a saudação. Próximo. Ai,
quase cliquei no botão errado. Próximo. Então, não vamos a saudação, não
vamos à imagem de plano de fundo. Aí aqui não vamos a nada na
apresentação, não vamos a nada, tá? Vou pro próximo aqui. Perguntas aqui
é o quê? É uma etapa mais igual lead mais caro. Mas presta atenção, aqui
o jogo muda. Por quê? Porque com as perguntas eu consigo qualificar o
meu lead. Com as perguntas eu consigo garantir que aquela pessoa é uma
pessoa qualificada. Então quando que eu vou utilizar as perguntas? Você
vai utilizar muitas vezes quando você precisa classificar e qualificar
os leads. Como assim classificar, Pedro? A gente tem uma coisa que a
gente chama de lead scoring. Que que é lead scoring? é a pontuação dos
leads. Vou dar um exemplo para você. Você, daqui a pouco a gente vai
começar as divulgações desse novo evento que a gente vai fazer. Você vai
se cadastrar, tá? Você vai. Por quê? Porque, pô, você é você tá aqui na
live, você é a nata da nata, você é a típica pessoa que vai virar gestor
de tráfego pago e vai ganhar dinheiro. Real, ah, você tem mais chance de
virar gestor de tráfego e ganhar dinheiro do que alguém que não tá aqui.
Eu sei disso por dados, de 380 lives que eu fiz na vida e mais de
100.000 gestores de tráfego que eu já treinei. O padrão é pessoas que
estão aqui são acima da média, tá? Só que quando você for se cadastrar
nesse evento, você vai responder algumas perguntas. Depois que você se
cadastra, eu mando umas perguntas para você. Se você quiser, você
responde. Se você não quiser, você não responde, não tem problema. Mas
quando você responde essas perguntas, cada pergunta que você responde,
eu tô dando uma nota para você de qual que é o seu valor. Para mim tem
pessoas que tm uma nota mais alta, que elas são mais qualificadas. Vou
dar um exemplo. E aí assim, não quer dizer que se você não tem ensino
superior completo, você não pode ser gestor de tráfego pago. Não. Hoje
mesmo eu tava vendo o depoimento de um aluno, o nome dele é é Mateus.
Mateus trabalha trabalhou na obra desde os 11 anos de idade, pediu
demissão em 90 dias, estava faturando 5.000 por mês como gestor de
tráfego. Então assim, e ele não é exceção, mas a maioria dos meus alunos
tem faculdade. Então, se você votou lá que você tem faculdade, eu dou um
pontinho a mais para você do que se você não tem. Isso é o quê? Isso é o
lead scoring. Eu tô classificando os meus leads. Ai, Pedro, mas isso
deve ser um negócio complexo de fazer, não é? Às vezes com uma pergunta
você já sabe se a pessoa é boa, se ela não é. Que tipos de pergunta que
eu posso fazer? Eu te mostro aqui. Você pode colocar perguntas como você
vai vir aqui, ó, perguntas, tá? Aí você vai adicionar a pergunta. E eu
gosto muito de ativar esse lógica condicional. Gosto muito, não. Ativa o
lógica condicional. Você vai adicionar uma pergunta e aí você pode pedir
múltipla escolha, resposta curta ou solicitar uma hora marcada para
falar com você. Isso aqui eu vi pouquíssimas pessoas usarem. Normalmente
múltipla escolha. E aí ele dá aqui exemplos de perguntas. É legal você
clicar para você ter alguma ideia. Por exemplo, orçamento, quanto você
vai gastar? Linha do tempo, quando você pretende comprar. Necessidade?
Você tá procurando um carro novo ou usado? Vamos dizer que eu vendo
carro novo. Então, se a pessoa respondeu carro novo, eu vou enviar o
formulário. Se a pessoa responderu, se a pessoa respondeu que ela quer o
carro usado, eu vou dizer que eu quero fechar o formulário. Se a pessoa
falou que quer carro novo ou usado, eu falo que ela vai enviar o
formulário. Se ela ainda não decidiu, eu falo que ela vai enviar o
formulário. Mas percebe que se eu vendo carro novo, o cara que vende
cara do carro usado, eu não quero ele? Então eu vou dizer, acabou, não
vai preencher o formulário, fecha o formulário. Essa pessoa perdeu os
pontos aqui. E aí você vai fazer a pergunta que você quer. Então,
hábitos, com que frequência você compra seguros a cada 6 meses, uma vez
por ano? Eu posso jogar a pessoa de uma pergunta para outra e você pode
adicionar mais de uma pergunta. Lembra que mais o lead vai ficando mais
caro, tá povo? Isso daqui para mim, na moral, isso aqui é quase um curso
de formulário nativo. Eu nunca vi uma aula que explica o formulário
nativo assim. Isso aqui tá no detalhe. Isso daqui tá para você pegar,
reassistir essa aula. Isso daqui é uma arma secreta para você ganhar
dinheiro como gestor de tráfego pago, tá? 90% dos gestores de tráfego
pago da internet não sabe fazer isso daqui. 90%, eu garanto para você,
eu garanto para você. Tá? Então, pô, solta o dedo nesse like desse vídeo
aí, que isso aqui tá uma palhaçada, tá? Então, eu vou usar as perguntas
quando, presta atenção, quando eu quero classificar e qualificar os
leads e eu vou usar essas perguntas quando eu o meu comercial precisa
dessas respostas para qualificar o lead. Então, vamos dizer o seguinte,
o exemplo do carro, eu vou lá e coloquei: "Ah, você quer comprar que
carro? Eu quero comprar carro zero, quero comprar carro seminovo, quero
comprar carro usado ou ainda não decidi ou qualquer um. Aí eu vou para
uma outra pergunta. Quanto que você quer gastar num carro? X.000, Y,
15.000? Que 15.000 não compra nenhum carro hoje no Brasil, né? Então,
30.000, 40.000, 50.000, 60.000 ou mais. Vamos dizer que eu tenho equipes
de vendedores diferentes. Se eu tenho a equipe que vende o carro usado,
eu preciso saber que carro que o cara quer comprar. Porque se o cara
comprou carro usado, eu já mando essa essa pessoa pro lugar certo. Se
essas informações me ajudam muito na venda, vamos dizer que eu não tenho
equipe diferente. O seu Roberto preencheu, cara, quer comprar um carro
usado na faixa de 50.000? Eu já ligo pro seu Roberto na hora, imagina,
seu Roberto cadastrou. Eu lembrei da aula do Sobral e falei: "Cara,
quanto mais rápido eu ligo, melhor". Seu Roberto cadastrou um minuto
depois. Alô, seu Roberto. Pô, vi aqui que você é da cidade de Itupeva.
Isso mesmo, pô. Legal, cara. Tem um primo que mora aí. Seu Roberto,
seguinte, vou sair direto ao ponto aqui com você. Vi que você tá
procurando um carro usado na faixa dos R$ 50.000. Eu tenho o seu carro
aqui. Eu não sei como é que já não inscreveram nele seu Roberto aqui
nesse carro. Como é que a gente pode fazer para você fazer uma visita
aqui? Você quer que eu leve o carro na sua casa? Eu já tenho seu
endereço aqui. Vi que você mora na rua eh Fernão Dias 312, Itupeva. Fica
perto daqui. Eu consigo fazer uma visita hoje no final do dia. Funciona
para você? Cara, aqui se eu fosse vendedor de carro era só na jugular do
seu Roberto. Por quê? Porque eu peguei as respostas, eu qualifiquei, eu
entendi que a pessoa tá com a intenção de compra. Vrau, não tem muito
segredo. Só que eu só eu tenho que usar as perguntas de maneira
estratégica e não de maneira aleatória porque ah, tem que colocar
pergunta porque qualifica. Não, qualifica se você souber aquilo que você
tem que perguntar, tá? E aí quando eu excluo, quando eu venho aqui, ó, e
eu excluo, ah, pessoa que compra seguro uma vez por ano, deixa eu, vamos
pegar outro aqui, ó. A pessoa que compra seguro apenas, deixa eu peg,
deixa eu pegar necessidade aqui, ó. Carro, a pessoa vai lá e não, eu não
tô vendendo carro usado. Eu não quero considerar essa pessoa uma
conversão. Eu não quero que ela conte como eu não quero que a meta
entenda que a pessoa que veio aqui preencher o carro usado, a meta
entenda que essa pessoa é meu lead. Eu quero que a meta entenda que essa
pessoa não é meu lead, porque a meta vai parar de buscar a pessoa que tá
buscando o carro usado. Ah, mas como é que a meta vai saber disso? A
meta sabe mais de você do que você. Então assim, não duvide poder da
meta, tá? Voltando, vou selecionar as perguntas ou não? Ou eu posso não
ter perguntas? Eu posso não ter pergunta nenhuma. Então não vou
adicionar nenhuma pergunta aqui. Só que aí a próxima etapa é a mais
importante. É por isso que a gente chegou até aqui, né? Por isso que a
gente tá fazendo o formulário num primeiro momento, que é que são as
informações de contato, tá? que é o número seis, informações de contato.
É o motivo pelo qual a gente criou esse formulário no primeiro momento.
E aí essa parte aqui das informações de contato, você vai vir aqui, ó, e
você vai adicionar os campos que fazem sentido para você. Ah, eu vou
perguntar a data de nascimento da pessoa, não sei. Faz sentido para você
saber isso? Não faz, não. Coloca. Vá, vou colocar o e-mail, o nome e o
telefone. Ah, não, eu preciso da cidade. Ah, eu preciso do estado. Eu
posso colocar que uma da uma uma das opções é opcional. Então, a pessoa
preencher a cidade é opcional. E aí eu sempre gosto de colocar as
opcionais no final, tá? Então, coloca primeiro todas as que não são e
depois as e depois as opcionais. Aí você vai colocando aqui o que faz
sentido para você. Beleza? Colocou o que faz sentido para você. Próxima.
Política de privacidade. Que que é a política de privacidade aqui, ó, na
próxima etapa. Política. Ué, por que que ele deu erro? Ah, tem que
colocar uma mensagem, tá? Preencha suas informações, tá? Aí você coloca
uma mensagem aqui. Isso aqui não vai mudar sua vida. Agora sim, política
de privacidade. Que que é a política de privacidade? Minha sugestão para
você é: roube como um artista. pega uma política de privacidade que
existe, deixa eu pegar a minha aqui, política de privacidade Pedro
Sobral, joga no GPT da vida e adequa ao seu negócio, tá? O ideal, o
ideal é que você não faça isso que eu tô te dizendo, tá? O ideal é que
você tenha um advogado que escreva sua política de privacidade, assim
como eu fiz, tá? E aí adequa ela ao seu negócio ou pega uma mais
genérica aí na internet, você vai precisar de um link de uma política de
privacidade. Beleza? jogou aqui a política de privacidade, você vai
colocar o texto, né? Aqui muda. Então, visite a política de privacidade,
tá? Fechou? Aí eu tenho os avisos personalizados. Aviso personalizado
você só vai utilizar se um nicho precisa de um consentimento, tá? Então,
a pessoa precisa consentir alguma coisa. entre nós aqui, eu nunca vejo
ninguém usar esse aviso legal aqui, tá? Então eu não me preocuparia com
isso daqui, tá? Mas minha missão aqui é te ensinar tudo, então eu vou eu
coloquei aqui na lista também. Depois disso, nós vamos para a última
etapa que é o encerramento, tá? Então o encerramento ele tem uma
mensagem final, tá? E aqui você vai esclarecer que o cadastro aconteceu
e convença a pessoa a clicar no próximo botão. Hoje o meu amigo Gabriel
Casagrande, um dos gestores de tráfego que mais fatura, que eu conheço,
ele falou que aqui ele escreve pra pessoa: "Pule a fila do WhatsApp e
pra pessoa clicar no botão." Aí ele fala assim: "Todo mundo gosta de
pular a fila". Então ele botou um título que incentiva a pessoa a clicar
no botão. Por quê? Porque no final aqui, deixa agora eu vou ter que sair
desse canto aqui onde eu tô. Deixa eu vir para cá. Porque no final aqui,
ó, a pessoa ela vai ter um botão aqui, ó. Tá vendo? Visitar site. E aí
eu vou botar aqui, ó, obrigado por se cadastrar. Para pular a fila do
WhatsApp, clique no botão, por exemplo. Clique no botão abaixo. E aqui
eu tenho umas opções. Eu posso mandar a pessoa pro meu site, eu posso
fazer a pessoa ver um arquivo, tá? Então aqui a pessoa pode baixar o
arquivo. Então se eu tô fazendo, divulgando um ebook, um PDF, a pessoa
pode baixar o arquivo. Eu posso colocar o botão paraa pessoa ligar pra
empresa. Então é uma campanha que funciona para ligação também. Então,
eu tô com os dados da pessoa, mas a pessoa já pode me ligar. Isso
funciona muito. Por quê? Porque a própria pessoa diminui o tempo de
contato. A própria pessoa tá fazendo o meu trabalho e eu tenho a opção
de conversar no WhatsApp. Para ter esse essa opção de conversar no
WhatsApp, que fica com a login do WhatsApp aqui, fica super bonitinho,
você já tem que ter o WhatsApp vinculado à conta, tá? E aí tem a chamada
para ação, que é o que vai tá escrito aqui, tá? Então, eh, converse,
você pode escrever aqui, ó, pule a fila. do WhatsApp. E aí vamos usar a
estratégia do Casagrande. Pule a fila do WhatsApp. Obrigado por se
cadastrar para pular a fila do WhatsApp. Clique no botão abaixo, pule a
fila do WhatsApp. Ou se você quer levar a pessoa para um site, leva a
pessoa pro site, tá? Daí vai mudar o botão aqui visitar o site. Agora
então a gente tem a mensagem, que é essa parte aqui que vai incentivar a
pessoa a apertar no botão ou vai simplesmente agradecer. E nós temos a
ação final, tá? Que são quatro opções, vai depender de cada um. Ou ir
pro site, ou ligar pra empresa, ou ver o arquivo, ou conversar com eh o
WhatsApp. E aí tem uma opção adicional que é conectar os leads no
Messenger, tá? que é o seguinte, a pessoa lá no finalzinho, depois de
mandar tudo, vai aparecer isso daqui para ela, ó, esse chequezinho.
Receba updates de Pedro Sobral e comece uma conversa no Messenger, eh,
que vão incluir as suas informações de contato. E aí a pessoa pode
selecionar isso daqui ou não. Vale o teste, vale, mas eu não começaria
com isso daqui não, tá? Eu acho que isso aqui pode encarecer por mais
uma etapa vai ficar mais caro, tá? Mas se você se fica bom para você ter
essas informações de contato, pô, 10 de 10, usa lá essa opção adicional
para conectar com os leads do Messenger, tá? Então assim, vale o teste,
mas não começaria por ele. Vale o teste, mas não começaria por ele.
Beleza, Pedro, como é que eu crio as minhas campanhas? E aqui eu vou te
dar uma resposta que é a resposta que você não quer ouvir, que é o
seguinte, cara. no meu canal do YouTube. Parece mentira, mas eu dou aula
ao vivo toda terça-feira 3 horas da tarde. E aí no meu canal do YouTube
tem uma aula em que eu só faço o processo de criar campanha na sua
frente, tá? É uma live, é a live é desse ano, então assim, tá
completíssima. Live 366. No final dessa live eu dou um presente para
você, que eu até hoje eu não acredito que eu entreguei isso aqui de
graça, mas eu te explico todo o processo de criação de campanha, tá? Aí
aqui você vai aprender a criar campanha, qualquer tipo de campanha, só
que quando você for criar campanha de formulário, ela vai ter duas
grandes diferenças, tá? Que é o seguinte, você vai selecionar a opção de
leads na hora de criar a campanha, tá? Selecionou a opção de leads, vou
vir aqui pro ladinho para ficar melhor. Você vai apertar aqui em
continuar. Aqui é tudo igual o que eu ensino na aula. Aí aqui na etapa
do conjunto de anúncio, a primeira coisa que você vai ter que definir é
onde que a conversão vai acontecer. Lembra que eu falei para você que
você pode jogar a pessoa pro site e pro formulário instantâneo ao mesmo
tempo? Eu sei que você não lembra, mas lá no comecinho eu falei para
você, ó, você pode utilizar ao mesmo tempo o formulário nativo e a
landing page. Como que você vai fazer isso daqui? Selecionando essa
opção aqui, formulários no site e instantâneos. Agora, Pedro, e se eu
quero só formulário instantâneo? É formulário instantâneo. Ah, e se essa
daqui que tem o Messenger também, eu não gosto, acho que ela não
funciona bem. Vai só no instantâneo ou se você tem os dois, usa o
formulário no site e o instantâneo. Jogou aqui formulário instantâneo,
top. Aqui você vai escolher a sua página, tá? Então, putz, vou ter que
aceitar os termos e condições aqui. Aceitei, deu, deu certo. E aí, aqui
você tem a meta de desempenho. Este pequeno detalhe absolutamente
inofensivo, que é a seleção dessas duas opções, pode deixar o seu lead
muito mais caro ou muito mais barato, tá? E aí eu já vou te explicar
sobre as metas de desempenho. É o seguinte, eu investi do meu próprio
bolso papo de R$ 50.000, tá? O carro lá do seu Zé, sei lá, o seu
Romário, seu Roberto, não lembro do nome dele, mas eu investi aqui, ó.
Ol, olha só, R$ 34.000 numa campanha, R.000 na outra, tá? Então isso
aqui deu, ó, R$ 60.000 R$ 1000 de presente para você. Eu gastei esse
dinheiro para você aprender isso daqui. Gastei R$ 60.000 para comparar
qual que é a diferença entre eu selecionar essa opção ou selecionar essa
opção. Que que muda quando eu seleciono isso ou quando eu seleciono
isso? Uma é o número de leads, maximizar número de leads. E a outra é
maximizar o número de leads convertidos. Vamos entender o que que são
essas duas coisas primeiro. Vamos lá. Maximizar número de leads é quando
eu quero trazer mais leads, maior volume, mas talvez talvez com menos
qualidade, tá? Isso daqui é o maximizar número de leads. Agora, o que
que é maximizar o número de leads convertidos, que é a nossa segunda
opção aqui. Maximizar número de leads convertidos é quando eu quero
trazer menos leads, mas eu quero trazer leads mais qualificados, tá?
Então eu vou trazer menos leads, mas eles têm um potencial de compra
maior. Pedro, foi isso que você verificou na prática? Vamos ver a
primeira linha aqui que vocês estão vendo, que é a número de leads. Eu
paguei R$ 2 paraa pessoa preencher o formulário e tive um total de
16.000 pessoas preenchendo o formulário. Na segunda campanha, que é a
campanha de leads convertidos, eu paguei R$ 3 para pessoa pessoa
preencher o formulário, gastando menos, tá? Então assim, esse valor ele
foi caro mesmo. Se tivesse gastado mais aqui, se eu tivesse gastado os
mesmos R4.000, esses R$ 3, isso daqui é para uns 13,30, uns R 3,40. E eu
fiz aqui 8.000 cadastros. Pedro, essas pessoas aqui foram muito mais
qualificadas do que essa aí que tá. Na prática não. Por quê? Porque eu
tenho muito mais pessoas aqui. O volume está compensando a falta de
qualidade. O que que é melhor? Eu tenho uma lista de 100 leads que
converte 10%. Ou eu eu ter uma lista de 10.000 leads que converte 5%.
Pô, é melhor eu ter uma lista de 10.000 leads que converte 5%. Se eu
pegar aqui 10.000 1000 x 5% eu tenho 500 conversões. Aqui eu tenho 10
conversões. Ah, mas a taxa é maior, tá? Mas a taxa não quer dizer nada.
A taxa não quer dizer dinheiro no bolso. Então cuidado com isso, tá?
Cuidado. Vale você testar? Vale, mas eu começaria se eu fosse você por
maximizar o número de leads. Pedro, tô com leads desqualificados.
Primeira coisa que eu faria muda para maximizar o número de leads
convertidos. Primeira coisa, antes de mexer no formulário, muda para
maximizar o número de leads convertidos, tá? Daí você vai seguir aqui a
sua configuração. Lá na parte do seu anúncio, você vai criar o anúncio e
aqui no destino, tá? Isso daqui é a etapa final. Eu tô te mostrando só o
que vai ser diferente do que tá nessa aula aqui, que o link dessa aula
vai tá na descrição. Então aqui no finalzinho, na hora de configurar o
anúncio, vai perguntar aqui formulário instantâneo. E aí você vai
pesquisar aqui pelo nome do seu formulário que você criou. Por isso que
é importante que você coloque um bom nome, tá? Na minha conta que eu tô
usando de exemplo aqui, não tem nenhum formulário criado, mas quando
você digitar aqui vão aparecer os formulários, tá? Você pode ter
formulários ativos. ou arquivados. E aí você pode criar aqui, apertar no
botão e criar aqui dentro da campanha mesmo o formulário, tá? Então,
dentro da campanha aqui, ó, vai abrir a mesma janela que a gente tava
brincando lá, vai abrir aqui e eu já posso criar o formulário aqui
dentro. Então você não precisa criar ele previamente. Eu gosto de criar
previamente porque para mim a coisa fica mais organizada, tá? Depois que
o formulário foi criado, depois que o seu anúncio foi pro ar, os seus
leads vão começar a cair aqui, ó. E você pode baixar os cadastros aqui,
tá? Então, você pode baixar esses cadastros aqui e você pode fazer
integrações, tá? Então aqui, ó, deixa eu tentar atualizar. O que que são
essas integrações? Eu posso integrar o meu formulário com uma planilha
do Google Sheets, tá? que é o que eu mais gosto de fazer, porque aí os
meus, todos os leads que caem, todos os leads que entram, eles vão para
uma planilha do Google e aí essa planilha eu compartilho ela com o meu
cliente ou eu mesmo tenho acesso. Dá para conectar no Gmail, dá para
conectar em outras ferramentas aqui também. Você pode procurar aqui para
ver se a ferramenta que você utiliza para gerenciar os seus contatos,
ela tá aqui, tá? Tem muitas ferramentas, tá? Então tem bastante chance
da sua ferramenta, ela tá aqui, dá uma procurada, se ela tiver, você faz
a conexão e aí a pessoa cadastra, ela já vai cair lá dentro do seu
sistema, tá? No meu caso, a gente usa uma ferramenta que se chama Active
Campaign, tá? Então, o Active Campain, ele já tem uma uma integração
nativa. Aí ele vai me pedir aqui alguns alguns dados para eu fazer essa
conexão, tá? Mas o Google Sheets ele funciona para 99% das pessoas. ele
vai te entregar aquilo que você precisa. E aí, por último e não menos
importante, Pedro, para quais públicos que eu devo anunciar quando eu
for fazer os meus anúncios? Então, aí aqui é o básico do básico, tá? O
que que é o básico do básico? Públicos quentes. Então, pessoas que
preencheram, mas não enviaram o formulário, pessoas que abriram o
formulário, mas não preencheram, tá? Esses públicos são super fáceis de
criar lá na aba públicos, tá? Eu vou deixar na descrição desse vídeo
também, vou pedir pro meu time deixar duas aulas, a de como criar as
campanhas e a aula dos públicos. Aqui na aba públicos, você vai vir aqui
em criar público, pera aí que tá carregando. Você vai em criar público,
público personalizado, criar público, público personalizado. E aqui você
tem a formulário de lead, tá? Então tá aqui, ó, formulário de lead. Vou
apertar aqui em avançar. Aqui você pode criar pessoas que abriram,
abriram, mas não enviaram e abriram e enviaram o formulário, tá? Então
você consegue criar esse público aqui de até 90 dias. Aí você anuncia
para quem preencheu, mas não enviou. Então abriu, mas não enviou. só
abriu, mas não preencheu. Pessoas que se envolveram com seu perfil,
pessoas que se cadastrou em outros formulários ou páginas que você tem,
pessoas que já visitaram seu site, listas de e-mail e de telefone.
Então, os públicos quentes, pessoas que já tiveram contato com você e os
públicos frios, Lucalike, pessoas, é, pessoas que estão no tem
interesses naquilo que você vende, público aberto, Advent Plus,
Geolocalizado, os públicos básicos, a gente ensina a criação de todos
eles lá na nossa aula sobre públicos. Lá lá você tem todo esse passo a
passo bonitinho para você, tá bom? Povo temos um sorteio para fazer.
Temos um sorteio, time. Deixa eu pegar aqui. Deixa eu ver se o time me
mandou. Não, não me mandaram. Então não tem sorteio. Não. Será que Ah,
já tem, já tem, já tem, já tem. Eu errei, eu errei. Tá aqui comigo, tá?
Temos um sorteio para fazer. É o seguinte, palavra-chave da aula de hoje
é a palavra-chave pai, que, pô, essa aula aqui foi, eu eu fui um pai de
entregar essa, essa esse isso daqui para vocês. Tá assim, tá absurdo.
Poderia ser papito porque eu tô na Espanha, mas vai ser pai agora. Já
mandei pro time. Pedro, para que que serve essa palavra-chave? É o
seguinte, você está agora aqui neste vídeo, pleno feriado, você tá aqui
comigo neste vídeo, tá? Você tá aqui nessa live, você vai clicar aqui,
ó, na lista de presença da live, tá? Então você vai clicar aqui lista de
presença. E aqui você vai colocar o seu nome, o e-mail, seu WhatsApp e
você vai escolher a palavra-chave da aula. Pedro, eu vou est virando seu
lead. Você [aplausos] aprendeu, você aprendeu. Você vai virar meu lead.
E aí você vai escolher a palavra-chave da aula, que é pai. Já tá aqui a
palavra-chave da aula, tá? Vai selecionar e vai enviar. Pedro, por que
que eu vou fazer isso? Por que que eu vou virar seu lead? Pelo seguinte,
nós fazemos mais ou menos uma vez por mês um sorteio aqui e quanto mais
aulas você vê, melhores são os prêmios que você ganha. Só que eu estou
em débito e eu não gosto dever pra gente pobre. [risadas] Eu não gosto
de dever. Eu tô devendo alguns sorteios. Então, hoje eu vou fazer três
sorteios. Eram três sorteios. Eu já estou com a lista aqui para fazer os
sorteios. Deixa eu pegar minha lista. Estou com a minha lista de
participantes aqui. E lembrando que não basta a pessoa estar ao vivo,
né? Ela tem que, aliás, não basta estar na lista, ela tem que me, ela
tem 24 horas para mandar uma mensagem pra gente para confirmar que ela
viu essa live aqui, tá? Então eu vou pegar o sorteador.com.br, que é um
site que não é meu, eu não tenho nada a ver com esse site, tá? Então
esse site é horroroso, mas que eu amo muito porque eles deixam fazer os
meus sorteios, tá? E eu vou sortear três números, tá? Opa! Vou sortear
três números entre 1 e 1284, que é o número de pessoas elegíveis, tá?
Vou colocar para Ah, nem vou colocar nada, só vou colocar para botar uma
contagem regressiva para ficar mais emocionante e sortear agora. 5 4 3 2
1 sorteador.com.br. E os números sorteados foram 2277. Vamos lá. 22 77.
22 77. Buscar número 22 77. Toma Daniel. Pô, tem um monte de gente que
preenche só Daniel. Qual que é o seu nome, Daniel? São vários. Vários.
Daniel. Só isso. Daniel, cara. Olha só. Quase que pega um outro Daniel
que tem 108 lives. O cara tem que ser o outro Daniel. Tá aí, Daniel, que
tem 108 lives. Olha só, essa pessoa bugou. Ah, é que ele já contou a a
de hoje. Daniel Aquiles, o maluco é que ele ele já ele já preencheu a de
hoje, por isso que tá aqui 139. O cara tem todas as lives. Eu nunca
tinha visto ninguém com todas as lives. Eu [limpando a garganta] tô
incrédulo, tá? Mas quem ganhou foi o Daniel. Sete de 138 lives. Sete de
138 lives. Daniel, você ganhou. Cadê a lista dos prêmios? Deixa eu achar
aqui de novo. Não é isso aqui. Não é isso aqui. Não é isso aqui. Não é
isso aqui. É isso daqui. Você ganhou uma caneca. [aplausos] [risadas]
Ganhou uma caneca. O que eu mais fácil aqui é dar caneca pras pessoas. É
só vocês verem as lives que vai dar bom, tá? Vamos lá. 9969. Vamos lá.
9969. Gol! E agora o ganhador foi Renan também da tribo das pessoas que
bota só o primeiro nome. Só tá dando o primeiro nome hoje. Seis lives de
138. Ganhou o quê? Uma caneca. Quer dizer, talvez tenha ganhado. Vamos
para o próximo. O próximo é o 5453. 54 53. Juliana Santos de Moura. E
aí, detalhe, olha bem o seu e-mail lá que apareceu, tá? Ele aparece o
início, final do seu e-mail. Cinco lives de 138. Ganhou o quê? Uma
caneca. Três canecas. Vou mandar, vou fazer mais um. Vou fazer mais um,
tá? Vou fazer mais um. Ó, esses daqui são os números. Ah, vocês tem a
gravação da live, né? Então não tem como perder. Vou sortear mais um sem
perder o sem repetir o resultado. Vai ser o último. Tô torcendo para
você, Daniel, que viu todas as lives. 5 4 3 2 1com.br. Que que acontece?
Calma que eu botei o número incorreto no segundo. Time falou, eu botei o
número incorreto. Tá bom. Qual que Ah, é 9669. Eu botei o quê? E eu
botei o quê? Calma, tô tô esperando os universitários aqui. Ah, 9669.
Vamos fazer mais um, tá? Então, vou aquela pessoa que eu sorteei ganhou,
tá? Aquela lá que eu sorteei ganhou. Nós vamos fazer mais um. Nós vamos
fazer mais um. Calma. 9669. Temos que pegar lá na lista, tá? E a gente
sorteou esse daqui também. 9669. Meu time vai me matar. Vou fazer um
monte de sorteio. 9669. Vamos ao ganhador do 9669 agora. O número
correto. Rafael 11 lives. Ó, já não é caneca. Esse aqui já quase ganhou
o moletom. Camiseta do subido ou caneca do subido. Você pode escolher,
tá? E aí vamos ao nosso último guerreiro. Desculpa, Rafael, você quase
foi penalizado, tá? O e-mail que começa com R termina com três. E aí é G
GM asterisco, asterisco alguma coisa. Não sabemos qual e-mail é esse,
tá? Mas é um e-mail G alguma coisa. E aí temos o último sorteado que é o
83 61. Pô, eu fiz, vou fazer cinco sorteios hoje, tá? 8361. Vamos nessa.
8361. Let's go. 8361. Mateus da Silva Costa, que começa com ma, termina
com K. E o e-mail é ró alguma coisa que também não sabemos o que que é.
16 lives já tá, já tá melhor. Ó, 16 lives ele já pode escolher entre
caneca, camiseta do subido, moletom do subido e o LED do subido. A gente
tem um LED escrito subido bem legal e um LED do cocozinho, que é o LED
do Baby Bosta também. Você pode escolher. O LED de subida é maneiro, mas
eu pegaria o moletom, porque esse moletom é muito maneiro, ele é muito
bom, até ele tá aqui porque ele tá, ele é mais barato do que isso, tá?
Os prêmios eles estão em ordem de preço, tá? E a gente, detalhe, a gente
já sorteou mais de um computador aqui, tá? Então assim, os sorteios eles
funcionam aqui. Eu me sinto quase que o IUD do Bom Dia e Companhia
fazendo sorteios aqui para vocês. Beleza? Cinco sorteios realizados, meu
povo. Desce, desça, desça o dedo no like desse vídeo. Agora eu vou nessa
que são 9 horas da noite. Minha esposa deve estar morrendo de fome,
querendo me matar, já que eu tô demorando aqui nessa live, porque, pô,
tô em Barcelona, né? Vou sair para jantar agora porque a live está
entregue, meus queridos subidos, minhas queridas subidas. E ó, detalhe,
para quem ganhou, eu esqueci de falar, para quem ganhou, você não tá
garantido, tá? Você tem que enviar uma mensagem no Instagram. Fala
Subido, tá? Esse Instagram aqui, ó, Fala Subido, que é o nosso suporte
oficial. Então, vai lá no Fala Subido, manda uma mensagem pra gente.
Você tem 24 horas para mandar uma mensagem para garantir o seu prêmio.
Se você mandar depois, perdeu o Playboy, muitas pessoas perdem o prêmio.
Mas se você tiver por aqui, se você tiver vendo a live, tiver vendo a
gravação, 24 horas, o prêmio é seu. Aí a gente pega suas informações de
contato para mandar para você. Fechou, minha gente? Tamos junto. Um
beijo. Foi um prazer estar aqui com vocês.

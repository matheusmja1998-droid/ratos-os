---
tipo: transcrição
live: 374
tema: Estratégias de tráfego para negócios locais em 2026
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #374

> Estratégias de tráfego para negócios locais em 2026

Resumo e aplicação: [[Live 374 — Estratégias de tráfego para negócios locais em 2026]]

---

Bem-vindos, bem-vindos à nossa live número 374, estratégias de tráfego
para negócios locais. E depois dessa live eu garanto uma coisa para
você. Você será 100% capaz de criar uma estratégia de tráfego pago para
um negócio local. Mesmo que você não tenha noção nenhuma de tráfego
pago, mesmo que você não saiba nada sobre anúncios online, mesmo que
você já saiba alguma coisa, mas agora você vai ter muito mais clareza de
qual estratégia você deve estruturar para cada tipo de negócio local.
Sim, em uma live eu garanto para você que eu vou resolver isso. Ah, mas
isso parece bom demais para ser verdade. Por isso que eu te digo,
bem-vindos, bem-vindos à nossas lives de terça-feira. Toda terça-feira,
3 horas da tarde, a gente tem uma live aqui nesse canal. Só que as lives
aqui elas seguem um modelo de conteúdo que eu chamo de conteúdo
perecível. Que que é o conteúdo perecível? Toda terça-feira, 3 horas da
tarde tem uma live. Na terça-feira da semana seguinte eu tiro aquela
live anterior do ar e faço uma nova live sobre um novo conteúdo, sobre
um novo tema. E esses temas eles não são sequenciais. Ah, Pedro, então
por qual live eu devo começar? Isso é uma coisa que quando você começa a
consumir os meus conteúdos, você vai ter que aprender a lidar. A não ser
que você compre os cursos, né? Nos cursos as aulas são sequenciais, mas
aqui nas lives você vai perceber que não tem sequencialidade nas lives.
Ou seja, a live 375 não é o complemento da live 374. Só que você passa
aqui comigo 12, 18 semanas, que nem é tanto tempo assim, aprendendo
sobre tráfego pago, isso aí é papo de três, 4 meses, você consegue
dominar todos os assuntos essenciais do tráfego pago. Além disso, você
sempre pode entrar aqui no meu canal do YouTube. Aqui a gente tem mais
ou menos 20 horas de conteúdo disponíveis em formato de lives que eu já
dei no passado, que eu chamo de lives essenciais. Essas lives elas são o
bastante para você aprender tráfego pago. Qual que é o problema? O
problema é que a maioria das pessoas quer o dinheiro, quer faturar seus
5, R$ 10.000 por mês com tráfego pago, mas não tá disposto a pagar o
preço da bunda na cadeira, não tá disposto a pagar o preço do estudo, da
execução, do aprendizado, mas a gente oferece para aqueles que estão
comprometidos, a gente oferece tudo que é necessário para que você ganhe
dinheiro com os anúncios online. Seja você alguém que, pô, quero prestar
serviço para outras empresas, Pedro, eu tô procurando uma nova forma de
ganhar dinheiro com digital. Eu tô procurando uma renda extra, quero
fazer uma transição de carreira pro marketing digital, pro tráfego pago.
O canal é para você, mas ele também serve para você que é dono de
negócio. Ô, eu sou dono de negócio, Pedro, eu quero usar os anúncios pro
meu próprio negócio. Vai servir 100% para você também, porque o tempo
que demora para você gerenciar o tráfego, os anúncios online de um
negócio, ele é muito pequeno. Por isso que gestores de tráfego conseguem
atender múltiplos negócios. E você que é dono de negócio, você consegue
dar conta de cuidar dos seus próprios anúncios. e ainda ter que fazer
todo o resto. Claro, às vezes todo o resto é muito grande e aí você vai
acabar delegando esse trabalho para um gestor de tráfego pago. Pois bem,
hoje falaremos aqui sobre as estratégias de tráfego pago para negócios
locais. E essa daqui vai ser uma das lives que eu vou fazer uma das
entregas que eu sempre falo, né, que eu tô aqui para te entregar de
graça o que muitas vezes você compra aí pela internet, mas eu garanto
para você, nenhum conteúdo da internet vai te entregar de forma tão
sistematizada as estratégias de tráfego pago como eu vou te entregar
aqui hoje. Por isso que eu falo com muita segurança de que eu tenho
certeza que você vai sair daqui sabendo implementar as estratégias de
tráfego pago para qualquer tipo de negócio. Antes de eu seguir pro
próximo passo aqui da aula, que eu quero te fazer um convite, eu preciso
só saber se meu áudio tá chegando bom para vocês, tá? Como vocês podem
perceber, não estou no meu cenário padrão aqui, tô num hotel, então tô
aqui num hotel beamara aqui em Miami. Tá muito chique, né? Tô me
achando. Mas é aquele negócio, é um pouco de droga, um pouco de salado,
um pouco de um pouco de trabalho, um pouco de férias. Hoje é minha
terça-feira. Ela é uma terça-feira full de trabalho aqui, porque a gente
tem esse nosso compromisso aqui. E aí tem gente que fala assim: "Ai, que
horror, o cara ganhou tanto dinheiro agora para ser escravo do próprio
conteúdo". Sim, eu e eu gosto disso, eu gosto da aula, eu me divirto, eu
me sinto bem aqui fazendo isso, entregando conteúdo para você. Sim, o
som tá bom, está top, está ótimo, está OK, está OK, está OK, tá
funcionando? É, né? problema. Outro dia, outro dia o cara me mandou uma
mensagem nos stories daí me criticando, falando dizer que você tá
viajando e trabalhando? Eu falei: "Pô, é melhor do que tá em casa e
trabalhando, né?" Na verdade, assim, eu gosto de, eu gosto muito da
minha rotina em casa. A gente tá fazendo essa viagem aqui, a gente tá
viajando uns 18 dias, fomos para Cancum, eh, fiz uma palestra lá, tinha
uma palestra, fiz uma palestra em espanhol, minha primeira palestra em
espanhol, foi legal. Agora a gente veio para Miami e aí daqui a dois
dias acho que a gente vai para Orlando. Aí vamos passar uns dias lá na
Disney. Passamos meu aniversário de casamento aqui em Miami e vamos
passar o aniversário da Priscila em Orlando. É cara, essa é a beleza do
digital, né? Assim, eh, tem gente que vai vender para você, é, o digital
vai trazer isso para você. É muito rápido. Não é muito rápido, mas a
questão é quando você começa a construir uma carreira no digital, esse é
o tipo de liberdade que você pode ter. Pô, eu tô num hotel aqui. Tô num
hotel super bom. Tem uma salinha aqui no hotel. Tô trabalhando, trabal
fizemos reuniões a manhã inteira aqui, fiz, resolvi várias, vários BOS
que eu tinha para resolver. Tô entregando minha live aqui para você.
Depois tenho mais uma reunião que eu vou fazer. Então assim, eu consigo
trabalhar de onde eu quiser e aí no final do dia a gente vai pegar
provavelmente uma bicicleta que tem aqui no hotel e aí vou pedalar aqui
pela orla de Miami. Ah, não dá para dizer que foi um dia ruim na minha
vida assim. Não, não tô não tô podendo reclamar. O Pedrinho de Pedrinho
que tinha 8 anos de idade ia olhar pra vida do Pedro de hoje com 30, ia
falar assim: "Caraca, que que a gente fez? Que vida foi essa?" Eu ia
dizer para ele, a gente dominou habilidades de alto valor. Nós dominamos
habilidades que fazem com que a gente ganhe dinheiro prestando serviço
para outras empresas. E não existe nada que dá mais dinheiro na internet
do que você aprender a prestar o serviço do da gestão de tráfego pago
para outros negócios. Por quê? Porque a gestão de tráfego pago, ela é a
porta de entrada para você entregar qualquer outro serviço para os
profissionais da internet. Hoje a gente tá caminhando para um mundo em
que os profissionais eles vão ser cada vez mais generalistas e menos
especialistas. Que que eu quero dizer com isso? Parte do meu trabalho é
estudar e entender para onde que tá indo o nosso mercado, né? Sou a
primeira pessoa interessada em entender para onde vai o mercado. Então,
a gente tem toda essa questão de automações, inteligências artificiais e
tem muita coisa que é hype, tem muita coisa que é purpurina que o povo
joga em cima, mas tem muita coisa que é verdade. E um dos caminhos que
eu acredito que a gente vai é um caminho da gente ter um profissional
cada vez menos especialista em um assunto só, por exemplo, tráfego pago
e um profissional mais generalista, um profissional que domina várias
habilidades. Isso porque você consegue, por meio de ferramentas que são
que existem, que vão passar a existir, você consegue implementar vários
serviços diferentes, ter várias habilidades diferentes com muita mais
facilidade. Então imagina que a inteligência artificial ela é uma
aceleradora da sua absorção de novas habilidades. Então você consegue
ter mais habilidades para você prestar serviço para as empresas. Isso
quer dizer que na os profissionais vão morrer e que eles vão todos
sumir? Não quer dizer que as empresas vão preferir contratar os
profissionais que entregam esse essa vasta gama de serviços, essa vasta
gama de habilidades. Agora, uma coisa é verdade, os profissionais eles
sempre vão procurar, a primeira coisa que uma empresa quer resolver é
trazer mais clientes, é vender mais. E o tráfego pago vai fazer isso
para elas antes do que qualquer uma dessas outras habilidades. Por isso
que o tráfego pago ele segue sendo o centro, ele segue sendo a
habilidade core, o núcleo para você poder prestar esses outros serviços
e você ganhar dinheiro prestando todos eles. Então você vai daqui pra
frente cada vez mais potencializar o seu potencial de ganho. Você não
vai diminuir o seu potencial de ganho com a IA, você vai potencializar
ele. Mas para isso você tem que dominar as habilidades fundamentais. E
uma dessas habilidades fundamentais é justamente essa construção de
estratégia para os negócios, tá? Eu vou dividir minha tela em dois aqui.
Deixa eu só deixa eu, só me organizar aqui porque eu tô com um monitor a
menos, né? Um monitor a menos. Vai, vai dar certo. Eu tenho fé. Aí agora
vai dar certo, tá? Então eu vou hoje eu não vou ficar, eu poderia ficar
aqui no cantinho lá. Eu vou dar para vocês aqui, ó. lá ele. Eu vou falar
para vocês aqui as opções que eu tenho. Eu posso ficar aqui no canto ou
eu posso ficar aqui eh ao lado, tá? Deixa eu ver como é que fica ao
lado. Ao lado fica assim, ó. Que que vocês preferem? No canto ou ou de
ladinho? Suas mentes sujas. Eu sei o que que vocês estão pensando. Ao
lado, ao lado, pô. ao lado. Foi unânime. Vamos ao lado. [risadas] Vamos
ao lado. Vamos ao lado que vai dar para ver melhor, tá? Vamos de
ladinho. Eh, vamos embora. Desculpa, tá? Desculpa, desculpa. Eu me
passei, eu me passei. Eu eu perdi a linha. Eu perdi a linha. Vamos lá,
minha gente. Eh, a gente vai falar aqui sobre as estratégias de tráfego
pago para negócios locais. Um dos fatores, uma das coisas que mais vai
fazer você ganhar dinheiro como gestor de tráfego, principalmente no
início da sua jornada, é você aprender a atender negócios locais. Qual
que é a lógica? Tem 20 milhões de CNPJ no Brasil. Todo ano tr novos
milhões de CNPJ abrem no Brasil. Todas as empresas precisam de tráfego,
precisam de clientes entrando na loja. Tráfego é isso, é movimento, é
fluxo de pessoas. O nosso trabalho como gestores de tráfego ou seu
futuro trabalho como gestores de tráfego é gerenciar esse fluxo de
pessoas na internet. Então as pessoas, desculpa, então as pessoas estão
no aplicativo, elas estão no YouTube, elas estão no celular e a gente
tem que direcionar essas pessoas para o local certo, pro WhatsApp da
empresa, pra loja do da empresa. A gente tem que direcionar essa essa
pessoa pra página da empresa para ela fazer um cadastro. Isso é gestão
de tráfego na explicação mais simples possível. Tá me entendido? Beleza?
Então, eu vou aprender as estratégias de tráfego para negócio local.
Qual que é o problema? O problema é que a maior parte das pessoas
aprendem tráfego pago, vem aqui, gostam do conteúdo, você vai ver que o
que eu vou te entregar aqui é altíssimo nível mesmo. Você vem, aprende,
assiste as lives e tal, mas você tá travado, você tá zerado, você tá
aquela pessoa que já tá entendendo mais de tráfego pago, mas não tem
cliente. Quem aí se identifica com isso, por favor, mande um eu no chat.
Pô, eu até entendo um pouco. Ou é aquela história, eu sei o que eu tenho
que fazer, mas eu não faço? Eu ainda tô inseguro se tá o meu momento
certo para começar, se não é o meu momento certo para começar. Eu acho
que eu ainda não tô preparada. Eu acho que eu ainda tenho que adquirir
mais alguns conhecimentos para que eu possa começar a colocar a mão na
massa. Pô, geral, né? Você você tá olhando o chat? Você tá vendo que
geral se sente assim? Isso daí não é porque você é especial, não é
porque você é diferente, não é porque você é o alecrm dourado do campo,
a última bolachinha do pacote, o do sei lá, um todinho gelado. Não, não
é a todo mundo que começa no tráfego pago passa por esse momento, passa
por essa essa sensação. Agora, existem algumas maneiras de você vencer
essa sensação. Ponto importante, o que que não é uma maneira de você
vencer essa sensação? É você estudar mais, não é? Ah, então essa aula
não vai resolver esse problema na minha vida. Não vai, nem essa aula e
nem nenhuma outra aula. Agora, o que que é algo que eu sei que resolve
esse seu problema? Execução guiada. O que que é execução guiada? Imagina
que eu chego, sei lá, vou pegar alguém aqui do chat, eh, Breno Benner,
Breno Benner, peguei aqui aleatoriamente. Beleza, Breno. Vou vou vou
usar o seu nome aqui de exemplo, mas pensa que eu tô falando com você,
tá? Então, agora eu vou falar com Breno aqui, mas tô falando com você
que tá aqui me assistindo. Eu chego para você e falo assim, ó: "O
seguinte, vamos resolver esse problema, você e eu, eu, eu e você. Eu vou
fazer o seguinte, toda semana eu vou te eu vou te dizer o que que você
tem que fazer. Você vai ter meu WhatsApp e eu vou te falar: "Olha, pô,
hoje você vai executar isso, amanhã você vai executar isso, amanhã você
vai executar isso." Fechou? Breno? Você consegue me entregar tudo isso
aqui que eu falei para você executar até o final da semana? Aí você vai
falar assim: "Pô, mas e se eu ficar com dúvida, Sobral?" Aí eu vou falar
assim: "Não tem problema. Se você ficar com dúvida, me chama que eu te
ajudo." Pô, Breno, a segurança não veio. Você você não começou a sentir
agora assim? Tá, se eu tiver isso daí, eu consigo. Se eu tiver isso daí,
eu consigo. Pô, dá certo. Execução guiada. Eu tô te guiando durante a
execução. Problema, eu não consigo fazer isso com todo mundo que tá
aqui, né? sei lá, tem 1600 pessoas ao vivo agora aqui nessa live, mais a
galera que tá assistindo a gravação, não consigo fazer isso com todo
mundo, mas eu criei uma uma maneira de conseguir fazer isso com todo
mundo. E esse é um teste, é algo que a gente nunca fez antes. Eu vou
fazer um negócio que vai se chamar desafio de 90 dias. Eu tava aqui em
Miami com a Priscila. Outro dia até publiquei isso nos meus stories que
eu tive essa ideia, né? Eu vou correr uma maratona no final do ano. E
para correr a maratona, eu só tô seguindo o método, seguindo o método,
seguindo o processo, aproveitando a jornada. São as três coisas que eu
tô fazendo. Eu tenho um bom método, eu tô seguindo o processo com esse
método e eu vou aproveitando a jornada e eu vou correr a maratona no
final do ano. Nunca corri nada, nunca corri 5 km, 10 km, 21, 42. Eu tô
só seguindo isso. Se você tem um bom método, sabe seguir o processo e
aproveita a jornada, é impossível você não ter resultado. O que falta
para você ter resultado como gestor de tráfego não é mais uma aula, não
é mais um curso, não é mais um conhecimento. Claro que uma aula, um
curso, uma mentoria, eu vendo essas coisas, eu quero vender essas coisas
para você. Mas a questão é um curso, uma mentoria, um mais um conteúdo
te ajuda a acelerar sua jornada. O problema é se você quer acelerar algo
que não existe, qualquer coisa multiplicada por zero é zero. Então o que
eu tô te oferecendo aqui é um desafio de 90 dias. São 90 dias um uma
comunidade que a gente vai criar só para participar desse desafio. Vão
ser 90 dias em que cada semana você vai saber exatamente o que fazer.
Você vai ter a quem recorrer se der problema. Pedro, me interessei. Como
é que eu faço para participar disso? Não é um curso, não é uma mentoria,
é um movimento que a gente tá gerando. Ah, mas e se eu precisar de
conteúdo, como é que vai ser? Como é que vai funcionar? Quando começa?
Calma, respira fundo. Eu vou te explicar tudo isso. Eu e a Pri, que é
minha esposa, que a Pri é o meu grande segredo, né? Tem gente que fala
assim: "Ah, o Pedro, pô, o Pedro é muito bom." Aí conhece a Priscila. Aí
fala assim: "Caraca, a Priscila manda muito bem". Ah, o Pedro, o Pedro é
o marido da Priscila, né? Então assim, eu e a Pri, que é a CEO, a
gestora da minha empresa, a gente vai juntos estruturar esse desafio com
você e a gente vai fazer uma live, uma live onde a gente vai explicar
tudo sobre esse desafio, como que vai funcionar, como que você vai
participar, como que você vai fazer para se cadastrar nessa live. Aqui
na descrição desse vídeo tem um link, clica nesse link, você já sabe
como é que funciona, e-mail, informações, coloca lá dois minutinhos, um
minuto, nem isso, você tá cadastrado, tá? se cadastra e coloca no seu
despertador. Essa live ela vai acontecer lá no dia 16 de março, tá?
Então, sem ser na próxima segunda-feira, na outra segunda-feira, às 8
horas da noite. Então já separa aí, coloca o despertador, ajusta sua
agenda aí para sem ser na próxima segunda-feira, dia 9, na segunda-feira
do dia 16, a gente faz essa live, explico para você como é que funciona
esse desafio e eu vou destravar você desse lugar que você tá de putz, eu
sei o que eu tenho que fazer, mas eu não faço, eu tenho a informação, eu
tô me preparando, eu tô inseguro, eu não me sinto pronta, eu tenho medo
de não gerar resultado pro meu cliente. Tudo isso daí a gente vai
resolver lá e eu vou te tirar do zero até os 5.000 por mês nesses 90
dias, do zero até o 5.000. Isso daqui não é uma promessa que não é
factível. Eu tenho certeza que se você executar tudo que a gente vai
entregar no desafio, você chega no 5.000. E é 5.000 recorrente todos os
meses. Independente se você tem experiência, não tem, tem um trabalho
paralelo, não tem, tanto faz. 90 dias a gente vai te tirar do zero e te
levar até os 5.000. É uma promessa real para pessoas reais que estão
dispostas a fazer um bom trabalho. Se você tá disposto a fazer um bom
trabalho, vem com a gente. Não tô disposto a trabalhar. Não quero. Quero
um caminho mais fácil, um caminho mais rápido. Tudo bem, daqui a 90 dias
me conta o resultado que você vai estar e eu comparo o seu resultado com
quem participou do desafio. E eu não tenho dúvida que quem participou do
desafio vai est faturando muito mais. Pois bem, vamos ao conteúdo.
Desculpem essa introdução vasta aqui, mas é uma introdução com conteúdo,
né? Afinal de contas, a gente tá falando daquilo que vai gerar resultado
de verdade para você, que não é só o conteúdo da aula. Claro que o
conteúdo da aula importa, mas a gente eh tem que entender o que que faz
com que o gestor de tráfego tenha ou não tenha resultado. Pois bem, hoje
vamos falar aqui sobre estratégias de tráfego pago para negócios locais.
Vou até dar um zoomzinho a mais aqui para você. Primeiro ponto que a
gente precisa para fazer estratégias de tráfego para negócios locais é
entender o que que é uma estratégia de tráfego pago, tá? E aí isso daqui
eu sei que parece óbvio, parece simples. Nossa, ele vai começar por essa
parte conceitual, tudo bem. Me diz então o que que é uma estratégia.
Fala para mim então o que que é uma estratégia. Você tem que, a gente
tem que conseguir explicar os conceitos de forma simples para que a
gente domine eles de forma profunda. Estratégia nada mais é do que a
variação de verbas. Então são três pontos: verbas, objetivos e fontes de
tráfego para alcançar os resultados desejados dos clientes. E aí isso
daqui pode ser o seu próprio resultado, caso você esteja fazendo
anúncios. pro seu próprio negócio. Beleza? Verba, quanto que a gente vai
gastar em cada tipo de campanha? E aí isso daqui vai depender 100% do
tipo de cliente que você vai pegar e o quanto que ele pode investir. E
aí eu sempre digo que você não controla a verba, a conta bancária do
cliente, mas você controla o tipo de cliente que você vai atrás. Então
eu posso escolher pegar clientes maiores, clientes menores. Eu tenho o
controle sobre o tipo de cliente que eu vou buscar. E aí o próprio
cliente vai me dizer: "Olha, eu tenho disponível para investir por mês
X. Eu tenho disponível para investir por mês Y. O cliente vai te dar
essa esse valor. Pedro, quanto que você recomenda? O cliente tá me
pedindo a recomendação. Olha, eu iria ali em pelo menos pelo menos 1000
12200 por mês. Ah, o cliente tem menos do que isso para investir, está
abaixo da recomendação, é o fim do mundo. Não, tá tudo bem. ele tem
menos para investir. Ele é um cliente que vai investir menos, vai ter
menos resultado. Mas aí espero que com as estratégias que eu vou te
passar aqui hoje, você consiga gerar resultado para ele e ele acabe
ganhando muito dinheiro e investindo mais em tráfego pago e colocando
mais dinheiro no seu bolso. Depois temos o fator fontes de tráfego. Eu
tirei eles da ordem aqui por motivos didáticos, tá? Então, primeira
variação que nós temos para definir uma estratégia é a verba. Segunda,
são as fontes de tráfego. Que que são as fontes de tráfego? É onde que
eu vou anunciar. E aqui são duas opções. Ou eu vou pro Google ou eu vou
pra meta, tá? Então, ou eu vou anunciar no Google. O que que é o Google?
É uma ferramenta de intenção. Como assim uma ferramenta de intenção,
Pedro? Você não vai no Google e você vai lá no Google, sei lá, ah, vou
fazer uma pesquisa aqui no Google porque eu quero me distrair um pouco.
Não, você só vai no Google quando você tá buscando algo. Ah, eu tô
buscando, sei lá, estourou o cano do meu banheiro aqui, tá chovendo
merda na minha casa, tá um cheiro horrível. Vou no Google e pesquiso
encanador em cidade tal. Então eu tenho uma intenção, eu estou buscando
ativamente aquele negócio. Agora tem negócios que funcionam mais com a
meta. A meta é uma ferramenta de atenção. Então eu preciso chamar a
atenção das pessoas para que elas parem e vejam o meu anúncio. Vou dar
um exemplo. Você pode ter um negócio de um dentista. Um dentista ele é
um negócio híbrido. Ele tem tanto intenção quanto atenção. Intenção no
dentista. Tô com dor de dente. Acabei de Tô com problema no dente. Tá
doendo muito. Vou procurar dentista na minha cidade. Atenção, eu
dentista estou vendendo eh um botox. Tem tem dentista que bota botox,
né? Aí eu posso fazer um anúncio do botox. Eu dentista tô vendendo
preenchimento labial. Eu dentista tô vendendo clareamento dental. Não é
algo que às vezes a pessoa pode pesquisar, é claro, mas é mais fácil de
eu atrair essa pessoa chamando a atenção dela. E eu coloco aqui que o o
meta é uma ferramenta de atenção e de relação. Por quê? Porque na meta,
principalmente, eu consigo me relacionar com as pessoas. As pessoas
conseguem seguir a minha marca, consumir os meus conteúdos, entender
quem que eu sou, quais são os valores, os princípios por trás da minha
marca. E por último, e não menos importante, objetivos. E os objetivos
eles se dividem em mais camadas, tá? Então aqui é quais objetivos de
campanha a gente vai utilizar, que criativos vão ser utilizados,
criativo nada mais é do que o anúncio. E quais vão ser os destinos das
campanhas? Pedro, socorro. Essa aula não é para mim. Eu não tô
entendendo nada. Você já falou objetivo, criativo, destino de campanha,
verba, um monte de palavra que eu nunca vi na vida. Esse é o meu
primeiro contato com tráfego pago. Respira fundo. A confusão é o
primeiro passo do entendimento. Esse daqui é o mantra. Tá, tá gerando
confusão. Tão aparecendo termos que você não conhece, que você nunca viu
na vida. Tá tudo tá tudo normal. Quem chegou aqui há três, quatro
semanas atrás para começar a assistir as lives, tá aqui hoje, já fala
assim: "Hum, eu já entendi o que que é isso. Eu já sei o que que é
isso". Esse conceito que o Pedro fala, falava antes que não fazia
sentido. Agora eu já tô começando a entender. Fica tranquilo. Você tem
que sair dessa aula sabendo mais do que você chegou aqui. É só isso que
você tem que focar. E o que que você tem que focar em entender agora?
Você tem que focar em entender o seguinte. Uma estratégia é eu fazer
alterações, mudanças, variações do dinheiro que o meu cliente investe,
dos diferentes objetivos que ele tem e de onde que eu vou anunciar. é
isso, do dinheiro que ele investe, ou seja, da verba, de onde que ele
vai anunciar, ou seja, no Google ou na meta e dos objetivos de que o meu
cliente tem. Como que eu vou fazer essas definições? Nós vamos responder
a cinco perguntas. Cinco perguntas para definir uma estratégia inicial
de tráfego pago. Primeiro, qual que é o tipo de negócio? É um dentista?
É um coworking? Não, ele é uma loja física de roupas? Não, ele é um
médico, ele é um contador, ele é um advogado, ele é uma imobiliária, ele
é um salão de cabelo, ele é uma barbearia, ele é uma academia, ele é um
pet shop. Qual que é o tipo de negócio? Primeira coisa. Número dois,
como que os clientes chegam até esse negócio hoje? E aí a gente tem
algumas opções. Eles podem buscar pelo Google, eles podem descobrir esse
negócio nas redes sociais ou eles podem ter uma descoberta híbrida, né?
Os dois. Vou colocar alguns exemplos de negócio aqui. Então, busca
ativa, encanador, eletricista, detetizadora, dentista, ortodontista,
advogado, contador, chaveiro, vidraceiro, serralheiro. a pessoa vai
ativamente buscar aquela especialidade de desejo ou descoberta, que é as
pessoas que descobrem nas redes, restaurante, hamburgueria, pizzaria,
loja de roupa, barbearia, estúdio de tatuagem, floricultura,
confeitaria, loja de decoração e os dois híbrido, clínica de estética,
academia, pet shop, imobiliária. Pedro, eu tenho que decorar isso? Claro
que não. Esquece isso daqui. Que que você tem que entender? que quando
você vai conversar com o seu possível cliente, ele vai te dar essas
informações ou vai ficar óbvio para você só de ver o tipo de negócio,
como que os clientes chegam até esse negócio hoje. Depois você vai
responder: "Qual que é o investimento mensal em tráfego pago?" Aqui são
três faixas até 1500, de 1500 a 5.000, acima de 5.000. Depois, qual que
é o ticket médio do produto ou do serviço principal? Que que isso quer
dizer? em média, quanto de dinheiro alguém deixa nesse negócio quando
vai fazer uma compra? Isso é o ticket médio. E por último e não menos
importante, quem atende os leades que chegam até esse negócio? O dono do
negócio atende sozinho, tem uma recepcionista ou uma secretária? Ou
então tem uma equipe comercial? Você vai responder essas perguntas e
essas perguntas vão gerar para você a estratégia de tráfego pago. Pedro,
como assim elas vão gerar para mim estratégia de tráfego pago? É o
seguinte, até o final dessa aula, eu não vou colocar o link disso daqui
na descrição, mas até o final dessa aula eu vou liberar para você essa
ferramenta que eu criei aqui para você, tá, para essa aula de hoje, que
é o diagnóstico de tráfego local. Que que você vai fazer? Você vai
começar o diagnóstico e você vai responder essas perguntas. Então, qual
que é o tipo de negócio? Ah, é um dentista. Aí vou colocar aqui
dentista. Como que os clientes chegam até esse negócio? Hoje já eles
buscam pelo Google, eles descobrem nas redes, não os dois caminhos.
Quanto que ele investe? Ah, ele investe até 1500 por mês. Qual que é o
ticket médio do produto principal? Ah, é até 500. Quem atende os leaders
que chegam? Ah, tem uma recepcionista e secretária. Respondeu que que o
sistema vai fazer? Ele vai gerar estratégia para mim. Então ele gerou
uma estratégia meio a meio aqui. 50 Google, 50 meta, duas campanhas,
100% focado em conversão, 0% focado em aquecimento. Então ele vai me
trazer aqui algumas informações e aí ele vai me trazer o tipo de
campanha, ó. Você vai fazer uma campanha Smart do Google Meu Negócio e
você vai fazer uma campanha no WhatsApp estilo war, tá? E aí eu já vou
falar para você o que que são esses tipos de campanhas aqui, tá? Então,
se eu tenho o botão aqui de ver a matriz completa, aqui eu consigo ver
onde que a minha estratégia tá inserida, tá? Eu tenho todas as outras
estratégias aqui. Pedro, da onde que vieram essas estratégias? Você
tirou essas estratégias do sovaco? Não. Eu fui na minha comunidade de
alunos, eu pesquisei sobre as estratégias que eles mais divulgam, fui no
meu grupo de eh gestores de tráfego que faturam ali acima de R$ 1
milhãoais por ano. Fui nas informações de pessoas que estão no campo de
batalha. Fui na minha agência de tráfego pago e eu entendi que tipo de
estratégia que a gente tá utilizando para cada tipo de negócio. Reuni
todas essas informações, identifiquei os padrões e entreguei aqui para
você. Eu publiquei nos meus stories que eu ia mostrar esse sistema na
live de hoje, né, que eu ia te entregar isso daqui e uma pessoa comentou
assim: "Ah, muito legal, meu sobrinho de 5 anos também sabe fazer isso
com IA". Aí eu falei assim: "Pô, mas ele sabe montar uma matriz, uma
matriz de estratégias de tráfego pago validadas por centenas de gestores
de tráfego pago?" Pô, se ele sabe fazer isso, por favor, me passa o
contato dele que eu quero contratar. O a mágica aqui da coisa não é a
ferramenta ter sido feita num numa IA ou não ter sido feita com uma Yá.
A mágica da coisa aqui é você ter o a informação, né? O que que tá
inserido ali dentro do negócio, tá? Então eu vou até o final da aula, eu
te explico como é que você vai ter acesso a essa ferramenta e aí você
vai conseguir ali ver a estratégia específica para cada tipo de negócio
que você quer fazer. Por isso que eu garanti para você que até o final
da aula você saberia criar uma estratégia de tráfego para negócio local.
Não importa o tipo de negócio, não importa o tipo de negócio local para
o qual você tá fazendo, tá? Seguindo em frente aqui, eh, terceiro ponto
que você tem que definir, então, respondi essas cinco perguntas. Opa.
respondi essas cinco perguntas aqui, você vai respondê-las até dentro do
próprio sistema. Aí eu vou pro número três, que é entender quais
campanhas que você deve saber rodar como gestor de tráfego para negócio
local, tá? E aqui a gente vai ter alguns tipos de campanhas que você vai
ter que dominar, tá? Quando a gente tá falando de meta, você tem que
saber fazer quatro tipos de campanha. campanha de impulsionar, campanha
de WhatsApp, que vai ser a campanha que eu vou te ensinar a fazer na
live da semana que vem, formulário nativo, engajamento vídeo ao alcance.
Vou abrir um parênteses aqui com você. Eu sei que tem gente no chat que
tá assim: "Cara, ele tá falando grego, nada do que ele tá falando tá
fazendo sentido para mim." E isso tá acontecendo por quê? Porque você
não tem o conhecimento prévio de tráfego pago. Agora, o que que você vai
fazer para resolver isso? Primeiro, você vai assistir essa aula aqui até
o fim. Tem informações que você só vai receber nessa aula aqui e essa
aula sai do ar e depois você não vai conseguir ter acesso a essas
informações. Mas se você entrar aqui no meu canal do YouTube, você vai
ver que aqui no meu canal do YouTube tem a lista de todas as aulas aqui
que estão que que que eu já dei, que aliás não todas as aulas que eu já
dei, algumas aulas que eu já dei. E aqui tem algumas aulas que eu vou
recomendar que você assista, tá? Quais vão ser elas? e elas vão estar na
descrição. Eu vou recomendar que você assista a live número 363, que é
uma live onde eu falo sobre como que você vai criar campanhas no
Metaedits, tá? Aqui você vai aprender a criar alguns desses tipos de
campanhas que estão aqui dentro. E na semana que vem, e aí peço o seu
comprometimento para estar aqui na semana que vem a gente vai fazer uma
aula só sobre campanha de criação de eh campanhas para WhatsApp, que é a
campanha que você mais vai utilizar com negócios locais. Eu vou explicar
tudo dessa campanha para você na semana que vem. É uma aula extremamente
técnica, diferente dessa aula de hoje, que não é uma aula tão técnica.
Eu não tô abrindo a ferramenta, eu não tô vindo aqui, ó, no gerenciador
de anúncios e tô criando as campanhas na sua frente e te mostrando como
é que você vai subir os seus anúncios e selecionar os objetivos. Não,
isso daqui a gente deixa pra aula da semana que vem, onde a gente vai
falar um pouquinho mais do tecniquês aqui do tráfego pago, tá? Mas eu
vou deixar na descrição essa aula aqui que é a 363 e vou deixar na
descrição também a 365, tá? Que é a aula sobre como anunciar no Google
Ads. Porque além de saber fazer essas campanhas do Meta, você também tem
que saber fazer essas campanhas do Google aqui, tá? Então você tem que
saber fazer a campanha no meta do botão turbinar. Desculpa, tava na tela
errada. Você tem que saber fazer a campanha do meta de botão turbinar,
que é a mais simples de todas, é o botão turbinar. Ele é excelente para
trazer seguidores pro seu perfil. Você tem que saber fazer as de
WhatsApp, formulário nativo, engajamento, vídeo e alcance e campanhas de
Google. Você tem que saber subir uma campanha Smart, você tem que saber
fazer uma campanha de visitas ao negócio Performance Max e você tem que
saber fazer uma campanha de pesquisa. Vamos lá, parênteses aqui com
você. Qual que é o seu erro? Você, pessoa que quer ser gestor de tráfego
pago, mas tá naquele estágio, eu sei um pouco de conhecimento, eu tenho
um pouco de conhecimento, mas eu tenho medo, eu fico inseguro, eu tenho
que adquirir mais conhecimento. O seu problema é você olhar para isso
daqui e você fala assim: "Primeiro eu vou aprender todas essas coisas,
depois eu vou fechar um cliente". Tá errado. Você primeiro fecha o
cliente. Aí, dependendo da necessidade do cliente, você vai atrás dos
conhecimentos específicos. É por isso que ter acesso, por exemplo, uma
comunidade subido de tráfego, que é o meu produto, é tão poderoso. Por
quê? Porque se eu tenho um determinado problema, eu vou atrás da solução
deste problema. Eu sei onde eu vou atrás da solução desse problema para
resolver ele quando o assunto é tráfego pago. Agora o problema é quando
você não tem ao que recorrer. Então, putz, se eu tenho um cliente, eu
tenho que subir uma campanha X Y Z, mas eu não sei fazer e eu não sei
onde que eu encontro a resposta para essa para esse problema que eu
acabei de ter, tá? Então, como eu falei para você, na descrição desse
vídeo, eu vou deixar o link da live que fala sobre as campanhas de meta
e vou deixar o link da live que fala sobre as campanhas de Google, tá?
Você não vai encontrar nessas nessas lives esses dois tipos de campanha
aqui e você não vai encontrar nessa live esse tipo de campanha aqui de
formulário nativo, tá? Então não, você não vai aprender nessas lives a
fazer campanha de formulário nativo, nem essas duas aqui, tá? Mas tem
outros conteúdos, já dei esses conteúdos aqui no canal, mas tem outros
conteúdos e vão ter no futuro novamente conteúdos onde eu ensino você a
fazer eh esses tipos de campanhas aqui. Inclusive, acho que é no próximo
mês agora, a gente já vai ter uma live sobre como faturar com Google Meu
Negócio, tá? Então, vai ter uma live específica sobre isso. Acho que vai
ser no final de março, último dia de março. Isso mesmo, dia 31 de março,
a gente tem uma live onde a gente fala sobre Google Meu Negócio. Vou
falar sobre como que você fecha contratos só com Google Meu Negócio, só
vendendo Google Meu Negócio pros seus clientes. E como que você vai
transformar esses contratos em contratos maiores de tráfego pago, tá?
Mas por que que eu tô mostrando essas campanhas aqui para você? Porque
tem gente que acha que você tem que dominar tudo do tráfego pago para
ganhar dinheiro com tráfego pago. E não tem que, você tem que dominar
isso daqui. Para fazer isso daqui, você não precisa nem saber instalar
um pixel, que é uma coisa um pouquinho mais complicada. Ah, quer dizer
que eu nunca vou aprender, nunca vou precisar, não. Mas para fazer
tráfego para negócio local, se você adquirir esses conhecimentos, souber
criar essas campanhas que estão aqui na sua tela, se você fizer disso
daqui a sua missão, você sabe fazer tráfego para negócio local. E se
você for ainda mais inteligente, ainda mais rápido, você vai entender
que você não precisa aprender nenhuma delas para fechar os seus
clientes. Ah, como é que eu vou fechar os meus clientes? Vem lá comigo
na live do que a gente vai falar do desafio de 90 dias e lá você vai ter
a resposta para isso. Lembrando que o link para você se cadastrar no
desafio tá na descrição, tá? Beleza, Pedro? Entendi. Essas são as
campanhas que eu tenho que dominar, que eu vou ter que aprender. São os
conhecimentos que eu tenho que ter. Por mais que eu não saiba o que que
é G GMN. O que que é performance max? Eu entendi que tem esses
conhecimentos aqui que se eu adquirir eles eu consigo ganhar dinheiro
com esse negócio de tráfego pago. Para você que tá começando, é isso que
eu preciso que você entenda aqui. E número quatro, que tipo de destino
que eu utilizo nas minhas campanhas de conversão? A gente sempre vai
criar, quando a gente for utilizar aqui a nossa ferramenta de
diagnóstico, ele sempre vai dividir as nossas campanhas em conversão e
em aquecimento. São os dois tipos de campanha que eu tenho. Conversão é
a campanha que chuta pro gol. Aquecimento é a campanha que vai preparar
as pessoas para comprarem de mim no futuro. Vamos falar agora das
campanhas de conversão. Para onde que eu posso enviar as pessoas quando
elas clicam no meu anúncio de conversão? Eu posso enviar as pessoas para
o WhatsApp. Qual que é a vantagem? Eu vou ter mais volume de pessoas
chegando lá. Qual que é a desvantagem? Pode ter menos qualidade das
pessoas que tão chegando no WhatsApp. Segundo local que eu posso enviar
as pessoas, eu posso enviar as pessoas pro WhatsApp utilizando um
objetivo de vendas. Então, quando eu for criar o meu anúncio lá na meta,
eu vou ter que selecionar meu objetivo. Eu posso mandar as pessoas pro
WhatsApp por engajamento. Aqui eu vou ter mais volume, mas um pouco
menos de qualidade. Ou eu posso enviar as pessoas pro WhatsApp com
objetivo de vendas. Aqui eu tenho menos volume, mas a tendência, não é
uma regra, é que eu tenha mais qualidade. Qual que é a desvantagem? eu
vou ter um custo por compra, um custo por lead mais eh mais elevado no
final das contas. E aí eu vou dar duas dicas para você aqui, para quem
vai utilizar o WhatsApp pros seus clientes, tá? Eu chamei isso daqui de
dicas extras. Se você já tem cliente de tráfego pago ou se você vai
fechar um cliente de tráfego pago, você e ah, eu tenho medo de não gerar
resultado pro meu cliente. Se você implementar isso daqui para qualquer
cliente, todos eles vão ganhar dinheiro. Que que você vai fazer? Número
um, você vai pegar todos os contatos de WhatsApp que o seu cliente já
tem, todos os contatos, e você vai criar um grupo VIP no WhatsApp. E aí
você vai criar um grupo VIP no WhatsApp e você vai falar que nesse grupo
VIP vão ser compartilhadas promoções, novidades e aí ali você vai criar
essa comunidade de clientes que vai receber essas promoções e novidades.
Então você vai destacar os benefícios de participar desse grupo. Acesso
antecipado a descontos, sorteio, dica especial. E aí você pode fazer
isso de dois modos. Modo número um, você simplesmente enfia todo mundo
num grupo, não recomendo. Modo número dois, você entra em contato com
cada cliente falando: "Olha, criamos aqui o grupo VIP da barbearia
subido". Nesse grupo VIP, você vai ter acesso a descontos, sorteios,
serviços especiais que não estarão disponíveis em nenhum outro lugar. E
aí a pessoa vai querer fazer parte daquele grupo. Então você tá
basicamente criando um grupo de pessoas que querem receber ofertas. E a
dica número dois é você fazer uma campanha de reativação. Então, pega
toda a base de clientes inativos do seu novo cliente que estão há 90
dias sem comprar e faz um disparo, uma mensagem padrão para todos eles
com uma oferta específica para eles voltarem a comprar. Isso daqui
parece bobo, parece simples, é bobo e é simples, mas coloca dinheiro no
bolso do seu cliente logo na largada do negócio, tá? funciona muito bem.
Assim, 90% dos negócios que a gente faz, que a gente pega para fazer
tráfego, a gente faz essas campanhas, são campanhas de injeção de caixa
e eu não tive que gastar dinheiro nenhum. Isso, claro, quando o cliente
que eu fechei já tem uma base de clientes anterior. Continuando, além de
enviar as pessoas pro WhatsApp ou pelo pela campanha de venda ou pelo
engajamento, eu posso usar o formulário nativo. Que que que é o
formulário nativo? A pessoa clicou no meu anúncio dentro do Instagram,
dentro do Facebook, ela não vai pro meu site, vai abrir na frente dela
um formulário para ela preencher, tá? Então aqui eu tenho muito mais
qualidade e tenho a possibilidade de fazer um lead scoring. E eu sei que
isso daqui, pô, é um termo merda para quem tá começando. Se você tá
começando, só ignora isso. Não é o momento de você entender isso. Mas um
lead scoring é basicamente eu vou ter várias pessoas que se cadastraram
lá no meu formulário, botaram nome, e-mail, telefone e e alguma
informação. Vamos dizer que eu peguei todo mundo que tá aqui assistindo
essa live e eu vou, você que tá assistindo e eu vou cadastrei você num
lugar. Aí eu vou pegar seu nome, seu e-mail, seu telefone e vou fazer
três perguntas para você. Pergunta número um: qual que é a sua situação
no tráfego pago hoje? Ah, não sei nada. Essa é a primeira live que eu tô
assistindo. Ah, já assisti várias lives e tenho certeza que quero
trabalhar como gestor, mas não ganho dinheiro. Já ganho dinheiro como
gestor de tráfego pago. Essa pergunta eu tenho três tipos de pessoas que
vão responder: o zerado, quem já começou a estudar e sabe que quer ser
gestor de tráfego e o gestor de tráfego. Aí eu vou vender um produto
para essas pessoas. Vamos, vamos dizer que eu vou vender um produto e
esse produto que eu vou vender é para quem já é gestor de tráfego. A
pessoa que marcou a última opção, ela vale mais para mim do que a pessoa
que marcou as duas primeiras. Não que você que esteja zerado, você que
já decidiu ser gestor de tráfego, não tenha valor nenhum. Pode ser que
você compre o produto feito só para quem já é gestor de tráfego pago,
mas eu vou classificar as pessoas. Isso é lead scoring, é dar notas para
as pessoas que que se cadastraram com base nas respostas que elas deram.
Você nunca vai encontrar na internet uma explicação de lead scoring mais
simples do que essa. É você atribuir nota ao lead. Lead é quem? Lead é a
pessoa que se cadastrou, tá? Isso daqui é o lead. Você pode fazer
campanhas de formulário nativo. Essas campanhas, elas funcionam bem para
produtos mais caros, tá? Produtos que precisam de muitas informações do
lead. Outro tipo de destino para o qual eu posso enviar as pessoas, eu
posso enviar as pessoas para uma página, para uma página, uma landing
page, um site, onde ela vai se cadastrar nesse site. Qual que é a
vantagem da página? Pré-qualificação do lead direto na página. Ou seja,
eu consigo levar a pessoa paraa página e a pessoa já vai entender mais
sobre o que que é o produto, o que que eu tô divulgando e eu posso
incluir várias perguntas personalizadas paraa pessoa responder na página
para fazer um cadastro. Qual que é a desvantagem? Maior custo por lead
de todas as estratégias. Então vou pagar mais caro para as pessoas irem
até a página e se cadastrarem. Mas dependendo do nicho, pode ser menor
ou até igual do que o formulário nativo. Então não é necessário enviar a
pessoa para uma página, mas traz um profissionalismo, traz uma
qualidade. Na minha agência, a gente usou muito isso e usa muito página
pra petshop, clínica médica, que eu tenho que dar muita informação pra
pessoa antes dela se cadastrar, arquiteto e para uma loja de persiana,
eu usava muito empresa de evento, empresa B2B, todos esses tipos de
empresa vão usar muito esse tipo de página. E eu posso também utilizar o
próprio eh Google Ads para fazer essas captações, né? Aí o Google Ads,
eu vou acabar enviando as pessoas para um site, mas ele também tem suas
vantagens e desvantagens. A vantagem, captação de demanda específica.
Então, a pessoa pesquisou gás residência, estrutura metálica para
construção e imóveis, produtos industriais, a pessoa fez uma pesquisa
específica. Qual que é a desvantagem? É mais difícil de mostrar a
autoridade do especialista e transmitir essa autoridade do especialista
só com uma página. Às vezes pode acabar sendo complicado e até
impossível. Número cinco. Agora aqui tá bem rápido, tá povo? São poucas
informações que eu tenho para você. Que tipo de campanha que você vai
usar nas campanhas de distribuição barraquecimento? Lembrando, para que
que serve uma campanha de distribuição ou aquecimento? para aumentar o
alcance, engajar novos públicos, fortalecer o relacionamento. Se eu
pegar aqui a nossa ferramenta de diagnóstico e eu colocar um outro tipo
de um outro tipo de resposta aqui, deixa eu, deixa eu só colocar mais
informações para ele me gerar uma estratégia diferente aqui, ó. Aqui ele
já me gerou uma estratégia. 40% Google, 60% meta. 65% da minha verba
para conversão, 35% da minha verba para aquecimento, de três a quatro
campanhas, tá? E aí ele destacou aqui quais são essas quatro campanhas.
Então, uma campanha de pesquisa no Google, uma campanha de WhatsApp na
meta, uma campanha na meta de engajamento e uma campanha de remarketing
na meta, que é opcional, tá? Tem tudo explicadinho aqui no sisteminha
para você. você consegue dar uma olhada, entender o que que é tudo isso.
Agora, o que que são as campanhas de de aquecimento? São as campanhas
que vão fazer isso daqui. Quais são as possibilidades? Eu posso fazer
uma campanha de engajamento ou visualização de vídeo. Ela vai gerar
volume de interação e gera contato para social selling. Que que é social
selling? A pessoa foi lá e comentou no meu post que eu patrocinei, o meu
time entra em contato com essa pessoa. Então a pessoa comentou, eu vou
atrás dela para vender para ela. Eu não fico esperando ela vir atrás de
mim, atrás de mim. Segunda opção, turbinar publicação. Essa é o tipo de
campanha, o botão turbinar, impulsionar, é a campanha que traz um volume
de seguidores muito grande com custo pequeno. Então, vai trazer muito
seguidor pro perfil, mas pode acabar atraindo um público não tão
qualificado. Você tem que tomar cuidado no principalmente em que
conteúdo que eu vou patrocinar. Se eu patrocino um conteúdo que tá que
vai trazer o público errado, vai dar ruim. E por último, campanha de
alcance. Tá? Essa campanha de alcance ou reconhecimento de marca, como é
o nome que muita gente chama, ela é muito boa paraa marca que quer quer
para marcas que querem ampliar o reconhecimento regional. Então eu quero
aparecer muitas vezes para as mesmas pessoas num mesmo local. A lógica é
simples. As pessoas compram das marcas que elas mais vêm. Quando você vê
um outdoor da Coca-Cola, você pergunta assim: "Putz, mas eu não consigo
comprar uma Coca-Cola só de ver esse outdoor?" Mas a marca ela tá
ocupando espaço na sua cabeça e você pode fazer isso com negócios locais
de maneira menor, mais direcionada através das redes sociais, através
das campanhas de alcance. Ah, qual delas que eu vou utilizar? Aí o
sistema vai dizer para você ali, vai te dar a sugestão de qual
estratégia você deve utilizar para iniciar, que tipo de orçamento que
você vai utilizar. Mais uma vez, técniqueza um pouquinho maior aqui. Eu
sei que quem não viu nada de tráfego pago vai torcer o nariz, mas a
gente tem dois tipos de orçamento, CBO e ABO. CBO é o quê? Eu vou dizer
pra meta, pro Google. Meta ou Google, gasta o meu dinheiro da melhor
forma possível. A Bo. Eu vou dizer pro Google e paraa meta. Olha, eu vou
decidir em que público eu quero gastar. Eh, quanto, desculpa, eu vou
decidir quanto que eu quero gastar de dinheiro em cada público. Então,
CBO, eu tô deixando a meta ter controle. ABO, eu tô tendo controle. Para
quem tá começando, eu sempre indico CBO, tá? Tem gente que fica, ai CBO,
ABO, o que que é melhor? Ah, é uma [ __ ] sem tamanho. [risadas] É
verdade, porque não faz diferença nenhuma. A BO, a CBO é um detalhe
muito pequeno, tá? Mas se a gente for responder pra pessoa que é um
pouco mais técnica, eu diria que CBO, ela é ideal para campanhas com
grande escala e que tem foco em diminuir o o CPA, tá? o custo por ação,
o custo por lead, o custo por mensagem, o custo por resultado. No final
das contas, normalmente eu começo com CBO e a BO é quando eu preciso
controlar melhor os meus gastos. É basicamente isso, porque eu vou ter
mais controle. Eu escolho quanto que eu quero gastar em cada público. Eu
uso isso para testes iniciais e para validar algumas hipóteses com
segurança e eficiência. Isso daqui é para quem já tá um pouquinho mais
avançado, um pouquinho mais ligeiro. Tô começando, você vai botar CBO e
vai ser feliz na sua vida, tá? É isso. Número seis, que CBO nem chama
mais CBO, né? CBO era cana budget optimization. Can budget optimization.
E otimização de orçamento de campanha. Hoje em dia CBO nem chama mais
isso. Você vai criar a campanha aqui, o CBO ele virou o orçamento
advantage. Então aqui, ó, ele já vem ativado por natureza, ele já tá
ativado, você nem tem que mexer em mais nada. Agora o ABO é o orçamento
no conjunto de anúncio. Então CBO ABO, CBO ABO, CBO ABO. É isso. Você
não tá vendo a minha tela? Desculpa, desculpa, desculpa. Agora sim,
quando você vai, você seleciona, você vai criar a campanha, ele vai te
perguntar aqui qual que é o orçamento. Ele já tá ativado, o orçamento
advantage. Aí você vai selecionar o orçamento da campanha, é o CBO,
orçamento do conjunto, ABO, CBO, ABO, CBO, ABO. É isso, tá? Normalmente
você vai selecionar o da campanha que vai funcionar melhor. Guarda essa
informação aí que ela vai ser útil no futuro. E que tipo de segmentação
que você vai utilizar? Ponto número seis. Aqui são oito pontos nessa
aula, tá, povo? 10 minutinhos a gente termina. Para você que tá
cansando, pensando em desistir, aguenta mais 10 minutinhos aí, treina o
seu foco. Que tipo de segmentação que você vai utilizar? sempre busca
identificar se o negócio local que para o qual você tá anunciando
precisa da construção de autoridade e relacionamento antes da tomada de
decisão. Por exemplo, vou contratar, sei lá, quero mudar o meu nariz,
vou contratar, eu não quero mudar meu nariz, mas eu, vamos dizer que eu
quero fazer uma rinoplastia, vou contratar um cirurgião plástico. Tu
acha que o primeiro anúncio que aparecer de cirurgião plástico na minha
frente, eu vou clicar e vou contratar o cara? Claro que não. Eu vou
querer saber quem é os resultados que ele já gerou, quem que é essa
pessoa. O maluco vai mexer no meu nariz ou sei lá, vou vou contratar uma
tatu, vou fazer uma tatuagem. Tudo bem, tem gente que é maluco e que faz
tatuagem como se não fosse nada, mas eu vou escolher o tatuador. Eu
quero ver o trabalho da pessoa, quem que é a pessoa, que tipo de
resultado que ela gera nas tatuagens que ela faz. Então, às vezes eu
preciso construir autoridade e relacionamento antes de vender. E às
vezes eu não tenho que construir autoridade relacionamento quando eu vou
vender. Tem que que eu quero dizer com isso? Tem dois tipos de público.
Público quente, gente que já me conhece. Público frio, gente que não me
conhece. Se eu chegar agora e falar para você assim: "Ah, vou te vender
aqui um curso rápido de tráfego pago, R$ 97. Pô, tudo bem, eu posso
vender esse curso para quem não me conhece. A decisão é mais simples, R$
97. Agora vou vender para você a minha comunidade de tráfego pago.
Comunidade subido de tráfego pago. Quanto que ela custa? Vai custar mais
de R$ 2.000, pô. Mais de R$ 2.000. R$ 2397. Vai custar R$ 2397. R$ 2497.
Tá mais caro do que eu pensava. É inflação, né? 2497 custa comunidade.
Vou te vender um produto de 2.000. Você nunca me viu na vida. Você vai
clicar e vai comprar? Claro que não. Antes você tem que me conhecer,
saber dos resultados que eu já gerei, que eu tenho mais de 100.000
alunos, que as pessoas que compram meu produto e implementam, todas elas
têm resultado, que em média em 30, 45 dias você já retorna o valor do
produto se você implementar o que tá explicado lá dentro. Então você tem
que me conhecer, você tem que saber quem sou eu, ver que, pô, esse cara
ele explica um monte de coisa que eu nunca ouvi falar na vida. Eu saí
dessa aula com mais confusões do que eu cheguei. Ótimo. Esse é o
objetivo. Ser a sua primeira vez aqui. Mas ele explicou várias coisas de
maneira didática que eu entendi. Mesmo eu não sabendo exatamente do que
ele tá falando. Ele tem a capacidade de me ensinar. Legal. Aí você
começa a ganhar mais confiança. Então você tem que entender para que
tipo de negócio que você tá vendendo. Tem negócios que precisam desse
relacionamento, tem negócios que não precisam, tá? E aí eu tenho aqui
uma lista de públicos que normalmente a gente utiliza. Público quente é
a pessoa que já me conhece, então pessoas que se envolveram recentemente
com a minha marca, pessoas que interagiram comigo recentemente, eh
públicos semelhantes, pessoas que interagiram com as minhas publicações
ou anúncios nos últimos 365 dias, quem interagiu nos últimos 365 dias e
também nos últimos 30 dias, hierarquia de engajamento. E aí, pô, Pedro,
eu não tenho ideia do que que é isso. Isso aqui é para você que é um
pouquinho mais avançado. Você que não é, ignora, tá tudo certo. Anota aí
no seu caderninho, nas suas anotações, para no futuro você vai voltar
aqui, tudo isso vai fazer sentido. E públicos frios, tá? Que são pessoas
que nunca me viram na vida. Então aqui eu tenho interesses específicos,
pessoas que têm interesses óbvios e nos assuntos. Então, por exemplo, eu
vou anunciar para um petshop, eu vou botar lá cães, gatos, animais de
estimação, petlove, ração de animais. Então eu vou bem óbvio ali nos
meus interesses, né, no direcionamento detalhado. Públicos abertos em
regiões específicas ou geolocalizado. Então 1 km na volta do meu
negócio, 2 km perto do meu negócio, um raio geolocalizado. Eu vou
anunciar ali em cima. Luca like de listas de clientes ou de seguidores.
Luca like de quem visualizou os meus vídeos. Localike de quem já viu 3
segundos ou mais de um vídeo meu nos últimos 365 dias e profissões de
pessoas que tm o maior poder aquisitivo, tá? É uma lista de públicos. É,
eu levantei a lista de públicos que as pessoas que anunciam para
negócios locais mais utilizam e são esses daqui. Que que você tem que
sacar aqui? Não tem que decorar a lista de público. Você tem que
entender o seguinte, público quente, você vai utilizar eles mais quando
você for anunciar um negócio que precisa de uma autoridade, um
relacionamento prévio para vender. Público frio. Esse daqui você vai
estar sempre anunciando e sempre testando, tá? Número sete aqui na nossa
live, que tipo de posicionamento que você vai utilizar? Opa, vim aqui
pro canto errado. Agora sim. Que tipo de posicionamento que você vai
utilizar? Você pode anunciar para dois posicionamentos quando a gente tá
falando de meta, Instagram ou Advantage Plus. Instagram são públicos
mais qualificados, tá? Você vai encontrar pessoas mais qualificadas no
Instagram do que na meta, pessoas que têm mais poder aquisitivo. Então,
se você vende algo com o ticket mais caro, tá querendo atrair um público
mais qualificado, anuncia só no Instagram. Advent Plus, públicos mais
amplos e mais populares. Número oito, que tipo de anúncio que eu vou
utilizar aí? Aqui eu vou fazer uma recomendação para você. Eu vou tirar
essa live do ar, tá? ela não vai ficar mais disponível eh depois de
hoje. Eu vou eu vou tirar ela do ar agora, mas só vai conseguir acessar
essa live quem tiver o link dela. O link dela vai estar na descrição
desse vídeo. Essa daqui é a melhor aula que eu já dei sobre como que
você cria anúncios para os seus clientes, como é que você vai criar bons
anúncios paraos seus clientes. Então, a resposta para vixe, parei de
compartilhar, errei o botão aqui, desculpa. Foi a resposta para quais
anúncios nós vamos utilizar está na live número 372. O link dessa live
já tá na descrição para você, tá? Que que você vai fazer agora, Pedro?
Não sei nada de tráfego pago, Socorro. Meu Deus do céu, nada fez sentido
para mim. Você vai salvar o link da nossa ferramenta de diagnóstico.
Você vai salvar porque eu não vou disponibilizar de novo essa
ferramenta, tá? Eu não vou, eu já estou arrependido de de ter de
disponibilizá-la de graça. Você vai salvar o link da ferramenta e ele
vai ficar disponível para você. Você vai salvar ele, você vai guardar
ele, você vai botar num bloco de notas e você não vai perder. E aí no
futuro você vai utilizar esse negócio, ele vai salvar sua vida. Pedro,
eu já sou gestor de tráfego, eu já quero atender, eu tô aqui só pelo
link do diagnóstico. Calma que eu vou te falar agora como é que você vai
ter acesso. Pedro, eu não sou gestor de tráfego, mas eu tô começando.
Não entendi tudo dessa aula, mas eu entendi várias coisas que você
explicou. As peças estão começando a fazer um pouco mais de sentido. Eu
sou aquela típica pessoa que tenho medo de executar. Eu sei o que eu
tenho que fazer, mas eu não faço. Eu me sinto inseguro. Eu sinto que não
tô pronto. Eu tenho medo de não gerar resultado pro meu cliente. Eu acho
que eu tenho que estudar um pouquinho mais antes de começar. você
especialmente, você vai clicar no link que tá na descrição desse vídeo e
você vai se cadastrar para participar do nosso desafio de 90 dias, tá?
Você vai lá na descrição desse vídeo e você vai se cadastrar na live de
aquecimento do nosso desafio. Você vai colocar o seu nome, o seu e-mail
e você vai fazer o seu cadastro. Simples assim, não tem mistério. Você
vai clicar no primeiro link que tá na descrição desse vídeo e você vai
cair aqui, ó, nessa página. vai colocar, olha como a gente tá bonitão
aqui nessa página, você vai colocar o seu nome, seu e-mail e você vai se
cadastrar. Nessa live a gente vai explicar tudo para você sobre o
desafio e você vai participar desse desafio e em 90 dias eu vou te
destravar de ganhar dinheiro na internet. Simples assim. Pedro, como é
que eu faço agora para ter acesso ao diagnóstico, a ferramenta de
diagnóstico de tráfego para negócios locais? Você vai fazer o seguinte,
você vai vir aqui no meu Instagram, Pedro Sobral, tá? Esse aqui é meu
Instagram, e você vai me enviar uma mensagem, não é para comentar no meu
post. Presta atenção que se você não conseguir fazer isso, você não vai
conseguir ser gestor de tráfego. Você vai me enviar uma mensagem, enviar
mensagem. E aí você vai me mandar uma, vai me enviar uma mensagem
escrito live L I V E 374. Live espaço 374, tá? Pode ser tudo minúsculo.
Live 374, tá? Então você vai me mandar live 374 do meu perfil. Você vai
receber quando você me mandar a live 374 o convite para se cadastrar no
desafio de 90 dias. se cadastre no desafio de 90 dias, participa da
nossa live que acontece quando? Sem ser na próxima segunda, dia 9, na
outra segunda, dia 16 de março, 8 horas da noite, a nossa live, onde a
gente vai explicar tudo sobre o desafio de 90 dias. Ele é basicamente um
protocolo dos seus primeiros R$ 5.000 na internet. É isso, o protocolo
dos seus primeiros R$ 5.000 na internet, tá? E aí, só me mandar lá no
Instagram, qual que é o link? O link do que, meu querido? Cadê o link?
Como é que você não tá limpa os seus ouvidos, cara? Pega um cotonete e
limpa os ouvidos. Eu tô te dizendo, vai no meu Instagram, me manda live
374 que eu vou te mandar o link por lá, tá? O qual link? O link vai no
perfil, velho. É só ir no Instagram e digitar Pedro Sobral. Pedro
Sobral. Pedro cinco letras. So. Opa, três. So bra. São 11 letras. 11
letras. É só você digitar Pedro Sobral. Você digitou Pedro Sobral, você
cai no meu perfil. Digitou Pedro Sobral, caiu aqui. Aí me manda uma
mensagem. Live 374. Ah, não. Muito trabalho. Ah, então vai tomar no cu.
Nando. Brincadeira. Brincadeira, brincadeira. Esse é o Pedro do Velho
Testamento. Eu tô tô tô querendo ressuscitar mais o Pedro do Velho
Testamento aqui, porque tem horas que vocês me estressam, tá? Tem horas
que horas que vocês estressam. [risadas] Ai ai. E e no caso eu que nunca
trabalhei como gestor, como é que eu vou vender se eu não tenho
autoridade? Calma, meu querido. Tudo isso vai ser explicado nos próximos
capítulos da nossa novela aqui, da novela da gestão de tráfego pago da
sua vida, tá? Como é que você vai vender uma coisa que você nunca fez da
mesma maneira que você foi pro seu primeiro trabalho? Você foi lá e você
aprendeu a fazer uma habilidade. Eu vou te explicar como é que você faz
isso. Ah, eu consigo ser pago para aprender. Consegue. É isso que eu tô
te dizendo. É isso que eu tô te dizendo. Ah, não. O link da ferramenta
de campanha que você prometeu no começo. Vai tomar no É só ir lá no meu
Instagram. Vai no meu Instagram. Vai no meu Instagram. Vai aqui, Vai,
vai no meu Instagram como é que vou te explicar. Vai no meu Instagram,
Pedro Sobral. Digita lá Pedro Sobral no Instagram. Chegou lá no
Instagram, me manda uma mensagem live 374. Só isso. Vai no meu
Instagram, Pedro Sobral me mandou uma mensagem. Live espaço 374. Como é
que escreve live? Não é live com a É live. L I V E L I V E 374 espaço
374. Me mandou essa mensagem, recebeu o link. Vai chegar também o
convite para você participar do nosso desafio de 90 dias. Se cadastre.
Vai ser um prazer ter você lá. Calma, calabresa. Eu povo, eu tô, eu tô
zoando, eu dou uma exagerada, tá? Vocês t que entender que faz parte do
personagem. [risadas] Ai ai ai. É só pela zoeira. Só pela zoeira que eu
sei que é aquele negócio, né? Eu sei que tem alguém rindo. Aí uma das
meus esportes favoritos da vida é fazer as pessoas rir, por mais que eu
seja uma pessoa meio sem graça, mas eu eu tento, eu me esforço, eu me
esforço, tá? Eh, calma aí, eu tenho que liberar a palavra-chave da aula
de hoje. Palavra-chave da aula de hoje vai ser respira. Respira,
respira. Povo, é o seguinte, para você que está aqui, nós temos toda
semana uma lista de presença das nossas aulas ao vivo, tá? Então, neste
momento, você está assistindo esta live aqui, ó. Deixa eu compartilhar
minha tela com você, vai ficar uma coisa meio sanduíche, mas, ó, isso.
Você tá assistindo essa live aqui, ó. Então, você tá aqui assistindo
essa live. Agora vai ficar o sanduíche geral aqui. Que que você vai
fazer? Sicher. Você vai ver na descrição desta live. E aqui você vai ter
alguns links, tá? Primeiro link, live de aquecimento. Se cadastra na
live para participar do nosso desafio de 90 dias. Segundo link, lista de
presença da live. Segundo link, aqui você vai colocar seu nome, um
e-mail, seu WhatsApp. Você vai escolher a palavra-chave da aula de hoje,
que é a palavra-chave respira. Por que que você vai se cadastrar? Porque
uma vez por mês, ou quase uma vez por mês, a gente faz um sorteio aqui.
E esse sorteio você pode ganhar desde um computador até uma caneca. De
uma caneca até um computador, né? E aí que que você vai fazer para você
receber prêmios melhores, você tem que ter visto mais aulas. Então você
vem aqui toda terça-feira tem uma aula de tráfego pago sobre anúncio
online e você consegue ter acesso a prêmios incríveis toda terça-feira,
tá? Pedro, faz o sorteio hoje. Eu não consigo fazer o sorteio hoje
porque eu tô com uma tela menos. Eu sei que isso parece uma desculpa
esfarrapada, mas complica muito fazer o sorteio com uma tela menos,
porque eu tenho que colocar os dados de vocês de um lado, o sorteio do
outro, fica uma confusão sem fim, tá? Quando eu voltar para casa de
viagem, eu faço o próximo sorteio e aí eu vou fazer dois sorteios, tá?
Vou fazer dois sorteios para compensar os sorteios que eu não tenho
feito, tá? assistir as lives passadas contam não, porque você precisa
preencher a sua presença nas primeiras 24 horas depois que a live foi no
ar para mostrar que você tava presente ali na semana, né? Então tem que
assistir as lives eh das conforme elas vão acontecendo, tá? E aí, última
coisa, se você for lá no meu perfil do Instagram, tá? Então, o perfil
Pedro Sobral, só procurar no Instagram Pedro Sobral e me mandar a
mensagem escrito live 374. Você vai receber o convite para participar do
nosso desafio de 90 dias e você também vai receber o link do nosso da
nossa ferramenta de diagnóstico de tráfego pago para negócios locais,
tá? Mesmo que você ainda não saiba como é que você vai utilizar, eu
recomendo muito que você já deixe ele salvo aí, porque isso aqui pode e
vai te ajudar muito no futuro. Eu garanto para você, nem curso pago te
entrega isso daqui na internet. Se você concorda, por favor, pode
colocar no chat aí que você concorda, porque essa entrega aqui tá a
altíssimo nível. É tudo aquilo que você precisa para fazer tráfego para
negócio local. Claro que eu não consigo trazer todos os conhecimentos de
tráfego pago numa única live. Para isso eu tenho o meu curso, para isso
eu tenho os meus treinamentos, para isso tenho os outros conteúdos aqui
do canal. E aí você também tem que fazer a sua parte, né, meu querido?
Ninguém vai te ensinar uma profissão inteira em uma hora. Se você acha
que era isso que ia acontecer, você está extremamente iludido. Mas se
você voltar aqui, na próxima semana teremos mais uma live, na outra
semana mais uma live, na outra semana mais uma live. E assim por diante.
Inclusive, eu já tenho aqui os temas das próximas lives, tá? Eh, semana
que vem a gente vai falar sobre como criar campanhas no WhatsApp para
negócios locais. Na outra semana a gente fala de como prospectar
clientes de tráfego pago. Na outra semana eu vou fazer uma live com um
aluno, tá? Que é um aluno que tá faturando aí seus acho que mais de R$
100.000 R$ 1000 por mês como gestor de tráfego. Tudo que ele faz, ele
aprendeu ali na comunidade subido. Eu vou trazer ele aqui para dar a
versão dos fatos dele, de como que isso aconteceu. Na outra semana
falaremos sobre Google Meu Negócio, então como é que você vai fechar
cinco contratos em 30, 60 dias com Google Meu Negócio. Na outra semana
falaremos das habilidades que você tem que desenvolver para sair do zero
e até os 10.000 prestando serviço na internet. E na outra semana a gente
fala de, olha só, campanhas de formulário nativos no Metaedits, tá?
Então várias semanas, vários conteúdos, às vezes falando mais de venda,
às vezes falando mais da gestão de tráfego, às vezes mais técnico,
enfim, toda terça-feira tem conteúdo aqui. Se você botar na sua agenda 3
horas da tarde, estarei ao vivo aqui te entregando conteúdos com esse
nível de qualidade. Fechou? Estamos junto e a gente se vê na próxima
semana. Não se esquece de se cadastrar no desafio de 90 dias e de me
mandar aqui na eh no meu Instagram live 374, tá? Não é para comentar
aqui no YouTube, é lá no Instagram. Comenta aqui no YouTube o que que
você gostou dessa aula quando a aula terminar. Fechou? Tamo junto, meu
povo. Um beijo. Valeu. É nós. Vou lá almoçar porque aqui é 2 horas da
tarde. Agora eu tô no fuso horário diferente, né? Tô com fome, não
almocei ainda. Fechou? É nós. Valeu,

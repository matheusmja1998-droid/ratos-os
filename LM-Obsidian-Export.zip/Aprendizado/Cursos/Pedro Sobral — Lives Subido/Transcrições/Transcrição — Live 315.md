---
tipo: transcrição
live: 315
tema: Como criar campanhas no Google Ads em 2025
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #315

> Como criar campanhas no Google Ads em 2025

Resumo e aplicação: [[Live 315 — Como criar campanhas no Google Ads em 2025]]

---

bem-vindo bem-vindo bem-vinda bem-vinda à nossa Live número 315 hoje
você vai aprender comigo aqui um passo a passo completo de como que você
cria a sua primeira campanha dentro do Google ADS além de ter acesso a
esse tutorial que é essa aula você também vai ter acesso a algumas aulas
extras que vão complementar o conteúdo que você vai aprender aqui hoje e
um material PDF que você também vai poder baixar para guardar ele no seu
computador para sempre que vai te dar um passo a passo bonitinho de como
que você cria a sua conta de anúncios dentro do Google ADS E como que
você configura ela para começar a rodar os seus anúncios ou seja essa
aula aqui é tudo que você precisa para dar o primeiro passo para
anunciar no Google ADS em 2025 e sim essa é a nossa Live número 315 você
pode estar se perguntando Pô esse maluco tá tá fazendo aulas a 315
semanas Sim estamos fazendo aulas a mais de 300 15 semanas se você
entrar no meu canal do YouTube você vai perceber que você não vai
encontrar aqui 315 lives aí você vai dizer assim ah ele tá mentindo não
é que as nossas aulas aqui elas seguem um modelo de conteúdo que eu
chamo de conteúdo perecível o que que é o conteúdo perecível ele fica
disponível durante 7 dias depois de 7 dias esse conteúdo ele sai do ar
então eu tiro esse conteúdo do ar e você não tem mais acesso a ele Ah
então quer dizer que se eu tivesse aqui ao vivo todas as terças-feiras 3
horas da tarde eu teria visto todas as aulas de graça sim você teria
visto todas as aulas de graça se você tivesse assistido elas aqui todas
as terças-feiras Mas algumas das aulas do meu canal do YouTube estão
sempre disponíveis então se você entrar aqui no meu canal elas vão
mudando com o passar do tempo tá eu não sei se quando você já tá tá
assistindo são as mesmas mas nós temos as aulas aqui que eu chamo de
essenciais são aulas que se você assisti-las você tem tudo tudo o que
você precisa para anunciar na internet e ganhar dinheiro com isso seja
você é alguém que vai prestar o serviço de cuidar dos Anunci online das
outras empresas Ou seja um gestor de tráfego Ou seja você o dono de um
negócio que quer aprender a fazer anúncios pro seu próprio negócio então
aqui você vai encontrar mais ou menos 20 30 horas de conteúdo que é
muito mais conteúdo do que assim 90% dos cursos de tráfego pago que tem
na internet e você vai perceber que são aulas mesmo tá toda aula eu faço
sem introdução porque tem pessoas novas chegando aqui caso você vai
assistir uma dessas aulas você pode pular essa introdução e é claro eu
tenho sim meus treinamentos pagos né então eu tenho na minha opinião o
produto de tráfego pago mais completo do mercado onde a gente aborda
tráfego para meta Google tiktok ADS do zero a avançado curso de
prospecção de clientes tráfego para e-commerce tráfego para negócio
local tráfego para infoprodutos bloqueios e contingência aulas e lives
sobre tráfego para todo todos os nichos existentes tem tudo lá mas esse
produto a gente abre ele né a comunidade subido de tráfego a gente Abre
ela somente algumas vezes no ano se você tá vendo essa Live aqui com
certeza os meus anúncios aparecerão para você te avisando agora o que
que eu quero que você foque eu quero que você foque no conteúdo aqui da
aula de hoje da nossa Live número 315 e antes de mais nada eu quero
dizer para você uma informação muito importante eu não estou ao vivo
agora você que tá me assistindo aqui terça-feira 3 da tarde eu sei que
isso aqui parece uma transmissão ao vivo E isso acontece com uma certa
Raridade eu não estar ao vivo ao vivo ao vivo mas eu estou na cidade dos
meus pais agora nesse momento fui ver meus pais no final do ano né
quando eu tô gravando essa aula e eu não conseguiria ter uma conexão de
internet de qualidade para entregar esse conteúdo para você como eu sei
que essa aqui é uma aula que vai ficar disponível por bastante tempo eu
resolvi fazer a gravação dela eu sei que tem um lado ruim que não tem
aquela interação com o chat Maroto mas eu estarei no chat interagindo
com você aqui digitando e eu gosto desse modelo de aula principalmente
paraas que para para as aulas que ficarão mais tempo no ar Porque ela
fica uma aula um pouco mais direta né eu eu vou mais direto ao ponto
porque não fico me distraindo com as mensagens do do chat não se engane
eu amo me distrair com as mensagens do chat tá então agora sim direto ao
nosso conteúdo Como que você faz para anunciar no Google ADS em 2025 é o
seguinte essa visão que você tá tendo aqui é é a carinha do Google ADS e
o Google ADS nossa ele dá um medo primeira vez que eu entrei aqui eu
tinha assim dava um como é que um faniquito me dava uma uma uma
inquietação de entrar aqui dentro porque são botões demais são muitos
menus é uma coisa um pouco assustadora é normal no começo você ficar
confuso o tráfego pago É como se é como se ele fosse um novo idioma e
aos poucos a gente vai explorando ele até que ele se torne 100% claro
para você agora como que a gente faz para ter acesso à nossa conta do
Google ADS primeiro isso é 100% gratuito tá aqui na descrição deste
vídeo você vai ter um link para você baixar o material PDF dessa aula
esse material PDF vai conter este tutorial de como que você cria e
configura sua conta de anúncios tá então esse material PDF vai est
disponível para você baixar você vai ter lá um passo a passo de como que
você cria e configura essa conta de anúncios Por que que você não vai
ensinar isso ao vivo ped porque isso demoraria 20 30 minutos e é algo
que é muito mais fácil de você fazer com um tutorial do que você fazer
comigo te explicando porque você i ter que ficar pausando o vídeo o
tempo inteiro e você já Guarda esse tutorial para você para aprender a
configurar aqui toda a sua conta uma vez Então passo número um check uma
vez que você tem a sua conta de anúncios você vai estar aqui dentro no
meu caso aqui eu tenho várias campanhas criadas né no seu caso não vai
ter nada aqui é sua conta de anúncios ela vai est completamente vazia
iia mas a gente vai começar por algum lugar e esse algum lugar é
apertando em criar a nossa campanha tá então vou criar uma campanha
antes de eu apertar no botão e eu sei que tem gente que ah já sai
clicando já sai fazendo tudo eu já vou sair fazendo tudo vou criar toda
a campanha na sua frente antes disso é importante que você entenda o que
que é uma campanha tá E aí para isso eu trouxe para você aqui uma
explicação de como que funciona uma campanha se você já viu alguma aula
minha de meta eds por exemplo tem uma aula no meu canal do YouTube aqui
de como fazer sua campanha no meta ads em 2025 vale a pena você dar uma
checada eu vou deixar essa aula do meta ads como uma aula complementar a
esta aula daqui o link vai est na descrição tá lá eu vou fazer a mesma
explicação que eu faço para você aqui que a campanha é como se ela fosse
uma pasta do seu computador sabe uma pasta do seu computador Então faz
de conta que essa caixinha é a pasta que eu tenho no meu computador
dentro dessa pasta eu posso colocar uma outra pasta dentro dessa outra
pasta eu posso colocar aqui dentro deixa eu pegar minha outra pasta aqui
dentro dessa outra pasta eu posso colocar aqui dentro uma outra pasta
Então eu tenho essas três estruturas que são vamos lá a minha campanha a
minha os meus conjuntos de anúncio e dentro dos meus conjuntos de
anúncio eu tenho os meus anúncios então uma coisa está dentro da outra
ela s como eu gosto de chamar estruturas organizacionais agora cada
estrutura dessas tem um grande objetivo tá então uma grande definição a
nossa campanha no Google ADS ela vai servir para definir o nosso
objetivo a rede na qual nós vamos anunciar e eu já vou te explicar o que
que é isso o orçamento ou seja quanto de dinheiro que eu vou gastar já o
conjunto de anúncio representado aqui pela nossa carteirinha marrom ela
é a a a a a estrutura organizacional onde eu vou selecionar as minhas
palavras-chave e isso no caso de uma campanha de pesquisa eu poderia
colocar palavraschave ou público alvo então para qual pessoa que eu
quero anunciar quando a pessoa tá fazendo qual busca no Google que eu
quero aparecer para ela para qual qual tipo de interação com o meu canal
do YouTube que eu quero aparecer Quais são os interesses das pessoas
para as quais Eu quero aparecer essa essa seleção vai ser feita no
conjunto de anúncio e por último e não menos importante dentro do
conjunto ou dos conjuntos de anúncio eu tenho os meu o meu anúncio ou os
meus diversos anúncios tá essa é a nossa estrutura inicial Tá então se a
gente for olhar por exemplo uma campanha da rede de pesquisa ela ficaria
mais ou menos assim eu tenho aqui a minha campanha dentro da minha
campanha eu vou ter diversos conjuntos de palavraschave ou seja
conjuntos de anúncios né Eu gosto de chamar de conjuntos de
palavra-chave porque eu vou ter vários vrios grupos que reúnem palavras
chaves diferentes isso vai ficar mais claro no momento para você por
enquanto eu quero pincelar essas confusões na sua cabeça porque isso vai
fazer parte do seu entendimento aqui então eu tenho a minha campanha ó
dentro da minha campanha eu tenho os meus conjuntos de anúncio ou os
meus conjuntos de palavra-chave no caso de uma campanha na rede de
pesquisa lá quando a pessoa digita no Google uma pesquisa aparece o seu
anúncio dentro dos conjuntos de palavra-chave eu tenho os anúncios
correspondentes a essa palavra-chave Então dentro de cada um deles eu
tenho aqui o anúncio ou mais de um anúncio correspondente a esta
palavra-chave Então você tá entendendo uma coisa tá dentro da outra
dentro da campanha eu vou ter todos os meus conjuntos de anúncio dentro
dos meus conjuntos de anúncio por sua vez eu tenho os meus diversos
anúncios tá só para você entender que uma coisa tá dentro da outra
quando a gente for criar isso na prática você vai perceber que em um
determinado momento o Google vai me perguntar Ah qual que é o nome que
você quer dar pra sua campanha Qual que é o nome que você quer dar pro
seu conjunto de anúncio Qual que é o nome que você quer dar pro seu
anúncio se você entrar aqui entrar aqui na minha conta de anúncio você
vai perceber que existe um padrão nas minhas nomenclaturas aqui ó Então
eu tenho aqui ó campanha ONG alunos Bumper eu tenho ONG alunos display
Então você consegue perceber que essa aqui é uma campanha PR os meus
alunos você consegue perceber que essa daqui é uma campanha para convite
das minhas aulas ao vivo porque tá escrito aqui ó convite aulas você
consegue perceber que essa aqui é uma campanha da pesquisa que eu
coloquei o termo em inglês né search você consegue perceber que é uma
campanha feita em 2024 Então são algumas nomenclaturas que me ajudam se
eu abro essa campanha aqui por sua vez eu vou perceber que eu tenho uma
um conjunto de palavras que é sobre divulgar uma empresa na internet eu
tenho um outro conjunto de palavras que é sobre divulgar impulsionar
Patrocinar no Instagram eu tenho um outro conjunto de palavras que é
sobre gestor de tráfego então esses são os meus conjuntos de anúncio
Então você tá percebendo que existe uma organização da minha
nomenclatura que o que que é A nomenclatura são os nomes que eu estou
utilizando agora isso para nós é muito importante porque por mais que
pareça algo bobo algo simples isso traz muita organização e clareza para
o processo de criar campanhas tá Então como que a gente vai organizar a
nomenclatura eu gosto de organizar nomenclatura dessa maneira tá então
na minha campanha eu sempre vou colocar o objetivo da campanha tá então
é uma campanha de vendas é uma campanha para gerar cadastros eu vou
colocar a data e a identificação da campanha Uma Breve descrição tá Ah
faltou uma coisa aqui mil desculpas a gente vai colocar também a rede a
rede é on qual rede que eu vou aparecer vai ser na pesquisa do Google
não não vai ser na pesquisa vai ser no YouTube não não vai ser no
YouTube vai ser na rede de display do Google ou onde que a gente vai
colocar em qual Red que o meu anúncio vai aparecer no conjunto de
anúncio eu vou colocar o nome do conjunto de palavras-chaves ou do
público alvo tá dependendo se eu tô anunciando por uma palavra-chave ou
por uma um público específico e o anúncio eu sempre vou colocar ad01
descrição do anúncio tá então sempre vai ser esse nome ad01 AD é anúncio
em inglês e uma breve descrição do meu anúncio beleza feito isso a gente
entendido isso a gente pode prosseguir já pra parte mais prática da
coisa pô Pedro a gente já vai prosseguir pra parte prática Exatamente
porque eu entendi como é que se estrutura uma campanha e como é que eu
vou dar nome para elas agora a gente tem que aprender o quê A gente tem
que aprender a criar todas essas estruturas na prática a gente vai
aprender como que a gente faz para fazer todo o processo de criação de
campanhas e quando a gente for caminhando junto por esse processo você
vai notar que as campanhas tem essas três estruturas que eu te falei
campanha conjunto de anúncio palavras-chave e anúncios e dentro de CAD
cada uma dessas estruturas existem configurações que nós vamos ter que
fazer quando a gente olha o Google ADS Ele parece algo muito complexo
mas quando você para para perceber que são poucos passos na verdade são
13 passos que nós temos que dar para criar uma campanha a coisa fica um
pouco mais simples tudo que você tem que saber é como que você dá cada
um desses Passos então quando eu for criar a minha campanha eu vou ter
que selecionar por exemplo os meus objetivos as minhas metas de
conversão o tipo de campanha Como que você quer alcançar sua meta os
lances as redes os locais os idiomas os segmentos de público alvo as
palavras-chaves de correspondência Ampla e recursos automáticos e outras
configurações Quando eu for configurar o meu conjunto de anúncio eu vou
escolher as minhas palavras-chave e quando eu for configurar o meu
anúncio eu tenho que configurar o meu anúncio são 13 Passos tá então o
que que nós vamos fazer a partir de agora a gente vai ver na prática a
configuração de cada um desses passos e eu vou fazendo a explicação de
cada um deles para você para tudo ficar muito tranquilo e você sair
daqui não só um papagaio que sabe clicar em todos os botões mas alguém
que entende aquilo que tá fazendo Tá Então como que a gente faz isso
primeiro passo para criar uma campanha você vai estar aqui no seu Google
ADS você vai estar aqui ó nesse menu campanhas campanhas e você vai
apertar no botãozinho de criar campanha nova campanha ao apertar aqui o
Google Já vai fazer o primeiro pedido para você que é qual que é é o seu
objetivo de campanha E aí quais são os objetivos que nós temos nós temos
o objetivo de vendas leads tráfego promoções do aplicativo
reconhecimento e consideração visitas a lojas locais e promoção e
Campanha sem meta Qual que é o objetivo das da campanha de vendas vender
Qual que é o objetivo da campanha de leads gerar contatos qualificados
de tráfego gerar acesso ao site promoção do aplicativo gera instalações
no seu aplicativo reconhecimento e consideração divulga o seu conteúdo e
a sua marca visita as lojas locais e promoções ignorar então não usa
normalmente ele não funciona não é o melhor objetivo que nós temos para
visitas às lojas locais pelo menos não quando eu tô gravando esse vídeo
E durante muito tempo também não foi não vai ser na minha na na minha
previsão e Campanha sem meta raramente utilizada tá então esses são
objetivos que você precisa se preocupar menos tá então vendas é para
vender dia para gerar Lead tráfego é para enviar as pessoas pro site
promoção de aplicativo para promover aplicativo reconhecimento e
consideração para divulgar sua marca seus conteúdos seu canal do YouTube
os conteúdos do seu site visitas a lojas locais a gente não vai utilizar
e criar uma campanha sem meta raramente vamos utilizar também o que que
a gente vai mais usar aqui no Google principalmente para quem tá
começando vendas e leads ou eu quero contato qualificado ou eu quero
vender Qual que é a diferença das duas não muda nada única coisa que vai
mudar é em qual dos dois que a gente vai clicar aqui no começo Ah eu
quero vender beleza quero Lead Beleza o processo é exatamente o mesmo tá
se você sabe fazer uma você sabe fazer outra depois que eu selecionei
isso o Google vai me pedir para configurar as metas de conversão então o
que que são as metas de conversão é no que que eu quero focar Ah eu
quero focar em compras eu quero focar em contatos eu quero focar em
enviar formulário de Lead enfim eu vou escolher aqui no que que eu quero
focar e o que eu não quiser focar eu vou remover Pedro mas como é que eu
configuro essas metas de conversão isso vai est explicado para você no
tutorial de como é que você cria e configura sua conta de anúncios
lembrando o link para você baixar esse tutorial ele tá aqui na descrição
é só você botar seu nome e-mail telefone que você consegue baixar ele a
um clique tá o link tá aqui na descrição então no caso como eu tô
querendo venda o objetivo que eu vou utilizar provavelmente é o de
compra tá então selecionei o objetivo de compra vou apertar agora aqui
em continuar então presta atenção eu já selecionei o objetivo e já
selecionei as minhas metas de conversão tá até coloquei aqui ó você vai
aprender a configurar sua tag de conversão em uma aula que vai est na
descrição tá então ah eu esqueci de falar isso ainda bem que eu abri
esse menu aqui a gente vai aprender na descrição você tem tanto o pdf
quanto uma aula complementar a esta aula que te ensina a fazer toda a
instalação da tag de conversão tá então tem uma aula complementar e o
material PDF tudo isso vai est aqui na descrição no final você acessa
ali todos os links disponíveis para você feito isso agora a gente vai
entrar na parte do tipo de campanha e aqui pode complicar um pouco tá
algumas pessoas elas ficam confusas aqui no tipo de campanha mas não tem
muito o que ficar confuso não o Google tem diversas opções mas todas
elas são bem Como que eu posso dizer todas elas são muito específicas
quando que elas devem ser utilizadas então por exemplo o primeiro item
que eu tenho aqui é o search né às vezes ele tá escrito pesquisa às
vezes vezes search o Google ele é meio bilíngue então o search ele serve
para eu focar em aparecer para a pessoa no momento da intenção e levar a
pessoa pro meu site Como assim Pedro ué quando eu vou no Google e
pesquiso curso de crochê o que que vai aparecer para mim como anúncio
curso de crochê é isso que vai aparecer para mim então eu tenho uma
intenção de comprar um curso de crochê e vai aparecer para mim aqui
cursos de crochê para eu comprar isso daqui nesse exemplo aleatório que
eu fiz ou seja isso é um anúncio na rede de pesquisa do Google esse é o
poder que a gente tem com a rede de pesquisa é dominar o topo da rede de
pesquisa depois nós temos o objetivo de performance Max tá a teoria
desse objetivo né desse tipo de campanha é muito bonito ele diz você vai
aparecer em todos os lugares que a gente consegue anunciar só que ele
funciona bem para algumas situações não tão bem para outras vamos a elas
quando eu quero gerar leads ou seja contatos qualificados pessoas me
dando e-mail e telefone para eu falar com elas eu vou ter uma campanha
mais Ampla e vou ter menos controle de segmentação Ou seja eu vou poder
escolher menos para quem que eu quero aparecer Então vale o teste para
quem tá escalando e investindo cada vez mais Pedro esse não é o meu caso
ignora ela serve para negócios locais então se eu tenho um negócio local
um estabelecimento local pode funcionar pra geração de leads e também é
o tipo de campanha que você usa para Google meu negócio para gerar
visitas na loja então quando eu quero fazer com que as pessoas vão até o
meu estabelecimento é esse tipo de campanha que a gente vai utilizar o
que é meio nada a ver né porque se a gente parar para pensar lá na parte
de objetivos eu tenho um objetivo de campanha que é visitas a lojas
locais e promoções e a gente vai acabar utilizando mais aqui o
performance Max né então assim vale o teste mas eu digo que é uma
roletinha russa porque às vezes ele funciona e às vezes ele não funciona
tá depois disso nós temos a a campanha de performance Max para
e-commerces nesse caso ela funciona bem Tem bastante escala e um bom ras
mas depende do nicho então em todo caso aqui o performance Max ele
normalmente é bom mas ele precisa tá então vou escrever aqui ó
normalmente é bom mas precisa testar não tem jeito não tem uma ah sempre
vai funcionar diferente da rede de pesquisa a rede de pesquisa ela é
muito boa porque você aparece pra pessoa no momento da intenção no
momento que ela quer encontrar uma determinada um determinado serviço um
determinado produto geração de demanda que é o próximo objetivo aqui ó
geração de demanda a gente vai aparecer no YouTube no Discover E no
Gmail e na teoria é lindo mas na prática nem tanto Vale também o teste
para quem tá escalando mais rede de display que é a próxima aqui você
vai ela funciona funciona muito bem para aparecer para pessoas que já
tiveram algum contato com você mas não compraram tá então pessoas que
foram até o seu site mas não compraram então eu coloquei aqui bom para
remarketing remarketing é isso aparecer para quem já aparece já quem já
visitou o seu site quem já teve algum contato com você mas ainda não
comprou campanhas de shopping é bom para remarketing de e-commerce então
mesma coisa eu vou exibir meus produtos para as pessoas que já visitaram
o meu site na rede de pesquisa pode funcionar aliás funciona bem mas ela
vai ser focada para lojas online e vídeo aí Aqui são as campanhas de
vídeo para gerar vendas para aumentar os inscritos no meu canal do
YouTube para gerar outras ações tá então fazer meus conteúdos chegarem
até mais pessoas é a divulgação no YouTube é quando você tá vendo aqui
esse vídeo no YouTube e pá aparece um anúncio na sua frente te
atrapalhando essa pessoa fez esse processo de criar uma campanha e
selecionar na objetivo de vídeo tá não tá aparecendo aqui o último
objetivo eu vou mudar aqui rapidamente o objetivo de campanha não tá
aparecendo aqui não estava aparecendo o aplicativos tá que serve para
você aumentar downloads e engajamento de aplicativo mas como a gente tá
focado em Venda Deixa eu só remover esses outros aqui também é só pelo
exemplo né que eu gosto de deixar tudo bonitinho e organizado pra gente
criar nossa campanha tá então quando eu selecionei meu objetivo aí eu
vou selecionar o quê on onde que eu quero Em qual rede que eu quero
alcançar esse objetivo e a gente vai escolher alguma delas aqui tá elas
vão ter diferenças na parte de criação eu tenho outras aulas de Google
ADS que eu dou aqui nas aulas de terça-feira que eu ensino outros tipos
de campanha nessa aula eu quero focar na campanha que todo mundo tem que
dominar que é a campanha da rede de pesquisa por quê Porque ela é a
campanha que vai gerar o seu contato mais qualificado o seu acesso mais
qualificado porque é uma pessoa que tá pesquisando pelo seu produto o
seu serviço pronto acabou aí aqui a gente vai selecionar como que a
gente quer alcançar nossa meta eu posso levar a pessoa pro meu site eu
posso fazer a pessoa me ligar e eu posso fazer a pessoa visitar minha
loja tá então assim todos eles aqui funcionam bem o ideal para mim para
quem tá começando é começar com visita ao site E aí sim você precisa ter
um site ou pelo menos um uma página do Google meu negócio bem
configurada bonitinha que é 100% gratuito de você fazer tá não precisa
colocar o site da empresa aqui e aí você vai apertar nesse botão de
continuar apertou no botão de continuar temos que colocar aqui o quê
temos que colocar o nome da nossa campanha tá então na parte da
nomenclatura da nossa campanha a gente vai colocar exatamente o que eu
falei para você anteriormente Vou colocar aqui o meu objetivo de
campanha que no caso é vendas vou colocar a data tá Então essa daqui vai
ser por exemplo Nossa campanha que vai rodar no ano de 2025 vou colocar
uma identificação da campanha então então pode ser a campanha não sei x
y z vou colocar rede aqui é uma campanha da pesquisa então só com isso
daqui eu consigo já ter uma boa noção do que que é essa campanha e
aperto em continuar presta atenção olha o que a gente já fez nós já
selecionamos a parte de objetivo de campanha já selecionamos a meta de
conversão e o tipo de campanha selecionei como que eu quero alcançar
minha meta e agora a gente tá no Passo número cinco tá então eu
selecionei aqui que eu queria visitas no meu site e aí eu vou pra etapa
número cinco que é a etapa da configuração do quê dos meus lances tá
como que funciona o que que são os lances o lance é basicamente o
seguinte em qual métrica que eu quero focar Qual resultado que você quer
focar e quanto que você tá disposto a pagar por esse resultado então eu
vou selecionar aqui ah eu tô eu quero focar em conversão não eu quero
focar em clique não eu quero focar em valor da conversão eu quero que a
pessoa gaste dinheiro comigo no meu site no na minha loja então você vai
selecionar aqui o mais comum vai ser clique ou então conversões tá
perdido não sabe para onde vai foca em conversões E aí você pode definir
um custo por ação ou não isso daqui é o quê Quanto que eu tô disposto a
pagar por uma conversão aí vai depender de cada produto por exemplo
alguém que tá vendendo um imóvel Talvez esteja disposto a gastar um
pouco mais por conversão do que alguém que tá vendendo sei lá um curso
de R 47 tá entendendo então isso vai depender de negócio para negócio
você tem que saber o quanto você tá disposto Ah Pedro eu sou muito
espertão eu vou botar 1 centavo aí que tá o problema este lance que é o
que que eu tô o quanto que eu tô disposto a pagar ele vai dizer o
seguinte quanto maior for o meu lance mais eu gasto mas mais eu pago por
resultado então se eu colocar um lance muito alto eu vou aparecer muito
a agora e vou pagar mais caro né vou pagar 10 vou enfim se colocar R 10
por conversão eu vou pagar R 10 para cada conversão ele vai buscar esse
resultado não quer dizer que ele vai conseguir me entregar e depois se
eu colocar um lance menor eu vou gastar menos ou seja eu vou aparecer
menos só que eu vou pagar mais barato por cada um dos resultados então
se eu colocar um lance aqui de 10 centavos Pode ser que eu não apareça
quase nada pode ser que eu apareça tão pouco que ninguém converta agora
se eu botar um lance de 999999999 eu vou aparecer muito mas eu vou pagar
muito caro por cada um desses resultados porque eu tô dizendo pro Google
que eu tô disposto a pagar muito caro por cada um desses resultados tá
então mais uma vez isso vai depender do seu negócio no meu caso aqui sei
lá se eu fosse vender eu tô levando as pessoas para comprar um produto
no meu site esse produto custa r$ 500 e eu sei que eu posso pagar até r$
3 30 por conversão r$ 50 por conversão vai ser esse o valor que eu vou
colocar aqui tá feito isso ele vai me perguntar se eu quero otimizar
para aquisição de novos clientes ou seja Ah eu quero ao máximo tentar
buscar alguém que não é meu cliente ainda isso é uma opção nova acredito
que pra maioria das pessoas não vai fazer diferença feito isso vamos
apertar em próxima E aí ele vai vir pra parte de configuração de rede
então ó já estamos andando são 13 passos a gente já falou de cinco para
você ver como que eu sei que a coisa parece Ultra mega complexa mas
quando a gente vai ser parando assim num num método num num Framework
Zinho a coisa vai ficando mais fácil tá na parte de redes nós temos a
parte de parceiros e rede de display do Google a lógica é parceiros da
rede de pesquisa mantém rede de display tira por quê Porque vai
funcionar melhor Depois temos a parte de locais na parte de locais a
gente pode anunciar para todos os países e territórios pro Brasil ou eu
posso inserir um local num local eu posso inserir um um uma cidade uma
região ou um CEP então eu posso inserir por exemplo Paraná o estado do
Paraná inteiro incluir agora eu vou anunciar pro Paraná ou posso colocar
uma cidade por exemplo a cidade de Londrina Então vou colocar aqui
Londrina Paraná ó vou tirar aqui o estado ó Londrina Paraná posso
colocar um CEP quando você colocar o CEP São só os cinco primeiros
dígitos tá cuidado que tem um outro CEP igual aqui no Brasil e no
Arizona Então vou selecionar aqui o CEP do Paraná agora vou aparecer só
no Paraná e eu posso ir pra pesquisa avançada tá na pesquisa avançada
agora ele tá segmentando só o Sep que eu coloquei aqui no em Londrina ou
eu posso colocar um raio tá aí você vai mudar o raio aqui ó para 1 km
para quilômetro desculpa eu posso colocar aqui um raio de 1 km tá E aí
eu posso inserir um endereço um local coordenada ou eu clico aqui ó no
modo alfinete E aí eu vou colocar um alfinete em cima do meu endereço
Então vou dizer que eu tô aqui ó na rua eh sei lá aqui nessa rua aqui ó
nesse nessa ruazinha aqui é o meu negócio e você consegue navegar pelo
mapa então coloquei aqui ó vou incluir vamos dizer que eu vou anunciar 1
km na volta do meu do meu negócio tá então aqui ó vou meu negócio tá
aqui eu vou anunciar 1 qum na volta do meu negócio então tô anunciando
só um raio de 1 km na volta do meu negócio no meu caso o meu negócio é
no Brasil inteiro eu vendo pro Brasil inteiro Então vou colocar Brasil
feito na parte de ó eu tô eu tô fazendo e vou Minimizar porque vai ficar
mais mais clean na parte de idiomas você vai colocar sempre português
inglês e espanhol português Ué por que que não tá aparecendo inglês deve
tá english ó english vai acontecer e spanish espanhol tá espanhol Ah tá
bom inglês tá inglês agora espanhol não tá em espanhol não tá em inglês
então Português Inglês Espanhol minimiza seg mento de público alvo pode
ignorar essa parte por qu isso aqui não é o que mais vai fazer diferença
nos seus nos seus resultados aliás no começo não vai fazer diferença nos
seus resultados e agora vai só dar um nó na sua cabeça que não vale a
pena acredita em mim como seu professor palavras chaves de
correspondência Ampla desativado recursos automáticos desativado
minimiza minimiza mais configurações aqui a gente não vai mexer em nada
em rotação data de início e de término Quando que a minha campanha
começa quando que a minha campanha termina só mexer aqui no calendário e
selecionar Além disso outra configuração importante programação de
anúncios quais são os horários e os dias que os meus anúncios vão
aparecer ah meu anúncio vai aparecer segunda e feira de tal a tal
horário terça-feira de tal a tal horário quarta-feira de tal a tal
horário quinta-feira de tal a tal horário sexta-feira de tal a tal
horário vamos dizer que é só de segunda a sexta o meu no meu caso não É
segunda sexta sábado e domingo então vou colocar aqui todos os dias de
tal a tal horário meia-noite é meia-noite então é 24 horas por dia que
vai rolar feita essa configuração feito isso apertou em ó acabamos a
configuração da campanha olha que louco a gente configurou toda a parte
de redes locais que foi o que eu falei para você que dá para selecionar
país estado cidade CEP ou pin que é aquele modo alfinete depois idiomas
português inglês espanhol simples segmentos de público alvo no início
pode pular não vai mudar nada na sua vida palavras chaves de
correspondência Ampla e recursos automáticos desativado são aqueles dois
recursos aqui ó palavra-chave de correspondência Ampla desativado
recursos automáticos desativado pode desativar porque vai vai funcionar
melhor para você tá pode confiar em mim outras configurações o que que é
importante aqui data de início e de término e programação de anúncios
que dá a Quando que começa e quando que termina e que dias e horários os
meus anúncios vão rodar feito isso olha só a gente configurou toda a
campanha toda a parte da campanha tá configurada faltam só mais duas
configurações que são um pouco mais trabalhosas mas são só mais duas
vamos em frente Então como que a gente faz para configurar essas outras
configurações feito isso a gente configurou tudo aqui nós vamos apertar
em próxima apertei em próxima eu vou configurar agora minhas palavras
chaves e anúncios e agora eu tenho que te apresentar uma coisa que eu
chamo de a lógica do bolo de cenoura fofinho Vixe Pedro o que que é a
lógica do bolo de cenoura fofinho é o seguinte quando você vai no Google
e você pesquisa bolo de cenoura fofinho o que que vai aparecer para você
como resultado vai aparecer o quê bolo de cenoura fofinho é isso que
apareceu para mim como resultado quando eu entro no site do bolo de
cenoura fofinho o que que eu vou encontrar bolo de cenoura fofinho que
que eu quero dizer com isso para você eu quero dizer o seguinte que
aquilo que eu pesquisei então aquilo que eu pesquiso é o que aparece
como resultado da pesquisa e que também tá ligado ao site que apareceu
para mim quando a gente tá falando de anúncios online isso tem que
seguir a mesma lógica quando eu pesquiso curso de crochê o que que tem
que aparecer para mim curso de crochê quando eu ó eu pesquisei curso de
crochê e tá aparecendo por exemplo aula de crochê iniciantes Pode ser
que alguém clique aqui pode mas não tá tão bom quanto este primeiro
quanto este segundo que tá escrito curso de crochê então o que que eu
vou fazer e aí quando eu abro este link aqui tem que estar aparecendo o
que para mim tem que est aparecendo curso de crochê e aqui não tá
aparecendo aqui tá aparecendo Clube do crochê então o ideal é que
tivesse aparecendo para mim aqui o resultado da pesquisa e o site tudo
tem que estar conectado Ou seja a palavra-chave que a pessoa digitou tem
que aparecer no meu anúncio que tem que aparecer no meu site é isso se
eu consigo conectar esses três pontos eu tô seguindo a lógica do bolo de
cenoura fofinho se eu consigo seguir a lógica do bolo de cenoura fofinho
acabou zerei o jogo do tráfego no Google ADS simples assim eu sei que é
algo bobo mas a maioria das pessoas erra então o que que a gente tem que
fazer quando a gente vai anunciar no Google ADS uma das principais
coisas que a gente precisa fazer é selecionar muito bem para quais
palavras nós vamos aparecer ou aliás para quais conjuntos de palavra de
palavraschave eu vou aparecer e essa é uma pergunta que se você tem a
resposta Você domina o jogo do tráfego no Google então por exemplo a
pergunta que eu me faço aqui é que tipo de pesquisa a pessoa que quer
comprar o meu produto faz que tipo de pesquisa a pessoa que quer comprar
um curso de anúncios online faz talvez ela Pesquise por gestor de
tráfego talvez ela Pesquise por trabalho Home Office talvez ela Pesquise
por meta ads talvez ela Pesquise por Google ADS talvez ela pesquise por
anúncios online agora quando a pessoa digita o termo anúncios online o
ideal é que não apareça para ela um anúncio escrito trabalho Home Office
talvez ela se identifique mas o ideal é que quando a pessoa pesquise
anúncios online apareça para ela um anúncio escrito anúncios online Você
tá entendendo que eu tô querendo dizer então tudo tem que tá conectado
como que a gente vai fazer isso parte número um primeiro para Quais
quais conjuntos de palavra eu vou aparecer agora como que nós
selecionamos essas palavraschave você vai usar a sua cabeça seu cérebro
Mas você também pode usar ferramentas como o answer the Public vou
deixar o link dessa ferramenta aqui na descrição tá em que você vai vir
aqui por exemplo e colocar aqui Google Brasil português e aí eu vou
escrever aqui tráfego pago e aí eu vou pesquisar o que que essa
ferramenta vai encontrar para mim todas as pesquisas relacionadas a
tráfego pago tá ele vai aparecer nesse formato aqui esquisito de parece
uma Mandala né você pode mudar este formato para lista tá então muda ele
paraa lista aqui ó ao invés de botar Will você bota lista ou até o
tables eu gosto mais do tables do que do lista E aí ele vai me encontrar
vai encontrar para mim todas as perguntas que as pessoas fazem sobre
tráfego pago Então como tráfego pago funciona como trá como fazer
tráfego O que é tráfego o que que é tráfego no Instagram o que que é
tráfego pago e orgânico o que que é tráfego no Facebook é quem trabalha
com tráfego pago Aí depois ele vai encontrar os resultados de preposição
Olha que loucura a quantidade de pesquisas feitas com tráfego pago e
aqui eu tenho uma lista em ordem alfabética de tudo aquilo que as
pessoas pesquisam sobre tráfego pago tudo aquilo que é pesquisado sobre
o tema então uma ferramenta incrível que vai te dar muitas ideias tá
então você pode usar essa ferramenta agora eu vou deixar no link que tá
aqui na descrição nos links que estão aqui na descrição um tutorial de
como que você seleciona suas palavraschave é uma aula extensa onde eu
trago vários métodos que eu utilizo só pensando nas palavraschave é algo
tão importante que vale a pena ter uma aula só sobre isso tá então
basicamente aqui o que eu vou ter que definir é sobre quais palavras
chaves que eu vou focar Então vamos dizer que eu vou focar em palavras
chaves relacionadas a gestor de tráfego e Aqui começa o problema pô
começou o problema agora eu pensei que já tinha começado antes vem
comigo que eu te explico quando a gente tá falando de palavraschave nós
temos diferentes tipos de correspondência de palavra-chave Vixe Pedro
pera aí agora já não entendi mais nada o que que são correspondências de
palavra-chave é o seguinte eu posso segmentar as minhas palavras-chaves
de três maneiras eu posso escrevê-las assim ó curso de anúncios online
eu posso escrevê-las Assim entre aspas curso de anúncios online e eu
posso escrevê-las Assim entre colchetes curso de anúncio online Isso é a
mesma coisa não é por qu quando eu faço a palavra-chave sem aspas e sem
colchete Eu estou fazendo uma palavra-chave ampla Ou seja eu tô dizendo
pro Google Google eu quero aparecer pras pessoas que estão pesquisando
cursos de anúncios online e coisas semelhantes e aí o Google pode me
mostrar por exemplo isso é são um exemplo para todas essas palavras se
alguém Pesquisar curso de anúncios online Meu anúncio pode aparecer se
alguém Pesquisar curso de anúncios meu anúncio pode aparecer Como
aprender a anunciar online Meu anúncio pode aparecer porque tá as essas
palavras estão relacionadas a essa palavra aqui agora eu posso deixar um
pouco mais específico eu posso falar pro Google Google eu só quero
aparecer quando na pesquisa da pessoa presta atenção quando na pesquisa
da pessoa tiverem essas palavras nessa ordem curso de anúncios online
detalhe o Google não se importa com acentuação tá então você não tem que
ficar paranoico com a acentuação então por exemplo eu vou pegar e vou
coloquei entre aspas a minha palavra-chave Ele vai gerar para mim aqui
curso de anúncios online eu a pessoa pesquisou desculpa curso de
anúncios online Meu anúncio aparece para ela a pessoa pesquisou curso de
anúncios meu anúncio não vai aparecer para ela por quê Porque tem que
ter as palavras curso de anúncios online nesta ordem na pesquisa da
pessoa se a pessoa pesquisar como aprender a anunciar online não vai
aparecer agora a pessoa pesquisou comprar um curso de anúncios online eu
posso aparecer por quê Porque na pesquisa da pessoa tinha curso de
anúncios online tá vendo exata a pesquisa que tá aqui em cima a pessoa
pesquisou comprar um curso de anúncios online barato eu posso aparecer
porque na pesquisa da pessoa tinham essas palavras nessa ordem agora a
exata é a mais fácil de todas porque eu só vou aparecer na exata
palavra-chave que eu coloquei entre colchetes qualquer outra variação
com palavras antes depois antes e depois palavras diferentes eu não vou
aparecer tá então esses são os três tipos de correspondência Qual que é
a sugestão que eu dou para você no início Aposte Use e abuse de palavras
chaves frase e exata por quê Porque essas são as palavras chaves que
mais vão gerar resultado para você no início da sua jornada porque você
tá focando somente nos termos mais qualificados Isso é uma das coisas
mais importantes que você tem que fazer para anunciar no Google ADS tá
então é assim que você configura as suas correspondências falt um acento
aqui as suas correspondências de palavra-chave Então você vai escolher
mais uma vez diversos grupos de palavras que eu quero focar então eu
quero focar por exemplo em gor de tráfego aí eu vou colocar várias
palavras chaves que t a ver com o gestor de tráfego então eu posso
colocar aqui deixa eu dar um super zoom eu posso colocar aqui por
exemplo a própria palavra-chave gestor de tráfego mais uma vez não tenho
que me preocupar com a acentuação posso colocar ela entre colchetes
posso colocar é curso de gestão de tráfego posso colocar gestão de
tráfego E aí onde que eu vou ter essas ideias de palavras mais uma vez
temos um link na descrição onde eu explico todos os meus métodos de
encontrar palavraschave e você pode usar ferramentas como o answer the
Public para conseguir encontrar essas ideias o link também vai est na
descrição tá então eu vou colocar somente palavras-chaves relacionadas
ao termo gestor de tráfego eu não vou colocar aqui por exemplo meta ads
Google ADS Por que que eu não vou fazer isso porque se eu faço isso eu
perco a lógica do bolo de fofinho se eu fizer dessa maneira eu consigo
garantir que quando a pessoa pesquisar essas palavras o anúncio que vai
aparecer para ela contém a palavra-chave gestor de tráfego gestor de
tráfego gestão de tráfego etc Pedro Quantas palavras eu coloco não
existe uma regra para isso Tá Mas você pode colocar entre 15 20 palavras
chaves é um número médio de algo que eu sei que vai funcionar feito isso
a gente vai pra próxima etapa Olha que maravilhoso Então configuramos as
palavras-chaves terminei de configurar o meu conjunto de anúncio agora
eu vou configurar o meu anúncio na configuração do anúncio a gente vai
ter que definir qual que é nossa URL final para onde que eu vou enviar
as pessoas Então vamos dizer que eu vou enviar as pessoas aqui para essa
página Vou colocar aqui a minha URL final Então qual que é o site que a
pessoa vai cair depois disso eu tenho o caminho de exibição aqui então
aqui eu posso levar a pessoa para um site que fala de gestão não pode
ter ti de não Coube aqui o tráfego então eu vou botar só tráfego por
exemplo que que vai acontecer no meu no meu link vai ficar aqui ó
pedrosobral.com.br bar tráfego a pessoa não vai ser levada para essa
página aqui a pessoa vai ser levada pra página que eu coloquei aqui ó
URL final a pessoa vai cair nessa página pedrosobral.com.br bblog barra
lista de presença aqui é só o caminho de exibição isso aqui muda o meu
resultado Pedro não é mais para bonito do que qualquer outra coisa aí
títulos o que que eu vou fazer eu vou preencher todos os títulos
possíveis aqui do Google ADS para gerar o melhor anúncio possível quanto
mais títulos eu colocar melhor Pedro quanto mais títulos você colocar
melhor desde que eles sejam relacionados a gestor de tráfego pago tá a
gestor de tráfego aqui no meu caso né no seu caso você vai colocar o que
tem a ver com o seu conjunto de palavraschave tá então eu separei aqui
uma série de títulos só para eu conseguir subir o anúncio na sua frente
tá então eles não TM a ver com gestor de tráfego pago mas eu vou colocar
aqui então Pedro sobal tráfego pago e 100% Home Office fature com
tráfego pago sua renda extra com anúncios online trabalha online sem
aparecer Então essas palavras aqui na verdade estão mais relacionadas a
trabalhar online do que gestor de tráfego Vamos mudar só para ficar 100%
certo eu sou meio neurótico com isso então vou colocar aqui ó trabalhar
online vamos dizer que essa é a palavra que eu ia focar então eu vou
colocar aqui trabalho online e trabalho e trabalho Home Office como
trabalhar Home Office ganhar trabalhando online aí assim O ideal era eu
ter feito essa pesquisa antes através dos métodos que eu ensinei que eu
ensinei e ensino para você na aula que tá na descrição coloquei todas as
palavras chaves aqui agora sim você vai ver até que ele tá dando um tá
ficou verdinho aqui ó por quê Porque eu tô usando essas palavras chaves
no meu título O próprio Google tá dizendo isso para mim eu tenho que
incluir as minhas palavras-chave no meu título só que aí claro eu tenho
que dizer também o que que eu tô divulgando né ah eu tô divulgando aulas
ao vivos e gratuitas eu tô te ensinando como trabalhar de casa com
tráfego pago então eu tô falando de tráfego pago eu tô falando de eh
trabalhar em casa do seu computador trabalhar 100% Home Office Quem que
tá divulgando isso Qual que é o nome da sua marca é um curso que eu tô
divulgando eu vou colocar trabalhos sem pré-requisitos enfim eu vou
preencher aqui todos os os títulos possíveis por o Google ele vai
descobrir para mim Quais são os melhores títulos quais títulos funcionam
mais e eu posso até pedir mais ideias para ele aqui tá então ele vai me
dando aqui outras ideias de títulos para eu fazer mas o ideal que você
já se prepare previamente todos os títulos t no máximo 30 caracteres
depois eu vou colocar aqui quatro descrições tá então todas elas são
descrições que tem que ter um um que de fazer a pessoa ter uma ação
então descubra tudo sobre a gestão de tráfego e como fazer dela sua nova
profissão se cadastre seja avisado das melhores aulas do mercado sobre
gestão de tráfego e quer descobrir como trabalhar em casa com anúncio
online sem ter que aparecer e ser bem pago passo a passo para conquistar
um trabalho Home Office honesto em que você é bem remunerado tá então eu
vou colocar minhas descrições aqui com o k de persuasão vou colocar os
meus títulos e depois disso eu tenho a parte de recursos adicionais
então eu posso colocar uma imagem que vai complementar a minha campanha
tá então você se você não tem isso aqui não vai matar os seus resultados
mas é legal que você inclua elas tá Quais são os formatos principalmente
a imagem quadrada a imagem retangular deitada e a imagem retangular e em
pé a em pé a gente usa menos na verdade assim a quadrada e a retangular
são o ouro elas é que vão fazer o seu anúncio fica mais bonito e tem que
ser imagens que complementam Pedro eu não tenho imagem eu deixo de subir
o meu anúncio por isso não não deixa de subir o seu anúncio Por isso tá
isso aqui não é um fator determinante depois nome da empresa tá então
posso colocar aqui e Pedro Sobral E aí às vezes ele vai pedir para
aprovar o nome da minha empresa tá mas você pode fazer o teste aqui
depois logotipo da empresa No meu caso aqui tá uma fotinho Minho e da
Priscila mas pode ser o logo da sua empresa você sobe ele aqui o seu não
vai est com essas imagens aqui mas é só você apertar aqui em upload ó e
fazer o upload do computador subiu a imagem do logotipo da empresa temos
o site links que que são site links são sites extras ao seu anúncio
Então são sites que complementam o seu anúncio vou apertar aqui em Mais
e aí eu coloco aqui o texto do site link então por exemplo depoimentos
eh estudos de caso aí eu vou escrever aqui conheço os nossos estudos de
caso veja agora os nossos alunos e eu coloco o link do meu site que leva
pros estudos de caso então ele vai complementar aqui o meu anúncio ó tá
vendo que ficou aqui estudos de caso aí eu vou colocar o outro eh
Conheça o nosso Instagram no siga acho que não cabe no siga no Insta no
siga no Insta no siga no Insta cabe no siga no Insta então vai ficar
aqui ó estudo de caso no siga no Insta eu vou colocar aqui outras outras
sites que complementam o meu anúncio isso tem uma tendência a deixar é o
nosso anúncio mais rico coloquei o site links depois no final nós temos
mais tipos de recursos aí vai depender de cada negócio mas eu posso
adicionar promoções se eu tô rodando alguma promoção posso colocar preço
se eu tô divulgando alguma coisa que tem preço posso colocar o meu
número de telefone pra pessoa clicar no meu anúncio e me ligar posso
colocar mensagem para quê pra pessoa me chamar no WhatsApp tá então isso
aqui para negócio local Puts é muito bom então você vai colocar aqui o
país Brasil você vai selecionar na o número de WhatsApp e uma mensagem
inicial Tá então Posso começar uma entrega e olha como é que fica no
anúncio aqui como é que fica bonito envio uma mensagem pelo WhatsApp tá
então fica super bonito frases de destaque São frases que complementam o
seu anúncio então é tráfego pago aprenda anúncios online no meu caso
aqui né você vai colocar as suas É só colocar pequenas frases ó então no
meu aqui tem vários que eu já utilizei então aulas ao vivo e tem umas
aqui que eu que eu uso de exemplo aula sobre tráfego eh sofá cheiro não
esquece e-book gratuito Pedro Sobral subido tem 1 milhão de palavras que
eu já utilizei aqui em outros exemplos Mas elas são palavras-chaves que
complementam e frases que complementam o seu anúncio snippets
estruturados é quando você tá vendendo eh um deter aqui tem várias
opções eu posso escolher eh complementar o meu anúncio com o que que tem
nos arredores eu posso escolher cobertura de seguro comodidades aí vai
depender muito do tipo de negócio que eu tô divulgando então comodidade
por exemplo dispensa piscina restaurante isso daqui vai servir mais para
hotel ou para alguém que tá vendendo uma casa é cursos se eu vendo
vários cursos eu posso colocar aqui destinos se eu tô numa agência de
viagens e estilos então isso são pontos muito específicos por isso que
eu não vou preencher aqui pro meu caso não faz sentido formulário de
Lead não me preocuparia com isso agora e aplicativo também não feito
isso vou apertar em concluído apertei aqui em concluído E aí na verdade
eu falei que eram 13 Passos tem um último passo tá um passo importante
então fiz aqui o meu grupo de palavras chaves com as palavras sobre
trabalhar online o meu anúncio Todo sobre trabalhar online vou apertar
em próxima apertei em próxima tenho que Definir meu último passo Agora
sim putz meu Google quer que eu dê o meu o acesso foi Não não não foi
bloqueado eu preciso confirmar a minha identidade Será que se eu apertar
Cancelar vai dar merda não deu tudo bem eu vou colocar aqui o meu
orçamento que é o quanto que eu quero gastar por dia e ele vai até me
dar uma previsão das minhas conversões não é certeza que eu vou alcançar
isso daqui mas é uma previsão eu posso selecionar o que Ele me
recomendou ou definir um orçamento personalizado do quanto eu quiser eu
posso colocar r$ 3 mas presta atenção se eu tô colocando aqui um uma um
custo por conv são de R 30 tenta investir pelo menos os seus r$ 3 agora
quanto mais eu aumento aqui olha o que acontece o meu custo semanal
aumenta mas o meu custo por conversão ele também aumenta então ó com 50
conversões eu tô fazendo 17 conversões semanais Aliás com r$ 50 eu tô
fazendo 17 conversões semanais se eu aumentar para 500 olha que louco eu
vou para 27 mas o meu custo foi para 30 tá então eu vou selecionar um
orçamento aqui que caiba no meu bolso por exemplo r$ 0 por dia eu gosto
de dizer que aqui você tem que investir um valor que se tudo der errado
Amanhã você tem mais para investir selecionei meu orçamento vou apertar
em próxima E aí ele vai passar pela revisão de campanha por mim então
ele vai verificar eventuais erros que eu deixei ao longo do caminho se
você seguir o passo a passo aqui não vai ter nenhum erro e aí você vai
partir depois pra parte de publicação da campanha tá o meu ele vai ficar
verificando os erros infinitos porque ele apareceu aquela mensagem para
mim de verificar minha identidade que é só basicamente eu colocar minha
senha de novo aqui do Google ADS tá acho que é porque eu tava muito
tempo com essa tela aberta planejando a aula e aí acabou dando isso mas
no seu caso pode ficar tranquilo não vai aparecer isso depois que você
fez isso vai ter um botão aqui embaixo azulzinho de publicar essa
campanha eu vou atualizar essa tela quer ver que eu vou perder a criação
da minha campanha isso é Google ADS minha gente tá não não perdi aí deu
certo Deu certo tá então fiz tudo bonitinho vou colocar o orçamento da
minha a campanha ah não mas ele Zerou aqui tá então ele Zerou minhas
palavraschave ele fez eu eu perdi o meu o trabalho que eu fiz aqui tá
mas no final das contas depois que ele fizer a revisão para mim deixa eu
atualizar mais uma vez ele vai aparecer aqui para mim como eu falei ó o
botão de publicar campanha ou aqui embaixo o botão de publicar campanha
clicou em publicar sua campanha vai ser publicada tá então deixa eu
salvar para depois eu não vou usar essa campanha aqui agora depois que a
sua campanha tiver publicada ela vai estar disponível para você aqui
deixa eu só fazer um filtro para ficar mais fácil ela vai estar
disponível para você aqui nas suas campanhas tá então você vai perceber
por exemplo que eu tenho aqui ó em nas minhas campanhas algumas
campanhas da rede de pesquisa tá que já foram criadas a sua vai estar
aqui aparecendo quando você entrar nela vai ter aqui o seu grupo de
anúncio criado Como é o meu caso aqui então essa daqui é uma campanha
que eu tenho o quê diversos grupos de anúncio ou seja diversos grupos de
palavra-chave aí como que funciona aqui olha olha que legal se você
olhar aqui um grupo de anúncio por exemplo tiktok ads se você clicar
nele aqui ó tiktok ads quais palavras-chaves tem aqui marketing digital
tiktok tudo sobre tiktok ads anúncios tiktok como mexer no tiktok ads
fazer tiktok ads tiktok digital marketing então palavras que eu sei que
estão gerando tração para tiktok ads como que eu encontrei essas
palavras com o método com o link que tá na descrição aí quando eu for
olhar o anúncio os anúncios os anúncios também são relacionados a tiktok
ads neste grupo de anúncios se eu voltar aqui se eu voltar aqui nos meus
grupos de anúncio eu vou ter aqui Google ADS meta ads gestor de tráfego
se eu abrir o grupo de anúncio gestor de tráfego as palavras chave são
todas relacionadas a gestor de tráfego a gestão de tráfego se eu abrir
os anúncios os anúncios estão relacionados ao quê que virar gestor de
tráfego aprenda tráfego pago o que que é gestor de tráfego o que que um
gestor de tráfego faz fature como gestor de tráfego gestor de tráfego na
prática e mais 12 outros títulos aqui ó só por curiosidade ó tudo sobre
gestor de tráfego vivendo como gestor de tráfego torne-se um gestor de
tráfego aulas a 300 semanas as quatro descrições duas imagens o nome da
empresa ó eu nem tô rodando o logotipo aqui o meu site link tá escrito
quer aprender tráfego e dos outros os tipos de recursos eu tô utilizando
só o frases de o sniped estruturado tá então são esses esse único que eu
tô utilizando exatamente como eu ensinei para você o mesmo método que é
o método do bolo de cenoura fofinho e aí quer saber se a campanha tá
funcionando Putz eu mostro para você aqui ó essa campanha se eu pegar um
todo período aqui olha só quanto que ela já gastou de dinheiro aqui ó só
essa campanha tá R 316.000 com uma com uma um número de conversões de
126.000 conversões com custo por conversão de 250 ou seja é uma campanha
que tá funcionando e ela segue exatamente o que eu te ensinei não tem
mistério eu sei que parece simples demais ele passa rápido demais é
muito simples mas é exatamente desse simples que você precisa para ter
resultado fechou agora o que que você não pode esquecer você não pode
esquecer que na descrição desse vídeo tem links de aulas complementares
para complementar o que você aprendeu aqui e tem o link para você baixar
o material PDF que te ensina o passo a passo para criar sua conta de
anúncios Tá bom então tamo junto essa aula de hoje como não é ao vivo
não vou fazer a palavra chave da aula tá porque eu não consigo
configurar a palavra-chave da aula Se eu não tô ao vivo mas na próxima
terça não sei quando você tá assistindo esse conteúdo mas na próxima
terça-feira 3 horas da tarde você pode ter certeza que eu estou ao vivo
aqui no nosso canal do YouTube Não esquece de curtir esse vídeo se
inscrever no canal e a gente se vê na próxima terça-feira às 3 horas da
tarde valeu

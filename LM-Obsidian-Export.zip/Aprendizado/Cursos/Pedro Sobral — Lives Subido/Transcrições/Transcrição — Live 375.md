---
tipo: transcrição
live: 375
tema: Como criar campanhas de WhatsApp para negócios locais
status: completa
tags: [transcrição, sobral]
---

# Transcrição — Live #375

> Como criar campanhas de WhatsApp para negócios locais

Resumo e aplicação: [[Live 375 — Campanhas de WhatsApp para negócios locais]]

---

Live número 375, como criar campanhas para o seu WhatsApp. Até o final
dessa aula aqui, você vai dominar primeiro a criação de campanha passo a
passo dentro do Metaads para você lotar o WhatsApp de qualquer pessoa
com mensagens qualificadas. Segundo, eu vou te explicar tudo sobre como
que você faz um bom atendimento no WhatsApp, porque ao criar a campanha,
você vai entender que o grande segredo não tá nos botões do gerenciador,
mas sim no que que acontece depois que a pessoa clicou no anúncio e vai
até o WhatsApp. Se você não atua ainda como gestor de tráfego pago, você
vai ao longo da sua carreira perceber algo assim, eh, de maneira
consistente, que é você gerando leads, você gerando contatos para o
WhatsApp dos seus clientes e eles reclamando que esses contatos não
estão qualificados. Se você é dono de negócio, você também vai ver algo
constante, que é você gastando dinheiro em anúncios online e os leads,
os contatos que chegam não são qualificados. Agora, os contatos são ou
não são qualificados? O lead é ou o lead não é qualificado? Existe uma
pontinha de verdade para quem diz que é. E existe uma pontinha de
verdade também para quem diz que não é. Mas fica tranquilo que nessa
aula aqui a gente vai explorar isso daqui juntos. Eu vou te ensinar como
é que você faz para verificar se o atendimento tá sendo um bom
atendimento, se a culpa é do tráfego pago, se a culpa é do atendente, do
comercial que tá recebendo os leads. E além disso, até o final dessa
aula aqui, você vai entender tudo sobre como que você faz o processo que
nós chamamos de cliente oculto. E como ter um processo de cliente
oculto. você vai entender um pouquinho mais o que que é isso, mas como
que ter um processo de cliente oculto vai te ajudar a fechar mais
clientes de tráfego pago, reter seus clientes de tráfego pago e para
você que é dono de negócio ter resultados ainda melhores através das
suas campanhas de anúncios online. Pois bem, então bem-vindos,
bem-vindos à nossa live número 375. Sim, nós estamos a 375 semanas,
todas as terças-feiras às 3 horas da tarde, fazendo aulas ao vivo aqui
no meu canal do YouTube. Ah, Pedro, mas eu entrei aqui no seu canal do
YouTube, eu não encontrei 375 lives. Eu sei, porque nós seguimos aqui no
meu canal do YouTube um tipo de conteúdo que eu chamo de conteúdo
perecível. O que que é o conteúdo perecível? Toda terça-feira, 3 horas
da tarde tem uma live. Terça-feira da semana seguinte, eu tiro a live da
semana anterior do ar e você vai ter acesso sempre à aula durante 7
dias. Ah, então se eu tivesse aqui, eu poderia ter assistido as aulas
desde o começo. Sim, você poderia ter visto todas as aulas. A, eu gosto
de falar, né, que quem tá aqui desde o começo das duas, uma, ou ficou
rico ou não trabalhou. Mas olha pela boa, olha pelo pelo lado bom, né? O
copo meio cheio. Você pode ficar comigo aqui nas próximas 375 semanas. E
dentro do meu canal do YouTube você encontra uma série de lives, tá? É
só acessar aqui a aba ao vivo. Você encontra aqui uma série de lives,
uma série de conteúdos onde eu te trago a base, né, os fundamentos e
muito conteúdo prático do que que você precisa para já começar a ganhar
dinheiro com tráfego pago. Eu sou uma pessoa que vendo cursos, né, eu
tenho meu minha eu tenho mais de umas. O principal é a comunidade de
subido de tráfego, que é a minha comunidade para gestores de tráfego.
Fica tranquilo, as inscrições não estão abertas. Não tô vendendo para
você agora. Se você tiver interesse em saber mais, tem o link da lista
de espera na descrição. Mas eu tô te falando isso por quê? Porque eu
digo que quanto mais pessoas aprendem tráfego pago sem comprar nada meu,
mais eu vendo meu curso de tráfego pago. Se você quer aprender a
anunciar na internet, se você quer e precisa da informação para anunciar
na internet e ganhar dinheiro com isso, o conteúdo tá disponível aqui
para você nesse canal ao vivo toda terça-feira, 3 horas da tarde. Mas
hoje tem uma coisa diferente das outras semanas. Hoje eu não estou ao
vivo de fato, Pedro. Parece que você tá ao vivo. Pois é, mas hoje eu não
tô ao vivo de fato. Hoje é no momento que você tá vendo essa live, é
terça-feira, é aniversário da minha esposa. E aí a gente tinha um
compromisso marcado e por causa do fuso horário acabou ficando bem no
horário da live. E aí, pô, o aniversário da minha esposa, né? Tenho que
comparecer. Afinal de contas, eu não quero dormir nesse sofá aqui do
hotel que tá atrás de mim. Nós estamos em viagem. A gente veio passar
uns dias aí, fizemos uma palestra em Cancum, depois fomos para Miami,
agora estamos aqui em Orlando, viemos aqui comemorar. E aí, hoje um dia
especial, eu não ia conseguir estar ao vivo aqui com você, mas estou
gravando essa aula no dia anterior, segunda-feira. Eu sempre me
comprometo de gravar a aula o mais próximo possível, pro conteúdo,
claro, estar 100% atualizado para você. Então, eu não tô ao vivo, mas
isso tem um lado bom. Tem um lado bom que quando eu tô ao vivo, eu me
distraio mais quando eu não tô. o conteúdo ele já vem mais direto. Pois
bem, vamos então ao nosso conteúdo da nossa live número 375. E a gente
já vai começar aqui, ó, no nosso passo número um, que é o passo a passo
para você criar as campanhas de mensagem, tá? Para você criar campanhas
de mensagem, você vai ter que acessar aqui o gerenciador de anúncios.
Tem o processo de você criar uma conta no gerenciador de anúncios caso
você ainda não tenha. Se você vai ser gestor de tráfego pago, você não
tem que ter a conta no gerenciador de anúncios. Quem tem que ter a conta
é o seu cliente e ele libera o acesso para você. Ah, Pedro, como que faz
isso? Como é que cria a conta de anúncio? Como é que o cliente libera o
acesso para mim? Eu que sou dono de negócio, como é que eu crio essa
conta? Na descrição desse vídeo, eu vou colocar o link de uma aula
extra, que é uma aula onde eu ensino a criar a conta de anúncio. Mas
você vai ver que é super simples, é igual configurar a conta no Gmail.
Tem algumas opções a mais ali. Eu guio você nesse vídeo. Vale a pena
você assistir para que você não eh ah não não erre, não cometa nenhum
errinho bobo ali durante o processo de criação da sua conta de anúncios.
E lá eu também ensino como é que você libera acesso para as pessoas.
Para você que é gestor de tráfego pago e não vai ser o dono da conta de
anúncio, quem vai ser o dono vai ser o seu cliente. É importante também
que você saiba fazer esse processo, porque você vai ter que saber
instruir o seu cliente para fazer essa criação, tá? Uma vez com acesso
aqui à conta de anúncios, a gente vai clicar neste botãozinho verde aqui
de criar campanha, tá? Para quem nunca teve contato com essa ferramenta,
eu sei que eu tô indo um pouquinho rápido aqui, mas a questão é essa
ferramenta aqui, ele vai é a ferramenta que nós vamos utilizar para que
os anúncios apareçam no Facebook, Instagram, stories, res, WhatsApp das
pessoas. Essa é a ferramenta que faz os anúncios aparecerem pras
pessoas. Essa interface aqui, né? Parece um painel de avião, mas eu
garanto para você que aos poucos ele vai ficando um pouquinho mais ah
mais confortável de você chegar aqui. Quando você chega a primeira vez é
desconfortável, mas com o passar do tempo você vai criando intimidade
com o gerenciador de anúncios. Beleza? Vamos apertar aqui no botão de
criar e a gente vai partir aqui pra escolha do objetivo da nossa
campanha. A meta nos oferece seis objetivos de campanha, sendo bem
prático com você aqui. Objetivo de reconhecimento, vamos utilizar quando
a gente quer aparecer pro maior número de pessoas possível ou aparecer
várias vezes paraas mesmas pessoas. A gente vai utilizar esse objetivo
de campanha. Então, quando eu quero aparecer muito, quando eu quero
martelar uma nova ideia na cabeça de uma audiência, eu vou utilizar esse
objetivo. Se eu tô anunciando para públicos muito pequenos e que tá
muito difícil de aparecer para eles com outros objetivos, claramente
você vai utilizar isso aqui no início da sua jornada como a primeira
campanha que você vai criar. Depois temos a campanha de tráfego. A
campanha de tráfego vai servir para enviar as pessoas para um
determinado link. Ah, então eu poderia utilizar campanha de tráfego para
enviar as pessoas pro WhatsApp. Sim, você poderia. Eu vou até falar
sobre isso já já aqui com você. Engamento. São as campanhas para fazer
as pessoas se envolverem com algum aplicativo ou publicação. Então, eu
vou fazer as pessoas engajarem com o meu vídeo, verem o meu vídeo até o
final. Eu vou fazer as pessoas engajarem com a minha publicação para
elas curtirem, comentarem, compartilharem. Eu vou fazer as pessoas
engajarem com o meu aplicativo de mensagens, WhatsApp, Direct,
Messenger. Então, vamos utilizar muito o objetivo de engajamento para
mensagem. Já vou dar o spoiler aqui. Ele é o que a gente mais vai
utilizar. Leads é quando eu quero fazer as pessoas se cadastrarem. Eu
quero as informações das pessoas, nome, e-mail, telefone e eu posso
pegar as informações dessas pessoas dentro do próprio Facebook,
Instagram ou então através do meu site. Promoção de aplicativo é para
promover aplicativo, vendas é para vender, só que eu posso vender dentro
do meu site ou através dos aplicativos de mensagem. Percebe o seguinte,
eu falei de WhatsApp, falei de aplicativo de mensagem em três tipos de
campanha: tráfego, engajamento, vendas. E esses são justamente os três
tipos de campanha que nós vamos utilizar aqui para criar as nossas
campanhas de mensagem. Quando que eu vou utilizar cada um deles? Vamos
lá. Engamento é a melhor opção no início. Por quê? Porque ele vai gerar
mais volume de mensagens. Eu vou ter mensagens por um custo mais barato.
Se eu gastar R$ 1.000 numa campanha de engajamento, R$ 1.000 numa
campanha de tráfego e R$ 1.000 numa campanha de vendas, eu tô botando R$
1.000 aqui, mas poderia ser 50. valor é hipotético. Se eu gastar R$
1.000 em cada uma dessas campanhas aqui, onde eu vou ter mais volume de
mensagens é no engajamento. Tráfego, que é o segunda opção aqui que a
gente tem para utilizar, na verdade é a primeira na ordem, né? Mas eu tô
colocando como segunda opção. Ele é uma opção que assim vale testar no
futuro depois que você já assim, pô, você tá gastando dinheiro, você tem
que encontrar. Testar é o quê? testar é você colocar um pouco de
dinheiro ali para ver no que vai dar, para ver se dá algum resultado.
Então assim, vale um teste no futuro, mas nunca ouvi falar de nossa,
usei a campanha de com objetivo de tráfego para mensagens e ela salvou
os meus resultados. Então assim, eu colocaria ela bem em terceiro plano
aqui, quase no tão pequenininho que não dá para ver, mas ele tá ali,
você sabe que um dia você pode testar. e vendas para uma página eh com
link. Você, eu botei, escrevi vendas para uma página com link, eu
escrevi errado, tá? Então, vendas, para vendas eu tenho uma maior
qualificação dos leads, mas eu tenho menos volume, tá? Então, eu tenho
esses dois tipos de campanha aqui, engajamento e vendas. Quando eu uso
vendas, eu vou ter menos pessoas mandando mensagem, mas a tendência,
presta atenção na palavra, vou até falar pertinho do meu microfone aqui,
a tendência é uma tendência, não é certeza. A tendência é que nós tem,
que a gente tenha, né? Que nós tenhamos, que tenhamos. A tendência é que
tenhamos, achei que ficou bonito isso, a tendência é que a gente tenha
leads mais qualificados. O que que são leads? Lead são os contatos que
eu tenha pessoas mais qualificadas me mandando mensagem no final das
contas. Beleza? Vamos selecionar o nosso objetivo. Qual que é a
diferença de selecionar engajamento ou vendas? Eu vou ter que são
campanhas completamente diferentes. Não, é tudo igual. A única diferença
é o objetivo. Mas se eu clicar em engajamento e clicar em vendas, todo o
processo a partir daqui é o mesmo. Então você já vai saber fazer os dois
tipos de campanhas. Então vamos lá. engajamento. Vou apertar aqui,
selecionei engajamento. Vou apertar em continuar. E ele vai carregar
aqui a parte de criação. Vai perguntar se eu quero uma campanha
personalizada ou manual. Se você sabe criar manual, você sabe criar
personalizada. Eu indico o quê? Para quem tá começando? Manual. Ah,
Pedro, e essa personalizada para que que ela serve? Pensa o seguinte, a
campanha personalizada é a meta, tomando mais controle da campanha por
você. Ah, isso é ruim? Não, de maneira nenhuma. É bom, mas isso aqui não
pode ser a sua única estratégia. No futuro, você pode ter duas
campanhas. Você pode ter uma campanha manual e uma personalizada. E aí
você vê que tá funcionando melhor. Eu acredito que se você seguir o que
eu vou te explicar nessa aula, a manual vai funcionar melhor para você.
Beleza? Então vou selecionar aqui campanha de engajamento manual, porque
se você sabe criar manual, você sabe criar personalizada. Selecionei a
manual, vou apertar em continuar. A a meta vai me perguntar o nome da
campanha que eu quero criar, tá? E aí o nome da campanha, eu sei que
parece algo bobo, mas eu sempre gosto de escrever organizadinho aqui
entre colchetes e já colocar aqui, por exemplo, o objetivo da minha
campanha. Então, vamos dizer que nessa campanha eu vou enviar as pessoas
para WhatsApp. E aí essa daqui ela é uma campanha de vendas do meu
delivery, tá? Então, do meu delivery XYZ. Então eu tenho aqui já uma
nomenclatura, um nome de campanha que deixa tudo mais organizado. Quando
eu bater o olho, eu vou saber o que que é essa campanha aqui. E eu sei
que parece perder tempo se preocupar com isso. Tem uma palavra que se
chama e eu acho que é taxonomia, mas é é como que a gente vai organizar
essas nomenclaturas das nossas campanhas. Isso daqui é um detalhe bobo,
mas que no médio e longo prazo deixa o seu trabalho mais organizado,
mais profissional. você consegue ler os dados com mais facilidade. Isso
daqui vai te auxiliar no futuro, no passo 2, 3, 4, do tráfego pago.
Beleza? Depois disso daqui, a gente já vai pra próxima. Você você vai
ver que a meta ela é muito intuitiva, tá? Que a gente vai sempre ir
rolando para baixo, selecionando a próxima opção. Vai rolando para
baixo, selecionando a próxima opção. Beleza? O que que eu tenho aqui?
Aqui eu tenho a parte de estratégias de orçamento. Parece um nome
difícil, né? Nossa, estratégias de orçamento. O que que são estratégias
de orçamento? A gente tem aqui dois tipos de orçamento. Temos o
orçamento da campanha. Deixa eu colocar aqui. Nós temos o orçamento.
Vixe, como é que eu faço agora para Ah, tudo bem. Nós temos o orçamento.
Não, não tá tudo bem não. Eu quero que esse negócio fique colado aqui.
Pera aí, deixa eu deixa de te arrumar aqui. Aqui é é ten um leve toque
aqui com a minha própria aula. Aí foi. Agora sim. Nós temos o orçamento
da campanha. E nós temos o orçamento do conjunto de anúncios, tá? Eu
adorei que a meta mudou. Esses nomes eles mudam sempre, mas é importante
que você conheça essas palavras, porque no futuro você vai ouvir eu
falando sobre isso, gestores de tráfego falando sobre isso, seu cliente
falando sobre isso. Orçamento da campanha, a gente chama ele de CBO.
Orçamento do conjunto de anúncios, a gente chama ele de ABO. Que que é
CBO? Campaign Budget optimization. ABO, Adset Budget Optimization,
otimização de orçamento de campanha, otimização de orçamento de conjunto
de anúncio, tá? O nome agora ficou mais simplificado, o que eu acho
excelente, tá? Então, nós temos esses dois tipos de orçamento. Orçamento
da campanha é o que você mais vai utilizar se você for fazer anúncios em
que você não tem problema de receber mensagens 24 horas por dia, tá? Por
quê? Porque quando eu seleciono o orçamento da campanha, normalmente,
desculpa, você vai se eu eu me confundi. Erro meu, erro acontece, né?
Melhores famílias. Orçamento da campanha, eu tava fazendo a explicação
já do do próximo passo aqui sem querer. O orçamento da campanha é o
orçamento que você mais vai utilizar na sua vida. Por quê? Porque
basicamente no orçamento da campanha eu tô dizendo pra Meta o seguinte:
Meta aqui tá o meu dinheiro, aqui tá o meu investimento, toma conta dele
para mim, gasta ele da melhor maneira possível. É isso. Orçamento do
conjunto de anúncio. Eu estou dizendo pra meta. Meta eu vou escolher em
que público que eu vou gastar o meu dinheiro. Vixe, Pedro, não entendi
nada. Deixa que eu te explico, vai ficar claro para você em um segundo.
Pensa o seguinte, quando eu vou anunciar na meta, eu tenho que criar uma
campanha. Quando eu crio a minha campanha, eu vou definir o meu
objetivo, tá? O meu por que eu vou anunciar. Então, o por que eu tô
anunciando, qual que é o meu objetivo? Além de definir o meu objetivo,
eu vou definir o quanto que eu vou gastar, que é o quanto de dinheiro
que eu que eu vou gastar aqui. Depois disso, eu vou criar dentro dessa
campanha os meus conjuntos de anúncio, tá? Então, o meu conjunto de
anúncio, eu vou botar aqui, ó, CA, conjunto de anúncio. Já vamos começar
a ter uma uma nomenclaturazinha melhor. O meu conjunto de anúncio, nele,
eu vou definir o meu para quem, para quem que eu vou aparecer. Só que
pensa o seguinte, na minha campanha, dentro dela, eu posso ter vários
conjuntos de anúncio. Então aqui eu posso ter um paraquen um, um
paraquen um paraquen três, um para quem quatro. Então, eu tenho uma
campanha que tem um objetivo, que é fazer as pessoas me enviarem
mensagens. E aqui dentro dela eu vou ter um público um, um público dois,
um público três, um público quatro. Quando eu seleciono o meu orçamento
da campanha, basicamente eu tô falando pra meta. Meta, bota R$ 50 aqui e
gasta esses R$ 50 entre esses públicos. Então, pode ser que a meta ela
gaste eh R$ 5 aqui. Aí ela vai lá e gastou R$ 25 aqui. Aí ela foi lá e
gastou R$ 0 aqui. E aí ela foi lá e gastou R$ 20 aqui. Então a meta ela
vai fazer essa distribuição do meu orçamento nos meus públicos diferent
nos meus diferentes públicos, buscando mais resultados para mim. Isso é
o orçamento de campanha. Agora, o que que é o orçamento de conjunto de
anúncio? Orçamento de conjunto de anúncio é quando eu digo pra meta,
meta, você não vai definir este quanto aqui para mim. Eu vou definir
aqui. Então eu vou dizer gasta R$ 10 aqui, gasta R$ 10 aqui, gasta R$ 10
aqui, gasta R$ 20 aqui. Então eu estou distribuindo o orçamento. Que que
eu recomendo para você? você que tá começando o orçamento da campanha,
porque vai funcionar melhor. Agora sim, a explicação que eu já estava me
adiantando anteriormente, não sei o que que aconteceu na minha cabeça.
Antes de começar a gravar essa aula, teve um mini terremoto aqui onde eu
tô. Nunca tinha passado por isso. Foi muito engraçado. Tudo ficava
tremendo um pouquinho assim, mas talvez tenha sido o terremoto. Vamos
voltar aqui agora. A gente tem, depois de selecionar o orçamento, a
estratégia de orçamento, a gente tem o tipo de orçamento. Nós temos
orçamento diário e orçamento total. Como eu te disse antes, orçamento
diário é quando nós vamos rodar uma campanha e eu não vou ter problema
de receber mensagem 24 horas por dia. Por quê? Porque ele vai rodar
diariamente, da meia-noite até a meia-noite. Então, madrugada eu vou est
recebendo mensagem. Então, aliás, da meia-noite até às 23:59, né?
Madrugada eu vou estar recebendo mensagem, 3 da manhã, 2 da manhã, minha
campanha vai estar rodando. Pedro, mas eu vou atender um negócio local.
Esse negócio ele só trabalha das 8 às 18. Ele trabalha num horário
específico. Ele vai, ele quer receber mensagens num horário específico.
Beleza? Aí nós vamos de orçamento total. Então orçamento diário é quando
eu quero aparecer 24 horas por dia. Orçamento total é quando eu não
quero aparecer 24 horas por dia. Simples assim, tá? Selecionei então o
meu orçamento total, que vamos usar esse exemplo aqui, porque o diário é
só selecionar e tá pronto. O total a gente tem mais uma seleção para
fazer. Então o total eu vou, vamos dizer aqui que eu quero gastar eh R$
50. E o total tem que escolher não quanto que você vai gastar por dia,
mas quanto que você vai gastar entre períodos. Então, ah, eu vou rodar
essa campanha aqui durante uma semana e eu vou gastar R$ 20 por dia
nela. Então vão ser R$ 20 por dia vezes uma semana, R$ 140. Então vou
colocar aqui o orçamento total de R$ 140. R$ 20 por dia, 7 dias, R$ 140.
Tá? Então eu vou colocar o o valor que eu quero gastar no período e aí
eu vou vir aqui embaixo e eu vou mudar essa opção aqui, ó, de
programação do conjunto de anúncio. Eu vou apertar em editar e vou
selecionar essa opção. Pronto. Feito isso, teste AB, categoria de
anúncio especial. Não vou mexer em nada disso. Que que eu acabei de
fazer? Eu acabei de fazer toda a parte de configuração da minha
campanha. Por quê? Porque eu já selecionei o meu porquê, o meu objetivo,
então por que eu tô anunciando. Eu já selecionei o quanto que eu quero
gastar e eu ativei a programação de de conjuntos de a programação de
orçamento, a programação de gasto. Toda a parte da configuração da
campanha, ela já foi feita. Agora nós vamos fazer o quê? Nós vamos fazer
a configuração do conjunto de anúncio e a configuração do anúncio. No
conjunto de anúncio, eu vou selecionar o meu para quem, então, para quem
que eu vou anunciar e vou selecionar o onde. Onde que eu vou aparecer?
Quero aparecer no Instagram, quero aparecer no Facebook, quero aparecer
e no WhatsApp, onde que eu quero que esse anúncio apareça pras pessoas.
A parte de campanha então, tá feita, tá? Agora a gente vai pra próxima
etapa. Próxima etapa, eu vou apertar aqui nesse botãozinho que tá aqui
de avançar esse botão azul. E aí eu vou pra parte do meu conjunto de
anúncios. E aqui eu tenho que definir para quem eu vou anunciar. Eu
sempre gosto de colocar no nome do meu conjunto de anúncio. Isso daqui
não interfere nos seus resultados, mas por uma questão de organização,
eu gosto de colocar algo que eu consiga bater o olho e saber que público
que é esse daqui. Então, por exemplo, vou colocar aqui pessoas que t de
25 até 45 anos, que estão a 1 km do meu negócio, tá? Então, uma pessoas
que estão num raio ali, numa região próxima do meu negócio. E aí eu vou
ter que definir aqui a conversão, que é o local da conversão. Pedro, que
que é esse negócio de conversão? Local da conversão. Isso aqui é
basicamente eu falar pra meta onde que eu tô buscando eh ter os meus
resultados, onde que eu tô buscando que os meus resultados aconteçam. E
aqui você vai selecionar, como já tá selecionado aqui, destino das
mensagens. Por quê? que eu quero que as o meu o meu resultado aconteça
nas nos aplicativos de mensagens. Você vai selecionar aqui sua página do
Facebook. Ah, como é que eu vou selecionar ela aqui? Isso aí vai ser
explicado na aula que tá na descrição, que é a aula de como que você
configura sua conta de anúncios. Beleza? Selecionei minha página do
Facebook, vai ter, vão ter aqui, ó, as opções de destinos de mensagens.
E aí eu já te levo pro passo número três dessa aula, que é: Pedro, uso
WhatsApp, direct ou Messenger? E a resposta é que depende muito do seu
público. WhatsApp ele é mais garantido, tá? Ele normalmente é onde você
vai ter mais resultado, é o que a maior parte dos negócios já utiliza, é
o que a maior parte dos donos de negócio vai solicitar para você, tá?
Agora, o Instagram ele funciona muito e se você quiser automatizar as
respostas, isso é muito fácil de você configurar com uma ferramenta, por
exemplo, chamada eh main Chat. E o Messenger é o que menos funciona até
hoje, que eu que eu vi funcionando até hoje e seria o último que eu
testaria. Via de regra, vamos de WhatsApp, tá? Por quê? Porque
configurar um é igual configurar o outro. Que que é o erro que as
pessoas cometem aqui? É falar assim: "Ah, eu quero receber mensagem no
Instagram e no WhatsApp. Aí vai dar ruim. Escolhe um, tá? E aí, como é
que você faz para conectar? Tudo que você vai fazer é apertar aqui em
conectar conta. Você vai selecionar o país, o número de telefone, você
vai receber um código lá no seu WhatsApp e ele vai configurar para você
bonitinho, tá? Então o meu aqui no caso tá o número do meu setor
comercial, não precisa mandar mensagem para eles. Esse aqui não é o meu
celular de verdade, tá? Então selecionou aqui o WhatsApp. Vamos pra
próxima etapa que é a gente pensar já. E aí aqui meta de de desempenho,
meta de custo por resultado, conjunto de regras, regras de valor, mais
opções. Pode ignorar tudo isso daqui, tá? Pode ignorar tudo isso daqui,
porque isso daqui não é, isso aqui são detalhes que para quem tá
começando vão fazer diferença nenhuma, nenhuma, nenhuma, nenhuma mesmo.
Esquece isso daqui. Agora vamos focar em fazer uma campanha que funciona
e que gera resultado. E aí a gente vai pra parte de custo e período de
exibição do anúncio. Na parte de custo e período de exibição do anúncio
é o quê? É a gente selecionar quando que a gente vai aparecer. Então a
meta já tá me dizendo aqui, ó. Você definiu o orçamento de campanha
Advantage Plus, total de R$ 140, tá? Então ele já tá a definição que a
gente fez anteriormente e ele vai me perguntar quando que a minha
campanha começa, quando que ela termina. Então, vou colocar aqui que ela
começa no dia 9 de março, termina no dia 23 de março. Coloquei aqui
então o período da minha campanha e aqui tá a programação. Lembra que eu
selecionei lá na criação da campanha essa opçãozinha aqui, ó, de definir
uma programação para os anúncios. Quando eu seleciono essa opção aqui,
vai aparecer essa seleção aqui para mim de horários, que é eu escolher
em quais dias e quais horários que eu quero aparecer. Então, se eu quero
aparecer de segunda a sábado, das 8 às 18, eu vou selecionar os
quadradinhos. É só você contar aqui os quadradinhos. Esse aqui é da
meia-noite a uma, da às duas, duas às 3, 3 às 4, 4 a 5, 5 a 6, 6 a 7, 7
a 8, 8 a 9. Então, das 8 às 18, eu vou rodar os meus anúncios aqui de
segunda a sábado. Vamos dizer que esse é meu horário de funcionamento.
Feito isso, nós vamos para a nossa quarta definição, que é para quais
públicos que você deve anunciar. E aí a resposta para você aqui é
extremamente simples. Dentro do meu canal do YouTube, eu tenho uma aula
onde eu falo sobre criação de públicos, tá? que é como que você vai
segmentar os seus anúncios, como é que você vai criar os seus públicos.
Na descrição desse vídeo, eu vou deixar o link dessa aula para você para
facilitar, mas é uma aula onde a gente aprofunda sobre esse assunto. Eu
te explico tudo sobre a criação dessas segmentações. Segmentação é
basicamente você escolher para quem você vai aparecer, mas via de regra,
negócios locais, você vai utilizar muito isso daqui, ó, geolocalização
mais demográfico, tá? E aí você vai sempre segmentar isso daqui quando
for necessário. Por quê? Que que eu quero dizer com isso? Ah, tô
anunciando para uma padaria em Londrina. Pô, você sempre vai segmentar
Londrina e a idade das pessoas que compram na sua padaria normalmente,
que é pode aí não pode não ter tanta e variabilidade assim, né? Pode não
variar tanto a idade das pessoas que compram numa padaria. Mas se eu
tenho um negócio que tem uma tendência de vender para pessoas mais
velhas, aí eu vou acabar utilizando sempre segmentações de idade, né?
demográfico de pessoas mais velhas. Se eu tenho um negócio que homens
consomem muito mais do que mulheres, eu sempre vou segmentar para
homens. Então, geolocalização e demográfico, ele é o básico do básico, é
o que garante que você tá aparecendo pras pessoas corretas. Tem muita
gente que fala assim: "Ah, Pedro, eu usei geolocalização e ele não gerou
resultado para mim. É porque eu tô aparecendo para pessoas de outras
cidades. O que que eu faço?" Nesse caso, existe uma opção que eu vou te
mostrar mais paraa frente, que é você escolher aparecer somente para
pessoas conectadas a Wi-Fi. E eu sei que isso parece bobo, mas quando eu
seleciono que eu quero aparecer numa cidade específica, por exemplo,
Londrina, e aí eu falo que eu só quero aparecer para quem tá conectado
ao Wi-Fi, dificilmente eu vou aparecer para uma pessoa que tá passando,
que tá viajando por Londrina e que não tá conectado num Wi-Fi, que tá de
passagem por lá ou que já esteve lá no passado. É algo que pode
funcionar legal para garantir que você tá aparecendo para quem tá lá.
Mas é só um detalhe, tá? Uma diquinha extra. Beleza? E aí nós temos dois
tipos de públicos. Temos o público frio e temos os públicos quentes, tá?
Sempre eu vou fazer essa divisão porque ela vai ser mais simples na sua
cabeça. Públicos frios, a gente sempre vai querer focar em semelhantes e
direcionamento detalhado. Semelhantes é o público que, como é que eu vou
te explicar o que que é um público semelhante? Eu sempre tenho um monte
de lápis para te explicar. Que que é isso? São joias da minha esposa.
Ótimo exemplo, tá? Então vamos lá. Vamos dizer que público semelhante ao
seguinte, eu chego pra meta e falo assim, meta, tá vendo esse público
aqui? Isso aqui é um público, tá? Público de pessoas que eh são meus
clientes, tá? Então eu mando pra Meta uma lista de e-mails ou uma lista
de telefones e falo assim: "Meta, esses daqui são todos os meus
clientes. Acha para mim pessoas semelhantes a esse daqui". E aí a meta
vai lá e vai achar puf um monte de gente, meu Deus, um monte de gente
semelhante a esse daqui, que são essas outras joias aqui. Então ele vai
achar para mim pessoas parecidas com esse público. Isso é um público
semelhante. Ah, como é que eu faço isso? Lá na minha aula sobre
segmentações, eu explico toda essa configuração para você. Ah, por que
que você não explica agora? Porque senão é tanto conhecimento, é tanto
conteúdo que a sua cabeça não consegue absorver. Então, vamos separar
elas em em partes porque vai ficar mais fácil. Então, aqui nós temos os
públicos semelhantes. E aí eu sempre digo para você que vai anunciar
para WhatsApp criar públicos de semelhante a listas de clientes,
semelhantes ao engajamento e semelhante à lista de quem já mandou
mensagem. Então, se eu tô buscando pessoas que vão me mandar mensagem,
vou anunciar para quem é semelhante a quem já me mandou mensagem. Gosto
de anunciar também para públicos de direcionamento detalhado, que eu
chamo de interesses mais óbvios. O que que são interesses mais óbvios?
Ah, então vou anunciar para uma barbearia, pô. Anuncia para quem tem
interesse em barba, cabelo, óbvio, sem ficar viajando muito na maionese.
E interesses de alta renda. O que que são interesses de alta renda? São
pessoas que têm um padrão de consumo mais alto, que tem mais dinheiro, a
tendência que eles tenham. Quais são esses interesses de alta renda?
Compradores envolvidos, viajantes internacionais frequentes, bens de
luxo e marcas menos mainstream. Então assim, não vai anunciar para Gut
Louis Vitton, porque todo mundo conhece Gut Louis Vitton, Rolex, todo
mundo conhece. Então, a pessoa que tem dinheiro, a pessoa que não tem
conhece essas marcas. Agora quando você coloca lá Patec Felipe, Zenha,
Estel Alder, Hermé, Duvo, Sefian, não sei como é que fala, Labotan,
Brunelo Cutinelli, que essas são marcas de grife menos conhecidas, tá?
Então são marcas de muito caras, mais caras até do que essas mais
mainstream, mas são marcas que poucas pessoas têm interesse, pessoas que
tem mais grana tem interesse, então você consegue aparecer pra galera
certa utilizando esse tipo de esse tipo de de interesse de alto padrão.
E aí nós temos os públicos quentes, tá? Públicos quentes são pessoas que
já tiveram contato com você. Então aqui a gente tem os públicos de
envolvimento, pessoas que já viram algum anúncio seu, visitantes do
site, lista de clientes, lista de leads e contatos. Então, pessoas que
estão na sua lista de WhatsApp, pessoas que estão na sua lista de eh de
atendimento. Uma dica aqui para você que é gestor de tráfego, dono de
negócio, uma estratégia que a gente sempre faz aqui com os novos
clientes que a gente fecha é clientes de negócios locais, é fazer o
seguinte. A gente pega esse cliente, aí eu falo para ele, ó, nós vamos
fazer uma estratégia de convidar as pessoas que estão no seu WhatsApp,
antigas, que não estão tendo mais contato com você, clientes antigos,
pessoas que já mandaram mensagem. E nós vamos mandar uma mensagem para
essa pessoa perguntando: "Oi, você gostaria de participar do nosso grupo
VIP da, sei lá, barbearia subido? Qual que é o benefício de você
participar do grupo VIP?" Ó, o benefício é o seguinte, você vai ter eh
acesso a descontos especiais, serviços que não estão disponíveis para
todo mundo na barbearia, eh bônus exclusivos, acesso a horários de
atendimento de maneira mais fácil, prioritária. Então você cria
benefícios pra pessoa fazer parte desse grupo VIP. Aí você convida todo
mundo, manda a mesma mensagem para todo mundo. Se a pessoa falar que
quer participar, você coloca ela num grupão de WhatsApp ali, no grupo
VIP. E aí, o que que é esse grupo? Esse é um grupo onde você vai
disparar a oferta. E aí, depois que eu crio esse grupo, eu já gosto de
fazer o disparo da primeira oferta. Então, em papo ali de uma semana, eu
crio o grupo, disparo a primeira oferta e faço um monte de venda para
todo mundo que já tava no WhatsApp do cliente, só que tava lá sem ter
nenhuma ativação. Isso é uma estratégia de ativação. Por que que eu tô
falando isso para você? Porque muitas vezes o gestor de tráfego novo
fica assim: "Putz, mas será que eu eu tenho medo de não gerar
resultado?" E às vezes com os ativos que o cliente já tem, você consegue
gerar resultado, tá? Eu me lembrei disso por causa da lista de contatos.
E além de fazer isso, você pode pegar todos os compradores antigos que
não compram há mais de 90 dias e disparar uma oferta específica. Daí
você vai no um a um e dispara uma oferta específica para cada uma dessas
pessoas, tá? Mas esses são os três tipos de públicos que a gente vai
utilizar aqui. Como que a gente vai configurar isso na prática? Aqui nós
temos os controles de público, tá? Nós temos controles de público,
público advantage. Nós vamos mudar para as opções originais de público.
Então vou clicar aqui em mudar para as opções originais de público. A
meta vai tentar me convencer de tudo que é jeito a não mudar, mas eu vou
limitar mais o alcance dos anúncios. Ah, limitar o alcance dos anúncios
parece algo na essência ruim, mas não é. Porque anunciar na internet não
é sobre aparecer para todo mundo, é sobre aparecer para as pessoas
certas. Então eu quero sem limitar o alcance dos anúncios. Isso quer
dizer que o Advantage Plus, que é a configuração atual, é ruim. Regras
de valor com Advantage Plus é ruim? Não. O que que é o Advantage Plus?
Eu tenho uma aula aqui no YouTube sobre isso também, mas eu tenho uma
aula no YouTube sobre basicamente tudo do tráfego pago. O Advent Plus
nada mais é do que eu estou dando controle pra meta decidir por mim.
Então, Advent Plus é a meta vai definir para mim a segmentação. Isso é
ruim? Não, mas quando eu tô falando de WhatsApp, quando eu tô falando de
anunciar para negócio local, limitar normalmente vai ser a melhor opção,
porque eu escolho onde eu quero aparecer, tá? Então vou selecionar aqui
limitar mais o alcance dos meus anúncios e vou continuar. E aí eu vou
pra parte aqui da configuração do meu público, tá? Então eu vou
selecionar aqui, ó, o meu público para o qual eu quero anunciar. Aqui eu
posso, por exemplo, anunciar pro público de quem me enviou mensagem no
meu Instagram nos últimos 30 dias. Eu posso anunciar para as pessoas que
se envolveram com o meu Instagram nos últimos três dias, eu posso
anunciar pro público de quem se envolveu com o meu Instagram nos últimos
365 dias. E aí você vai criar esse público, tá? Na minha aula de criação
de público, você vai ver que isso aqui é super simples, tá? Você vai
apertar aqui em criar novo, público personalizado ou semelhante, que é
aquele público que eu te falei. Clicou aqui em personalizado, eu posso
vir aqui em conta do Instagram. Aí eu posso pegar aqui a minha conta do
Instagram, ó. Deixa eu só, eu tenho muitas contas do Instagram. Deixa eu
pegar minha conta do Instagram. Aí eu vou pegar aqui, ó, pessoas que
seguiram essa conta do Instagram. Aí eu vou anunciar para quem me segue,
para quem me segue no Instagram. Só vou colocar o nome aqui, ó,
seguidores @pedros. Aí eu vou criar o público e vou anunciar para ele,
tá? Só que no caso aqui a gente não tá anunciando para um público
quente. Eu tô anunciando só para um público demográfico, pelo exemplo
que eu tô fazendo para você. Aí eu vou vir aqui nas localizações, tá?
Vamos dizer que eu tô anunciando na cidade de Londrina. Então eu vou
colocar aqui Londrina. Eu sempre uso esse exemplo porque eu já morei em
Londrina, no Paraná. Não sou de lá, mas já morei lá. E aí, presta
atenção. Tá vendo que ficou aqui, ó? O meu anúncio tá em Londrina, mas
ele também tá em várias cidades do lado. Eu tô aparecendo em Açaí,
Jataízinho, Ibiporã, Cambé, Rolândia, Arapongas. Eu tô aparecendo em um
monte de cidade fora de Londrina. Por quê? Porque eu tenho um raio de 40
km na volta da cidade de Londrina. Aí o que que eu vou fazer? Eu vou
selecionar apenas a cidade atual. Agora eu tô aparecendo somente na
cidade de Londrina, mas no caso eu não quero aparecer em Londrina. Eu
não quero anunciar em Londrina inteira. Eu quero anunciar em cima do meu
negócio, 1 km na volta do meu negócio. Vamos dizer que o meu negócio ele
está aqui, ó. Vou aqui, ó. Barbearia. Barbearia Prado, ó. Barbearia
Prado. Essa daqui é a minha barbearia. Tá aqui no centro, ó. Barberia
Prado. Que que eu vou fazer? Eu vou clicar aqui em adicionar pino e vou
colocar um pino em cima da da minha barbearia. Só que tá vendo que ficou
gigante de novo, ó? Voltei a aparecer aqui em Biporã, Londrina inteira.
Por quê? Porque o raio que tá na volta do meu negócio tá de 16 km. Você
vai clicar, vai arrastar. E agora eu tô anunciando 1 km na volta do meu
negócio. Vou selecionar a idade aqui que é de 25 até, opa, cliquei no
botão errado. De 25 até 45 anos. Gênero, vou selecionar aqui homens.
Vamos dizer que eu tô anunciando uma barbearia, né? Eu comecei o exemplo
falando que era delivery e virou barbearia. Mas é que eu achei a
barbearia Prado ali. Direcionamento detalhado. Isso daqui é o quê? é
onde você vai colocar aqueles interesses que eu falei para você. Então,
se eu quiser achar aqui o viajantes, ó, viajantes internacionais
frequentes, é aqui que eu vou selecionar. Minha sugestão, não seleciona
esse tipo de interesse quando você tá anunciando numa uma geolocalização
tão específica, ele pode acabar limitando os seus anúncios. Na verdade,
ele não vai limitar. Quando você seleciona o direcionamento detalhado,
isso daqui é um, vou abrir um parênteses intermediário barra avançado,
tá? Ao selecionar cuidado, ó, vou botar aqui, ó, cuidado. Ao selecionar
o direcionamento detalhado, direamento detalhado, você está
transformando o seu público de um público normal. para um público
advantage plus. Então, ao selecionar, presta atenção, ao selecionar um
direcionamento detalhado, qualquer um, qualquer um, eu estou dando
permissão pra meta anunciar não só para essas pessoas que estão na minha
segmentação, não só para quem tá 1 km na volta do meu negócio e tem de
25 a 45 anos e é homens, mas eu estou dando pra meta a opção de anunciar
para mais pessoas, para ela encontrar os melhores públicos para mim.
Então, selecionei aqui viajantes internacionais frequentes. A meta agora
ela vai se dar ao direito de buscar mais pessoas para mim. Tá escrito
aqui, ó, o direcionamento detalhado adventado. Isso significa que vamos
expandir o seu público para incluir mais pessoas além das seleções de
direcionamento. Quando isso tiver probabilidade de melhorar o
desempenho, essa opção é aplicada automaticamente com base no objetivo e
nas metas de conversão. Então, cuidado, quer dizer que não funciona?
Não, mas é um teste que você deve fazer de maneira separada, isolada.
Beleza? Feito isso, nós vamos pra parte de posicionamento, que é onde
que a gente vai aparecer pras pessoas. Na parte de posicionamento, você
tem aqui, ó, posicionamento advantage. Que que é o posicionamento
advantage? Advantage é meta toma conta para mim. Você vai escolher onde
que eu vou aparecer. Podemos deixar selecionado? Podemos. Quando que
você não vai deixar o orçamento adventa de selecionado? Quando você quer
aparecer para pessoas que têm maior poder aquisitivo, quando você quer
aparecer para quem tem maior poder aquisitivo, você vai apertar em
editar, você vai mudar para o posicionamento manual e você vai tirar
fora tudo que não é Instagram. Então você vai aparecer somente no
Instagram. Não vai aparecer em WhatsApp, não vai aparecer em Facebook,
somente no Instagram. Aqui você tem o poder aquisitivo mais alto. Pedro,
eu tô no início, eu não sei se eu quero aparecer para quem tem poder
aquisitivo mais alto. Eh, às vezes todo mundo acha que aparecer para
quem tem mais dinheiro vai vender mais. Não necessariamente. Então, para
quem tá começando, eu recomendo usar o posicionamento advantage. Putz,
tô com problema na qualidade dos leads. Os leads não estão chegando
legais. Ótimo. A gente a gente muda pro posicionamento manual, seleciona
somente o Instagram. Feito isso, vamos pra última etapa. Então, olha só,
eu já criei minha campanha e já criei o meu conjunto de anúncio. Já
defini aqui todo o meu para quem, todo o meu onde e aí eu vou pra última
etapa que é a criação do anúncio. Como que eu faço para criar o meu
anúncio? Vou vir aqui no gerenciador, aperto aqui no botãozinho azul de
avançar e eu vou pra parte de criar o meu anúncio. Vou colocar nome do
meu anúncio aqui, então vou chamar ele de anúncio 01, eh, barbearia. E
aí eu vou configurar o meu anúncio. Configurar o anúncio é extremamente
simples, é só seguir o passo a passo. Eu quero anunciar uma imagem ou um
vídeo ou um carrossel. Quero uma imagem ou um vídeo. Anúncios com vários
anunciantes. Pode deixar essa opção selecionada, ela não te atrapalha em
nada. Criativo do anúncio. Configurar o criativo. O que que é o
criativo? É a minha imagem ou o meu vídeo. Eu vou clicar aqui, seleciono
se é imagem ou se é vídeo. Vamos dizer que é um anúncio de imagem. E aí
eu vou selecionar aqui o meu anúncio, tá? Aí você já tem que ter a
imagem previamente criada para fazer a seleção dela aqui bonitinho,
deixar ela pronta aqui para você. Aqui você vai colocar eh o texto do
seu anúncio, tá? Não precisa viajar na maionese, não precisa fazer nada
muito eh complexo. Você vai colocar aqui o título do seu anúncio e essa
descrição você pode pular. Algo importante que você tem que fazer aqui é
legal você adicionar, desculpa, vários textos aqui para você, tá? Então,
adicione vários textos diferentes. Esse aqui vai ser o texto do seu
anúncio um. Esse daqui vai ser o dois. Esse aqui vai ser o três. Esse
aqui vai ser o quatro. Esse aqui vai ser o cinco. Por quê? A própria
meta vai descobrir o que que tá funcionando melhor pr você. Ela vai te
dar algumas sugestões feitas por IA aqui, tá? Mas acho que assim,
normalmente as acho, acho não, normalmente as pessoas que fazem os
próprios textos dos anúncios aqui, a descriçãozinha do anúncio, funciona
melhor, porque isso aqui não é o que, meu Deus, mudou os meus
resultados, tá? Tem gente que às vezes fica paranoica com isso, isso é
um detalhe. O mais importante mesmo é a imagem, é o vídeo. E você dá pra
meta variedade. Então dá pra meta cinco opções de título, cinco opções
de texto principal e ela vai brincar. Você não vai pagar mais caro por
isso, ela vai brincar, ela vai fazer diferentes combinações para
entender o que funciona melhor. Feito isso, vou apertar em avançar. Ele
vai me dar aqui a criação de imagens com IA. Então ele pegou a minha
imagem e criou várias imagens diferentes para mim. Se você gostou de
alguma, você pode selecionar e utilizar elas na sua campanha. Não tem
custo nenhum para você fazer essas imagens. A própria meta tá fazendo
para você. Um grande cuidado é o quê? Dá uma boa lida no que tá escrito,
tá? Às vezes ela erra muito essa questão de texto, mas ó, cada vez
melhores anúncios sendo feitos aqui, tá? Então eu joguei uma imagem e a
meta ela criou para mim essas diferentes variações. Ela percebeu que era
um no meu no meu anúncio tinha um pergaminho, uma corrente, um cadeado,
o texto que tava escrito no meu anúncio. E ela já criou para mim aqui.
Tem umas que estão bem ruins, tá? Mas tem umas que estão bem boas. Essa
aqui eu achei bem boa. É, essa daqui eu achei bem boa, que tá nessa cor
mais clarinha. Essa daqui também tá muito legal. Todas essas todas
assim, não, mas várias dessas imagens eu acho que tão boas para serem
testadas. Avalie o que que faz sentido para você, o que que não faz
sentido para você. Feito isso, vou apertar em avançar. Ele vai me pedir
aqui aprimoramentos, tá? Eu não gosto de de ativar esses aprimoramentos,
então eu sempre desativo todos eles, tá? Sempre desativo todos eles. Por
quê? Porque eles, para mim, eles deixam o meu anúncio pior do que melhor
e eles não trazem mais resultado. Disselei os aprimoramentos, vou
apertar em continuar e aqui tá criado o meu anúncio, tá? Tá quase tudo
pronto aqui. A chamada para ação já tá enviar mensagem pro WhatsApp.
Você vai manter essa chamada aqui, enviar mensagem pro WhatsApp. E aí a
gente vai pra parte de configurador de conversa. Que que é o
configurador de conversa? Aqui você vai fazer um modelinho de conversa.
Que que é o modelinho de conversa? A pessoa clicou no botão de WhatsApp
no seu anúncio, vai automaticamente, quando ela clicar nesse botão,
abrir o WhatsApp na frente da pessoa e dentro do WhatsApp vai aparecer
isso daqui, ó. Oi, como podemos ajudar? anúncio, ver detalhes. Então
isso daqui vem automaticamente quando a pessoa clicou no seu anúncio. E
aí você pode mudar isso daqui. Oi, somos eh a barbearia do do prado.
Gostaria de agendar seu horário? E aí você pode colocar mensagem pronta
ou perguntas frequentes, tá? Perguntas frequentes, eu colocaria assim,
só se tivesse duas, no máximo três perguntas que todo mundo faz e você
tá chamando as pessoas pro seu WhatsApp para responder aquelas
perguntas. Normalmente eu não gosto de ir por aí, eu gosto de ir na
mensagem pronta. E aí eu colocaria aqui: "Oi, eh, vi o anúncio de vocês
e gostaria de agendar um horário." Aí você coloca o nome do modelo aqui,
ó, modelo barbearia prado 1 e aperta em salvar. Apertou em salvar, agora
sim tá tudo pronto aqui dentro da minha campanha. Ah, e essa pontuação
da minha campanha aqui que tá em 78, eu sei que isso incomoda, mas isso
é porque a gente não selecionou alguns recursos advantage durante o
processo de criação, tá? Então, como a gente não selecionou, ele fica
com essa pontuação de 78 aqui. Que que eu faço para publicar minha
campanha? Eu vou apertar em conferir e publicar para minha campanha
aparecer pras pessoas. O que que eu preciso que você saiba aqui nesse
processo de criação do anúncio? Eu preciso que você saiba criar anúncios
que vão gerar boas mensagens. Para você criar anúncios que vão gerar
boas mensagens, minha principal sugestão para você é: vem aqui no meu
canal. Eu vou deixar na descrição desse vídeo, na verdade, o link dessa
aula aqui, que ela não vai estar disponível mais abertamente, mas ela
vai est no link aqui embaixo, que é a aula de copywriting para gestores
de tráfego. Nessa aula, eu falo tudo sobre como que você cria um bom
anúncio. Não é você que tem que criar a imagem, não é você que tem que
gravar o vídeo se você é gestor de tráfego, mas essa aula aqui, ela vai
te dar o conhecimento necessário para você criar um bom anúncio. E aí lá
você vai entender o principal conceito de uma de um bom anúncio, que um
bom anúncio ele precisa ser um filtro pro público certo. E além de ser
um filtro pro público certo, ele tem que comunicar o que que acontece
depois que a pessoa clica no anúncio. Muita gente tem fala assim para
mim: "Ah, Pedro, eu tenho uma campanha de WhatsApp, ela tá com muitos
cliques, mas tem poucas pessoas chamando no WhatsApp". Isso acontece
muitas vezes por quê? Porque o seu anúncio não deixou claro o que que ia
acontecer depois que a pessoa clicasse no anúncio, tá? Então, como que
isso aqui vai ficar claro? Como que você vai fazer o o seu anúncio ser
um filtro do público, certo? Porque o maior problema, assim, número um,
disparado, maior problema de campanhas de WhatsApp é você fazer
campanhas que estão atraindo o público errado. E você não tá fazendo
isso porque você não tá colocando bons filtros na sua campanha. Quais
são os filtros que você coloca na sua campanha? Três. Objetivo,
segmentação e anúncio. Objetivo, eu tenho dois filtros aqui. Eu posso
selecionar engajamento em que eu vou ter mais pessoas. E aí,
provavelmente a tendência, lembra, a tendência é que elas sejam menos
qualificadas. Ou eu posso selecionar o objetivo de vendas e a tendência
é que elas sejam mais qualificadas, só que eu vou ter menos pessoas, eu
tô colocando um filtro maior. Segundo filtro, a segmentação. Para quem
que eu vou aparecer? Eu posso ir na segmentação e selecionar a
segmentação Advantage Plus e deixar a meta definir para mim, para quem
eu quero aparecer. Mas eu posso ir lá e limitar. Olha, eu quero aparecer
para pessoas de 25 a 45 anos. Eu quero aparecer para homens. Eu quero
aparecer para pessoas que estão a 1 km do meu negócio. Eu quero aparecer
só para quem tá conectado na Wi-Fi e só para quem usa o Instagram.
Então, tá vendo que eu tô colocando filtros e mais filtros e mais
filtros e mais filtros e mais filtros? Por quê? Eu tô buscando aparecer
pras pessoas corretas. Agora, você não pode exagerar na quantidade de
filtro, porque pode ser que você não apareça para quase ninguém e aí
você não tenha resultado. E o último filtro mais importante é o seu
anúncio. Tem uma frase de um cara que chama Jay Abraham que ele fala:
"Algumas vezes a melhor maneira de você vender um cavalo, a melhor a
melhor cópia, né, o melhor texto persuasivo para vender um para vender
um cavalo é dizer cavalo à venda". Então, às vezes a gente coloca muita
purpurina em cima de como é que faz um bom anúncio. Eu lembro que outro
dia até peguei o print aqui para te mostrar que uma pessoa me perguntou
no Instagram: "Ah, me dá uma ideia de anúncio para captar dentistas.
Como é que eu faço um anúncio eu, gestor de tráfego, para atrair
dentistas?" Aí eu falei para ele o seguinte: "Olha, faz um anúncio
assim, procura se dentistas que querem triplicar o número de clientes
particulares sem venda de curso, sem fórmula mágica, sem promessa
mirabolante, seguindo todas as normas do CFO, CFO, CRO. Então, eu falo
com dentistas, eu tô usando termos que os dentistas têm, tô falando de
dores que os dentistas têm, eu tô fazendo bons filtros aqui, tá? O que
que você precisa entender sobre esse anúncio que você vai aprofundar na
aula que tá na descrição? Você tem que entender que primeiro a frase em
destaque na imagem ou os primeiros 3 segundos do vídeo tem que falar
diretamente com o seu público, tem que chamar a atenção dele. Você vai
colocar no seu anúncio uma descrição simples com um título que fala em
poucas palavras o que você tá anunciando. Então, toda essa parte aqui
que as pessoas às vezes gastam um tempão pensando em, "Ah, como é que eu
faço um bom texto principal aqui pro meu anúncio, que é a descrição?
como é que eu faço um bom título pro meu anúncio? Você não tem que ficar
gastando muito tempo nisso. Faz algo simples que fala em poucas palavras
o que você tá anunciando e um CTA pra pessoa mandar mensagem. O que que
é CTA? É a chamada para ação. Por exemplo, você que tá vendo esse vídeo,
pô, como é que você tá vendo essa aula aqui e você ainda não apertou no
botão de curtir esse vídeo? Não tem sentido nenhum. Então assim, curte
esse vídeo aqui, por favor, se inscreve no canal. Isso é um CTA. Eu tô
pedindo para você fazer alguma coisa. Mas assim, você pode mesmo fazer,
eu vou ficar feliz, tá? Então você vai fazer o CTA que diz pra pessoa
mandar uma mensagem no final das contas. Então, ó, clica aqui nesse
anúncio, me manda uma mensagem, deixa isso escrito no texto do anúncio,
isso, deixa isso falado se o anúncio foro, porque isso faz com que seja
mais claro o que que vai acontecer depois que a pessoa clica no seu
anúncio, tá? Então, e mais uma vez essa parte de como você filtra bons
públicos no seu anúncio, tá? Uma aula sobre isso lá no lá na nossa aula
de copyright, literalmente, né? Uma aula na nossa aula, mas você tem um
baita conteúdo sobre isso na nossa aula de copywriting. Publiquei minha
campanha, Pedro. É isso, acabou, já era. Resultados para sempre. Agora
não, depois disso, você vai ter que olhar pros dados que a sua campanha
vai trazer para você. E quando eu falo olhar pros dados, as pessoas elas
trem. Meu Deus, dados, eu sempre fui ruim com números, eu sou uma pessoa
de humanas. Não seia com isso, porque tráfego pago não é sobre apertar
os botões das ferramentas, é sobre apertar os botões das pessoas que
estão do outro lado quando o seu anúncio aparecer para elas. Às vezes
alguém que é de humanas tem mais facilidade do que alguém que é de
exatas, mas não tem jeito, você vai ter que analisar alguns dados. Quais
dados a gente vai analisar aqui? Eu vou trazer para você um conhecimento
que assim, eu acho que 1% dos gestores de tráfego pago devem implementar
isso com seus clientes. E você tá tendo isso de graça aqui numa aula.
Então, tudo que você tem que fazer é implementar. Quando você tiver um
cliente, você vai analisar dois tipos de dados. Você vai analisar dados
no seu gerenciador de anúncios e você vai analisar dados no seu
aplicativo de mensagens. São os dois lugares que você vai analisar. Onde
que estão esses dados? No WhatsApp Business. Quase ninguém analisa isso
daqui. E aqui estão alguns dos dados mais importantes do negócio do seu
cliente ou do seu próprio negócio, se você for o cliente, o seu próprio
cliente. Eh, quais são os dados do gerenciador? número de conversas
iniciadas, custo por conversa iniciada, CTR, que é a taxa de clique no
seu anúncio. Isso aqui diz o quanto o quão atrativo tá o seu anúncio. E
CPM, quanto que custa pro seu anúncio aparecer 1000 vezes. Isso aqui tá
dizendo o quão caro ou quão barato está aparecer para aquela determinada
segmentação que você tá utilizando, tá? Simples assim. mede a atração do
seu anúncio, mede o quanto que custa para você aparecer e essas duas
aqui vão medir o custo que tá tendo por cada mensagem que você tá
gerando. Fora do gerenciador de anúncios, você vai pegar aqui métricas
de mensagens enviadas, mensagens entregues, mensagens lidas, mensagens
recebidas. Mensagens enviadas são quantas mensagens o seu cliente
enviou, mensagens entregues, quantas mensagens que o seu cliente enviou
chegaram no WhatsApp das pessoas. É o dois tracinhos lá, sabe, do do
WhatsApp. Quantas pessoas receberam aquela mensagem? Mensagens lidas,
quantas mensagens foram lidas pelos clientes? e mensagens recebidas, que
quantas mensagens o seu negócio está recebendo, o negócio do seu cliente
tá recebendo. Aí a gente pode calcular isso aqui. Você vai ter que
calcular algumas taxas, taxa de entrega de mensagem, que é quantos por
cagando estão sendo entregues. Taxa de leitura, quantos por cagam
entregues estão sendo lidas? e taxa de retorno, que é quantas mensagens
você tá recebendo de volta para as mensagens que foram lidas. Então,
para cada mensagem que foi lida, quantos quantos por cent de resposta
nessas mensagens? Isso daqui mede uma eficiência do WhatsApp que a maior
parte das pessoas não implementa. E aí você vai ter que, claro, não só
enviar e receber mensagens. O seu cliente não tem só que enviar e
receber mensagens. Pô, eu vou ter que tomar um gole d'água aqui que a
minha garganta secou, mas eu só tenho essa garrafa aqui que parece 1
litrão. Não vai ter jeito. Ai meu Deus, agora eu consigo dar mais 2
horas de aula, mas não vai durar isso. Eu tenho mais dois pontos só.
Além da gente analisar esses dados. Beleza, Pedro? Fui lá, analisei os
dados. Ótimo. Agora eu vou ter resultado? Não, porque ter resultado
depende muito do atendimento do seu cliente. E aí eu tenho 20 regrinhas
de ouro de um bom atendimento. São regras assim que normalmente se eu
vou trazer pro meu cliente, se eu vou analisar o atendimento do meu
cliente, eu vou utilizar isso daqui. Então, regra número um, seja
rápido. Quanto mais rápido você é para responder, maior a chance de
fechar o cliente. Se você manda uma, pensa em você, quando você manda
mensagem para um negócio, você fica esperando às vezes horas para aquele
negócio te responder? Não. Na maioria das vezes, se você mandou mensagem
e a pessoa já te respondeu, é ali que você vai já se engajar com aquilo
ali. Sua chance de comprar aumenta muito. Número dois, poupa o tempo do
cliente, tá? Não fica fazendo pingpong de mensagem. Então assim,
antecipa o que ele quer. Não tem nada pior do que você mandar mensagem
pro negócio. Eu lembro que uma vez, eu sempre conto essa história, eu
tava no Ceará, eu mandei mensagem para um negócio, eu falei assim: "Oi",
aí a pessoa para um delivery: "É, oi, tudo bem? Vocês estão abertos?" Aí
a pessoa me respondeu: "Oi, estamos". Aí eu falei assim: "Vocês estão
entregando a pessoa: "Estamos". Aí eu falei assim: "Vocês têm um
cardápio?" E a pessoa me respondeu: "Temos". Aí eu falei: "Poderia me
enviar?" E ela, "Posso?" Aí ela me enviou o cardápio. Então assim, tá
vendo que fica uma putz? Oi, vocês estão atendendo? Sim, estamos
atendendo. Segue o nosso cardápio, blá blá blá blá blá. Já manda pra
pessoa, antecipa. Se a pessoa tá perguntando se ela tá atendendo, ela
vai querer o cardápio, ela vai querer escolher, ela vai querer pedir,
ela vai querer saber já se pagamento pode ser no Pix, na maquininha, no
cartão. Quanto mais rápido você deixa pro cliente, maior é a chance dele
converter. Número três, gramática e ortografia em dia, tá? Então assim,
se precisar, usa o chatpt, tá? Evita escrever VC, PQ. Ah, mas eu acho
que fica descolado. Não fica. Fica feio, tá? Não fica profissional.
Número quatro. Faça um atendimento personalizado. Chama o cliente pelo
nome, lê o histórico das mensagens. Se você já atendeu aquela pessoa uma
vez, a sua obrigação é ter o nome daquela pessoa salva no seu no
celular, na ferramenta de atendimento que você tá utilizando. Então,
putz, eu mandei mensagem para um negócio que eu já mandei de novo, que
eu já fiz um pedido anterior e a pessoa me responde: "Oi, Pedro, tudo
bem? Você vai querer o mesmo pedido da última vez? Pô, aquilo ali já me
ganha. Uma vez que eu mandei mensagem, eu já sou cliente. Tem que ser
tratado diferente. Número cinco, conversa como se tivesse olhando no
olho do cliente usando a linguagem do público alvo, tá? Então assim,
você não precisa ser eh informal, mas você tem que entender com quem que
você tá conversando. Usa o princípio do espelhamento, tá? Então, entende
como é que o cliente se comunica e emula a comunicação dele, não sai
enviando um monte de figurinha pro cliente se o cliente não tá dando
essa abertura para você. Tem gente que é mais séria, tem gente que é
mais fria, tem gente que é mais quente, tem gente que é mais engraçada,
tem gente que é mais descolada. Você tem que mimicar esse tipo de
comunicação do cliente. Evita enviar áudio ou texto muito longo ou muito
áudio muito curto também. Pô, pessoa me mandou um áudio de 3 segundos,
eu falo: "Essa pessoa tá". Ela acha que o tempo dela é mais importante
do que o meu. Pô, um áudio de 3 segundos você não manda, você digita,
tá? Então, envia as mensagens cadenciadas. Não precisa mandar tudo num
blocão de texto. Por mais que você tenha todo o texto pronto, separa ele
em bloquinhos menores. Isso vai te ajudar muito. Número oito, usa os
recursos de edição das mensagens do WhatsApp. Coloca coloca itálico,
sublinhado para destacar aquilo que é importante. A maior parte das
pessoas não vai ler toda a sua mensagem. Ela vai só fazer um scan. Ela
vai só escanear toda a mensagem para ver o que que é mais importante e o
que tá destacado é o que vai se destacar. Número nove. Quando for enviar
o Pix, telefone ou endereço, envia uma mensagem com essa informação.
Então não envia assim, ó, Pix CPF dois pontos. E aí tu manda o número do
seu CPF aqui. Aí na aí embaixo tu manda em junto na mesma mensagem tu
manda endereço e o e o endereço rua blé blé blé bléu. Não faz isso.
Manda assim, ó. Pix dois pontos. Uma mensagem. Próxima mensagem. Vou
botar uma setinha aqui em cada mensagem, ó. Próxima mensagem. O número
do Pix. Endereço. Ai meu Deus, não consigo digitar. Endereço dois
pontos. Próxima mensagem. Rua blá blé blu blu. Sempre faz isso. Isso
ajuda muito as pessoas. Eu tenho um ódio mortal de quem manda o Pix
junto da outra mensagem. Não dá para copiar e colar. Ou a pessoa manda
uns pontos no CPF dela e eu não consigo copiar só um número, tá? Então
assim, deixa fácil pra pessoa. Sua vida é facilitar a vida do cliente.
Número 10, seja simples e claro. Então, dependendo do negócio, não
exagera nos nos termos técnicos. Número 11, não força a intimidade com
ninguém. Seja uma pessoa falando com uma pessoa, tá? Não, uma marca
falando com uma pessoa. Então, de preferência, opa, eu pulei o 12 aqui.
Então, aparentemente são 19, não são 20 regras de ouro. Seja uma pessoa
falando com uma pessoa e não uma marca falando com uma pessoa, tá? Então
assim, tem uma foto do atendente no perfil e não da marca. Número 14,
foca em resolver o problema do cliente. 15, esse é o mais importante.
Meu Deus, todo mundo erra nisso. Follow up do cliente que parou de
responder. Que que é follow up? O cliente parou de responder, você vai
lá e vai falar: "Opa, viu minha mensagem acima, tem mais alguma coisa
que você ficou com dúvida?" Follow up. Cara, eu sou péssimo de WhatsApp.
Eu sou o pior pessoa do mundo para responder WhatsApp, mas eu sou ruim
porque eu acho que as pessoas não fazem follow-up. Ah, então quer dizer
que as pessoas deveriam fazer follow-up? Na minha concepção? Sim, porque
se eu preciso da sua resposta, eu vou te encher o saco até você me
responder. Ah, mas quando é com você, você não quer. É, mas você eu sou
assim. Eu sei que a sua vida é corrida também. Às vezes você só não viu
a mensagem, você tava só ocupado, tava resolvendo um monte de pepino que
você tem para resolver. Mas eu tô precisando da resposta, eu vou atrás.
Ai, mas eu não quero parecer uma pessoa que é que tá precisando daquela
resposta. Mas não é que você tá parecendo, você precisa daquela
resposta, tá? Número 16. seja desenrolado na venda. E 17, configure as
mensagens automáticas do WhatsApp Business. É só você entrar em
configurações e ferramentas comerciais, tá? Então, configura as
mensagens lá de ausência, horário desse e aí você pode colocar e o
horário que aquela mensagem vai aparecer. Oi, não estamos, você já viu
isso com certeza em algum WhatsApp. Oi, não estamos atendendo nesse
horário. Nosso horário de atendimento é tal horário, é tal horário. Aí
você pode colocar o filtro, né, quem que recebe essa mensagem aí.
saudação, tá? Então, a saudação é uma mensagem automática que ela vai
ser enviada para quem entra em contato com você. E aí, lembra, ela é uma
continuação da conversa que você iniciou no anúncio. Então, ela tem que
dar continuidade ao que tá sendo falado no anúncio. Terceiro, respostas
rápidas. Pô, isso daqui, às vezes eu pego um negócio local, eu ensino o
dono do negócio a configurar isso daqui, a produtividade dele aumenta em
dois, três. Como que eu faço isso daqui? Lá no próprio WhatsApp eu
configuro respostas rápidas. Então eu digito barra agradecimento e
aparece pra pessoa. Agradecemos por utilizar os nossos serviços.
Esperamos trabalhar com você novamente em breve. Dados. Vou precisar dos
seguintes dados. Então, se eu sempre peço os mesmos dados pra pessoa, eu
já monto essa mensagem. Endereço. Nosso endereço é barrapix, número do
Pix. Aí você pode fazer vários. Cardápio, banco, produto, endereço,
e-mail. Já botei endereço duas vezes, tá? Então, configura essas
respostas automáticas, são até 50. Etiquetas, você pode adicionar uma
tag, né, um carimbo no no nas nos contatos. Então, etiqueta de novo
cliente, novo pedido, pagamento pendente, pago o pedido finalizado. No
começo isso aqui parece que não faz diferença nenhuma, mas quando vai
colocando volume, isso faz toda a diferença do mundo. Número 18, tenha
controle do funil para não perder os contatos antigos por falta de
respostas. Ou seja, CRM, tá? Um excelente CRM que você pode utilizar é o
como CRM, tá? Inclusive lá na comunidade, eu não sei se eu tô logado
aqui, tô tô logado. Lá na comunidade de subido de tráfego, se você é
aluno, tá? A gente tem nosso lá na na aba de cursos, dos vários cursos
que a gente tem, a gente tem o curso de habilidades complementares. Lá
no curso de habilidades complementares tem um curso inteiro de como CRM,
tá? São 51 aulas, é tudo sobre como CRM. Você vira um mestre de CRM com
esse curso aqui, tá? Então, CRM é o quê? Uma ferramenta que gerencia os
contatos dos clientes, gerencia e organiza. 19. Faz perguntas nas suas
mensagens para manter a conversa fluindo, sabe? Não seja aquela pessoa
que responde tudo com ponto final. E número 20. Agora, agora eu me
perdi. Eu pensei que eu tinha um item a menos. Eu acho que eu pulei um
item. É isso aí. Eu pulei o 13 porque o 13 dá azar. É isso. Então, vão
ser 20 sem o 13. E 20. Eu já falei sobre isso, mas eu reforço, faça
follow-ups. Faça follow-ups. Não fazer follow-ups é o maior motivo dos
clientes perderem as vendas. E aí, falando em clientes perderem as
vendas, eu trago para você aqui, pra gente encerrar essa aula, o seu
novo superper, que é fazer um cliente oculto. O que que é fazer um
cliente oculto? Cliente oculto é você fingir que você é cliente do seu
cliente. É você ser um espião no WhatsApp do seu cliente para ver o que
que ele tá fazendo de certo, para ver o que que ele tá fazendo de
errado. No passado, eu te explicaria aqui durante 20 minutos como é que
você faz um cliente oculto. Eu vou fazer diferente. Eu vou te entregar
esse material aqui, tá? que é o processo do cliente oculto, que é como
que você vai avaliar o atendimento e as vendas do seu cliente. Tá tudo
explicado aqui. Qualquer pessoa consegue implementar isso daqui, tá? E
aí não só eu vou te entregar o processo do cliente oculto, como eu vou
te entregar o processo de análise de conversas antigas do seu cliente.
Que que isso daqui vai fazer? Muitas vezes o cliente vai chegar para
você e vai falar assim: "Cara, meu, o tráfego eh o cliente chega assim:
"Ah, eu já contratei gestor de tráfego, mas os leads que chegavam eram
muito, muito desqualificados". Aí eu falo assim: "Pô, tudo bem, super
entendo, muitos gestores de tráfego não utilizam as melhores práticas do
mercado. A gente vai se esforçar o máximo aqui para te entregar tudo que
você precisa para você ter o maior número de leades qualificados
possível. Mas deixa eu te falar, você se importa de eu fazer uma análise
dos seus atendimentos do WhatsApp?" Aí o cliente normalmente ele vai
falar: "Não, que que você vai fazer? Você vai pegar, vai pedir para ele
o histórico dessas conversas e você vai fazer a análise dessas conversas
antigas e você vai encontrar um monte de problema lá. Você vai ver que a
pessoa não atende com profissionalismo, que ela não tem método para
conduzir a resposta, que ela não faz follow-up. Você vai ver que tem um
monte de erro daquilo que eu te falei das regras de ouro, das 20, que
são 19, que não estão sendo implementadas. E aí muitas vezes o cliente
fala assim: "Ai, o meu tráfego não converte. O gestor de tráfego não
sabe gerar leites qualificados para mim". Aí você vai ver a conversa e
você encontra tipo o Patrick Estrela na na na o Patrick no do Bob
Esponja atendendo lá no Ciric Cascudo que a pessoa liga pro Ciric
Cascudo, fala assim: "Oi, é do Ciric Cascudo". Ele fala: "Não, aqui é o
Patrick". E aí ele desliga. Aí a pessoa liga de novo. É do Ciric
Cascudo? Ele: "Não, aqui é o Patrick". que aí ele desliga, por ele tá
fazendo um péssimo atendimento. Só que se você não sabe avaliar o
atendimento do seu cliente, o culpado sempre vai ser o tráfego pago.
Então, o seu trabalho é também analisar o atendimento. Ah, e como é que
eu analiso o atendimento? Só seguir o material. Só seguir o material. Tá
bonitinho. Tá bonitinho. Eu redigi todo o material. Depois passei no
chatt para ele organizar e deixar lindão para você. Você tem até un
emojizinhos que ele colocou aqui, achei ótimo. Analisa isso daqui e ele
vai criar uma pontuação pro seu cliente e ele vai dar uma classificação
dando exemplos daquilo que tá bom, daquilo que não tá bom. É um
tutorialzinho completo e simples para você utilizar, para você fazer
esse processo de análise do seu cliente. Você pode analisar conversas
antigas, que para mim é o mais valioso de todos, se você já fechou o
cliente. Se você não fechou o cliente, isso daqui, ó, avaliar
atendimento e vendas dos outros é absurdo. Por quê? Porque muitas vezes
o gestor de tráfego pago, ele fecha o cliente não só falando de tráfego
pago, você vai fechar bons clientes, muitas vezes apontando coisas que o
gestor de tráfego atual dele não tá conseguindo ver. Então, fazer essa
análise de cliente oculto com o seu cliente, entregar pra pessoa na
maior boa vontade, não com um tom de olha só a merda que você está
fazendo no seu atendimento, mas cara, olha só, eu tomei a liberdade
aqui, eu fiz uma uma análise do seu atendimento no seu WhatsApp, dos
seus atendentes nas últimas duas semanas, eu encontrei vários pontos de
melhora. Tá bom? Tem um relatório aqui para você, se você quiser
utilizar, melhorar seu atendimento, tá? Aqui. Eu trabalho com anúncios
online e eu sei que os anúncios eles estão diretamente ligados ao tipo
de de lead que tá sendo trazido pro seu WhatsApp. Mas muitas vezes o
problema não é só o lead, a gente tem que acertar nas duas pontas. Eu
sei que você, como empresário, sabe quão desafiador é a gente ter um bom
time de marketing e um bom time comercial. Espero que esse material te
ajude. E se você tiver interesse da gente bater um papo sobre como que
eu poderia te ajudar a gerar melhores resultados nos seus anúncios,
segue aqui meu WhatsApp. Pô, acabou. Mensagem super profissional. Ah,
esse é um script que você tem pronto. Não, não é um script que eu tenho
pronto. Eu tô só me comunicando, falando a verdade, criando empatia, me
identificando com a pessoa que tá do outro lado, sem ser um com quem tá
lá. Tá, Pedro, como é que eu faço para receber esses dois materiais?
tanto processo de cliente oculto, avaliação do atendimento e vendas, que
é você sendo o Sherlock Homes do seu cliente, quanto o processo de
análise das conversas antigas, que é o cliente oculto retroativo.
Simples, você vai ir lá no meu Instagram e você vai me mandar uma
mensagem escrito Live 375, tá? Live 375. Então você vai vir aqui no meu
Instagram, que é o Instagram Pedro Sobral. Você vai apertar em aqui no
meu perfil, vai me enviar uma mensagem para receber estes dois
materiais. Um convite importante para você que tá começando, que tá
zerado aí, que tá tendo dificuldade para fechar os seus primeiros
clientes, ter resultado no universo dos anúncios online, da prestação de
serviço na internet. Quero te convidar para clicar no link que tá na
descrição deste vídeo. Você tá agora, ó, nesse vídeo aqui, no caso, se
você tá vendo esse? Eu não tô ao vivo, né? Porque eu já te expliquei
isso. Parece que eu tô ao vivo, mas eu não tô. E mas aqui na descrição
desse vídeo você tem o link da nossa live de aquecimento para do plano
para você fazer 5.000 por mês em 90 dias, tá? O que que é essa live de
aquecimento? Nós vamos fazer um desafio de 90 dias, tá? A gente, eu,
quando digo a gente sou eu e minha esposa, eu e a Pri, nós vamos fazer
um desafio de 90 dias, onde o objetivo é te tirar do zero e te levar até
os 5.000 por mês de faturamento recorrente. Sem promessa mágica, sem
números mirabolantes inalcançáveis só para você comprar um curso
aleatório. Não é um curso, não é uma mentoria, é um desafio prático, é
uma implementação guiada, onde você vai saber exatamente o que você tem
que fazer em cada um dos dias para você fechar R$ 5.000 R em contratos
recorrentes nos próximos 90 dias, de forma profissional, com trabalho em
que você gera resultado e que você ganha dinheiro. 90 dias é só isso que
você precisa. Como é que você faz para se cadastrar? Só clicar no link
da descrição, colocar seu nome, seu e-mail e fazer o seu cadastro. E a
palavra-chave da aula de hoje. Que que é a palavra-chave da aula de
hoje? Toda aula aqui, toda terça-feira, 3 horas da tarde, a gente tem
uma live e você tem aqui o link para você. A a lista de presenças agora
não tá disponível para mim, né? Porque eu tô um dia no passado. Mas aqui
a gente tem a lista de presença da live, que basicamente é o seguinte:
uma vez por mês, mais ou menos, a gente faz um sorteio aqui. E aí,
dependendo do número de aulas que você já assistiu, seus prêmios eles
são melhores ou piores. Então você pode ganhar até um computador ou uma
caneca, tá? Muita gente já ganhou caneca, já sorteei dois computadores
também. Como é que você faz para você preencher sua lista, a lista de
presença? Aqui do lado vai ter aqui o seu nome, eh, o local para você
colocar o seu nome, seu e-mail, WhatsApp e selecionar a palavra-chave da
aula de hoje, tá? Palavra-chave da aula de hoje é como é que escreve
Sherlock Holmes? Sherlock. Vai ser Sherlock a palavra de hoje, tá?
Então, palavra-chave de hoje, Sherlock. Mas se você, mais uma vez, se
você quer receber os materiais da aula de hoje, você vai lá no meu
Instagram e você vai me mandar uma mensagem. Não é para comentar nos
meus posts, é para mim mandar uma mensagem escrito live espaço 375, tá?
Então, exatamente como tá aqui na sua frente, me manda lá que eu mando
esses materiais para você, fechou? Estamos junto. E a gente se vê aí na
próxima terça-feira ao vivo na nossa Ah, não, na verdade a gente se vê
na próxima segunda-feira, porque próxima segunda-feira 8 horas da noite
é a nossa live de aquecimento do desafio de 90 dias, tá? Então, próxima
segunda-feira, 8 horas da noite, temos a nossa live aqui. Inclusive,
essa aula vai acabar, você vai ser direcionado para esse vídeo aqui. E
nesse vídeo aqui, você já clica aqui, ó, em receber notificação. Já
curte o vídeo aqui para não perder ele de jeito nenhum, tá bom? Então
vai lá, clica em receber a notificação, curte o vídeo para não perder
ele de item nenhum e a gente se vê na próxima segunda-feira, 8 horas da
noite.

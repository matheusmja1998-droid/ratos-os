---
tipo: aula
autor: Pedro Sobral
canal: Subido
numero: 373
tema: Copywriting para Gestores de Tráfego — Parte II (Páginas + Promessas)
status: completa
tags: [copywriting, copy, sobral, landing-page, lp, headline, garantia, prova-social, escassez, fac]
parte-de: [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]]
---

# Live #373 — Copywriting para Gestores de Tráfego: como criar bons anúncios (Parte II)

[[Pedro Sobral — Índice de Lives]]
[[Transcrição — Live 373]]
**Parte I**: [[Live 372 — Copywriting para Gestores de Tráfego (Parte I)]]

> Os 20 pilares de uma boa landing page + introdução ao pilar 5 (promessas).

---

## Big Idea

Landing page é a **2ª solução mais contratada** depois do tráfego pago. E é o **melhor gancho de venda** porque, ao contrário do gerenciador de anúncios, **a página do cliente é um recurso público** — você pode auditar sem precisar de acesso.

> "É mais fácil fechar cliente analisando a landing page dele do que tentando vender tráfego direto."

Com Lovable/Manus/Bolt criando páginas a partir de instrução, **não precisa saber design**. Precisa saber **o que escrever, quais seções colocar**. Pra mandar bem na IA, precisa ter inteligência natural.

---

## Status na carreira (3 fases mencionadas no início)

**Zerado** (nenhum cliente):
- Único foco: adquirir conhecimento pra vender com mais segurança
- **Você nunca vai se sentir 100% pronto.** Tudo bem.
- Receita: encontrar o problema → buscar a resposta (não acumular respostas antes). Mundo opera assim (estudar pra prova sem consulta), mas tráfego pago é o contrário.
- **Adquirir conhecimento + buscar cliente em paralelo.** Se hoje você só estudou, errou.

**Começando** (tem cliente):
- Vai notar que clientes têm outras necessidades (ex: Google Meu Negócio mal feito). Empilha habilidade ou terceiriza.
- A **2ª habilidade mais vendida depois de tráfego** = landing page.

**Escalando**:
- Já sabe vender LP, dashboards, automação. Aumenta ticket.

---

## PILAR 4 — LANDING PAGES (20 PILARES)

### Por que LP é o melhor gancho de venda

Cliente não te dá acesso ao gerenciador antes de fechar. Mas a página é pública. Você analisa, aponta problemas e fecha.

> "A IA não vai roubar trabalho de quem cria página. A IA vai dar mais poder pra quem sabe criar página. Você sabe quais são as principais seções de uma página boa? Não? Então como você vai pedir pra IA criar uma página boa?"

---

### 1. REFERÊNCIAS
Toda boa página começa de referência.

**Ferramenta**: extensão Chrome **Fire Shot** — tira print da página inteira em um clique. Salva no computador.

**Como construir banco**: vai atender dentista? Em 1 hora você salva 50 páginas de dentista pesquisando no Google. Aí seleciona as melhores. **Você não tropeça nas pedras grandes — você tropeça nas pequenas.**

### 2. OBJETIVO CLARO
"Pra quem não sabe onde tá indo, qualquer lugar serve."

**Página sem objetivo claro = lead caro.**

**Prioridade = UMA.** "Priori" vem de UM. Quem fala "minhas prioridades" tá errado.

Objetivos comuns: solicitar orçamento, agendar consulta, vender produto X, pedido no WhatsApp, agendar consultoria, cadastro em evento, baixar e-book.

### 3. PÚBLICO
"Quem quer falar com todo mundo não fala com ninguém."

A LP **continua a conversa do anúncio**. Se o anúncio tinha um fator de segmentação (crença, comportamento, plataforma, etc), a LP tem que continuar conversando com essa pessoa.

Você pode falar com mais de um público, mas a comunicação tem que ser clara (ex: Sobral fala com dono de negócio E com gestor de tráfego, mas é tudo "gestão de tráfego pago" no final).

### 4. HEADLINE
Primeira coisa escrita na página. **A pessoa decide se fica ou vai embora no primeiro segundo.** Ninguém lê a página toda pra depois decidir.

> "Sem dúvida um dos elementos mais importantes."

### 5. SUBHEADLINE
"Marrone do Bruno. Dupla sertaneja da conversão. Arroz com feijão. Pão com manteiga. Queijo com goiabada."

Complemento da headline.

Exemplo Sobral:
- Headline: "Faça sua pré-inscrição gratuita"
- Subheadline: "Para ser avisado da próxima abertura e se preparar pra ser um subido"

### 6. BOTÃO NA PRIMEIRA DOBRA
**Primeira dobra** = o que aparece no celular antes de scrollar.

**Sempre ter botão na primeira dobra.** Antes da pessoa rolar, ela já tem como clicar.

> "Só ganha o jogo quem chuta pro gol."

### 7. BOTÃO EM CADA SEÇÃO
Depois de cada seção (capítulo) da página, **botão**.

**Analogia do garçom:** bom garçom não te oferece bebida só na chegada. Enche o copo o tempo todo, pergunta se quer outra garrafa. **Constantemente coloca o botão de "compre" na sua frente.** Sabe que se a garrafa acabar, você compra outra. Se acabar o jantar com meia garrafa, não compra.

### 8. BENEFÍCIO DO PRODUTO
Todo cliente pergunta: "O que eu ganho com isso?"

> "Quem ganha dinheiro no mundo dos negócios é quem resolve problemas ou ajuda a conquistar sonhos. Ter negócio não é caridade."

4 perguntas que a página tem que responder:
- O que você faz pra facilitar a vida das pessoas?
- Como torna a vida do cliente melhor e mais fácil?
- Qual transformação seu produto causa?
- Por que a vida muda depois de comprar?

> "90% das pessoas que criam páginas não param pra responder essas perguntas simples."

### 9. SERVIÇOS, PREÇO E FORMAS DE PAGAMENTO
**Falta de clareza barra conversão.**

Tem que explicar de forma simples e clara. Donos de negócio às vezes não sabem fazer — você extrai deles.

**Maldição do conhecimento** (livro **Ideias que Colam**): o que você acha óbvio um dia já não foi pra você. Profissional bom (dentista, médico, nutricionista) não lembra mais como é não saber aquilo. Sintoma de bom profissional.

**Aprender a descrever como pra criança.** Você puxa do dono — ele responde e fala "ninguém nunca me explicou desse jeito".

3 perguntas obrigatórias:
- Quais produtos/serviços você oferece?
- Quanto custam?
- Quais formas de pagamento? (Pix, cartão, boleto, parcelamento inteligente que não consome limite)

**Cuidado**: página foca em UM produto/serviço. Vende vários = converte menos.

### 10. GARANTIAS
"La garantia no la garantia no pode ser solamente tu."

**História do contratante**: Sobral foi contratar um serviço. Ele e a esposa imaginavam pagar até R$10k. Cara cobrou R$100k. Recusou. Cara: "100k, mas dou garantia. Se em 3 meses você não fizer 10× esse valor, devolvo 100%". → Mudou de ideia na hora.

> "100k é caro? Se eu te falo 'me dá 100k hoje, em 1 mês eu te devolvo 1M', você arruma 100k em horas. É a garantia."

**Como Sobral fazia como gestor:** contratos de 3-6 meses, mas cláusula "em 30 dias, se achar que não tá dando resultado, cancela sem multa". **Nunca ninguém pediu pra usar.** É argumento de venda.

### 11. DEPOIMENTOS DE CLIENTES
Gatilho da **prova social**. Restaurante cheio passa segurança.

Tipos:
- Texto
- Print de WhatsApp
- Vídeo

**O melhor: ter os 3 tipos.**

**3 perguntas mágicas pra colher depoimento** (vai gerar os melhores depoimentos):
1. **Como era sua vida ANTES de contratar?**
2. **O que te MOTIVOU a comprar?**
3. **Como ficou sua vida DEPOIS?**

Gera identificação com quem assiste, mostra benefícios pela boca do cliente, mostra transformação.

> "Nenhum cliente seu de negócio local colhe depoimento dessa maneira."

### 12. QUEBRA DE OBJEÇÕES
"Metralhadora de quebra de desculpa."

> "Ser humano é máquina de inventar boas desculpas pra não agir."

Você antecipa: "todas as desculpas que você tem são pequenas demais comparadas à transformação que você vai ter."

Objeções universais:
- Falta de tempo
- Medo de não funcionar pra mim
- Falta de dinheiro

Cada uma tem uma seção dedicada na página.

### 13. QUEM SOMOS
Pessoas se conectam com pessoas. Mesmo marca tem alguém atrás.

Aqui abusa do **gatilho da autoridade**:
- Descrição da empresa
- Tempo de mercado
- Números (Sobral: "Já gerenciei R$400M+ em ads, 50+ colaboradores, 120k alunos passaram, 55k+ ativos")

### 14. ESCASSEZ E URGÊNCIA
"Sal e pimenta da receita que converte. Toda página tem que ter."

**Urgência** (agir agora):
- Oferta por tempo limitado, apenas hoje
- Oferta válida só por mais 2h
- Aproveite antes que seja tarde
- Válido só por essa semana

**Escassez** (quantidade):
- Somente 10 unidades disponíveis
- Últimas unidades
- Estoque reduzido
- Edição limitada

**Exclusividade**:
- Apenas pros 5 primeiros

### 15. BÔNUS
Todo mundo gosta de presente. Serviço/produto extra no pacote já gera sensação de ganho.

### 16. PERGUNTAS FREQUENTES (FAQ)
Maioria das perguntas é igual em todo nicho. Não tem pergunta nova.

Lista quase universal:
- Quais opções de pagamento?
- Funciona pra X, Y, Z?
- Como saber qual produto escolher?
- Como funciona contratar?
- Quanto tempo leva?
- Tem manutenção?
- Prazo de entrega?
- Como rastrear pedido?
- Aceitam devolução?
- Produto tem garantia?
- Trocar se não satisfeito?
- Como contatar suporte?
- Alterar dados de entrega?
- Status do pedido?
- Necessário criar conta pra comprar?
- Medidas de segurança dos dados?
- Oferecem suporte técnico?
- Orçamento personalizado?

### 17. INFORMAÇÕES DE CONTATO
Todo mundo quer ter pra quem perguntar. Email comercial, WhatsApp, telefone, redes sociais, chat na página.

### 18. VELOCIDADE DE CARREGAMENTO
Toda página tem velocidade. Tem que ser **milésimos de segundo**. Página lenta = pessoa fecha.

**Ferramenta**: **pagespeed.dev** — analisa quanto a página demora pra carregar no computador e no celular.

> "A maior parte dos seus clientes tem páginas lerdas."

### 19. COMPRIMENTO (longa vs curta + com ou sem vídeo)

Como decidir:
- **Ticket**: vender carro vs vender caneta. Caro = mais esforço (mais longa).
- **Complexidade**: produto difícil de explicar = mais longa.
- **Objeções**: produto que gera muitas dúvidas = mais longa.

**Consequência:**
- **Página longa + vídeo**: converte menos %, mas qualidade maior dos que convertem
- **Página curta + sem vídeo**: converte mais barato %, mas pessoas menos qualificadas

> "Não tem certo nem errado. Depende do negócio."

### 20. TESTES
> "Só os testes dizem a verdade no final."

Variações constantes: seções, headlines, descrições, subheadlines, texto do botão. Descobre o que funciona melhor.

> "Você compra qualquer curso de página na internet e o que vão te ensinar tá aqui nesses 20 pilares. Pega isso, pede pra IA criar a página com base nisso — não tem jeito, vai dar resultado."

---

## PILAR 5 — PROMESSAS (referenciado, não desenvolvido)

Sobral perguntou pra esposa Priscila como ela ensina promessas. Resposta: "Pra ensinar promessa preciso de pelo menos 1h3min40s de conteúdo."

Por isso, em vez de tentar resumir em 5 minutos, Sobral liberou na descrição uma **aula completa dela** sobre **promessas e chamadas que dão resultado**.

> "Eu peguei essa aula da Priscila e vou deixar ela disponível pra você."

---

## Palavra-chave da aula: **México** (Sobral estava no México palestrando quando gravou)

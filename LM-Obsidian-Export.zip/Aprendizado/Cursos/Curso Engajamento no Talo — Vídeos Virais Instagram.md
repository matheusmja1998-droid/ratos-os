---
fonte: Curso_Engajamento_no_Talo.docx
tipo: curso
tags: [instagram, conteúdo, viral, engajamento, reels]
aplicar: [WinVision, LM, pessoal]
---

# Curso Engajamento no Talo — Vídeos Virais no Instagram

## As 6 Criptonitas de um Vídeo Viral

> Se você acerta todas as 6 → vídeo tem potencial de viralizar.
> Se você erra uma → vídeo não performa.

| # | Criptonita | Importância |
|---|---|---|
| 1 | **Assunto** | A mais importante |
| 2 | **Gancho** | Segunda mais importante |
| 3 | **Título** | Gancho visual |
| 4 | **Formato** | Como você entrega |
| 5 | **Roteiro** | Estrutura do conteúdo |
| 6 | **Locação** | Último a ajustar |

---

## 1. Assunto

> Antes de qualquer coisa: sobre o que você está falando?

**Assuntos que performam melhor:**
- Crescimento no Instagram
- Ganho de seguidores
- Viralização
- Engajamento
- Ideias de conteúdo

> **Regra:** Você não precisa inventar assunto novo. Fale do mesmo assunto várias vezes — mude só o gancho, o formato ou a abordagem.

---

## 2. Gancho

> Responsável por prender a atenção nos primeiros segundos. Se for ruim, a pessoa passa o vídeo.

**Erros comuns:**
- "Oi gente, tudo bem?"
- "Resolvi gravar esse vídeo"
- "Muita gente me perguntou"

**Dois tipos de gancho:**

| Tipo | O que é | Exemplo |
|---|---|---|
| **Visual** | O que aparece: título, imagem, cena, pessoa famosa | Texto na tela chamativo |
| **Falado** | O que você fala nos primeiros segundos | "Você está fazendo isso errado no seu Instagram." |

> **Regra:** Use os dois juntos. Muita gente assiste sem áudio.

---

## 3. Título

O título aparece nos primeiros segundos — funciona como um gancho visual.

**Dois tipos:**

| Tipo | Como funciona | Exemplo |
|---|---|---|
| **Sensacionalista** | Exagera a importância, cria urgência | "Cuidado, o Instagram pode usar suas imagens em Inteligência Artificial." |
| **Contra-intuitivo** | A pessoa espera uma coisa, o vídeo fala outra | "Cuidado para não se frustrar com quem só quer seu dinheiro." |

> **Referência:** Jornal Sensacionalista — títulos extremamente chamativos.

---

## 4. Formato

> Erro comum: usar sempre o mesmo formato. Às vezes o problema não é o assunto — é o formato.

**Formatos para testar:**
- Passo a passo / tutorial
- Pergunta e resposta
- Tela dividida
- Formato preguiçoso
- Corte de podcast
- Ancorado em alguém famoso
- Vários vídeos ao mesmo tempo

---

## 5. Roteiro

> Sem roteiro o vídeo fica redundante, confuso e repetitivo.

**Estrutura base em 5 etapas:**

| Etapa | O que fazer |
|---|---|
| **1. Impacto (gancho)** | Algo que chama atenção: medo, sonho, fofoca, treta, curiosidade, cena visual |
| **2. Momento atual** | Conectar com algo que a pessoa está vivendo agora. Faz ela continuar assistindo |
| **3. Luz no fim do túnel** | Mostrar que existe solução — **sem entregar ainda** |
| **4. CTA** | Pedido de ação: me segue, comenta, clica no link |
| **5. Entrega final** | A melhor informação fica no final. Se você entregar antes, a pessoa sai |

> **Regra de ouro:** A melhor informação sempre vai para o final.

---

## 6. Locação

> Locação não significa cenário caro. Significa onde você grava.

**Opções:**
- Casa, rua, carro, supermercado, academia, garagem

**Como a locação influencia:** luz, áudio, energia do vídeo e conexão com o público.

**Recomendações:**
- Gravar em pé
- Usar luz natural
- Testar diferentes lugares

> **Regra:** Se todas as outras 5 criptonitas estiverem boas e o vídeo não performar — o problema pode ser a locação.

---

## Ordem de ajuste

1. Assunto
2. Gancho
3. Título
4. Formato
5. Roteiro
6. **Por último:** Locação

---

**Ver também:** [[Curso Lucas Felix — Assessoria de Performance]]

---
fonte: Apostila_Lucas_Felix.docx
tipo: curso
tags: [assessoria, marketing, performance, agência, clientes]
aplicar: [WinVision, LM]
---

# Curso Lucas Felix — Método de Assessoria de Performance

## O modelo de negócio

Assessoria de marketing focada em **resultado**, vendida via contratos recorrentes mensais.

> Objetivo: não vender posts, social media ou tráfego isolado. Objetivo: **fazer a empresa do cliente vender mais.**

Fluxo completo que a assessoria pode tocar:
Anúncios → Página de conversão → Formulário → Atendimento comercial → Vendas → Pós-venda → Recompra

---

## 3 critérios antes de escolher nicho

> O erro mais comum: tentar escolher nicho antes de validar esses 3 critérios.

| Critério | O que é | Por quê importa |
|---|---|---|
| **1. Faturamento suficiente** | Empresa fatura R$50k–70k+/mês | Empresas pequenas são instáveis e quebram — não pagam o contrato |
| **2. Relevância da oferta** | O produto/serviço do cliente é bom | Marketing não salva oferta ruim. Cliente cancela |
| **3. Capacidade produtiva** | Se o marketing funcionar, o cliente consegue entregar mais | Se ele já está no limite, escalar vai quebrar a operação |

---

## Nichos: como pensar certo

> O fator diferenciador não é o setor — é a **complexidade do funil de vendas**.

| Tipo | Características | Exemplos | Fluxo típico |
|---|---|---|---|
| **Simples** | Ciclo curto, decisão rápida, funil simples | Academias, delivery, varejo, restaurantes, clínicas | Anúncio → WhatsApp → Venda |
| **Complexos** | Vendas consultivas, vários decisores, ciclos longos | SaaS, serviços B2B, consultorias | Anúncio → Landing Page → SDR → Closer → Farmer |

---

## As 4 fases de execução do projeto

| Fase | Quando | Objetivo |
|---|---|---|
| **1. Exploração** | Início — nada ainda funciona | Encontrar o que funciona: testes de criativo, público, oferta, página, argumentos |
| **2. Lapidação** | Algo começa a funcionar | Melhorar o que já funciona: copy, segmentação, funil, scripts, oferta |
| **3. Escala** | Funciona de forma consistente | Aumentar investimento, volume de leads, ampliar campanhas vencedoras |
| **4. Extração** | Maximizar faturamento | Vender mais para quem já comprou: recompra, upsell, cross-sell, recorrência |

---

## Setup vs. Manutenção

| Fase | Trabalho | Remuneração |
|---|---|---|
| **Setup** (primeiras semanas/meses) | 2h–4h/dia por cliente — tudo precisa ser criado | Justifica onboarding ou fee maior inicial |
| **Execução recorrente** | Minutos por dia — ajustes e otimizações | Cliente paga pelo resultado, não pelas horas |

> "Muitos clientes passam a exigir minutos por dia, mas continuam pagando o contrato."

---

## Prospecção por bloco de nicho

Prospectar em blocos cria: inteligência de mercado, melhor comunicação e maior conexão.

**Exemplo:**
- Semana 1 → clínicas estéticas
- Semana 2 → academias
- Semana 3 → restaurantes

**Antes de prospectar cada nicho:** pesquise dores do setor, linguagem usada, problemas comuns, desafios operacionais.

> Exemplo: para delivery, não dizer "mais vendas" — dizer **"mais pedidos por dia"**. Mesma mensagem, muito mais conexão.

---

## Como apresentar o serviço na venda

Simplifique em 3 partes:

1. **Atrair clientes** — "Trazer pessoas interessadas para o seu negócio"
2. **Otimizar o funil de vendas** — Página, atendimento, comercial e fechamento (não só marketing)
3. **Vender mais para quem já comprou** — Recompra, recorrência e ofertas internas para a base

---

## Diferenciação no mercado

> "Grande parte das agências faz apenas posts, seguidores e curtidas."

O método posiciona como **parceiro estratégico de crescimento** com foco em vendas, faturamento e retorno financeiro.

---

## Business Intelligence — como falar de resultado

| ❌ Errado | ✅ Certo |
|---|---|
| "Criamos campanhas e segmentamos públicos" | "Levamos essa escola de 23 para 40 turmas" |
| Falar de tecnologia | **Falar de dinheiro** |
| Detalhes técnicos | ROI, custo por venda, faturamento gerado |

---

## Linguagem na venda

> "O cliente quer saber apenas: vai vender mais? Quanto vai ganhar? Como vai acontecer?"

O objetivo da venda é **clarear a oportunidade na cabeça do cliente** — não impressionar com jargões.

---

## Regra final do método

> O sucesso depende de duas coisas:
> 1. Escolher a empresa certa
> 2. Aplicar corretamente a metodologia
>
> Se os dois forem feitos: o cliente **inevitavelmente** venderá mais.

---

**Ver também:** [[Minha Oferta de Serviços — WinVision]] | [[../../LM/LM — Visão Geral]] | [[$100M Money Models — Hormozi]]

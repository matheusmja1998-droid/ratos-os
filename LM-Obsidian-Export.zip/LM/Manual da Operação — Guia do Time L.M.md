# Manual da Operação L.M
### Tudo que você precisa saber pra fazer parte do time

---

> **Pra quem é esse documento:** você, que acabou de entrar (ou está entrando) na L.M.
> Leia com calma, do começo ao fim. Aqui está quem somos, o que vendemos, pra quem vendemos, como vendemos e o seu papel nisso tudo.
> Quando terminar, você vai entender a operação inteira — e por que a gente faz cada coisa do jeito que faz.

---

## 1. QUEM SOMOS

A **L.M Agência** é uma operação de estruturação comercial focada em **integradoras de energia solar**. A gente não é agência de marketing tradicional. A gente não vende post, não vende seguidor, não vende "gestão de tráfego". A gente constrói a **máquina de vendas** que faz a integradora parar de depender de sorte e passar a ter cliente entrando de forma previsível.

A empresa é tocada por dois sócios:

### Valentino Pascual — Head de Prospecção
É o cara da máquina de demanda. Constrói a operação de prospecção do zero: lista, script, cadência, treinamento. Tem uma habilidade rara — tira um BDR do zero até 5, 6, 7 agendamentos por dia em duas semanas. Quando você precisar aprender a prospectar de verdade, é com ele. Ele vai estar todo dia em cima, cobrando e ensinando.

### Matheus Jardim — Head de Vendas
É o cara do fechamento e da estrutura. Conduz as reuniões de venda (R1 e R2), fecha os contratos e monta toda a inteligência por trás da operação — CRM, automação, tecnologia, IA aplicada ao comercial. É quem transforma a reunião que você marcou em contrato assinado.

**A divisão é clara:** o Valentino enche o pipeline, o Matheus fecha. E você, BDR, é a peça que liga os dois — você gera a demanda que alimenta a máquina inteira.

### A missão
Construir a operação comercial mais bem-feita do mercado solar B2B brasileiro. Sem hype, sem promessa fácil, sem enganar ninguém. A gente vende o que entrega.

### A visão
- **2028:** ser referência nacional em estruturação comercial solar. Máquina de 30+ pessoas, escritório físico, líderes em cada frente.
- **2030:** a L.M vira a primeira peça de um conglomerado. Quem cresce com a gente cresce junto.

---

## 2. O MERCADO ONDE A GENTE JOGA

Pra você vender bem, precisa entender o terreno. Aqui está o que está acontecendo no mercado solar — e por que ele é o lugar certo pra gente atuar agora.

### O setor é gigante, mas parou de crescer
O Brasil é o 2º maior em energia solar na matriz elétrica, com mais de **63 GW** instalados e **R$300 bilhões** investidos. Mas — e esse "mas" é o que abre a porta pra gente — o mercado **caiu 29% em 2025** e deve cair mais **7% em 2026**.

Por anos, a integradora crescia sozinha: o telefone tocava, a indicação aparecia, vendia. Esse tempo acabou. Curtailment, entraves de conexão à rede, dólar alto e o Fio B encareceram tudo. Agora é mercado de disputa.

### O dado que abre os olhos do cliente
**90% das integradoras fundadas antes de 2016 já fecharam.** Só 10% sobreviveram. E as que sobreviveram não tinham o melhor painel nem o menor preço — tinham o **melhor comercial**.

### Quem é a integradora média (o nosso cliente)
- **68%** têm até 4 funcionários — operações pequenas, o dono é o vendedor
- **72%** dependem de indicação como canal principal
- **Menos de 15%** usam CRM de verdade
- O número de propostas caiu **19%** em 2025 — quem dependia de demanda passiva está sangrando agora

### A nossa tese em uma frase
> Num mercado que parou de crescer, ganha quem tem máquina de vendas — não quem espera a indicação chegar. É exatamente isso que a L.M constrói.

---

## 3. PRA QUEM A GENTE VENDE

Nosso cliente ideal é o **dono de integradora solar** que:

- **Depende de indicação** e sabe que isso não escala. Tem mês ótimo e mês seco, sem prever qual vai ser qual.
- **Já tentou tráfego pago** (Meta, Google) e queimou dinheiro com lead desqualificado. O lead chegava, mas morria no WhatsApp porque ninguém qualificava.
- **Tem time comercial, mas sem processo** — cada vendedor faz do seu jeito, ninguém segue script, ninguém mede nada.
- **Fecha o mês no escuro** — não sabe de onde vem o próximo cliente.
- **É o gargalo da própria empresa** — ele fecha a maioria dos contratos pessoalmente, então não cresce mais do que a própria agenda permite.

### As 5 dores que ele sente (e que você vai tocar na prospecção)

1. **Dependência total de indicação** — meses imprevisíveis
2. **O dono é o comercial** — teto invisível de crescimento
3. **Guerra de preço com concorrente pior** — sem argumento pra justificar valor
4. **Sazonalidade matando o caixa** — sem pipeline pra antecipar meses fracos
5. **Não sabe onde estão os clientes bons** — só chega lead frio ou caçador de preço

### Pra quem a gente NÃO vende
Dono que quer "só uns leads", que busca o menor preço, que não tem time nem vontade de estruturar. Esses não são nosso cliente — e tentar vender pra eles é desperdício de tempo.

---

## 4. O QUE A GENTE VENDE

A L.M tem uma linha de produtos chamada **Ignição** — consultoria comercial para integradores solares. São dois níveis:

### Ignição Comercial — R$5.000 (o produto principal)
**"Do zero ao time prospectando em 45 dias."**

Pra dono que **tem time comercial** e quer parar de depender de indicação. É um programa de 6 semanas / 10 horas onde a gente monta a máquina de prospecção inteira da empresa dele.

**O resultado (antes × depois em 45 dias):**

| Antes | Depois |
|---|---|
| Depende de indicação | Pipeline ativo de prospects B2B toda semana |
| Gasta em tráfego com lead ruim | Custo de aquisição próximo de zero |
| Time sem processo | Cadência definida, CRM rodando, playbook na mão |
| Fecha o mês no escuro | Dashboard com métricas em tempo real |
| Dono resolve tudo | Time prospecta sem depender do dono |

**As 10 entregas tangíveis:** ICP + perfil do decisor, lista de 50-100 empresas, 3 scripts validados, cadência completa, playbook, CRM configurado, documento de objeções, dashboard de métricas, scripts ajustados com dados reais e plano de 30 dias pós-programa.

**A lógica de valor:** um único cliente gerado pela estrutura paga o Ignição Comercial inteiro. A pergunta certa não é "quanto custa contratar" — é "quanto custa NÃO contratar por mais 6 meses". (Ticket médio solar é de R$25k a R$80k por projeto.)

### Ignição Solo — R$497 (porta de entrada)
Pra dono **solo, sem time, sem budget** pros R$5k. É uma sessão de 90 minutos de diagnóstico e direcionamento. Funciona como entrada — quem faz o Solo e cresce, depois sobe pro Comercial (com crédito dos R$497).

### A escada de produtos
```
Webinar → Diagnóstico (R1/R2) → Ignição Solo (R$497) → Ignição Comercial (R$5.000)
```

---

## 5. COMO A GENTE VENDE — O FUNIL COMPLETO

Esse é o coração da operação. Decora esse fluxo, porque é nele que você trabalha todo dia.

```
1. PROSPECÇÃO ATIVA (você liga — outbound)
        ↓
2. LIGAÇÃO 1 — convite pro webinar + qualificação
        ↓ (qualificado: tem 2+ vendedores)
3. LIGAÇÃO 2 (dia seguinte) — marcar a R1
        ↓
4. PRÉ-CALL (1 dia antes da R1) — mapear o cenário, 10-15 min
        ↓
5. R1 — diagnóstico profundo, 45-60 min (Matheus conduz)
        ↓
6. DOC DE GUERRA (até 24h após a R1) — devolve o cenário, amplia urgência
        ↓
7. R2 — fechamento, 60-90 min (Matheus conduz)
        ↓
   Fechou → Ignição Comercial (R$5k) ou Solo (R$497)
   Não fechou → base aquecida → volta pro webinar → reengaja
```

### Onde VOCÊ entra
Seu trabalho é a **etapa 1, 2 e 3**: prospectar, qualificar e marcar a reunião. Você não fecha venda, não faz proposta, não negocia preço. **Você abre a porta. O Matheus entra e fecha.** Seu placar é o número de reuniões qualificadas que você marca.

### Cada etapa, explicada

**Ligação 1 — Convite pro webinar + qualificação**
Você liga, desperta curiosidade e convida pro webinar. A pergunta de qualificação é: *"Vocês têm vendedores na equipe? Quantos?"*
- 2+ vendedores → lead qualificado → segue pro funil Ignição Comercial
- Solo / 1 vendedor → pipeline Ignição Solo (não descarta)

**Ligação 2 — Marcar a R1 (dia seguinte)**
Aqui tem uma regra de ouro. O que **NÃO** funciona: *"Minha equipe gostou da sua empresa e liberou um horário."* Soa fabricado, o decisor esperto percebe.

O que **funciona** é ancorar no que ele mesmo falou:
> *"Fulano, ontem você comentou [coisa específica que ele disse]. Falei com o Valentino e a gente quer entender melhor esse cenário. Temos 45 minutos essa semana pra fazer uma análise da sua operação. Qual dia fica melhor?"*

Motivo ancorado no que ele disse = muito mais credibilidade.

**Pré-call (1 dia antes da R1)**
Ligação de 10-15 min pra mapear o contexto antes da reunião. Chega na R1 já sabendo faturamento, ticket, decisores e urgência — a R1 fica cirúrgica. Mapeia 4 blocos: time/estrutura, faturamento/ticket, o problema, e quem decide.

**R1 — Diagnóstico (Matheus)**
Reunião de 45-60 min de diagnóstico profundo. Não é apresentação, é diagnóstico. Regra de ouro: **quem conduz fala 30%, o cliente fala 70%.** Quem mais fala no diagnóstico, mais compra.

**Doc de Guerra (até 24h depois da R1)**
Documento enviado entre R1 e R2. Não é proposta, não tem preço. Devolve o cenário com as palavras do próprio cliente, mostra o custo do problema em números, amplia a urgência e cria antecipação pra R2.

**R2 — Fechamento (Matheus)**
Reunião de 60-90 min onde a venda acontece. Abre retomando o Doc de Guerra: *"Você leu o que te mandei — o que fez mais sentido pra você?"*

---

## 6. O WEBINAR — NOSSO MOTOR DE AUTORIDADE

O webinar é a peça central da nossa estratégia de geração de demanda. Em vez de ligar pra 200 pessoas tentando vender, a gente reúne dezenas de donos de integradora num evento online e entrega valor real. Quem assiste sai querendo conversar com a gente.

### Como funciona
É um evento online, ao vivo e gratuito. A gente prospecta durante a semana pra encher o webinar, entrega conteúdo de verdade sobre prospecção solar, e no final convida quem quer estruturar o comercial pra uma reunião de diagnóstico (a R1).

### A estrutura do webinar (7 blocos)
1. **Aquecimento** — Valentino abre, engaja, faz perguntas pro público
2. **Abertura com autoridade + promessa** — quem somos, o que vamos mostrar
3. **Tensão** — o cenário de consequências reais: prospecção ultrapassada, custo insustentável, Fio B
4. **Liberação** — a saída do problema: o sistema de prospecção ativa estruturada
5. **Conteúdo principal** — nichar dentro do solar, reposicionar, convite em vez de cold call
6. **Chamado final** — o convite pra reunião ("E se a gente pudesse fazer isso junto?")
7. **Finalização** — ação de saída

### A história que prova a tese (usada no webinar)
> "A gente investia R$10 mil por mês em tráfego pago. Gerava 300 leads. Quase nenhum qualificado. O cara pedia orçamento em 5 empresas e fechava com a mais barata. Quando trocamos pra prospecção estruturada, o jogo virou: mais de 80 empresários por semana chegando até a gente pedindo pra conversar. Investimento em mídia: zero. Crescimento de 200% em 2 meses."

### Lição que a gente aprendeu (e que afeta seu trabalho)
No primeiro webinar tivemos só 23% de comparecimento. O culpado principal foi o **horário** (meio-dia, em cima do almoço de decisor B2B) e a **falta de ligação de confirmação**. Por isso hoje:
- Webinar nunca ao meio-dia (sempre 14h ou 19h)
- Confirmação **sempre** com ligação 48h antes, além de WhatsApp/email
- No dia: WhatsApp de manhã + ligação pra quem não entrou em 10 min

**Por que isso importa pra você:** confirmar presença por ligação é parte do seu trabalho. WhatsApp confirma por educação. Ligação confirma por compromisso.

---

## 7. A PROSPECÇÃO — SEU DIA A DIA

Essa é a parte que você vai viver todo dia. Aqui está como a gente prospecta.

### O script de prospecção (3 etapas)

**Etapa 1 — Triagem inicial (passar pelo porteiro)**
Objetivo: despertar curiosidade e chegar no decisor. Você não vende nada aqui.
> *"Oi, tudo bem? Aqui é o [seu nome], da L.M. Tenho um convite pra pessoa responsável pela empresa, consegue repassar pra ela?"*

**Etapa 2 — Convite pra reunião (com o decisor)**
Objetivo: aumentar a conversão. Apresenta o evento e toca na dor.
> *"Tenho um convite pro responsável da empresa, é você mesmo? Nessa quinta ao meio-dia a gente tá organizando um evento 100% online e gratuito, com mais de 100 empresários do mesmo ramo e da mesma cidade. A gente criou esse evento porque viu que muita integradora perde cliente por R$500 a menos no orçamento, depende de indicação ou de tráfego pago que já tá ultrapassado."*

Toca em pelo menos 3 tópicos de valor:
- Aumentar o MRR (receita recorrente)
- Diminuir o CAC (custo de aquisição) — *"como tá teu CAC hoje?"*
- Criar novas linhas de receita (o "CAC zero")

**Etapa 3 — Autoridade e diferenciação (fechar o convite)**
Objetivo: concluir com clareza e confirmar a presença.
> *"E por que a gente tá fazendo esse convite? Porque temos um braço educacional onde compartilhamos o que vimos nas maiores operações do país. Seria uma honra ter você no evento. Posso confirmar sua participação? O que você gostaria de aprender pra sair feliz do evento?"*

### Como qualificar a lista
A gente prospecta integradora solar. Sinais de lead bom:
- Mais de 10 avaliações no Google (empresa ativa, tem operação)
- 3+ vendedores (tem time = qualificado pro Ignição Comercial)
- É integradora de verdade (não só "mão de obra")

### A regra do follow-up
Lead qualificado você **persegue até ele bloquear ou explodir**. Não é "liguei uma vez, não atendeu, desisti". É cadência: canal → dia → mensagem → intervalo. Quem some no follow-up perde a venda.

---

## 8. AS MÉTRICAS — O QUE VOCÊ MEDE TODO DIA

Aqui a gente vive pelo número. "Acho que tá indo bem" não existe. O que existe é o dado na mesa.

| Métrica | O que é | Por que importa |
|---|---|---|
| **Ligações discadas** | Quantas tentativas no dia | É o combustível. Sem volume, sem resultado. |
| **Conexões** | Quantas pessoas atenderam de fato | Mede se a lista e o horário estão certos. |
| **Decisores** | Quantas vezes você falou com quem decide | Mede sua eficácia em passar pelo porteiro. |
| **Reuniões marcadas** | Seu placar principal | É o que paga seu bônus e te leva à efetivação. |

### Benchmark do funil (o que é normal vs alto desempenho)

| Conversão | Média do mercado | Alto desempenho |
|---|---|---|
| Lead → reunião | 8-12% | **25-35%** |
| Reunião → proposta | 40-55% | **65-75%** |
| Fechamento de proposta | 15-25% | **40-55%** |

### O relatório diário
Todo fim de dia você manda no grupo — **sem ninguém precisar pedir**:

```
📊 [SEU NOME] — [DATA]

📞 Ligações
➡️ Ligações discadas:
➡️ Conexões (atenderam):
➡️ Decisores:
➡️ Reuniões marcadas:

🔁 Follow-up
➡️ Follow-ups enviados:
➡️ Decisores gerados:
➡️ Reuniões geradas:

🎯 Geral do Dia
➡️ Total de visitas realizadas:
➡️ Principal dificuldade do dia:
➡️ Horas prospectando:
```

---

## 9. COMO A GENTE TRABALHA — RITUAIS E CULTURA

### A daily (todo dia útil, 15 min)
Rápido, em pé, sem enrolação. Cada um traz: número de ontem em 60s, plano de hoje, onde está travando. É aqui que a gente alinha o foco e destrava o que travou.

### O pre-flight (antes de cada rodada de prospecção)
Lista aberta, script revisado, meta do dia definida, e a pergunta: "tô no nível hoje?". Quem entra mal preparado, não entra.

### Os 5 valores da L.M
1. **Faz dobrado, sem mandar** — entrega 110% e cobre o gap do colega antes de virar fogo. Aqui não existe "fiz o que mandaram".
2. **Número na mesa. Hoje.** — métrica é a única verdade. Sem narrativa pra esconder número ruim.
3. **Se não for excelência, não vai pro cliente** — quem liga em nome da L.M tem que estar no nível. Preparado, focado, estudado.
4. **Caminho difícil por escolha** — a gente recusou o caminho fácil. Quem entra escolheu o difícil também.
5. **Palavra vale contrato** — combinou, cumpriu. Não vai cumprir, avisa antes. Sumiu, tá fora.

### As linhas vermelhas (o que não toleramos)
- Linguagem de vítima ("o mercado", "o cliente não quis", "ninguém me avisou")
- Falta de palavra (combinou e não cumpriu, sumiu)
- Preguiça intelectual (não estudou, repete o mesmo erro)
- Falsa modéstia ("tá bom assim")
- Fazer o mínimo (entregar e parar)

---

## 10. SEU CAMINHO NA L.M

### O Fire Test (primeiros 45 dias)
É o seu período de prova. 100% comissão, sem fixo. A meta é fechar 2 contratos em 45 dias. Tem checkpoint no dia 15, 30 e 45. É duro de propósito — porque a gente quer quem performa, não quem vem pelo fixo.

### Depois do Fire Test (efetivação)
Quem passa entra com fixo de R$2.100 + 5% de comissão sobre o que entra + bônus. E aí começa o **Dream Plan**: a gente senta com você, descobre seu sonho material (carro, casa, viagem) e monta um bônus específico pra te levar até ele. Aqui seu sonho é levado a sério.

### O plano de carreira (sem teto)
```
BDR  →  Closer  →  Head de operação  →  Sócio
```
Quem entrega, sobe. A gente não segura ninguém embaixo.

---

## 11. RESUMO — A OPERAÇÃO EM UMA PÁGINA

- **Quem somos:** L.M, estruturação comercial pra integradoras solares. Valentino (prospecção) + Matheus (vendas).
- **O mercado:** solar parou de crescer (-29% em 2025). 90% das integradoras antigas fecharam. Ganha quem tem máquina de vendas.
- **Pra quem vendemos:** dono de integradora com time, que depende de indicação e quer previsibilidade.
- **O que vendemos:** Ignição Comercial (R$5k, monta a máquina de prospecção em 45 dias) e Ignição Solo (R$497, porta de entrada).
- **Como vendemos:** Prospecção → Webinar → R1 (diagnóstico) → Doc de Guerra → R2 (fechamento).
- **Seu papel:** prospectar, qualificar e marcar reunião. Você abre a porta, o Matheus fecha.
- **Como medimos:** ligações, conexões, decisores, reuniões marcadas. Número na mesa todo dia.
- **Seu caminho:** Fire Test (45 dias) → efetivação (fixo + comissão + Dream Plan) → carreira sem teto.

---

> **Bem-vindo à L.M.**
> A diferença entre uma integradora que fatura R$400k/mês e uma que fatura R$1,5M/mês raramente é o produto. É o processo. A gente vende processo. E agora você faz parte de quem constrói isso.
>
> *Número na mesa hoje. Excelência antes de sair pro cliente.*

---
tipo: índice
programa: Os Escolhidos
mentor: Adriano Aquino
agência: LM
tags: [escolhidos, adriano, outbound, playbook]
criado: 2026-04-12
---

# Os Escolhidos — Adriano Aquino

## Sobre o programa
Programa de vendas outbound B2B conduzido por Adriano Aquino (Ascend Sales).
Foco: lotar a agenda de reuniões usando CAC zero — sem tráfego pago, sem anúncio.
Meta: **50 reuniões/semana** por vendedor.

## Time da L.M participante
- Matheus (sócio)
- Valentino / Tino (sócio)
- Keila Anandyara (comercial)
- Outros membros do time

## Playbook — Documentos de Referência
- [[Playbook/Canais CAC Zero — Ligação, Disparo e Follow-up]]
- [[Playbook/Critérios de Nicho]]
- [[Playbook/Checklist de Execução — Pré-Segunda]]
- [[Playbook/Mapeamento de Conexão]]
- [[Playbook/Compromissos e Metodologia OAE]]
- [[Playbook/Banco de Aulas]]
- [[Playbook/Benchmarking Solar]]
- [[Playbook/Metodologia Adriano Aquino]]
- [[Playbook/Antecipação de Decisão e Pomodoro]]
- [[Playbook/Controle de Pomodoro e Gestão de Tarefas]]
- [[Playbook/Horizonte de Oportunidades]]
- [[Playbook/Ciclo de Vendas — Como Encurtar]]

## Aulas
- [[Playbook/Aula 1 — Onboarding]]
- [[Playbook/Super Aulão — 28-03]]
- [[Playbook/Treinamento de POPs]]

## Dailies e Análises
- [[Dailies/Daily 23-03 — Análise de Ligação e Áudios]]
- [[Dailies/Daily 24-03 — Análise de Métricas]]
- [[Dailies/Daily 25-03 — Gravação Daily]]
- [[Dailies/Daily 25-03 — Análise de Disparos]]
- [[Dailies/Daily 31-03]]
- [[Dailies/Daily 01-04 — Como Resolver Problemas de Clientes]]
- [[Dailies/Daily 02-04]]

## Benchmarks do programa
| Métrica | Benchmark |
|---|---|
| Ligações/hora | 15 |
| Conexão (atendimento) | 50% |
| Decisor após conexão | 40% |
| Reunião após decisor | 33–66% |
| Disparos/dia | mínimo 40 |
| Disparo → decisor | 8–12% |
| Decisor → reunião (disparo) | 40–50% |
| Follow-ups/dia | mínimo 20 |
| Follow → decisor | 30–40% |
| Decisor → reunião (follow) | 50% |

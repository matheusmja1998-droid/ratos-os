# Cultura de Alta Per
ormance**Fonte:** Os Escolhidos — Adriano (Ascend Sales)  **Data:** 16/04/2026> Cultura não é o que você declara nos valores da empresa. É o comportamento que você tolera quando ninguém está olhando — e o comportamento que você elogia quando alguém está.---## O que é cultura de alta per
ormance — e o que não éNão é ter a equipe mais 
eliz, o ambiente mais descontraído, os melhores bene
ícios ou a comunicação mais transparente.**É:** o conjunto de comportamentos que um time repete de 
orma consistente quando en
renta pressão, ambiguidade e decisões di
íceis. O que o time 
az quando o dono não está presente. O padrão de ação que emerge naturalmente nos momentos de crise, de escolha e de execução sob pressão.---## Os 4 Pilares da Cultura de Alta Per
ormance### 1. RituaisO que o time 
az de 
orma repetida e intencional.- Daily de 15 min todo dia vale mais que reunião trimestral bem produzida- Ritual precisa ter: **propósito claro** (todo participante sabe por que existe), **
ormato de
inido** (estrutura não muda), **consequência** (quando não acontece, existe uma resposta)- A repetição é o que trans
orma comportamento em cultura- Times sem rituais = grupos de indivíduos competentes trabalhando em paralelo- Times com rituais 
ortes = organismos coletivos com inteligência e direção compartilhadas### 2. LinguagemAs palavras que o time usa para descrever a realidade.**Linguagem de alta per
ormance:**- \"O que eu poderia ter 
eito di
erente?\"- \"Qual é o próximo passo?\"- \"O que eu aprendi?\"- \"Eu me comprometo com X até Y\"**Linguagem de baixa per
ormance:**- \"O mercado está di
ícil\"- \"Ninguém me avisou\"- \"Eu tentei\"- \"Não depende de mim\"- \"Foi culpa de Z\"> O líder que não corrige a linguagem do time está validando o sistema de crenças por trás dela. Quando alguém diz \"o cliente não quis\" e o líder não pergunta \"o que você 
ez di
erente quando percebeu que o cliente estava hesitando?\", está sinalizando que linguagem de vítima é aceitável.### 3. ConsequênciasO que acontece quando os padrões são mantidos ou quebrados.- Consequências positivas são tão importantes quanto negativas- Reconhecimento especí
ico (nomeia comportamento + contexto + impacto) educa o time sobre o que signi
ica per
ormar- Reconhecimento genérico (\"bom trabalho\") não constrói cultura- Consequência negativa = 
eedback individual, não punição- **O que você tolera, você ensina**> Consequências não são punição: são clareza. A equipe que sabe o que acontece quando os padrões são mantidos ou quebrados tem mais segurança psicológica do que a que não sabe.### 4. Re
erênciasQuem o time olha como modelo de cultura.- Re
erências 
uncionam como âncoras comportamentais- Quando alguém en
renta decisão di
ícil, pensa: \"como X trataria isso?\"- O líder é a re
erência mais poderosa — mas não pode ser a única- Culturas dependentes de uma única re
erência são 
rágeis- Culturas resilientes têm múltiplas re
erências em di
erentes níveis e 
unções> \"A cultura do time é quando você 
az mais do que todo mundo quando ninguém está olhando.\" — Nimoto---## E
eito Janela Quebrada**Teoria:** um edi
ício com janela quebrada não consertada rapidamente tende a ter mais janelas quebradas. A janela não consertada sinaliza que a deterioração é tolerada — e esse sinal atrai mais deterioração.**Aplicado a times:** o comportamento abaixo do padrão que não é tratado sinaliza para todo o time que o padrão é negociável. Quando o padrão é percebido como negociável, outros membros começam a negociá-lo também.**Exemplos de janelas quebradas:**1. Membro chega atrasado na reunião e o líder não comenta → na semana seguinte, mais dois chegam atrasados2. Relatório entregue incompleto que passa sem conversa → no próximo prazo, mais entregas chegam incompletas3. Comprometimento não cumprido sem 
ollow-up → a palavra perde peso dentro do time4. Reclamação do cliente tratada com \"é complicado\" sem ação → padrão de atendimento começa a escorregar**Como tratar:**- Conversa individual e especí
ica (não em reunião de equipe, não por e-mail)- Usar o método SBI- **Regra prática:** qualquer comportamento abaixo do padrão percebido e não tratado em até 48h vira padrão implicitamente aceito---## Rituais de Alta Per
ormance### Daily (15 min — em pé, sem slides)**Objetivo:** alinhar o time no que importa hoje, identi
icar bloqueios, criar comprometimento público.1. Cada membro responde em 60s: o que 
ez ontem, o que vai 
azer hoje, o que está bloqueando2. Líder registra bloqueios que precisam de ação 
ora do daily3. Encerra com: \"o que precisa acontecer hoje para o dia ser um sucesso?\"Sinal de que está 
uncionando: o time chega preparado, sem improvisar.### Weekly (45–60 min — com pauta 
ixa)**Objetivo:** revisar resultados da semana, calibrar prioridades da próxima, tratar o que travou.1. Métricas da semana (2–3 números que importam, não todos)2. Vitórias da semana (especí
icas — \"
echei o cliente X usando a abordagem Y\")3. Aprendizados (o que não 
uncionou, por que, o que muda)4. Prioridades da próxima semana (3 ações de maior impacto por membro)5. Bloqueios estratégicos para o líder remover### Monthly (90 min — 
ora da rotina operacional)**Objetivo:** calibrar cultura, dar e receber 
eedback estruturado, desenvolver competência coletiva.1. Revisão dos 4 pilares: o que está 
orte, o que está en
raquecendo?2. Reconhecimento cultural (cada membro indica colega que exempli
icou o padrão — com comportamento especí
ico)3. Rodada de 
eedback usando SBI4. Aprendizado coletivo (um tema de desenvolvimento apresentado por alguém do time)5. Alinhamento de expectativas pelo líder> Rituais degridem quando perdem o propósito. Sinal mais claro: quando o time começa a achar que poderia ter sido um e-mail.---## Método SBI — Situação, Comportamento, ImpactoEstrutura 
eedbacks separando o que aconteceu de quem a pessoa é.| | | ||---|---|---|| **S** | **Situação** | Quando e onde o comportamento aconteceu. Contexto especí
ico, sem generalização. || **B** | **Comportamento** | O que a pessoa 
ez ou disse — observável e descritível, sem interpretação ou julgamento. || **I** | **Impacto** | O e
eito que o comportamento teve em você, no time, no cliente ou no resultado. |**Feedback vago vs. SBI:**| Vago | SBI ||---|---|| \"Você precisa ser mais cuidadoso com os clientes.\" | \"Na reunião de terça com o cliente X, quando ele perguntou sobre prazo, você respondeu sem con
irmar com a equipe. O cliente 
icou inseguro e pediu para remarcar.\" || \"Sua comunicação com o time precisa melhorar.\" | \"No daily de segunda, quando a Ana pediu ajuda no projeto Y, você disse que ia ver e não voltou. Isso travou a entrega dela por dois dias.\" || \"Bom trabalho essa semana!\" | \"Na negociação com o cliente Silva na quinta, quando ele sinalizou que ia comparar preço, você não recuou — pediu 10 minutos, reposicionou o valor e 
echou. Isso é exatamente como queremos lidar com essa objeção.\" |> SBI 
unciona para 
eedback construtivo E para reconhecimento. Reconhecimento especí
ico ensina. \"Bom trabalho\" não ensina o que 
oi bom.Dica prática: joga o 
eedback no GPT e pede pra estruturar em SBI.---## O Líder como Guardião da CulturaO que o guardião 
az no dia a dia:1. **Exempli
ica antes de cobrar** — nível de exigência consigo mesmo determina a credibilidade para exigir do time2. **Trata desvios com imediatidade** — não acumula 
eedbacks, trata no momento com SBI em conversa individual3. **Reconhece com especi
icidade** — trans
orma vitória individual em aprendizado coletivo4. **Protege rituais como protege resultados** — daily cancelado por estar ocupado sinaliza que não é prioridade real5. **Nomeia re
erências publicamente** — distribui a responsabilidade da cultura além do líder6. **Admite quando errou o padrão** — o líder que nomeia o próprio erro com o mesmo SBI 
ortalece a cultura mais do que qualquer discurso### Armadilha do líder que quer ser querido- Priorizar ser querido em vez de respeitado- Evitar conversa di
ícil pra não criar clima ruim- Tolerar baixa métrica pra não parecer rígido- Cancelar rituais quando a rotina 
ica corrida> Cada uma dessas decisões parece gentileza no curto prazo — é negligência no longo prazo.---## Diagnóstico dos 4 Pilares (missão das próximas 24h)Responda honestamente em uma 
rase para cada pilar:**Rituais:** Quais rituais o seu time tem hoje? Acontecem com consistência real ou são cancelados quando a semana 
ica corrida?**Linguagem:** Qual é a linguagem predominante quando algo não 
unciona? Responsabilidade pessoal ou circunstância externa?**Consequências:** O que acontece quando alguém entrega abaixo do padrão? E quando entrega acima?**Re
erências:** Quem são os membros que exempli
icam a cultura que você quer? Eles são nomeados publicamente como re
erência?Depois do diagnóstico: identi
ique a **janela quebrada mais antiga** que ainda não 
oi tratada. Prepare o 
eedback em SBI e agende a conversa para as próximas 48h.---## Resumo 
inal> Cultura é comportamento tolerado, não valor declarado.- Não existe cultura em slide de onboarding- Uma janela quebrada tratada logo vale mais que 10 tratadas depois- Rituais = consistência, não conteúdo- SBI trans
orma 
eedback de julgamento em instrução- O líder que não se aplica o padrão perde o direito de cobrá-lo
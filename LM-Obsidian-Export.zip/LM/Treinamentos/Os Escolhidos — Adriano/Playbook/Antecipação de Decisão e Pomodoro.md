---
fonte: 02_Antecipacao_de_Decisao_e_Pomodoro
programa: Os Escolhidos
tags: [pomodoro, gestão-do-tempo, decisão, prospecção, metas]
---

# Antecipação de Decisão e Pomodoro

## Por que Começar Cedo no Ano

Quem começa antes colhe muito mais resultado. O empresário tem predisposição positiva quando percebe que o vendedor também começou cedo.

> "Oportunidade não se pede, ela se cria."

---

## A Técnica Pomodoro Aplicada ao Comercial

**Duas modalidades:**
- 25 min de trabalho + 5 min de descanso
- **50 min de trabalho + 10 min de descanso** ← recomendado para o time

**Por que funciona:** após 50 minutos de trabalho intenso, foco e energia naturalmente diminuem. A pausa retoma o foco e mantém alta performance.

Aplica para: prospecção, follow-up, reuniões de venda, criação de proposta.

---

## Hierarquia de Metas

```
Trimestral → Mensal → Quinzenal → Semanal → Diária → Por Pomodoro
```

| Nível | Exemplo |
|---|---|
| Trimestral | R$ 80.000 por trimestre |
| Mensal | R$ 30.000 |
| Quinzenal | R$ 15.000 em duas semanas |
| Semanal | R$ 7.500 por semana |
| Diária | 5 reuniões por dia |
| Por Pomodoro | 1 reunião agendada por bloco de 50 min |

> 6 Pomodoros de 50 min = 5 horas e meia de trabalho efetivo.
> 80 ligações ao dia ficam simples quando divididas em blocos de 20.

---

## Exemplo de Distribuição de Pomodoros

| Pomodoro | Objetivo |
|---|---|
| P1 | 20 ligações de prospecção |
| P2 | 40 disparos de WhatsApp |
| P3 | 20 ligações + busca de 1 reunião |
| P4 | 15 follow-ups prioritários |
| P5 | 20 ligações + respostas a decisores de alta prioridade |
| P6 | Meta de fechar a reunião pendente dos blocos anteriores |

---

## Antecipação de Decisão

Cada decisão tomada no dia consome energia — como uma repetição de musculação. Quanto mais decisões não planejadas, pior a performance de prospecção.

> "Energia é fundamental na prospecção. Sem energia você não consegue prospectar, falar com o empresário, agendar compromisso nem fechar venda."

**Como automatizar as decisões:**
- Planejar todo o dia na véspera (preferencialmente na tarde de quinta)
- Atribuir horário e função para cada atividade do dia seguinte
- Nenhuma decisão importante durante a execução — só execução pura
- Até almoço e criação de lista devem ser antecipados

> Grandes empreendedores levam ao extremo: marmitas prontas, roupas planejadas na véspera.

---

## Transformar Processos em Imagens

Documentos de 10 a 20 páginas são abandonados depois de uma semana. Alternativa: transformar processos em imagens visuais que o time consulta todo dia. Ferramentas: GPT e Gemini geram essas imagens a partir de descrições textuais.

---

## A Primeira Semana do Mês é Sagrada

Se a primeira semana for fraca, todo o mês será comprometido.

| Semana | Foco |
|---|---|
| **Semana 1** | Geração de demanda máxima (ligação, disparo, follow-up) |
| **Semana 2** | Boom de reuniões — aproveitar tudo gerado na semana 1 |
| **Semana 3** | Fechamento das oportunidades das semanas anteriores |
| **Semana 4** | "Hospício comercial" — fechar tudo que está aberto |

---

**Ver também:** [[Controle de Pomodoro e Gestão de Tarefas]] | [[Horizonte de Oportunidades]] | [[Metodologia Adriano Aquino]]

---
fonte: 05_Ciclo_de_Vendas
programa: Os Escolhidos
tags: [ciclo-de-vendas, lead-score, follow-up, outbound, conversão, fechamento]
---

# Ciclo de Vendas — Como Encurtar

> O outbound começa com leads frios. O erro não está no outbound em si — está em aceitar ciclos longos como inevitáveis.

**3 causas de ciclo longo:**
1. Falta de prioridade do lead (não é o momento dele)
2. Falta de clareza do problema (ele não entende a profundidade da própria dor)
3. Falta de confiança no processo (ele não confia em você ou no que você entrega)

> "Encurtar o ciclo de vendas não é pressionar o lead. É remover os atritos."

---

## Tática 1 — Lead Score (Ranqueamento)

Sistema de pontuação para cada lead agendado. **Nota de corte: 60 pontos** (escala de 100).

| Critério | Pontos |
|---|---|
| Site bem estruturado | 10 |
| Google Meu Negócio ativo | 8 |
| Capital social adequado | 6 |
| 4 ou mais colaboradores | 6 |
| Participação em webinário | 25 |
| Entrou no grupo após agendar | 15 |
| Mapeamento de conexão realizado | 15 |
| Convidou sócio/equipe | 7 |

> Abaixo de 60: BDR é obrigado a gerar mais conexão antes da reunião.

---

## Tática 2 — Mini Questionário Pré-Reunião

Após agendar a reunião, enviar um **áudio de pré-qualificação** ao lead:

1. Qual é a maior dificuldade atual da empresa?
2. O que ele gostaria de ver ou aprender na conversa?

**Resultado:** reuniões mais curtas, menos remarcações, decisões mais rápidas. Permite preparar mini proposta antes do primeiro encontro.

---

## Tática 3 — Educação via Webinário

Para quem não tem webinário: transformar a primeira reunião em um **mini webinário** — apresentação, diagnóstico e proposta panorâmica em uma só conversa. Segunda reunião: tomada de decisão direta.

---

## Tática 4 — Lista Diária por Cidade

Ao invés de prospectar múltiplas cidades por dia → trabalhar **apenas uma cidade por dia**. Cada lista vira um micromercado.

**Resultado:**
- Mais familiaridade com os leads da cidade
- Mais pontos de contato com cada decisor
- Lead percebe presença constante
- Leads avançam mais rápido porque você não some

---

## Tática 5 — Psicologia da Posse (Projeto Rolando)

Mesmo sem pagamento ou assinatura, dar a sensação de que o **projeto já está em andamento**.

**Como fazer:**
- Enviar print de reunião no Meet com a equipe discutindo o projeto
- Mostrar entregável parcial implementado (ex: primeira página de landing page)
- Documentar resultados e apresentar proativamente

> "O decisor não compra de quem está desesperado. Você deve agir como quem já está entregando."

---

## Tática 6 — Relacionamento Ativo

Não é insistência — é continuidade. Leads não avançam porque não confiam. Confiança nasce na constância.

- Manter cadência clara de follow-up
- Variar o canal se o lead esfriar (WhatsApp frio → liga)
- Mensagens de contexto e conexão — não só "e aí, fechamos?"
- Usar [[Horizonte de Oportunidades]] para organizar a cadência

---

## Tática 7 — Prazo de Desenvolvimento e Semana de Promoção

**Prazo de Desenvolvimento** — cria escassez legítima:
> "Minha equipe está toda alinhada com o seu projeto, mas só consigo segurar esse alinhamento até o fim deste mês."

**Semana de Promoção** (última semana do mês) — para propostas abertas:
- Mais 15 dias de projeto sem custo adicional
- Um entregável extra não previsto
- Desconto pontual ou facilidade de pagamento

---

## Rotina Mínima de Implementação

| Momento | Ação |
|---|---|
| Domingo/Sábado | Criar a lista da semana |
| Diariamente | Prospectar + atualizar lead score no CRM |
| Pré-reunião | Enviar áudio de pré-qualificação (mapeamento de conexão) |
| Pós-reunião | Classificar lead, definir próxima aproximação, abrir proposta se qualificado |
| Última semana do mês | Ativar semana de promoção para propostas em aberto |

---

## Impacto no Financeiro

> "Se você aplicar pelo menos três dessas táticas, o caixa vai ser muito mais rápido, o desgaste do time com leads frios vai diminuir e a previsibilidade de receita vai aumentar."

---

**Ver também:** [[Horizonte de Oportunidades]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Metodologia Adriano Aquino]]

---
fonte: 03_Controle_de_Pomodoro_e_Gestao_de_Tarefas
programa: Os Escolhidos
tags: [gestão-do-tempo, produtividade, tarefas, rafael-medeiros, pomodoro]
---

# Controle de Pomodoro e Gestão de Tarefas

> Método Rafael Medeiros (sócio de Pablo Marçal) — aumento de 40–45% de produtividade.

## A Ressignificação da Matriz Eisenhower

Rafael Medeiros simplificou os 4 quadrantes da Eisenhower para **apenas 2 categorias**.

---

## As Duas Categorias de Tarefas

### 1. Preventivas de Dor

Não geram prazer imediato, não dão dopamina, não motivam — **mas evitam perdas, caos e sofrimento futuro.**

**Exemplos:**
- Planejamento semanal
- Organização de agenda
- Follow-up com leads que estão sendo adiados
- Treinar o time comercial
- Revisar métricas
- Estudar o nicho antes de prospectar
- Criar e renovar código de cultura

> **Pergunta-chave:** "Se eu NÃO fizer isso, vai virar um problema?" → Se sim, é Preventiva de Dor.

---

### 2. Produtivas de Ganho

Geram crescimento, resultado, dinheiro, expansão e avanço real. Dão dopamina e motivam.

**Exemplos:**
- Prospecção ativa
- Executar reuniões de venda
- Gravar conteúdos para redes sociais
- Criar novas ofertas e produtos
- Fechar parcerias
- Rotina de estudos e desenvolvimento
- Criar relacionamento com o decisor

> **Pergunta-chave:** "Se EU fizer isso, vou avançar financeiramente ou estrategicamente?" → Se sim, é Produtiva de Ganho.

---

## Como Aplicar na Prática

1. Listar tudo que vai fazer no dia
2. Classificar cada atividade (Preventiva de Dor ou Produtiva de Ganho)
3. Todo dia ter pelo menos **1 de cada categoria**
4. Agendar: **Preventivas de Dor SEMPRE de manhã** → Produtivas de Ganho no turno seguinte

**Por que Preventivas vêm primeiro:**
Preventivas exigem disciplina, não motivação. Produtivas tendem a dar energia durante a execução. Se você começa com o que motiva, nunca executa o que estrutura.

---

## Erros Comuns

| Erro | Consequência |
|---|---|
| Fazer só Produtivas de Ganho | A empresa vende, mas cresce desorganizada e entra em colapso |
| Fazer só Preventivas de Dor | Fica muito organizado mas não gera receita — "organizado e pobre" |

> "Quem só vive de Produtiva de Ganho vai virar refém do próprio crescimento. Quem só faz Preventiva de Dor vai virar um organizado e pobre."

> Alta performance nasce do **equilíbrio intencional** entre os dois tipos de tarefa.

---

## Transformar Atividades em Imagens Visuais

Ao invés de documentos de 20 páginas, transforme Pomodoros e listas de tarefas em imagens geradas por IA (GPT, Gemini). O cérebro processa imagens com muito mais facilidade — o time consulta e segue o processo com muito mais frequência.

> "Pô, eu transformei todo o meu processo comercial em imagens. Documentos complexos em algo visual que todo mundo vai ter gosto de olhar."

---

**Ver também:** [[Antecipação de Decisão e Pomodoro]] | [[Metodologia Adriano Aquino]] | [[Horizonte de Oportunidades]]

---
fonte: 17_Canais_de_CAC_Zero
programa: Os Escolhidos
tags: [cac-zero, ligação, disparo, follow-up, outbound]
---

# Canais de Aquisição a CAC 0

> CAC zero = gerar clientes sem pagar por anúncios. O único recurso investido é tempo e habilidade.
> Vendedor que gera resultado com os próprios braços não depende de orçamento, algoritmo ou nada além de consistência.

---

## Os 3 Canais

### 1. Ligação — Qualidade
Canal de maior qualidade e maior velocidade de feedback.
Quando você liga, sabe imediatamente: lista boa? Horário certo? Abordagem convertendo?

**Benchmarks:**
- 15 ligações/hora
- 50% de conexão (atendimento)
- 40% de decisor após conexão
- 33–66% de reunião após decisor

---

### 2. Disparo — Volume
Canal de escala. Multiplica sua presença sem multiplicar seu tempo.
Uma boa copy gera 10–20% de resposta de decisor.

**Benchmarks:**
- 8–12% disparo → decisor
- 40–50% decisor → reunião
- Mínimo 40 disparos/dia

---

### 3. Follow-up — Aproveitamento
Transforma esforço passado em resultado presente.
Todo lead que não converteu na primeira abordagem não está descartado — está esperando o momento certo.

**Benchmarks:**
- 30–40% follow → decisor
- 50% decisor → reunião
- Mínimo 20 follows/dia

---

## Meta diária combinada
Os 3 canais funcionam em paralelo. Nenhum substitui o outro.

| Canal | Meta mínima | Meta ideal |
|---|---|---|
| Ligações | 30 | 50+ |
| Disparos | 40 | 60+ |
| Follow-ups | 20 | 30+ |

---

## Missões dos 5 primeiros dias
Primeiros 5 dias = calibração. Foco em:
1. Validar a lista (nicho certo?)
2. Validar o horário (quando o decisor atende?)
3. Calibrar o script (abordagem está convertendo?)
4. Registrar tudo no CRM
5. Identificar gargalo principal do funil

**Ver também:** [[Checklist de Execução — Pré-Segunda]] | [[Mapeamento de Conexão]]

---
fonte: 19_Compromissos_Os_Escolhidos
programa: Os Escolhidos
tags: [oae, metodologia, relatório, mentalidade]
---

# Compromissos Diários — Metodologia OAE

> Missão diária de todo Escolhido: Observar → Autoavaliar → Encontrar padrões.
> Não existe atalho. Existe método. E o método é o OAE.

---

## A Metodologia OAE

| Letra | Verbo | O que fazer |
|---|---|---|
| **O** | **Observar Tudo** | Olhar para os próprios dados sem julgamento. Ligações feitas, conexões, decisores, reuniões, follow — tudo registrado e lido com atenção |
| **A** | **Autoavaliar** | Analisar o que os dados estão dizendo. Onde está o gargalo? Topo, meio ou fundo de funil? Sem esconder resultado ruim |
| **E** | **Encontrar Padrões** | Identificar o que funciona — nos seus dados e nos dados dos outros escolhidos. Replicar o que converte |

---

## Os 4 EUs
Framework de identidade que sustenta a execução:
1. **EU executo** — faço o volume necessário todos os dias
2. **EU melhoro** — analiso e ajusto uma coisa por vez
3. **EU documento** — registro tudo para aprender e replicar
4. **EU entrego** — gero resultado real, não só esforço

---

## Relatório Diário
Todo Escolhido preenche diariamente:
- Ligações feitas
- Conexões (atendimentos)
- Decisores alcançados
- Reuniões agendadas
- Disparos enviados
- Decisores por disparo
- Reuniões por disparo
- Follow-ups feitos
- Decisores por follow
- Reuniões por follow

**Métrica derivada:** Topo (conexão/ligação), Meio (decisor/conexão), Fundo (reunião/decisor)

---

## Como analisar o funil

| Etapa | Benchmark | Abaixo indica... |
|---|---|---|
| Topo (conexão) | 50% | Lista ruim ou horário errado |
| Meio (decisor) | 40% | Abordagem com atendente fraca |
| Fundo (reunião) | 33–66% | Script com decisor ou oferta fraca |

---

## Regra de melhoria
Identifique **1 gargalo por vez**. Corrija. Valide. Passe para o próximo.
Quem tenta melhorar tudo ao mesmo tempo não melhora nada.

**Ver também:** [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Mapeamento de Conexão]]

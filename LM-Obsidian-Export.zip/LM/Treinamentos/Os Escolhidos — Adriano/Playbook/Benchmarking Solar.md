---
fonte: 22_Benchmarking_Solar
programa: Os Escolhidos
nicho: Energia Solar
tags: [solar, nicho, benchmarking, mercado]
criado: 2026-04-12
---

# Benchmarking Estratégico — Energia Solar Fotovoltaica

> Preparado para L.M Consultoria Comercial — 2026

---

## Visão Geral do Mercado

### Tamanho e escala (2025)
- 2ª maior fonte da matriz elétrica nacional
- **63,7 GW** de potência operacional acumulada
- **43,7 GW** geração distribuída (telhados/terrenos)
- **20 GW** geração centralizada (usinas)
- **R$ 282,6 bilhões** em investimentos acumulados
- **1,9 milhão** de postos de trabalho gerados

### Projeção 2026
- Adição de **10,6 GW** de nova capacidade
- Investimentos estimados: **R$ 31,8 bilhões**
- CAGR projetado 2026–2034: **12,20%**
- Meta para 2034: **164,9 GW**

### Fase atual
Amadurecimento tecnológico (S&P Global). Migração de volume (instalar potência) para qualidade da energia + integração com a rede.

---

## Por que é um nicho interessante para a L.M

- Mercado grande com volume de empresas (integradoras)
- Setor em crescimento contínuo
- Decisores acessíveis (donos de integradora = PMEs)
- Dor clara: geração de demanda qualificada B2B
- Referências e cases de sucesso facilmente verificáveis

---

## Perfil do cliente ideal (ICP)
- **Segmento:** Integradoras de energia solar
- **Porte:** PME (5–50 funcionários)
- **Dor:** Dependência de indicações, falta de processo comercial estruturado
- **Decisor:** Sócio/fundador da integradora

---

## Pontos de atenção
- Mercado com desaceleração após recorde de 2024 (pode aumentar urgência por eficiência comercial)
- Ciclo de venda pode ser mais longo em grandes projetos
- Precisa de argumentação baseada em ROI

**Ver também:** [[Critérios de Nicho]] | [[Os Escolhidos — Índice]]

---
fonte: 20_Criterios_de_Nicho
programa: Os Escolhidos
tags: [nicho, icp, outbound, mercado]
---

# Critérios para Escolher um Nicho

> Regra de ouro: você não precisa encontrar o nicho perfeito. Precisa de um nicho bom o suficiente para começar.
> Escolha **até 2 nichos** para trabalhar. Foco é o que separa quem escala de quem fica rodando em círculos.

---

## Por que o nicho define tudo

No outbound B2B você não vende para todo mundo — você **escolhe quem abordar**.
Essa escolha determina o quanto você vai trabalhar para fechar cada deal.

- Nicho ruim: ciclo longo, ticket baixo, decisor inacessível, resultado difícil de provar
- Nicho bom: ciclo curto, ticket justo, decisor acessível, resultado fácil de provar

---

## Os 8 Critérios de Avaliação

### 1. Mercado qualificado?
Empresas do nicho têm: orçamento, o problema que você resolve, e hábito de contratar soluções externas.

### 2. Decisor acessível?
Você consegue chegar no tomador de decisão sem passar por 5 filtros? Quanto mais acessível, mais eficiente o outbound.

### 3. Ticket compatível?
O ticket médio justifica o CAC de tempo do vendedor?

### 4. Ciclo de vendas razoável?
Quanto tempo do primeiro contato ao fechamento? Ciclo longo = previsibilidade difícil.

### 5. Resultado mensurável?
Você consegue provar resultado com dados? Nicho que não aceita métricas dificulta a venda.

### 6. Mercado com volume?
Tem quantidade suficiente de empresas para prospectar sem esgotar a lista rapidamente?

### 7. Dor urgente?
A dor que você resolve é urgente para o decisor, ou é "nice to have"?

### 8. Referência de sucesso?
Você já tem (ou pode conseguir) algum case nesse nicho? Prova social acelera muito o fechamento.

---

## Como usar
Pontue cada critério de 1–3 para cada nicho considerado. Some o total.
O nicho com maior pontuação merece seu foco.

**Ver também:** [[Benchmarking Solar]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]]

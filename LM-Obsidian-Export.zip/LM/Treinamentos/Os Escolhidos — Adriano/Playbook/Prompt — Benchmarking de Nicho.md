---
fonte: Engenharia reversa do "Benchmarking Solar" (Adriano Aquino)
programa: Os Escolhidos
tags: [prompt, benchmarking, pesquisa, nicho, mercado]
criado: 2026-05-11
---

# Prompt — Benchmarking de Nicho (Adriano Aquino)

> Prompt reconstruído por engenharia reversa a partir do documento `Benchmarking Solar.md` produzido pelo Adriano. Usar pra gerar benchmarking de qualquer nicho B2B pra consultoria comercial.

---

## Como usar

Substituir os campos `[INSERIR ...]` e colar em ChatGPT/Claude/Gemini com acesso à web (ou Deep Research).

---

## Prompt

```
Você é um analista de mercado B2B preparando um benchmarking estratégico de nicho para uma consultoria comercial que vende serviços de estruturação comercial pra PMEs.

NICHO ALVO: [INSERIR NICHO — ex: Energia Solar Fotovoltaica, Clínicas Odontológicas, Indústria Metalúrgica, etc.]
ANO DE REFERÊNCIA: [INSERIR ANO — ex: 2026]
CONTEXTO GEOGRÁFICO: Brasil

OBJETIVO
Produzir um documento de benchmarking enxuto (1 página) que ajude a consultoria a decidir se vale focar nesse nicho e como abordar o cliente ideal. Não é relatório acadêmico. É material de decisão comercial.

ESTRUTURA OBRIGATÓRIA (seguir nessa ordem)

1. Visão Geral do Mercado
   - Tamanho e escala no último ano fechado: posição na economia/setor, números absolutos (volume, faturamento, unidades, GW, R$ bi, empregos gerados — o que fizer sentido pro nicho)
   - Projeção pro ano corrente e próximos 12 meses: nova capacidade/crescimento esperado, investimento previsto, CAGR
   - Fase atual do mercado em uma frase: está em expansão de volume, amadurecimento, consolidação, declínio? Citar fonte de mercado reconhecida (S&P, McKinsey, ABSOLAR, Sebrae, IBGE, associação setorial, etc.)

2. Por que é um nicho interessante pra consultoria comercial
   - 4 a 6 bullets curtos cobrindo: volume de empresas no mercado, ritmo de crescimento, acessibilidade do decisor, dor comercial clara, facilidade de gerar prova social/cases, ticket potencial

3. Perfil do cliente ideal (ICP)
   - Segmento (tipo de empresa)
   - Porte (número de funcionários ou faixa de faturamento)
   - Dor principal (em linguagem do cliente, não de consultor)
   - Decisor (quem assina o contrato — cargo + perfil)

4. Pontos de atenção
   - 3 bullets sobre riscos, sazonalidades, ciclos longos, exigências de argumentação (ROI, compliance), saturação de concorrência, dependência de fatores externos

REGRAS DE ESTILO
- Bullets curtos, números em negrito (ex: **63,7 GW**, **R$ 282 bi**)
- Sem parágrafos longos. Sem enrolação corporativa.
- Citar fonte quando o número for forte (ex: "S&P Global", "ABSOLAR", "Sebrae 2025")
- Tom direto: o leitor é dono de consultoria, decide em 2 minutos se segue no nicho ou não
- Quando não tiver dado oficial, dizer "estimativa de mercado" em vez de inventar
- Português do Brasil

REGRAS DE SUBSTÂNCIA
- Priorize números recentes (último ano fechado + projeção)
- Sempre que possível, contraste volume atual vs. projeção (mostra trajetória)
- A dor do ICP precisa ser comercial (geração de demanda, processo de vendas, escala) — não operacional ou técnica
- O decisor precisa ser alguém com autonomia pra contratar consultoria (sócio/fundador, diretor comercial), não nível gerencial sem orçamento

ENTREGÁVEL
Documento em markdown seguindo exatamente a estrutura acima, com cabeçalho:

# Benchmarking Estratégico — [Nicho]
> Preparado para [Consultoria] — [Ano]

Não inclua introdução nem conclusão. Vai direto pra "Visão Geral do Mercado".
```

---

**Ver também:** [[Benchmarking Solar]] | [[Critérios de Nicho]] | [[Os Escolhidos — Índice]]

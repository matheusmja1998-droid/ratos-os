---
fonte: 01_Metodologia_Adriano_Aquino
programa: Os Escolhidos
tags: [metodologia, prospecção, cidades, produtos, decisor]
---

# Metodologia Adriano Aquino

## Prospecção por Cidades

> Erro comum: prospectar sempre as mesmas capitais com as mesmas listas que os concorrentes.

**Ordem de prioridade:**
1. Cidades com 100k+ habitantes
2. 90k habitantes
3. 80k habitantes
4. Até 50k habitantes (começa a perder potencial dependendo do nicho)

> Existe muito mercado em cidades médias — empresas que faturam R$1,5M+/mês em cidades de ~80k habitantes.

**Como funciona na prática:**
Cada cidade vira um teste de mercado. Faça 5 a 10 ligações → meça o resultado → se não houver resposta, mude de cidade.

> "Insistência muda o jogo — mas insistir no lugar errado destrói tempo e energia."

---

## Estrutura de Produtos

Uma empresa precisa ter produtos para diferentes níveis de cliente.

| Faixa | Finalidade |
|---|---|
| Abaixo de R$1.500 | **Investimento** — não lucro. Usar para: impulsionar conteúdos, gravar vídeos, construir autoridade, atrair decisores, criar audiência |
| Acima de R$1.500 | **Fluxo de caixa** — contratar closers, gestores, ferramentas, CRM, dashboards |

> Adriano tem produtos de R$500 a R$150.000 — atende empresas em momentos diferentes.

---

## A Frase que Desarma o Decisor

> Pergunta errada: "Você tem interesse?", "Topa uma reunião?", "Quer ver como funciona?"
> Essas perguntas ativam o modo de defesa — o decisor pensa em não perder tempo.

**A frase certa:**
> "Gostaria muito que sua empresa estivesse entre elas. Seria uma honra conversar contigo. Como está sua agenda na próxima semana?"

**Os 3 gatilhos ativados:**
| Gatilho | O que gera |
|---|---|
| **Relevância** | Você não pede interesse — mostra que escolheu aquela empresa |
| **Exclusividade** | O decisor se sente valorizado → reciprocidade natural |
| **Ação imediata** | Ao perguntar sobre a agenda, ele pensa "quando posso?" — não "eu quero isso?" |

---

## Metodologia do Espectador

A cada 15 dias ou 1x/mês: saia da operação e olhe o negócio como investidor, consultor externo ou cliente oculto.

**O que analisar:**

| Área | Pergunta |
|---|---|
| Prospecção | Existe processo claro e documentado ou é tudo improviso? |
| Cultura | Existe cultura forte ou caos? (Criar 7 a 10 códigos culturais) |
| Processo comercial | Os closers conduzem a reunião ou é o lead que conduz? |
| Estrutura de produtos | Há produtos para empresa pequena, média e grande? |
| Resultado do cliente | Os clientes estão tendo transformação real? |
| Métricas | Média de ligações, produtividade, presença e autoridade do vendedor |

---

## Mensagem central

> "Muitas empresas têm bons serviços e capacidade técnica, mas não crescem. O problema não é capacidade — é falta de direção, método, acompanhamento e estrutura de crescimento."

**Ver também:** [[Antecipação de Decisão e Pomodoro]] | [[Horizonte de Oportunidades]] | [[Ciclo de Vendas — Como Encurtar]]

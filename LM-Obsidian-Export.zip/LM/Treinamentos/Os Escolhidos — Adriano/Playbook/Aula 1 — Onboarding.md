---
fonte: 05_Adriano_Aula1_Onboarding
data: 2026-03-21
tipo: aula
programa: Os Escolhidos
tags: [onboarding, rotina, performance, relatório]
---

# Aula 1 — Onboarding (21/03)

## Cultura do programa
> "A nossa cultura não é formada por gênios — mas todo mundo é esforçado pra caramba. A gente executa tanto que é inevitável não alcançar um resultado estratosférico."

## Referências de performance do programa
- Gabriel Trida, David e Keyla: **8+ reuniões/dia** — membros avançados do time
- Eles acompanham os novos durante a primeira semana

## Meta do programa
**50 reuniões/semana** por vendedor — sozinho, sem tráfego pago.

## O que Adriano ensina nessa aula
1. **Rotina de performance** — como aumentou a performance dele e do time
2. **Check-in diário** — relatório que todo escolhido preenche
3. **Como funciona o mapa mental** do sistema outbound

## Premissa central
> A maior dor de vocês é não gerar demanda suficiente. Não ter reuniões na agenda.
> Isso é resolvível com método e execução — não com sorte ou talento.

## Próximos passos após onboarding
- [ ] Configurar checklist pré-segunda (ver [[Checklist de Execução — Pré-Segunda]])
- [ ] Entender os 3 canais (ver [[Canais CAC Zero — Ligação, Disparo e Follow-up]])
- [ ] Definir nicho (ver [[Critérios de Nicho]])
- [ ] Começar relatório diário (ver [[Compromissos e Metodologia OAE]])

**Ver também:** [[Super Aulão — 28-03]] | [[Os Escolhidos — Índice]]

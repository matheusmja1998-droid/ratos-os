---
fonte: 18_Checklist_de_Execucao
programa: Os Escolhidos
tags: [checklist, execução, preparação, outbound]
---

# Checklist de Execução — Execute Antes de Segunda

> Vender sem estrutura é como dirigir sem GPS — você sai do lugar, mas chega tarde, cansado e no lugar errado.
> Tudo precisa estar pronto **antes de começar a prospectar**.

---

## Os 7 Passos

### Passo 1 — Remodelar o script para o seu nicho
O script base funciona em múltiplos nichos, mas o que converte é o script adaptado para:
- Linguagem do nicho
- Dores específicas
- Contexto do decisor

- [ ] Script adaptado e memorizado

### Passo 2 — Criar o convite/flyer da sua empresa
Material visual que você vai usar nos disparos e follow-ups.
- [ ] Convite/flyer criado

### Passo 3 — Comprar a ferramenta de disparo (PRIORIDADE)
Sem ferramenta de disparo, você não escala o canal de volume.
- [ ] Ferramenta contratada e configurada

### Passo 4 — Criar o fluxo de disparo e gravar o áudio
O áudio é o coração do disparo. Um áudio fraco = nenhuma reunião, mesmo com lista boa.
- [ ] Fluxo de disparo montado
- [ ] Áudio gravado e validado

### Passo 5 — Criar listas de ligação e disparo qualificadas
Lista ruim = esforço sem retorno. Qualificar antes de prospectar.
- [ ] Lista de ligação criada e qualificada
- [ ] Lista de disparo criada e qualificada

### Passo 6 — Configurar CRM (Notion ou Planilha)
Sem CRM, você não tem dados. Sem dados, você não melhora.
- [ ] CRM configurado com campos: Nome da empresa, Atendente, Decisor, Horário, Status

### Passo 7 — Acessar o CRM de Rankeamento Os Escolhidos
- [ ] Acesso confirmado e perfil atualizado

---

## Regra
Sem esses 7 passos completos = não começa a prospectar.
Sem desculpa. Sem improviso.

**Ver também:** [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Mapeamento de Conexão]]

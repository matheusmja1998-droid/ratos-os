---
fonte: 07_Treinamento_de_POPs
programa: Os Escolhidos
tags: [pops, processo, padronização, script]
---

# Treinamento de POPs

## O que são POPs
Procedimentos Operacionais Padrão — os scripts e processos padronizados para a execução do outbound.
POPs garantem que o time execute de forma consistente, independente do humor ou do dia.

## Ver documento original
Arquivo: 07_Treinamento_de_POPs.docx

## Aplicação na L.M
- [ ] Mapear os POPs que o time já usa (mesmo que informalmente)
- [ ] Documentar POPs de ligação, disparo e follow-up
- [ ] Revisar e atualizar a cada ciclo de análise de métricas

**Ver também:** [[Checklist de Execução — Pré-Segunda]] | [[Mapeamento de Conexão]] | [[Compromissos e Metodologia OAE]]

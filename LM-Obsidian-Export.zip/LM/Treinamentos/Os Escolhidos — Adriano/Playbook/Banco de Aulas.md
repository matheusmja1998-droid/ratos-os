---
fonte: 16_Banco_de_Aulas
programa: Os Escolhidos
tags: [banco-de-aulas, referência, gargalo]
---

# Banco de Aulas — Os Escolhidos

> Não assista por obrigação. Assista quando travar.
> Identifique onde está o gargalo e vá direto para a aula que resolve aquilo.

---

## Aulas disponíveis

| Aula | Foco | Quando usar |
|---|---|---|
| **Antecipação de Decisão** | Organizar agenda para executar sem decidir na hora H | Quando procrastina na hora de prospectar |
| **Controle de Pomodoro** | Mapear melhores pomodoros e proteger tempo de prospecção | Quando perde foco ou produtividade |
| **Aulão dos Escolhidos** | Metodologias completas para agendar mais reuniões | Aula mais completa — assistir no início |
| **Prospecção Afiada** | Mindset e execução de alta performance | Quando resultados estagnaram |
| **Análise de Gravação + Áudio** | Refinamento de abordagem com base na própria voz | Quando taxa de conversão está baixa |

---

## Como usar o banco
1. Identifique em qual etapa do funil está o seu gargalo (topo, meio ou fundo)
2. Encontre a aula correspondente
3. Assista e aplique imediatamente
4. Meça o impacto no relatório diário

**Ver também:** [[Os Escolhidos — Índice]] | [[Compromissos e Metodologia OAE]]

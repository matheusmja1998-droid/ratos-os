---
fonte: 08_Super_Aulao_Escolhidos
data: 2026-03-28
tipo: aula
programa: Os Escolhidos
duração: 193 min
tags: [aulão, metodologia, reuniões, outbound]
---

# Super Aulão dos Escolhidos — 28/03

## Sobre
Aulão completo de sábado, 193 minutos. Adriano Aquino + time.
A aula mais completa do banco — cobre metodologias para agendar mais reuniões.

## Participantes
- Adriano Aquino (Ascend Sales)
- Matheus Keller
- Time Os Escolhidos

## Ver gravação
Arquivo: 08_Super_Aulao_Escolhidos.docx

## Temas abordados
- Metodologias avançadas de prospecção outbound
- Como agendar mais reuniões com o mesmo volume de esforço
- Refinamento de abordagem baseado em dados do time

**Ver também:** [[Banco de Aulas]] | [[Aula 1 — Onboarding]] | [[Os Escolhidos — Índice]]

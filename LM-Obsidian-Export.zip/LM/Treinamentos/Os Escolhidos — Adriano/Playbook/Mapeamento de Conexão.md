---
fonte: 21_Mapeamento_de_Conexao
programa: Os Escolhidos
tags: [ligação, decisor, mapeamento, crm]
---

# Mapeamento de Conexão

> **Regra fundamental:** Cada ligação atendida = 1 decisor mapeado.
> Não existe ligação neutra. Se você desligou sem mapear, desperdiçou a oportunidade.

---

## O que é Mapeamento de Conexão

Técnica de extrair, em cada ligação, as informações estratégicas que permitem voltar àquela empresa com contexto, preparo e a rota certa até o decisor.

**Sem mapear:** você liga de novo começando do zero, como se fosse a primeira vez. Perde credibilidade. Gasta o dobro de tempo.

**Com mapeamento:** você entra na segunda ligação sabendo o nome de quem decide, o horário certo para falar, e por onde chegar.

---

## Os 6 Campos Obrigatórios (CRM)

| # | Campo | Por que importa |
|---|---|---|
| 1 | **Nome da atendente** | Chamar pelo nome quebra o padrão e aumenta chance de passar |
| 2 | **Nome do decisor** | Sem esse nome você está atirando no escuro |
| 3 | **Horário que ele estará** | Chegar na hora certa vale mais do que ligar 10x no horário errado |
| 4 | **Número de atendimento ou pessoal** | Elimina o filtro da recepção |
| 5 | **Como abordar o decisor** | Contexto específico para aquela empresa |
| 6 | **Status da conta** | Próximo passo definido, nunca deixar em aberto |

---

## Na prática

**Ao ser atendido pela recepcionista:**
Antes de tentar chegar no decisor → extraia os campos 1, 2, 3 e 4.
Mesmo que não passe hoje, na próxima ligação você entra com vantagem.

**Ao falar com o decisor:**
Preencha os campos 5 e 6.
Defina sempre o próximo passo antes de desligar.

---

## O que diferencia vendedor comum de top performer
- Comum: liga, não passa, descarta a conta
- Top performer: liga, mapeia, volta preparado, fecha

**Ver também:** [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Compromissos e Metodologia OAE]]

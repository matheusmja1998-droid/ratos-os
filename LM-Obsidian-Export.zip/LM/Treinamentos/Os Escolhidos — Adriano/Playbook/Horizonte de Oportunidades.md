---
fonte: 04_Horizonte_de_Oportunidades
programa: Os Escolhidos
tags: [leads, funil, CRM, priorização, outbound, H1-H2-H3]
---

# Horizonte de Oportunidades

> Operações de outbound não falham por falta de esforço — falham por **desorganização de oportunidade**.
> O maior erro: tratar todos os leads como se tivessem o mesmo nível de urgência.

> "Não foi falta de interesse do cliente. Foi falta de time do vendedor."

---

## Os Três Horizontes

### H1 — O Hoje

Leads com alta intenção e prontidão imediata. Oportunidades na cara do gol.

- Leads gerados nas últimas 24 horas
- Respostas recentes no WhatsApp
- Follow-ups imediatos agendados
- Pedidos diretos de conversa

**Regra do H1:** não pode esperar mais de 24 horas (dias úteis).
**Objetivo:** gerar conversa — não ainda marcar reunião, apenas conversa.

---

### H2 — A Semana

Leads quentes e qualificados, mas sem urgência imediata. Zona de evitar o limbo.

- Leads que não responderam em 24 horas
- Contatos que pediram mais tempo
- Follow-up de 2 a 7 dias

**Objetivo:** transformar volume em reuniões (R1 e R2).

---

### H3 — O Mês

Leads com alto potencial, mas com ciclo de vendas longo. Empresas qualificadas com tickets maiores.

- Propostas de R$ 9.000 a R$ 20.000+ que levam semanas para fechar
- Leads que passaram por H1 e H2 sem urgência
- Empresas de ICP máximo (3 estrelas)

**Objetivo:** nutrir, educar e amadurecer até a venda virar inevitável.

> "H3 é o abrigo da riqueza futura. Ignorar o H3 é sacrificar o faturamento do próximo trimestre."

---

## Os Percentuais de Cada Horizonte

A partir de 100 novas oportunidades geradas em um dia:

| Horizonte | % | Resultado esperado |
|---|---|---|
| **H1** | 20% | 20 reativações para gerar conversa no dia seguinte |
| **H2** | 30% das conversas | ex: 6 novas reuniões R1 |
| **H3** | 50% das reuniões | ex: 3 propostas de alto ticket |

> Com ticket médio de R$ 9.000 → R$ 27.000 em proposta aberta por dia trabalhado.

---

## O Ciclo Mensal com os Três Horizontes

| Semana | Foco |
|---|---|
| **Semana 1** | Foco total em H1 — geração de demanda absurda |
| **Semana 2** | Boom de reuniões — H2 em ação, transformando volume em R1 |
| **Semana 3** | Manter reuniões e começar a encurtar ciclos — H3 ativo |
| **Semana 4** | "Hospício comercial" — fechar tudo que está em proposta (H3) |

---

## Como Classificar Leads na Planilha

| Critério | Ação |
|---|---|
| ICP 1 estrela | Empresa pouco qualificada — não vale investir tempo |
| ICP 2 estrelas | Empresa moderada — seguir até H2 |
| ICP 3 estrelas | Empresa altamente qualificada — levar até H3 |
| +5 dias sem resposta | → H2 |
| ICP 3 estrelas + 7 dias sem resposta | → H3 |
| 10 follow-ups sem resposta | → Pausar e deixar de molho |

---

## Como Gerar Urgência em Leads de H3

Leads de H3 não têm urgência por natureza. Para criar urgência: perguntas de **implicação** — tensione a dor mostrando o impacto financeiro de continuar com o problema.

> "Se você continuar assim, em um ano você perde 60% da sua base de clientes. O que isso representa no seu faturamento?"

---

## Antecipação de LTV

Prefira vender em implementação única ao invés de recorrência quando possível.

> Um projeto de 2 meses por R$ 6.000 é melhor do que 3 parcelas de R$ 2.000 — você antecipa o LTV, o cliente prefere pagar de uma vez, melhora o fluxo de caixa e facilita a negociação.

---

**Ver também:** [[Ciclo de Vendas — Como Encurtar]] | [[Antecipação de Decisão e Pomodoro]] | [[Metodologia Adriano Aquino]]

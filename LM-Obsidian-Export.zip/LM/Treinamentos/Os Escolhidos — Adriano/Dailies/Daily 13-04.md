---
fonte: Daily_13_04
data: 2026-04-13
tipo: daily
programa: Os Escolhidos
instrutor: Adriano Aquino
participantes: [Martin Vargas, Muriel Henrique, Pedro Cezaretto]
foco: Análise de scripts de prospecção, roleplay com ajustes e feedbacks
---

# Daily 13/04

## Foco da sessão
Análise de scripts de prospecção, roleplay com ajustes e feedbacks individuais por nicho.

---

## Participantes em Simulação

- **Martin Vargas** — Comunicação Visual
- **Muriel Henrique** — Energia Solar
- **Pedro Cezaretto** — LM Agência

---

## Feedbacks por Participante

### Martin Vargas — Comunicação Visual

**Pontos Fortes:**
- Tom de voz excelente como diretor
- Mapeamento correto do nome do decisor
- Estrutura clara da proposta

**Melhorias:**
1. Usar explicitamente "Eu tenho um convite para..." — desarma o prospect
2. Pedir permissão de tempo: "Você tem dois minutos?"
3. Usar o nome do prospect a cada tópico importante (prende atenção)
4. Fazer 1-2 perguntas de qualificação após confirmar interesse (ex: "Quantos funcionários?")
5. Quando há objeção, oferecer pré-agendamento via WhatsApp

**Métrica:** Meta de 5 reuniões. Lista "quente" de 30 pessoas já com R1/R2 — foco em follow-up e gravação de ligações.

---

### Muriel Henrique — Energia Solar

**Pontos Fortes:**
- Script bem estruturado e conhecimento profundo do nicho
- Boa gestão de objeções
- Explicação clara dos tópicos

**Melhorias:**
1. Tom com atendente: menos afiado, mais colaborativo ("vai me ajudar" vs. "repassar pra ele")
2. Qualificar com a atendente: "Quantas pessoas trabalham aí?"
3. Repetir o nome do prospect a cada 2-3 tópicos
4. Pedir permissão antes de explicar: "Você tem dois minutos?"
5. Usar ordem: "Repassa para ele, por favor" (não pedido)
6. Após conseguir o WhatsApp, comunicar por mensagem/áudio — não por ligação
7. Sempre mencionar número de empresas convidadas: "Já convidei 30+ empresas de energia solar"

**Insight:** Pessoas têm mais medo de PERDER do que de GANHAR. Exclusividade = senso de urgência.

---

### Pedro Cezaretto — LM Agência

**Pontos Fortes:**
- Boa gestão de objeção (perguntou "por que não quer?")
- Controle da conversa ("Seu time comercial tá alinhado?")
- Explicação clara de value (não é marketing, é vendas/operação)

**Melhorias:**
1. Seguir o script base — improvisar fora do script faz perder referência
2. Mapeamento de nome: perguntar "Como ele chama?" é crítico
3. Ser específico nas dores — evitar termos vagos ("extrair 100%", etc.)
4. Confirmação clara do canal: e-mail ou WhatsApp de forma consistente

---

## Framework de Prospecção (Adriano Aquino)

### Etapas da Ligação

1. **Abertura** → "Oi, aqui é [nome], [título] em [empresa]"
2. **Mapeamento** → Nome da atendente, do decisor, horário disponível
3. **O Convite** → "Tenho um convite EXCLUSIVO para o responsável... seria com você?"
4. **Permissão** → "Você tem dois minutos?"
5. **Explicação (3 tópicos)** → Dor → Solução → Exclusividade
6. **Nome repetido** → A cada tópico principal
7. **Qualificação** → "Quantos funcionários? O que gostaria de aprender?"
8. **Pré-agendamento** → WhatsApp para confirmar horário
9. **Follow-up** → Mensagem, não ligação

### Elementos-Chave

| Elemento | Aplicação |
|---|---|
| Frase de dor | "Porque tem muito dono que tá cansado de..." |
| Exclusividade | "Já convidei 30-50-100 empresas e você foi selecionado" |
| Ordem vs. pedido | "Repassa para ele" (ordem) — não "Você consegue repassar?" |
| A palavra "convite" | Baixa a guarda — prospect não percebe como venda |

---

## Insights do Adriano

1. **Nomes fixam atenção** — Neurociência: ouvir o próprio nome aumenta foco
2. **Exclusividade gera urgência** — Número de empresas convidadas cria FOMO
3. **Você dirige, não implora** — Pedir permissão não significa perder o controle
4. **Atendente é aliada** — Tratá-la bem é o que abre caminho até o decisor
5. **Analisar as piores ligações** — Não as boas — para feedback mais efetivo

---

## Próximas Ações

- [ ] **Todos** — Gravar calls (especialmente as piores) para análise coletiva
- [ ] **Hoje às 17h** — Análise de gravações de ligações
- [ ] **Martin** — Disparar 30-40 contatos, meta de 5 reuniões
- [ ] **Muriel** — Prospectar a partir das 9h
- [ ] **Pedro** — Alinhar script com padrão da squad

**Ver também:** [[Daily 02-04]] | [[Os Escolhidos — Índice]] | [[Metodologia Adriano Aquino]]

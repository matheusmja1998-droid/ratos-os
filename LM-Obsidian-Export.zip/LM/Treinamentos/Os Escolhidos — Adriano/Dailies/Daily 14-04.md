---
fonte: Daily_14_04
data: 2026-04-14
tipo: daily
programa: Os Escolhidos
instrutor: Adriano Aquino
participantes: [Martin, Micael, Valentino (Tino), Kallyl Bertolino, Matheus Henrique, Marcos Aurelio, Muriel Henrique]
foco: Análise individual de relatórios de prospecção — métricas de funil, gargalos e plano de ação
---

# Daily 14/04

## Foco da sessão
Revisão dos relatórios individuais de prospecção: topo, meio e fundo de funil. Diagnóstico de gargalos por participante e definição de metas do dia.

---

## Benchmarks utilizados pelo Adriano

| Métrica | Benchmark mínimo | Benchmark ideal |
|---|---|---|
| Fundo de funil (decisor → reunião) | 33% | 50–66% |
| Follow-up (decisor → reunião) | 50% | 50% |
| Decisores por hora | 4 | 4+ |
| Disparos diários | 40 | 40–50 |
| Média de mercado (decisor → reunião) | 10% | — |

---

## Análise por Participante

### Martin
**Resumo:** falou com 12 decisores, agendou 3 reuniões (25% — abaixo do benchmark mínimo de 33%).

**Gargalos:**
1. Ritmo de discagem baixo — 7 ligações/hora (precisa aumentar)
2. Fundo de funil fraco por ligação — 25%
3. Leads esfriaram: contatos quentes de meses atrás sem reabordagem adequada

**Leads esfriando — como resolver:**
- Variar o canal (se veio por ligação, abordar por áudio/mensagem agora)
- Trazer novo contexto: novo motivo real para contato depois de meses
- 3 elementos para reabordagem: **novo ângulo de valor + urgência real + baixo comprometimento**

**Plano de ação:**
- Criar abordagem específica para lead frio (enviar para Adriano aprovar)
- Trabalhar as frases-chave no fundo de funil
- Ativar disparos: 40–50 enviados
- Confirmar reunião pendente no WhatsApp
- Meta: 5 reuniões

---

### Micael
**Resumo:** 1 reunião em 50 minutos. Zero ligações. 20 disparos, 5 decisores, 0 reuniões por disparo. 7 follow-ups, 7 decisores, 1 reunião.

**Gargalos:**
1. Zero ligação — canal completamente inativo
2. Não tem mensagem para conduzir o decisor do disparo até a reunião
3. Objeções sem resposta: "já tem empresa que faz isso" e "não tem interesse"
4. Volume geral insuficiente (50 min apenas)

**Erro crítico:** Abrir a abordagem revelando que é de uma assessoria/empresa — entrega o jogo logo de cara.

**Como contornar objeção "não tem interesse":**
> "Eu entendo que você não tem interesse. Mas o que faria você ter interesse? Seria uma honra ter essa conversa com você."

**Plano de ação:**
- Memorizar as duas respostas de objeção
- Ligar para os 5 decisores que não converteram
- Separar montagem de reunião do bloco de prospecção
- 60 disparos hoje (se chip cair, faz 40–50)
- Seguir documento de fluxo de reativação (fixado no grupo)
- Aula recomendada: **Dia 4 da trilha — "Como fazer follow-up agressivo"**
- Meta: 3–4 reuniões

---

### Valentino (Tino)
**Resumo:** 2 reuniões em 2 horas (ambas por ligação). Disparo zerado. Lista ruim forçou requalificação no dia.

**Gargalos:**
1. Lista ruim — consumiu o dia inteiro em requalificação (deveria ter sido feito no fim de semana)
2. Disparo zerado — canal mais forte completamente inativo
3. Follow-up fraco no dia (ponto que era forte do Tino)

**Critério de qualificação de lista:** não prospectar empresas com menos de 9 avaliações no Google. Limite manual de disparos do chip: ~20 por sessão.

**Plano de contingência para chip:**
- Ter pelo menos 1 chip secundário em maturação (aguardar 15 dias para aquecer)
- Usar Dolphin Antidetect com perfis separados por chip no Chrome
- Meta: 5 chips ativos (referência: Adriano usa 4–5 chips com perfis diferentes)
- Restrições de 24h não bloqueiam o número permanentemente — é seguro continuar

**Plano de ação:**
- Montar lista qualificada hoje
- Reativar disparo (20 envios manuais) + ligação para quem responder
- Não abordar 2 decisores queimados de ligação
- Reavaliar base de follow-up com novo critério de qualificação
- Proteger 3 horas de prospecção
- Aula recomendada: **"Gestão por Indicadores"**
- Meta: 10 reuniões

---

### Kallyl Bertolino (Calil)
**Resumo:** Zero horas de prospecção. Dia dedicado a operacional (imobiliária) e confirmação de reuniões com BDRs. 4 follow-ups de ligação para reuniões do dia.

**Contexto:** Novo BDR (Arthur) entrando hoje. Time: 3 BDRs (2 atuais + Arthur).

**Plano de ação:**
- Proteger bloco fixo de prospecção na agenda
- Meta do time hoje: 6 novas reuniões (2 por BDR)
- Colocar os 3 BDRs na sala do Discord (sala "G-Compass" já criada)
- Acelerar recrutamento do BDR
- Aula recomendada: **"Descentralização de Comando"** (como tirar o comando de si e delegar)
- Meta pessoal: 4 reuniões

---

### Matheus Henrique
**Resumo:** 2 reuniões em ~1h15. Nicho: energia solar. Problema principal: horário e cidade errados de manhã, conexão baixa.

**Métricas:** 30 ligações, 7 conexões, 15 disparos, 1 decisor por disparo, 9 follow-ups → 1 decisor → 1 reunião.

**Gargalos:**
1. Prospectando nas cidades erradas de manhã (atendimento ruim)
2. Disparo com 6% de conversão para decisor (precisa melhorar a mensagem)
3. Volume baixo: apenas 1 hora de prospecção

**Divisão ideal do dia:**
- **Manhã:** follow-up (confirmar reuniões, reativar leads) — evitar novas ligações
- **Tarde:** novas prospecções (conexão melhor nesse horário)

**Plano de ação:**
- Resolver lista antes de fazer mais ligações
- Ligar para decisora do follow no dia seguinte cedo
- Adicionar critério de ICP à lista
- Aumentar disparo para 40 com lista qualificada
- Aula recomendada: **"Oceano Azul da Prospecção" (Dia 2 da trilha)** — critérios de ICP e como aumentar o ritmo
- Meta: 4 reuniões

---

### Marcos Aurelio
**Resumo:** melhor performance do mês em 2 horas. 15 reuniões/preenchimentos. Canal forte: disparo + follow-up de disparo.

**O que funcionou:** disparou 65 mensagens no fim de semana → converteram em massa na segunda-feira.

**Insight estratégico — padrão descoberto:**
> Disparar no fim de semana → prospects veem no FDS e respondem na segunda. Segunda-feira = alta taxa de resposta.

**Métricas:** 15 novos disparos → 8 decisores → 3 reuniões. 40 ligações de follow → 6 atenderam → 3 reuniões (50% fundo de funil). 65 disparos da base anterior → a maioria das 15 reuniões veio daí.

**Gargalos:**
1. Lista de ligação fraca — 15% de conexão (20 ligações/hora)
2. Follow-up por mensagem abaixo do potencial — fluxo de nutrição pós-agendamento não estruturado

**Sobre o fluxo de nutrição:** Marcos quer ter mensagens para nutrir os leads entre o agendamento e a reunião. Adriano já enviou manual de follow-up de nutrição de webinário no sábado — pode replicar para reuniões.

**Plano de ação:**
- Enviar para Adriano (privado) o fluxo atual de nutrição para revisão
- Reservar horário fixo diário para envio de nutrição
- Aumentar volume de disparos diários
- Canal prioritário: disparo + follow por mensagem (não ligação para primeiro contato)
- Meta: acima de 15 reuniões

---

## Iniciativa da turma — Call das 11h
Tino propôs call informal às 11h entre os alunos para revisão da manhã e ajuda mútua. Adriano apoiou mas não poderá participar (call de recrutamento no mesmo horário). Combinar no grupo.

---

## Alunos abaixo da média (segundo Adriano)
Valkyrie e Kallyl. Muriel, Arthur e Diogo estão entrando agora (dados ainda incompletos).

---

## Princípios reforçados

1. **Volume é a base de tudo** — não há técnica que compense falta de volume
2. **Nunca deixar um canal zerado** — disparo, ligação e follow-up todos os dias
3. **Leads frios precisam de novo motivo** — não usar o mesmo script de primeiro contato
4. **Separar blocos** — prospecção, montagem de proposta e nutrição em horários distintos
5. **Gravar as ligações** — especialmente as piores, para análise e melhoria
6. **Disparar no fim de semana** — retorno alto na segunda-feira

---

## Proximas Acoes

- [ ] **Todos** — 40 disparos/dia (200/semana mínimo)
- [ ] **Todos** — seguir documento de fluxo de reativação (fixado no grupo)
- [ ] **Martin** — criar abordagem de reabordagem de lead frio e enviar para Adriano
- [ ] **Micael** — assistir aula Dia 4 da trilha (follow-up agressivo)
- [ ] **Tino** — montar plano de contingência de chips (Dolphin Antidetect)
- [ ] **Kallyl** — adicionar BDRs no Discord (sala G-Compass), assistir aula de descentralização
- [ ] **Matheus H.** — assistir Oceano Azul da Prospecção (Dia 2)
- [ ] **Marcos** — enviar fluxo de nutrição para Adriano revisar, reservar horário diário de nutrição

**Ver tambem:** [[Daily 13-04]] | [[Os Escolhidos — Índice]] | [[Metodologia Adriano Aquino]]

---
fonte: Daily_Meet_15_04
data: 2026-04-15
tipo: daily
programa: Os Escolhidos
participantes: [Adriano (Ascend Sales), Valentino, Micael, Kallyl, Regis, Lohane, Marcos]
duração: 40 min
---

# Daily 15/04 — Análise de Métricas do Time

## Recado geral do Adriano
- Poucas pessoas mandando métricas — é inegociável, mandar todo dia independente do resultado
- Métricas são a base de qualquer análise; sem elas, não dá pra melhorar

---

## Valentino (Tino) — Melhor performance do dia

### Métricas (2h de prospecção)
- 31 ligações | 10 conexões | 9 decisores | 7 reuniões novas
- 6 disparos | 1 decisor | 1 reunião
- 7 follow-ups | 2 conexões | 1 decisor | 1 reunião
- **Total: 11 decisores → 9 reuniões (81% de aproveitamento)**
- Topo 32% | Meio 90% | Fundo 77%

### Análise
- Melhor performance desde que entrou no programa
- Script adaptado ao nicho → decisores com muito mais disposição
- Ponto negativo: só 6 disparos (pouca lista disponível) e 7 follow-ups (baixo)
- Quando o decisor responde no disparo, ele liga na hora → tática validada
- Hipótese: com 50 ligações e topo de 50%, teria agendado ~17 reuniões

### Ações para hoje
- Mínimo 20–21 follow-ups por ligação
- Até 20 disparos manuais (trocar mensagem inicial pra não tomar restrição)
- Reabastecer lista com mais contatos

---

## Micael — Resultado fraco por falta de volume

### Métricas
- 0 ligações | 30 min prospectando
- 20 disparos | 7 decisores | 1 reunião (35% de decisores)
- Tomou bloqueio no chip

### Análise
- Taxa de decisor de 35% é excelente — se mantivesse 100 disparos, teria ~5 reuniões
- Conversão de decisor→reunião travada nos mesmos 13–14% desde semana passada
- Problema: não sabe responder objeções → fica perdendo reunião na mão
- Objeções que aparecem sempre: *já tem empresa*, *sem interesse*

### Ações para hoje
- Resolver chip (ter chip reserva sempre)
- Ligar para os 6 decisores que responderam e não agendaram
- **Criar documento com objeções mapeadas + resposta pra cada uma** (prioridade)
- Protecer 2h mínimas de prospecção
- 50–60 disparos por dia
- Gravar ligação para análise na sexta

---

## Kallyl — Zero métricas

### Situação
- Fez 3 reuniões de manhã + parte operacional presencial à tarde
- Amanhã tem 6 reuniões agendadas
- Ainda não acertou o disparo

### Ações para hoje
- Achar brecha no dia pra consertar o disparo
- Gravar tela com o disparo (da primeira mensagem ao decisor) e mandar pro Adriano

---

## Regis — Boa conversão, volume muito baixo

### Métricas (1h de prospecção)
- 11 ligações | 2 conexões | 1 decisor | 1 reunião
- 0 disparos | 0 follow-ups
- Topo 18% | Meio 50% | Fundo 100%

### Análise
- Amostragem muito pequena pra tirar conclusão sólida
- Quando atendido, tem bom jogo de cintura pra chegar no decisor e agendar
- Erro provável: lista inadequada ou horário errado
- Com 20 ligações e topo a 52% → teria agendado ~4 reuniões
- Média do mercado: 60 ligações pra 1 reunião; 100 disparos pra 1 reunião

### Ações para hoje
- 2h30 de prospecção mínimo
- Trocar lista
- Gravar as próximas 3 ligações e mandar pro Adriano
- Implementar timer entre ligações (máx. 3 min)
- Implementar disparo hoje

---

## Lohane — Pior dia, mesmo resultado em 3 cidades diferentes

### Métricas (1h)
- ~40 ligações | 6 conexões | 0 decisores | 0 reuniões
- 0 disparos | 0 follow-ups

### Análise
- Mudou de cidade e manteve o mesmo resultado → erro pode ser no nicho ou horário
- Ritmo de ligação é bom (40 ligações), mas prospectou em horário errado
- Objeções recorrentes: patrão viajando, atendente não passa contato
- Adriano deu resposta pra cada objeção no relatório

### Ações para hoje
- Mandar script + gravar tela do disparo pro Adriano
- Ativar 30–40 envios de mensagem
- Memorizar respostas pras objeções (atendente desligou / patrão viajando / sem contato do dono)
- Trocar fonte da lista
- Insistir mais: caixa postal → chama no WhatsApp → se não responder, liga 2–3x no mesmo dia

---

## Marcos — Evolução expressiva, gargalo no CRM

### Métricas
- Dia 14: 15 enviados | 8 decisores | 3 reuniões (37% fundo)
- Dia 15 (ontem): enviados similares | 10 decisores | 7 reuniões (70% fundo)
- Follow-up por ligação: 66% de conversão decisor→reunião
- Follow-up por mensagem: ~20% de conversão

### Análise
- Fundo de funil mais que dobrou de um dia pro outro
- Lista mais qualificada → decisores com mais intenção de agendar
- Gargalo primário: CRM manual → perde tempo procurando lead no WhatsApp
- Follow-up por mensagem tem 40% menos performance que follow-up por ligação

### Ações para hoje
- 1h automação CRM (tagging automático + follow automático)
- Depois, voltar à prospecção — não gastar o dia todo em setup
- Fazer follow-up por ligação, não só por mensagem
- Assistir aula: **Gestão por Indicadores** (trata métricas de inbound e outbound)

---

## Conceitos e táticas mencionados

**Chip reserva / plano de contingência:**
Ter 4–5 chips pré-aquecidos (2 semanas de maturação, 20 disparos/dia cada). Se tomar bloqueio, não para.

**Tática quando toma restrição:**
Ligar pro decisor/atendente e pedir pra ele te mandar um "oi" — isso reabre a conversa e você consegue mandar mensagem normalmente.

**Fórmula 1 das listas:**
Sempre ter lista reabastecida pronta pra entrar quando a atual acabar. Troca em segundos, sem parar o ritmo.

**Horário ideal de prospecção:**
Manhã é o melhor turno — atendentes chegaram, dono está lá, ninguém está estressado. Exceção: delivery (hamburgueria, pizzaria) → manhã só pra disparo, ligação à tarde.

**Mínimo diário:**
- 2h de prospecção ativa (inegociável)
- Métricas enviadas todo dia pro Adriano

---

## Faltou mandar métricas
- Diogo
- Muriel
- Matheus Jardim
- Valkyrie

**Ver também:** [[Daily 25-03 — Análise de Disparos]] | [[Os Escolhidos — Índice]]
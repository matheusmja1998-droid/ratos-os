---
fonte: 11_Daily_Analise_Metricas
data: 2026-03-24
tipo: daily
programa: Os Escolhidos
participantes: [Adriano Aquino, Matheus, Allyson, Kallyl]
---

# Daily 24/03 — Análise de Métricas

## Foco da sessão
Adriano analisando métricas individuais do time. Planejamento de trimestre.

## Análise do Matheus (dia 1 dos Escolhidos)
| Métrica | Resultado | Benchmark | Status |
|---|---|---|---|
| Ligações | 40 | — | ✅ |
| Conexões | 15 | 50% | ⚠️ abaixo |
| Decisores | 10 | — | ✅ muito bom |
| Reuniões | 4 | — | ✅ muito bom |
| Disparos | 30 | 40+ | ⚠️ abaixo |
| Decisores/disparo | 3 | 8–12% | ⚠️ |
| Reuniões/disparo | 0 | — | ❌ |

**Gargalo principal:** topo de funil (ligação) + áudio de disparo fraco

## Insights do Adriano
- Topo de funil em 37% (benchmark: 50%) — melhorando para 50% geraria 5–7 reuniões/dia só com ligação
- Meio de funil em 66% — **muito acima do benchmark** → hora e abordagem perfeitas → documentar e replicar
- Fundo de funil em 40% — dentro do benchmark
- Disparo: 30 enviados, 0 reuniões → áudio não está gerando resposta
- Follow-up: 100% de conversão — mas volume muito baixo

## Diagnóstico real
- Ligação por hora: 20 — ritmo muito bom para dia 1
- Principal dificuldade: adaptar script + improvisar na parte da oferta

## O que fazer
- [ ] Dominar o script antes de qualquer outra melhoria
- [ ] Documentar exatamente o que está dizendo na abordagem com atendente (66% de conversão = ouro)
- [ ] Escalar disparos para 50–60/dia
- [ ] Melhorar áudio do disparo
- [ ] Ligar para os 3 decisores do disparo que não converteram

**Meta do dia seguinte:** 7 reuniões

**Ver também:** [[Compromissos e Metodologia OAE]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]]

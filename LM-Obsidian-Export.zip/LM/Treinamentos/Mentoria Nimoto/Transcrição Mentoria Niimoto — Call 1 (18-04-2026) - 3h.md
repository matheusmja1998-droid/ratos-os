---
tipo: transcrição
agência: LM
evento: Mentoria Niimoto — Call 1
data: 2026-04-18
duração: 2h55min
ordem: 1
tags: [mentoria, nimoto, comercial, transcrição]
fonte: Google Drive
modelo: faster-whisper small (pt)
---

# Transcrição — Mentoria Niimoto Call 1 (18-04-2026)

Primeira call de treinamento da mentoria. Cobre reunião de vendas → oferta → webinar. 5.088 segments, ~3h. Continuação em [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]].

---

[00:00] Então, hoje o nosso objetivo é passar um pouquinho por todos, tá?
[00:04] Então, desde a reunião de vendas até a oferta, até o próprio webinar ali.
[00:09] E eu queria começar até com o que vocês já fizeram,
[00:12] quais que vocês sentiram que foram as dificuldades que vocês disseram que, pô,
[00:16] os últimos resultados não foram tão bons.
[00:19] Quero entender um pouco o que aconteceu ali.
[00:23] E se vocês têm essas métricas ali tranquilamente para vocês enviarem também,
[00:28] para que vocês tenham isso de bate pronto,
[00:30] para que a gente consiga dar uma analisada até mesmo antes de começar essa parte do webinar.
[00:36] Show, o mano, no primeiro a gente fez três, basicamente, né?
[00:41] O primeiro, a gente veio analisando também as sasionalidades,
[00:46] veio analisando a uns pontos também.
[00:48] O primeiro, a gente convidou ali, se eu não me engano, umas 70 pessoas tinham convites.
[00:54] A agenda tinha em torno de 23, mais ou menos, confirmados.
[00:58] Deixa eu trazer um ponto aqui.
[01:03] E até agregar ali no que o Matheus falou,
[01:06] essas pessoas em específico do primeiro webinar
[01:10] foram pessoas que a gente já abriu a oferta, já abriu o projeto antes,
[01:14] já abriu a proposta.
[01:15] Então, era bastante empresa que a gente já conhecia, que já foi R1, R2,
[01:21] talvez R3 também.
[01:24] Você tem empresas 23 convites e a gente teve vinte e duas.
[01:33] Vinte e uma que a outra empresa tinha levado duas pessoas na mesma empresa.
[01:37] Vinte e uma empresas participaram.
[01:41] Ah, esses vinte e um participaram.
[01:44] Isso, vinte e três estão firmados na agenda e vinte e um participou.
[01:48] Ah, e quantas reuniões foram?
[01:51] Cara, a gente já deu, acho que três e não foi tino.
[01:54] Por aí, mano, sério.
[01:57] Vamos ter a gente agora, uma, duas, uma, duas, duas, três, quatro, cinco, seis, sete, oito.
[02:14] Um álbum é umas três, mano.
[02:18] A gente coloca em três e gera a parte dela.
[02:22] No segundo web, nós...
[02:24] Espera, geraram três reuniões ou três?
[02:27] Três.
[02:28] Ah, tá, três reuniões.
[02:30] Isso, boa.
[02:31] No segundo web, nós...
[02:34] Foi a 19.
[02:36] Só que aí a gente...
[02:38] Acho que vocês fizeram...
[02:40] Aconteceu com vocês também.
[02:42] Que na sexta-feira a sexta-feira Santa foi feriada.
[02:45] Sim.
[02:46] Aí a gente mudou a hora, em vez de fazer meio dia, foi fazer 19.
[02:49] Aí a gente não marpeou essa sasionalidade.
[02:52] Muita gente já tá viajando.
[02:54] E aí a gente tinha convidado trinta e dois...
[02:58] Trinta e três convidados, oito, cinco.
[03:02] E participou, foram...
[03:03] Quantos reuniões?
[03:05] Tinha presente, você lembra?
[03:06] Segundo web, não é quatro.
[03:08] Quatro.
[03:09] Quatro presentes.
[03:11] No terceiro web, não é que foi...
[03:13] E zero reuniões, né?
[03:15] Zero reuniões.
[03:18] Teve um cara que chamou a gente...
[03:20] Teve um que a gente marcou, não?
[03:22] Não, foi na sexta-feira de Santa.
[03:24] Mas ele sumiu, mano.
[03:25] Isso, aham.
[03:26] Tá.
[03:27] E o terceiro?
[03:28] O terceiro foi quinta-feira agora.
[03:30] Esse web foi muito trabalho, mano.
[03:33] Aí esse web, né, mano?
[03:35] A gente ia fazer na próxima semana.
[03:38] Só que aí eu tava passando muito mal, não consegui fazer.
[03:41] E a gente pegou e remarcou ele e deu 15 dias entre um e outro.
[03:46] Tá, isso é importante.
[03:49] Quantas pessoas se convidaram nesse?
[03:52] Agora foi oitenta e oito.
[03:56] Vamos pegar o número real, mano.
[04:00] Deixa eu ver aqui.
[04:02] Aqui teve gente que foi...
[04:04] Tipo Adriana.
[04:06] Aqui não tava ali confirmado, acho.
[04:11] Eu e tu...
[04:13] Ah, tá.
[04:14] Foi o Pedro também, né?
[04:15] Ah, foi o Pedro também.
[04:17] Então Pedro...
[04:19] Nos últimos quatorze.
[04:21] Isso.
[04:22] Seventa e duas.
[04:24] Deus, setenta e duas, mano.
[04:26] Aliás, setenta e duas foram vinte e quatro sims.
[04:31] Ali no...
[04:33] No...
[04:34] Vinte e quatro, tá?
[04:36] Tá.
[04:37] É, vinte e quatro sim.
[04:39] E quantos participou?
[04:41] Acho que foi...
[04:42] É porque não deu com a mapear seco cinto.
[04:45] Seis a dez, mais ou menos.
[04:47] Que participou?
[04:48] De oito a dez.
[04:50] De oito a dez.
[04:51] Quantas uniões marcadas?
[04:54] Aí a gente...
[04:56] A gente fez recuperação, mesmo assim.
[04:59] E até agora, das pessoas que a gente falou...
[05:02] Sete.
[05:03] Sete?
[05:04] Sete, seis não?
[05:05] Ah, não, tem mais uma aqui, na verdade.
[05:07] Ah, tá.
[05:08] E daí, só que aí, o que que acontece?
[05:10] Essas uniões aí...
[05:12] Não, são seis.
[05:13] São seis.
[05:14] Tá minha agenda aqui, mais uma reunião, mas não é do Webner, não.
[05:17] Ah, aí, o que que acontece?
[05:19] A gente...
[05:20] Quando a gente tava fazendo as prospecções, os agendamentos,
[05:23] a gente tava terminando os dígitos como lixo qualificado e disqualificado.
[05:27] Com lixo qualificado acima de três vendidores,
[05:29] ali na equipe da parte comercial.
[05:31] E daí, quando a gente ligava e tinha essa tag,
[05:34] pra perguntar, porra, você participou do Webner e tal?
[05:37] Não, participou.
[05:38] Se o cara não participou e era um lixo qualificado,
[05:40] a gente virava e falava assim, então, fulano,
[05:43] pra sua empresa que a gente selecionou sua empresa,
[05:46] a gente fez todo o análise, como que você queria participar do evento e não conseguiu,
[05:50] a gente tá disponibilizando um análise 360 pra sua empresa.
[05:53] Daí, a gente...
[05:55] Eu tô ligando aqui pra bater uma agenda contigo.
[05:57] Como que tá o melhor horário ali na semana que tem que a gente bater esse papo?
[06:01] Vida ali, dessas empresas ali, dessas seis, Valentino.
[06:04] A gente tem quantas que participarem, quantas não participaram?
[06:08] Um participou.
[06:10] Um só dos seis, né?
[06:11] É.
[06:12] Um só dos seis.
[06:13] O resto foram cinco reativações.
[06:15] Cinco.
[06:16] Um lixo qualificado que não participou.
[06:19] E aí, porra, aí a gente...
[06:21] Cara, como a gente tá sem volume de reunião,
[06:23] vale a pena a gente tentar trazer um AR1.
[06:26] E aí, até trazendo um...
[06:29] Ah, pro Nimodo tem entender.
[06:32] A estrutura aí a gente sentou e conversou, cara.
[06:35] Tá muito ouço a gente trazer essas pessoas,
[06:37] trazer o comparecimento e tudo isso.
[06:40] E a gente sentiu que se você quiser,
[06:42] a gente pode abrir até aquele docus que eu montei.
[06:45] Abrei, mano.
[06:46] Deixa eu abrir tudo.
[06:47] Que daí a gente fez como se fosse o AI do Adriano Mesnatino.
[06:51] Assim, via...
[06:54] Eu tenho um...
[06:56] Um gigantesco com Iago.
[06:58] Muito legais, na verdade.
[07:00] Tem, tipo assim, todos os livros do Ormose, tá ligado?
[07:03] E aí dá pra criar uma farada bem legal
[07:06] e tudo o que ele trouxe ali, mano.
[07:08] Ficou bem, bem, bem legal.
[07:10] E aí a gente te mostrar aqui pra tu entender
[07:13] como que a gente trouxe, meio com a solução, mano.
[07:18] Daí a gente, basicamente, eu vou te mostrar
[07:22] como que ficou o que a gente pensou.
[07:25] Cara, tá bem tranquilo?
[07:27] Quer que dá um zoom?
[07:28] É, um zoom seria bom.
[07:30] Mano, o que que a gente pensou?
[07:33] Cara, no primeiro ebinário foi muito bom porque
[07:36] a gente trouxe muita gente que já tava com proposta aberta
[07:39] e que já conhecia a gente da R1.
[07:41] Daí o que que a gente montou?
[07:43] Só pra tu entender.
[07:44] Cara, por que que a gente não liga pra pessoa
[07:48] e...
[07:49] Só pra tu entender, depois a gente refinou.
[07:51] Liga pra pessoa, traz ela pra R1.
[07:54] Se vender, vendeu, né?
[07:56] R1 e R2.
[07:58] Se não vender, a gente deixa esse cara
[08:00] e traz ele pro EBITDA que vai ser daqui um mês.
[08:03] A gente vai fazer um EBITDA por mês.
[08:05] E aí a gente traz como se fosse uma nutrição
[08:07] pra depois vender de novo.
[08:09] E daí, o que que a gente refinou em cima disso?
[08:12] Isso daí foi ideia do Chino
[08:14] e o que que eu trouxe de ideia de refinação?
[08:16] Pra gente marcar reuniões mais fáceis,
[08:18] o que que a gente vai fazer?
[08:20] A gente vai ligar e vai mandar o convite pro cara
[08:22] e vai fazer, ó, a gente vai convidar pro EBITDA.
[08:24] Só que daí, no próximo dia seguinte,
[08:26] a gente vai ligar e vai falar falando,
[08:28] seguinte, a gente gostou, inclusive,
[08:31] não é esse script.
[08:33] Inclusive isso é uma coisa que a gente faz aqui também, tá?
[08:36] A gente começou a fazer isso,
[08:38] faz mais ou menos um mesinho ali.
[08:40] A gente viu exatamente a mesma ideia com vocês, pô.
[08:43] Caraca que sinistra, mano.
[08:45] E aí, a gente...
[08:46] Já do quer, Toma?
[08:47] É que eu caí aqui.
[08:48] Eu falei com o Nimoto,
[08:50] da estratégia de ligar, convidando pro EBITDA
[08:52] e no próximo dia ligar,
[08:54] falando que separamos uma agenda pra empresa dela,
[08:56] pra gente bater um papo especializado
[08:58] e a gente queria marcar uma agenda.
[09:00] Essa semana a gente liberou 45 minutos
[09:02] do nosso palestrante pra conversar com ela.
[09:04] E aí a gente marca reunião.
[09:06] E daí o Nimoto falou que eles tiveram a mesma ideia
[09:08] e tá começando a aplicar.
[09:09] Tem um mês que eles estão aplicando isso daí.
[09:11] E daí, mano, o que que é isso daí?
[09:13] Tudo de conversa com a IA, tá?
[09:15] Isso daí aí.
[09:16] Prova.
[09:17] Prova a ideia.
[09:18] E aí a gente montou essa estrutura
[09:20] e o funil ficou assim, mano.
[09:22] Prospectação ativa, ligação no convite
[09:24] e então se tiver mais de dois vendedores
[09:26] no dia seguinte, então a gente só faz a reunião
[09:28] com quem é qualificado.
[09:30] E não é qualificado, deixa com o EBITDA na mesa.
[09:32] Mesmo que dele não show, mas não tem problema.
[09:34] Entendi.
[09:35] E aí a gente é pensado inclusive até
[09:37] em um vez de chamar pra EBITDA primeiro,
[09:39] chamando pro ebinar,
[09:41] pra ele já falar assim,
[09:43] aí chamar pra ebinar depois.
[09:45] E pós ebinar,
[09:47] tu passou a script pra ele do pós ebinar?
[09:49] Não vou mostrar aqui o que tá agora
[09:51] que eu falo pra ele agora.
[09:53] Aí depois disso,
[09:55] a gente vai inserir uma precal,
[09:57] que vai ser um dia antes da reunião, da R1.
[09:59] E aí a gente montou o script aqui da precal.
[10:01] E daí a gente vai fazer uma
[10:03] qualificação ainda maior, que é basicamente
[10:05] abertura, depois
[10:07] time estrutura, faturamento e ticket,
[10:09] problema do cara
[10:11] e decisão pra ver se ele tem só ou não.
[10:13] Que daí a gente já sabe e aí a gente se cerra
[10:15] e aí a gente já tem um roteamento postal.
[10:17] Cerca pra R1 normalmente,
[10:19] time comercial, mais dois vendedores,
[10:21] mais de 50, 100 mil de faturamento,
[10:23] mais de 20 mil por projeto.
[10:25] Problema, existe há um tempo e tem urgência de ser resolvido.
[10:27] Decido sozinho ou traço soço.
[10:29] Se tem o soço, aí o cara perfeito,
[10:31] aí você fala que faz sentido.
[10:33] Falando, deixa eu te perguntar como você tem um soço,
[10:35] faz sentido ele estar na reunião amanhã?
[10:37] Porque o que eu vou trazer vai ser
[10:38] valioso pra sua operação.
[10:39] Então é interessante todas as pessoas
[10:41] que tomam decisão ali, dá pra ir nascentes.
[10:43] Então seja nesse precal aí,
[10:45] aos 10, 15 minutos pra fazer uma baita,
[10:47] pra ele ficar só no prato.
[10:49] Então é isso, R1, dock de guerra,
[10:51] aí eu já montei um aparelho dentro da
[10:53] do cloud que eu jogo a transmissão,
[10:55] ele já monta o dock de guerra,
[10:57] eu passo o link e envio do cara.
[10:59] Depois R2 de fechamento,
[11:01] fechou,
[11:03] se foi ignição solo
[11:05] ou ignição comercial,
[11:07] as ofertas que a gente tem,
[11:09] depois que você vai entender,
[11:11] não fechou base quesida,
[11:13] webinar, reengagem, trajo de novo.
[11:15] Script do convite do ebinário,
[11:17] mais ou menos, só que aqui não tá aprofundada,
[11:19] o convite, precal,
[11:21] a ligação, o mapeamento,
[11:23] o que fazer agora?
[11:25] Chega sabendo totalmente que R1
[11:27] fica cirúrgico.
[11:29] Quatro bocos da R1,
[11:31] voteamento, dock de guerra
[11:33] e o ebinário diagnóstico
[11:35] do baixo comparecimento.
[11:37] Aqui tem pré-diagnóstico,
[11:39] aqui que a gente foi.
[11:41] Aí,
[11:43] pode ser,
[11:45] o horário meio-dia,
[11:47] o principal culpado,
[11:49] confirmação sem ligação,
[11:51] que a gente não trouxe,
[11:53] trouxam algumas ligações,
[11:55] trouxam muito.
[11:57] Eu trouxe em todos.
[11:59] Então aqui foi.
[12:01] WhatsApp meio, confirmação por educação,
[12:03] quando confirma por WhatsApp
[12:05] é mais por educação,
[12:07] não por compromisso,
[12:09] talvez teve falta de acancimento.
[12:11] Não foi.
[12:13] Não foi.
[12:15] Solar e obter
[12:17] tem dor real.
[12:19] Tempo de prospecção, não foi.
[12:21] Dois semanas ao tempo ideal.
[12:23] Correção, traz uma hora diferente.
[12:25] Confirmação adicional,
[12:27] ligação a 48 horas além de WhatsApp.
[12:29] É que a gente estava fazendo
[12:31] protocolo ideal, WhatsApp.
[12:33] Confirmação, ligação a 48 horas, WhatsApp.
[12:35] 7,45 do dia, ligação para quem não entrou
[12:37] em 10 minutos.
[12:39] Estratégia.
[12:41] Algumas coisinhas.
[12:43] Tá.
[12:45] É isso, mano.
[12:47] Basicamente.
[12:49] Vou trazer uma visão para vocês aqui,
[12:51] com base em tudo que vocês me falaram, beleza?
[12:53] Isso aqui é bacana,
[12:55] que vai ficar muito claro algumas coisas.
[12:57] Quando a gente fala do evento de vocês,
[12:59] por exemplo, você pega esse primeiro,
[13:01] que já eram pessoas que estavam confirmadas ali,
[13:03] ou que eram pessoas
[13:05] que já tiveram contato com vocês de alguma forma,
[13:07] vocês se criaram em relacionamento,
[13:09] para vocês ali conduzirem
[13:11] e terem essas propostas.
[13:13] Foi aí, com base nisso ali,
[13:15] talvez que vocês tenham tido algumas
[13:17] ideias de fazer o que vocês estão fazendo hoje.
[13:19] Quando a gente vai para esse segundo,
[13:21] esse segundo webinar,
[13:23] eu desconsideraria ele porque ele foi totalmente
[13:25] atípico e eu consideraria ele
[13:27] mais um aprendizado de...
[13:29] Opa, deixa eu permitir o Phantom aqui.
[13:31] Boa, mano.
[13:33] Depois eu vou mandar a transmissão para nós assim.
[13:35] Não, fechou.
[13:37] Fechou.
[13:39] Ele foi bloqueado, mano.
[13:41] Tá dizendo aqui.
[13:43] Eu permiti aqui.
[13:45] Eu acho que é o próprio Gmini
[13:47] que está bloqueando.
[13:49] Não está gravando?
[13:51] Estou gravando aqui também.
[13:53] Eu vou gravar então.
[13:55] Fechou. E aí, nesse segundo webinar,
[13:57] aconteceu ali o feriado,
[13:59] então a gente sempre tem que estar olhando
[14:01] o calendário, foi algo que é um aprendizado.
[14:03] O que me importa mesmo
[14:05] são as métricas desse terceiro webinar
[14:07] aqui.
[14:09] Quando a gente tem um
[14:11] volume maior de convites,
[14:13] o que acontece?
[14:15] Se a gente adia o webinar,
[14:17] ou se a gente muda esse evento para
[14:19] alguma outra data,
[14:21] o retrabalho de convite é quase
[14:23] o mesmo do que você convidar pela primeira vez.
[14:25] Então, quando a gente tem um evento
[14:27] e a gente muda a data desse evento,
[14:29] quando a gente vai
[14:31] comunicar para o público
[14:33] esse evento mudado,
[14:35] a gente tem que fazer ligação,
[14:37] a gente tem que ter uma conversa novamente,
[14:39] a gente tem que reaquecer esse lead.
[14:41] Por quê? Porque se não acontece o que aconteceu.
[14:43] Vocês convidaram 88 pessoas e apareceu 6,
[14:45] apareceu 10,
[14:47] apareceu um número
[14:49] muito inferior do que vocês esperavam
[14:51] dentro de um evento.
[14:53] Só que ainda assim vocês conseguiram recuperar
[14:55] algumas reuniões dos que apareceram.
[14:57] Então, dos que apareceram,
[14:59] dentro de follow-up,
[15:01] do contexto que vocês fizeram,
[15:03] vocês conseguiram uma taxa de conversão legal.
[15:05] Uma taxa de conversão bacana.
[15:07] O grande problema de vocês
[15:09] foi o comparecimento dentro desses convites.
[15:11] Já no primeiro webinar,
[15:13] vocês também conseguiram uma taxa de agendamento legal.
[15:15] Então, quando a gente coloca
[15:17] a taxa de agendamento, foi legal.
[15:19] O que faltou nos dois webnários
[15:21] que eu acredito? Cara,
[15:23] dos convites que vocês fizeram
[15:25] que realmente as pessoas confirmaram,
[15:27] que realmente as pessoas aceitaram,
[15:29] depois elas participaram e tudo mais.
[15:31] Eu sinto que
[15:33] houve ali uma perca muito grande.
[15:35] Uma perca muito grande
[15:37] ali nessa parte de nutrição
[15:39] para você confirmar essa pessoa
[15:41] para ela realmente comparecer.
[15:43] E essa nutrição ela vem muito do convite
[15:45] a fazer certos gatilhos ali
[15:47] e eu bato muito com o nosso time
[15:49] certos gatilhos vão fazer com que
[15:51] a pessoa realmente compre de você
[15:53] ou ela não compre de você
[15:55] ou ela não aparece no evento
[15:57] que são tipo assim, vamos lá.
[15:59] Quando eu faço um convite para vocês
[16:01] existe a posição
[16:03] de autoridade, existe a
[16:05] posição de realmente
[16:07] eu estar convidando ali como
[16:09] se fosse extremamente importante
[16:11] que esse cara participasse.
[16:13] Eu preciso equilibrar as duas coisas
[16:15] de pô, eu quero que esse
[16:17] cara participe, mas eu também
[16:19] não quero deixar muito claro
[16:21] para ele que tipo assim, nossa,
[16:23] ele é a minha prioridade de vida
[16:25] e é um destino muito para ele aparecer.
[16:27] Então como que eu faço isso?
[16:29] Eu me posiciono como uma pessoa
[16:31] responsável por fazer o convite
[16:33] para ele, eu me posiciono como
[16:35] uma pessoa que realmente pô
[16:37] você realmente vai conseguir participar
[16:39] você entendeu como funciona o evento
[16:41] posso deixar aqui que você vai
[16:43] que a gente vai contar com a tua
[16:45] presença nesse dia, nesse horário
[16:47] e nisso aqui que a gente vai fazer
[16:49] e aí a pessoa fala não, pode contar
[16:51] com a sua presença
[16:53] quando a gente começa a colocar
[16:55] certas vieses de compromisso
[16:57] as pessoas elas tendem a aparecer
[16:59] mais sem necessariamente a gente
[17:01] ficar fazendo um follow up gigantesco
[17:03] então quando a gente faz um convite
[17:05] se eu faço um convite e falo assim
[17:07] Matheus, realmente é um evento
[17:09] mais exclusivo e esse evento
[17:11] exclusivo a gente realmente quer
[17:13] que estejam os empresários, os 50
[17:15] os 100 empresários ali que a
[17:17] gente convidou e
[17:19] porque a gente acredita que esse
[17:21] é importante para o segmento de vocês
[17:23] e para tudo o que a gente vai representar
[17:25] com todas as empresas que estarão lá
[17:27] realmente posso
[17:29] deixar atrancado na agenda que você vai
[17:31] participar até o dia, até o horário
[17:33] não pode, quando eu faço essa
[17:35] conformação, por mais que seja uma
[17:37] conformação boba, ela faz o que
[17:39] ela nutre o nosso lead para ele
[17:41] pensar o que cara, eu estou realmente
[17:43] me comprometendo com isso
[17:45] e aí nisso que eu nutrei o lead
[17:47] na hora do convite mesmo eu já faço
[17:49] alguma na agenda
[17:51] então nessa parte que você convidou
[17:53] ele e você só considera o convite
[17:55] então aceita o convite na agenda
[17:57] que a gente está te enviando
[17:59] para a gente
[18:01] confirmar
[18:03] que você realmente vai conseguir
[18:05] para a gente realmente
[18:07] deixar isso aqui, inclusive para você
[18:09] porque se o cara não confirmou
[18:11] na agenda, significa que
[18:13] alguma coisa aconteceu, ou seja
[18:15] significa que ele não teve
[18:17] trabalho nem ou de entrar no e-mail
[18:19] muitas das vezes, ele não teve trabalho
[18:21] nem de entrar no Google Calendar
[18:23] muitas das vezes, então é muito difícil
[18:25] com que esse cara compareça
[18:27] você pode perceber que dentro da agenda
[18:29] normalmente quem confirma que vai, vai
[18:31] e quem não confirma que vai
[18:33] normalmente é o cara que não aparece
[18:35] então essa métrica
[18:37] isso daí já é algo real
[18:39] o que que eu sinto
[18:41] dentro da confirmação de vocês
[18:43] perfeito, todo o funil que vocês
[18:45] já vão falar sobre ele, perfeito
[18:47] o único ponto é
[18:49] cara, esse cara tem que se comprometer
[18:51] de alguma forma, porém a gente fala
[18:53] sobre o compromisso, sobre o viés de
[18:55] compromisso, é quando alguém executa
[18:57] algo que dá a entender o real
[18:59] interesse delas
[19:01] vocês já devem ter escutado falar
[19:03] o pessoal que ensina os gatilhos
[19:05] do Cialdini falando assim
[19:07] quando uma pessoa tende a se comprometer
[19:09] com algo, ela tende a manter aquilo lá
[19:11] ok, isso é real
[19:13] mas quando ela se compromete
[19:15] com algo emocionalmente
[19:17] ela tende a cumprir
[19:19] com aquilo, quando são compromissos
[19:21] rasos ou são compromissos
[19:23] não, tá bom, vou sim, não, não sei o que
[19:25] e não tem um viés emocional
[19:27] não tem um impacto emocional?
[19:29] qual seria o impacto emocional?
[19:31] cara, eu vou realmente porque eu tenho
[19:33] que conhecer outras empresas
[19:35] porque eu tenho que conhecer outras pessoas do meu segmento
[19:37] porque eu tenho que realmente aprender
[19:39] coisas sobre o meu segmento
[19:41] eu preciso ir
[19:43] se a gente gera o sentimento de
[19:45] eu preciso ir
[19:47] equivalente ali também
[19:49] o sentimento de cara, deixa eu já
[19:51] confirmar aqui na agenda porque senão
[19:53] eu não vou conseguir ir
[19:55] aí a gente consegue generar
[19:57] um compromisso de verdade
[19:59] então um dos gatilhos que você pode usar
[20:01] durante a prospecção é, beleza, você confirmou
[20:03] cara, você consegue
[20:05] confirmar aí dentro do teu e-mail
[20:07] eu preciso dessa conformação do teu e-mail
[20:09] pra hoje também
[20:11] a gente já te enviou o convite
[20:13] pra ir pro seu Google agendas e pra você
[20:15] conseguir acessar o link do evento no dia
[20:17] confirmar pra mim já
[20:19] e realmente
[20:21] aceita ir pra mim, por favor
[20:23] porque esse convite
[20:25] vai fazer o que? vai fazer com que vocês
[20:27] tenham a garantia que esse cara
[20:29] não só vai receber o follow de vocês
[20:31] mas sempre vai ter aquele compromisso na agenda dele
[20:33] e o Google apitando
[20:35] porque o Google ele vai enviar na notificação
[20:37] a pau estão 24 horas, amanhã
[20:39] tem um evento tal
[20:41] daqui duas horas tem um evento tal
[20:43] daqui 30 minutos em sigo o evento tal
[20:45] e essa é uma notificação que ninguém
[20:47] desliga
[20:49] então o Google
[20:51] ele faz esse follow up as vezes muito mais
[20:53] eficiente que a gente
[20:55] então é muito mais fácil comparecendo
[20:57] o compromisso que o Google me avisou
[20:59] do que necessariamente alguém me fez
[21:01] um follow up no WhatsApp, eu até eu
[21:03] que trabalho com isso, que trabalho com
[21:05] isso é muito mais fácil, por exemplo
[21:07] a nossa cal de hoje ela estava agendada
[21:09] e aí ontem de noite
[21:11] o Google pegou e falou
[21:13] não esquece, não sei o que
[21:15] que você tem o compromisso
[21:17] amanhã, oito horas
[21:19] então o Google
[21:21] ele está sempre nessa
[21:23] nessa disposição
[21:25] e o próprio a notificação dela até quando
[21:27] meu celular tá no silencioso
[21:29] ele notifica o compromisso
[21:31] que ele trata isso como muito importante
[21:33] então um dos primeiros pontos que vocês
[21:35] precisam mudar urgentemente
[21:37] essa taxa de convite
[21:39] não existe por exemplo a gente ter 88 convites
[21:41] e não ter
[21:43] 88 pessoas confirmadas na agenda
[21:45] sabe, porque se a gente
[21:47] tem 88 convites e não tem 88 pessoas
[21:49] confirmadas na agenda, significa que
[21:51] em algumas das partes do compromisso
[21:53] que esse cara criou com vocês, eles não
[21:55] cumpriram
[21:57] mano posso dizer que
[21:59] quem não confirmou
[22:01] estava confirmado no evento anterior
[22:03] e não confirmo no próximo
[22:05] e dos que eu liguei
[22:07] falei e confirmaram
[22:09] porque eu fiz follow up por ligação
[22:11] expliquei como é que aceitava
[22:13] e tudo mais
[22:15] confirmei ter a terça-feira
[22:17] aí o evento era quinta
[22:19] eu liguei e me criou tudo bem
[22:21] expliquei né
[22:23] falei que eu ia mandar um link
[22:25] estava tudo certo no nosso evento
[22:27] que vai acontecer agora na quinta-feira
[22:29] e as pessoas falavam que sim
[22:31] que estavam animados
[22:33] que tinham convidado o time
[22:35] já tinha pegado o email do time
[22:37] aí eu mandava um link no whatsapp
[22:39] e falava é só aplicar no link
[22:41] é só acessar o link
[22:43] e clicou em sim
[22:45] aí as pessoas iam lá e faziam
[22:47] e as pessoas que não me atendiam
[22:49] eu mandava um audio explicando
[22:51] uma mensagem
[22:53] e mandava o link
[22:55] aí se a pessoa não me respondia
[22:57] era um follow up
[22:59] durante a tarde
[23:01] perguntando tudo certo
[23:03] consegui aceitar o link
[23:05] e teve pessoas do whatsapp
[23:07] que aceitaram
[23:09] porque tem pessoas que não falem no telefone
[23:11] que eu marquei por disparo
[23:13] e aí foi assim
[23:15] da minha parte
[23:17] vou dar uma dica pra vocês
[23:19] sempre que alguém confirmar
[23:21] o evento com vocês e essa pessoa
[23:23] assumir
[23:25] que a gente não fez com todo o time
[23:27] mas ele estava tendo esse problema
[23:29] ele era a pessoa que mais tinha esse problema
[23:31] dentro do time e o que a gente fez
[23:33] quando o lead não respondia a ele
[23:35] não aceitava o convite da agenda
[23:37] o que a gente fazia
[23:39] mandava uma mensagem falando assim
[23:41] seu convite foi cancelado
[23:43] por falta de resposta
[23:45] e por falta de aceite na agenda
[23:47] e a gente só mandava isso
[23:49] e aí a pessoa não, pera aí
[23:51] vou aceitar, não consegui ver
[23:53] porque quando a pessoa tem a sensação
[23:55] que ela vai perder
[23:57] penso ser humano sempre vai ter
[23:59] muito mais medo de perder
[24:01] do que vontade de ganhar
[24:03] então quando a gente faz isso
[24:05] seu convite foi cancelado
[24:07] por falta de confirmação na agenda
[24:09] caso queira
[24:11] por favor conferir o e-mail
[24:13] e aceitar o convite
[24:15] cara se você coloca isso
[24:17] ou seu convite irá ser cancelado
[24:19] caso você não aceite
[24:21] tudo da sua agenda
[24:23] por favor verificar
[24:25] quando você coloca isso
[24:27] sabe qual é a sensação que o cara sente
[24:29] eu não fiz isso
[24:31] pera deixa eu fazer e parar o que eu estou fazendo
[24:33] no início agora senão eu vou perder
[24:35] quando eu faço follow up
[24:37] por exemplo
[24:39] ah Mateus tudo bem Mateus
[24:41] passando para te avisar que tal dia
[24:43] tal horário vai ter o nosso evento
[24:45] você conseguiu ver
[24:47] você conseguiu ver dentro do seu e-mail
[24:49] cara às vezes o Mateus
[24:51] até está vendo o meu mensagem
[24:53] mas qual que está sendo a autina do Mateus
[24:55] eu estou no dia a dia depois eu vejo isso
[24:57] ah não sei o que
[24:59] nem sei se eu vou participar mais
[25:01] e aí o cara está no dia a dia na correria
[25:03] quando eu pego e falo assim
[25:05] Mateus tudo bem Mateus
[25:07] seu convite irá ser cancelado
[25:09] hoje caso você não aceite no e-mail
[25:11] poderia verificar ou prefere
[25:13] que eu envio aqui novamente
[25:15] cara
[25:17] o Mateus ele já vai olhar
[25:19] ele vai falar assim oi como assim
[25:21] os caras estão muito convidando
[25:23] para o evento sabe e realmente
[25:25] se o cara ele não responder depois desse follow up
[25:27] eu acredito sinceramente
[25:29] que ele já não ia no evento
[25:31] então já não é alguém que vocês poderiam
[25:33] tipo assim perder tanto tempo
[25:35] ali com ele
[25:37] quando a gente fala sobre o próprio script
[25:39] de prospecção que vocês estão fazendo
[25:41] primeiro a gente leva para uma reunião
[25:43] para a diagnóstica e tudo mais
[25:45] você consegue fazer isso
[25:47] e para os leads que vocês não conseguem
[25:49] também não tem um grande problema
[25:51] ali você levar somente para o webinar
[25:53] tá um dos pontos que eu estou falando
[25:55] é por que que eu faço o webinar
[25:57] todas as semanas e por que que eu consigo
[25:59] no trio meus leads todas as semanas
[26:01] porque se ele não aparece no evento
[26:03] eu vou convidar ele para um próximo
[26:05] da próxima semana
[26:07] vocês têm que imaginar que o webinar de vocês
[26:09] ele nada mais é
[26:11] se ele acontece toda semana
[26:13] em períodos mais curtos
[26:15] o que ele está sendo? Ele está sendo sempre uma fonte
[26:17] é onde você pode
[26:19] usar disso para o seu lead
[26:21] então do jeito que vocês estão fazendo
[26:23] tá perfeito eu não acredito que vocês precisem
[26:25] mudar isso
[26:27] até a parte de diagnóstico
[26:29] até a parte de pré-evento
[26:31] vocês já fazerem uma qual com essa galera
[26:33] o que eu acredito
[26:35] que vocês têm que fazer
[26:37] realmente ser mais incisivo nesse convite
[26:39] tá o problema de vocês
[26:41] não tá sendo a conversão dentro do evento
[26:43] porque as pessoas que estão participando
[26:45] aparentemente elas estão gostando e elas estão agendando
[26:47] tá
[26:49] e dentro do contexto
[26:51] geral que vocês estão fazendo
[26:53] e o que vocês precisam
[26:55] fazer muito e isso
[26:57] realmente
[26:59] é extremamente necessário
[27:01] é gerar esses viés de compromisso
[27:03] até depois para vocês não levarem
[27:05] no show numa reunião
[27:07] até depois para vocês não levarem no show
[27:09] que vocês estão marcando
[27:11] uma das dúvidas que eu tenho
[27:13] dessas três reuniões
[27:15] que vocês marcaram
[27:17] vocês chegaram a fechar algumas vendas
[27:19] dessa
[27:21] das 13 do primeiro
[27:23] fechou uma venda de reativação
[27:25] fechou meio assim
[27:27] tá pra pagar ainda né
[27:29] não fechou mano
[27:31] não fechou
[27:33] tá enrolando ainda
[27:35] e dessas seis a gente vai fazer semana que vem
[27:37] então aqui a gente
[27:39] percebe outro gargalo
[27:41] quando a gente tem 13 pessoas
[27:43] na base e vocês mostraram que
[27:45] vocês tem um produto de 4
[27:47] 439 é isso também
[27:49] o que que acontece
[27:51] dessas 13 ali
[27:53] a gente pegou muita gente
[27:55] disqualificada
[27:57] nesse evento aí
[27:59] 80 ou 90%
[28:01] das caos dessas 13
[28:03] era disqualificada
[28:05] quando a gente fez
[28:07] aí eu tô fazendo as caos de verda
[28:09] quando eu fiz a primeira reunião e vi que era muito disqualificada
[28:11] aí o Valentino a gente sentou
[28:13] e montou uma
[28:15] uma oferta de 500 reais
[28:17] tá aí tem uma oferta de 500
[28:19] uma de 4
[28:21] 4 a 5 ali
[28:23] e a gente outro de 12
[28:25] dorme não Valentino
[28:27] todos que foram
[28:29] as que aconteceram porque teve
[28:31] no show
[28:33] todos nos shows
[28:35] todos que aconteceram foram disqualificados
[28:37] tá o que que é disqualificado
[28:39] seria qual que é o faturamento
[28:41] o envenedor é o presa
[28:43] mas quantos que eles faturavam
[28:45] ah é
[28:47] imedia
[28:49] 15 por 3
[28:51] 15 por 5
[28:53] imedia
[28:55] é 75 mil
[28:57] isso de faturamento
[28:59] porque é um produto de 500 reais
[29:01] sim
[29:03] a gente não tinha pensado
[29:05] só mano
[29:07] depois eu fui lá e falei pra Matheus
[29:09] acho que a gente tá perdendo dinheiro porque
[29:11] tem muita gente burra aqui mano
[29:13] que é empresa pequena que a gente consegue ajudar
[29:15] pra gente vender alguma coisa
[29:17] depois
[29:19] então vão montar um improducto
[29:21] alguma coisa gravada e vender pra todo mundo
[29:23] que não leve tempo pra gente
[29:25] e daí eu
[29:27] o Matheus conversou com um melhor amigo dele
[29:29] o Ormosi
[29:31] eu gosto muito dele
[29:33] eu já li todos os livros dele
[29:35] eu comecei a falar do Ormosi antes
[29:37] de ele entrar no hype
[29:39] ai mano
[29:41] só pra tu entender
[29:43] a gente trouxe porque
[29:45] as vezes também é
[29:47] modular de oferta também né
[29:49] a gente poderia estar trazendo
[29:51] um outro tipo de produto
[29:53] porque esses caras
[29:55] a gente tá
[29:57] trazendo pra uma linha de trabalhar
[29:59] a área comercial desses caras
[30:01] então o treinamento de vendedores
[30:03] script de atendimento
[30:05] prospecção ativa
[30:07] pra energia só lá pra possibilitar
[30:09] bítio vicar é muito bom
[30:11] é uma linha muito boa
[30:13] e aí a gente traz pra essa linha
[30:15] e quando o cara não tem vendedor
[30:17] não tem quem a gente treinar
[30:19] e aí quando o cara é sozinho
[30:21] o cara não tem tempo nem pra
[30:23] pegar uma água
[30:25] de coisa
[30:27] normalmente o cara é sozinho
[30:29] ou ele é o dono da empresa
[30:31] e terceiriza a instalação
[30:33] ou ele tem
[30:35] ele e outro cara
[30:37] e ele deve ter um ou dois gatos
[30:39] para fazer a instalação
[30:41] e ele faz as vendas
[30:43] e aí por ser um ticket maior
[30:45] 10, 15 mil pra cima
[30:47] o cara fecha 5 vendas no mês
[30:49] ele pouco
[30:51] parte 75 mil, às vezes 100 mil
[30:53] finalmente
[30:55] só que não é um bom cenário
[30:57] uma venda de 15 mil não é um bom cenário
[30:59] pra eles também não
[31:01] porque pensa só esses caras
[31:03] tem um LL de uns 10, 15%
[31:05] se tá ali
[31:07] faturando 75 mil
[31:09] o cara tá indo 7, 10 mil de lucro
[31:11] então o cara
[31:13] se ele tem um sócio
[31:15] meio a meio
[31:17] ele daria 5 mil pra cada
[31:19] sem salvar nada no caixa da empresa
[31:21] pra acessar esses caras
[31:23] que a gente pensou o cálculo também
[31:25] e aí talvez a gente
[31:27] rampa outro produto
[31:29] ao invés de no comercial
[31:31] porque nessa linha a gente tem os produtos
[31:33] Ignição Solo
[31:35] que é basicamente uma cauda de 1h30
[31:37] trazendo pra ele ali
[31:39] como fazer lista
[31:41] como trazer inscritos de validade
[31:43] fazer ligações com ele na própria cauda
[31:45] extravar ele na ligação, um acompanhamento de 7 dias
[31:47] pra ele gerar a primeira reunião
[31:49] a primeira visita com cliente potencial
[31:51] de 500 mil de orçamento
[31:53] e aí finaliza o projeto
[31:55] e uma garantia que a gente fica com ele
[31:57] até ele conseguir rampar a primeira reunião
[31:59] a primeira visita técnica do cliente grande
[32:01] e aí a Ignição Comercial
[32:03] é 4, 5 mil anos
[32:05] e Ignição Solo é de 500 reais
[32:07] isso, que é pra cara que não tem vendedor
[32:09] e a Ignição Comercial
[32:11] é basicamente um acompanhamento
[32:13] de 6 semanas
[32:15] a 6 semanas
[32:17] onde
[32:19] em cada semana a gente traz coisas específicas
[32:21] exemplo, a primeira semana
[32:23] é um bordo de segunda semana
[32:25] treinar
[32:27] estruturação de inscritos junto com ele
[32:29] treinar o time dele pra fazer tudo isso
[32:31] então a gente vê
[32:33] um conteúdo de educação
[32:35] um pouquinho de mano na massa somente na reunião
[32:37] na cauda, então só
[32:39] cara, acho que deu 10 horas
[32:41] deu 10 horas
[32:43] dá 10 horas de entrega nessas 4 semanas
[32:45] nesses 4 mil
[32:47] a gente bobiou antes mano
[32:49] tipo assim, a gente nem teve tanto oportunidade
[32:51] de vender a Ignição Comercial
[32:53] por conta que começou a webinar
[32:55] começou as colhidas e tal
[32:57] mas antes do que a gente tava vendendo
[32:59] seja o ICP ou não, foda-se o sim
[33:01] a gente pegava qualquer empresa
[33:03] que a gente marcava a reunião
[33:05] a gente vendia
[33:07] a máquina de vendas, que é 8 pal
[33:09] que é
[33:11] acompanhamento de 2 meses
[33:13] a gente contrata, a gente treina
[33:15] a gente faz tudo, basicamente
[33:17] ao invés de ensinar
[33:19] e aí a gente parou
[33:21] porque toda sexta a gente faz uma análise da operação
[33:23] aí eu parei sem ter
[33:25] e falei, porra, tão a merda isso aqui
[33:27] não tão vendendo nada, tá meio caro
[33:29] acho que
[33:31] também a gente vai demorar muito tempo
[33:33] a promessa é muito forte
[33:35] e a promessa é entregar
[33:37] entregar vendas pra ele, tá ligado?
[33:39] e se não vender, a gente continuaria
[33:41] então a promessa é muito forte pra encontrar um cara
[33:43] pra contratar ele, pra manter ele
[33:45] pra treinar ele, pra entregar a reunião
[33:47] e a contratação, porque a contratação
[33:49] é algo muito sensível, né?
[33:51] a gente queria sair do gap
[33:53] de ajudar, de contratar pro cara
[33:55] aliás, a gente contrata, tem um case
[33:57] do cara legal, de contratação aqui
[33:59] só que
[34:01] é algo que dá muito trabalho
[34:03] e aí a gente trouxe a ignição comercial
[34:05] também
[34:07] e se o cara não tiver time
[34:09] pra trazer mais pessoas no time
[34:11] a gente traz um bônus de ajuda na contratação
[34:13] como o cara vai fazer a contratação
[34:15] tá, eu vou trazer um ponto pra vocês aqui
[34:17] e eu acho ele extremamente
[34:19] necessário, que é o que?
[34:21] vamos lá, a primeira coisa
[34:23] que eu vou bater aqui
[34:25] vai ser na própria reunião de venda de vocês
[34:27] eu vou trazer alguns insights aqui
[34:29] que talvez a reunião de vocês não esteja
[34:31] cara, na real não é, talvez
[34:33] a reunião de vocês
[34:35] sinceramente falando, ela não está boa
[34:37] eu vou explicar o motivo
[34:39] eu vou explicar o motivo ali
[34:41] porque que ela não está boa
[34:43] porque vamos lá
[34:45] quando eu trago aqui, eu vou até abrir uns slides
[34:47] que eu tenho aqui
[34:52] uma apresentação de slides
[34:54] deixa eu apresentar isso aqui
[34:56] a ignição comercial é 3 mil
[34:58] tá, só pra ver
[35:00] a ignição comercial é 3 mil
[35:02] acho que a gente ia passar 4 mano
[35:04] 3 mil, barato
[35:06] independente do valor
[35:08] de que eu falo
[35:10] e eu dei esse mesmo conselho pro David Rafael
[35:12] não sei se vocês conhecem David Rafael
[35:14] ele é anichado só pra
[35:16] a gente começou a vender e trabalhar no início
[35:18] por conta de uma aula dele, entendeu?
[35:20] inclusive ele é o maior case
[35:22] ele faz o webinar
[35:24] 70% das vendas dele
[35:26] vem através do webinar
[35:28] tava com ele semana passada entregando uma mentoria pra ele
[35:30] pra gente resolver alguns gargalos dentro da operação dele
[35:32] então tipo assim
[35:34] eu peguei o David Rafael
[35:36] e falei 15 mil reais por mês
[35:38] cara eu bati na mesma coisa que eu vou bater
[35:40] aqui com vocês
[35:42] realmente que pois
[35:44] daí fez algumas coisas
[35:46] mudaram não só o produto dele mas mudou um pouco
[35:48] a forma como que ele vendia
[35:50] tanto que no primeiro webinar dele
[35:52] ele teve 3 pessoas só
[35:54] ele teve 4 pessoas e 3 vendas
[35:56] caralho
[35:58] foi bizarro o primeiro webinar dele
[36:00] é disparado
[36:02] o cara que mais
[36:04] depois da gente ali o cara que mais
[36:06] teve resultado nessa parte de webinar
[36:08] quando a gente fala sobre
[36:10] a própria reunião de vendas
[36:12] eu gosto desses 7 princípios da influência
[36:14] ou seja como as destes sonhos humanas
[36:16] realmente acontecem
[36:18] e o que eu preciso que vocês entendam
[36:20] muitas das vezes vocês não tão
[36:22] vendendo pro teu cliente final
[36:24] porque vocês obvio
[36:26] vocês pegaram ali no cloud
[36:28] vocês pegaram boas ofertas
[36:30] eu entendi que vocês pegaram boas ofertas
[36:32] até porque vocês estão indo com um cara
[36:34] que eu acredito muito que é o próprio ElectronMoz
[36:36] e essas boas ofertas de vocês
[36:38] realmente funcionam
[36:40] o que não tá funcionando a própria reunião
[36:42] de vendas de vocês porque a reunião
[36:44] de vendas de vocês se essa oferta
[36:46] ela não tá funcionando é porque
[36:48] porque você não tá conseguindo despertar
[36:50] o potencial dessa oferta
[36:52] em cada etapa dentro da tua reunião de vendas
[36:54] quando a gente fala de um produto
[36:56] de 500 reais e é isso que eu queria
[36:58] que vocês entendessem
[37:00] quando eu falo qualquer pessoa compra
[37:02] eu preciso entender exatamente o
[37:04] porque qualquer pessoa não compraria
[37:06] então o primeiro momento
[37:08] não é entender porque
[37:10] que esse cara ele compraria de mim
[37:12] o primeiro momento é entender porque
[37:14] que ele não compraria de mim
[37:16] qual que é o maior impeditivo
[37:18] que impede esse cara
[37:20] que de ele comprar de mim agora nesse momento
[37:22] então se eu pego e faço ali
[37:24] sei lá
[37:26] eu tô fazendo uma col
[37:28] e a primeira coisa
[37:30] que eu preciso entender é por qual motivo
[37:32] esse cara não compraria de mim
[37:34] qual quais são as objeções
[37:36] que ele não vai me contar
[37:38] mas que realmente existem é uma objeção
[37:40] de tempo é uma objeção de
[37:42] muita das vezes ele não gostar
[37:44] de trabalhar e existe
[37:46] isso tá às vezes ele
[37:48] associa o produto de vocês com mais
[37:50] trabalho e aí ele se sente
[37:52] acelerado dentro desse produto
[37:54] isso pode acontecer algumas vezes
[37:56] inclusive se vocês tiverem alguma reunião de
[37:58] vendas onde vocês fizeram um pit
[38:00] disso e depois a gente pode analisar isso
[38:02] aqui e eu te mostrar pra vocês
[38:04] é isso aqui que eu vou mostrar dentro
[38:06] da reunião de vendas de vocês que
[38:08] vai ficar muito claro mas assim
[38:10] quando a gente vai falar com cliente
[38:12] por exemplo o que eu preciso entender
[38:14] tá qual é que são as crianças dele sobre isso
[38:16] cara você realmente acredita
[38:18] em prospecção cara você realmente
[38:20] acredita que você pode trazer um cliente
[38:22] assim assim assim seja sincero comigo
[38:24] porque eu de verdade
[38:26] mesmo eu não acredito na maioria das
[38:28] coisas que as pessoas falam
[38:30] quando eu abro a minha reunião assim
[38:32] com o meu cliente
[38:34] o que que eu faço eu dou espaço pra ele falar
[38:36] ah Gustavo já tentei
[38:38] pô o que você vai falar e provavelmente
[38:40] eu já sei não sei o que
[38:42] e provavelmente tá assim
[38:44] é que a gente tem a
[38:46] como se diz
[38:48] a gente tem sempre
[38:50] a tendência a acreditar que a
[38:52] pessoa do outro lado ela não sabe
[38:54] o que a gente tá falando e tudo
[38:56] que a gente tá apresentando uma novidade
[38:58] mas aí um ponto que eu trago pra
[39:00] vocês é numa era que a gente
[39:02] tem ia provavelmente
[39:04] o cara ele já teve essa ideia ou
[39:06] provavelmente enquanto esse cara tava
[39:08] deitado no sofá ele falou cara e se eu fizer assim
[39:10] assim assim e aí ele teve essa ideia
[39:12] e aí quando você falar algo
[39:14] que reforça uma criança que ele
[39:16] teve uma ideia positiva que ele teve no
[39:18] passado as pessoas elas pensar assim
[39:20] pô então esse é bom porque esse
[39:22] cara ele vai se identificar e ele vai
[39:24] vender e ele vai comprar ideia mais fácil
[39:26] não na verdade ele vai falar assim
[39:28] cara é eu não fiz isso no
[39:30] passado por causa disso disso disso
[39:32] mas já que eles tiveram a mesma ideia
[39:34] que eu significa que eu tô indo pelo caminho certo
[39:36] não preciso contratar eles
[39:38] exatamente entendeu então
[39:40] a maioria das vezes
[39:42] talvez se esteja um adaptando
[39:44] a linguagem de vocês pra algo genérico
[39:46] que faça ele entender que vocês
[39:48] estão tendo algumas ideias
[39:50] que talvez ele já tenha tido
[39:52] ou talvez ele já tenha algumas
[39:54] crenças sobre isso quando eu falei com David
[39:56] uma das coisas que eu bati ele
[39:58] em reuniões e em coisas com ele
[40:00] foi o seguinte foi cara
[40:02] você precisa entender primeiro teu cliente
[40:04] depois da sua oferta a gente tem uma
[40:06] uma
[40:08] uma vantagem na reunião de vendas que
[40:10] a gente chama de e aí eu
[40:12] eu chamo isso de oferta viva
[40:14] o que é uma oferta viva é onde
[40:16] eu consigo criar a melhor oferta
[40:18] do ormose só que para uma pessoa
[40:20] específica
[40:22] qual que é o grande sentido ali quando
[40:24] a gente vai na internet quando a gente
[40:26] fala de vsl a gente fala de lançamentos
[40:28] a gente fala de webnários a gente fala
[40:30] de todas as estruturas de vendas que existem
[40:32] qual que é o grande princípio que as
[40:34] pessoas têm elas falam assim
[40:36] pô criarei uma boa oferta uma boa
[40:38] oferta para atender o meu público
[40:40] específico legal isso é segmentado
[40:42] e aí as pessoas sempre falam pra
[40:44] isso que quanto mais segmentado estou
[40:46] oferta melhor ela vai ser beleza
[40:48] e agora se a minha oferta
[40:50] e se a minha oferta ela for
[40:52] segmentado o suficiente para ela ser
[40:54] segmentada para pro matheus
[40:56] pro valentino
[40:58] vocês percebem como ela ganha ainda
[41:00] mais força vocês percebem como ela
[41:02] ganha ainda mais potência então
[41:04] a primeira coisa que eu preciso entender é
[41:06] qual que seria a oferta que o matheus
[41:08] e o valentino comprariam e aí a
[41:10] gente tem a oferta de todo mundo a
[41:12] gente tem oferta de nicha a gente tem
[41:14] oferta de mercado a gente tem oferta de cp
[41:16] e a gente tem oferta do indivíduo
[41:18] e a oferta do indivíduo
[41:20] depois que ela vem sobre toda essa
[41:22] estrutura ela vai fazer com que
[41:24] vocês venham muito mais
[41:26] então a oferta do indivíduo é
[41:28] muito você entender
[41:30] alguns pontos de influência
[41:32] que você tem sobre essa pessoa
[41:34] só que esses pontos de influência
[41:36] adaptada a realidade
[41:38] dessa pessoa
[41:40] então quando você pega sua oferta
[41:42] sua oferta ela já está estruturada
[41:44] e eu tenho certeza que quando vocês
[41:46] falaram a oferta um para o outro os dois
[41:48] ficaram caraca isso vai vender bastante
[41:50] mas quando vocês chegaram na realidade
[41:52] vocês não entenderam porque não venderam
[41:54] e aí a grande justificativa foi
[41:56] mano eu acho que esse cara não tem 500
[41:58] conto eu acho que os caras não estão
[42:00] dispostos a pagar 500 conto para
[42:02] melhorar a operação deles não eles estão
[42:04] pode ter certeza que eles estão
[42:06] porque em algum outro momento eles
[42:08] tem uma ferramenta para eles trabalhar
[42:10] de 15 mil reais parcelada em
[42:12] sei lá às vezes ele dá até
[42:14] o salta dele dentro daquela ferramenta
[42:16] e quando eu falo isso
[42:18] eu antigamente
[42:20] eu tive que parar de fazer isso porque
[42:22] isso prejudicava a minha empresa
[42:24] mas a primeira empresa
[42:26] de marketing que eu tive
[42:28] foi a fórmula secreta
[42:30] a fórmula mano
[42:32] eu era um vendedor tão bom que
[42:34] isso se tornou maior gargalo da empresa
[42:36] e a gente teve que fechar a empresa
[42:38] vocês terem ideia
[42:40] porque chegava um cara
[42:42] que faturava 5 mil reais para mim
[42:44] eu fazia uma venda de 29 mil para ele
[42:46] e fazia ele dar tipo 6 mil de entrada
[42:48] e parcelar o resto só que mano
[42:50] não tinha sentido fazer uma venda
[42:52] desse para esse cara
[42:54] mas por que eu conseguia vender
[42:56] para esse cara porque eu entendia
[42:58] uma oferta personalizado para ele
[43:00] eu parei de vender isso porque
[43:02] esse era um lado de vendas
[43:04] desse para quase qualquer outra pessoa
[43:06] se você fizer uma promessa
[43:08] muito forte
[43:10] só que a promessa muito forte não é a tua
[43:12] promessa ser muito forte igual o Valentino falou
[43:14] nossa promessa é muito forte
[43:16] e tudo mais
[43:18] ela é muito forte porque vocês enxergam
[43:20] na visão do que ele vai receber
[43:22] o que é uma visão muito forte
[43:24] o que é uma oferta muito forte
[43:26] às vezes o Matheus tem medo de ligar
[43:28] a minha oferta muito forte é eu
[43:30] Matheus você não vai precisar ligar
[43:32] eu não preciso falar outras 800 coisas
[43:34] é o tirado da cabeça dele
[43:36] que ele não vai precisar ligar nesse primeiro momento
[43:38] então quando eu vou colocando
[43:40] esse tipo de coisa
[43:42] dentro do funil
[43:44] que eu vou adquirindo
[43:46] eu consigo vender sim realmente
[43:48] para quase qualquer pessoa
[43:50] cara por que aquilo trazer um problema
[43:52] eu saí metendo o loco
[43:54] e vendi
[43:56] de verdade não tinha várias closers
[43:58] naquela época
[44:00] mas eu vendi 150 mil reais
[44:02] sozinho e sei lá
[44:04] um mês
[44:06] com uma pessoa
[44:08] e meia
[44:10] basicamente
[44:12] uma agência 360
[44:14] era um bagulho muito loco
[44:16] deixa eu ver o Adriano
[44:18] o Adriano
[44:20] está aqui para comprovar
[44:22] eu nem sabia que ele entra aqui
[44:24] então quando a gente fala disso
[44:26] caraca
[44:28] está bem arrumado
[44:30] só faltou arrumar a roupa que você está arrumado
[44:32] né
[44:34] o ferro de passar
[44:36] arrumar os ombrinhos
[44:38] ele sempre tem que criar alguma coisa
[44:40] tá bonitão
[44:42] não sei se você sabe
[44:44] mas o tino comprou até um boné
[44:46] e um opus também para ficar parecendo vocês
[44:48] não queria falar isso não
[44:54] então o Adriano
[44:56] eu estava falando para eles da época da fórmula
[44:58] que eu entrava na reunião
[45:00] e eu vi de qualquer custo
[45:02] depois era impossível de entregar
[45:04] então
[45:06] cara quando a gente fala sobre isso
[45:08] o que eu estou falando para vocês é
[45:10] não é porque
[45:12] vocês tenham um produto
[45:14] e não é porque a oferta de vocês é muito boa
[45:16] para o seu público
[45:18] que necessariamente vocês vão vender muito
[45:20] isso não é sinônimo de venda
[45:22] de bastante vendas
[45:24] mas a grande objeção do cara sabe o que pode ser
[45:26] cara pode ser você mesmo
[45:28] muitas das vezes a grande objeção do meu cliente
[45:30] era ele não acreditar em mim
[45:32] e aí o que eu tinha que fazer
[45:34] cara eu tinha que primeiro quebrar essa objeção
[45:36] quando eu percebi ela
[45:38] para depois essa objeção ela ser estruturada
[45:40] então o que eu vou trazer
[45:42] aqui para vocês
[45:44] e eu preciso que vocês aprendam isso
[45:46] não é algo que simplesmente vocês vão anotar
[45:48] e eu vou falar
[45:50] na reunião você aplica assim
[45:52] não eu preciso que vocês aprendam isso
[45:54] para vocês aplicarem
[45:56] porque vocês vão usar isso em diferentes situações
[45:58] aqui
[46:00] quando eu falo dos sete princípios da influência
[46:02] ou seja como as decisões humanas
[46:04] realmente acontecem
[46:06] eu dou algumas
[46:08] eu dou alguns exemplos
[46:10] e eu ainda trago aqui algumas coisas
[46:12] que você pode fazer com isso aqui
[46:14] que eu vou mostrar para vocês dentro da reunião
[46:16] de venda de vocês
[46:18] porque que eu não estou começando ali
[46:20] porque eu acho que você faz uma
[46:22] reunião eficiente
[46:24] porque eu tenho certeza
[46:26] que se eu olhar a reunião de vocês
[46:28] eu vou falar assim cara eu concordo
[46:30] porque pela linha que vocês seguiram
[46:32] ali no script
[46:34] pela linha que vocês seguiram ali naquela lógica
[46:36] eu provavelmente vou olhar para a reunião de vocês
[46:38] e vou falar assim eu concordo
[46:40] porque eu realmente acredito que o grande
[46:42] o problema não está sendo nem estrutura da reunião
[46:44] sim a condição dela
[46:46] e isso não é culpa de vocês
[46:48] e isso é culpa de um hábito que todo mundo no mercado teve
[46:50] e o mercado se otimizou
[46:52] então as pessoas elas estão recebendo ofertas
[46:54] o tempo todo
[46:56] só que agora elas não compram mais
[46:58] e esse que é o grande ponto e por que eu estou
[47:00] cara vendendo todo dia por que a gente está
[47:02] tendo uma
[47:04] conversão tão alta
[47:06] sendo que o mercado
[47:08] ele não está comprando mais como antes
[47:10] porque eu realmente estou trabalhando nas pessoas agora
[47:12] além de uma oferta boa
[47:14] eu trabalho as pessoas
[47:16] quando a gente pega esse primeiro slide
[47:18] você acredita que as suas decisões são racionais
[47:20] a maioria das pessoas acredita que sim
[47:22] deixa eu mudar aqui
[47:24] as decisões humanas são totalmente
[47:26] não são totalmente racionais
[47:28] elas seguem um padrão psicológico
[47:30] lembra as pessoas elas
[47:32] vão tomar a decisão
[47:34] emocionalmente e vão justificar
[47:36] da forma lógica
[47:38] sempre que eu faço uma venda
[47:40] ela parece 100% lógica
[47:42] mas esse cara ele está tomando uma decisão
[47:44] emocional porque se não há emoção
[47:46] também não há vontade do crescimento
[47:48] se não há emoção também não há vontade
[47:50] dele melhorar a empresa dele
[47:52] se não é emoção não há várias outras coisas
[47:54] então necessariamente vai ser emocional
[47:56] só que você tem que bater
[47:58] numa barreira lógica para que isso
[48:00] faça tão sentido para ele que ele mesmo
[48:02] justifique a compra dele
[48:04] então você fazer com que
[48:06] seu cliente ele justifique a compra dele
[48:08] faz com que seja muito eficiente
[48:10] para ele comprar de ti
[48:12] então quando a gente traz nesse ponto
[48:14] a primeira coisa que a gente traz
[48:16] é a reciprocidade
[48:18] quando a gente fala sobre reciprocidade
[48:20] a maioria das pessoas entendem isso errado
[48:22] alguns conceitos aqui que eu vou falar
[48:24] vocês já ouviram
[48:26] só que do jeito que eu vou explicar
[48:28] talvez fique claro
[48:30] de uma forma como nunca ficou
[48:32] esses conceitos aqui para que vocês
[48:34] possam aplicar nas suas reuniões de vendas
[48:36] quando a gente fala de reciprocidade
[48:38] o nosso cérebro
[48:40] ele oudeia ficar indívida
[48:42] quando a gente entende
[48:44] que o nosso cérebro
[48:46] ele oudeia ficar indívida
[48:48] e a gente precisa causar uma
[48:50] sensação de valor para uma pessoa
[48:52] o que necessariamente
[48:54] eu preciso fazer
[48:56] lembra que eu falei que a decisão
[48:58] ela entra no aspecto emocional
[49:00] eu preciso gerar através
[49:02] de algo que eu falo
[49:04] uma sensação emocional boa
[49:06] para que essa pessoa fique indívida
[49:08] e essa sensação
[49:10] então vamos lá
[49:12] quando você convida para um webinar
[49:14] e você faz o convite
[49:16] e essa pessoa aceita o convite
[49:18] e você trata isso como um favor
[49:20] que você está fazendo para ela
[49:22] você ativa a reciprocidade
[49:24] quando você trata isso como
[49:26] eu preciso que você esteja lá
[49:28] você já não ativa essa reciprocidade
[49:30] quando você faz uma reunião
[49:32] e você fala assim
[49:34] eu vou te entregar algumas coisas
[49:36] e aí é esse cara
[49:38] ele percebe que eu é diagnóstico
[49:40] sobre a empresa dele
[49:42] tipo assim
[49:44] é para vender para ele
[49:46] você não ativa a reciprocidade
[49:48] porque a maioria das pessoas acredita
[49:50] que isso vai ativar a reciprocidade
[49:52] agora sabe o que vai ativar a reciprocidade
[49:54] eu cheguei numa reunião
[49:56] igual eu cheguei numa reunião ontem
[49:58] e eu peguei e perguntei para o cara assim
[50:00] cara eu posso te falar
[50:02] que milhares de coisas que vão fazer você vender
[50:04] o que eu quero entender aqui
[50:06] é quais são as coisas que fazem
[50:08] você não vender internamente mesmo
[50:10] porque eu sei que você
[50:12] é um cara que está sobrecarregado
[50:14] muito provavelmente você está passando por isso
[50:16] isso isso isso
[50:18] a importância de você conhecer seu público
[50:20] para você fazer essa leitura fria
[50:22] muito provavelmente
[50:24] você tem medo de prospectar
[50:26] por algum motivo
[50:28] ou não seja um medo que seja
[50:30] seja uma preguiça
[50:32] ou seja por não acreditar
[50:34] ou às vezes você acredita nesse processo
[50:36] mas você sente que
[50:38] isso aqui talvez não seja para você
[50:40] porque você não tem tempo
[50:42] e a sua cabeça não funciona
[50:44] ali pedindo para fazer
[50:46] certas coisas
[50:48] e aí o que que o cara começa a entender
[50:50] ele fala pô é verdade
[50:52] pô eu passo por isso e tudo mais
[50:54] quando a gente entra numa reunião
[50:56] a gente só ativa a reciprocidade
[50:58] se a gente for para um lado psicológico
[51:00] para um lado intelectual
[51:02] então a reciprocidade é entender
[51:04] cara eu entendo como você se sente
[51:06] talvez você se sente assim
[51:08] eu acertei como você se sente
[51:10] é exatamente isso que você sente
[51:12] você acredita que esse é um impeditivo
[51:14] para você realmente fazer isso
[51:16] porque vamos lá se eu falo pro cara
[51:18] se eu vou vender um produto
[51:20] onde esse cara prospecta empresas
[51:22] para ele agendar a primeira reunião
[51:24] de diagnóstico com uma empresa
[51:26] uma reunião técnica
[51:28] qualificada
[51:30] quem que garante que esse cara
[51:32] tem ali condições
[51:35] emocionais para fazer uma reunião
[51:37] com uma empresa qualificada
[51:39] há uma pergunta que eu vou fazer
[51:41] para vocês que eu não sei se já
[51:43] fizeram para os clientes de vocês
[51:45] se se sente confiante de verdade mesmo
[51:47] para fazer reunião com uma empresa grande
[51:49] você se sente confiante
[51:51] realmente para entrar em contato
[51:53] com essas empresas grandes
[51:55] e o
[51:57] valentino a gente costuma falar
[51:59] que o valentino se sai melhor
[52:01] em reuniões
[52:03] onde não é tão
[52:05] a empresa não tem uma estrutura
[52:07] mega complexa
[52:09] e ele se sai melhor principalmente com mulheres
[52:11] porque você é conectar mais
[52:13] nas reuniões
[52:15] o que eu quero dizer
[52:17] é que
[52:19] quando vai
[52:21] uma linha mais lógica
[52:23] não dá tão certo para mim
[52:25] quando é mais emocional
[52:27] aí dá certo, obrigado
[52:29] aqui também sabe porque é mais fácil
[52:31] com mulher porque a mulher tende
[52:33] para esse lado emocional
[52:35] esse é o grande problema
[52:37] quando vem
[52:39] um cara de
[52:41] maior
[52:43] o nível de técnico dele é muito alto
[52:45] e aí para conversar técnico com técnico
[52:47] eu consigo
[52:49] trazer muita coisa
[52:51] só que vendo isso daí
[52:53] é interessante porque isso faz total sentido
[52:55] porque quando você fala técnico
[52:57] a pessoa se não conecta
[52:59] a pessoa às vezes tá trazendo
[53:01] quanto maior o lead mais técnico que você tenta ser
[53:03] e o cara vem muito técnico
[53:05] do outro lado
[53:07] e aí ele vai olhar
[53:09] a maioria das coisas que você falou
[53:11] ele já tentou aplicar
[53:13] ou ele já fez ou ele já tá no processo
[53:15] de fazer e aí fica
[53:17] faz muito sentido
[53:19] mas talvez não seja um momento para a minha empresa
[53:21] sim
[53:23] já tentei e deu certo
[53:25] mas a gente tá restruindo a empresa
[53:27] eu vou trazer uma pergunta pra vocês
[53:29] por exemplo
[53:33] quem são os dois tipos de clientes
[53:35] de clientes de vocês
[53:37] vocês tem mapeado quem é o cliente ideal
[53:39] de vocês?
[53:41] sim e quem é?
[53:43] o que tem um comercial
[53:45] tá e quem é o cliente ideal de vocês?
[53:47] o que tem comercial? como assim?
[53:49] tá e o cliente
[53:51] a persona do cliente
[53:53] é especificamente não
[53:55] mas normalmente
[53:57] não tem mapeado mas a gente sabe
[53:59] meio no feeling né
[54:01] não pode falar meio no feeling
[54:03] quem é o cliente de vocês eu vou trazer
[54:05] essa reunião aqui é realmente
[54:07] pra vocês entenderem e depois disso
[54:09] a próxima reunião vocês vocês vão ver
[54:11] depois disso aqui que vocês entenderem
[54:13] só pra entender Tino
[54:15] ele tá perguntando quem é a persona
[54:17] no caso do mercado digital
[54:19] principalmente nos lançamentos
[54:23] meio no feeling
[54:25] porque a gente não tem o perfil da empresa definida
[54:27] mas não do decisoro da empresa
[54:29] eu acho que é um cara que tem consciência
[54:33] mas ele tá perguntando
[54:35] é o ACP real
[54:37] como que é o cara?
[54:39] o cara tem qualidade, é uma mulher
[54:41] o cara trabalha
[54:43] é essa linha né
[54:45] eu só tô trazendo esse questionamento
[54:47] realmente pra pra vocês
[54:49] refletirem sobre isso
[54:51] vai mais no feeling Matheus
[54:53] quem é o cliente de vocês?
[54:55] cara é um empresário
[54:57] que tem entre
[54:59] 30 e 50 anos
[55:01] ele é casado
[55:03] normalmente
[55:05] tem
[55:07] filhos entre
[55:09] entre 3 a 10
[55:11] 10 anos mais ou menos
[55:13] e isso daí a gente tá falando
[55:15] de cliente ideal
[55:17] e também de percepção dos clientes
[55:19] que a gente já entrou em tal
[55:21] cara
[55:23] ele tem uma rotina mega outra corrida
[55:25] ele tá sufocado
[55:27] no comercial da empresa dele
[55:29] porque se ele não tiver ativamente
[55:31] a empresa não vende como deveria vender
[55:33] é o cara que
[55:35] ele
[55:37] também
[55:39] é o cara que
[55:41] ele fica na mega correria
[55:43] os vendedores sempre dependem dele
[55:45] pra uma venda mais complexa
[55:47] com um projeto maior
[55:49] é o cara que
[55:51] cara
[55:53] é o cara que quase não tem tempo
[55:55] e praticamente
[55:57] na empresa ele quase não tem tempo
[55:59] porque sempre tá pagando incêndio fazendo vendas
[56:01] e fora ele tá numa correria
[56:03] porque tem família, filha, escola
[56:05] e por aí vai
[56:07] o que o cliente de vocês quer?
[56:09] exatamente
[56:11] cara
[56:13] tempo
[56:15] tá, tempo
[56:17] exatamente pra que ele quer tempo
[56:19] e como que ele quer tempo e como que vocês oferecem
[56:21] como que vocês tangibilizam esse tempo de vocês
[56:23] cara, eu entendi o que quis dizer agora
[56:25] sim, só que aí a gente
[56:27] o cara quer tempo, só que aí a gente não tá vendendo
[56:29] economia de tempo, a gente tem
[56:31] vendendo a uma de faturamento da empresa
[56:33] aí
[56:35] é que nem quando a gente vai vender a gente fala
[56:37] que não tem que vender energia solar
[56:39] na minha conta, não
[56:41] tem que vender
[56:43] saiba qual é o problema
[56:45] vocês estão vendendo pra uma empresa
[56:47] e não pra uma pessoa
[56:49] eu vou te falar uma coisa que
[56:51] vai mudar o jogo de vocês
[56:53] que isso mudou o meu jogo quando eu comecei a entender
[56:55] se eu for vender pra uma empresa
[56:57] eu vou ter
[56:59] a competitividade que eu pretendo
[57:01] contra pessoas
[57:03] que vendem pra empresas
[57:05] então você vai competir com gigantes
[57:07] do mercado
[57:09] você vai competir com um cara que é
[57:11] influenciador do instagram ali
[57:13] que tem sei lá 5 milhões de seguidores
[57:15] do nicho desse cara que só fala
[57:17] sobre isso o dia inteiro
[57:19] esse cara ele não vai comprar de você
[57:21] se você não tá vendendo pra empresa dele
[57:23] você tem que vender pro empresário
[57:25] qual que é o caminho mais curto
[57:27] pra venda, é você vender pra empresa
[57:29] ou vender pro empresário
[57:31] vender pro empresário
[57:33] porque a gente
[57:35] não tem isso
[57:37] e a gente nem se tocou mano
[57:39] porque a gente vê muito vídeo assim
[57:41] que fala que venda
[57:43] venda bítio B
[57:45] venda bítio C
[57:47] é mais fácil porque é emocional
[57:49] e aí tu traz um questionamento
[57:51] que faz a gente ir em cima
[57:53] e é racional
[57:55] mas também é emocional
[57:57] e também igual
[57:59] você vai ver que o Valentino
[58:01] a gente vai conectando muito rápido
[58:03] tipo assim cara
[58:05] porque que tu falou que é
[58:07] a parte psicológica, imagino eu
[58:09] porque cara, quando o cara responde
[58:11] só tem uns techs ali
[58:13] você vai trazer mais tecnesas
[58:15] e ele vai conectar com o cara
[58:17] e daí se a gente tá vendendo tempo
[58:19] se a gente tá vendendo aumento de faturamento
[58:21] o cara teoricamente associa isso
[58:23] que ele vai ter que gastar mais tempo
[58:25] e ele não tem tempo e o produto não serve pra ele
[58:27] eu vou exemplificar isso aqui
[58:29] que vai ficar de uma forma muito clara
[58:31] pra vocês
[58:35] o lid de vocês quando ele vai fazer um churrasco
[58:37] ele pensa muito
[58:39] antes de comprar a picanha
[58:41] não, que o melhor que tem
[58:43] qual que é a variável
[58:45] quando ele vai comprar a picanha
[58:47] às vezes é a marca da picanha
[58:49] tá, o quilo
[58:51] o lugar
[58:53] porque a marca
[58:55] tu vai encontrar em vários lugares
[58:57] mas assim, é o lugar que ele vai comprar essa picanha
[58:59] e ele não pensa e ele não conversa
[59:01] depois pôs, ele não conversa com ninguém
[59:03] ele só vai lá e compra a picanha
[59:05] porque ele acredita que aquilo lá é pra ele
[59:07] então é uma decisão muito comum pra ele
[59:09] o grande sentido disso que eu tô trazendo pra vocês é
[59:11] quando a gente pega um lid de técnico
[59:13] um lid que é muito grande
[59:15] a maioria das pessoas, elas vão pra área
[59:17] 100% técnica
[59:19] e eu vou pra uma área técnica também
[59:21] eu tenho que demonstrar que eu entendo do assunto
[59:23] agora o grande questionamento do lid de técnico
[59:25] é o quê, cara
[59:27] eu entendo isso que você tá falando
[59:29] que isso faz sentido e isso daí
[59:31] é realmente o que eu preciso
[59:33] agora eu preciso entender se é você que eu quero
[59:35] eu entendo qual que é o produto
[59:37] eu entendo qual que é a picanha que eu quero
[59:39] agora eu preciso entender
[59:41] se eu quero comprar ela de você
[59:43] ou se eu quero comprar ela no açougue
[59:45] ou se eu quero comprar ela no mercado
[59:47] ou aonde que eu quero comprar
[59:49] então o que vocês precisam entender
[59:51] é que você precisa ter a parte técnica
[59:53] mas você precisa vender pro empresário
[59:55] e vender pro empresário, muitas das vezes
[59:57] é você entender, ele entender
[59:59] o que vai além da venda pra ele
[60:01] então quando a gente puxa
[60:03] nesse ponto aqui e eu falo assim
[60:05] pô Mateus, beleza? Mateus
[60:07] deixa eu entender um pouquinho mais sobre você
[60:09] cara, eu tenho dois filhos no seu que
[60:11] pô, pô, pô, beleza
[60:13] eu vou te apresentar e eu apresento ali normalmente
[60:15] só que durante a apresentação
[60:17] eu vou puxando algumas coisas
[60:19] pô Mateus, você sabia que eu também tenho criança pequena
[60:21] pô Mateus, você sabia que isso aqui
[60:23] e aqui eu vou gerando reciprocidade
[60:25] e nessa reciprocidade eu já era o ela
[60:27] com intencionalidade
[60:29] então muitas das vezes a reciprocidade que eu vou puxar
[60:31] é, cara, eu também tenho criança pequena
[60:33] e às vezes eu me sinto até culpado
[60:35] quando eu não consigo
[60:37] ou eu posso usar uma história do passado
[60:39] eu me senti até culpado
[60:41] quando eu não conseguia
[60:43] ter tempo suficiente pra eles
[60:45] às vezes porque eu tava trabalhando
[60:47] e às vezes minha mulher não entendia
[60:51] cara, quando eu falar isso
[60:53] que todo público que tem filho
[60:55] ele vai falar a mesma coisa
[60:57] todo empresário que tem filho
[60:59] ele vai falar a mesma coisa
[61:01] sabe uma coisa que eu faço com os meus clientes
[61:03] eu peço conselho pra ele muitas das vezes
[61:05] às vezes o cara é mais velho
[61:07] e esse cara é mais velho
[61:09] e ele tem mais experiência de mercado
[61:11] sabe o que eu faço?
[61:13] eu viro pra ele e peço um conselho
[61:15] porque muitas das vezes as pessoas
[61:17] elas entendem que pra mim o vender
[61:19] e eu acredito que esse é um grande ponto de você
[61:21] isso é um defeito
[61:23] isso aí não é uma qualidade
[61:25] que vocês acreditam o tempo todo
[61:27] que vocês tem que se demonstrar muito bons
[61:29] pro cliente fechar com vocês
[61:31] a gente acredita que
[61:33] tem que trazer case
[61:35] tem que saber tudo
[61:37] deixa eu te fazer uma pergunta
[61:39] quantos
[61:41] e às vezes cês pegam um cliente
[61:43] que fatura muito mais que vocês
[61:45] ou um cliente que fatura muito alta
[61:47] e aí cês ficam naquela síndrome
[61:49] por inferioridade e aí vocês pegam
[61:51] e compensam isso
[61:53] tentando demonstrar que vocês são mais técnicos possíveis
[61:55] agora a grande pergunta é
[61:57] esse cara é gigantesco
[61:59] ele não contratou uma faxineira
[62:01] e essa faxineira ela não fatura menos que ele
[62:03] esse cara
[62:05] ele não contratou um vendedor e esse vendedor
[62:07] ele fatura menos que ele
[62:09] esse cara não contratou uma contabilidade
[62:11] muitas das vezes essa contabilidade
[62:13] fatura menos que ele
[62:15] agora o grande ponto é
[62:17] a gente tenta aparecer que a gente fatura mais
[62:19] que uma empresa pra gente realmente
[62:21] vender pra ela porque a gente entende
[62:23] que o nosso melhor caminho é fazer com que
[62:25] essa empresa
[62:27] sei lá
[62:29] o nosso melhor caminho é fazer com que essa empresa
[62:31] ela entenda que somos maiores que elas
[62:33] somos mais técnicos que elas
[62:35] somos os melhores que elas pra ela comprar da gente
[62:37] e não
[62:39] ninguém quer alguém melhor que a gente
[62:41] essa grande realidade do ser humano
[62:43] a grande reciprocidade
[62:45] eu vou chegar nesse cara e falar se cara
[62:47] dentre todos os empresários
[62:49] de energia solar que eu conheci
[62:51] talvez você seja o maior
[62:53] o mais técnico e com mais conhecimento na área
[62:55] e eu fico muito honrado
[62:57] de estar fazendo essa reunião com você
[62:59] eu fico imaginando
[63:01] o que acontece se a gente
[63:03] colocar nossa metodologia que você falou
[63:05] que faz muito sentido
[63:07] junto com essa experiência gigantesca
[63:09] que você tem
[63:11] o resultado que isso vai dar
[63:13] talvez você seja a nossa
[63:15] porta de entrada para vários outros cases
[63:17] e várias outras empresas
[63:19] gigantescas porque eu realmente
[63:21] acredito nesse teu projeto
[63:23] e assim como eu acredito
[63:25] nesse teu projeto eu acredito muito
[63:27] mais ainda porque é você que
[63:29] tá na liderança com ele
[63:31] porque eu não conseguiria fazer tudo
[63:33] que você falou que você faz
[63:35] hoje a gente tá aqui pra
[63:37] resolver um problema específico
[63:39] e com esse problema
[63:41] talvez a gente dobre teu fatoramento
[63:43] mas eu acho admirável
[63:45] você simplesmente conseguir
[63:47] ter a capacidade de dobrar o fatoramento de vocês
[63:49] porque isso exige
[63:51] o conhecimento técnico operacional
[63:53] descala de funcionagem, gerenciamento
[63:55] de liderança que você tem
[63:57] e muito parabéns porque provavelmente
[63:59] é por isso que você chegou a onde você tá
[64:01] olha como eu tiro
[64:03] o peso de cara eu não preciso
[64:05] ser o mais rico da sala
[64:07] parece que a gente concorrência do cara né
[64:09] exatamente
[64:11] se trata a reunião de venda de vocês
[64:13] como se estivessem lutando um com o outro
[64:15] na verdade vocês deveriam entrar
[64:17] em sintonia com o cliente
[64:19] então a reciprocidade por si só
[64:21] é quando você entrega algo
[64:23] genuinamente pra uma pessoa
[64:25] sem ela sentir o interesse
[64:27] ou que ela sinta o interesse
[64:29] mas que você entregue isso genuinamente
[64:31] então quando a gente vai
[64:33] falando desses pontos
[64:35] até o ponto do compromisso
[64:37] ali na confirmação da reunião
[64:39] cara se eu
[64:41] quando alguém
[64:43] assume alguma coisa ela tende a manter
[64:45] ou seja quando ela
[64:47] assume alguma coisa emocionalmente
[64:49] quando o que que eu fiz
[64:52] quando eu fiz esses elogios pra esse cliente
[64:54] por exemplo eu ativei o emocional dele
[64:56] e aí eu falei assim cara
[64:59] o meu grande objetivo
[65:01] e olha que louco
[65:03] eu percebi matheus que quanto mais eu cresço
[65:05] o que me faz
[65:07] crescer é realmente eu pegar pessoas
[65:09] bem sucedidas como você
[65:11] e consegui entregar o que a maioria
[65:13] dos empresários ou que a maioria das empresas
[65:15] que vieram falar com elas
[65:17] não entenderam que é o que você realmente
[65:19] quer você não quer um tempo
[65:21] pra ficar 100% ocioso
[65:23] você só não quer ficar
[65:25] sobrecarregado com esse tanto de decisão
[65:27] que você toma no dia a dia
[65:29] cara se eu entendo isso do empresário
[65:33] e aí depois eu gera um compromisso
[65:35] e ele não sim cara
[65:37] é exatamente isso que eu quero
[65:39] se o empresário falar exatamente isso que eu quero
[65:41] ele manteve o compromisso
[65:43] e olha como fica mais fácil
[65:45] eu vendei ele no final
[65:47] po Matheus, po Valentino
[65:49] vocês falaram que é exatamente isso que vocês precisam
[65:51] e quando ele se comprometeu
[65:53] emocionalmente a gente teve
[65:55] esse compromisso gerado
[65:57] e a partir desse compromisso gerado
[65:59] eu consigo fazer o que
[66:01] foi exatamente isso que vocês falaram
[66:03] o único queixonamento pra gente fechar
[66:05] não seria esse fator preço
[66:07] porque é o que você falou
[66:09] que você precisa de agora
[66:11] é exatamente esse compromisso que você quer
[66:13] o único fator que você precisa
[66:15] resolver agora com a gente
[66:17] seria esse fator preço pra gente
[66:19] realmente começar esse projeto
[66:21] olha como a venda se torna mais leve
[66:27] mais rápida
[66:29] então tudo o que você for falando
[66:31] a maioria das reuniões de vendas que eu faço
[66:33] a maioria das reuniões de vendas que eu fiz
[66:35] o cara falava assim, cara, pensei que ia custar
[66:37] tipo, sei lá, cinco vezes mais caro
[66:39] dez vezes mais caro
[66:41] porque eu não só me comprometi
[66:43] tecnicamente, mas eu me comprometo
[66:45] emocionalmente
[66:47] e esse emocional
[66:49] eu faço ele por meio lógico
[66:51] eu também não sou o cara que vai ficar
[66:53] não
[66:55] contando milhares de histórias durante
[66:57] uma reunião de vendas
[66:59] ou fazendo aquelas
[67:01] e aí o emocional não significa
[67:03] que você precisa ser ridículo, chato
[67:05] pra caramba, tentar virar um melhor amigo
[67:07] do cliente a qualquer custo, não, não é isso
[67:09] emocional é você
[67:11] a partir da lógica
[67:13] você atingir pontos que emocionalmente
[67:15] comprometem ao seu cliente
[67:17] beleza
[67:19] então nesse ponto a prova social
[67:21] também ela é muito importante
[67:23] existem casos de vendas
[67:25] que a prova social
[67:27] ela é 70, 60%
[67:29] da venda
[67:31] agora, uma coisa que o Valentino falou
[67:33] às vezes eu acredito que eu preciso
[67:35] ter uma prova social muito forte
[67:37] deixa eu trazer um ponto pra vocês
[67:39] hoje, qual que é o meio do caminho
[67:41] que vocês vendem, não é a captação de leads
[67:43] não é esse cara que tem reuniões
[67:45] qualificadas
[67:47] então vocês têm prova social
[67:49] vocês podem abrir a agenda de vocês
[67:51] vocês podem abrir o CRM de vocês
[67:53] e mostrar assim, olha quantas reuniões
[67:55] a gente trouxe
[67:58] o maior prova social que vocês podem trazer pra ele
[68:00] é o compromisso sério
[68:02] então se você abre o seu CRM
[68:04] e você mostra assim, cara, deixa eu ver
[68:06] eu não tenho prova social suficiente
[68:08] de empresas que eu fiz vender muito mais pra esse cara
[68:10] só que eu consigo demonstrar pra esse cara
[68:12] que eu consigo trazer reuniões o suficiente
[68:14] e é essa prova social
[68:16] que esse cara quer
[68:18] olha o que a gente faz aqui
[68:20] e o nosso segmento ele é até um pouco mais difícil
[68:22] porque a gente precisa demonstrar pra vocês
[68:24] o nosso nível de educação ele exige muito
[68:26] mas deixa eu mostrar pra vocês
[68:28] o tanto de reuniões que a gente consegue
[68:30] a partir disso
[68:32] olha esse CRM
[68:34] olha isso aqui que eu vou te demonstrar
[68:36] e aí você consegue demonstrar o CRM
[68:38] não necessariamente
[68:40] você precisa vender da venda pro final
[68:42] que é o que a maioria das pessoas fazem
[68:44] nossa, a gente quer que você aumente
[68:46] suas vendas
[68:48] muitas das vezes esse cara nem acredita
[68:50] que você vai conseguir vender como ele
[68:52] agora se eu vendo o meio de campo
[68:54] de reuniões que eu consigo te trazer
[68:56] quantos a gente consegue trazer
[68:58] ter a partir dessas reuniões
[69:00] que eu trouxe pra você
[69:02] você percebe que se torna muito mais
[69:04] fácil pra esse cara compreender
[69:06] que ele vai vender no final
[69:08] porque se eu coloco
[69:10] porque esse cara vai vender eu tenho que
[69:12] quebrar a objeção que eu sei vender
[69:14] que eu tenho provas sociais que já venderam
[69:16] ou que outras várias outras
[69:18] variáveis dentro
[69:20] de uma venda ali do produto dele
[69:22] eu sei e eu domino e eu não domino
[69:24] agora se eu coloco pra esse cara
[69:26] que eu consigo fazer o meio de campo
[69:28] e trazer esse cara qualificado
[69:30] educado
[69:32] pronto pra comprar é diferente
[69:34] de vendido
[69:36] é diferente
[69:38] e aí eu consigo jogar até uma responsabilidade
[69:40] pra ele pô você sabe vender
[69:42] você e vender, quando você conversa com um cliente
[69:44] você sabe explicar seu produto, você explicar seu produto
[69:46] depois em um outro momento
[69:50] você pode trabalhar essa parte de vendas
[69:52] com ele, só que o que vocês não perceberam
[69:54] e isso eu bati muito com Davi
[69:56] é você tem um meio de campo incrível
[69:58] só que você tá tentando chutar
[70:00] no gol errado cara
[70:02] entendeu? Você tá indo pro lado errado
[70:04] então quando a gente faz isso
[70:06] a própria prova social
[70:08] muitas das vezes é vocês
[70:10] tu abriu o teu CRM ali
[70:12] tinha 135 reuniões
[70:14] cara tem cara que não tem isso em 3 anos
[70:16] dentro do segmento de vocês
[70:18] só de você abrir isso
[70:20] e comprovar que isso é real
[70:22] isso já é uma prova social
[70:24] eu já começaria a minha reunião
[70:26] a primeira coisa que eu faria é
[70:28] oito do bem cara você participou do nosso evento
[70:30] olha que legal
[70:32] uma das coisas que eu vou te mostrar aqui
[70:34] olha o tanto de empresários que participaram
[70:36] ou que não participaram
[70:38] que seja que você convide antes na hora do diagnóstico
[70:40] olha o tanto de empresários
[70:42] que estão confirmados já no nosso evento
[70:44] deixa eu te mostrar aqui
[70:46] eu abro a agenda e eu mostro a lista
[70:48] de todos os empresários que estão confirmados
[70:50] e aí esse cara vai sentir
[70:52] a autoridade por meio de que?
[70:54] por meio das pessoas que vão participar do evento
[70:56] olha esses caras eles palestram
[70:58] eles demonstram para outras pessoas
[71:00] deixa eu te mostrar aqui
[71:02] o tanto de reuniões, o tanto de oportunidades
[71:04] que a gente consegue gerar com a metodologia
[71:06] que eu quero te passar nesse evento
[71:08] ou que eu te passei nesse evento
[71:10] abre o CRM, demonstro CRM
[71:12] cara, vocês percebem que
[71:14] a gente nem começou a oferta ainda
[71:16] a gente nem começou a falar do seu produto ainda
[71:18] mas isso já gerou uma autoridade
[71:20] para esse cara
[71:22] que muitas das vezes vocês não estão conseguindo gerar
[71:24] porque vocês tentam parecer alguma coisa
[71:26] que vocês não são
[71:28] e esse é o pior caminho
[71:30] para vocês conseguirem vender
[71:32] porque eu conseguia vender até para o cara
[71:34] que ele não era muito
[71:36] não era muito qualificado
[71:38] cara, a gente pode falar
[71:40] sei lá
[71:42] você já ouviu falar sobre isso
[71:44] quando a gente fala de ditadores
[71:46] ou
[71:48] pessoas que realmente
[71:50] tem uma grande influência
[71:52] no mundo, políticos e tudo mais
[71:54] cara, existe uma maneira de
[71:56] falar mil verdades
[71:58] para contar uma mentira
[72:00] não necessariamente, vocês estão contando uma mentira
[72:02] agora imagina se vocês usarem mil verdades
[72:04] para falar uma verdade maior ainda
[72:06] então, que é o meio de campo que você conseguiu fazer
[72:08] por que eu conseguia fazer isso
[72:10] eu não colocava para o cara
[72:12] que faturava 5 mil reais
[72:14] e eu vendia um produto de 29 mil
[72:16] que ele não iria conseguir pagar depois
[72:18] mas eu não colocava para esse cara
[72:20] tipo assim, cara, olha pra prova social
[72:22] desse cara que saiu de 5 mil reais para 50 mil reais
[72:24] eu tornava isso
[72:26] lógico na cabeça dele
[72:28] hoje, qual que é o 80-20
[72:30] para que você consiga fechar um cliente
[72:32] cara, eu tenho reuniões
[72:34] deixa eu te mostrar uma coisa
[72:36] olha o tanto de reuniões que a gente consegue gerar
[72:38] olha o tanto de reuniões
[72:40] quantos anos você conseguiria gerar
[72:42] olha como eu estou gerando minha prova social
[72:44] e estou fazendo ele mesmo confirmar e fazer a promessa
[72:46] para ele
[72:48] chegando no final da reunião
[72:50] o próprio cliente fez a conta na cabeça dele
[72:52] de quanto ele vai faturar
[72:54] e não eu falei para ele
[72:56] então, quando eu vou criando essa expectativa
[72:58] você pode usar isso tanto para o bem quanto para o mal
[73:00] mas quando eu vou criando essa expectativa
[73:02] eu consigo chegar numa maneira lógica
[73:04] para fazer vocês pensarem
[73:06] que vocês vão faturar 2 milhões de reais
[73:08] por exemplo, se eu chego aqui
[73:10] e olha que louco isso, se eu chego aqui e falo assim
[73:12] pô, que bacana isso que vocês estão
[73:14] falando
[73:16] hoje, cara, vamos fazer um planejamento
[73:18] para vocês venderem 700 mil reais
[73:20] vocês sabiam que se vocês pegarem
[73:22] ao invés de vender um produto de
[73:24] sei lá
[73:28] 500, 2, 3 mil reais
[73:30] você vender um produto de 97 por mês
[73:32] tá
[73:34] você vende isso para seus clientes
[73:36] que vai ter uma maior aderência
[73:38] que é muito mais fácil de eles comprarem
[73:40] e você vender 3 desses produtos por dia
[73:42] saber que no equivalente de 1 ano
[73:44] você vai ter faturado 700 mil reais
[73:46] aquele ano
[73:48] faz a conta aí, você vai ter faturado
[73:50] 700 mil reais aquele ano
[73:52] então você só precisa de 3 vendas de 97
[73:54] se eu falo isso para vocês
[73:56] e eu começo realmente fazer o cálculo
[73:58] isso é real, tá
[74:00] se você fizesse 3 vendas de 97 reais por dia
[74:02] no final de 1 ano
[74:04] você vai ter faturado 700 mil reais
[74:06] só que no final de 2 anos
[74:08] você vai estar faturando 1 milhão e 400
[74:10] por ano fazendo 3 vendas de 97 por dia
[74:12] que é extremamente
[74:14] ridículo fácil de você fazer
[74:16] agora imagina
[74:18] se nessa venda
[74:20] se é muito mais fácil você entregar
[74:22] e olha o quanto você vai trabalhar
[74:24] pô, você pode criar um produto
[74:26] onde você tem todas as aulas gravadas
[74:28] uma comunidade de network
[74:30] empresários eles vão se conectar
[74:32] aonde você vai fazer um encontro por dia
[74:34] então uma entrega que você vai fazer
[74:36] você vai fazer para todos
[74:38] esses caras vão continuar assinando
[74:40] esses caras vão continuar com recorrência
[74:42] quanto mais pessoas participam do seu evento
[74:44] você pode vender mais
[74:46] você consegue fazer eventos toda semana
[74:48] isso eu to falando de 3, se você fizer 6 vendas por dia
[74:50] você consegue tanto
[74:52] e aí eu começo a trabalhar
[74:54] essa lógica com vocês, no final
[74:56] essa lógica é real
[74:58] mas eu consigo entender
[75:00] que isso é o melhor caminho
[75:02] só que eu consigo fazer
[75:04] vocês entenderem que isso é o melhor caminho
[75:06] através do potencial lógico
[75:08] e aí o potencial emocional
[75:10] de eu fazer você sair desse estado
[75:12] que você está hoje para o estado
[75:14] que você está ali no futuro
[75:16] é muito fácil
[75:19] então quando a gente pega
[75:21] isso aqui que a gente está falando
[75:23] a prova social não necessariamente
[75:25] é só um case e só um depoimento
[75:27] é muito bom você ter case e depoimentos
[75:29] mas a prova social
[75:31] é o que conecta a realidade lógica
[75:33] com a realidade emocional
[75:35] e com o resultado futuro
[75:37] e aí você usando isso de forma eficiente
[75:39] você consegue vender para esse cara
[75:41] peixou?
[75:43] o Nimuto
[75:45] a gente está com dois vídeos muito foda
[75:47] que a gente recebeu aqui de
[75:49] prova do
[75:51] do evento
[75:53] que eu acho interessante mostrar isso no início
[75:55] que a gente recebeu também
[75:57] cara por que você não manda antes da col
[75:59] a gente recebeu esses dias
[76:01] a gente não testou ainda
[76:03] cara
[76:05] tenta enviar um pouco antes da col
[76:07] sabe
[76:09] eu acho que dentro da col
[76:11] o que você não faz muito sentido
[76:13] entrar na col e botar um vídeo para rodar
[76:15] ficar os dois parados assistindo
[76:17] o vídeo ali junto com o diente
[76:19] a gente vai ficar meio constrangedor
[76:21] para você
[76:23] é nem constrangedor
[76:25] mas acho que vai perder um tempo da reunião
[76:27] que não é necessária
[76:29] eu acho que o case é a prova social
[76:31] você envia lá os vídeos para ele ver
[76:33] que realmente existe
[76:35] e aí fica muito mais fácil se apresentar
[76:37] isso numa reunião
[76:39] dos números
[76:41] do jeito que eu falei ali atrás
[76:43] até agora vocês perceberam que eu não necessariamente
[76:45] falei da reunião de vendas de vocês
[76:47] porque eu acredito que a reunião de vendas de vocês deve estar boa
[76:49] deve ser uma boa reunião de vendas
[76:51] que eu considero essas coisas que eu falei
[76:53] e aí vem um ponto de autoridade
[76:55] autoridade ela não necessariamente
[76:57] ela tá
[76:59] só em você
[77:01] ela tá no contexto geral
[77:03] autoridade ela pode ser dados
[77:05] que você realmente puxou
[77:07] pode ser pesquisa de mercado
[77:09] pode ser literalmente
[77:11] a lógica que utilizei
[77:13] então autoridade ela vem muito do
[77:15] conhecimento sobre o assunto técnico
[77:17] que vocês estão falando
[77:19] e coisas que comprovam
[77:21] e externamente que isso daí é real
[77:25] então por que que eu trabalho muito com dados
[77:27] porque se eu pego as métricas de vocês
[77:29] automaticamente vocês viram
[77:31] que eu peguei a métrica de vocês
[77:33] e eu consegui através da métrica de vocês
[77:35] analisar um possível gargalo
[77:37] que vocês têm na sua operação
[77:39] que seria na parte de convites
[77:41] e esse possível gargalo
[77:43] eu tenho certeza que vai resolver um problema
[77:45] outro possível gargalo que eu identifiquei
[77:47] foi as reuniões de vendas
[77:49] então a autoridade ela pode vir
[77:51] de analisar muitas das vezes a métrica
[77:53] do seu próprio cliente
[77:57] então a métrica do seu próprio cliente
[77:59] ele pode vir ser analisado pra essa métrica
[78:01] então ele quer mais tempo
[78:03] beleza ele quer mais tempo
[78:05] quando ele vende um projeto muito maior
[78:07] quanto de tempo isso gasta
[78:09] em relação ao projeto menor
[78:11] o que é mais custoso
[78:13] ele fechar três projetos de 15 mil
[78:15] ou fechar um projeto de 50
[78:17] que ele lucra 5 mil a mais
[78:19] e talvez ele tenha menos trabalho
[78:21] do que ele executar três projetos de 15 mil
[78:23] e aí eu vou demonstrando
[78:26] para o meu cliente através dos próprios dados dele
[78:28] ah quantos dias
[78:30] quanto tempo você leva pra executar
[78:32] um projeto de 50 mil reais
[78:34] cara eu levo tanto tempo
[78:36] sei lá eu levo o suportar
[78:38] não vou colocar número real não
[78:40] porque senão essa conta fica difícil
[78:42] eu levo dez dias pra fazer um projeto de 50 mil reais
[78:44] obviamente não é isso
[78:46] mas assim
[78:48] e o projeto de 15 mil
[78:50] ah eu levo cinco dias cada projeto de 15 mil
[78:52] então você fatura 45 mil
[78:54] você leva 15 dias pra faturar
[78:56] essas 45 mil
[78:58] se você vendesse um projeto de 50 mil
[79:00] você ia ganhar 5 mil reais a mais
[79:02] e ia levar cinco dias a menos
[79:04] ele ia olhar e ia falar assim
[79:08] aqui eu vendi a ideia
[79:10] de ele pegar o projeto
[79:12] dentro do
[79:14] do escopo que vocês querem
[79:16] que são empresas mais qualificadas
[79:18] usando a lógica
[79:20] só que emocionalmente isso impactou ele
[79:22] ele sentiu a autoridade em mim
[79:24] simplesmente por eu ter usado a lógica
[79:26] por eu ter pegado dados deles
[79:28] e realmente convertido isso
[79:30] em realidade
[79:32] então a autoridade ela é muito sobre
[79:34] como você pega certos dados
[79:36] certos momentos do mercado
[79:38] certas coisas que são reais
[79:40] e você converte isso na realidade do seu cliente
[79:42] beleza
[79:44] e a autoridade ela precisa ser passada
[79:46] você tinha alguma pergunta pra gente
[79:48] não, aqui é 10 dias mesmo mano
[79:50] é 10 dias
[79:52] e um residencial
[79:54] também é 5, 3 dias pra ele
[79:56] top top
[79:58] então a gente acertou mais ou menos
[80:00] estou andando muito com David
[80:02] mas bora lá
[80:04] então quando a gente pega isso daí
[80:06] a gente começa a ter
[80:08] essa parte de autoridade
[80:10] que vai fazer com que você anda muito mais
[80:12] então esse é mais um dos pontos
[80:14] que vocês vão bater
[80:16] afinidade, as pessoas confiam
[80:18] com quem se parece com elas
[80:20] deixa eu falar uma coisa pra vocês
[80:22] todo mundo querendo falar
[80:24] o mundo inteiro ele tá querendo falar
[80:26] e ninguém tá querendo escutar
[80:28] o que eu digo quanto é isso
[80:30] muitas das vezes
[80:32] a briga que eu mais tenho
[80:34] com meus closers é o que?
[80:36] cara, você não tá escutando teu cliente
[80:39] não é o problema que ele te fala
[80:41] é intenção que ele te falou isso
[80:43] porque eu estava, eu não tenho tempo
[80:45] tá, mas qual é a intenção
[80:47] que ele falou isso?
[80:49] é eu resolver o tempo dele
[80:51] ou é desabafar
[80:53] ou é ele pegar e falar assim
[80:55] cara, eu não tenho tempo
[80:57] por isso que eu não conseguiria aplicar o teu projeto
[80:59] o que ele quis dizer
[81:01] com essa fala que ele me fez
[81:03] porque tem várias interpretações diferentes
[81:05] pra mesma fala
[81:07] então a todo momento
[81:09] eu não fico pensando
[81:11] exatamente, eu não só escuto
[81:13] o que o meu cliente falou
[81:15] eu entendo a intenção dele
[81:17] e aí eu não respondo
[81:19] sobre o que ele falou diretamente
[81:21] mas eu respondo
[81:23] sobre a intenção que ele tinha
[81:25] com aquela fala
[81:27] porque você tem uma facilidade
[81:29] maior de fechar com mulheres, por exemplo
[81:31] porque a mulher
[81:33] ela vai falar e é muito fácil
[81:35] você pegar a intenção dela
[81:37] é muito fácil você entender
[81:39] quando ela fala que ela tá preocupada
[81:41] quando ela tem medo, quando não sei o que
[81:43] e aí você pega e fala assim
[81:45] cara, eu entendo esse medo
[81:47] esse medo é normal, ele acontece
[81:49] por causa disso, disso, disso e aí você entende
[81:51] porque você tá entendendo
[81:53] às vezes ela nem falou que tá com medo
[81:55] mas a própria fala dela transpareceu isso
[81:57] e você percebeu que a intenção dela
[81:59] era demonstrar que ela estava com medo
[82:01] então a grande pergunta pra você
[82:03] criar uma afinidade com qualquer pessoa
[82:05] é entender a intenção que essa pessoa
[82:07] tem por trás de cada coisa
[82:09] isso é usado dentro da psicologia
[82:11] quando você chega
[82:13] as pessoas elas começam a associar seus comportamentos
[82:15] com às vezes um comportamento da infância
[82:17] qual que é a intenção
[82:19] que essa pessoa tem de afastar
[82:21] as pessoas da vida dela
[82:23] ah, aí o médico
[82:25] o médico não
[82:27] psicólogo ou terapeuta
[82:29] ou seja lá o que for
[82:31] ele vai pegar, ele não vai olhar assim
[82:33] essa pessoa, você tem que parar de afastar
[82:35] as pessoas da sua vida porque senão a consequência
[82:37] é essa, é essa
[82:39] ele não faz isso, o que ele faz?
[82:41] ele tenta buscar o por que que ela faz isso
[82:43] pera aí
[82:45] você já se machucou
[82:47] uma vez na tua infância
[82:49] o que que acontecia
[82:51] você foi traído, o que que aconteceu
[82:53] por que que você afasta as pessoas
[82:55] você sente que
[82:57] não pode confiar nas pessoas
[82:59] e aí você vai entendendo ali
[83:01] com ela antes
[83:03] para entender o que está acontecendo com ela agora
[83:05] para entender a consequência dos atos dela no futuro
[83:07] isso parece complicado
[83:09] mas não é
[83:11] parece muito difícil a gente entender
[83:13] isso durante uma reunião de vendas
[83:15] mas não é, não é
[83:17] então todas as intenções
[83:19] e toda a afinidade que eu vou criando com essa pessoa
[83:21] é literalmente eu consigo criar um linguajar
[83:23] com ela
[83:25] então pode ver o cliente que for
[83:27] normalmente, eu não vou ter nada parecido
[83:29] com esse cara
[83:31] só que de eu entender
[83:33] e por que que eu consigo ver ele muito?
[83:35] porque eu sou muito bom nisso, em ler a intenção
[83:37] da pessoa através da fala dela
[83:39] cara, teve um cara
[83:41] que eu fui fazer uma reunião, uma imobiliária
[83:43] que faturava meio bilhão de reais
[83:45] faturava ainda, fatura meio bilhão de reais
[83:47] essa imobiliária que fatura meio bilhão de reais
[83:49] o dono chegou, ele estava no aeroporto
[83:51] esperando um voo
[83:53] ele ia para sei lá onde na Europa
[83:55] ele estava esperando um voo
[83:57] 15 minutos para vocês me provarem que vocês são bons
[83:59] o que que eu fiz?
[84:01] cara, eu li a intenção dele
[84:03] sabe qual que era a intenção dele?
[84:05] eu li ali naquele exato
[84:07] frame, eu falei assim, cara, esse cara
[84:09] ele teve que se provar muito na vida
[84:13] seja ele herdeiro ou não
[84:15] e eu preciso descobrir isso
[84:17] ele teve que se provar muito na vida
[84:21] e esse é um ponto que eu trouxe para ele
[84:23] a primeira frase que eu soltei na reunião, eu falei
[84:25] nossa que bacana, cara
[84:27] você ter falado isso, que eu adianto muitas coisas
[84:29] que eu vejo que todos os empresários
[84:31] assim como eu e assim como você
[84:33] tiveram que passar por um momento
[84:35] aonde a gente precisa provar
[84:37] que a gente é muito bom e quando a gente consegue
[84:39] provar isso, é que a gente realmente
[84:41] alcança o que a gente quer
[84:43] você já fez isso, agora está na minha vez
[84:45] cara, eu comecei a reunião assim, o cara
[84:47] ele ficou uma hora
[84:49] com a gente em call
[84:51] senão que ele tinha 15 minutos
[84:53] e essa uma hora que ele ficou, ele só saiu
[84:55] realmente, senão ele ia perder o voo
[84:57] então quando a gente faz
[84:59] isso e a gente cria essa afinidade
[85:01] vocês percebem que é muito além
[85:03] da fala desse cara, o que a maioria dos
[85:05] profissionais iria iniciar falando
[85:07] ah, então tá bom, deixa eu mostrar a minha metodologia
[85:09] eu não
[85:11] primeiro eu coloco a minha posição
[85:13] de cara, eu te entendo
[85:15] olha como eu sou parecido com você
[85:17] eu estou cantando me provar, você se provou
[85:19] em algum lugar do passado, logo nós dois
[85:21] estamos ali no mesmo desafio
[85:23] logo nós dois criamos uma conexão
[85:25] e aí a gente fechou
[85:30] com esse cliente inclusive
[85:32] então não é difícil você fazer
[85:34] todas essas coisas, o que é difícil
[85:36] você entender que essas coisas
[85:38] elas vão te levar a uma venda final
[85:40] beleza
[85:42] até aqui tudo ok, está dando para entender
[85:44] porque quando a pessoa falava
[85:46] que ela tem pouco tempo, a gente falava
[85:48] então a gente vai ser bem breve
[85:50] e a gente é massável
[85:52] já aconteceu várias vezes
[85:55] e aí você tem que entender se
[85:57] isso vai vir muito do fim da hora
[85:59] eu não posso falar, a pessoa tem tanto tempo
[86:01] ah, então essa pessoa ela tá falando
[86:03] ela tá fazendo isso, ou porque ela não quer falar com você
[86:05] às vezes ela tem um pouco tempo mesmo
[86:07] às vezes o dia a dia dela
[86:09] é com pouco tempo, às vezes ela tá corrida
[86:11] por causa de alguma coisa, às vezes ela
[86:13] não quer falar com vocês
[86:15] enfim, são vários fatores ali que vocês vão
[86:17] precisar analisar instantes
[86:19] só que o cérebro de vocês já entendem isso
[86:21] vocês só precisam começar a externalizar
[86:23] e esse externalizar
[86:25] muitas das vezes é
[86:27] entendo que você tá corrido ali
[86:29] a vida de um empresário
[86:31] é muito corrido
[86:33] chega a ser louco
[86:35] às vezes parece
[86:37] que todo mundo tem tempo
[86:39] você trabalha e faz um monte de coisa
[86:41] e não dá nem para entender como a galera
[86:43] tem tempo para ficar fazendo besteira
[86:45] tudo mais, saindo
[86:47] às vezes eu só de
[86:49] olhar para a pessoa eu consegui identificar isso
[86:51] é verdade isso
[86:53] é funcionário isso, é funcionário aquilo
[86:55] aí o cara começa a desabafar
[86:57] ali eu criei uma afinidade sem iniciar minha reunião
[86:59] chega 10 minutos de reunião
[87:01] o cara tá cagando por tempo
[87:03] já fiz reunião de 3 horas
[87:05] com um empresário muito grande
[87:07] e obviamente
[87:09] quanto maior o empresário, mais eu vou querer
[87:11] fazer afinidade com ele, mais eu vou querer explorar
[87:13] a afinidade com ele, por que?
[87:15] porque eu sei que esse cara, tecnicamente
[87:17] ou em questão de case de resultado
[87:19] tem outras 50 empresas melhores que a minha
[87:21] tá, isso é algo que vocês precisam entender
[87:25] sempre vai ter alguém maior
[87:27] que você dentro do mercado
[87:29] só que se você se comparar com isso
[87:31] cara, tá boa, você nem
[87:33] joga o jogo
[87:35] e aí a gente vem para um ponto de escassez
[87:37] o ponto de escassez
[87:39] eu uso ele de maneira diferente
[87:41] do que a maioria das pessoas usam
[87:43] tá, eu não fico assim
[87:45] cara, eu tenho essa oferta
[87:47] essa oferta é pra agora e se você sair
[87:49] ou se você morreu
[87:51] sim ou não, sim ou não direto
[87:53] como é que é?
[87:55] sim ou não claro né
[87:57] sim ou não, claro, isso é exatamente
[87:59] então quando a gente começa nessa
[88:01] parte de escassez
[88:03] cara, eu acredito que o mercado
[88:05] ele utiliza isso de uma maneira muito errada
[88:07] e eu puxo esses casez
[88:09] muito para o lado do que o cara me trouxe
[88:11] eu vou trazer esses casez
[88:14] cara, se disse que tá totalmente sem tempo
[88:16] bora resolver esse tempo agora
[88:18] outro que é ficar mais sem tempo
[88:20] ainda e no futuro
[88:22] a gente sempre adia isso
[88:24] e você nunca conseguir fazer
[88:26] porque você sabe que você já tentou
[88:28] outras vezes e você não conseguiu
[88:30] realmente conseguir o tempo que você
[88:32] falou que precisava
[88:36] tu acredita que isso que eu falei é
[88:38] verdade, acredito
[88:40] então você acredita que isso aqui resolve
[88:42] o tempo que você tá perdendo
[88:44] e é escassez que eu trago
[88:46] 100% das vezes é
[88:48] algo que ele me falou
[88:50] eu vou trazer a escassez que é real dele
[88:52] e não do meu produto
[88:54] que depois eu precisar fazer follow up
[88:56] com esse cara eu vou fazer como
[88:58] qual credibilidade eu vou ter
[89:00] para fazer follow up com esse cara
[89:02] porque 35% das pessoas elas vão comprar com você
[89:04] no primeiro momento
[89:06] eu tenho 70% de taxa de conversão nossa
[89:08] sabe o que foda mas é
[89:10] os outros 35% eu faço follow up
[89:12] durante um ano inteiro
[89:14] que nenhum vendedor, quase nenhum vendedor
[89:16] tá disposto a fazer então quando a gente
[89:18] puxa isso cara
[89:20] eu preciso entender desse cara
[89:22] qual que é o grande ponto dele
[89:24] que
[89:26] realmente vai fazer ele comprar
[89:28] que realmente eu vou gerar uma escassez nele
[89:30] e todas as minhas reuniões
[89:32] é muito raro eu perder uma reunião
[89:34] e eu perder uma venda
[89:36] sabe por que é raro? porque as vezes ele não
[89:38] compra de mim no momento
[89:40] mas eu consigo nutrir esse cara por tanto tempo
[89:42] e acaba comprando
[89:44] óbvio eu to falando de vendas acima de 10 mil reais
[89:46] abaixo disso é minha taxa de conversão
[89:48] elas são 60% já em reunião
[89:50] mesmo tá mas assim
[89:52] quando a gente parte
[89:54] de um ponto de a gente gerar a própria escassez
[89:56] na vida da pessoa cara é muito
[89:58] tranquilo ela toma decisão mais suave
[90:00] sabe então
[90:02] outro ponto unidade
[90:04] toda vez que eu apresento
[90:06] uma reunião eu não apresento uma reunião falando
[90:08] nós iremos fazer isso
[90:10] eu já apresento a reunião falando
[90:12] quando a gente fizer isso a consequência é isso
[90:14] sabe o que a gente vai fazer
[90:16] você a gente vai pegar
[90:18] a gente vai fazer isso isso isso
[90:20] eu já começo a me comportar como se eu estivesse
[90:22] dentro da empresa dele
[90:24] e aquela visão compartilhada
[90:26] eu entendo qual é o futuro que ele
[90:28] projeta e eu começo a projetar esse futuro
[90:30] e me colocar dentro desse futuro
[90:32] porque a união compartilhada
[90:34] muitas vezes nem a mulher desse cara
[90:36] entende aonde ele quer chegar
[90:38] os funcionários desse cara não entende
[90:40] aonde ele quer chegar
[90:42] muitas vezes a família desse cara não entende
[90:44] aonde ele quer chegar
[90:46] muitas vezes esse cara é o único que entende
[90:48] aonde ele quer chegar e quando ele encontra
[90:50] alguém que tem união e que tá indo pro mesmo
[90:52] direcionamento se coloca nesse direcionamento
[90:54] pra ajudar ele
[90:56] ele simplesmente compra
[90:58] porque ele quer até alguma pessoa pra estar do lado dele
[91:00] alguma pessoa alguma empresa
[91:02] que não necessariamente
[91:04] talvez se torna um melhor amigo dele
[91:06] mas só de ter alguém que tem a visão
[91:08] compartilhada a mesma visão compartilhada
[91:10] que ele vai fazer com que esse cara
[91:12] ele tenha essa sensação e consiga
[91:14] comprar de vocês
[91:16] fechou então quando a gente vai
[91:18] vendo isso isso aqui é muito importante
[91:20] tá eu coloco
[91:22] que esse pessoal não é manipulação mas de certa
[91:24] forma assim tá mas enfim
[91:26] é um é o comportamento humano
[91:28] isso daí ele serve
[91:30] é como a gente reage no dia a dia
[91:32] vocês provavelmente já ouviram todos
[91:34] esses gatilhos lá atrás que eu falei
[91:36] vocês provavelmente já ouviram todos esses
[91:38] princípios lá atrás que eu falei mas
[91:40] talvez não do jeito que eu falei
[91:43] tá porque isso aqui é realmente
[91:45] aplicado pra pra vivência
[91:47] de vocês pra pro contexto
[91:49] e pra realidade de vocês
[91:51] quando as pessoas e esse é o grande
[91:53] problema que tá acontecendo na era
[91:55] de hoje as pessoas elas estão pegando
[91:57] conhecimento e o conhecimento
[91:59] não é as palavras que tem
[92:01] é como aquilo realmente
[92:03] funciona
[92:05] não é o que que é a unidade
[92:07] beleza qualquer um pode explicar o que que é a unidade
[92:09] o que que é a escassez a afinidade a autoridade
[92:11] pode pedir dez exemplos pra ia
[92:13] e falar ali os dez exemplos e mesmo assim
[92:15] não entendeu o que que é
[92:17] e mesmo assim não nunca
[92:19] conseguir fugir do que que é
[92:21] que o sabe
[92:23] ou das explicações
[92:25] ou de criar algo novo a partir de uma
[92:27] cara como que eu cria uma escassez com
[92:29] essa informação que essa pessoa me deu
[92:31] e essas são as perguntas que você
[92:33] tem que pegar e começar a se fazer
[92:35] e essas perguntas vão fazer com que
[92:37] vocês vendam mais então vocês vão perceber
[92:39] a reunião de venda de vocês
[92:41] que só de vocês levarem um site de
[92:43] opa deixa eu parar de vender
[92:45] pro dono da reunião ou pra empresa
[92:47] da reunião e começar a vender pro dono
[92:49] vocês vão ver que isso já
[92:51] vai mudar a venda de vocês
[92:53] pode falar valentia
[92:55] a gente foi uma reunião
[92:57] esses dias foi o amilsson
[92:59] e esse cara já foi R1
[93:01] R2 a gente
[93:03] não tinha conhecido o sócio primeiramente
[93:05] ele foi eu na reunião
[93:07] ele participou dos dois webinars
[93:09] já
[93:11] participou do primeiro webinar a gente marcou
[93:13] uma reunião com ele aí foi R3
[93:15] com o sócio e com
[93:17] e com o amilsson
[93:19] e a gente fez a proposta
[93:21] eu acredito que a gente ia
[93:23] fechar nesse momento tá ligado
[93:25] quando a gente falou o preço
[93:27] eles falaram só
[93:29] aí acho que em si
[93:31] essa reunião foi muito boa
[93:33] mas aí eu me lembro do que tu falou
[93:35] e
[93:37] o que o sócio do amilsson disse
[93:39] na hora da gente fechar a cal
[93:41] que era pra eles decidirem ali no momento
[93:43] era
[93:45] eu não sou uma pessoa que toma decisões
[93:47] no impulso de falar
[93:49] na hora
[93:51] ele falou
[93:53] não sou uma pessoa que toma decisões na hora
[93:55] o que que tu teria falado pra ele nesse momento
[93:59] cara
[94:01] dentro desse ponto eu acredito que
[94:03] não é nenhum que eu teria
[94:05] falado pra ele naquele momento
[94:07] a grande lógica
[94:09] ele participou de dois webinars
[94:11] ele participou de uma reunião
[94:13] e eu ia falar
[94:15] você disse que não toma decisão na hora
[94:17] em relação ao projeto
[94:19] ou em relação aos valores
[94:21] primeiro eu tenho que isolar
[94:23] e entender o que esse cara realmente tá querendo dizer
[94:25] se é relação entre os valores
[94:27] ou se é relação entre o projeto
[94:29] então se o cara ele fala
[94:31] em relação aos valores porque é um investimento
[94:33] pra uma empresa e tudo mais
[94:35] provavelmente ele ia falar
[94:37] porque a gente fala
[94:39] só pra entender
[94:41] hoje a gente passou ali por dois eventos
[94:43] nossos
[94:45] gostaram bastante
[94:47] vocês só precisam tomar uma decisão
[94:49] em questão de valores
[94:51] porque a gente já tem essa questão de valores
[94:53] que normalmente há um impeditivo sim
[94:55] há um impeditivo sim
[94:57] há um risco
[94:59] há um pensamento que vocês querem fazer
[95:01] tipo assim nossa será que é isso que a gente quer investir agora
[95:03] será que a gente quer gastar esse dinheiro agora
[95:05] não seria isso
[95:07] seria
[95:09] mas isso normalmente é uma conversa de dois minutos
[95:11] vamos fazer o seguinte
[95:13] eu preciso muito beber uma água
[95:15] você muta seu microfone ali
[95:17] conversa com o seu sócio
[95:19] porque você não tinha os e vocês decidem
[95:21] porque eu acredito
[95:23] tipo não tudo isso
[95:25] isso tudo que tu falou é foda
[95:27] mas a gente falou o Matheus fala assim
[95:29] o que a gente pode fazer
[95:31] foi algo parecido com isso
[95:33] mas o que a gente pode fazer aqui
[95:35] eu e o Matheus a gente sai da chamada
[95:37] a gente deixa vocês dois aqui pensando
[95:39] conversando sobre o projeto
[95:41] e a gente volta em cinco minutos
[95:43] pra saber o que vocês pensaram
[95:45] e daí foi aí que ele falou
[95:47] essa é uma pessoa que não toma decisão
[95:49] na hora
[95:51] não, mas são desculpas padrões que ele vai dar
[95:53] então a primeira coisa que você tem que fazer
[95:55] é realmente isolar a objeção
[95:57] isolar a objeção
[95:59] porque se você não isolar a objeção
[96:01] e a única coisa que sobra
[96:03] é o fator preço
[96:05] é muito difícil você quebrar essa objeção
[96:07] porque ele realmente vai te dar 30 mil desculpas pra pensar
[96:09] se eu tiro todo o resto
[96:11] e deixo somente o fator preço
[96:13] que ele tá pensando em quesito de valores
[96:15] tá pensando em quesito de valores
[96:17] cara, você tá pensando só em quesito de valores
[96:19] tô pensando só em quesito de valores
[96:21] aqui a gente tem alguns pontos
[96:23] cara, você pode se arrepender em 7 dias
[96:25] você pode me falar um jeito
[96:27] que a gente pode facilitar pra você
[96:29] pra que a gente consiga fazer esse projeto
[96:31] iniciar esse projeto ali
[96:33] que vocês disseram que é algo importante pra vocês
[96:35] e que é o momento de vocês
[96:37] eu só preciso entender como eu posso
[96:39] facilitar nesse quesito de valores
[96:41] não necessariamente
[96:43] o sentido de desconto mais facilitar
[96:45] pra que vocês consigam entrar com a gente agora
[96:47] pra que eu consiga discutir isso com vocês
[96:49] porque às vezes cês chegam numa solução
[96:51] sozinhos e a gente vai
[96:53] ter que marcar outro bate-papo pra gente
[96:55] entender essa solução
[96:57] não tô pedindo pra você tomar decisão agora
[96:59] tô pedindo pra entender como eu posso
[97:01] te ajudar a tomar essa decisão de uma maneira
[97:03] mais fácil nesse sentido de valores
[97:05] que é o único que você realmente falou
[97:07] que tem de dificuldade
[97:09] eu acho
[97:13] que a gente tem que
[97:15] isso daí
[97:17] a construção
[97:19] com ele
[97:21] o que a gente trouxe de agregar valores foi bom
[97:23] mas
[97:25] faltou a interpretação
[97:27] igual o que você trouxe
[97:29] do que ele tá falando
[97:31] por trás das palavras
[97:33] da parte psicológica dele
[97:35] porque se a gente tivesse entendido
[97:37] desde o começo da parte psicológica
[97:39] a gente ter, talvez muito provavelmente
[97:41] uma maneira diferente
[97:43] traga uma escasseza em cima do
[97:45] psicológico dele
[97:47] do real motivo dele
[97:49] e aí aquilo ali
[97:51] talvez
[97:53] e daí a parte de
[97:55] cara
[97:57] dessa parte de a tomar decisão
[97:59] se teria sido construído de uma melhor maneira
[98:01] pra que ele sentisse confortável
[98:03] a fazer aquela ação ali naquele momento
[98:05] mas ele só teria
[98:07] essa consciência de fazer isso
[98:09] cara, eu quero ver mais
[98:11] unidade
[98:13] por exemplo, o que que impidiu vocês na R1
[98:15] no final da R1 e falar assim
[98:17] eu vou fazendo uma proposta que faz sentido
[98:19] você toma uma decisão com a gente
[98:22] ali na hora
[98:24] não entendi
[98:26] na própria R1, muitas vezes eu faço isso
[98:28] eu chego no cliente e falo assim
[98:30] beleza, a gente vai ter uma segunda reunião
[98:32] se eu fizer uma proposta que faz sentido
[98:34] você toma uma decisão com a gente lá
[98:38] legal, a gente não fez isso
[98:40] muito provavelmente você exola a objeção
[98:42] você quebra essa objeção
[98:44] e sabe o pior disso
[98:46] é que
[98:48] o sócio dele não estava passando dica
[98:50] no whatsapp pra a gente vender
[98:52] pro sócio dele, tá ligado
[98:54] ele gosta disso, ele gosta daquilo
[98:56] a gente estava assim
[98:58] desde contra R1
[99:00] sim
[99:02] só que aí, acho que faltou muito
[99:04] acho que isso, mas sim
[99:06] e aí que vem um ponto
[99:08] é a pergunta que você sempre tem que se fazer
[99:10] se ele estava te passando dica
[99:12] é porque ele sabia que o sócio dele
[99:14] de alguma forma não queria
[99:16] e aí você precisava dessa
[99:19] firmeza de perguntar assim
[99:21] cara, de verdade mesmo
[99:23] eu conheço o trabalho com comercial
[99:25] e você nem me contrataria, eu nem seria o bom
[99:27] suficiente se eu não tivesse coragem de falar isso aqui pra você
[99:29] deixa eu entender
[99:31] alguma coisa que você não gostou
[99:33] eu preciso entender exatamente qual que é a tua dúvida
[99:35] o que realmente você acredita
[99:37] que
[99:39] nesse projeto que te preocupa
[99:41] aqui
[99:43] que realmente
[99:45] está fazendo com que você fique com o pé atrás
[99:47] lembra a intenção
[99:49] por que que esse cara está me passando essas dicas
[99:51] por que que isso aqui está acontecendo
[99:53] é sempre a intenção
[99:55] e a intenção às vezes eu posso jogar
[99:57] ela estancará que eu joguei toda a responsabilidade
[99:59] pro cara me explicar por que que ele não quer
[100:01] muitas das vezes ele se abre nesse momento
[100:03] e às vezes ele fala eu quero
[100:05] e se é algo óbvio pra você
[100:07] a única questão é o valor
[100:09] tu me explica em quesito de valor
[100:11] cara, qual que está sendo a dificuldade
[100:14] você percebe?
[100:16] então existem mil maneiras de você fazer isso
[100:18] a única coisa que você precisa entender
[100:20] é qual que é a intenção desse cara por trás
[100:22] pô, a gente poderia ver
[100:24] essa R2 agora
[100:26] eu acho que ajuda muito
[100:28] eu acho que assim
[100:32] foi uma das melhores reuniões que a gente já fez
[100:34] e não era quesito de valor mano
[100:36] para eles
[100:38] não era quesito de valor
[100:40] era quesito da própria
[100:42] da própria desconfiança do cara
[100:44] era alguma coisa internamente, alguma objeção que vocês não captaram
[100:46] pô, você tem essa R2
[100:48] você estava para assistir essa R2 ali
[100:50] muito provavelmente eu consigo
[100:52] captar isso ali só de olhar
[100:54] é uma hora e meia de R2
[100:56] de R4 eu acho que
[100:58] não, mas R4?
[101:00] se foram para R4
[101:02] R1 foi só com a Milson e eu
[101:04] R2 foi eu e Mateus
[101:06] com a Milson
[101:08] aí foi o Webinar
[101:10] aí a gente marcou
[101:12] R3
[101:14] com a Milson e o Romante
[101:16] e o Mateus também e eu
[101:18] era R4
[101:20] coloca aí
[101:22] coloca em 2x a gente vai pulando
[101:24] algumas partes ali
[101:28] eu só preciso entender
[101:30] e muitas das vezes sabe o que aconteceu
[101:32] no interior pelo processo
[101:34] então estava fazendo muito sentido o outro sócio
[101:36] estava indo na empolgação do John sócio
[101:38] mas ele não viu o processo inteiro
[101:40] o primeiro contato com a gente
[101:42] talvez a outra reunião que vocês fizeram
[101:44] fez muito sentido para vocês
[101:46] fez muito sentido para o sócio que participou de todo o processo
[101:48] mas não fez muito sentido para o que estava mais desatualizado
[101:50] entendeu?
[101:52] eu acho que... você tem a engine?
[101:54] eu estou pegando aqui
[101:56] eu acho que o jogo
[101:58] tipo assim
[102:00] a lógica por trás
[102:02] é toda a intencionalidade
[102:04] do que a pessoa está trazendo do outro lado
[102:06] na reunião
[102:08] e a partir disso
[102:10] você vem trabalhando
[102:12] em cima da real intenção de cada palavra
[102:14] que a pessoa está trazendo ali
[102:16] e eu acho que agora
[102:18] o que a gente tem que fazer
[102:20] é achar uma maneira de
[102:22] afiar essa percepção da gente
[102:24] deixa eu parar a minha gente compartilhar
[102:26] para assistir
[102:28] o meu sonho em cima
[102:30] é gigantesco
[102:32] inclusive ele participou ontem
[102:34] antes de ontem no caso
[102:36] a gente não chamou ele mano
[102:38] só manulando o grupo e ele participou
[102:40] ele entrou
[102:42] e aí garotada
[102:44] beleza
[102:46] você está muito bonito
[102:48] você consegue entender assim?
[102:50] eu consigo, só está meio baixo
[102:52] para mim que nem vim
[102:54] não consegui
[102:56] tá no
[102:58] como é a coisa que tiver no meu drive
[103:00] às vezes eu compartilho
[103:02] tá bem baixinho para mim
[103:04] tá difícil de ouvir
[103:06] pera aí
[103:21] tá saindo a cesta
[103:23] daí
[103:32] depois libero a cesta
[103:53] alo alo
[103:55] com um pouquinho mais óbvio
[103:57] eu estou cada dia mais bonito
[103:59] mais velho
[104:01] é assim
[104:03] eu posso
[104:05] tá muito bonito
[104:07] que nem vinho
[104:09] tá bom para escutar
[104:11] que qualquer coisa
[104:13] eu escutava mais alto
[104:15] cara eu acho que seria o ideal
[104:17] me manda que o drive eu compartilhe
[104:19] a tela e a gente escuta por aqui
[104:21] tá aí no grupo
[104:23] vou ver aqui
[104:28] e aí você consegue controlar também
[104:30] nas partes da reunião e ir adiantando
[104:32] para tudo entender
[104:34] e eu acho que ali
[104:38] Tino
[104:40] se não analis eu acho que a gente
[104:42] trouxe muita coisa técnica da reunião
[104:44] foi uma hora e quarenta e oito
[104:46] mas muita coisa técnica
[104:48] e muita sacada para eles
[104:50] às vezes a condução
[104:52] não seria talvez seria coisa técnica
[104:54] para ele
[104:56] mas foi uma reunião muito boa
[104:58] foi
[105:00] foi uma reunião que a gente
[105:02] era uma reunião com certeza
[105:04] que a gente ia vender
[105:06] mas talvez foi boa na percepção
[105:08] que a gente tem atual de vendas
[105:10] talvez na percepção do NIMO
[105:12] de condução
[105:14] é uma pergunta
[105:16] que eu quero fazer para vocês
[105:18] vocês querem um feedback com
[105:20] sim
[105:22] inclusive eu era para falar isso desde o começo
[105:24] se você achar
[105:26] a oferta nossa e você acha que aquela oferta
[105:28] é uma bosta
[105:30] eu não acho que é ruim a oferta
[105:32] eu acho que é ruim para vocês
[105:34] eu acho que a reunião por si só
[105:36] não deve estar boa
[105:38] a gente é direto que a gente pode
[105:40] rasgar o verano
[105:42] pelo amor
[105:44] pelo amor
[105:46] pelo amor
[105:48] e aí garota beleza
[105:50] eu tô falando de mais bonito
[105:52] mas é assim
[105:54] é muito bonito né
[105:56] que nem vinho né
[105:58] que nem vinho
[106:00] né
[106:02] e aí
[106:04] eu vou
[106:06] eu vou pular
[106:08] e aí
[106:10] aham
[106:12] aham
[106:14] e aí
[106:16] e aí
[106:19] e aí
[106:21] e aí
[106:23] e aí
[106:25] e aí
[106:27] e aí
[106:29] A gente está falando sobre a produção de conteúdo da Milson.
[106:35] A gente está dando bastante em relação ao nosso primeiro contato e tudo mais.
[106:38] Tem produção também da Solar Sonata, tem bastante coisa feita lá também.
[106:42] Vamos lá, o Romantic entrou aí.
[106:50] Romantic, eu queria te perguntar, você já viu o nosso evento? Eu passei o link para a Milson.
[106:53] Você assistiu ele? Sim, pela verdade eu não consegui assistir a Live Live.
[106:56] O evento já trazia o próximo na sexta, na quinta-feira, às 19h, se você quiser participar vai ser o vivo.
[106:59] Cara, vocês percebem o tanto de raportes que você geraram com a Milson e eu?
[107:04] O tanto de raportes que você geraram com o cara ali?
[107:06] O cara entrou, um de vocês olhou para o lado, o outro pegou a água e tipo assim...
[107:11] Tá bom? O que eu estou fazendo aqui? Tudo mais.
[107:15] Tudo bem, as conversas e a gente analisar o que vocês estão fazendo.
[107:18] Seja traficado, seja atendimento, seja qualquer tipo de extrema indicação também.
[107:21] Na parte comercial e na parte de post-venda.
[107:23] Analisar a operação de vocês em 360, ver o que a gente consegue dar a vocês
[107:25] e passar um tom de vocês para vocês experimentarem, no que vocês precisarem.
[107:28] E daí eu queria saber o que mudou desde a nossa primeira conversa, o que vocês identificam
[107:31] seus cargados hoje e me conta um pouco mais de vocês dois, o que você acredita que dá para melhorar
[107:34] a partir dessa linha.
[107:35] Esse tempo aqui, esses 45 minutos, 50 minutos, é para vocês.
[107:37] Totalmente para vocês, é aqui para vocês experimentarem de vocês de qualquer forma.
[107:40] Tá bom?
[107:41] Abre o jogo e eu mate.
[107:42] Pessoal, para entender melhor, às vezes você trabalha com uma acessoria de Mark,
[107:45] uma acessoria constorível, exalial, qual o foco mais ou menos...
[107:47] É você cheguei contado pelo animo.
[107:49] É o que eu falei, é o que eu falei.
[107:52] É você...
[107:54] Esse cara nem entende, ele nem sabe o que ele está fazendo.
[107:57] Nem sabe quem isso é.
[107:58] Então o primeiro passo não é vocês ouvirem ali realmente o que esse cara tem para dizer.
[108:03] É você realmente se apresentar.
[108:05] Apresentar o que fez o Amilson, gostar de vocês.
[108:08] Você percebe que nesse cara...
[108:10] Cara, eu sou muito bom em ler as pessoas.
[108:12] Esse cara, ele está olhando até com um tom meio que tipo assim...
[108:16] Não diria deboche, mas, pô, olha o rosto dele de tipo assim, cara.
[108:21] O que está acontecendo aqui?
[108:23] Eu nem sei o que está acontecendo aqui, sabe?
[108:25] Tipo assim, o que esses caras estão falando?
[108:27] Eu passei o link para o Amilson, você assistiu ele?
[108:29] Sim, para a verdade, eu não consegui.
[108:31] E assistiu a live lá ainda.
[108:32] Tudo bem.
[108:33] Vocês vêm para fazer um próximo na sexta, na quinta-feira, às 19h,
[108:35] porque a gente participava de seu vivo.
[108:36] E, turma, o título de nossa conversa é a gente analisar o que vocês estão fazendo,
[108:38] seja o trafico do pago, seja o atendimento, seja o que tipo de acessão de clientes
[108:41] e a indicação também, na parte comercial e na parte de posenda.
[108:43] Analisar a operação de vocês de 260,
[108:45] ver o que a gente consegue dar a vocês,
[108:46] e passar um pouco de você para vocês experimentarem no que vocês precisarem.
[108:48] E daí eu queria saber o que mudou desde a nossa primeira conversa,
[108:50] o que vocês identificam os seus cargas hoje
[108:52] e me conta um pouco mais os seus dois, o que vocês acreditam que dá para melhorar?
[108:54] A gente vai ir a partir dessa linha.
[108:56] Esse tempo aqui, esse 45 minutos, 50 minutos, é para vocês.
[108:58] Totalmente para vocês.
[109:00] Outro ponto.
[109:01] Esse cara chegou na reunião,
[109:03] o próprio Amilson percebeu isso.
[109:05] Ele próprio Amilson percebeu isso.
[109:07] Tanto que ele não está, tipo assim,
[109:09] ele não está dentro ainda.
[109:11] Ele não entrou ainda na reunião junto com vocês.
[109:14] Ele ainda está abrindo, sei lá, uma armita dele,
[109:16] o que ele está comendo ali, o que ele está fazendo.
[109:18] Ele não entrou, pô,
[109:20] vocês estavam sorrindo,
[109:22] ele entrou, vocês pararam de sorrir.
[109:24] Olha o sentimento que isso causa dentro de uma pessoa.
[109:26] Imagina você estar num ambiente,
[109:28] cara, olha que louco isso.
[109:30] Imagina você agora entrando por uma porta
[109:32] de, sei lá, uma sala,
[109:34] aí você entra na sala,
[109:36] está todo mundo dando risada.
[109:38] Você entrou, aí todo mundo olha para você,
[109:40] para de dar risada e começa a conversar normal.
[109:42] Qual que é a tua sensação com isso?
[109:44] Eu não gosto.
[109:46] É, faz com ele,
[109:48] tipo, não queria ele, aquele ambiente.
[109:50] Entendeu?
[109:52] Entendeu? Então, muitas das vezes,
[109:54] esse cara, esse cara, ele se sentiu excluído, pô.
[109:58] Ele estava de lado também, né?
[110:00] Pessoal, para entender melhor,
[110:02] antes de você trabalhar com acessoria de marque,
[110:04] acessoria constorível, ideal,
[110:06] eu vou brilhar a tela aqui,
[110:08] eu vou explicar bem certinho visualmente,
[110:10] o que está acontecendo,
[110:12] e a gente entrar com a nossa palavra.
[110:30] Olha que louco isso que vocês estão fazendo,
[110:32] vocês estão mapeando, entregáveis.
[110:34] Eles estão colocando
[110:36] muitas coisas que vocês fazem para um cara
[110:38] que você está fazendo.
[110:40] O que que o Almielson gostou de vocês?
[110:42] Não foi esse monte de entregado,
[110:44] foi o que ele viu nos eventos,
[110:46] foi o que ele conversou com vocês.
[110:48] Então, você não começa por esses entregáveis
[110:50] do que você faz,
[110:52] começa pela metodologia.
[110:54] Está entrando a alguém novo,
[110:56] isso que vocês precisam entender.
[110:58] Vocês precisam entender o que que
[111:00] esse cara perguntou, o que vocês fazem,
[111:02] acessoria, não sei o que.
[111:04] Cara, vocês meteram um pamphletagem aqui, pô.
[111:06] Isso que ele olhou, ele já está olhando para vocês
[111:08] e ele está comparando vocês
[111:10] com qualquer outro cara dentro do mercado digital
[111:12] dentro de agência que eles já
[111:14] conversaram na vida.
[111:36] Você está com pressa de falar para ele
[111:38] porque você quer ouvir o que eles
[111:40] têm para falar,
[111:42] mas ele não te conhece, cara.
[111:44] Leve em consideração
[111:46] um contexto, tipo, toda reunião
[111:48] é contexto sem intenção.
[111:50] O contexto aqui está totalmente aleatório.
[111:52] Pode falar, Matheus.
[111:54] Nesse caso, seria interessante
[111:56] chegar e falar assim, pô,
[111:58] romante, seguinte, a gente trabalha
[112:00] ajudando empresas a crescer
[112:02] e crescer dentro disso na área
[112:04] por formas
[112:06] trazendo isso da área
[112:08] pela sua área comercial, pela área de Marte,
[112:10] pela área de indicação
[112:12] e inclusive, romante,
[112:14] eu quero trazer para vocês aqui como
[112:16] que a gente trabalha no nosso ecosystem
[112:18] de vendas aqui para geração de demanda
[112:20] para a gente converter em clientes.
[112:22] Aí abre a prova social.
[112:24] Seria uma forma de trazer isso
[112:26] ou seria errado também?
[112:28] Cara, seria uma forma de trazer isso.
[112:30] Só que nesse caso aqui
[112:32] ele, cara, eu acho que vocês apresentariam
[112:34] que vocês apresentaram no web, né?
[112:36] Vocês não precisavam convidar ele
[112:38] para o próximo web.
[112:40] Cara, explicar que a minha metodologia
[112:42] a gente fala disso, obviamente, de forma mais
[112:44] resumida, mas eu ia analisando
[112:46] nesse momento, ele
[112:48] tipo assim, se tu analisar o rosto dele
[112:50] ele está
[112:52] prestando atenção, mas tipo assim,
[112:54] ele não está, ah,
[112:56] tendia mais uma agência de marketing falando comigo.
[112:58] Entendeu? Você não fala
[113:00] de marketing, se não fala de entregável,
[113:02] porque o grande potencial de vocês
[113:04] não é entregável, são vocês.
[113:06] É a metodologia.
[113:08] É o por trás. Se você começa pelo entregável
[113:10] o cara acabou, sabe?
[113:12] Acabou. Então primeiro você começa
[113:14] com a metodologia. Nunca você vai
[113:16] começar pelos entregáveis, porque
[113:18] pelos entregáveis, depois, ah, eu vou
[113:20] para os entregáveis e depois eu vou para a metodologia, não.
[113:22] O cara vai pegar a gaveta dele
[113:24] de crenças que ele já tem e vai te colocar
[113:26] junto com todas as outras pessoas
[113:28] que fazem isso, e
[113:30] todas as outras experiências.
[113:32] E o tema do evento é justamente falar
[113:34] o que?
[113:36] Você consegue virar mais sem,
[113:38] sem oportunidades felificadas toda semana,
[113:40] a custo zero, como? Por meio de prestação ativa.
[113:42] A gente faz um evento assim como a gente fez,
[113:44] junto a vários empresários, aí você foi assistir o evento,
[113:46] aí você vai pegar um pouco mais o contexto.
[113:48] Se você assistiu o evento, cara,
[113:50] é a tua obrigação dar o contexto para ele.
[113:52] Sim, sim.
[113:54] Ele não deu o contexto, é a obrigação
[113:56] do evento, entendeu? Então,
[113:58] até um dos pontos, eu acredito que
[114:00] é muito difícil que a reunião
[114:02] ela, cara, olha isso, se estava
[114:04] apresentando,
[114:06] tu acabou a apresentação do que
[114:08] vocês fazem, sei lá, em 3 minutos?
[114:10] É, porque foi rápido.
[114:12] Com alguma dúvida, falei ainda.
[114:14] Com alguma dúvida, sim?
[114:16] Tipo, vocês fazem,
[114:18] não entendia ainda, sabe?
[114:20] Vocês fazem tudo? Ah, beleza.
[114:22] Bacana, pô.
[114:24] Era mais assim, me manda o site,
[114:26] manda o seu site, aí que eu vou dar uma lida, pô.
[114:28] Cara,
[114:30] e o que a gente fala
[114:32] no webinar nosso,
[114:34] os caras vão vender, vender o solar,
[114:36] vender, baile ao solar,
[114:38] vender, produção de custos
[114:40] de energia.
[114:42] A vender não baile ao solar,
[114:44] só que nessa realidade nossa.
[114:46] Eu percebi isso,
[114:48] quinta-feira
[114:50] quando eu deitei na cama
[114:52] porque o nosso webinar deu errado, mano.
[114:54] Sim, sim.
[114:57] E aí, olha que louco isso,
[114:59] vocês vão olhar pro cara aqui,
[115:01] tipo assim,
[115:03] cara, isso não foi
[115:05] nenhuma banda, mano, é que
[115:07] vocês estavam tão confiante.
[115:09] Você vê que até o Amilson mudou a expressão dele,
[115:11] porque ele viu, caralho, o meu sócio não entendeu
[115:13] porra nenhuma, mano.
[115:15] Os caras não me encantaram do jeito que eles
[115:17] não encantaram, é o meu sócio do jeito que eles
[115:19] me encantaram.
[115:21] Ele deu um próprio Amilson também,
[115:23] que já está comprado, entendeu?
[115:25] Não, na verdade,
[115:27] com você de clientes, resolvem com você de
[115:29] fechamento, com você de vendas.
[115:31] Não, apenas com as clientes que a gente
[115:33] caiu com as empresas, caiu muito cliente
[115:35] no nosso portfólio, no nosso
[115:37] atendimento, no portfólio, no atendimento.
[115:39] Ah, você viu que ele já está te comparando.
[115:41] Cara, quando a gente faz o evento,
[115:43] a única coisa que a gente não faz,
[115:45] um aluno me perguntou esse dia,
[115:47] Gustavo, o que você faz quando
[115:49] a gente compara, fala que o outro
[115:51] é mais barato, não sei o que,
[115:53] eu sei lá, isso não acontece com a gente.
[115:55] Porque é tão diferente,
[115:57] tipo assim, pô.
[115:59] Como é que eu teria iniciado a calcum
[116:01] com ele ali?
[116:03] Cara, primeiro eu teria entendido
[116:05] o que que ele, se ele não sabe nada
[116:07] sobre a gente, eu teria ido pro mesmo
[116:09] conteúdo que eu falava no webinario.
[116:11] Cara, deixa até te explicar.
[116:13] Eu, palestra aqui, tá,
[116:15] quase a gente faz algumas palestras
[116:17] com 50 empresários de energia solar
[116:19] todos os meses, então
[116:21] a gente tem isso daqui, foi um desses
[116:23] eventos que eu conheci o Amilson, inclusive,
[116:25] pô, ele te elogiou bastante.
[116:27] Olha como eu vou criar na conexão com o cara,
[116:29] porque ele, até então, ele está sentindo
[116:31] que ele não é bem-vindo, até então,
[116:33] ele está sentindo que é ele contra vocês.
[116:35] Entendeu?
[116:37] Porém, tudo que a gente disse, qualificado, né?
[116:39] Então, a gente trabalhava, trabalhava, trabalhava, trabalhava.
[116:41] Ficou um mês a gente fazer 60 atendimentos
[116:43] pra fechar um, entendeu?
[116:45] Então, até depois, depois de um certo tempo,
[116:47] a gente já inseriu ali no Marge, no Café do Pago,
[116:49] no Souto ali no...
[116:51] No Lourgan, que a gente sempre...
[116:53] Cara, olha, é muito... leiam um livro,
[116:55] um livro
[116:57] que se chama O Corpo Fala, né?
[116:59] Você consegue analisar, tipo, todo mundo
[117:01] dentro da... dentro
[117:03] da reunião com base no, tipo assim,
[117:05] esse livro é muito bom, mano.
[117:07] Esse livro é muito bom. Vocês vão ver que
[117:09] durante uma reunião de vendas minhas,
[117:11] se vocês pegarem uma reunião de vendas minhas,
[117:13] assim, ou...
[117:15] sorrindo. E aí, quando eu vou falar,
[117:17] aí sim, eu expresso com a minha mão.
[117:19] Aí sim, eu me preocupo muito com que
[117:21] o cliente, ele tá vendo sobre mim.
[117:23] Porque... ele interpreta
[117:25] isso ali, mesmo que inconscientemente.
[117:27] Quando eu vejo aqui o Matheus,
[117:29] bom, o Matheus aqui tá com a mão mole,
[117:31] tipo assim, ele tá, pô, deixa eu escutar
[117:33] que esse cara tem pra falar aí.
[117:35] Aí ele até esconde o rosto, tipo, meio que
[117:37] desinteressado. E o nervoso, né?
[117:39] É, você tá coçando o queixo, tipo assim,
[117:41] tá bom, mano.
[117:43] Vamos pro assunto principal.
[117:45] Então, tipo assim, esse cara tá percebendo
[117:47] que, ah, cara, deixa eu mostrar pra
[117:49] esses caras que eles não são tudo isso,
[117:51] não. Entendeu? Inconsentemente,
[117:53] ele tá fazendo isso. Inconsentemente,
[117:55] as próximas falas dele vão atacar
[117:57] vocês indiretamente.
[117:59] Porque ele não tá sentindo
[118:01] um ambiente confortável ali.
[118:03] Vocês veem que até o próprio Wilson
[118:05] ele foi ali cruzar os braços.
[118:08] Então, vocês percebem como que modela
[118:10] isso?
[118:12] Cara, eu tava numa reunião de vendas, um closer
[118:14] meu, ele tava totalmente distraído.
[118:16] Sabe o que eu fiz? Eu removi ele.
[118:18] Eu tirei ele do medo da reunião.
[118:20] E aí ele pedia pra entrar, eu não
[118:22] deixava não. E aí eu mandei, eu falei só um
[118:24] segundo, mandei uma mensagem no WhatsApp,
[118:26] não entra na reunião, depois eu falo com
[118:28] você. E continuei a minha reunião.
[118:30] E depois eu esculachei
[118:32] ele, porque eu falei assim, cara, como
[118:34] que se comporta? A pessoa tá te vendo,
[118:36] ela tá te assistindo. O mínimo que
[118:38] ela espera é o profissionalismo.
[118:40] Então, quando você
[118:42] está numa reunião de vendas, cara, presta
[118:44] muita atenção no que você tá fazendo na câmera
[118:46] também, porque o cliente, ele tá te olhando.
[118:48] O teu corpo, ele vai falar, é uma
[118:50] linguagem não verbal, ele vai falar.
[118:52] Então, se você não tá posicionado
[118:54] aonde você tá escutando esse cara, se
[118:56] você olha pro lado o tempo todo, se você
[118:58] fica ali distraído e ele percebe
[119:00] você tá mexendo em outras coisas, o que
[119:02] que acontece? Esse cara, ele realmente
[119:04] percebe que vocês não estão fazendo
[119:06] isso. Então, vocês percebem que durante
[119:08] a aula inteira, todas as vezes que
[119:10] ou eu fui abrir alguma coisa,
[119:12] ou eu fui fazer alguma coisa, eu avisei
[119:14] vocês? Vocês percebem que
[119:16] quando vocês estavam falando, eu
[119:18] escutei vocês realmente, vocês conseguiam ver
[119:20] até no próprio reflexo do meu óculos
[119:22] que eu tava escutando vocês. Que eu realmente
[119:24] não tava mudando de aba, que eu não tava mexendo no celular,
[119:26] que eu não tava fazendo outras coisas.
[119:28] Isso fez com que vocês me escutassem
[119:30] na hora que eu falasse também.
[119:32] Isso até pra eu dar uma aula
[119:34] e até pra eu dar um treinamento pra vocês.
[119:36] Agora, imagina um cliente que tá numa reunião de
[119:38] vendas. Então, feedback que eu tenho pra
[119:40] vocês nesse primeiro momento também
[119:42] é entendendo, cara, é exito
[119:44] de empatia
[119:46] você realmente escutar e se preocupar.
[119:48] A partir do momento que esse cara
[119:50] entrou, vocês estavam mais preocupados
[119:52] com a proposta que vocês iam fazer do que um
[119:54] próprio cliente que acabou de entrar e não
[119:56] conhecia vocês. Então, vocês
[119:58] excluíram totalmente o que vocês
[120:00] construíram com a Milson
[120:02] e vocês destruíram isso em poucos momentos
[120:04] com o sucesso dele.
[120:06] Não.
[120:08] De uma barreira com o cara.
[120:10] Exatamente.
[120:12] Então, até depois de um certo tempo que a gente
[120:14] já insistiu ali no
[120:16] no orgâneo que a gente sempre
[120:18] busquei alimentar bastante ali, né?
[120:20] Aí, com a Milson e o Instagram ali, eu movimento
[120:22] ali o Google, eu fico utilizando ele também,
[120:24] eu acredito que o nosso funcionamento do Google
[120:26] o orgâneo que tá trabalhando, né?
[120:28] A gente tem resultado do Google também, no orgâneo
[120:30] do Google.
[120:32] Sério, que bacana, pô, quem
[120:34] quem que trouxe esse resultado do Google?
[120:36] Foi ideia tua, foi ideia do a Milson.
[120:38] Quem que puxou isso aí?
[120:40] Cara, dá crédito, cara, tenta entender o que o
[120:42] cara, tenta priorizar, dar alguma vitória
[120:44] para o cara, pô.
[120:46] Para mostrar nossa, a gente é amiga, a gente
[120:48] te admira também, pô. Quem que teve
[120:50] essa ideia aí? Nossa, quem que fez isso
[120:52] daí? Ah, então, tu é o cara por trás
[120:54] dessa parte de tecnologia e tudo mais, pô,
[120:56] parabéns. Da onde que vem isso?
[120:58] Olha, cara, não custa nada, eu tenho
[121:00] patir e, tipo, fazer com que o cara
[121:02] ele goste de mim.
[121:04] É, é uma coisa, pô, que vai levar pouco
[121:06] tempo. Eu tô falando assim, porque vocês
[121:08] falaram que vocês querem um feedback real, eu
[121:10] tô dando um feedback real. Ele tá
[121:12] lançando, pô. Então, tipo assim,
[121:14] não custa nada
[121:16] você pegar e olhar para o cara e falar
[121:18] assim, não, deixou, manisar um pouco,
[121:20] deixa eu entender um pouco esse cara, não
[121:22] é a gente contra eles, até vocês
[121:24] estão na mesma percepção que ele
[121:26] trabalhou com agência realmente boa.
[121:28] Olha, a gente trabalhou com agência
[121:30] realmente boa, tipo
[121:32] de foda-se vocês.
[121:34] Porém, isso não é
[121:36] para o nosso cliente, né?
[121:38] É muito difícil você
[121:40] conseguir um cliente, um cliente
[121:42] que é, como eu posso dizer, um cliente
[121:44] que é um, podia falar aqui,
[121:46] atingir o povo que vai ser o nosso cliente. É muito difícil.
[121:48] Sim, realmente.
[121:50] Cara, e eu vou falar um ponto, tá?
[121:52] Quando o cliente ele traz isso, isso
[121:54] é muito difícil.
[121:56] Ah, é muito difícil você
[121:58] encontrar um cliente
[122:00] que, realmente um cliente
[122:02] muito bom. Quando um cliente
[122:04] normalmente ele me traz esse tipo de objeção,
[122:06] tenta compreender quando ele tá fazendo
[122:08] uma afirmação. Isso aqui não foi uma pergunta,
[122:10] isso aqui foi uma afirmação. Qual que é o pior erro
[122:12] que um vendedor pode cometer nesse momento?
[122:14] Explicar para ele por que dá
[122:16] para trazer um cliente bom.
[122:18] Esse é o pior erro que o vendedor pode cometer.
[122:20] Qual que é realmente
[122:22] certo quando alguém faz uma afirmação
[122:24] para você? Porque ali ele não fez
[122:26] uma pergunta, ele não trouxiasse.
[122:28] Eu acredito que é difícil, eu acho
[122:30] que é difícil. Não, ele trouxe uma afirmação.
[122:32] É muito difícil trazer cliente.
[122:34] O que eu faria nesse caso? Eu concordo
[122:36] com você. Cara, é exatamente por isso
[122:38] que eu tô aqui. Porque eu concordo com você.
[122:40] Porque não adianta se você faz extra-fego pago,
[122:42] não adianta se você trazer um monte de LID
[122:44] e ele não comprar no final das contas. E é muito difícil
[122:46] alcançar esse LID que você falou para mim,
[122:48] que é o LID qualificado para você.
[122:50] Até que a gente tá nessa conversa.
[122:52] Então a gente percebeu que existia
[122:54] esse problema e como que a gente resolve
[122:56] esse problema e como que a gente entendeu
[122:58] esse problema aqui. Olha como eu concordei
[123:00] com ele e depois eu fui explicar como
[123:02] eu trago esse LID qualificado para ele.
[123:04] Entendeu? Pode falar.
[123:06] E a gente pecaníssimo, Matheus.
[123:08] Eu vi várias vezes
[123:12] que a gente não apaga o fogo rápido,
[123:14] que é basicamente assim,
[123:16] quando o cliente
[123:18] faz uma pergunta que é urgente,
[123:20] por exemplo
[123:22] Ah, mas vocês são isso?
[123:24] Você não fala não, a gente não é
[123:26] e explica, tá ligado? E eu também
[123:28] sou assim, tá ligado? Eu sinto isso.
[123:30] A gente não
[123:32] não nega ou deixa claro a resposta
[123:34] e depois explica. A gente explica e depois
[123:36] nega.
[123:38] Quando ele faz
[123:40] uma pergunta direta, você pode
[123:42] responder. Não tem problema você responder
[123:44] a pergunta. Agora, quando esse
[123:46] cara, ele traz uma afirmação
[123:48] você não combate a crença
[123:50] desse cara. Você não vai mudar ele.
[123:52] Qual é mudar ele de cinco minutos?
[123:54] Você vai concordar e vai trazer um novo
[123:56] ângulo de visão sobre aquilo que ele tá
[123:58] falando, entendeu? Deixa eu ver o que você faz
[124:00] aqui. Aqui tem algumas retensas que fazem
[124:02] a teoria tá certa e eu concordo com a
[124:04] gente. Ah, eu concordo.
[124:14] Aí eu já discordo. Ele acabou de falar
[124:16] que o anúncio ele é um dos grandes
[124:18] problemas e realmente
[124:20] você tem que tirar, cara.
[124:22] Eu acredito que o anúncio ele é um
[124:24] mecanismo de encontrar e eu também
[124:26] acredito que isso aqui é um grande
[124:28] problema.
[124:30] Eu acredito que o jeito de fazer um
[124:32] anúncio é um grande problema. Então
[124:34] até um dos pontos é a gente
[124:36] entende por que isso dá errado e aí
[124:38] eu começo por que que dá errado.
[124:40] Não porque como que qual que
[124:42] é o anúncio e essa explicação. Aqui
[124:44] você voltou a falar sobre anúncios.
[124:46] Enquanto você voltou a falar sobre anúncios
[124:48] sendo que ele acabou de explicar, cara,
[124:50] você tem que desviar do foco anúncios
[124:52] nesse momento, tá?
[124:54] Você tem que tirar o anúncio da
[124:56] do do parâmetro no momento pra
[124:58] ele entender que vocês não fazem
[125:00] só anúncios. Porque a partir do
[125:02] momento você falou anúncio de novo,
[125:04] ele pegou o copo de água e foi
[125:06] beber água porque ele pôde de novo
[125:08] realmente.
[125:10] Agora pensa no processo
[125:12] pra você pra falar por que isso dá
[125:14] errado.
[125:16] Agora pensa no processo,
[125:18] tá? Fala o processo,
[125:20] sabe qual é o processo que faz
[125:22] um cliente pagar 15 mil?
[125:24] Pensa no processo,
[125:26] pensa aí.
[125:28] É isso aí.
[125:30] Agora pensa só no McDonald's.
[125:32] Não tem nenhum lugar que você vai e não
[125:34] consegue ver a marca deles.
[125:36] O horrível isso, nunca faz esse
[125:38] processo.
[125:40] Nunca, nunca, nunca, o cara fala
[125:42] não vem do lanche, porra.
[125:44] Nunca, nunca, nunca.
[125:46] Mano, até o Amilson, ele já tá
[125:48] caralho, fudeu esse cara.
[125:50] Mano, o Amilson, ele conhece
[125:52] o sócio dele. Tá achando que
[125:54] ele tá massagando a bochecha
[125:56] dele por que? Porque ele
[125:58] hum...
[126:00] Eu estudei, mano.
[126:02] Deu uma lida sobre esse
[126:04] comportamento humano.
[126:06] É o caso,
[126:08] os poros abrindo por conta
[126:10] da ansiedade, tá ligado?
[126:12] Então, a gente aqui,
[126:14] o Matheus, o Matheus não tava
[126:16] tanto, mas eu tava mais aqui
[126:18] encostando.
[126:20] Sim, e, ó, o Amilson
[126:22] tá começando também. E ele
[126:24] aqui é o que mais tá confiante, porque
[126:26] ele não tá no sentido de defesa,
[126:28] ele tá no sentido de ataque, ele vai
[126:30] voltar a atacar.
[126:32] Ou você só pensa em referência de tanto que
[126:34] ele não tá no sentido de defesa,
[126:36] até no nochidor.
[126:38] Mas eu não gosto desse tipo de
[126:40] exemplo não, porque não remete
[126:42] nada a profissão dele.
[126:44] E essas marcas que são gigantes,
[126:46] elas investem milhões pra aparecerem
[126:48] no Unice por exemplo de TV que não
[126:50] vendem nada, mas só aparecem.
[126:55] Agora, vamos lá, isso é um ponto do
[126:57] porque não funciona de repente.
[126:59] Não os exigem muito mais.
[127:01] As pessoas, principalmente lids
[127:03] que vendem de tráfico pago, que
[127:05] é de venda. Estão fechados, mas não fecha contigo.
[127:07] A quarta vertente é que tem taxação em cima do anúncio.
[127:09] Então é uma solução que eu não reconhecei.
[127:11] Cara, sei lá, ali parece que tu...
[127:18] Olha como fica muito louco isso.
[127:20] Tu inicia, a primeira coisa que tem dentro do teu mapa mental
[127:23] é tráfego pago.
[127:25] E aí o cara fala que não gosta de tráfego pago,
[127:27] tu começa a meter pau no tráfego pago
[127:29] usando exemplos de Coca-Cola
[127:31] e fala de taxa de anúncio do... mano,
[127:33] tá desconexo com o que esse cara quer saber.
[127:36] Não deveria nem ter falado, não é mano?
[127:38] Eu acho que tá meio sem rumo ainda, a reunião.
[127:42] Ainda não... o cara não entendeu
[127:44] qual é o objetivo da reunião ainda e nem eu.
[127:46] Quando eu parar de falar, tu vai ver que vai fazer sentido.
[127:49] O super consciente dele, mano.
[127:51] Eu entendi também um pouco aqui.
[127:53] Tipo assim, quando ele viu ali no mapa mental
[127:55] tráfego pago, ele já esqueceu tudo
[127:57] que a gente já falou depois disso.
[127:59] Tu deu ênfase na panfletagem
[128:01] quando tu tava explicando o mapa mental.
[128:04] Verdade.
[128:06] Entendeu? Então, tipo assim,
[128:08] bora lá, bora lá.
[128:10] E vamos a gente perguntar, é,
[128:12] você parava de justiça na panfletagem
[128:14] que foi em que ano mais ou menos ali,
[128:16] pra gente entender o que é isso?
[128:18] Até o começo dos dois mil e cento e quilo,
[128:20] isso mais, isso mais.
[128:22] Não sei o adetado.
[128:24] Não é bom fazer tráfego pago,
[128:26] por causa da justiça.
[128:28] Matheus vem e pergunta,
[128:30] se vocês ainda não tráfego pago,
[128:32] até aqui.
[128:34] Pode se deu ou não?
[128:36] Não leva isso como regra, mas é uma interpretação do...
[128:38] Eu quero conhecer o negócio,
[128:40] eu falo que caralho fodeu.
[128:42] Às vezes o cara dá um poceira mesmo.
[128:46] Mas ali você tem que levar em contexto,
[128:48] cara, você consegue processar isso,
[128:50] tipo, automaticamente, sabe?
[128:52] Consegue processar essas...
[128:54] Agora que você falou, eu vou perceber mais também.
[128:56] Sim, sim. Mas cara, eu vou dar uma lição
[128:58] de casa pra vocês.
[129:00] Toda hora, muitas vezes nas reuniões,
[129:02] eu vejo assim,
[129:04] ele tá fechado, é tipo sem a dele,
[129:06] mas ele fica retraído, mano,
[129:08] você tá muito fechado.
[129:10] Aí ele ri mais.
[129:12] Muitas vezes, mano,
[129:14] só que aí o meu erro é o quê?
[129:16] Eu até mandei um WhatsApp dele,
[129:18] eu falo, na nossa carro aqui,
[129:20] eu vou até falando,
[129:22] que não é que a gente tava aqui,
[129:24] ele tava olhando pra baixo assim,
[129:26] e tava dando a intenção,
[129:28] parecia que tava mexendo no celular.
[129:30] O Nemoto vai achar
[129:32] que você não tá prestando atenção na aula.
[129:34] Mas eu presto, você pode ver,
[129:36] que todas as vezes você falou isso,
[129:38] ou alguns momentos depois,
[129:40] eu já chamei e usei ele como exemplo.
[129:42] Porque eu tô percebendo,
[129:44] cara, eu tô olhando pra vocês o tempo todo.
[129:46] Então você pode ver, aí eu explico uma coisa
[129:48] e eu dou exemplo, então
[129:50] pega isso como exemplo, Valentino,
[129:52] pega isso como exemplo, Mateus,
[129:54] e aí eu fico dando esses exemplos,
[129:56] porque eu tô te trazendo pra conversa.
[129:58] Gente, eu te trago pra conversa,
[130:00] você nem percebe o que eu tô chamando de tensão, sabe?
[130:02] E isso, tipo assim,
[130:04] às vezes eu consigo
[130:06] perceber isso no Valentino, na reunião de vendas.
[130:08] Só que aí eu não faço uma alta análise
[130:10] em mim, porque
[130:12] aí muitas vezes, Valentino,
[130:14] aí a gente troca ideia
[130:16] enquanto tá reunião pra alinhar
[130:18] alguma coisa pra continuar a reunião.
[130:20] Só que se você troca a ideia,
[130:22] vai saber que você tá mandando mensagem.
[130:24] E isso já não é bom porque disponei.
[130:26] O Valentino agora tá, tipo,
[130:28] eu faço isso mesmo, mas eu tô prestando atenção.
[130:30] Eu tô nos negócios aqui e tudo mais.
[130:32] Eu tô ouvindo, se a pessoa me perguntar
[130:34] o que ela tá falando, eu consigo explicar.
[130:36] É isso que tá passando na cabeça dele agora.
[130:38] E aí como que eu sei disso? Leio mente?
[130:40] Não, ele tá tipo assim,
[130:42] cara, mas não era essa intenção
[130:44] que eu tava fazendo isso, sabe? Não era por mal.
[130:46] Então quando a gente começa a analisar as pessoas,
[130:48] a gente começa a ficar muito óbvio
[130:50] que elas estão pensando.
[130:52] E a gente começa a ter muito mais empatia
[130:54] na mente da pessoa, mas não, a gente só tá
[130:56] prestando atenção, sabe?
[130:58] É o sentido lógico que a gente falou, entendeu?
[131:00] Então tipo assim, não é porque o Valentino
[131:02] agora tá cocendo o braço, que ele tá
[131:04] nossa, se sentindo intimidade
[131:06] ou ele tá...
[131:08] Não, ele tem um ponto ali que, tipo,
[131:10] ele tá recebendo feedback.
[131:12] Inclusive, quando a gente tá recebendo
[131:14] um feedback e a gente já entendeu o feedback,
[131:16] qual que é o nosso comportamento principal?
[131:18] A gente fica assim, ó.
[131:20] Porque a gente quer confirmar que a gente
[131:22] quer demonstrar pro outro, que a gente entendeu pra,
[131:24] tipo, para de falar disso logo.
[131:26] Vamos pra próxima etapa.
[131:28] Eu já entendi, porra.
[131:30] Eu tenho muito...
[131:32] Eu tenho muito, mas
[131:34] é, quando você tá falando, eu tô
[131:36] balançando a cabeça, eu tô concordando com tudo que você tá falando.
[131:38] Não, é que depende do ritmo, depende do ritmo.
[131:40] É o que eu falei, tudo é contexto.
[131:42] Tudo é contexto, entendeu?
[131:44] Então tipo assim, é muito bom a gente
[131:46] estar tendo esse papo, porque vocês
[131:48] estão entendendo que várias coisas que
[131:50] você tá falando, as vezes um detalhe que
[131:52] vai fazer vocês venderem muito, entendeu?
[131:54] Às vezes é um micro detalhe.
[131:56] Até agora, mano.
[131:58] 22 milhões de união.
[132:00] Nem eu entendo de onde vocês querem chegar.
[132:02] Não, e essa foi a melhor reunião, né?
[132:04] Imagina pior, né?
[132:06] Imagina pior, né?
[132:08] Ainda falei que a ingrida aqui, que é a...
[132:10] Meu Deus.
[132:12] Comendo canela.
[132:14] Comendo canela.
[132:16] Comendo canela.
[132:18] Eu não sou com uma caneta.
[132:25] O cara tá devorando a caneta na reunião.
[132:37] Aí ele vê ele devorando a caneta,
[132:39] inconsentemente ele pega a caneta, que
[132:41] também começa devorar de novo.
[132:45] É hábito, mano. Cuidado.
[132:49] A gente tem uma empresa pequena, um porte pequeno, outro pequeno de 5 mil pra gente.
[132:52] É muito mais do que a faculdade de milhões, porque o tamanho da faculdade vai investir de milhões ali,
[132:55] pra ela é pouca coisa. O percentual é muito baixo, né?
[132:57] Quando pra gente se incluir um percentual alto, dentro do nosso, da nossa realidade, né?
[132:59] E isso é um por esse motivo que eu conversei com ele e falei, não, vamos mexer por enquanto.
[133:02] Vamos trabalhar por enquanto, porque a gente tem bastante de cação, a gente tem bastante de...
[133:04] Você viu? Por isso que eu conversei com a Milson e falei, não, vamos mexer por enquanto.
[133:07] Ele já não quer fazer, entendeu?
[133:09] Ele já demonstrou aqui que ele não quer fazer.
[133:11] Então, tipo assim, tudo o que vocês falarem agora vai vir contra a criança dele.
[133:15] Ele não quer fazer.
[133:17] Eu deveria estar ouvindo, né?
[133:20] E eu tenho certeza que nenhum dos dois prestou atenção quando ele falou que ele não quer fazer.
[133:24] Que ele conversou com a Milson e que ele não quer fazer, sabe?
[133:28] Acho que o nosso erro, Valentino, é sempre focar em como traz...
[133:33] Tipo assim, o cara tá falando como que a gente vai contornar o que ele tá falando pra gente botar no produto.
[133:39] Tipo assim, conta pra ele e pra trás, é sempre pro produto.
[133:42] E não caminhar junto com a fala dele, que seria o certo.
[133:46] É, mano, vocês estão, sei lá, preocupados com o que vocês vão falar, na verdade.
[133:50] Eu acho que a gente tem que achar a fala dele, porque vocês nem estão ouvindo ele.
[133:53] Eu tava, tipo assim, acho que eu tava mandando.
[133:54] Eu tô indo pro outro lado, assim, sei lá.
[133:58] Eu acho que vocês ficam muito nessa pira de, tipo assim, cara, o que esse cara tá falando,
[134:03] como que eu vou contornar sobre...
[134:05] Cara, escuta primeiro.
[134:06] Eu acho que a gente fica muito no...
[134:08] Ai, a nossa próxima frase tem que ser foda, tá ligado?
[134:12] E daí eu fico aqui, Mateus, e que a gente vai falar.
[134:15] Não, eu vou dar um conselho pra vocês.
[134:16] Vocês não vivem num filme, mano.
[134:22] A primeira...
[134:22] Essa é uma WhatsApp no meio da reunião, a primeira coisa.
[134:26] Sim, a primeira coisa que vocês precisam entender é que vocês não vivem num filme, não, mano.
[134:29] Então, tipo assim, cara, esquece isso daí, tá?
[134:32] Bora lá.
[134:33] Nosso posicionamento da cidade aqui, ele é muito bom, entendeu?
[134:35] Então a gente tem um aviso de contatos ali, o Google também é muito bom.
[134:41] Então a gente tem bastante gente pra trabalhar.
[134:42] Porém, o que tá marrando a gente é que a gente já é cliente, né?
[134:44] Então a gente tem estrutura pra fecer, se precisar, né?
[134:46] Eu tenho a filosofia assim.
[134:47] Eu não vou anulgar o maracão gigante com cada 10 funcionários.
[134:50] Eu não tô tentando...
[134:51] Ô, Valentino, cara, ó a percepção que...
[134:53] Aqui tu tá doido pra falar, mano.
[134:55] Aqui tu tá...
[134:56] Cara, isso daí são sinais, tipo assim, não verbais.
[134:59] Então ele percebe que tu tá doido pra falar.
[135:02] Você vai ver que ele vai parar de falar.
[135:03] Mas às vezes ele ia falar alguma coisa importante.
[135:06] Por isso que quando vocês percebem que, às vezes, quando vocês estão falando, eu pare e faço assim, ó.
[135:12] Porque eu quero que vocês tenham a impressão que eu realmente estou ouvindo vocês.
[135:16] Eu quero que vocês realmente entendam que eu estou ouvindo vocês.
[135:19] Tanto que vocês conseguem terminar a fala de vocês.
[135:21] Vocês conseguem terminar o raciocínio de vocês sem eu pegar interromper vocês do nada.
[135:25] Então, tipo assim, quando ele tá falando, você ficou assim, ó.
[135:29] Aí você ainda se posiciona pra frente e ele entendeu o que tu quer falar.
[135:32] Aí tu ainda dá o sorrisinho de, tipo, hum, eu tenho uma resposta pra isso.
[135:35] Aí o cara te apresenta, tá bom, deixa esse cara falar e quer falar.
[135:38] Depois eu ampliar o meu sistema.
[135:39] Então, se eu tô tendo...
[135:41] Isso ali de serviço de duas pessoas que você consegue fazer,
[135:44] eu vou manter essas duas pessoas até o futebol mental.
[135:45] O dia que eu futebol mental, eu vou até a gente pegar mais pessoas.
[135:47] É o que a gente saudável, não é?
[135:48] Isso.
[135:49] As indicações ali, é...
[135:50] As indicações que você tem, são 80% hoje.
[135:52] O número da data, eu não sei, mas é a maioria.
[135:54] E...
[135:55] Quantas indicações você tem pra conversar com esse peixe?
[135:57] Chega um limeto.
[135:58] As indicações, é praticamente fechado, né, meus?
[135:59] Quando vem indicação, a gente é muito forte.
[136:00] As indicações.
[136:01] Então, é 90% fechada já.
[136:02] Você é só...
[136:03] O que você já pediu, né?
[136:04] Quando vem indicação.
[136:05] Tá. E, mas também, quando conversar com você hoje?
[136:06] Você tem essa data ainda mesmo?
[136:07] Não, não tem. Quantas?
[136:08] Bem, não sei.
[136:09] Indicação?
[136:10] Ah, sei lá, cara.
[136:11] É...
[136:12] Como como a gente tá falando aí?
[136:13] A nossa empresa é...
[136:14] Eu não sei se vocês têm essa...
[136:15] Vocês têm que vender energia solar?
[136:16] Lê?
[136:17] Sim.
[136:18] Tem alguém que vende mais aqui, 10?
[136:19] 10 negócios por mês?
[136:20] Sim.
[136:21] Mas...
[136:22] É 15?
[136:23] Cara...
[136:24] Sim.
[136:25] Sim.
[136:26] Cara, aqui eu abro...
[136:27] Não, vou te mostrar um exemplo aqui.
[136:28] E eu entendi exatamente o que tu quer dizer.
[136:30] Ó, vocês realmente têm?
[136:32] Vocês estavam metendo louco.
[136:35] Isso é importante.
[136:36] Ó, eu vou te abrir aqui.
[136:37] Cara, você abre o exemplo do cara.
[136:38] Tu abre o Google Meu Negócio.
[136:39] Tu compartilha a tela.
[136:40] Eu vou te mostrar ele.
[136:41] E eu vou falar exatamente como que ele fez para quebrar essa barreira ali que você...
[136:45] Que o próprio...
[136:46] Não sei lá o nome desse cara.
[136:47] Romante.
[136:48] Porque vocês não falam...
[136:49] É, vocês não falam o nome dele.
[136:50] E aí nem ele, tipo assim, decorou o próprio nome.
[136:53] Tanto que foi ignorada nessa reunião.
[136:55] Cara, aqui é o momento que tu abre o Google Meu Negócio.
[136:58] Estou apresendo o cliente.
[136:59] Lembra que eu falei de prova social?
[137:01] Eu acho que o Jonas está vendendo a média dos 30.
[137:04] É.
[137:05] Que Jonas, né?
[137:06] Eu acho que o Jonas vende numa média dos 30.
[137:10] Esse cara está inventando o Jonas aí, pô.
[137:12] Que porra de Jonas.
[137:13] Não existe Jonas nenhum, cara.
[137:14] Mostra alguma coisa.
[137:17] Às vezes o cara só quer ver.
[137:19] Às vezes se você tivesse...
[137:20] Mano, aqui você poderia ter salvado a tua reunião de vendas.
[137:23] E tipo assim, mano.
[137:24] Não sei se é a percepção.
[137:27] Marcando Valentino falou sim.
[137:29] Pareceu meio que...
[137:32] Um debaixo, né, mano?
[137:33] Um debaixo.
[137:34] Tipo sim, mas...
[137:37] Calma aí, que...
[137:40] Que é isso, né, mano?
[137:41] É.
[137:42] Eu...
[137:44] Eu estou se mudando de empresa mais comum do mercado, né?
[137:46] Eu não conheço o Jonas, mas eu tenho certeza que o...
[137:49] Eu não conheço o Jonas, mas eu tenho certeza aqui.
[137:51] Por que ele tem certeza, véi?
[137:52] É um que não mostra.
[137:54] Aí, tipo, ele vai tirar as conclusões dele.
[137:56] Vocês não falaram nada sobre o Jonas.
[137:57] Ele vai definir quem é o Jonas na cabeça dele.
[137:59] Porque ele precisa...
[138:00] Olha o que vocês fizeram.
[138:01] Vocês falaram que tem alguém.
[138:04] E que vocês...
[138:05] E tipo assim, isso bateu diretamente...
[138:07] Olha que louco isso.
[138:09] E se eu pego exatamente o que vocês falam e falam assim...
[138:11] Ah, tem um tal pessoa que faz.
[138:14] E ele vende muito mais que vocês.
[138:16] Aí, vocês falam...
[138:17] Ah, não, mas...
[138:18] Ele deve ter alguma coisa ali,
[138:19] não sei o que...
[138:20] Ele vai justificar o fracasso dele.
[138:22] Por que?
[138:23] Porque pareceu uma ofensa direta.
[138:25] Se eu demonstro e falo assim...
[138:27] Cara, Matheus, Valentino...
[138:29] Deixa eu te mostrar o Davi.
[138:31] Porque o Davi tinha exatamente o mesmo problema que você.
[138:33] E, na verdade,
[138:35] ele nem tinha uma oferta tão boa quanto a de vocês.
[138:37] E isso que eu acho bacana.
[138:39] E mesmo ser uma oferta tão boa quanto a de vocês,
[138:41] ele conseguiu fazer isso aqui.
[138:43] Então, deixa eu mostrar isso.
[138:45] Porque eu ainda acredito que vocês,
[138:47] com o potencial que vocês têm,
[138:48] vocês conseguem chegar ainda mais longe.
[138:50] Olha, ele faz isso de vendas,
[138:51] ele tem isso, isso, isso.
[138:53] E se hoje vocês vivem só de indicação,
[138:55] significa que o serviço de vocês é muito bom.
[138:57] Você não concorda comigo?
[138:59] Então, se a gente consegue explorar isso,
[139:01] a gente sempre vai ter mais indicações.
[139:03] E se você consegue chegar no nível do Jonas, por exemplo,
[139:05] cara, você explodiu, você se torna um dos maiores,
[139:07] você não concorda comigo?
[139:09] Olha como eu estou trazendo isso para ele.
[139:11] Ele tem que brigar para o preço,
[139:13] ele consegue brigar para o preço.
[139:15] Puta, se ele tirou essa informação do nada.
[139:17] E vocês não têm nem como refutar,
[139:19] não brigam por preço, não é?
[139:21] Vai ficar aquela briga, sabe?
[139:23] Mas eu tenho certeza que ele vai estar
[139:25] entre os melhores precios aí do mercado, né?
[139:27] Você sabe dizer qual é a idade desse Jonas?
[139:29] 15% de margem de lucro?
[139:31] É, a Ariane.
[139:33] Entendi.
[139:35] O bosta, né?
[139:37] 10% a 15%?
[139:39] Eu entendi.
[139:41] Cara, eu perguntaria aqui,
[139:43] qual é a margem de vocês?
[139:45] Ele se sentiu menos, sabe?
[139:47] Cara, se sentiu aqui, mano,
[139:49] aqui esse cara vai falar, pô,
[139:51] aqui ele já tomou a decisão dele, mano.
[139:53] Eu não preciso nem assistir o resto da reunião.
[139:55] Eu nem quero, na verdade,
[139:57] assistir o resto da reunião, porque eu vou
[139:59] me sentir um pouco maluco com essa reunião aqui.
[140:01] Porque, mano,
[140:03] muitas vezes, você pega, por exemplo,
[140:05] o que é que eu tento...
[140:09] Eu vou tentar achar uma reunião minha
[140:11] aqui, que eu estou vendendo para um lead duro.
[140:13] E eu vendi, acho que,
[140:15] 5 mil reais para um lead que ele, tipo assim,
[140:17] faturava, acho que,
[140:19] 8 mil por mês, deixa eu achar aqui.
[140:21] Caralho.
[140:23] Então você procura aí,
[140:25] eu vou no banheiro dele, rapidão.
[140:34] Mas tu entendeu o que eu quis dizer ou...
[140:36] Deixa eu procurar aqui.
[140:38] Entendi, mano.
[140:42] Parece que eu estava só apressando as coisas, sabe?
[140:44] Tipo, tá, tá bom.
[140:48] Vamos passar para o fechamento, né?
[140:50] Sim.
[140:52] A gente fala que um título não é vender,
[140:54] a gente vai lá e fez merda, né, mano?
[140:56] Pega uma água.
[140:58] Água.
[141:00] Uma água.
[141:02] Estou procurando aqui a...
[141:21] Mano, o quão sinistro...
[141:23] Quão sinistro é
[141:25] quando parem e fazem uma alta análise assim
[141:27] e, tipo assim,
[141:29] igual,
[141:31] quando você trouxe as paradas
[141:33] de olhar o que a pessoa está fazendo,
[141:35] interpretar realmente
[141:37] o sentido de cada palavra da pessoa,
[141:39] você consegue...
[141:41] É só isso daí
[141:43] que a reunião já vai me dar água para o vinho, né, velho?
[141:46] Com certeza, com certeza.
[141:48] Cara, eu tenho um exemplo aqui,
[141:50] de uma reunião...
[141:55] O Dino.
[142:08] Esse cara vem do webinário,
[142:10] os primeiros minutos da reunião,
[142:12] deixa eu compartilhar até aqui.
[142:14] Cara, eu tenho dois exemplos de reunião
[142:16] para mostrar para vocês,
[142:18] eu vou mostrar eles rapidinho.
[142:20] O primeiro é que o cara vem do webinário,
[142:22] o início da reunião com ela,
[142:24] o meu e dela foi uma bosta, tá?
[142:26] E aí eu consegui consertar no final, porque
[142:28] eu vi que ele não estava dando instrateja nenhuma,
[142:30] eu fui lá para o pessoal, mano.
[142:32] E eu comecei a fazer uma amizade com ela,
[142:34] ela é que me faz follow para me vender para ela.
[142:36] Tá ligado? Então, tipo assim,
[142:38] deixa eu...
[142:40] Então, o que eu penso um pouco sobre vocês?
[142:42] Deixa eu só entender melhor, hoje você fica com
[142:44] 50% da condição recorrente.
[142:46] Do recorrente.
[142:48] Esse cara não é nenhum empresário,
[142:50] você faz alguma parceria
[142:52] com transportadoras, lojas de veículos?
[142:54] Cara, mais com lojas de veículos
[142:56] e mais com indicação do próprio associado, né?
[142:58] O cara que tá na nossa base, ele acaba indicando, entendeu?
[143:00] Boa.
[143:02] Mas eu vou contar uma curiosidade sobre
[143:04] minhas unidades vendas, eu abro o mapa mental,
[143:06] escrevo duas coisas e nunca mais
[143:08] se escrevo nada no mapa mental.
[143:10] Por que tu faz isso, mano?
[143:12] Boa. Por que eu pergunto isso, tá?
[143:14] Porque a gente foi fazer uma pessoa rápida de mercado,
[143:16] de cara, existem milhões de lojas de veículos,
[143:18] ela é uma base diferente, gigantesca.
[143:20] Então, o que a gente faz normalmente? Eu sempre procuro.
[143:22] Aqui eu tava ensinando, aqui eu tava
[143:24] querendo vender uma implementação webinário
[143:26] pra ele, tá?
[143:28] Então, pra ele fazer o webinário B2B
[143:30] pra vender pra lojas de veículos
[143:32] e fazer essa correlação de ele vender seguros
[143:34] e tudo mais, enfim.
[143:36] Ele é um empresário direto.
[143:38] O meu cliente, ele...
[143:40] Ele vem de webinário de corretoras de seguros.
[143:42] Não é um empresário direto, mas ele é
[143:44] alguém que atende, ou o meu público
[143:46] vai te dar, né?
[143:48] Exatamente. E aí, o que eu penso, tá?
[143:50] Quando a gente faz uma construção, imagina se a gente faz
[143:52] uma construção pra essa parceria de lojas de veículos,
[143:54] nem que você não ganhe no início, mas você ganha depois,
[143:56] fazer o quê? Cara, faz o seguinte,
[143:58] eu quero saber se a empresa de vocês é aberta pra isso,
[144:00] pra esse tipo de parceria com as lojas de veículos
[144:02] que eu já te falo ali, o que eu tô pensando.
[144:04] Mas é o seguinte, ó, você ganha os dois primeiros meses
[144:06] de recebimento ali, esses 10% pelos dois primeiros meses,
[144:08] depois disso, você não ganha, mas se você não se indicar,
[144:10] você vai ganhando essa graninha.
[144:12] Você percebe que eu dou o exemplo,
[144:14] que eu não vou fazer sentido pra vocês,
[144:16] porque eu não vou perder duas horas do meu tempo
[144:18] explicando um bagulho que eu talvez não faço sentido
[144:20] pro cara, sabe? Então, tipo assim,
[144:22] eu vou trazer pra esses caras.
[144:24] Eu acho que foi nessa reunião, inclusive,
[144:26] que eu quitei o Wesley, velho.
[144:28] Porque ele tava fazendo...
[144:30] A gente faz essa parceria, a gente tem esse atendimento premium,
[144:32] é uma coisa a mais que você pode colocar na empresa de vocês,
[144:34] que a gente tem esse atendimento pra vocês,
[144:36] que o nosso atendimento é diferenciado,
[144:38] que nós somos parceiros que o seu cliente confia.
[144:40] Porque se você tivesse disponibilidade,
[144:42] você teria que respeitar, por exemplo, o direto dono de...
[144:44] O dono de uma X6, por exemplo.
[144:46] Eu não conseguiria pegar o contato desses caras mais caras e vender pra ele criamente.
[144:48] Só que, se eu tenho um monte de concessionários dentro do Brasil
[144:50] e essas concessionários já vendem pros clientes,
[144:52] o que eu posso fazer? Eu faço acordo.
[144:54] Então, eu conseguiria fazer um evento com todas essas concessionários.
[144:56] Então, toda semana eu falaria com 50, 100 concessionários.
[144:58] Essas concessionárias me enviarem indicações,
[145:00] automaticamente eu vou ter quase um multinível ali
[145:02] que o outro rapaz falou, mas você já é isso pra você.
[145:04] E quanto você já é isso? O custo disso é quase zero.
[145:06] Por quê? Vamos lá, quanto tempo eu levo pra ligar pra uma concessionária
[145:08] que tem um outro rapaz, que tem um muito certo,
[145:10] que ele fazia multinível e tudo mais.
[145:12] Eu peguei um exemplo que ele gostava
[145:14] e eu comecei a usar isso de uma pessoa
[145:16] que ele tinha como referência e eu comecei a usar isso
[145:18] durante a reunião.
[145:21] Eu levo três minutos, quatro minutos.
[145:23] Por que você não usa esse óculos?
[145:25] Não, porque o Jorge me deu, eu gosto dele.
[145:27] Não tem nenhum motivo específico.
[145:29] Eu achei que era pra escolher, esconder onde estava olhando.
[145:31] Não tem nenhum motivo específico.
[145:33] Eu só uso ele porque o Jorge me deu, eu gosto dele.
[145:35] E a maioria participa?
[145:37] Se você já é uma empresa de renome, fica muito fácil pra fazer esses eventos.
[145:39] Aí vamos supor que você coloca três, quatro, cinco vendedores pra atuar.
[145:41] Cara, se você coloca seus vendedores, todos os vendedores
[145:43] eles podem convidar pro mesmo evento. E aí a gente vai gerando um volume de parceiros.
[145:45] Imagina, cada concessionária fala assim, não, toma um histórico de clientes, toma isso, toma aquilo.
[145:47] Então a gente oferta, ficaria muito forte pra concessionária
[145:49] porque, cara, você não vai trabalhar, tá?
[145:51] A gente só precisa falar pros seus clientes antigos que você já atendeu
[145:53] e pros clientes novos. Oi?
[145:55] Só a indicação que nós somos parceiros,
[145:57] se você quiser, a gente até chama esse cliente por você.
[145:59] Não tem problema porque ele já comprou o carro com você, sabe quem é você?
[146:01] Você só indica a gente pros clientes novos e a gente vai ganhar muito dinheiro.
[146:03] A gente vai colocar muito dinheiro no seu posto.
[146:05] Então, às vezes até pensar, pô, às vezes a gente não dá uma comissão
[146:07] pelos primeiros dois meses, mas dá uma comissão recorrente que aí o cara, a cabeça do cara,
[146:09] ele vai pensar assim, cara, só ganha 2%.
[146:11] De tudo que eu indicar, daqui a algum tempo eu não tô pagando um aluguel da loja
[146:13] porque quem paga são os clientes que eu indiquei e não tô pagando tal coisa porque quem paga
[146:15] Ah, tipo assim, eu tô sempre olhando pro cara
[146:17] e tô prestando atenção. Enquanto ele tá prestando atenção
[146:19] nunca tô falando, eu tô falando, entendeu?
[146:23] E pra gente ficar muito bom porque imagina,
[146:25] mil lojas de veículos indicando clientes todo dia.
[146:27] E se cada um indicar uma placa é mil placa por mês.
[146:29] Em 12 meses tem 12 mil placas protegidas.
[146:31] E quanto é a quantidade de faturamento?
[146:33] É absurdo, é absurdo, não é?
[146:35] Eu faço ele mesmo pensar nas possibilidades dele.
[146:39] Você vê como eu não falo sobre o resultado,
[146:41] quem fala sobre o resultado é o próprio cliente.
[146:43] E tu gerou conexão ali, né, mano?
[146:45] É, fez o cara sorrir.
[146:47] Exatamente. E, mano, esse é o tipo de lead
[146:49] que ele já, tipo, ele já não whatsapp.
[146:51] Sabe o que ele tava falando?
[146:53] Eu não vou comprar nada porque eu não tenho dinheiro, mano.
[146:55] Ele já não whatsapp o BDR.
[146:57] Então, tipo, assim, é foda.
[146:59] Tem um 450 da placa tiva, né?
[147:01] Talvez dê uns 24 mil de recorrentes, mais ou menos.
[147:03] 24 mil de recorrentes.
[147:05] E esses 24 mil de recorrentes é que ele sempre cada vez mais?
[147:07] Não, não é de Deus. Se eu tiver lojito,
[147:09] você tá me mandando uma venda,
[147:11] você não tem muita venda não.
[147:13] Exatamente.
[147:15] Aí eu falei, porra, eu vou ensinar
[147:17] eles a fazer um trabalho bem feio pra eles
[147:19] começarem até um processo de aquisição de clientes.
[147:21] Eles começarem muito bem.
[147:23] 100% do que eu vendo pra esse cara.
[147:25] Eu comecei a fazer isso, começou a ter, tipo assim,
[147:27] dezenas de milhares de clientes.
[147:29] Então é um evento que ele é uma parte do processo.
[147:31] Você vai entrar no Google agora, tá?
[147:33] E colocar aqui, ó, sei lá, multi marcas,
[147:35] sei lá, caja marga, vou colocar caja marga
[147:37] aqui também, aqui também.
[147:39] Então, se eu colocar aqui, cara,
[147:41] você percebe que eu tô exemplificando,
[147:43] eu tô mostrando na prática uma coisa, tipo assim,
[147:45] cara, eu tô provando o que eu tô falando.
[147:47] Então, lembre que eu falo do processo
[147:49] lógico, vocês falaram ali do processo.
[147:51] Eu falo isso na tua aula, mano,
[147:53] de...
[147:55] Essa multi marcas, caja marga,
[147:57] nem tem o case, né?
[147:59] Não, cara, eu tô mostrando
[148:01] no Google Maps todos os possíveis clientes
[148:03] que ele pode ter, sabe?
[148:05] Então, tipo assim,
[148:07] sei lá, nem conheço,
[148:09] eu nem tenho nenhuma multi marcas que eu tô atendendo.
[148:11] Eu falo isso na tua aula de cinco horas, mano.
[148:13] Sei lá, de 10 lojas que eu convido,
[148:15] quatro, cinco topam em um evento meu.
[148:17] Então imagina, Daniel, a gente faz um evento,
[148:19] vocês, obviamente, tem a parte de prospecção,
[148:21] tem a parte de convite, porque não é uma prospecção chata
[148:23] para vender para os caras e falar assim, ó, eu vou mostrar
[148:25] na loja de veículos como vocês podem fazer oaturamento X,
[148:27] realmente, já com o que vocês fazem, sem adicionar trabalho,
[148:29] sem adicionar complexidade no trabalho de vocês,
[148:31] e a gente vai fazer esse evento e vão ter mais 200 lojas de veículos.
[148:33] Você gostaria de participar? Gostaria de participar?
[148:35] Olha que legal. Nisso, a gente tem um hobby.
[148:37] Aí vai para uma parte onde essas pessoas que tocam participar desse evento,
[148:39] elas entram nesse evento junto com você.
[148:41] E aí nesse evento, a gente faz toda uma construção,
[148:43] em toda uma construção ali, realmente,
[148:45] de venda para esse cara, para ele entender
[148:47] que eles podem fazer parceria para vocês.
[148:49] Cara, já está muito bom, porque esses 10,
[148:51] eles vão enviar os leads antigos que eles tinham,
[148:53] os clientes antigos que eles tinham, é só falar,
[148:55] ah, sei lá, a Vip, multi-marques, te indicou,
[148:57] porque vocês compraram um carro, tão dia e tal coisa.
[148:59] Posso fazer uma ligação com vocês, rapidinho?
[149:01] A gente tem um presente para vocês, a gente tem uma coisa,
[149:03] provavelmente, tem uma estratégia para você, enfim...
[149:05] A reunião, essa foi uma reunião
[149:07] que a maioria das pessoas consideraria ruim,
[149:09] porque o meu cliente ele falou muito menos que eu.
[149:11] Só que você vê, olha o rosto do meu cliente,
[149:13] em todo momento que eu vou enxergando ele,
[149:15] você vai enxergando que, tipo assim,
[149:17] cara, está fazendo sentido pra caramba, entendeu?
[149:19] Ele está realmente entendendo o que eu estou falando,
[149:21] pode falar, Valente?
[149:23] Eu queria ver teu tom de voz no 1.x,
[149:25] a tua velocidade de falo também.
[149:27] Ah, porra.
[149:29] Com uns 10, 15 segundos ali,
[149:31] nem que seja.
[149:33] Eu vei aqui...
[149:35] Ai, como que eu dou...
[149:45] 9, 5, aqui,
[149:47] um bugou o bagulho do Fento.
[149:49] Ta, ta, ta.
[149:51] Olha, eu começo
[149:56] a minha apresentação falando de case, pô.
[149:58] 80KL.
[150:00] Ah, 80KL.
[150:02] A gente tem um lado de Campinas.
[150:04] Aqui na gente tem uma família, né?
[150:06] Deixa eu pular pra parte do outro.
[150:08] De milhares de clientes, eu falei assim,
[150:10] cara, eu tenho um negócio muito bom.
[150:12] Então, um evento, ele é uma parte do processo.
[150:14] Se eu entrar no Google agora, tá?
[150:16] E colocar aqui, ó...
[150:18] sei lá,
[150:20] Cajamar,
[150:22] vamos colocar Cajamar, que tem um apartamento aqui também.
[150:24] Bora lá.
[150:26] Então, se eu colocar aqui,
[150:28] cara, de 5,
[150:30] todas as lojas que eu convido, basicamente,
[150:32] sei lá, de 10 lojas que eu convido,
[150:34] 4, 5 topam
[150:36] em um evento meu.
[150:38] Então, imagina, Danilo, a gente faz um evento
[150:40] no nome da empresa de vocês.
[150:42] E aí, no nome da empresa de vocês,
[150:44] 6, obviamente,
[150:46] tem a parte de prospecção,
[150:48] chata pra vender pros caras, e falar assim,
[150:50] ó, eu vou mostrar na loja de veículos.
[150:52] Não tem nada,
[150:54] a maioria da galera que pede pra ver,
[150:56] assiste uma reunião de vendas minha,
[150:58] eu falo, cara, você não vai achar nada
[151:00] de impressionante, e você nem vai entender
[151:02] o que eu tô fazendo.
[151:04] Simulemente o que eu tô fazendo aí no contexto,
[151:06] intenção, e encaixando a minha oferta
[151:08] no contexto e na intenção.
[151:10] É só nisso, entendeu?
[151:12] Então, tipo assim,
[151:14] eu acho que mais valioso,
[151:16] aqui, dentro do
[151:18] que a gente fez, do
[151:20] treinamento que a gente passou aqui,
[151:22] todo dia inteiro aqui hoje,
[151:24] tá? Eu tenho certeza, vocês esperavam
[151:26] que eu ia abrir um monte de slide, um monte de documento,
[151:28] e eu realmente ia abrir algumas coisas,
[151:30] só que eu percebi que, pô,
[151:32] às vezes é um detalhe que vocês
[151:34] estão fazendo ali de compromisso dentro
[151:36] do convite de vocês,
[151:38] e na reunião de vendas, eu percebi que a oferta
[151:40] de vocês não é ruim, vocês não
[151:42] tem problema em explicar o produto de vocês.
[151:44] Então, eu fui ajustar exatamente
[151:46] que vocês precisam, e isso
[151:48] só aconteceu por que? Vocês viram
[151:50] começando o treinamento sem perguntar
[151:52] alguma coisa para vocês?
[151:54] Vocês viram começando o treinamento sem ouvir
[151:56] vocês, e isso aqui, vocês poderiam
[151:58] considerar como se fosse um treinamento,
[152:00] tipo assim, se vocês olhassem
[152:02] esse treinamento como se fosse uma reunião de vendas,
[152:04] provavelmente vocês viram comprar no final.
[152:06] Por que? Olha como eu tô entendendo
[152:08] todo o contexto de vocês.
[152:10] Olha como eu tô entendendo tudo o que
[152:12] são as dores que vocês estão trazendo,
[152:14] e eu tô indo com base nessas dores
[152:16] para a gente resolver e são microcargalos.
[152:18] Não adianta eu querer resolver tudo
[152:20] ao mesmo tempo, porque se eu resolvo tudo
[152:22] ao mesmo tempo, muitas das vezes
[152:24] eu vou deixar passar um monte de coisa. Às vezes
[152:26] se eu aperto o parafuso, olha que louco,
[152:28] se eu apertar esses dois parafusos, o primeiro
[152:30] de criar o compromisso das pessoas e ir
[152:32] em pro evento de vocês, e o segundo
[152:34] de vocês conseguirem escutar o cliente
[152:36] de vocês para que vocês consigam vender mais,
[152:38] esses dois parafus que eu aperto, já muda
[152:40] isso. Então, e esse que é o ponto
[152:42] que eu quero que vocês entendam, dentro
[152:44] de uma reunião de vendas, às vezes
[152:46] você só precisa apertar um parafuso junto
[152:48] com o cliente para que ele compre de ti.
[152:50] Sabe? Então, a tua oferta
[152:52] ela não precisa ter 30 mil coisas,
[152:54] ela precisa ter o que o seu cliente
[152:56] acredita que vai ajudar ele. Então,
[152:58] o próprio Ormose, ele fala muito disso,
[153:00] ele fala assim, cara, o que você vai
[153:02] fazer enquanto o tempo, tá?
[153:04] Qual que é o valor que isso gera? Qual
[153:06] que é o trabalho que isso gera?
[153:08] Qual que é a garantia que você dá que isso
[153:10] daí é real? Então,
[153:12] ali eu mostrei uma garantia. Qual que é a
[153:14] garantia? Cara, olha como existem várias
[153:16] empresas que eu estou falando. Isso é um
[153:18] tipo de garantia, entendeu?
[153:20] Então, quando a gente vai construindo
[153:22] isso aqui com o tempo, cara, isso se
[153:24] torna absurdo. Eu vou mostrar um exemplo
[153:26] da mulher lá, que eu acho muito bom
[153:28] eu mostrar esse exemplo. Por que?
[153:30] O início da minha reunião com ela
[153:32] foi horrível, foi horrível.
[153:34] Era... Influência...
[153:38] Deixou eu achar aqui a reunião com ela.
[153:40] Essa você conseguiu vender?
[153:44] Adaira?
[153:46] É, você vai...
[153:48] Ela me fez uma conta proposta,
[153:50] mandei um pitch de quatro mil e
[153:52] ela perguntou se eu conseguia fazer por
[153:54] três mil e eu ainda não respondi ela.
[153:56] E ela me fez um follow-up ontem
[153:58] e eu não respondi ela ainda também não.
[154:00] Deixa eu colocar aqui. Mas ela
[154:02] eu estou fazendo de propósito pra
[154:04] pra quando eu entrar em qual qual ela
[154:06] pagar na hora. Cara, foi horrível
[154:10] meu início de reunião com essa mulher.
[154:12] Horrível, horrível, horrível.
[154:16] Deixa eu ver aqui.
[154:20] Nossa, que take maravilhoso.
[154:24] Nossa...
[154:26] Deixa até...
[154:28] Isso é desse ano, né?
[154:30] Cara, é desse... sei lá, acho que é de
[154:32] semana passada.
[154:34] Ué.
[154:42] Ah, ela não participou do meu evento, tá?
[154:44] Inclusive foi uma daquelas ali que a gente
[154:46] tem aquela estratégia que vocês falaram
[154:48] pra... opa, a gente também faz.
[154:50] Vou entrar aqui.
[154:52] Ah, tá. Ah, agora deu certo.
[154:54] Entra pela celular aqui.
[154:56] Só pra perguntar.
[154:58] Boa, boa. E aí,
[155:00] o que a gente fez... a gente ao invés
[155:02] de começar a fazer... aquela já tinha
[155:04] falado que ia abrir a câmera, tá?
[155:06] Porque eu não faço reunião com ninguém
[155:08] com a câmera desligada. É que aí ela
[155:10] abriu a câmera e não dá pra ver porque
[155:12] eu gravei pelo menos...
[155:14] digital. Então a gente tem algumas soluções...
[155:16] Mas ela tá aqui, ó, ela tá com outro...
[155:18] Mas tu pediu pra ela abrir?
[155:20] Não, ela tá com a câmera ligada, é porque
[155:22] ela tá em dois mítios ao mesmo tempo, tá ligando?
[155:24] Perfeito.
[155:26] Ó, ela tá aqui, ela tá em dois mítios ao
[155:28] mesmo tempo. Perfeito, perfeito, perfeito.
[155:30] Tanto que tá dando esse eco.
[155:32] É uma câmera e outra aqui, né?
[155:34] É, no início ela não tava entendendo
[155:36] nenhuma, não tava nem um pouco
[155:38] interessada. Se tu pegar, ó, essa reunião durou
[155:40] uma hora e meia. Se tu pega mais
[155:42] um pouco, sei lá.
[155:44] Aonde que eu começo a...
[155:46] Aqui eu achei um ponto, um gatilho
[155:48] que eu consegui falar com ela. Aí a gente
[155:50] começa a subir ela nessa cadeia produtiva, então é uma
[155:52] análise que é feita mais interno mesmo
[155:54] na empresa. A gente tem um fone específico, coloca
[155:56] ela como o GCC e vai prescindendo ela como
[155:58] um influenciador nessa cadeia pra ter a reunião
[156:00] de uma tipo que faz mais sentido pra marca, né?
[156:02] Então ela não é embaixadora. Então tem
[156:04] vários formatos, depende muito do que a empresa...
[156:06] Até uma dúvida que eu tenho, tá? Porque hoje
[156:08] o nosso motor comercial é muito forte. Então
[156:10] tem uma quantidade de reuniões e quantidade de clientes. Hoje
[156:12] qual que seria o seu objetivo principal? Você conseguiria ter
[156:14] várias empresas ali, realmente, você fazendo esse processo
[156:16] com essas empresas? Ou seu objetivo principal são poucas
[156:18] empresas, mas que pagam muito melhor ali, realmente, pelo
[156:20] processo que vocês fazem pra eles? Qual que seria
[156:22] o seu objetivo? Crescer ali, como a referência que vai
[156:24] cobrar muito claro, ou como simplesmente
[156:26] uma maior quantidade de clientes pra que você tenha
[156:28] trabalhos recorrentes e trabalhos o tempo todo?
[156:30] Essa é uma dúvida que eu tenho, se não
[156:32] dar um sucesso. Porque eu prefiro dedicar
[156:34] tempo de time criativo pra...
[156:36] Cara, aqui, ó, eu...
[156:38] Eu tava tendo dificuldade até esse momento
[156:40] da reunião.
[156:42] Porque eu não tinha achado gargalha ainda dela.
[156:44] E vocês percebem como eu fiquei
[156:46] fazendo pergunta? Tipo, eu fiquei fazendo
[156:48] pergunta. Ó, a gente tá em
[156:50] 54 minutos de reunião,
[156:52] eu ainda tava tentando achar meu ponto
[156:54] de conexão na onde que eu ia abordar e
[156:56] bater junto com ela. Vocês percebem
[156:58] que o slide que tá aberto aí, o slide
[157:00] de evento que eu faço?
[157:02] Por que que é o slide de evento? Porque ela
[157:04] não participou, quem participou é a social dela
[157:06] que foi pra reunião. Então eu tenho que fazer o que?
[157:08] Tem que explicar.
[157:10] Exatamente, eu não coloco
[157:12] tudo isso aqui porque, pô, seria
[157:14] massante ouvir, mas olha como ela começa a abrir
[157:16] a partir do momento que eu entendo o ponto dela.
[157:18] Por isso, grandes indústrias, por isso.
[157:20] Posso dar minha visão? Porém, é isso. Aí vem outro lado.
[157:22] Eu também quero um tipo de processo que seja escalonado.
[157:24] Mas pra isso eu preciso também estruturar
[157:26] algumas coisas que, pra que eu tenha entregas mais rápidas, mais acertivas, mais
[157:28] direcionadas. Então acredito que
[157:30] não excluo nenhum em outro, eu acho que é uma questão de divisão de
[157:32] porcentagem. Então, de onde tinha um faturamento
[157:34] 20% de clientes com um ticket muito mais alto
[157:36] e os outros 80 com um ticket mais baixo
[157:38] que isso seria importante.
[157:40] Então nenhum outro.
[157:42] Posso dar minha visão até mesmo nessa parte de comercial?
[157:44] Hoje eu acredito que um dos grandes fatores que faz com que você seja
[157:46] referência, que você tenha várias agências com fio você e várias
[157:48] empresas com fio você, é por você ainda estar nessa parte
[157:50] do processo comercial, do processo comercial não no processo alecretivo.
[157:52] Quando a gente fala disso, a gente sabe o quão difícil é
[157:54] contratar boas pessoas dentro do Brasil. E isso daí é um fato.
[157:56] Olha como você vai fazendo certos elogios
[157:58] suaves, que tipo vai aumentando
[158:00] a intimidade, vai fazendo com que a
[158:02] pessoa ela goste, mas você
[158:04] para de operacional.
[158:06] Quando eu digo isso, eu digo que
[158:08] eu acredito que no momento que vocês estão, o ideal seria
[158:10] pegar essas grandes empresas, começar a iniciar com essas grandes
[158:12] empresas. Quando você for começar a atender a nível, tipo assim,
[158:14] ah, eu quero que 80% seja uma pequena empresa. Ok, mas
[158:16] nesse momento, se 80% for
[158:18] as pequenas empresas, inevitavelmente você vai ter que aumentar
[158:20] muito isso aqui. Então, por mais que cria essa dependência dentro do
[158:22] início, eu recomendo que você atui com poucas empresas mais
[158:24] tríflos de caixa, que realmente, a tenda seja você atendendo
[158:26] em outro ponto interessante. Quando a gente faz dentro do seu funil de
[158:28] vendas, o que a gente pode fazer? A gente pode posicionar até
[158:30] um influenciador ou outro para uma campanha e tudo mais. A gente
[158:32] já fecha para essa campanha que ela vai fazer.
[158:34] Que eu falei de como eu me posiciono, como se eu já tivesse
[158:36] junto com a cliente dentro do projeto.
[158:38] Tá?
[158:40] Então, tipo assim, eu vou falando ali como se eu já tivesse dentro
[158:42] do projeto. E para outros bares, então a gente já pode fechar, sei lá,
[158:44] o Natal, já pode fechar o Pasco, já pode fechar
[158:46] outras datas ou outros meses ali, para todos os meses
[158:48] essa pessoa ela ter essas campanhas, ela já ter isso garantido. Porque
[158:50] qualquer grande ponto, às vezes... Exatamente,
[158:52] às vezes, e não só isso, tá? Um influenciador,
[158:54] talvez ele não gere resultado, tá? Por mais que a gente
[158:56] tenha que fazer, eu sei disso, porque eu contratava, eu tinha um atleta
[158:58] ontológica, a gente faturava 800 mil reais por mês, eu contratava.
[159:00] Chegou um momento que, tipo assim, eu já não tava nem seguimentar mais,
[159:02] eu falei, ó, eu vou testar todo mundo que der, eu gastava um 50 mil
[159:04] por mês influenciador, eu vou testar todo mundo que der, o resultado
[159:06] eu vou deixar. Então eu conheci você nessa época.
[159:08] Poxa!
[159:10] E aí, um grande ponto que a gente fez foi isso, e aí a gente
[159:12] trouxe essa métrica aqui, talvez nem todos os influenciadores,
[159:14] talvez não seja a questão do influenciador, seja a época do ano,
[159:16] talvez seja um ano, talvez seja um ano... Exatamente.
[159:18] E aí o que a gente poderia elaborar?
[159:20] Doida para falar, Ana.
[159:22] Você abri... Cara, todo momento ela falava,
[159:24] ah, não sei como você tá de tempo, mas eu queria falar disso,
[159:26] eu queria falar daquilo, eu queria falar... E aí a reunião
[159:28] durou quase duas horas, sabe?
[159:30] Então, tipo assim, cara, às vezes é conexão.
[159:32] Tá faltando isso em vocês, sabe?
[159:34] Vocês vendem bem, mano.
[159:36] Vocês têm um produto bom, vocês têm uma oferta boa,
[159:38] vocês têm um processo bom.
[159:40] Eu vejo que vocês capricham no processo,
[159:42] tá faltando literalmente essa
[159:44] parte de se preocupar com cliente de vocês, cara.
[159:46] Eu acho que a gente...
[159:48] A gente se preocupou em melhorar muito
[159:50] na geração da demanda
[159:52] para a gente vender.
[159:54] Mas a gente não estudou
[159:56] e, tipo assim, não tem...
[159:58] Olha o tanto de conta do que a gente já estudou
[160:00] sobre prospecção e geração de demanda.
[160:02] E olha o quanto de energia que a gente colocou
[160:04] para estudar sobre a parte de vendas.
[160:06] E melhorar a parte de vendas.
[160:10] É absurdo.
[160:12] Ô, mano, depois você conseguiu compartilhar
[160:14] um local de vendas suas para a gente...
[160:16] Mano, eu consigo compartilhar essas duas ali
[160:18] para vocês darem uma assistida nas duas.
[160:20] Vocês veram que são duas e eu não é diferente.
[160:22] Eu, cara, tive muita dificuldade
[160:24] no início e depois eu mandei muito bem.
[160:26] E a outra, tipo, só foi ele.
[160:28] Só fluiu.
[160:30] Para que o Wesley entrou na primeira reunião?
[160:32] Cara, porque ele queria
[160:34] assistir à reunião para pegar alguns insights
[160:36] para ver como que eu estava
[160:38] vendendo, mas eu acho que eu quitei ele
[160:40] em algum momento, mano. Deixa eu achar
[160:42] quando eu quitei ele. Porque, cara,
[160:44] olha, essa parada que eu estou prestando
[160:46] com atenção é real, mano.
[160:48] É real. Se vocês verem que algum
[160:50] de vocês dois está quebrando o clima
[160:52] da reunião, quita a pessoa, a pessoa
[160:54] vai entender que ela está quebrando o clima
[160:56] necessariamente. Cara, não sai no WhatsApp,
[160:58] não vai digitar, não vai fazer nada.
[161:00] Porque isso daí vai quebrar até a expectativa
[161:02] do cliente. Deixa eu ver aqui se foi
[161:04] nessa que eu tirei o Wesley.
[161:06] Por que? Percebe?
[161:08] Eu e o cliente morro atento e olha a cara
[161:10] do Wesley.
[161:12] Sabe? Então, tipo assim,
[161:14] eu acho que nessa aqui eu ainda consegui
[161:16] mandar uma mensagem, alguma coisa do tipo
[161:18] ou não foi essa, eu acho que foi na R2
[161:20] desse mesmo cara. Mas assim,
[161:22] eu tiro o meu closer direto.
[161:24] Tiro o meu closer direto das reuniões.
[161:26] Se a gente tem na reunião
[161:28] que o Matheus está gerando mais conexão
[161:30] e eu estou com a lado da reunião inteira posso sair, então?
[161:32] Não. Não é que você precisa
[161:34] sair. É que você não pode ficar assim,
[161:36] igual o Wesley estava. Away.
[161:38] Away. Tá ligado?
[161:40] Então, você esteja prestando atenção,
[161:42] não é porque um está gerando conexão e o outro
[161:44] não. Cara, se você percebe que o Matheus
[161:46] está gerando mais conexão, começa a prestar
[161:48] atenção mais no contexto. Então,
[161:50] você tem mais tempo para ler a intenção,
[161:52] o contexto, às vezes pegar uma objeção
[161:54] que ele trouxe e o Matheus não captuou.
[161:56] Então, se vocês estão em dois,
[161:58] a grande vantagem de você estar em dois
[162:00] na reunião é que um quanto um fala, o outro
[162:02] pode analisar. Enquanto um pensa
[162:04] na resposta, o outro pode pensar
[162:06] na pergunta, na intenção, no contexto
[162:08] o que está acontecendo dentro dessa reunião.
[162:10] Sabe? Então, essa é uma
[162:12] vantagem de fazer a reunião em dupla.
[162:14] Eu faço sozinho porque, de verdade
[162:16] mesmo, eu fico irritado
[162:18] quando alguém não entende o contexto, porque
[162:20] eu já consigo ler sozinho, eu fico irritado
[162:22] quando algum closer ou alguém interrompe
[162:24] a minha reunião, alguém do meu time.
[162:26] Você pode ver todo,
[162:28] exatamente, e quebra a minha linha de raciocínio
[162:30] porque eu já poder energia os próximos cinco
[162:32] passos da reunião quando eu estou entendendo
[162:34] que o cliente precisa. Então, tipo assim,
[162:36] vocês sempre vão ver alguém
[162:38] no meu time entrando comigo dentro da minha reunião.
[162:40] Vocês nunca vão ver ele falando.
[162:42] Sabe? Tipo, que não seja no
[162:44] início, ali e tudo mais. Então,
[162:46] é muito difícil vocês veram eles falando
[162:48] sem eu pedir pra eles falar ou sem ser no
[162:50] início. Por quê? Porque eu sei
[162:52] que eu preciso manter a linha de raciocínio
[162:54] durante essa reunião. Eu
[162:56] sei ler o cliente, eu sei ler o contexto,
[162:58] eu sei ler as intenções e eu sei
[163:00] apresentar oferta. Apresentar uma oferta
[163:02] eu posso, pensa comigo, eu posso treinar
[163:04] qualquer pessoa pra apresentar uma oferta.
[163:07] Mas, eu treinar a pessoa pra
[163:09] vender essa oferta já é uma coisa
[163:11] completamente diferente. Então, pra você
[163:13] vender essa oferta, você vai ter que se preocupar
[163:15] com o cliente de vocês. Simplesmente isso, tá?
[163:17] Simplesmente isso. Esse ponto
[163:19] de conexão. Então,
[163:21] o que que eu recomendo vocês façam
[163:23] agora? Tá? Eu vou mandar essas duas reuniões
[163:25] pra vocês darem uma olhada.
[163:27] Tá? Eu vou mandar algumas
[163:29] eh, eu vou mandar
[163:31] algumas aulas também que eu tenho ali
[163:33] gravado também pra vocês darem mais
[163:35] uma olhada. Mas assim,
[163:37] coisas que vocês precisam imediatamente
[163:39] resolver que se vocês resolverem
[163:41] vocês já vão ter resultado relevante
[163:43] ali e aí a gente já conversa na próxima
[163:45] semana mesmo após essas reuniões
[163:47] que vocês vão ter. Cara, primeiro prestar
[163:49] atenção no cliente, entendeu o contexto
[163:51] não mudem a oferta de vocês, eu não
[163:53] recomendo vocês, não precisam mudar a reunião
[163:55] nem oferta, nem nada do tipo.
[163:57] Cara, muda simplesmente o fato de
[163:59] tentar fazer
[164:01] com que isso faça sentido pra
[164:03] você. Tá?
[164:05] Esquece um pouco que você tá vendendo
[164:07] pra empresa. Tente entender um pouco
[164:09] a pessoa que você tá vendendo. Fechou?
[164:11] Porque é impossível você não vender um
[164:13] produto de 500 conto pra qualquer
[164:15] pessoa que seja.
[164:17] Beleza? Tipo assim,
[164:19] achar o gatilho pra
[164:21] tu trazer o contexto do produto
[164:23] basicamente. Sim, sim.
[164:25] Tipo assim, nem a margem do lucro
[164:27] de lucro da
[164:29] padarice que a gente fala
[164:31] e vou identificar o
[164:33] que que tá por trás ali, né?
[164:35] Não é pra eu falar, velho.
[164:37] Tipo assim, pra definir o nicho e dentro
[164:39] do nicho entender o contexto do produto
[164:41] pra você ser uma referência na hora de
[164:43] conversar com a empresa. Cara, aí eu dou
[164:45] exemplo de supermercado que é baixo e de
[164:47] lucro é baixo. E aí eu falo ainda, cara.
[164:49] Posso fazer uma pergunta? Uhum.
[164:51] Quantos podcast vocês ouviram sobre
[164:53] empresa de energia solar nos últimos
[164:55] tempos?
[164:57] Nenhum mano. Agora, quantos vídeos
[164:59] vocês ouviram sobre a
[165:01] técnica nova, não sei o que,
[165:03] vocês viram nos últimos tempos?
[165:05] Dia nada, mas de vendas
[165:07] é bastante. De vendas, de oferta,
[165:09] de tudo mais. Vocês viram bastante, né?
[165:11] Agora, o que que é mais importante?
[165:13] Vocês aprenderam mais técnica de vendas
[165:15] ou vocês entenderem melhor o público
[165:17] de vocês nesse momento?
[165:19] Acho que é assim, uma coisa é podcast.
[165:21] Mas eu concordo contigo.
[165:23] Mas o fato é que eu parei
[165:25] meu dia um dia só
[165:27] quando eu comecei a estudar o nicho,
[165:29] tá ligado? E eu fiz o que tu falou
[165:31] no treinamento lá das cinco horas
[165:33] de liga pro cara e pergunto o que
[165:35] ele fez, tá ligado? O Matheus não fez
[165:37] isso, é essa parte. Mas eu fui
[165:39] atrás de cada tipo de empresa
[165:41] de diferentes setores ali pra falar
[165:43] com o dono e entender o que que
[165:45] eles estavam fazendo, entendeu?
[165:47] Isso me deu mais profundidade
[165:49] também pra entender.
[165:51] Deixa eu colocar aqui.
[165:53] Cara, isso aqui é meu notebook
[165:57] do PM quando eu entrei
[165:59] no mercado de corretora de seguros.
[166:01] Isso aqui são as coisas
[166:03] que eu fiz ali com IA.
[166:05] Esses são todos os podcasts
[166:07] que eu ouvi. Isso aqui é o texto.
[166:09] Esse aqui é o meu webinar de alto impacto.
[166:11] Isso aqui, tipo, eu ouvi
[166:13] todos esses podcasts,
[166:15] li todos os comentários
[166:17] de todos esses podcasts.
[166:19] Fiquei horas e horas
[166:21] estudando nicho.
[166:23] Pisa ali áudios com base
[166:25] de textos, com bases em referências,
[166:27] com bases em sites.
[166:29] Entendi a estreia de produtos do meu cliente.
[166:31] Isso faz com que eu venha a dar mais.
[166:33] Porque simplesmente
[166:35] tudo o que ele tá falando, eu sei sobre o que
[166:37] ele tá falando.
[166:39] Por exemplo, quando ele fala assim
[166:41] ah, qual que é a margem do seu cliente?
[166:43] Ah, entre 10% a 15%
[166:45] e eu de vocês provavelmente é
[166:47] mais ou menos 8%, certo?
[166:49] Quando eu consigo acertar essas coisas do cliente,
[166:51] ele fala assim, caraca, você tá no meu DRE
[166:53] e aí a gente tipo assim, você sabe
[166:55] o que acontece dentro da minha empresa
[166:57] e cara, isso gera muita autoridade.
[166:59] Então, esses caras aqui
[167:01] que tão fazendo um podcast, por exemplo, desse mercado
[167:03] eles vivem a anos e anos e anos e anos
[167:05] no mesmo mercado e hoje em dia
[167:07] vocês têm a vantagem de encontrar esses podcasts.
[167:09] Sabe? Se eu pesquisar
[167:11] podcast de energia solar, provavelmente
[167:13] a gente vai conseguir umas 90 horas
[167:15] de conteúdo.
[167:17] E muitas vezes você vai ver um conteúdo
[167:19] de alguém vendendo a ideia da energia solar dele
[167:21] para até entender.
[167:23] Então, cara, eu tô lavando uma loja
[167:25] o que eu tô fazendo? Eu tô estudando o meu público.
[167:27] Eu tô, sei lá, correndo
[167:29] eu tô estudando o meu público, eu tô fazendo
[167:31] qualquer coisa que seja, eu tô estudando o meu público
[167:33] eu só preciso colocar e escutar.
[167:35] Fechou?
[167:37] Mano, tipo assim,
[167:39] na reunião de vendas
[167:41] claro que é bom usar a técnica, mas
[167:43] deixa até a técnica, talvez um pouco
[167:45] de lado, tipo,
[167:47] alguns gatilhos fortes, mas
[167:49] realmente o que tá por trás
[167:51] de cada fala da pessoa
[167:53] e as expressões da pessoa da reunião.
[167:55] É, nesse momento é isso que falta pra vocês.
[167:57] Tá.
[167:59] Tem pessoas que eu falo, cara, que falta
[168:01] técnica mesmo.
[168:03] Mas pra vocês falta mais essa parte
[168:05] de conhecimento do público e conexão
[168:07] com o público. Conexão, intenção e tudo
[168:09] mais. Fechou?
[168:11] Eu desenvolvi, mano.
[168:13] Não, vou reiniciar minha fala aqui.
[168:15] Eu fui reunião com
[168:17] uma pessoa que trabalha
[168:19] com geração distribuída
[168:21] que é
[168:23] basicamente assim.
[168:25] A empresa que vende geração
[168:27] distribuída é como se fosse
[168:29] energia suar por assinatura.
[168:31] A pessoa vai lá, chama essa pessoa,
[168:33] ela assina o contrato, não paga nada
[168:35] e ela recebe desconto na conta de energia
[168:37] dela. Só pelo número de porcentagem
[168:39] de desconto, consenso de saber
[168:41] essa geração.
[168:43] Ai, eu ganho uma empresa. Sim.
[168:45] A passagem que a pessoa fala de desconto
[168:47] eu consigo saber, tá ligado?
[168:49] E eu fui... ah, a empresa tu diz?
[168:51] A Safira. Foi a Safira, sim.
[168:53] E daí eu fui reunião
[168:55] com esse cara que se chama Marcos Paulo
[168:57] e na reunião, ele me falou
[168:59] que ele tinha um problema de churny
[169:01] e eu tinha visto a
[169:03] tua reunião ali de cinco horas
[169:05] tua aula, né, de cinco horas
[169:07] aí que tu fala sobre o caminhoneiro, né?
[169:09] Um bagulho assim.
[169:11] E na hora da reunião, mano,
[169:13] eu consegui apresentar pra ele alguma coisa
[169:15] foi basicamente conhecer ele
[169:17] eu não consegui fazer nada
[169:19] nessa reunião, eu tava sozinha nessa reunião
[169:21] e
[169:23] quando eu saí dessa reunião, fiquei puto por isso
[169:25] fiquei puto porque eu não consigo
[169:27] ajudar ele nada, tá ligado?
[169:29] E aí eu fui atrás das maiores
[169:31] empresas que tem, que vêm
[169:33] na geração distribuída pra entender o que eles
[169:35] estavam fazendo. E aí eu percebi
[169:37] que o Marcos, ele estava
[169:39] com duas faturas. Ele tinha um
[169:41] problema de churny porque o cliente
[169:43] se confundia com as faturas
[169:45] pagava a da concessionária
[169:47] que fornece energia
[169:49] e a deles, da Safira, eles não pagavam
[169:51] porque se confundiam.
[169:53] E aí eu fui atrás de saber o que que eles
[169:55] estavam fazendo, outras empresas que são
[169:57] maiores no mercado, o que que eles fizeram
[169:59] pra ter pouco churny
[170:01] pra crescer.
[170:03] E eu descobri que eles têm unificação
[170:05] de faturas.
[170:07] Eu fui atrás de conhecer como é que
[170:09] eles faziam a unificação de faturas.
[170:11] A primeira coisa que eu pensei foi
[170:13] eles foram na concessionária
[170:15] ou na prefeitura e pediram
[170:17] uma parceria pra mandar esse
[170:19] desconto direto na fatura.
[170:21] E aí, pesquisando, não fui no
[170:23] chá de EPT, foi tipo assim no Google
[170:25] ligando também pras empresas
[170:27] falando com o gestor, com o
[170:29] diretor também.
[170:31] Eu descobri que tem como fazer
[170:33] unificação das faturas sem necessariamente
[170:35] falar com a prefeitura concessionária.
[170:37] Desenvolvendo um sistema
[170:39] onde essa automação
[170:41] iria no site
[170:43] e no login dessa pessoa
[170:45] é meio que uma junção jurídica
[170:47] e de inteligência judicial.
[170:49] E pegaria lá e faria basicamente uma fatura
[170:51] unificada e online
[170:53] onde tem um desconto também, a pessoa
[170:55] não pagaria mais a física, pagaria só online.
[170:57] E eu fui atrás disso,
[170:59] eu vi que isso aí resolveu o cara
[171:01] e resolveu o problema dele.
[171:03] E depois dessa reunião
[171:05] eu não consegui mais falar com ele.
[171:07] Não consegui mais falar com ele.
[171:09] Cara, mas olha que legal isso aqui.
[171:11] Isso que você me trouxe
[171:13] é uma história que você deveria...
[171:15] Se tu tivesse contado essa mesma história
[171:17] naquela reunião de Vendas Elito
[171:19] iria ter muito mais respeito daquele cara do que
[171:21] o que você quiser.
[171:23] Você falar assim, cara,
[171:25] meu objetivo aqui é encontrar soluções.
[171:27] Por que a gente fez o Jornal ser sucesso?
[171:29] Por que a gente faz os nossos clientes ser sucessos?
[171:31] Deixa eu te contar uma história.
[171:33] Eu tinha um cliente,
[171:35] cliente dessa empresa, Safira, que tudo mais.
[171:37] Eu fiz isso, isso, isso, isso, isso.
[171:39] Eu não sabia a resposta, a gente fez, buscou assim,
[171:41] assim, assim, assim.
[171:43] E aí uma coisa que
[171:45] você pode falar para ele e falar...
[171:47] Se tu tivesse falado assim,
[171:49] e contar dessa história e a conclusão fosse o seguinte,
[171:51] por essa história
[171:53] você pode ver que nem sempre a gente vai saber
[171:55] mais do que você
[171:57] ou nem sempre a gente vai saber
[171:59] exatamente qual que é o melhor
[172:01] ou como resolver
[172:03] algum desafio.
[172:05] Só que você sempre vai saber que a gente vai procurar
[172:07] e vai encontrar uma resposta para esse desafio
[172:09] e a gente vai resolver ele junto com você.
[172:11] Porque a nossa maior habilidade
[172:13] e a nossa maior capacidade não está simplesmente
[172:15] no que a gente sabe fazer.
[172:17] A nossa maior capacidade está em
[172:19] realmente analisar a situação
[172:21] e encontrar soluções a partir
[172:23] dessa solução, ou a partir dessa situação
[172:25] para que a gente consiga resolver
[172:27] um problema e levar sua empresa para um outro patamar.
[172:29] Então o meu objetivo aqui com você
[172:31] não é simplesmente
[172:33] falar de tráfego pago.
[172:35] A gente encontrar o problema e resolver
[172:37] esse problema juntos.
[172:39] Cara, quando você conta essa história
[172:41] e traz isso aqui para o cara,
[172:43] ele automaticamente abaixaria
[172:45] todas as defensas que você tem.
[172:47] Ou que ele teve ali com vocês.
[172:49] Entendeu?
[172:51] Como tu faz, né?
[172:53] Exatamente.
[172:55] Mas é isso.
[172:57] Pessoal,
[172:59] no geral,
[173:01] eu acho que é isso, tá?
[173:03] Se eu sobrecargar vocês com mais coisa ainda
[173:05] para vocês arrumarem, eu acho que isso aqui já tem
[173:07] conteúdo para, caramba, para vocês trabalharem.
[173:09] Agora é organizar isso.
[173:11] Pegar essas próximas reuniões que vocês vão ter
[173:13] e vender, cara. Eu quero realmente vocês vendo.
[173:15] Deu para entender que, tipo,
[173:17] às vezes não está sendo o problema do WebNar
[173:19] ou às vezes não está sendo o problema ali
[173:21] na própria metodologia e sim,
[173:23] às vezes um fechamento no detalhe.
[173:25] Um detalhezinho, cara. Um detalhe vai mudar tudo, tá?
[173:29] Acho que o Mateus e a gente vai juntos
[173:31] nas reuniões?
[173:33] Cara, pode ir enquanto um fala ou outro escuta.
[173:35] Mas os dois pressão a atenção. Mateus,
[173:37] cara, mão na mesa, cara.
[173:39] Mão na mesa, por exemplo.
[173:41] Tirei esse hábito porque
[173:43] tipo, de ficar olhando para o lado, de ficar colocando
[173:45] a caneta na boca, descondendo a mão, assim,
[173:47] porque, cara, é muito difícil para o cliente
[173:49] lidar com isso, sabe?
[173:51] É muito imprevisível isso para o cliente.
[173:53] Então tenta se posicionar na câmera,
[173:55] por exemplo, tenta deixar alguma margem,
[173:57] por exemplo, se você usa um fundo
[173:59] igual eu, tenta deixar uma margem do lado
[174:01] de vocês para que o cliente
[174:03] ele veja que você tem, tipo assim,
[174:05] para que ele veja teu corpo, para que ele realmente
[174:07] sinta que vocês estão abertos, porque
[174:09] se eu faço isso automaticamente, eu estou preenchendo
[174:11] câmera, eu estou pressionando mais o meu cliente.
[174:13] Por exemplo, vocês estão assim,
[174:15] mas quando eu peguei
[174:17] e coloquei a câmera assim do nada, não ficou esquisito
[174:19] para vocês? Agora,
[174:21] quando eu fico assim, cara, parece,
[174:23] eu pareço uma outra pessoa, parece que eu sou muito
[174:25] mais gente boa do que eu realmente sou.
[174:27] Quando a gente coloca isso,
[174:29] então são certos detalhes, são micro detalhes
[174:31] que vão fazer diferença, tá?
[174:33] A venda ela não mora na construção
[174:35] intera, ela mora no detalhe.
[174:37] E qualquer um pode apresentar um produto,
[174:39] mas nem todo mundo pode vender esse produto.
[174:41] Fechou? Fechou.
[174:43] Fechou, fechou, fechou.
[174:45] É isso aí, pessoal.
[174:47] Cara, mais alguma dúvida?
[174:49] Cara, eu acho que
[174:51] vamos executar isso, Netinho.
[174:53] Eu, mano,
[174:56] particularmente acho que
[174:58] tanto eu quanto tu, a gente deveria saber muito
[175:00] sobre o
[175:02] que a gente está falando do nosso cliente.
[175:04] Sim, total.
[175:06] Acho que o primeiro passo é vocês ouvirem
[175:08] aqueles podcasts que eu falei, tá?
[175:10] A gente diz de tudo.
[175:12] Assim como eu fiquei puto
[175:14] de não conseguir ajudar o cara, eu acho que
[175:16] os dois a gente deveria ficar puto
[175:18] de não saber tanto assim
[175:20] da energia solar.
[175:22] Porque eu fiquei tão puto assim
[175:24] que eu sei até o nome dos países
[175:26] solários. Sabe porque o David
[175:28] Rafael cresceu tão rápido?
[175:30] Porque, cara, se você perguntar
[175:32] qualquer coisa pra ele de energia solar,
[175:34] ele sabe.
[175:36] Ele sabe mais que o dono da empresa.
[175:38] Entendeu? Então, tipo assim,
[175:40] quando eu entro no nicho,
[175:42] normalmente eu sei mais sobre o segmento
[175:44] do que o dono da empresa.
[175:46] Eu estudo de uma maneira psicopata ali.
[175:48] Obviamente, o micro detalhes
[175:50] do dia a dia, ele sempre vai saber mais que eu.
[175:52] Mas no macro, eu sempre vou saber mais que ele.
[175:54] E esse que é o ponto, tá?
[175:56] E a gente sabe algo que as pessoas não sabem
[175:58] de eletroposto, por exemplo.
[176:00] Sim, porque eu vou escutar
[176:02] vários especialistas
[176:04] falando sobre, tipo,
[176:06] cara, quando eu escuto um podcast, normalmente
[176:08] eu estou escutando de alguém especialista,
[176:10] que é alguém muito foda naquele segmento.
[176:12] Só que eu escutei várias pessoas foda
[176:14] e eles não me escutam.
[176:16] E se escutam, escutam um ou outro.
[176:18] Não escutam todos.
[176:20] Agora, quando você escuta todos, cara,
[176:22] é diferencial.
[176:24] Que às vezes vai levar 20 horas de estudo
[176:26] de conteúdo, ouvindo, barra, estudando.
[176:28] Mas que essas 20 horas vai trazer
[176:30] milhares de horas de resultado
[176:32] de repertório pra vocês, sabe?
[176:34] Mas é isso, pessoal.
[176:36] Cara, espero que vocês tenham gostado
[176:38] do treinamento de hoje.
[176:40] Tá maluco.
[176:42] Tá maluco, mano.

---

**Conteúdo destrinchado em:** [[Mentoria Nimoto — Fundamentos Comercial]] | [[Mentoria Nimoto — Execução e Webinar]]
**Hub:** [[Mentoria Nimoto — Índice]]

---
tipo: análise R1
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Matheus Garcia (BID, integradora solar)
nicho: energia solar
resultado: R2 a confirmar (com o pai, decisor)
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Matheus vendendo para BID (Matheus Garcia)

R1 de cerca de 20 minutos com o Matheus Garcia, da BID (integradora solar). No comercial são ele e o pai (dono, que não estava na call), mais parceiros comissionados e indicação. Produto-alvo: Ignição Comercial (prospecção comercial). R2 a confirmar com o pai.

> [!info] Resultado e diagnóstico geral
> R1 sólida na lógica. O cliente entregou duas dores cristalinas (crédito travado e guerra de preço) e tu fez a melhor ponte da semana: cliente comercial tem crédito, sai da guerra de preço e tem ticket 3-6x maior. Ele mesmo validou. Tu ainda isolou o decisor (pediu pra trazer o pai), coisa que não fez nas outras. Os furos: não rotulou, deixou passar o número de dor mais forte (a queda de 30 vendas pra 5), e concordou com a objeção macro (governo/crise) em vez de reframar.

> [!note] Contexto (feedback do Matheus)
> Essa call também foi ANTES do ajuste de encurtar a R1 e segurar o produto pra R2. Mesmo assim, aqui tu já tava mais contido que na Orion (não dumpou teste de fogo nem preço). A régua oficial muda a partir do Denner (17/06). Ler com esse filtro.

---

## Bloco 1 — Abertura, estrutura e clareza

> "a gente trabalha especificamente com a área comercial, ajudando e desenvolvendo a parte de prospecção... a Amanda falou que você tem time com três vendedores, são 100% comissionados ou fixos?" (call [01:11])

**Conceito:** posicionamento comercial + diagnóstico de estrutura logo na entrada.
**Aula:** R1/R2 [16:05] + Fundamentos (Blue Ocean).

---

> "voltando pra área comercial, qual são os seus principais gargalos, as suas dificuldades hoje?" (call [02:12])

**Conceito:** C do CLOSER feito.
**Aula:** R1/R2 [16:05].

---

> Matheus Garcia: "o problema forte é a questão de crédito (financiamento não disponível, mais caro) e a prostituição de preço, tem empresa em cada esquina baixando margem" (call [02:33])

**Conceito:** o cliente entrega duas dores claras e nomeadas por ele mesmo (crédito + guerra de preço).
**Aula:** R1/R2 [21:49] — bandeja pra rotular.

---

## Bloco 2 — Diagnóstico e o número de dor

> "pra identificar o real problema seu, é a negativação de crédito e a guerra de preço, seria esses dois?" → Garcia: "isso" (call [05:42])

**Conceito:** Label descritivo. Só repetiu os dois pontos, sem dar um nome maior nem amarrar na causa.
**Aula:** R1/R2 [24:24].
**Por que falhou parcial:** o rótulo afiado era *"vocês construíram a empresa no mercado residencial, e esse mercado virou contra vocês: crédito travado e guerra de preço."* Conecta as duas dores numa causa só.

---

> "o que vocês tentaram fazer pra contornar isso?" → Garcia: "trabalho com vários bancos, passo dados de outra pessoa pra aprovar... na questão de preço a gente dá explicação técnica, pós-venda forte... recebi material de marketing faz uma semana" (call [05:42])

**Conceito:** primeira parte da tríade (já tentou). Boa cobertura.
**Aula:** R1/R2 [27:28].

---

> "os fechamentos mensais?" → Garcia: "a gente vinha 15, 20, às vezes 30. Esse ano tá bem ruim, 5, 7, no máximo 10. 5 de 10 é mês muito bom" (call [09:01])

**Conceito:** o número de dor mais forte da call. Queda de até 30 vendas/mês pra 5-7. Despencou.
**Aula:** R1/R2 [22:17] — era pra repetir em tom de espanto e enfatizar: *"você caiu de 30 pra 5, isso é o teu faturamento sumindo. Quanto isso representa por mês?"* Passou sem amplificar (ver falhas).

---

> Garcia: "é ano de eleição, de copa, o governo aumentando taxa... ataque forte às renováveis no governo do PT" → Matheus: "é, o governo estraga, piora as coisas" (call [09:38] a [10:47])

**Conceito:** objeção macro (crise/governo). Tu concordou e entrou no papo de política em vez de reframar.
**Aula:** Call 1 [122:00] — não bater de frente, mas reframar, não endossar.
**O reframe que faltou:** a crise que derruba o residencial é exatamente o que torna o comercial mais atrativo (cliente comercial tem crédito e não compara preço). Tu tinha o contra na mão e bondou na política.

---

## Bloco 3 — Solução, ponte lógica e transição

> "como driblar isso? trabalhar 100% com clientes comerciais, que igual você falou tem mais crédito, menos reprovação de financiamento, e o cliente comercial vale por 3, 4, 5, 6 residenciais de ticket. E sai da guerra de preço porque o picareta sem estrutura não chega no cliente comercial" (call [10:47])

**Conceito:** a melhor ponte da semana. Pega as duas dores que ELE deu (crédito + preço) e mostra que o cliente comercial resolve as duas de uma vez.
**Aula:** Call 1 [47:29] — barreira lógica que ele mesmo justifica. Ele já tinha dito que comercial tem mais crédito.
**Por que funciona:** a solução não é externa, é a resposta direta pra dor que ele verbalizou. Forte.

---

> "é justamente por receber só de marketing que vocês esbarram na comparação de preço e na reprovação de crédito, porque são leads residenciais. 99% dos anúncios traz residencial, não comercial" (call [18:20])

**Conceito:** diagnóstico afiado da causa-raiz. Conecta o canal (só marketing) ao sintoma (preço + crédito).
**Aula:** R1/R2 [21:49].

---

> "se você gostar da ideia, a gente pode marcar um segundo bate-papo onde eu traria um projeto formatado pra instalar essa prospecção pra projetos comerciais. Vocês estão abertos?" (call [18:20])

**Conceito:** transição pra R2 SEM dump de mecanismo, teste de fogo nem preço. Mais contido que a Orion.
**Aula:** R1/R2 [13:18].

---

> "queria marcar contigo e com teu pai, como que a gente cruza a agenda?" (call [19:25])

**Conceito:** ISOLOU o decisor. Pediu pra trazer o pai (dono) pra R2.
**Aula:** Call 1 [98:50] — isolar/trazer o decisor. Único R1 da semana que tu fez isso direito.

---

> "confirma pra gente, manda no grupo, fala com ele hoje e confirma a data" (call [19:48])

**Conceito:** R2 sem data travada, ônus de confirmar jogado pro cliente.
**Aula:** R1/R2 [13:18] — pede data e hora firmes.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| Posicionamento comercial + estrutura | Blue Ocean + diagnóstico | R1/R2 [16:05] |
| "Qual seus principais gargalos?" | C do CLOSER | R1/R2 [16:05] |
| Garcia: "crédito travado e guerra de preço" | Dores entregues pelo cliente | R1/R2 [21:49] |
| "É esses dois, né?" | Label descritivo | R1/R2 [24:24] |
| "Caí de 30 vendas pra 5-7" | Número de dor (não enfatizado) | R1/R2 [22:17] |
| "O governo estraga" + papo de política | Concordou com objeção macro | Call 1 [122:00] |
| "Comercial tem crédito + ticket 3-6x + sai do preço" | Ponte lógica impecável | Call 1 [47:29] |
| "Só marketing traz lead residencial" | Diagnóstico de causa-raiz | R1/R2 [21:49] |
| "Projeto formatado na R2, abertos?" | Transição contida (sem dump) | R1/R2 [13:18] |
| "Marcar com você e teu pai" | Isolou o decisor | Call 1 [98:50] |
| "Confirma no grupo" | R2 sem data firme | R1/R2 [13:18] |

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não rotulou com nome próprio.** Duas dores claras (crédito + preço) ficaram soltas em "é esses dois, né?". Faltou amarrar numa causa só: "o mercado residencial virou contra vocês." R1/R2 [21:49] e [24:24].

**2. Deixou passar o número de dor mais forte.** A queda de 30 pra 5 vendas/mês é o ouro da urgência e passou sem enfatizar. Era pra repetir em espanto e fazer doer: "quanto de faturamento isso é por mês?" R1/R2 [22:17].

**3. Concordou com a objeção macro e bondou na política.** Diante do "governo/crise" tu endossou ("o governo estraga") em vez de reframar. O comercial é a fuga da crise (tem crédito, não compara preço), e tu tinha esse contra na mão. Call 1 [122:00].

**4. R2 sem data travada.** Acertou em isolar o pai, mas deixou a data no "confirma no grupo". Trava na hora. R1/R2 [13:18].

---

## 🎯 Destino pra R2 (com o pai, decisor)

A R2 é com o pai presente (dono). A lógica já tá vendida (ele validou que comercial tem crédito). Falta rotular forte, doer no número e fechar.

**C — Recap:**
> "Matheus, seu pai, desde terça o ponto é o mesmo: o residencial travou pra vocês, crédito e preço, e vocês querem migrar pro cliente comercial. Continua sendo isso?"

**L — Crava o rótulo:**
> "O problema não são vocês, é que vocês construíram a empresa toda no mercado residencial, e esse mercado virou contra vocês: o cliente não tem crédito e o picareta da esquina derruba o preço. Vocês tão competindo num mercado que parou de funcionar pra vocês."

**O — Urgência (usa o número que ele deu):**
> "Vocês vinham fazendo 30 vendas no mês e despencaram pra 5. Isso é mais de 80% do faturamento sumindo. Quanto tempo a empresa aguenta nesse ritmo?"

**S — Sell the Vacation (a fuga da crise):**
> "O cliente comercial é a saída dos dois problemas de uma vez: tem crédito (não trava no financiamento) e não entra na guerra de preço (avalia experiência, não cotação). E ticket 3 a 6x maior. A prospecção comercial leva vocês pra esse mercado, com visita qualificada chegando, em vez de esperar lead residencial de anúncio."

**E — Reframe da objeção macro (o que faltou na R1):**
> "Eu sei que vocês olham o cenário e pensam 'tá tudo travado, melhor esperar'. Mas isso vale pro residencial. No comercial é o contrário: empresa que quer cortar conta de luz na crise é o cliente que MAIS aparece, e tem crédito pra fechar. A crise é o motivo pra migrar agora, não pra esperar."

**R — 3 perguntas antes do preço:**
1. "Vocês acreditam que cliente comercial resolve o crédito e a guerra de preço de vocês?" (já validaram)
2. "Acreditam que funciona pra BID, com vocês fechando?"
3. "Acreditam que a gente é quem coloca isso de pé?"

**Isolar a decisão:** com o pai na sala, "se fizer sentido pra vocês dois, vocês decidem aqui mesmo?"
**Preço:** ancora no ticket comercial (poucas vendas comerciais recuperam o faturamento que sumiu). Trava data e decisão no dia.

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Orion Solar (R1)]]
- [[2026-06-16 — Apanhado geral das R1 (padrões)]]
- [[Mentoria Nimoto — Índice]]

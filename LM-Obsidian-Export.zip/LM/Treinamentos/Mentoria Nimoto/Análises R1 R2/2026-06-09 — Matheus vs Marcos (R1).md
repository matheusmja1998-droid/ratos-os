---
tipo: análise R1
data: 2026-06-09
vendedor: Matheus Jardim
prospect: Marcos Castro Júnior (Fotovoltaico Brasil, SC)
nicho: energia solar
resultado: R2 remarcada para 16/06 às 14h
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Mentoria Nimoto — Fundamentos Comercial]]"
---

# Análise — Matheus vendendo para Marcos (Fotovoltaico Brasil)

R1 de 58 minutos com o Marcos, dono de empresa de energia solar em Santa Catarina. Time de 5 vendedores parceiros 100% comissionados, só 1 comprometido de verdade, ~5 vendas/mês (2 de tráfego, 3 de indicação). Produto-alvo: Ignição Comercial (SDR gerando demanda comercial). R2 marcada pra mesma tarde, 16h.

> [!info] Resultado e diagnóstico geral
> R1 confusa e com perda de controle. O Marcos é cético, analítico e entrou como JUIZ avaliando, não como dor latente. Ele conduziu a conversa em vários trechos (fez mais pergunta que o Matheus). Os acertos: a pergunta de clareza foi feita certinho na abertura, e o foco comercial foi conduzido com uma pergunta socrática boa. Os erros pesados: o Matheus bateu de frente, oscilou entre 3 modelos (projeto / mensal / sócio), nunca cravou o rótulo que o próprio cliente entregou três vezes ("quem vai fazer e cuidar disso") e despejou pitch, prova e preço (tudo R2) dentro da R1, gastando munição e entregando o método de graça.

---

## Bloco 1 — Abertura, metodologia e Clarity

> "eu queria perguntar para você, qual que é o motivo de você estar aqui hoje, qual que é o gargalo que você tem hoje, falando de vendas, time comercial, aquisição de clientes... pra gente direcionar e bater papo relacionado a isso" (call [01:08])

**Conceito:** C do CLOSER feito direito. Pergunta de clareza isolada, ancorada na parte comercial.
**Aula:** R1/R2 [16:05] — *"deixa eu entender qual que está sendo a maior dificuldade de vocês hoje."*
**Por que funciona:** abriu o jogo na hora certa (diferente da R1 do Ladislau, onde o C ficou no vácuo). Aqui ele cumpriu o C.

---

> "confesso que eu não sei muito bem para onde essa reunião vai... estou mais curioso para saber o que vocês têm de diferente, para ver se a gente eventualmente fecha alguma coisa" (call [02:19])

**Conceito:** cliente entra como JUIZ avaliando, não como quem tem dor latente. Sinaliza ceticismo e frame de comprador no controle.
**Aula:** Call 1 [80:24] — *"não é o problema que ele fala, é a intenção."* Intenção: "me prova que você não é mais um."
**Por que importa:** esse aviso pedia ainda MAIS disciplina de CLOSER (perguntar, não despejar). Foi o contrário do que aconteceu depois.

---

> "a gente trabalha 100% mais na parte comercial, que é o que ajuda as empresas a vender mais através do seu time comercial, através de prospecção, através de estruturação, buscando clientes mais comerciais" (call [02:19])

**Conceito:** entrega da metodologia + Blue Ocean (foco no cliente comercial).
**Aula:** R1/R2 [16:05] + Fundamentos Comercial.
**Por que funciona:** posiciona a categoria. Ok.

---

## Bloco 2 — Cliente rotula o problema sozinho

> "a grande questão não é nem o que deve ser feito. Eu sei que a gente tem muitas coisas que devem ser feitas. A questão é quem vai fazer, que é o meu grande gargalo hoje" (call [04:09])

**Conceito:** o cliente entrega o RÓTULO de bandeja. O problema dele não é "o quê", é "quem". Execução, não estratégia.
**Aula:** R1/R2 [21:49] — rotular o problema. Era só cravar: *"então seu problema é que você sabe o que fazer, mas não tem quem execute e cuide disso por você, certo?"*
**Por que é ouro perdido:** o Matheus não fixou esse rótulo. Voltou pro genérico "mais vendas" depois (ver falhas).

---

> "um concorrente meu investiu 200 mil numa consultoria comercial e no final ele não teve resultado... ele está no mesmo patamar... talvez não teve a pessoa certa para fazer" (call [04:09])

**Conceito:** cliente planta a objeção central antecipadamente (consultoria cara que não entrega). Medo de jogar dinheiro fora.
**Aula:** R1/R2 [40:32] — essa vira a objeção da R2 ("você acredita que funciona pra você?").
**Por que importa:** munição pra contornar depois com risco compartilhado. Anotar e guardar.

---

## Bloco 3 — Diagnóstico e qualificação

> "não é entrada de lead, é acompanhamento que é o gargalo... se a gente não tiver alguém pra ficar fazendo isso, não adianta nada" (call [05:29])

**Conceito:** cliente refina a dor. O gargalo é follow-up e braço, não geração de lead.
**Aula:** Imersão [116:46] (quem pergunta controla). Aqui a pergunta do Matheus extraiu bem.

---

> "pra vender mais a gente precisa de mais braço. Esse é o grande ponto" (call [06:43])

**Conceito:** confirma a dor de capacidade. Reforça o "quem vai fazer".
**Aula:** R1/R2 [21:49].

---

> "são parceiros, não são full time... só ajuda de custo, mas basicamente 100% comissionado... menos de mil por mês" (call [07:12] a [07:30])

**Conceito:** diagnóstico de estrutura (5 parceiros comissionados, custo baixo, baixo comprometimento).
**Aula:** Imersão [116:46].

---

> "umas duas vendas por tráfego... então as outras três giram indicação" (call [08:19])

**Conceito:** confissão de número (5 vendas/mês, 2 tráfego + 3 indicação). Teto de faturamento exposto.
**Aula:** R1/R2 [22:17] — número de dor (não foi devolvido em tom de espanto).

---

> "o problema hoje é trazer mais vendas realmente, ter mais vendas no final do mês... aumentar o volume de vendas, seria isso?" (call [08:19])

**Conceito:** tentativa de Label, mas genérica e sem as palavras do cliente.
**Aula:** R1/R2 [24:24] — *"eu preciso resumir tudo o que ele está falando em um nome só."*
**Por que falhou:** o cliente acabou de dizer que o problema é "quem vai fazer/cuidar", não "mais vendas" no abstrato. Rótulo errado, e o cliente redireciona no item seguinte.

---

> "é, eu vejo que hoje precisa de mais braço... na verdade eu preciso de gerente comercial pra estruturar o comercial, só que isso vai custar caro, e quando o gerente é gerente comercial de verdade, ele vai e abre uma empresa concorrente" (call [08:55])

**Conceito:** cliente rejeita o rótulo simples e impõe a própria tese (preciso de gerente) + duas objeções (caro + risco de virar concorrente).
**Aula:** Call 1 [80:24] (intenção) + R1/R2 [21:49].
**Por que importa:** aqui era pra concordar e reframar, não discutir a tese dele. O que veio foi confronto (ver bloco 4).

---

## Bloco 4 — Matheus bate de frente e perde o frame

> "o vendedor é alguém que suga a tua energia... e como empresário eu tenho muitas coisas que não são comerciais pra resolver: financeiro, instalação, obra, projetos" (call [09:37])

**Conceito:** cliente verbaliza a dor real (sem tempo, sem banda pro comercial).
**Aula:** Imersão [322:00] (a dor dele). Sinal claro do destino: tirar o comercial das costas dele.

---

> "mas por que gerente comercial, sendo que o gerente comercial iria ter que fazer o trabalho de vendedor, basicamente, no início?" (call [16:34])

**Conceito:** bateu de frente na tese do cliente. Criou conflito em vez de reconhecer e reframar.
**Aula:** Call 1 [122:00] — *"primeira coisa numa quebra de objeção não é bater de frente, porque eu crio um conflito com o meu cliente."*
**Por que falhou:** o cliente se fecha e repete a objeção no item seguinte.

---

> Marcos: "mas de quem vai cuidar desse vendedor?" ... "mas aí é o contrário, né? A demanda sem uma estrutura inicial pode desmoronar tudo, que é o que está acontecendo" (call [16:45] e [17:54])

**Conceito:** cliente cava a posição e discorda da tese do Matheus (crescer pela base). Frame invertido, o cliente está conduzindo.
**Aula:** Imersão [116:46] — quem pergunta controla. Aqui quem perguntava era o Marcos.
**Por que falhou:** o Matheus recua ("eu concordo com essa parte do gerente") em vez de ter concordado ANTES e levado a conversa.

---

## Bloco 5 — Cliente entrega o spec exato da oferta

> "a conclusão que cheguei é que eu preciso de sócio... se vocês quiserem ajudar nessa fase de estruturação, pensando em receber a lucratividade depois... meu grande problema é como manter a empresa redonda pra atrair um sócio" (call [~19:00])

**Conceito:** cliente perdido entre sócio / gerente / SDR. Sinal de que ninguém ancorou o rótulo nem o destino.
**Aula:** R1/R2 [3:53] — os 225 caminhos. Sem rótulo fixo, o cliente fica chutando trilha.

---

> "eu estou mais preocupado no como, no método... eu quero ver o modelo, se o modelo faz sentido. Eu não quero ver os números" (call [48:17])

**Conceito:** o próprio cliente pede pra vender o DESTINO/modelo, não a planilha. Presente de bandeja.
**Aula:** R1/R2 [30:37] — *"a gente sempre vende o destino final, não o voo."*
**Por que importa:** ele te disse como quer ser vendido. Era pra ter parado de empilhar número e vendido o modelo.

---

> "eu queria alguém que trouxesse o SDR, que já tivesse a margem dessa empresa embutida, e ela ficasse cuidando do SDR e também reportando os resultados... se esse SDR não deu certo, já coloquei outra pessoa no lugar, nem notei... De preferência alguém da região... e por último, que eu tivesse uma única coisa pra pagar, não uma consultoria, um SDR e depois jogar pro outro" (call [48:17])

**Conceito:** o cliente ESCREVEU a oferta que compraria. Terceirização gerenciada do SDR, margem embutida, uma fatura só, troca de pessoa transparente, SDR local que vira vendedor. Modelo "empresa de limpeza/segurança".
**Aula:** R1/R2 [30:37] (destino) + Call 1 [47:29] (barreira lógica que ele mesmo justifica).
**Por que é ouro:** a R2 inteira é devolver esse spec como destino. O Matheus pegou só parte e ainda sujou com dashboard e reunião semanal (que o cliente rejeita depois).

---

## Bloco 6 — Erro de escopo: dump de R2 dentro da R1

> "deixa eu compartilhar a minha tela... aqui são reuniões gravadas nossas... essa foi 120 minutos, essa foi 170 minutos... 5 horas de treinamento... aqui é o manual de cultura da gente" (call [35:30])

**Conceito:** despejou o método inteiro de graça + prova que é munição de R2, dentro da R1.
**Aula:** Call 1 [110:48] — *"cobra antes de ensinar."* + R1/R2 [13:18] (R1 é diagnóstico, R2 é apresentação).
**Por que falhou:** entregou o playbook pra um cético que pode levar pro concorrente, e esvaziou a R2.

---

> "a Amanda hoje fez 22 ligações, atenderam quatro, três decisores e marcou duas reuniões... na sexta, primeiro dia dela, fez 55 ligações, 16 atendidas, 10 decisores e marcou 10 reuniões" (call [38:22] a [39:10])

**Conceito:** prova social forte (métricas reais da operação). MAS é apresentação de R2 jogada na R1.
**Aula:** R1/R2 [37:15] — probabilidade de percepção de sucesso é o coração da R2, não da R1.
**Por que falhou:** gastou o trunfo cedo. O cliente responde cético no item seguinte.

---

> Marcos: "tá sendo bem otimista... a não ser que seja uma empresa de RH, vai achar que tipo de pessoa tão rápido pra pegar do concorrente? Vai ter que oferecer mais dinheiro, né?" (call [38:01] a [38:07])

**Conceito:** cliente derruba a prova com objeção de viabilidade. A prova foi cedo demais e sem o terreno preparado.
**Aula:** Call 1 [122:00] (a prova virou ringue).

---

> Matheus: "uma pessoa que te chamou do anúncio e pediu orçamento pra três, quatro empresas, ou um lead que nem estava sabendo, que o SDR ligou e marcou a visita? Qual vai ter mais concorrência?" → Marcos: "o lead que chegou do anúncio, com certeza" (call [46:00])

**Conceito:** pergunta socrática. Fez o cliente concluir sozinho que o lead comercial vale mais. Melhor movimento da call.
**Aula:** Imersão [116:46] — quem pergunta controla, e o cliente quebra a própria objeção.
**Por que funciona:** não afirmou, perguntou. O cliente entregou a conclusão.

---

## Bloco 7 — Objeções, co-construção e fecho

> "5% já está alto, vou ter que dar mais pro SDR... pega SDR destreinado que não passa confiança e passa uma bola quadrada pra frente" (call [43:58])

**Conceito:** objeção dupla (comissão + qualidade do atendimento).
**Aula:** R1/R2 [40:32] — guardar pra quebrar na R2 com os 3As.

---

> "não quero ver dashboard, não quero ficar analisando... vou depois de um tempo avaliar se valeu ou não a pena" (call [51:59])

**Conceito:** cliente rejeita o dashboard e a reunião semanal que o Matheus tinha acabado de oferecer. Esforço pro cliente = denominador da equação de valor subindo.
**Aula:** R1/R2 [37:13] — *"quanto maior o sacrifício do seu cliente, menor a percepção de valor."*
**Por que falhou:** ofereceu o oposto do que o cliente quer (ele quer NÃO ter que olhar). Teve que recuar pra "uma reunião por mês".

---

> "o que funcionaria pra mim em remuneração seria começar em X menos 50%, depois chega no X, depois X mais 50% se der bom resultado, pra pelo menos dividir o risco" (call [55:09])

**Conceito:** o cliente PROPÕE a estrutura de pagamento escalonada por risco. Está co-construindo a oferta sozinho.
**Aula:** R1/R2 [47:28] — *"quem resolve o problema financeiro do meu cliente é ele mesmo."* Ele já resolveu.
**Por que é ouro:** a R2 já tem o modelo de preço dado pelo cliente. Só formatar e devolver.

---

> "precisaria ver algum case de vocês pra energia solar" → Matheus: "tem o case da Cine, de Tangará da Serra... na semana do gerente deles tinham marcado 2 visitas, na semana que a gente tomou a frente a gente gerou 10" (call [53:43] a [54:04])

**Conceito:** cliente pede prova específica do nicho. Matheus entrega o case Cine (2 → 10 visitas).
**Aula:** Call 1 [67:47] (prova social do meio do funil). Bom case, mas pede validação no nicho dele.

---

> "vou formatar melhor essa proposta, e hoje na parte da tarde, umas 4 horas, você consegue bater esse papo, porque aí eu te trago a proposta formatada, o que a gente pensa te entregar e o valor mensal, pode ser?" (call [58:04])

**Conceito:** marca a R2 com data e hora (mesmo dia, 16h).
**Aula:** R1/R2 [13:18] — encerramento com próxima reunião marcada.
**Por que funciona em parte:** marcou com horário (bom), mas no tom frouxo "pode ser?" em vez de assumir o compromisso.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Qual o motivo de você estar aqui hoje?" | C do CLOSER (bem feito) | R1/R2 [16:05] |
| Cliente: "estou curioso, é pra ver se fecho" | Entra como juiz cético | Call 1 [80:24] |
| Cliente: "a questão é quem vai fazer" | Rótulo entregue (não cravado) | R1/R2 [21:49] |
| Cliente: "concorrente perdeu 200k em consultoria" | Objeção plantada | R1/R2 [40:32] |
| "2 vendas tráfego, 3 indicação" | Número de dor (não devolvido) | R1/R2 [22:17] |
| "Por que gerente, sendo que...?" | Bateu de frente | Call 1 [122:00] |
| Cliente: "mas é o contrário, vai desmoronar" | Frame invertido, cliente conduz | Imersão [116:46] |
| Cliente: "quero ver o modelo, não os números" | Pede o destino, não a planilha | R1/R2 [30:37] |
| Cliente descreve "SDR terceirizado, uma fatura só" | Cliente escreve a própria oferta | R1/R2 [30:37] |
| Compartilha tela, treinos, manual de cultura | Consultoria grátis + escopo errado | Call 1 [110:48] |
| Mostra métricas Amanda (22 lig, 10 reuniões) | Prova de R2 jogada na R1 | R1/R2 [37:15] |
| "Qual lead tem menos concorrência?" | Pergunta socrática (melhor momento) | Imersão [116:46] |
| Cliente: "não quero dashboard" | Ofereceu sacrifício, não valor | R1/R2 [37:13] |
| Cliente propõe pagar X-50%/X/X+50% | Co-constrói o preço por risco | R1/R2 [47:28] |
| R2 marcada 09/06 16h | Encerramento CLOSER | R1/R2 [13:18] |

---

## Decisões estratégicas de escopo / camada

**Produto-alvo:** Ignição Comercial (SDR gerando demanda comercial).
**Camada que o cliente comprou na cabeça dele:** terceirização gerenciada do SDR. Ele rejeita "ajuda você a contratar e treinar" e quer "vocês trazem o SDR pronto, cuidam dele, trocam se não der, e me mandam uma fatura só". Modelo done-for-you tipo empresa de limpeza.

**Onde o Matheus oscilou (e devia ter travado):** ficou pulando entre projeto único de 45 dias, mensal como gerente comercial, e até sócio. Três modelos na mesma call. O cliente já tinha dito qual quer. Travar no done-for-you mensal com margem embutida e parar de oferecer as outras versões.

**Termo a ressuscitar na próxima conversa:** "esse SDR depois vira vendedor" (plano de carreira). É o gancho de escalada (quando a máquina rodar, sobe a camada).

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não cravou o L.** O cliente entregou o rótulo três vezes ("quem vai fazer", "quem vai cuidar", "uma fatura só pra pagar") e o Matheus rotulou genérico ("mais vendas"). Faltou devolver com as palavras dele: *"seu problema não é venda, é que não tem quem execute e cuide do comercial por você."* R1/R2 [21:49] e [24:24].

**2. Bateu de frente.** No "gerente vs SDR" ([16:34], [16:49], [17:54]) discutiu a tese do cliente em vez de concordar e reframar. Criou conflito, o cliente cavou e o frame inverteu. Call 1 [122:00].

**3. Violou o escopo da R1.** Despejou pitch, prova (tela, métricas, treinos) e preço, tudo material de R2, dentro da R1. Gastou munição e entregou o método de graça pra um cético que conhece concorrentes. R1 é diagnóstico (R1/R2 [13:18]); ensinar de graça é o erro da Call 1 [110:48].

**4. Tríade ausente.** Perguntou "já tentou contratar?" mas não enfatizou perda: *"quanto você já queimou com vendedor que não rampava? quanto deixou de faturar travado em 5 vendas/mês?"* A enfatização da dor não aconteceu. R1/R2 [9:54].

**5. Perdeu o controle do frame.** Em vários trechos o Marcos fez mais perguntas que o Matheus. Quando o cliente vira interrogador, recupera-se com pergunta, não com defesa. Imersão [116:46].

---

## Aplicação na próxima R1

- [ ] Cravar o Label com as palavras do cliente, principalmente quando ele já entregou ("quem vai fazer e cuidar disso por você")
- [ ] Nunca bater de frente na tese do cliente. Concordar, depois reframar ("concordo que precisa de quem cuide, e é exatamente isso que a gente faz, sem o custo de um gerente")
- [ ] R1 é diagnóstico: segurar pitch, prova e preço pra R2. No máximo um teaser, nunca a plataforma inteira
- [ ] Tríade completa com enfatização de perda (quanto já custou, quanto deixou de faturar)
- [ ] Com prospect que vira interrogador, retomar o controle com perguntas em vez de se defender

---

## 🎯 Destino pra R2 (hoje, 16/06 às 14h) — roteiro CLOSER

Prospect cético que já viu a prova (tela, métricas) na R1 e que te disse exatamente o que compra. Hoje NÃO é dia de mostrar mais número. Ele falou "quero ver o modelo, não os números". A R2 é travar o modelo done-for-you que ele mesmo escreveu e dividir o risco. Segue a linha:

**C — Recap (1 min):**
> "Marcos, desde a última conversa, o que continua te incomodando é o mesmo: você sabe o que precisa ser feito no comercial, o que falta é QUEM faz e cuida disso sem ser mais um problema na tua mão. Continua sendo isso?"

**L — Cravar o rótulo que faltou na R1 (com as palavras dele):**
> "Teu problema não é falta de venda, é que hoje tudo no comercial passa por você. Vendedor te enche de mensagem, SDR teria que ser pilotado, gerente sai caro e ainda vira concorrente. Você quer o comercial fora das tuas costas, não mais uma coisa pra você administrar."

**O — Urgência presente (comprimida, com a perda):**
> "E enquanto isso você fica travado em 5 vendas no mês, sacrificando tarde de quarta pra fazer visita que era pra ser de um vendedor. Quanto desse mês você acha que perde indo pessoalmente fazer o que devia estar delegado?"
(faz ele dizer, não responde por ele)

**S — Sell the Vacation (devolve o modelo que ELE escreveu):**
Destino: "O comercial rodando sem você. Um SDR gerando 10 a 15 visitas comerciais por mês, e você só recebendo as visitas qualificadas pra fechar."
3 pilares (no modelo dele, done-for-you):
1. A gente traz, treina e cuida do SDR. Não deu certo, a gente troca. Você nem sente.
2. Foco em cliente comercial da sua região (açougue, padaria, academia), menos concorrência, ticket maior.
3. Uma coisa só pra você pagar. Margem embutida. Sem consultoria de um lado, SDR do outro e a culpa jogando de um pro outro.
Oferta-frase: "Eu coloco e mantenho rodando a tua máquina de SDR comercial, do meu lado, com uma fatura só, pra você sair da operação do comercial."
NÃO oferecer dashboard nem reunião semanal. Ele rejeitou. No máximo um apanhado mensal "quando você tiver tempo".

**E — Quebra de objeção (a certa: os 200k de consultoria que não entregou):**
Resgata a fala dele, não bate de frente:
> "Você me falou do teu concorrente que botou 200 mil numa consultoria e ficou no mesmo lugar. Eu entendo o receio 100%. A diferença é que a gente não te entrega slide e some, a gente fica responsável pelo SDR entregando visita. E pra você não correr o risco que ele correu, a gente divide o risco no pagamento, do jeito que você mesmo sugeriu."

**R — Reinforce (3 perguntas de fechamento, antes do preço):**
1. "Você acredita que SDR fazendo prospecção comercial gera visita qualificada?" (o case Cine e a prova que ele já viu respondem)
2. "Você acredita que funciona pra TUA empresa, com a gente cuidando do SDR no teu lugar?" (se travar = objeção de risco, contorna com o escalonado)
3. "Você acredita que a gente é quem consegue colocar isso de pé pra você?"
Sim/sim/sim, só sobra preço.

**Preço (no modelo que ele propôs):**
Escalonado, risco compartilhado: começa em X-50%, sobe pra X, depois X+50% conforme entrega. Mais o custo do SDR (~R$1.500/mês PJ). Ancorar no retorno: "2 vendas comerciais a R$50k = R$100k no mês."

**Cuidados táticos:**
- Esse cara interroga. Quando ele te encher de pergunta, devolve com pergunta, não entra na defensiva
- Não mostrar mais tela/métrica, ele já viu. Hoje é modelo e fecho
- Não oscilar entre projeto/mensal/sócio. Travar num modelo só: mensal done-for-you
- Não bater de frente. Concorda sempre antes de reframar

Se a R2 de hoje ficar gravada no Fathom, me manda que eu analiso ela também.

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Ladislau (R1)]]
- [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]
- [[Mentoria Nimoto — Índice]]

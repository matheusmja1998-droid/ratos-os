---
tipo: análise R2
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Cristiano Ferreira Andrade (energia solar / instalações elétricas, Natal/RN)
nicho: energia solar
oferta: Teste de fogo (LM contrata + treina SDR, pague por resultado) + acompanhamento 45 dias (~R$3.500, entrada ~R$500)
resultado: FECHOU (verbal) — início 1º de julho após encerrar contrato atual de ads. Contrato a montar a partir da gravação. Sem pagamento ainda.
tags: [mentoria, nimoto, r2, análise, lm, vendas, fechamento]
fontes:
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[CLOSER R2 — Versão Matheus]]"
  - "[[2026-06-16 — Matheus vs Ladislau (R2)]]"
  - "[[2026-05-05 — Matheus e Tino vs Synergy (R2)]]"
---

# Análise — Matheus vendendo para Cristiano (R2)

Call de 1h08 com o Cristiano, eletricista de 50 anos em Natal/RN, dono de uma operação solo (instalações elétricas como carro-chefe, energia solar como extra). Foi uma **R1+R2 comprimida numa reunião só**: diagnóstico, oferta e fechamento na mesma call. Cristiano vinha queimado por agência de tráfego (R$16k torrados, 316 leads, zero venda, zero visita) e cético ("gato escaldado tem medo de água fria"). **Fechou.** Aceitou o modelo de teste de fogo (LM contrata + treina um SDR, ele paga por resultado), início 1º de julho, depois de encerrar o contrato de ads atual. Sem dinheiro na mão ainda, mas com sim verbal, data e contrato a enviar.

> [!info] Resultado e diagnóstico geral
> Fechou, e fechou pela peça certa: o **E** foi obra-prima. O Cristiano deu a própria filosofia de venda ("pago com resultado", a história do fator de potência), e o Matheus espelhou isso no formato de teste de fogo, matando o "gato escaldado" com o argumento dele mesmo. C ✅, L ✅, S ✅, E ✅✅, R ✅. O ⚠️ (não mediu urgência e não capturou que pra ele solar é baixa prioridade — risco de retenção). Pontos de atenção: o fechamento é verbal e adiado pra julho (sem pagamento, risco de esfriar), e a parte de preço saiu meio embolada por queda de conexão.

---

## Bloco 1 — Abertura + C (Clarity)

> "Cristiano, você conseguiu participar do nosso evento? O que você achou?" (call [00:46])

**Conceito:** abertura ancorando no evento (mesmo gancho da R1 do Ladislau). Puxa contexto de por que ele está ali.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05].
**Por que funciona:** ✅ abre leve. Ele não foi ao evento, mas a Amanda (SDR da LM) já tinha aquecido.

---

> "Esse bate-papo aqui é basicamente para a gente entender como que está hoje as suas dificuldades relacionadas à área comercial... A Amanda falou que você está rescindindo contrato com a agência de marketing, que você investiu uns 10 mil reais, mais mil reais mensais" (call [01:26])

**Conceito:** C do CLOSER. Já chega sabendo o motivo (rescisão da agência) e nomeia a clareza pro cliente.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] — *"descobrir por que aquele cliente aceitou."*
**Por que funciona:** ✅ ancorou o C com informação de bastidor (a SDR já tinha mapeado). Cliente se sente entendido na largada.

---

## Bloco 2 — Cliente despeja a dor sozinho

> Cristiano: "fechei com ele pacote de ano, dez mil reais, e mil reais todo mês para o crédito... tá queimando o dinheiro" (call [04:13])

**Movimento do prospect:** confissão de número de dor (R$10k + R$1k/mês) + a palavra-chave emocional dele: "queimando o dinheiro".
**Aula:** Call 1 [80:24] — *"não é o problema, é a intenção."* Intenção: "me prova que você não é mais um que vai queimar minha grana."
**Por que importa:** "queimando o dinheiro" é o termo dele. Munição pra rótulo (foi pouco aproveitado, ver falhas).

---

> Cristiano: "deu 316 [leads]... e você não conseguir fechar nenhuma venda sequer" + "Não, nenhuma visita. Nenhuma visita." (call [03:48] e [07:03])

**Movimento do prospect:** dor quantificada e brutal: 316 leads, zero venda, zero visita. O fracasso total da solução do concorrente (agência de tráfego).
**Aula:** Call 1 [80:24]. Reforça o Blue Ocean: ele já odeia "lead de anúncio".
**Por que importa:** sinal verde gigante. A solução que o Matheus vende (prospecção ativa, não anúncio) é o oposto exato do que o queimou.

---

> Cristiano: "esses 10.000 reais, ter comprado duas máquinas de lavar módulos... estava aí ganhando dinheiro" (call [05:01])

**Movimento do prospect:** custo de oportunidade verbalizado. Ele já calculou o que perdeu (o dinheiro daria duas máquinas que gerariam receita).
**Aula:** Imersão [320:10] — *"eu quero ver meu cliente triste."* Aqui ele se entristeceu sozinho.
**Por que importa:** dor de arrependimento, pronta pra ser devolvida.

---

> Cristiano: "eu tô gato escaldado e tem medo de água fria... tô com o pé atrás, tô acreditando nisso mais não" (call [05:42])

**Movimento do prospect:** a OBJEÇÃO-MÃE, dita com termo próprio: "gato escaldado". Não é preço, é desconfiança. "Não acredito mais."
**Aula:** Call 1 [97:18] — *"toda objeção é falta de narrativa bem contada."*
**Por que é ouro:** essa frase definiu a venda inteira. O Matheus pegou exatamente esse termo e construiu a oferta em cima dele (ver Bloco 5). Foi o movimento decisivo da call.

---

> Cristiano: "pra morrer pobre, o que eu tenho já está bom demais... eu gosto de instalar, gosto de resultado, gosto de ver uma família feliz" + "fico muito triste quando o cliente só olha preço" (call [11:52])

**Movimento do prospect:** revelou que a urgência em solar é BAIXA. A elétrica paga as contas, solar é extra, ele está confortável. O motor dele é gostar de instalar + não querer desperdiçar, não desespero financeiro.
**Aula:** Call 1 [80:24] — a intenção real importa mais que a fala.
**Por que importa (e foi subaproveitado):** esse é o sinal que o Matheus não capturou (ver falhas). Solar não é prioridade pra ele. Fecha, mas pode não priorizar a execução. Risco de retenção.

---

## Bloco 3 — L (rótulo) + diagnóstico

> "basicamente o seu problema hoje, não digamos problema, mas a situação que você gostaria de melhorar seria a quantidade de vendas... Trazer mais vendas de energia solar, né?" → Cristiano: "Isso." (call [14:19])

**Conceito:** L do CLOSER. Rotula e pede confirmação em voz alta. Cliente confirma.
**Aula:** [[CLOSER R2 — Versão Matheus]] — recap + "é isso mesmo?".
**Por que funciona parcial:** ✅ L feito e confirmado. **Oportunidade:** rotulou só o racional ("mais vendas de solar"). Tinha termos quentes dele na mesa ("queimando o dinheiro", "gato escaldado") que dariam um rótulo bem mais forte. Plus, não falha.

---

> "a gente aqui da [agência] já investiu só em anúncio mais de 8 milhões... gerencia em torno de 200 a 300 mil reais só em anúncios todos os meses" (call [14:39])

**Conceito:** prova social + autoridade. Posiciona que sabe de tráfego de verdade (e por isso a recomendação de NÃO usar anúncio tem peso).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] — autoridade/prova social.
**Por que funciona:** ✅ "quem queima 8 milhões em ads e te diz pra não usar ads" tem credibilidade. Desarma a desconfiança técnica.

---

> "a margem é isso aí, uma instalação simples 3.000, 4.000... cliente comercial varia de 30, 40, 50, 100 mil reais" (call [30:25] e [34:24])

**Conceito:** qualificação de número (margem, ticket). Mapeia a operação pra dimensionar a oferta.
**Aula:** Imersão [116:46] — *"quem faz as perguntas está no controle."*
**Por que funciona:** ✅ pegou ticket comercial (R$30-100k) pra ancorar o destino com número.

---

## Bloco 4 — S (Sell the Vacation) + destino

> "a gente tem pessoas que trabalham com lead... essa pessoa que a gente contrata já entrega a visita marcada no final da conta... a gente tem tráfego pago 2.0, visita já pra ti" (call [18:20])

**Conceito:** oferta-frase / mecanismo. Reposiciona a solução como "tráfego pago 2.0" (prospecção ativa que entrega visita marcada), contrastando com o anúncio que o queimou.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"venda o destino, não o voo."*
**Por que funciona:** ✅ nome próprio pro mecanismo ("tráfego pago 2.0") que fala a língua de quem se queimou com tráfego pago 1.0. Esperto.

---

> "trabalhar com cliente comercial — açougue, padaria, supermercado, academia — é muito melhor do que residencial... a aprovação de crédito de comércio é muito mais fácil" (call [20:08] e [20:23])

**Conceito:** Blue Ocean. Recorta o nicho comercial, onde a guerra de preço residencial não chega e o crédito aprova.
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] (Blue Ocean).
**Por que funciona:** ✅ tira ele da briga de preço residencial que ele odeia ("fico triste quando o cliente só olha preço").

---

> "você falou que a cada 10 você fecha 1... então pelo menos uma ou duas vendas por mês, e o salário da pessoa vai se pagando muito tranquilamente" (call [34:00] e [34:36])

**Conceito:** destino com resultado de negócio + autofinanciamento (a venda paga o custo da pessoa). Usa o número que o PRÓPRIO Cristiano deu (1 a cada 10).
**Aula:** R1/R2 [30:37] (destino) + [37:15] (probabilidade de sucesso).
**Por que funciona:** ✅ destino ancorado no número dele, não num genérico. "1-2 vendas comerciais/mês de R$30-100k, e a pessoa se paga." Lógico e irresistível.

---

## Bloco 5 — E do CLOSER: a obra-prima (teste de fogo espelhando o cliente)

> Cristiano: "vou ser bem sincero, eu só contrato agora se tiver provas... vou fazer teste com você e ver, você vai me mostrar que dá certo" (call [35:13])

**Movimento do prospect:** cravou a condição de compra: pague-por-prova. Ele NÃO compra promessa, só resultado demonstrado.
**Aula:** Call 1 [97:18] — a objeção é a narrativa que falta.
**Por que importa:** o cliente entregou o formato que aceitaria. Matheus só precisava embrulhar a oferta nesse formato (e fez).

---

> Cristiano (história do fator de potência): "o cara dizia, eu pago com o resultado... eu botava o equipamento, com 30 dias mostrava a fatura, consumo zerado, recebia meus 6 mil... é bacana quando você paga por resultado" (call [36:00])

**Movimento ouro do prospect:** ele contou que ELE MESMO vendia por resultado. Entregou a própria filosofia comercial de bandeja.
**Aula:** Call 1 [48:38] — reciprocidade / entender como o cliente pensa.
**Por que é ouro:** o Matheus tinha agora o roteiro exato pra fechar: oferecer a ele o mesmo modelo que ele usa pra vender. Vender pro cara do jeito que o cara vende.

---

> "você não começa pagando, e aí você vê os resultados separados" (call [44:27])

**Conceito:** E + risco reverso. Inverte a polaridade: não é "confia e paga", é "vê funcionar e depois paga".
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] — garantia/risco reverso.
**Por que funciona muito:** ✅ matou o "gato escaldado" com o argumento dele. Zero risco percebido na entrada.

---

> "a gente chama o teste de fogo, pra ver se a pessoa vai desempenhar... no período de teste a gente traz bonificação por agendamento, e fechando venda, 2% do valor. E aí, indo bem no primeiro mês, não tem porquê você não efetivar ela" (call [51:52] e [53:42])

**Conceito:** S + E completos. Estrutura a entrega como teste de fogo: a pessoa é remunerada por performance no teste, e só vira fixo depois de provar. O risco é todo da LM e da pessoa, não do Cristiano.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] + [37:15] (probabilidade de sucesso).
**Por que funciona:** ✅ formato desenhado sob medida pra desconfiança dele. Cada peça responde a um medo.

---

> "meu pai gosta de falar que gato escaldado tem medo de água fria, pra deixar a pessoa do outro lado mais tranquila" (call [57:22])

**Conceito:** devolveu o TERMO DELE ("gato escaldado") com empatia, validando o medo em vez de combatê-lo.
**Aula:** Imersão [317:35] (devolver o termo do cliente) + Call 1 [48:38] (reciprocidade).
**Por que funciona muito:** ✅ pegou a expressão exata que o Cristiano usou lá no início e devolveu como ponte. Cliente se sente lido. Esse é o tipo de movimento que a R2 do Ladislau não teve.

---

> Cristiano: "fica bom, porque aí eu não vou fazer investimento desse... se ela vai se desenvolvendo, eu vou fazer Pix. Se realmente acontecer, a gente efetiva. Se eu vender dois kits, pagar R$1.500 pra uma pessoa, não tem problema nenhum. E eu fico sossegado." (call [55:49])

**Movimento do prospect:** ele QUEBROU A PRÓPRIA OBJEÇÃO em voz alta. Justificou a compra sozinho ("se vender dois kits, pagar a pessoa não é problema") e verbalizou o estado de destino ("fico sossegado").
**Aula:** Call 1 [47:29] — *"o cliente bate numa barreira lógica e justifica a compra sozinho."*
**Por que é ouro:** quando o cliente argumenta a favor da compra com os próprios números, a venda já está feita. Faltava só formalizar.

---

## Bloco 6 — Demonstração do método (Passo D)

> "como que a gente pega os números pra ligar? Vou mostrar. Energia solar em Belo Horizonte, venho no Maps... tenho uma extensão no Google que puxa automático todos os telefones... jogo numa planilha, no CRM, e começa a ligar" (call [40:23])

**Conceito:** apresentação técnica do produto (Passo D). Mostra o mecanismo operacional (lista no Maps, extensão, CRM, script de ligação).
**Aula:** [[CLOSER R2 — Versão Matheus]] — *"apresentação do produto, pode ser técnico, pode mostrar mapa mental."*
**Por que funciona:** ✅ detalhar o COMO aqui é correto (Passo D), e com um cliente "só acredito vendo" ajuda a tirar o medo. Demonstrar a operação é prova de capacidade, não consultoria grátis.

---

## Bloco 7 — R: preço, garantia e adiamento

> "a gente tem somente o custo da contratação, em média uns 500 reais no máximo [na entrada]... em vez de 4 mil nos 30 dias, seria 3.500, e a gente divide em duas vezes" (call [1:03:05] a [1:04:00])

**Conceito:** preço do acompanhamento (~R$3.500, de R$4.000), com entrada baixa (~R$500 só pra contratar) e o resto diferido/parcelado. Risco reverso embutido: o grosso só depois da pessoa rampar.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"nunca dar desconto, trocar a estrutura."* (aqui deu um abatimento de R$500, mas estruturou pague-conforme-resultado).
**Por que funciona parcial:** ✅ a estrutura (entrada mínima + resto após resultado) casa com o perfil. ⚠️ a parte numérica saiu embolada (R$4.000 → R$3.500 → R$500 entrada → R$1.500 da pessoa) e cortada por queda de conexão. Faltou cravar o número final limpo numa frase só.

---

> Cristiano: "no primeiro momento, nada de contratação fixa, né? só a parte, 30 dias daquele modelo, 10 visitas" + "o que eu peço é finalizar esse mês, a gente começa em julho... não vou misturar as coisas" (call [1:01:59] e [1:05:31])

**Movimento do prospect:** aceitou o modelo, mas pediu pra começar em julho (depois de encerrar o contrato de ads atual). Objeção de timing legítima, não de mérito.
**Aula:** Call 1 [98:50] — respeitar o ritmo/decisão do cliente.
**Por que importa:** o sim veio, mas com 2 semanas de espera e sem dinheiro na mão. Risco de esfriar (ver falhas).

---

## Bloco 8 — Fechamento

> "já que está gravando, vamos deixar bem certo. Vamos fechar mesmo dia 1º?" → "a gente combinando de iniciar 1º de julho... assina no início de julho. Pode ser?" → Cristiano: "Fechado." (call [1:07:15] e [1:08:04])

**Conceito:** fechamento por compromisso público, usando a gravação como testemunha pra formalizar a data.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"pode ser? Sim ou não?"*
**Por que funciona:** ✅ usou o gravador de forma criativa pra cravar a data e tirar o "depois a gente vê". Cliente disse "Fechado". Compromisso assumido.

---

> "no início de julho você transfere a entrada, a gente começa a contratação, em média 7 dias a gente já contrata e coloca a pessoa pra começar" → Cristiano: "Terminado." (call [1:08:25])

**Conceito:** R do CLOSER — sequência pós-fechamento (entrada → contratação → início em 7 dias) + onboarding rápido.
**Aula:** Imersão [307:00] — *"as primeiras 48h."* (aqui adaptado: ramp em 7 dias).
**Por que funciona:** ✅ deixou o próximo passo concreto e datado. "Terminado" do Cristiano = compromisso final.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Participou do evento?" + "entender suas dificuldades" | C do CLOSER | Imersão [311:25] |
| Cristiano: "tá queimando o dinheiro" | Número de dor + termo próprio | Call 1 [80:24] |
| "316 leads, zero venda, zero visita" | Dor quantificada (fracasso do anúncio) | Call 1 [80:24] |
| "podia ter comprado 2 máquinas de lavar" | Custo de oportunidade | Imersão [320:10] |
| "gato escaldado, não acredito mais" | Objeção-mãe (desconfiança) | Call 1 [97:18] |
| "pra morrer pobre o que tenho já tá bom" | Urgência baixa em solar (não captada) | Call 1 [80:24] |
| "mais vendas de solar, né?" → "Isso" | L feito (racional) ✅ | CLOSER R2 |
| "já investimos 8 milhões em ads" | Prova social + autoridade | Imersão (autoridade) |
| "tráfego pago 2.0, visita já marcada" | Oferta-frase / mecanismo | Imersão [326:50] |
| "cliente comercial: açougue, padaria, academia" | Blue Ocean | Fundamentos |
| "1-2 vendas/mês, a pessoa se paga" | Destino com resultado | R1/R2 [30:37] |
| "só contrato com prova" | Cliente cravou o formato de compra | Call 1 [97:18] |
| História do fator de potência ("pago com resultado") | Cliente entregou a própria filosofia | Call 1 [48:38] |
| "você não começa pagando" | Risco reverso | Imersão [222:54] |
| Teste de fogo (bônus no teste, fixo após provar) | S+E sob medida | Imersão [222:54] |
| Devolveu "gato escaldado" com empatia | Devolver o termo do cliente | Imersão [317:35] |
| "se vender 2 kits, pagar a pessoa não é problema" | Cliente quebrou a própria objeção | Call 1 [47:29] |
| Demonstrou Maps + extensão + CRM | Apresentação técnica (Passo D) ✅ | CLOSER R2 |
| ~R$3.500, entrada ~R$500, parcelado | Preço (estrutura ok, número embolado) | Imersão [330:00] |
| "começa em julho, não misturar" | Adiamento de timing (não de mérito) | Call 1 [98:50] |
| "já que tá gravando, fechar dia 1º" → "Fechado" | Fechamento por compromisso público | Imersão [330:00] |
| "transfere a entrada, contrata em 7 dias" → "Terminado" | Sequência pós-fechamento | Imersão [307:00] |

**Score CLOSER R2:** **C ✅ · L ✅ · O ⚠️ · S ✅ · E ✅✅ · R ✅** — FECHOU (verbal, início 1º/jul).

---

## ⚠️ Onde o Matheus deixou pontas (mesmo fechando)

**1. Não mediu urgência e não capturou que solar é baixa prioridade pro Cristiano.** Ele disse claro: "pra morrer pobre o que eu tenho já tá bom", "elétrica vai bem, solar é extra". O motor dele é não desperdiçar + gostar de instalar, não desespero. Fechou, mas o risco é ele não priorizar a execução (não atender a pessoa, não ir nas visitas). Faltou o O pra pinar o real porquê e amarrar compromisso de execução. **Imersão [320:10].**

**2. Fechamento verbal, adiado e sem dinheiro na mão.** O sim é pra 1º de julho, com 2 semanas de vácuo e zero pagamento. "Gato escaldado" + 2 semanas parado = risco real de esfriar. Cravou a data (bom), mas idealmente puxava uma microâncora de compromisso já (ex: sinal simbólico, ou agendar o onboard de contratação já com data).

**3. L só racional (mesma ponta da R2 do Ladislau).** Tinha "queimando o dinheiro" e "gato escaldado" na mesa e rotulou só "mais vendas de solar". Fechou mesmo assim porque o E foi cirúrgico, mas o rótulo com a palavra dele teria deixado o L mais quente. Plus, não falha.

**4. Número do preço saiu embolado.** R$4.000 → R$3.500 → R$500 de entrada → R$1.500 da pessoa, tudo no meio de queda de conexão. Faltou fechar o valor numa frase limpa ("o acompanhamento fica R$3.500, R$500 de entrada agora e o resto em 2x após a pessoa rampar"). Risco de ruído na hora do contrato.

**O que foi acerto grande (manter):** o E. Ouviu o cliente entregar a própria filosofia ("pago com resultado") e a história do fator de potência, e desenhou a oferta no formato exato dele (teste de fogo / risco reverso). Devolveu o termo "gato escaldado" com empatia. Resultado: o cliente quebrou a própria objeção e fechou. Esse é o tipo de leitura que faltou na R2 do Ladislau.

---

## Aplicação na próxima R2

- [ ] **Medir urgência (O) mesmo quando o cliente está confortável.** Se a dor não é financeira, achar o motor real (orgulho, não desperdiçar, gostar do ofício) e amarrar compromisso de EXECUÇÃO, não só de compra.
- [ ] **Fechou adiado? Crava microcompromisso já.** Onboard datado, sinal simbólico, ou grupo criado na hora, pra não esfriar no vácuo.
- [ ] **Cravar o número do preço numa frase limpa** depois de toda a negociação, pra não deixar ruído pro contrato.
- [ ] **Manter o que ganhou:** ouvir a filosofia do cliente e devolver a oferta no formato dele + devolver o termo próprio dele com empatia + risco reverso pra matar desconfiança.

---

## 🔁 Comparativo: Ladislau vs Cristiano (as duas R2 do dia)

Mesmo avatar quase idêntico: integradora solar, queimado por agência de tráfego, "gato escaldado", caixa curto, desconfiado. **Um fechou (Cristiano), o outro não (Ladislau).** O que explica a diferença:

| | Ladislau | Cristiano |
|---|---|---|
| Estrutura | Tem time (Thaísa + Camila) | Solo |
| Oferta | Ignição Comercial R$4.000 (treina o time, paga adiantado) | Teste de fogo (LM contrata+treina, paga por resultado) |
| Objeção-mãe | "tiro tudo do bolso, não posso arriscar" + "tem que ter marketing" | "gato escaldado, só contrato com prova" |
| Tratamento da objeção | Garantia DEPOIS do preço; bateu de frente no marketing; objeção ficou viva | Risco reverso ANTES do preço; espelhou a filosofia dele; objeção morreu |
| Resultado | Não fechou (foi pro financeiro) | Fechou (início 1º/jul) |

**A lição:** os dois são "gato escaldado" e sem caixa. No Cristiano, o Matheus enquadrou a entrada como **pague-conforme-resultado** (o cara só desembolsa de verdade depois de ver funcionar), e isso matou a desconfiança. No Ladislau, a oferta começou com **R$1.500 de entrada upfront**, que bateu de frente com o "tiro do bolso". A garantia do Ladislau era forte, mas veio tarde (depois do preço) e a estrutura ainda pedia dinheiro adiantado.

**Pro follow-up do Ladislau:** reembalar a proposta no mesmo espírito do Cristiano. Reduzir/zerar a fricção da entrada, colocar a garantia na frente do número, e enquadrar como "você só investe pesado depois que as visitas começarem a acontecer". O modelo que fechou o Cristiano é o mapa pra destravar o Ladislau.

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Ladislau (R2)]] — a outra R2 do dia (não fechou) — comparativo acima
- [[2026-05-05 — Matheus e Tino vs Synergy (R2)]] — referência de R2 que fechou (garantia antes do preço)
- [[CLOSER R2 — Versão Matheus]] — método
- [[Mentoria Nimoto — Índice]]
</content>

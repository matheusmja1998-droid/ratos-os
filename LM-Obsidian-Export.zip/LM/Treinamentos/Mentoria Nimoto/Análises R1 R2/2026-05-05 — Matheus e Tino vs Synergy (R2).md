---
tipo: análise R2
data: 2026-05-05
vendedor: Matheus Jardim + Valentino Pascual
prospect: Flávio Narezzi de Oliveira + Fabrício Coletti (gestor comercial)
empresa: Synergy Soluções em Energia
nicho: integradora solar (Tangará da Serra/MT)
resultado: FECHADO — R$4.000 em 3 parcelas (1.500 + 1.500 + 1.000), 45 dias
tags: [mentoria, nimoto, r2, análise, lm, vendas, fechamento]
fontes:
  - "[[2026-04-22 — Matheus e Tino vs Synergy (R1)]]"
  - "[[Call Roleplay R2 Synergy (05-05-2026)]]"
  - "[[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]]"
  - "[[CLOSER R2 — Versão Matheus]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Matheus e Tino vendendo para Synergy (R2)

R2 com o Flávio (dono) e o Fabrício (gestor comercial novo no jogo). 44 minutos. Contrato fechado, R$4.000 em 3 parcelas pós-entrega. Onboarding marcado pra quinta 7h. Esse é o cenário onde a R1 ficou aberta com problemas (CLOSER 0/6) e tu chegou na R2 depois de coaching ao vivo do Nimoto + estudo intensivo dos materiais.

> [!info] Resultado e diagnóstico geral
> Fechou pelo método, não por timeout como a R1. O CLOSER apareceu nas 6 letras com execução sólida em 5. A grande sacada foi o reframe criativo de pagamento por marco quando o Flávio resistiu Pix e cartão. **Movimento de closer experiente.**

---

## Bloco 1 — Abertura

> Tino: "Vocês têm mais gargalo hoje, seja na parte comercial, seja na parte de contratar, seja na parte de treinar a equipe... Isso é LM, a gente entra na sua operação, a gente ajuda a escalar seu comercial."

**Conceito:** Apresentação curta da empresa pro Fabrício que caiu de paraquedas.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05] — *"Apresentação em menos de 5 minutos."*
**Por que funciona parcialmente:** cumpre regra do tempo, mas pula apresentação pessoal ("meu nome é, sou do, fundador da..."). Foi direto pro o que a empresa faz.

---

> Matheus: "Que bom ter você aqui conosco nesse bate-papo... A primeira coisa que eu queria perguntar e ver contigo, **se alguma coisa mudou da semana passada para essa semana**, se teve alguma dificuldade nova, se permanece tudo igual."

**Conceito:** **C do CLOSER em versão R2** — pergunta de atualização.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] — *"A primeira coisa numa reunião não é se apresentar. É descobrir por que aquele cliente aceitou."*
**Por que funciona:** exatamente a fórmula que o Nimoto roleplayou em 05/05. Tu DECOROU. Saiu natural. ✅

---

> Flávio: "Vamos dizer que tá a mesma coisa. **Na verdade, tá pior.**"

**Movimento do prospect:** verbalizou agravamento de dor antes mesmo do L. Sinal verde gigante.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real do Flávio:** "tô sufocado, preciso de saída, vim aqui pra ouvir solução."

---

## Bloco 2 — Recap do problema (L do CLOSER)

> Matheus: "Você falou conosco que os seus problemas eram os vendedores que não trabalhavam CRM de maneira correta... falou também da **autofagia de mercado**, que aquela concorrência com os pica-fios, que aquilo ali é uma concorrência desleal na realidade."

**Conceito:** **L do CLOSER — devolver o termo do cliente.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [317:35] — *"Dê um nome ao problema. Faça o cliente repetir o problema em voz alta."*
**Por que funciona MUITO:** **CONSERTOU O ERRO #1 DA R1.** Trouxe "autofagia de mercado" de volta na boca dele. Ancorou. Se ele tinha esquecido o termo, lembrou agora. ✅

---

> Matheus: "Só para a gente entender bem, **é isso mesmo os seus problemas ou tem mais alguma coisa que tu queria agregar** para a gente aqui agora?"

**Conceito:** Pergunta de validação do L ("seria isso ou tô enganado?").
**Aula:** [[CLOSER R1 — Versão Matheus]] — *"Faça o cliente repetir o problema em voz alta."*
**Por que funciona:** força confirmação. Mas o Flávio passou a palavra pro Fabrício, abrindo espaço pra dor nova surgir.

---

> Fabrício: "Fora de Tangará, **a gente não consegue ser competitivo** justamente por essas questões aí das empresas do mercado de energia solar não ter essa barreira de entrada e qualquer um conseguir vender."

**Movimento do prospect:** Fabrício verbalizou autofagia geográfica (Mirassol, Itapurá). Dor expandida de bandeja.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [116:46] — *"Quem faz as perguntas está no controle da conversa."*
**Por que importa:** o gestor confirmou e ampliou a dor que o dono tinha rotulado. Munição extra pro S.

---

## Bloco 3 — O do CLOSER (urgência)

> Matheus: "Eu queria perguntar para vocês, para o Flávio, para o Fabrício, **qual que é o nível de urgência para estar resolvendo esse problema**?"

**Conceito:** **O do CLOSER em versão R2 — comprime tríade em pergunta de urgência presente.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [320:10] — *"Eu quero ver meu cliente triste."*
**Por que funciona:** exatamente a inversão que o Nimoto te mostrou no roleplay. ✅

---

> Matheus: "**Se a gente falar que é urgente, vai ser mais caro, então não.**"

**Conceito:** **Antecipação de objeção que o cliente NÃO fez** — erro.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [97:18] — *"Toda objeção é falta de uma narrativa bem contada."*
**Por que falhou:** plantou semente de "tem preço" antes do cliente perguntar. Inverte o controle. **Não plantar narrativa que o cliente não pediu.**

---

> Tino: "**A gente não vai trazer um projeto se a gente ver que não é urgente** para vocês."

**Conceito:** **Ameaça de retirada / escassez real.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [219:35] — *"Escassez real, não inventada."*
**Por que funciona:** o Tino salvou a etapa que tu tinha embolado. Jogou a régua de volta no cliente: "se não é urgente, a gente nem traz proposta". Forçou alinhamento. ✅

---

> Tino: "Vocês estão aqui para... **atingir o cliente certo de vocês, sair da comparação? É isso mesmo?**"
> Flávio: "Sim."

**Conceito:** **Pergunta-âncora do destino antes de apresentar.**
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [30:37] — *"A gente sempre vende o destino final."*
**Por que funciona:** confirma destino antes de tu apresentar produto. Inversão clássica do Nimoto: oferta antes do produto. ✅

---

## Bloco 4 — S do CLOSER (Sell the Vacation)

> Matheus: "O destino final que a gente quer levar e trazer para vocês é que **em 45 dias, tirar vocês da autofagia de mercado através de uma prospecção ativa e estruturada, onde vocês vão alcançar os clientes que os pica-fios não conseguem alcançar**."

**Conceito:** **S do CLOSER — Sell the Vacation com a oferta-frase decorada.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final, não o voo."* + [193:14] — *"Vende o destino, não a passagem."*
**Por que funciona MUITO:**
- 4 ingredientes da fórmula MAGIC: tempo (45 dias) + saída de (autofagia) + mecanismo (prospecção ativa estruturada) + destino (clientes que pica-fio não alcança)
- Específico do Flávio, não genérico
- Tu decorou. Saiu natural sem ler. ✅

---

> Matheus: "**Esse destino que a gente quer entregar para vocês está alinhado com as expectativas?** A gente está alinhado no mesmo caminho?"

**Conceito:** **Pergunta-âncora do destino** (passo A da sequência Nimoto pós-S).
**Aula:** [[Call Roleplay R2 Synergy (05-05-2026)]] — *"Esse é o destino que tu quer chegar? A gente entendeu bem o que tu quer?"*
**Por que funciona:** força o cliente a confirmar o destino antes de tu detalhar produto. ✅

---

> Fabrício: "Eu acho que **se a gente conseguisse melhorar os leads**, hoje o tráfego que a empresa faz... chega bastante lead desqualificado."

**Movimento do prospect:** Fabrício jogou destino divergente (melhorar tráfego pago). Ameaça de bagunça interna entre dono e gestor.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [98:50] — *"Isolar decisão antes de avançar."*
**O que era pra ter sido feito:** "Antes de seguir, vocês dois tão alinhados sobre qual destino querem hoje?". Tu não isolou.

---

> Flávio: "Eu tenho quase certeza de que o tráfego pago não gera mais lead qualificado... **eu acho que até a proposta dos meninos aí, Fabrício, não é nesse sentido não.**"

**Movimento ouro do prospect:** o Flávio defendeu tua proposta sozinho na frente do gestor. Sinal absurdo de que ele já tava vendido. Resolveu o problema do bloco anterior por ti. ✅

---

> Matheus: "**Inclusive, Flávio, eu concordo. Eu é um grande ponto que você concordo firme.**"

**Conceito:** **Reciprocidade real + reforço de autoridade do decisor.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [48:38] — *"Reciprocidade é entender: cara, eu entendo como você se sente."*
**Por que funciona:** tu virou aliado do Flávio na frente do Fabrício. Não bateu de frente com a divergência interna. Resgatou autoridade do dono. ✅

---

## Bloco 5 — Apresentação técnica (Miro com 3 pilares)

> Matheus: "A gente trouxe esse produto, esse caminho para o destino final... em três pilares, a **máquina de leads**, **time estruturado**, **previsibilidade**."

**Conceito:** **Apresentação em 3 pilares.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Divida sua solução em 3 pilares."*
**Por que funciona:** estrutura limpa, cliente segue o raciocínio. ✅

---

> Matheus: "Flávio, você consegue me relembrar **quantas vendas vocês estão fazendo por mês** aí hoje?"

**Conceito:** Pergunta de calibração antes de avançar na apresentação.
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] cap. 4 — *"Checkpoints durante a call."*
**Por que funciona:** mantém o cliente engajado. Não é monólogo de apresentação. Pega dado pra customizar.

---

> Matheus: "**Eles têm, pelo menos, uma hora por dia, cada pessoa tem capacidade?**"
> Fabrício: "Eu ensino."

**Conceito:** Pré-validação de responsabilidade da contratante.
**Por que funciona:** ancora condição operacional necessária pra entrega antes do contrato. Reduz risco da garantia ser acionada por culpa deles. ✅

---

> Matheus: "Eu queria saber se vocês acreditam que **isso faz sentido hoje para a realidade de vocês**, se vocês acreditam que **isso é para vocês hoje**, eu queria realmente ouvir um feedback sobre esse organograma."

**Conceito:** **2 das 3 portas do R do CLOSER** (faz sentido + é pra você).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Você entende que esse serviço atende? Você acredita que isso se encaixa pra sua empresa?"*
**Por que funciona parcialmente:** ✅ as perguntas certas. ⚠️ feitas em bloco no fim, não distribuídas durante a apresentação igual o Nimoto faz na V4 ("deu pra entender?", "seria problema MRR?", "tem dúvida?"). Pra próxima R2: intercalar uma porta entre cada pilar do Miro.

---

> Flávio: "**A gente já tem um playbook**, tá faltando formatar ele."

**Movimento do prospect:** objeção sutil. "Vocês querem fazer algo que eu já tenho." Resistência de ego.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [97:18] — *"Toda objeção é falta de narrativa bem contada."*

---

> Matheus: "A gente pode trabalhar **o melhor dos mundos e formatar o seu playbook**... a gente entraria ali realmente para agregar o que falta relacionado à parte de prospecção ativa..."

**Conceito:** **3As clássico** — Concordo (existe playbook) + Contorno (formatamos juntos + agregamos prospecção ativa) + Sugiro (tu daria liberdade?).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [97:18] — *"Concordo / Contorno / Sugiro."*
**Por que funciona:** valorizou o trabalho dele e posicionou o Ignição como **complemento**, não substituição. Desarmou ego e objeção ao mesmo tempo. ✅

---

## Bloco 6 — 3ª porta (acreditar no executor)

> Matheus: "Hoje você, Flávio, você, Fabricio, vocês acreditam **que na gente pra estar executando isso com vocês**? Porque a parte da confiança e do comprometimento e do entendimento que a gente pode avançar..."

**Conceito:** **3ª porta do R do CLOSER — "tu acredita que sou a pessoa?"**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Você acredita que eu sou a pessoa que consegue te entregar isso?"*
**Por que funciona:** pergunta direta, sem rodeio. ✅

---

> Flávio: "A pergunta que eu faço é o seguinte, **você vai conversar só comigo e com o Fabricio ou você vai conversar com os vendedores?**"

**Movimento do prospect:** não respondeu sim direto na 3ª porta. Levantou pergunta operacional. Sinal de "tô interessado, mas preciso de detalhe pra fechar".
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema, é a intenção."*
**Intenção real:** "preciso saber se isso vai mexer com meu time inteiro ou só comigo."

---

## Bloco 7 — Garantia ANTES do preço

> Matheus: "Esse projeto de 45 dias, ele se estende **indefinidamente, sem custo nenhum para vocês**, até seu time estiver gerando reuniões com clientes comerciais... A gente traz essa garantia **até antes de falar o preço aqui**, porque a gente quer realmente entregar resultado para vocês."

**Conceito:** **Garantia ANTES do preço + Probabilidade de Sucesso da Equação do Valor.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] — *"Garantia de execução."* + [189:46] — *"Resultado × Probabilidade / Tempo × Esforço."*
**Por que funciona MUITO:**
- Reduz risco percebido a zero antes do número aparecer
- Cliente pensa "posso pagar e mesmo assim não perder"
- Mata objeção de "e se não funcionar" antes dela existir
- **Mais explícita que o Nimoto fez com a V4** (ele falou de garantia implícita de 15 dias). Vocês deixaram literal: "vai indefinido sem custo até gerar visitas". ✅✅

---

> Matheus: "Hoje, pessoal, o valor dessa implementação da ignição comercial... fica no valor de **R$4.000,00**."

**Conceito:** **Preço direto, sem rodeio**, depois de tudo armado.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Se sim/sim/sim, sobra apenas valor."*
**Por que funciona:** sem floreio. Número direto após 3 portas e garantia. ✅

---

## Bloco 8 — E do CLOSER (objeção forte de pagamento)

> Flávio: "**Eu não gostaria de pagar nada à vista e eu não gostaria de pagar nada no cartão**. É assim, eu não vou julgar vocês, mas **cachorro picado por cobra tem medo de linguiça**. O contato que eu tenho é via telefone."

**Movimento crítico do prospect:** objeção forte e legítima. Trauma de fornecedor que sumiu. Não é falta de dinheiro, é falta de confiança.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema, é a intenção."*
**Intenção real:** "quero pagar mas preciso de garantia de que vocês não somem."

---

> Tino e Matheus entram em conversa de futebol, boxe, jiu-jitsu por 2 minutos.

**Conceito:** Rapport no momento errado.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [97:18] — *"Toda objeção é falta de narrativa bem contada."*
**Por que falhou:** rapport tem hora — durante objeção forte não é a hora. Quase deixou a objeção esfriar e virar "preciso pensar". Recuperou bem depois, mas o ideal era ter ido direto pro reframe.

---

> Tino: "E a gente também, assim, **a gente é desconfiado, principalmente com o digital.** E eu queria te perguntar, é mais para... picadas que você recebeu ou é realmente pela gente, pelo nosso lado aqui?"

**Conceito:** **Reciprocidade real + isolar objeção.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [48:38] — *"Reciprocidade é entender: cara, eu entendo como você se sente."*
**Por que funciona:** Tino se igualou ("a gente também já foi picado") e isolou a objeção (é trauma genérico ou desconfiança específica de nós?). Movimento limpo. ✅

---

> Matheus: "Uma ideia que eu tive aqui, Valentino... **a gente seta pagamentos pós entrega.** Exemplo, a gente fez entrega de 15 dias, vocês pagam R$1.500. Fez mais entrega de 15 dias, mais R$1.500. Fez a entrega dos últimos 15 dias, o outro pagamento do restante."

**Conceito:** **Reframe criativo + escuta da intenção real + nunca dar desconto.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Nunca dar desconto. Como posso facilitar pra você fechar comigo agora?"*
**Por que funciona MUITO:**
- Não baixou preço (regra de ouro)
- **Trocou estrutura, não valor**
- Inverteu polaridade: era "tenho medo de pagar", virou "pago se vocês entregarem"
- Movimento de closer experiente. ✅✅

---

> Flávio: "**Por mim tá ok, dessa forma sim.**"

**Movimento do prospect:** objeção fechada. Compromisso público. ✅

---

> Flávio: "**Vocês vão conversar direto com o Fabricio**, tá, Fabricio e o time comercial, eu não vou poder me comprometer com isso, porque já teve casos assim de, ah, precisa de mim, precisa de mim, que eu sinto, sinto, que quem tava fornecendo o serviço já sabia que eu não conseguiria participar."

**Movimento do prospect:** isolou própria responsabilidade operacional. Desce o decisor estratégico, sobe o gestor tático.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [98:50] — *"Isolar decisão."*
**O que isso significa:** ele tá fechando, mas avisando que execução do dia a dia vai com Fabrício. Importante pra ti planejar onboarding.

---

## Bloco 9 — Fechamento

> Matheus: "Ô Flávio, então **a gente pode estar fazendo um contrato do nosso lado pra gente estar dando um start**?"
> Flávio: "**Pode. Fechado, então.**"

**Conceito:** **Fechamento direto com pergunta de compromisso.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Sim ou não? Pode ser?"*
**Por que funciona:** sem rodeio. Pergunta direta, resposta direta. ✅

---

> Matheus: "Pessoal, a gente vai criar um grupo, eu, você, o Valentino, o Fabrício também... amanhã vocês podem ler com calma o contrato, assinando, a gente já manda o formulário. **Na quinta-feira, ali, sete horas da manhã** para vocês, e oito horas da manhã para nós, a gente já faz a nossa primeira reunião."

**Conceito:** **R do CLOSER — Reinforce com primeiras 48h.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — *"As primeiras 48h são decisivas para decidir se gostou ou não do produto. Faça uma recepção calorosa."*
**Por que funciona:** kickoff em 48h, próxima sessão marcada na hora. ✅

---

> Matheus: "**Agradeço vocês pela confiança, e a gente vai empenhar o máximo do nosso lado aqui para entregar resultado para vocês.**"

**Conceito:** Recepção calorosa imediata + reforço do compromisso.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — *"Faça uma recepção calorosa."*
**Por que funciona:** fecha o R com gratidão e promessa pública. ✅

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Mudou alguma coisa desde a última conversa?" | C do CLOSER (R2) | Imersão [311:25] |
| "Tá pior" (Flávio) | Cliente verbalizou agravamento | Call 1 [80:24] |
| Devolveu "autofagia de mercado" | L do CLOSER | Imersão [317:35] |
| "Qual o nível de urgência?" | O do CLOSER comprimido | Imersão [320:10] |
| "Se for urgente vai ser mais caro" | Antecipou objeção que cliente não fez | Call 1 [97:18] |
| "Se não for urgente, a gente nem traz" (Tino) | Ameaça de retirada | Imersão [219:35] |
| "É esse destino mesmo?" (Tino) | Pergunta-âncora do destino | R1/R2 [30:37] |
| "45 dias tirar da autofagia via prospecção ativa estruturada" | S — Sell the Vacation com MAGIC | Imersão [326:50] |
| "Inclusive Flávio, eu concordo" | Reciprocidade + reforço de autoridade do dono | Call 1 [48:38] |
| 3 pilares (máquina, time, previsibilidade) | Apresentação em 3 pilares | Imersão [326:50] |
| "Vocês acreditam que isso faz sentido?" | 1ª e 2ª portas em bloco | Imersão [330:00] |
| "Vocês acreditam que na gente pra executar?" | 3ª porta | Imersão [330:00] |
| 3As no playbook ("a gente formata o teu") | E — quebra de objeção | Imersão [97:18] |
| "Indefinido sem custo até gerar visitas" | Garantia antes do preço | Imersão [222:54] |
| Reframe pagamento por marco | E — não dar desconto, trocar estrutura | Imersão [330:00] |
| "Pode fazer contrato?" → "Pode. Fechado." | Fechamento direto | Imersão [330:00] |
| Onboarding em 48h | R do CLOSER | Imersão [307:00] |

**Score CLOSER R2:** **C ✅ L ✅✅ O ✅ S ✅✅ E ✅✅ R ✅** — 6 de 6 letras com execução sólida.
**Comparação com a R1 (13 dias atrás):** C❌ L❌ O⚠️ S❌ E❌ R⚠️.

---

## ⚠️ Onde Matheus e Tino ainda escorregaram

**1. Antecipou objeção que o cliente NÃO fez.**
> "Se a gente falar que é urgente, vai ser mais caro, então não."

O Flávio nem tinha objetado preço. Plantou semente que ele não pediu. Custou autoridade do momento. **Call 1 [97:18]** — toda objeção é falta de narrativa, mas não plantar narrativa que o cliente não pediu.

**2. As 3 portas em bloco no fim, não distribuídas.**
Tu fez as 3 perguntas juntas no final da apresentação. O Nimoto vs V4 mostrou que distribuir DURANTE a apresentação é mais natural ("deu pra entender?" no fim de cada pilar). **Imersão [330:00]** — perguntas espalhadas funcionam melhor que bloco final.

**3. Não isolou divergência cliente x gestor.**
Quando Fabrício jogou destino diferente ("melhorar leads do tráfego"), tu não isolou. Foi sorte que o Flávio defendeu tua proposta sozinho. **Call 1 [98:50]** — isolar antes de avançar. Pra próxima: *"vocês dois tão alinhados sobre o destino?"*

**4. Rapport de 2 minutos no meio da objeção forte de pagamento.**
Quase deixou esfriar a objeção e virar "preciso pensar". Recuperou bem com o reframe, mas o melhor era ter ido direto pro reframe. **Call 1 [97:18]** — objeção forte exige narrativa imediata, não rapport.

**5. Sobreposição entre Matheus e Tino no momento da urgência.**
Tu plantou "se for urgente vai ser mais caro", e o Tino entrou pra salvar. Funcionou, mas mostra que ainda tem sobreposição. **Pra próximo cliente:** combinar antes quem responde objeção. Idealmente quem fez a pergunta original conduz a resposta.

---

## ✅ O que vocês fizeram MELHOR que o Nimoto na R2 dele com a V4

**1. Garantia explícita ANTES do preço.**
O Nimoto vs V4 falou de garantia implícita (resultado em 15 dias). Vocês explicitaram: *"vai indefinido sem custo até gerar visitas qualificadas com clientes comerciais."* Mais forte. Mata risco percebido na hora.

**2. Reframe criativo de pagamento.**
Quando Flávio resistiu Pix e cartão, vocês inventaram pagamento por marco no ato. Não baixaram preço. Trocaram estrutura. Movimento de closer experiente. ✅

**3. Resgate da autoridade do dono perante o gestor.**
Quando Fabrício jogou destino divergente, tu reforçou o Flávio na frente dele em vez de mediar. Respeitou hierarquia interna e fortaleceu o decisor.

---

## Aplicação na próxima R2 (cliente novo)

- [ ] **Distribuir as 3 portas durante a apresentação**, não em bloco no fim
- [ ] **Não antecipar objeção que o cliente não fez** (deixar ele puxar)
- [ ] **Combinar com Tino quem responde cada pergunta** antes da call (zero sobreposição)
- [ ] **Em objeção forte, ir direto pro reframe** — sem rapport de futebol no meio
- [ ] **Quando aparecer divergência cliente x gestor, isolar antes de avançar**
- [ ] **Manter o que funcionou:** oferta-frase decorada + garantia antes do preço + reframe criativo de pagamento

---

## Frases de ouro pra repetir (versão Matheus + Tino)

1. "Em 45 dias, tirar vocês da autofagia de mercado através de prospecção ativa estruturada, alcançando clientes que os pica-fios não conseguem alcançar."
2. "A gente não vai trazer um projeto se a gente ver que não é urgente." (Tino)
3. "Esse projeto de 45 dias se estende indefinidamente, sem custo nenhum, até seu time estiver gerando reuniões com clientes comerciais."
4. "A gente seta pagamentos pós entrega. Fez 15 dias, vocês pagam R$1.500. Fez mais 15, mais R$1.500."
5. "Inclusive, Flávio, eu concordo. Eu é um grande ponto que você concordo firme."

---

## Documentos relacionados

- [[2026-04-22 — Matheus e Tino vs Synergy (R1)]] — análise da R1
- [[Call Roleplay R2 Synergy (05-05-2026)]] — coaching com Nimoto antes da R2
- [[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]] — referência canônica do padrão
- [[CLOSER R2 — Versão Matheus]] — método estudado
- [[Contrato — Synergy x Winvision (Ignição Comercial)]] — contrato fechado
- [[R2 Synergy — Flávio + Fabrício (05-05-2026)]] — transcrição completa

---
tipo: análise R1
data: 2026-06-19
vendedor: Matheus Jardim
prospect: Eduardo Ferreira (Cematech, energia solar, Bahia)
nicho: energia solar
resultado: R2 marcada para 26/06 às 9h
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Matheus vendendo para Cematech (Eduardo)

R1 de cerca de 24 minutos com o Eduardo, da Cematech (energia solar, Bahia). Cara experiente (40 anos de tecnologia, ~30 de mercado, migrou pro solar). Operação enxuta: ele + um auxiliar (o filho, de manhã, faz orçamento e algumas ligações) + um técnico na rua. Terceiriza engenharia e instalação. Vende por parceiros em várias cidades + indicação. Forte em serviço (monitora proativo, garantia de troca de equipamento). Tráfego só trouxe curioso, zero venda. Dor principal: concorrência predatória de preço na Bahia. R2 marcada pra 26/06 9h.

> [!info] Resultado e diagnóstico geral
> R1 boa, e nota-se a evolução. Essa é PÓS-ajuste: tu segurou o pitch (não dumpou teste de fogo nem preço), plantou a solução e travou a R2 com data e hora. E o encaixe é dos melhores que tu pegou: o diferencial do Eduardo (serviço, garantia, 30 anos) é exatamente o que o cliente comercial valoriza, então o comercial não é só ticket maior, é a única arena onde a vantagem dele importa. Os furos são os de sempre: não rotulou com nome próprio, deixou passar o número de dor (30 orçamentos parados) e concordou com a objeção macro (período ruim) em vez de reframar.

> [!note] Contexto
> Call pós-ajuste de encurtar a R1 (a régua mudou a partir do Denner, 17/06). Aqui dá pra ver na prática: pitch contido, transição limpa, R2 travada. Bom material de comparação com a Orion (16/06, longa, pré-ajuste).

---

## Bloco 1 — Abertura e clareza

> "qual que é a sua maior dificuldade? O Valentino falou que você tá tendo muita comparação de preço" (call [06:10])

**Conceito:** C do CLOSER, mas tu pré-carregou a resposta (entregou o problema que o Valentino te passou, em vez de deixar o Eduardo dizer primeiro).
**Aula:** R1/R2 [16:05].
**Por que parcial:** funcionou porque o Eduardo confirmou e elaborou, mas o ideal é pergunta aberta e ele nomear. Pequeno. (Antes disso teve ~5 min de papo de Copa, rapport bom mas longo.)

---

## Bloco 2 — A dor e o modelo dele

> Eduardo: "aqui na Bahia tem concorrência predatória. Os caras dão quase preço de custo pro cliente. Todo mundo compra nos mesmos fornecedores, não tem mágica" (call [06:24])

**Conceito:** a dor central, bem articulada pelo cliente. Guerra de preço num mercado comoditizado.
**Aula:** R1/R2 [21:49] — bandeja pra rotular.

---

> Eduardo: "minha empresa é enxuta, terceirizo tudo. 99,9% dos clientes satisfeitos, eu sou proativo, ligo antes de dar problema, dou garantia especial, troco equipamento... me indicam muito" (call [08:00])

**Conceito:** o cliente entrega o diferencial dele de bandeja (serviço premium, confiabilidade, 30 anos). Isso é o ativo que muda tudo.
**Aula:** Call 1 [80:24] — a intenção: "eu sou premium e ninguém enxerga meu valor." Esse é o eixo da rotulação que faltou.

---

> Eduardo: "pela internet praticamente nunca vendi nada. Chega muito lead que não quer nada, só quer saber preço, curioso" (call [11:06])

**Conceito:** confirma que o canal atual (anúncio) só traz comprador de preço, o pior cliente pra quem é premium.
**Aula:** R1/R2 [22:17] — número de dor (zero venda pela internet), não enfatizado.

---

> Eduardo: "tô com uns 30 orçamentos prontos, o cliente quer mas não faz: vou aguardar semana que vem, passar a Copa, depois eu trato. Tá tudo nessa marizinha... e não vou reduzir preço só pra fazer obra" (call [12:46])

**Conceito:** o número de dor mais forte (30 orçamentos parados) + a postura (não corre pro preço baixo).
**Aula:** R1/R2 [9:54] — era pra enfatizar: "30 orçamentos parados é quanto de faturamento represado?" Passou sem amplificar (ver falhas).

---

## Bloco 3 — Label e tríade

> "hoje sua dificuldade vem da comparação de preço (o preço desleal dos caras) e da dificuldade de aumentar o volume de vendas por conta desses períodos. Seria isso?" → Eduardo: "exato, e mostrar nosso diferencial" (call [13:47])

**Conceito:** Label descritivo. Repetiu os dois pontos, mas não amarrou no que o Eduardo é (premium num mercado de commodity).
**Aula:** R1/R2 [24:24].
**Por que falhou parcial:** o rótulo afiado: *"teu problema não é preço, é arena. Você é um cara de serviço premium num mercado residencial que só olha preço e não enxerga teu diferencial."* O Eduardo até completou sozinho ("mostrar nosso diferencial"), tu só não cravou.

---

> "além do tráfego e indicação, já tentou porta-a-porta, ligação?" → Eduardo: "ligação já, numa campanha 2 anos atrás passei lista pro parceiro ligar, mas era tudo curioso, não veio nada" (call [17:34])

**Conceito:** primeira parte da tríade (já tentou) + o porquê falhou (lista de curioso). Boa cobertura.
**Aula:** R1/R2 [27:28].

---

> (Matheus conta a própria história de trabalhar com o pai na roça, ao saber que o auxiliar do Eduardo é o filho) (call [17:34])

**Conceito:** rapport via espelhamento (pai/filho). Boa conexão, talvez um pouco longa.
**Aula:** Call 1 [48:38] (reciprocidade/conexão real).

---

## Bloco 4 — Solução, ponte e transição (disciplinada)

> "a gente trabalha prospecção ativa, treina as pessoas da empresa, e não é ligação pra curioso, é pra EMPRESA: comercial (açougue, padaria, supermercado, academia). O picareta que vende espremido não chega no comercial. O comercial puxa fundo (quantas instalações, tempo de mercado), então sai da briga de preço" (call [19:53])

**Conceito:** a melhor ponte da call. Liga a dor (guerra de preço) à solução (comercial), e implicitamente ao diferencial dele (o comercial valoriza confiabilidade, que é o forte do Eduardo).
**Aula:** Call 1 [47:29] — barreira lógica que ele mesmo justifica.
**Por que funciona:** o comercial não é só ticket maior, é a arena onde o serviço premium do Eduardo finalmente vira vantagem em vez de custo.

---

> "eu queria montar um projeto pra você ou seus revendedores... esse bate-papo é pra conhecer, eu reverei a gravação e penso no projeto com calma. Se for teu interesse, marco um segundo bate-papo" (call [19:53])

**Conceito:** transição pra R2 SEM dump de mecanismo, teste de fogo ou preço. Disciplina pós-ajuste.
**Aula:** R1/R2 [13:18].

---

> R2 travada: "dia 26, sexta, 9h" (call [23:21] a [23:57])

**Conceito:** travou data E hora (negociou em cima do São João e fechou firme).
**Aula:** R1/R2 [13:18].
**Por que funciona:** compromisso concreto, não ficou no "me manda os horários". Evolução clara.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Qual sua maior dificuldade?" (pré-carregada) | C do CLOSER | R1/R2 [16:05] |
| Eduardo: "concorrência predatória, preço de custo" | Dor central | R1/R2 [21:49] |
| Eduardo: "sou proativo, garantia, 30 anos, me indicam" | Diferencial premium entregue | Call 1 [80:24] |
| Eduardo: "30 orçamentos parados" | Número de dor (não enfatizado) | R1/R2 [9:54] |
| "É preço + volume, né?" | Label descritivo | R1/R2 [24:24] |
| "Já tentei ligação, era tudo curioso" | Tríade (já tentou) | R1/R2 [27:28] |
| "Comercial puxa fundo, sai da briga de preço" | Ponte dor→solução (a arena dele) | Call 1 [47:29] |
| Transição sem dump de preço/mecanismo | Disciplina pós-ajuste | R1/R2 [13:18] |
| R2 travada 26/06 9h | Encerramento firme | R1/R2 [13:18] |

---

## Decisões estratégicas de escopo / camada

**Produto-alvo:** Ignição Comercial / prospecção comercial.
**Quem prospecta:** ele tem o auxiliar (filho, faz orçamento e ligações de manhã) e os parceiros nas cidades. Dá pra treinar o filho e/ou os parceiros, ou trazer alguém. Mostrar isso no projeto.

**O insight que muda a venda:** o Eduardo é um player PREMIUM (serviço, garantia, 30 anos, proativo) preso na arena errada. No residencial, o comprador é commodity (só olha preço), e o diferencial dele é invisível. No comercial, o comprador é sofisticado e valoriza exatamente o que ele faz de melhor (confiabilidade, suporte, histórico). A venda da R2 não é "vende mais", é "te leva pra arena onde teu jogo finalmente vale". Esse é o rótulo e o destino.

**Perfil de preço:** estabelecido e estável (vive bem de indicação), não é desesperado mas não paga bobagem ("não faço maluquice"). Vender no valor (a arena certa), não no desconto.

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não rotulou com nome próprio.** O Eduardo te deu o eixo de bandeja (premium num mercado de commodity), e tu ficou no descritivo "preço + volume". Faltou: "teu problema não é preço, é arena." R1/R2 [21:49] e [24:24].

**2. Deixou passar o número de dor.** 30 orçamentos parados é o ouro da urgência e passou sem enfatizar. Era pra repetir e fazer doer: "30 orçamentos represados é quanto de faturamento parado na mesa?" R1/R2 [9:54].

**3. Concordou com a objeção macro.** No "período frio, Copa, política, todo mundo estica" tu falou "é período ruim mesmo" em vez de reframar. O comercial é menos sensível a isso, e quem quer cortar conta de luz na crise é o comercial. Call 1 [122:00].

**4. Small talk longo no começo.** ~5 min de Copa. Rapport é bom, mas encurta pra sobrar tempo de diagnóstico afiado.

---

## 🎯 Destino pra R2 (26/06 às 9h)

Cliente experiente, premium e seguro de si. A R2 é fazer ele ver que tá no campo errado e que o comercial é onde o jogo dele vale. Não dumpa mecanismo.

**C — Recap:**
> "Eduardo, desde a nossa conversa o ponto continua o mesmo: você entrega um serviço que ninguém na tua região entrega, mas tá brigando num mercado que só olha preço. Continua sendo isso?"

**L — Crava o rótulo (o eixo que faltou):**
> "Deixa eu te falar como eu vejo o teu problema, porque não é preço. Você é um cara premium: proativo, garantia, troca equipamento, 30 anos de mercado. Só que você tá vendendo isso num mercado residencial onde o cliente só olha o número da proposta e não enxerga nada disso. Você é craque jogando num campo onde ninguém valoriza o que você faz de melhor. O problema não é teu preço, é a tua arena."

**O — Urgência (usa o número dele):**
> "E enquanto isso você tá com 30 orçamentos parados na mesa, gente que quer mas fica empurrando. Quanto de faturamento isso é represado? E quanto desses 30 fechariam se fossem cliente comercial, que decide por confiança e não por centavo?"

**S — Sell the Vacation (a arena certa):**
> "O cliente comercial é exatamente quem valoriza o que você faz. Um açougue, uma padaria, um supermercado, quando vai botar solar, ele puxa fundo: quantas instalações, quanto tempo de mercado, quem dá suporte. Porque pra ele, usina parada é prejuízo. Ele NÃO compra do picareta de preço de custo, ele compra de quem dá garantia. Esse é você. A prospecção comercial te leva pra esse cliente, onde teu serviço vira o motivo da compra, não um custo a mais."

**E — Reframe da objeção macro (o que faltou):**
> "Sobre o período ruim: no residencial sim, todo mundo estica pra frente. Mas no comercial é o contrário. Empresa que quer cortar conta de luz na crise é quem mais corre atrás, e justo ela valoriza quem dá garantia, porque não pode ficar com usina parada. A crise faz o comercial valorizar MAIS o teu diferencial, não menos."

**R — 3 perguntas antes do preço:**
1. "Você acredita que cliente comercial valoriza o teu serviço e sai da briga de preço?"
2. "Você acredita que funciona pra Cematech, com você e teus parceiros fechando?"
3. "Você acredita que a gente é quem coloca essa prospecção comercial de pé com você?"

**Preço:** ancora no ticket comercial e nos 30 orçamentos parados (poucas vendas comerciais de ticket alto já justificam). Vende no valor, não no desconto. Trava a decisão no dia (ele é o decisor).

---

## Documentos relacionados
- [[2026-06-17 — Matheus vs Denner (Termo Clima) (R1)]]
- [[2026-06-16 — Matheus vs BID (Matheus Garcia) (R1)]]
- [[2026-06-16 — Apanhado geral das R1 (padrões)]]
- [[Mentoria Nimoto — Índice]]

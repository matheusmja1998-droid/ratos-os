---
tipo: análise R1
data: 2026-05-04
vendedor: Gustavo Nimoto (Assim)
prospect: V4 Company (sócio coordenador de receita)
resultado: R2 pré-agendada (com sócios)
referência: true
tags: [mentoria, nimoto, r1, análise, referência]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Nimoto vendendo Assim para V4

R1 do próprio Nimoto vendendo seu SaaS/metodologia Assim pra um sócio da V4. Serve de **referência-mestre** pra calibrar análises das minhas R1/R2 nas próximas semanas — ele aplica quase todo o framework que ensinou em primeira pessoa.

> [!info] Como usar este doc
> Cada bloco abaixo amarra um trecho da R1 a um conceito da mentoria + onde está na aula original. No fim tem um mapa-resumo e a lista de **falhas dele no próprio framework** — esses são os pontos onde eu também costumo escorregar.

---

## Bloco 1 — Abertura

> "Eu sou o Gustavo, vou fazer essa call aqui com você. Hoje eu sou o fundador da Assim..."

**Conceito:** Apresentação curta + entrega da metodologia logo na abertura.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05] — *"Oi, tudo bem? Muito prazer estar aqui com vocês... deixa até te explicar um pouco sobre mim."*
**Por que funciona:** cumpre a regra "menos de 5 minutos" do CLOSER. Apresenta, sinaliza autoridade (fundador), entrega contexto e solta a metodologia.

---

> "A gente pega toda a parte de outbound e, ao invés de fazer esse outbound direto para uma reunião, a gente faz esse outbound direto para um evento."

**Conceito:** Big Idea / metodologia com nome próprio + Blue Ocean.
**Aulas:** [[Mentoria Nimoto — Fundamentos Comercial]] (Blue Ocean) + Imersão [193:14] *"Vende o destino, não a passagem."*
**Por que funciona:** ele não vende "outbound" (commodity). Renomeia o mecanismo — "outbound via evento" — e cria categoria nova. Mesmo conselho que ele deu pra LM na Call 1 [110:48].

---

> "Fomos os primeiros a começar isso aqui no Brasil, então a gente nadou ali no oceano azul..."

**Conceito:** Autoridade por pioneirismo + escassez de concorrência.
**Aula:** Call 1 [76:53] — *"Autoridade vem de coisas que comprovam externamente que isso daí é real."*

---

> "O empresário sempre tem aquela resistência quando a gente faz o outbound padrão... mas quando a gente convida para um evento..."

**Conceito:** Reciprocidade real (reconhecer a dor antes de oferecer solução).
**Aula:** Call 1 [48:38] — *"Reciprocidade é entender: cara, eu entendo como você se sente."*
**Por que funciona:** nomeia a dor que o Falante 2 já viveu antes mesmo do cara falar. Quando o Falante 2 confirma depois "errou muito no outbound", o gatilho já tinha sido plantado.

---

> "100, 200, 300 reuniões por mês para a gente com um time de cinco pessoas só prospectando."

**Conceito:** Prova social via números do meio do funil (não do resultado final).
**Aula:** Call 1 [67:47] — *"O maior prova social é o compromisso sério. Você abre o seu CRM e mostra: olha quantas reuniões a gente trouxe."*

---

## Bloco 2 — Transição pra diagnóstico

> "Eu gostaria de entender hoje como está a operação de vocês."

**Conceito:** Transição do CLOSER — apresentação → "preciso te fazer algumas perguntas".
**Aula:** R1/R2 [16:05]
**Detalhe:** chega armado com hipótese ("sei que vocês são mais focados em inbound") = pesquisa prévia (Imersão [73:30]).

---

## Bloco 3 — Diagnóstico

> Falante 2 (espontaneamente): *"75% inbound... canais incipientes... CAC elevado..."*

**Movimento:** o Falante 2 entrega o problema de bandeja. Nimoto está em modo escuta.
**Aula:** Call 1 [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real do Falante 2:** "tô sob pressão, preciso provar pros sócios que outbound funciona."

---

> Nimoto: "A gente também pede indicação na própria prospecção..."

**Conceito:** Conectar dor existente do cliente à própria solução, sem bater de frente.
**Aula:** R1/R2 [21:49] — *"Junta a gente com a solução."*

---

> "Não tem nenhum canal alternativo que você busca clientes sem necessariamente pagar por eles?"

**Conceito:** Pergunta de revisão da dor + plantio de framing ("pagar por eles" = CAC).
**Aula:** R1/R2 [9:54] — primeira parte da tríade.

---

## Bloco 4 — Aprofundando o diagnóstico

> "Como que é a relação de time?" → "Esse SDR de outbound, qual processo usa hoje?"

**Conceito:** Quem pergunta domina.
**Aula:** Imersão [116:46] — *"Quem faz as perguntas está no controle da conversa."*

---

> Falante 2: *"Processo foi pro espaço... planilha... só vai no esforço... 700 reais/lead, 11k CAC, corda no pescoço."*

**Movimento:** lead entrega 3 dores em sequência sem pressão. Os "225 caminhos" da R1/R2 [3:53] colapsam num só. Nimoto agora sabe exatamente em qual trilha andar.

---

> Nimoto: **"700 reais? Qual a conversão?"** ... **"11 mil CAC?"**

**Conceito:** Repetir o número em tom de questionamento = Label + revisão da dor.
**Aula:** R1/R2 [22:17]
**Por que funciona:** ele não diz "11k é caro". Repete e o cliente responde sozinho *"Sim. Estressa bastante a margem."* — **cliente quebrou a própria objeção sobre o status quo** (Imersão [116:46]).

---

> Falante 2: *"Operamos com a corda no pescoço."*

Cliente verbaliza a dor no nível emocional sem o Nimoto precisar bater. Imersão [322:00] — *"Eu quero ver meu cliente triste."* O cliente bateu por ele. Sinal verde pra apresentar a solução.

---

## Bloco 5 — Apresentação (Sell the Destination)

> "Quando a gente começou a fazer outbound, a gente tinha esse problema de script, rejeição..."

**Conceito:** Terceira parte da tríade — *"Como eu resolvo isso?"* + storytelling do "antes/depois" da própria empresa.
**Aula:** R1/R2 [11:01]
**Por que funciona:** Nimoto se posiciona como alguém que passou pela mesma dor. Reciprocidade real + autoridade adquirida.

---

> "10-15 preenchimentos/dia por BDR. 70% de conversão pós-evento."

**Conceito:** Probabilidade de Sucesso da Equação do Valor.
**Aula:** R1/R2 [37:15] — *"A maior parte da R2 é você falando sobre probabilidade de percepção de sucesso."*

---

> "A gente faz muito mais. Custo de aquisição é o time, não mídia."

**Conceito:** Ataque ao denominador da Equação do Valor (Esforço/Sacrifício).
**Aula:** Imersão [208:30] — *"Quanto menos esforço o seu cliente tiver, mais caro você cobra."*

---

## Bloco 6 — Cliente verbaliza o destino

> Falante 2: *"Meu objetivo é chegar em 50% inbound e 50% outbound."*

**Movimento ouro:** cliente diz qual é o destino dele. Daqui pra frente qualquer apresentação só precisa amarrar "nosso modelo te leva a 50/50".
**Aula:** R1/R2 [30:37] — *"A gente sempre vende o destino final."*

---

> "Outbound bem estruturado paga a empresa. Inbound vira lucro."

**Conceito:** Frase-bordão que o cliente vai usar pra vender pros sócios.
**Aula:** Call 1 [47:29] — *"Você precisa bater numa barreira lógica para que ele mesmo justifique a compra."*

---

## Bloco 7 — Urgência e visão compartilhada

> Falante 2: *"Já é urgente."*

Cliente verbaliza urgência sozinho. Escassez real, dele, não do produto.
**Aula:** Imersão [157:50] *"Nada gera mais urgência do que esperança."* + Call 1 [88:50] *"Trago a escassez que é real dele e não do meu produto."*

---

> "Então o modelo SERIA: SDR prospecta → convida pra evento → 20/dia/SDR..."

**Conceito:** Visão compartilhada + Viés de Certeza.
**Aula:** Call 1 [90:00] — *"Já apresento a reunião falando: quando a gente fizer isso, a consequência é isso."* + Imersão [94:30].

---

## Bloco 8 — Fechamento

> "Vou montar um projeto personalizado. Marca R2. Pode ser amanhã 13h?"

**Aula:** R1/R2 [13:18] — encerramento clássico R1.
**Por que funciona:** data específica (não "essa semana"). Compromisso emocional via Cialdini.

---

> "Posso contar com uma resposta na próxima reunião?"

**Aula:** Call 1 [64:43] — *"Quando alguém assume emocionalmente, ela tende a cumprir."*
**Por que funciona:** força o cliente a dizer "pode contar" — compromisso público.

---

## Mapa-resumo

| Movimento do Nimoto | Conceito | Aula |
|---|---|---|
| Apresentação curta + metodologia com nome | CLOSER abertura | R1/R2 [16:05] |
| "Outbound via evento" | Big Idea + Blue Ocean | Fundamentos |
| "Primeiros do Brasil" | Autoridade por pioneirismo | Call 1 [76:53] |
| Reconhece dor antes do cliente falar | Reciprocidade real | Call 1 [48:38] |
| "100-300 reuniões/mês com 5 pessoas" | Prova social do meio do funil | Call 1 [67:47] |
| Repete "11k CAC?" em tom de espanto | Label + revisão da dor | R1/R2 [22:17] |
| Cliente diz "corda no pescoço" sozinho | Cliente quebra própria objeção | Imersão [116:46] |
| "Antes a gente também tinha esse problema" | Tríade + reciprocidade | R1/R2 [11:01] |
| "70% pós-evento, sem mídia" | Probabilidade × Esforço | R1/R2 [37:15] + Imersão [208:30] |
| "Outbound paga, inbound lucra" | Reframe lógico p/ sócios | Call 1 [47:29] |
| "20/dia/SDR..." | Visão compartilhada + Viés de Certeza | Call 1 [90:00] |
| R2 marcada com data específica | Encerramento CLOSER | R1/R2 [13:18] |
| "Posso contar com uma resposta?" | Compromisso emocional | Call 1 [64:43] |

---

## ⚠️ Onde o Nimoto falhou no próprio framework

**1. Não isolou a decisão dos sócios.** Quando o Falante 2 disse "quero trazer meus sócios", deveria ter perguntado: *"Se a proposta fizer sentido pra todos vocês, decidem na própria R2?"* — exatamente o que ele cobrou da LM na Call 1 [98:50]. Sem isso, entra na R2 sem saber se vai virar R3.

**2. Não rotulou o problema com nome próprio.** Em momento nenhum soltou: *"Então seu problema é CAC alto + dependência única do inbound + processo no esforço — vou chamar isso de 'corda no pescoço comercial'."* Faltou o **L do CLOSER** (R1/R2 [9:30]). Funcionou porque o lead estava maduro, mas em lead frio essa ausência custa caro.

**3. Não fez a tríade de ofertas completa.** Perguntou "já tentou?" mas não perguntou "por que falhou? por quanto tempo? quanto perdeu?" — perguntas que enfatizam a dor (R1/R2 [9:54]). Pulou direto pra solução porque o cliente entregou tudo de bandeja.

---

## Aplicação na minha próxima R1/R2

- [ ] **Sempre rotular** o problema com nome próprio antes de apresentar solução
- [ ] **Tríade completa**: já tentou? por que falhou? quanto perdeu? quanto tempo? como seria sem isso?
- [ ] **Isolar decisão** quando aparecerem sócios: "se fizer sentido pra todos, decidem na R2?"
- [ ] **Repetir números do cliente** em tom de espanto pra ele quebrar a própria objeção
- [ ] **Fechar com compromisso explícito**: "posso contar com uma resposta?"

---
tipo: apanhado geral R1
data: 2026-06-16
vendedor: Matheus Jardim
nicho: energia solar (prospecção LM)
base: R1 do Ladislau, Orion Solar e solar do Matheus Garcia (+ padrões cruzados com Marcos e Cafu)
tags: [mentoria, nimoto, r1, apanhado, padrões]
---

# Apanhado geral das R1 de prospecção (LM solar)

Análise ampla, não call por call. Olhei os R1 de prospecção do dia (Ladislau, Orion Solar, solar do Matheus Garcia) e cruzei com os padrões que já tinha visto no Marcos e no Cafu. A nota 155446854 não tinha transcrição (conexão curta), ficou de fora. O objetivo é mostrar o que tu acerta SEMPRE e o que tu erra SEMPRE, pra atacar o padrão, não o caso isolado.

> [!info] Resumo de uma linha
> Tu abre muito bem (clareza + posicionamento) e conecta dor com solução com uma lógica que convence. Mas tu não rotula, não aprofunda a dor, fala demais na R1 e fecha a R2 frouxo. O teto não é a abertura, é o meio e o fim.

---

## ✅ O que tu acerta (padrões de força)

**1. Pergunta de clareza na cara, logo cedo.**
Em quase todos tu abre com "qual o motivo de você estar aqui hoje, qual a tua maior dificuldade na área comercial?". No Orion e no Matheus Garcia isso veio limpo. É o C do CLOSER bem feito, e ancora a conversa no comercial antes de qualquer pitch.

**2. Posicionamento Blue Ocean forte e repetível.**
"A gente é 100% comercial, prospecção ativa, não é tráfego, não é Instagram, não é marketing." Isso te diferencia na hora de tudo que o cliente já se queimou. Bate igual nos cinco.

**3. A lógica do cliente comercial é matadora.**
"Cliente comercial tem mais crédito (menos reprovação de financiamento), menos concorrência (o picareta não chega nele) e ticket 3 a 6x maior." No Matheus Garcia isso encaixou perfeito nas dores que ele mesmo deu (crédito negado + guerra de preço). É teu melhor argumento e tu manda bem nele sempre.

**4. "Tráfego pago 2.0" é uma metáfora que vende.**
"Em vez de mandar um link pro teu WhatsApp pra você correr atrás, o pré-vendedor te entrega a visita já marcada." Explica o mecanismo em uma frase. Excelente.

**5. Prova viva embutida.**
"Foi a Amanda, nossa SDR, que te ligou e marcou essa reunião." O próprio agendamento vira demonstração de que funciona. Usa isso sempre, é ótimo.

**6. Escuta e deixa o cliente abrir.**
Com cara falante (Cafu, o Fernando do Orion) tu segura e deixa fluir. Eles te entregam dor, história e objeção de bandeja. Boa leitura de rapport.

**7. Não força encaixe quando não tem.**
No Cafu tu desqualificou o que não servia (IA e SDR pro solar dele) com honestidade. Isso constrói confiança e te diferencia de quem empurra qualquer coisa. Bom instinto consultivo.

---

## ⚠️ O que tu erra (padrões recorrentes)

**1. Tu não ROTULA. O erro nº1, em todos.**
Tu junta a dor e fecha com um "seria isso, né?" genérico ("o problema é trazer mais vendas" / "é formar equipe" / "é crédito e guerra de preço"). Nunca devolve a dor com as PALAVRAS do cliente nem dá nome a ela. O Nimoto bate nisso direto: rotular e fazer o cliente confirmar em voz alta. Sem isso, tu segue a reunião sem travar a trilha, e o cliente não sente que tu entendeu de verdade. (R1/R2 [21:49] e [24:24])

**2. Tríade pela metade, a dor nunca dói.**
Tu pergunta "o que vocês já tentaram?" (a primeira parte, boa). Mas nunca aprofunda: "quanto isso já te custou? quanto deixou de faturar? há quanto tempo tá assim?". A dor fica racional, nunca vira urgência. O cliente precisa SENTIR o buraco antes de tu mostrar a ponte. (R1/R2 [9:54])

**3. Tu fala demais e pitcha a solução inteira na R1.**
Esse é o mais caro. No Orion e no Matheus Garcia tu despejou o modelo completo, o teste de fogo, o passo a passo do SDR e até faixa de preço (R$1.500-2.100) na R1. Isso é R2. R1 é diagnóstico. Ao entregar tudo, tu esvazia a R2, gasta munição e dá pro cliente material pra fazer sozinho ou comparar. Segura o pitch. (R1/R2 [13:18])

**4. Consultoria de graça.**
A ideia do evento da Copa (Orion e Cafu) e a estratégia de Instagram (Cafu) foram entregues com passo a passo executável. Plantar a visão é gancho de R2; entregar o how-to é dar o ouro. Mostra que sabe, não ensina a fazer. (Call 1 [110:48])

**5. R2 marcada frouxa, sem data firme.**
Padrão feio: "me manda os horários que batem", "deixa pré-marcado quarta ou sexta que eu confirmo no grupo". Isso joga o controle pro cliente e enfraquece o compromisso. No Ladislau tu travou 10h na hora, e foi o melhor fecho. Faz isso sempre: data e hora cravadas antes de desligar. (R1/R2 [13:18])

**6. Tu não isola o decisor.**
No Matheus Garcia o pai (dono) não tava na call. No Cafu, a esposa. Tu identifica que falta o decisor, mas não trava "se fizer sentido pra vocês, vocês decidem na próxima?". Sem isso, a R2 vira R3.

**7. Tu concorda com a objeção macro em vez de reframar.**
Quando vem o "crise, governo, ninguém investe" (Matheus Garcia, Cafu), tu acompanha e até puxa papo de política. Empatia demais, reframe de menos. Tu tem o contra na mão e não usa: o cliente comercial é o que MENOS sente crise (tem crédito, não compara preço). Concorda com a emoção, mas vira o argumento. Senão tu valida o motivo do cliente não fechar. (Call 1 [122:00])

**8. Tu deixa o cliente impor o frame.**
Cafu ("tenho 3 perguntas: como, quanto, retorno") e em geral, quando o cliente pede preço/retorno cedo, tu responde na hora. Responde curto e RETOMA com a tua pergunta. Quem pergunta conduz. (Imersão [116:46])

---

## As 3 correções que mais movem o ponteiro

Se for pra mudar só três coisas nas próximas R1, é essas, na ordem:

1. **Rotular sempre.** Depois que o cliente despejar a dor, devolve com as palavras dele e dá nome: "então teu problema não é X, é Y, certo?" e espera ele confirmar. Trava a trilha antes de seguir.

2. **Calar o pitch na R1.** R1 é pra diagnosticar e marcar R2. Nada de modelo completo, passo a passo e preço. No máximo planta a visão. O detalhe e o preço são o ápice da R2, não da R1.

3. **Travar a R2 com data e hora na hora, e isolar o decisor.** "Quinta às 10h, e traz teu pai/sócio/esposa. Se fizer sentido pra vocês, vocês decidem ali mesmo?" Para de deixar no "me manda os horários".

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Ladislau (R1)]]
- [[2026-06-09 — Matheus vs Marcos (R1)]]
- [[2026-06-16 — Matheus vs Cafu (R1)]]
- [[Mentoria Nimoto — Índice]]

---
tipo: análise R1
data: 2026-06-17
vendedor: Matheus Jardim
prospect: Denner (Termo Clima Energia Solar e Climatização, Itajaí SC)
nicho: climatização + energia solar
resultado: R2 marcada para 19/06 às 14h
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Matheus vendendo para Denner (Termo Clima)

R1 de 14 minutos com o Denner, dono da Termo Clima em Itajaí (SC). Carro-chefe é climatização (ar-condicionado), muito sazonal (verão bomba, inverno morre). Quer reentrar no solar pra estabilizar o caixa. Já esteve no solar até início de 2023, saiu quando a legislação mudou (e a tática "compra agora antes de mudar" deu tiro no pé). Começou tráfego pago faz menos de um mês, com agência que não curte, só leads curiosos, zero venda. R2 marcada pra sexta 19/06 às 14h.

> [!info] Resultado e diagnóstico geral
> Esse foi um dos teus R1 mais disciplinados. Tu fez o C, cobriu bem os canais no diagnóstico, plantou a solução como complemento (não substituto) do tráfego e, principalmente, NÃO dumpou o pitch como nos outros. Marcou a R2 com data e hora. Os erros: chamou o cara pelo nome errado a call inteira (Daniel/Nenê em vez de Denner), não rotulou a dor com nome próprio, e não enfatizou a perda. Mas no geral, R1 limpa.

---

## Bloco 1 — Abertura e clareza

> "o intuito dessa reunião é conhecer mais de você, do seu negócio, seus desafios, principalmente na área de vendas. Qual seu maior desafio hoje?" (call [01:36])

**Conceito:** C do CLOSER feito direto. Pergunta de clareza ancorada em vendas.
**Aula:** R1/R2 [16:05].
**Por que funciona:** abriu o jogo cedo, sem enrolação. Padrão que tu vem acertando.

---

> Denner: "climatização é muito sazonal, no verão tem muito serviço e no inverno não tem nada... minha ideia é partir pro nicho que eu já aprendi, a energia solar... pra segurar as despesas" (call [02:01])

**Conceito:** o cliente entrega a dor de fundo (sazonalidade do AC) e o destino real (estabilizar o caixa no inverno).
**Aula:** R1/R2 [30:37] — esse é o destino emocional a vender na R2: segurar as despesas no inverno.

---

## Bloco 2 — Diagnóstico (boa cobertura)

> "quanto tempo que você parou?" (call [03:00]) ... "você já conseguiu fechar algum cliente depois disso?" (call [04:10])

**Conceito:** perguntas de diagnóstico encadeadas pra mapear histórico e situação atual.
**Aula:** Imersão [116:46] — quem pergunta conduz.

---

> Denner: "não faz nem um mês que comecei com o tráfego pago, ainda não tive retorno, só clientes curiosos... tô com uma agência que não tô gostando muito" (call [04:15])

**Conceito:** confissão de número (zero venda) + insatisfação com a agência atual. Abre a porta pra posicionar a prospecção como o que realmente vende.
**Aula:** R1/R2 [40:32] — guardar pra R2 (o tráfego não fecha, a prospecção fecha).

---

> "então o maior problema hoje é buscar as primeiras vendas desse retorno à energia solar, seria isso ou teria mais alguma coisa?" (call [05:12])

**Conceito:** tentativa de Label, mas descritiva ("buscar as primeiras vendas"), sem nome próprio nem as palavras do cliente.
**Aula:** R1/R2 [24:24] — *"resumir tudo o que ele está falando em um nome só."*
**Por que falhou parcial:** o cliente confirmou, mas o rótulo afiado seria: *"você quer reentrar no solar mas hoje não tem NENHUM canal que gera venda: tráfego só traz curioso, indicação você não tem, e bater porta não é teu perfil."* Mais preciso e mais dolorido.

---

> "você já tentou indicação?" → "conhecidos, amigos, restaurante, bar?" → "já tentou o PAP, porta-a-porta, ligar pras empresas?" (call [07:03] a [09:00])

**Conceito:** varredura dos canais de aquisição. Boa cobertura, fecha as saídas uma a uma.
**Aula:** Imersão [116:46].

---

> Denner: "indicação eu não tenho, os clientes são tudo longe (Floripa, Criciúma)... vender pra conhecido é mais difícil, o cara acha que você tá passando a perna... PAP não é meu perfil, não consigo chegar e oferecer" (call [07:12] a [09:14])

**Conceito:** o cliente desqualifica sozinho TODOS os canais que dependem dele. A auto-desqualificação do "não é meu perfil" é a fresta de ouro pro SDR (alguém prospecta por ele).
**Aula:** Call 1 [47:29] — *"barreira lógica para que ele mesmo justifique a compra."*
**Por que importa:** ele mesmo provou que precisa de alguém fazendo a prospecção. Munição de ouro pra R2 (ver falhas, foi pouco explorada).

---

## Bloco 3 — Solução plantada e transição

> "o que a gente vê é falta de volume de venda... além do tráfego, dá pra colocar a prospecção, que gera demanda de cliente comercial (açougue, padaria, academia, ticket 30k+) contra o residencial de 10-20k... e não exclui o tráfego, trabalha os dois em conjunto" (call [09:46])

**Conceito:** conecta a dor (sem volume, ticket baixo) à solução, com Blue Ocean (cliente comercial) e framing COMPLEMENTAR (não pede pra ele largar o tráfego que acabou de começar).
**Aula:** Fundamentos (Blue Ocean) + R1/R2 [30:37] (destino).
**Por que funciona:** o framing "soma, não substitui" tira a fricção de quem já investiu no tráfego. Bom.

---

> "queria marcar, sentar com o Valentino, pensar com calma e te trazer uma formatação sobre essa prospecção" (call [09:46]) ... R2 travada sexta 14h (call [13:10])

**Conceito:** transição correta pra R2 + marcação com data e hora.
**Aula:** R1/R2 [13:18].
**Por que funciona:** travou o horário (depois de um juggling), não deixou no "me manda os horários". Melhor que Orion/Garcia.

---

> Denner: "qual é a pauta? pra eu dar uma pesquisada" → Matheus: "projeto de prospecção ativa, como gerar pelo menos 20 visitas comerciais por mês, de cada 10 fecha 1, então umas 2 vendas por mês" (call [13:34] a [13:41])

**Conceito:** dá a projeção (destino com número) como pauta, mas NÃO entrega o how (teste de fogo, SDR, preço). Teaser correto.
**Aula:** R1/R2 [37:15] — probabilidade de sucesso. Aqui plantou o resultado sem queimar o mecanismo. Disciplina boa.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Qual seu maior desafio hoje?" | C do CLOSER feito | R1/R2 [16:05] |
| Cliente: "climatização morre no inverno, quero solar pra segurar despesa" | Destino emocional entregue | R1/R2 [30:37] |
| "Quanto tempo parou? Já fechou cliente?" | Diagnóstico encadeado | Imersão [116:46] |
| "Não faz 1 mês de tráfego, só curioso, agência ruim" | Número de dor + objeção plantada | R1/R2 [40:32] |
| "O problema é buscar as primeiras vendas, né?" | Label descritivo (não rotulado) | R1/R2 [24:24] |
| Cliente: "PAP não é meu perfil, não consigo" | Auto-desqualificação = fresta do SDR | Call 1 [47:29] |
| "Prospecção comercial, ticket 30k+, soma com o tráfego" | Solução + Blue Ocean + complementar | R1/R2 [30:37] |
| R2 travada sexta 14h | Encerramento CLOSER | R1/R2 [13:18] |
| "A pauta é 20 visitas/mês, 2 vendas" | Destino com número (teaser) | R1/R2 [37:15] |

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Chamou o cara pelo nome errado a call inteira.** O nome é Denner, e tu chamou de "Daniel" e "Nenê" várias vezes. Isso é furo de rapport sério, mostra que tu não tava dialed in. Confere o nome antes de entrar e usa certo. Erro fácil de zerar.

**2. Não rotulou com nome próprio.** O Label ficou em "buscar as primeiras vendas" (descritivo). O rótulo afiado, com as palavras dele, era: "você quer voltar pro solar mas não tem nenhum canal que gera venda: tráfego só traz curioso, indicação você não tem, e bater porta não é teu perfil." R1/R2 [21:49] e [24:24].

**3. Tríade sem enfatização de perda.** Cobriu bem o "já tentou?" em todos os canais, mas não doeu: "quanto a climatização cai no inverno? quanto você precisa do solar pra cobrir esse buraco? quanto te custou o tiro no pé de 2023?" A dor ficou racional. R1/R2 [9:54].

**4. Não cravou a auto-desqualificação como wedge.** Quando ele disse "PAP não é meu perfil", era pra fincar: "é exatamente por isso que a gente traz alguém pra prospectar por você, você não precisa ter esse perfil." Passou batido. Call 1 [47:29].

---

## 🎯 Destino pra R2 (hoje, 19/06 às 14h)

Cliente cash-tight (baixa estação do AC), reativo (queimado com o tiro no pé de 2023), já pagando uma agência que não curte. Não empilha custo sem ver que PAGA. Trava na prospecção comercial.

**C — Recap (e usa o nome certo: DENNER):**
> "Denner, desde quarta o teu objetivo continua o mesmo: voltar pro solar pra segurar o caixa no inverno, quando a climatização cai. Continua sendo isso?"

**L — Crava o rótulo que faltou:**
> "Teu problema não é falta de esforço, é que hoje você não tem NENHUM canal que gera venda de verdade. O tráfego só traz curioso, indicação você não tem porque os clientes são tudo longe, e bater porta não é teu perfil. Você tá remando sem canal que fecha."

**O — Urgência presente (a perda):**
> "E o inverno já tá aí, a climatização desacelerando. Quanto você precisa fechar no solar por mês pra segurar as despesas nessa baixa estação?"
(faz ele dizer o número)

**S — Sell the Vacation (o destino que ele mesmo deu):**
Destino: "Em vez de esperar o tráfego amadurecer trazendo curioso, ter visita comercial qualificada toda semana, ticket 30k+, gerando umas 2 vendas/mês de receita constante pra atravessar o inverno, sem você ter que sair batendo porta."
Mecanismo (sem o how-to): "uma estrutura de prospecção ativa que liga e marca a visita comercial pronta pra você fechar."

**E — Quebra de objeção (as certas):**
- Caixa apertado / "já pago agência": "isso não é trocar a agência nem empilhar custo perdido. O tráfego dela traz curioso residencial; a prospecção traz visita comercial de ticket alto, que é o que efetivamente fecha. É o canal que GERA caixa enquanto o tráfego amadurece."
- Medo (tiro no pé de 2023): risco compartilhado / entrada enxuta. Ele não pode tomar outra rasteira, então a estrutura de pagamento tem que dividir o risco.
- "Não é meu perfil": "é exatamente por isso, você não precisa prospectar, a gente traz quem faz isso por você."

**R — Reinforce (3 perguntas antes do preço):**
1. "Você acredita que prospecção de cliente comercial gera visita qualificada?"
2. "Você acredita que funciona pra TUA realidade, voltando pro solar agora?"
3. "Você acredita que a gente é quem coloca isso de pé com você?"

**Preço:** ancora no retorno (2 vendas comerciais de R$30k = R$60k que ele não tem hoje), entrada enxuta com risco dividido (ele tá cash-tight e gun-shy). Trava a decisão no dia (ele é o decisor único).

**Cuidados:** usa o nome certo (Denner). Não empilha custo sem mostrar que paga. Não dumpa mecanismo, vende o destino (segurar o inverno) e o resultado (visita comercial que fecha).

---

## Documentos relacionados
- [[2026-06-16 — Apanhado geral das R1 (padrões)]]
- [[2026-06-16 — Matheus vs Cafu (R1)]]
- [[Mentoria Nimoto — Índice]]

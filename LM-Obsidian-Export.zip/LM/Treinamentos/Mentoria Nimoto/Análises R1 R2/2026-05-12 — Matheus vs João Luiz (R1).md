---
tipo: análise R1
data: 2026-05-12
vendedor: Matheus Jardim
prospect: João Luiz Doria
empresa: integradora solar / consultoria energia (Londrina)
nicho: energia solar + consultoria de eficiência energética grupo A
produto-alvo: Ignição Comercial entrando pela porta do prospector solo
camada-entrada: prospector solo (menor unidade vendável do Ignição)
resultado: R2 acordada por mensagem — "vou amadurecer e te mando mensagem amanhã"
tags: [mentoria, nimoto, r1, análise, lm, solar]
escopo: R1 = C + L + O (só)
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]]"
---

# Análise — Matheus vendendo para João Luiz (Doria Solar / Londrina)

R1 de 59 minutos. João Luiz é integradora solar de Londrina em transição pra consultoria de energia grupo A. Acabou de demitir 5 pessoas em 2 meses, incluindo o gerente comercial. Tá com pouco volume no funil, "desmotivado", e quer apostar tudo em "1 contrato grande em 60 dias" em vez de reconstruir equipe.

**Produto-alvo:** Ignição Comercial. **Camada de entrada planejada:** prospector solo — a menor unidade vendável do Ignição, fricção psicológica mínima pro João. A intenção do Matheus era entrar pela porta de entrada (1 pessoa só prospectando) e escalar pra Ignição completa nas fases seguintes. Por isso ignorou deliberadamente os termos do João ligados a equipe inteira / gerente / recontratação — eles puxavam pra camada grande do produto, fricção alta, venda morre.

> [!info] Resultado e diagnóstico geral
> R1 conduzida no estilo "conversa lenta com clarificação tardia". O Matheus deixou o João derramar contexto por ~45 minutos antes de clarificar a dor que interessava ("precisa de mais vendas, não sabe como chegar"). Quando clarificou, fez Label em movimento e plantou visão do **prospector solo como porta de entrada do Ignição** com destino reframado (3-4 dias vs 60 dias do João). Fechou em "vou amadurecer, te mando mensagem amanhã" — não é R2 com data, mas tem follow-up pré-acordado.

---

## Bloco 1 — Abertura (00:00–02:20)

> Tino: "Ô, João, é o seguinte, hoje a Cal vai ser mais voltada pro comercial de vocês. E eu não vou conseguir ficar hoje nessa Cal, infelizmente."

**Conceito:** Saída do sócio na abertura.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [76:53] — *"Autoridade vem de coisas que comprovam externamente."*
**Por que falhou:** sócio sai na primeira frase. Prospect lê "se um dos dois não acha importante, talvez também não precise estar". Se o Tino tinha conflito, devia ter avisado antes e o Matheus reabrir o convite sozinho com outro framing. Pequeno desgaste de autoridade.

---

> Tino: "Eu sei que você queria que eu ficasse, tá? Ô, Valentino, tá vacilando, cara."

**Conceito:** Auto-deprecação que enfraquece ainda mais a autoridade.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [76:53]
**Por que falhou:** "tá vacilando" reforça que o Tino sabe que tá errado. O João absorve isso. Início da reunião com a operação se desculpando.

---

> Matheus: "E aí, João, como é que foi da última semana que a gente conversou para essa? Você colocou alguma coisa de IA para rodar aí?"

**Conceito:** Small talk de continuidade sobre tema da call anterior.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] — *"A primeira coisa numa reunião não é se apresentar. É descobrir por que aquele cliente aceitou se reunir."*
**Por que falhou:** abriu com pergunta sobre IA em vez de fazer o C explícito ("por que tu topou voltar pra essa conversa?"). Sem C definido na abertura, a reunião vira bate-papo e a clarificação só vem no minuto 49.

---

> Matheus: "E, João, a gente, nesse bate-papo aqui, a gente vai trazer mais para o lado ali do comercial."

**Conceito:** Sinalização do tema sem apresentar metodologia da LM.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05] — *"Eu vou me apresentar, vou colocar a metodologia, vou falar: pra eu fazer um trabalho personalizado preciso te fazer algumas perguntas."*
**Por que falhou:** pulou apresentação da LM e da Ignição Comercial. Foi direto pra tema. Sem framing inicial, R1 fica sem peso de venda.

---

> Matheus: "E hoje, João, eu queria saber um pouco mais das suas dificuldades relacionadas ali pra parte do comercial, voltar na venda, time de venda, aquisição de leads, aumento de faturamento, como que tá aí hoje?"

**Conceito:** Empilhamento de 4 temas numa pergunta só.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05] — *"Qual está sendo a maior dificuldade — captação? fechamento? encontrar bons leads?"*
**Por que falhou:** Nimoto isola DENTRO de uma metodologia apresentada. Aqui, sem metodologia, vira "me fala tudo que tá ruim". O João respondeu derramando 25 minutos sem rumo.

---

## Bloco 2 — João derrama contexto de pivot (02:20–10:00)

> João: "como eu tô mudando, fazendo essa transição... eu tô migrando mais pra consultoria de energia, voltado pro grupo A... é uma cebola, né? Você tem que ir tirando camada por camada."

**Movimento do prospect:** confessou pivot estratégico. Momento de vulnerabilidade.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real:** "tô trocando avião em pleno voo, sozinho, sem rede". Material pra contextualizar, mas não pra rotular agora (a dor-alvo ainda não apareceu).

---

> João: "olha, é basicamente isso que a gente faz. Clica no meu negócio, liga para ligar direto, atendeu, beleza, não atendeu, vai embora, liga para próximo, vai fazendo volume assim."

**Movimento do prospect:** confessou processo de prospecção sem cadência.
**Conceito:** Material observado, guardado pra contextualizar a oferta de SDR depois.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [21:49]
**Decisão estratégica:** ao invés de rotular agora ("prospecção sem cadência" é diagnóstico técnico), tu deixou rolar pra construir a dor mais ampla. Funcionou parcialmente — mais à frente esse contexto vira matéria-prima pro plantio do SDR.

---

> Matheus: "Não tem gente com fluxo de cadência para estar voltando essas empresas e por aí vai, não?"

**Conceito:** Pergunta operacional de diagnóstico.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [116:46] — *"Quem faz as perguntas está no controle."*
**Por que funcionou parcialmente:** detectou a falha estrutural. Mas formato retórico ("não, não?") entrega resposta. Ganharia força aberta: *"E o follow-up com quem não atende, como funciona?"*.

---

## Bloco 3 — Demissões expostas (10:17–14:00)

> João: "Ah, Matheus, tô com um problema de efetivo, cara. Tá complicado. Tive que desligar mais uma semana passada agora."

**Movimento do prospect:** primeira menção de demissão.
**Conceito:** Janela tática, mas...
**Decisão estratégica de camada:** o Matheus NÃO rotulou "demissão" nem fez tríade aqui de propósito. **Rotular essa dor puxaria pra camada errada do Ignição** (Ignição completo com recontratação de equipe inteira). A camada de entrada planejada era prospector solo — 1 pessoa rampada em 3-4 dias, fricção mínima. Por isso passou direto. Decisão coerente.

---

> João: "Formar um já é difícil, sabe? Imagina formar ele como um líder para formar mais."

**Movimento do prospect:** verbalizou cansaço de formar gente.
**Decisão estratégica de camada:** segundo termo que puxa pra Ignição completa (estruturação de equipe). **NÃO rotulado de propósito** porque a camada de entrada é prospector solo — não pede formar time. Termo guardado pra ressuscitar na escalada do Ignição (fase de treinamento de vendedores).

---

> João: "É muita energia e uma aposta muito alta e cara, né? Nada mais cara do que se contratar errado."

**Movimento do prospect:** rotulou sozinho — "nada mais caro do que contratar errado".
**Decisão estratégica de camada:** terceiro termo que puxa pra debate sobre processo seletivo de vendedor — camada maior do Ignição. **Ignorado por design.** O Matheus respondeu "total, total" e seguiu. Termo guardado pra ressuscitar na R2 como reframe: *"você não vai precisar contratar errado de novo — começa trazendo só UM prospector rampado em 3-4 dias, e quando ele tiver gerando funil a gente entra na fase de recrutamento de vendedores com método pra não cair nesse buraco"*.

---

## Bloco 4 — Aula de mercado do João (14:15–17:53)

> João: "está mais embaixo do buraco, o buraco está muito mais embaixo do que a gente imaginava."

**Movimento do prospect:** rotulação espontânea da própria situação geral.
**Conceito:** Termo guardado pra eventual reframe na R2.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24]
**Por que não foi ancorado:** termo emocional ainda genérico ("buraco" pode ser margem, mercado, equipe, faturamento). Ancorar aqui sem saber qual buraco interessa rotular pro produto-alvo seria precipitado.

---

> João: [4 minutos sobre Coppel, Sérgio Moro, ICMS, ANEEL, banco de capacitores]

**Movimento do prospect:** aula técnica de mercado. Tomou controle.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [116:46]
**Por que falhou:** deixou rolar 4 minutos sem cortar. Era pra ter sido: *"Faz sentido, João. Voltando pro teu negócio — esse cenário regulatório te empurrou pro industrial. Mas tua estrutura de prospecção tá pronta pra esse cliente novo?"* — corte cirúrgico de volta pro diagnóstico.

---

## Bloco 5 — Tentativa de retomar (17:53–24:10)

> Matheus: "Mas o volume industrial, ele é menor do que o volume de outros comércios, comercial normal, ou a linha B que você fala ali. Como que você vê isso? Porque a gente tem um problema, uma questão ali, problema ali de quantidade ociosa para você atender, para você conseguir vender."

**Conceito:** Primeira pergunta da reunião que cutuca a lógica do João.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [47:29] — *"Bater numa barreira lógica para que ele mesmo justifique a compra."*
**Por que funcionou parcialmente:** boa intenção (apontar furo lógico do pivot pro industrial), mas misturou afirmação com pergunta, dando saída lógica pro João defender o pivot.

---

> João: "essa semana perdemos dois orçamentos de residencial, nosso orçamento estava em R$17.200, o fechou por R$16.800."

**Movimento do prospect:** dor numérica recente — perdeu 2 vendas semana passada por R$400.
**Conceito:** Material que ENCAIXA no produto-alvo (SDR) — porque mostra que ele perde por falta de fluxo qualificado, não por preço.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [22:17] — *"Repetir o número em tom de questionamento."*
**Por que poderia ter sido capturado:** essa janela era boa pra tríade leve sem cair em "estruturação de equipe". *"R$400, João? E no mês passado, quantas vendas tu acha que tu perdeu nessa mesma diferença?"* — Label da dor "perda por margem apertada porque o funil não tem lead qualificado". Levaria pro SDR sem precisar mexer em contratação.

---

> João: "então prefiro trabalhar menos em termos de volume de clientes e tal, em um ticket mais alto e em um ambiente muito menos competitivo."

**Movimento do prospect:** destino verbalizado. Ouro pra R2.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [30:37]
**Por que poderia ter sido ancorado:** essa frase é o destino que combina perfeitamente com SDR (ticket maior, menos competitivo = industrial = precisa de prospecção qualificada). Era pra ter sido: *"Então hoje teu objetivo é trabalhar menos volume com ticket maior em ambiente menos competitivo. Posso anotar isso como tua meta nos próximos 60 dias?"* — guardaria pra abrir R2.

---

## Bloco 6 — Plantio inicial da visão "convite" (24:10–30:39)

> Matheus: "pelo exemplo de abordagem que você deu ali, é uma abordagem meio que já procurando na venda desde o início... Falando de experiência própria de prospecção, quando a gente faz uma abordagem direta como essa, os nossos resultados era significativamente muito baixo, quase nenhum."

**Conceito:** Plantio de visão — diagnóstico técnico que prepara terreno pro produto.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [110:48]
**Por que misto:** plantar a noção de que "abordagem direta gera rejeição alta" abre caminho pra R2 onde tu apresenta o método. ⚠️ MAS detalhou demais — entregou o "como" (reunião vs convite) que dá pro João testar sozinho. Pra próxima R1, plantar a noção sem entregar o hack inteiro.

---

> Matheus: "quando a gente trocava ali pra convite, cara, pô, tô te convidando, velho. Então a pessoa já olhava com um olho diferente."

**Conceito:** Hack específico de prospecção entregue.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [110:48] — *"Cobra antes de ensinar."*
**Por que misto:** o reframe "reunião → convite" funciona como prova social de que tu sabe do que tá falando, MAS poderia ter sido contado em formato de história ("a gente tinha esse mesmo problema, descobrimos uma forma de virar isso") sem entregar a palavra-chave. Pra próxima: contar o caso, segurar a palavra-chave pra R2.

---

## Bloco 7 — João descarrega frustração (30:33–41:18)

> João: "nesses últimos dois meses foram cinco pessoas, o gerente foi o último, não, o gerente foi penúltimo."

**Movimento do prospect:** dor numérica de demissão.
**Decisão estratégica de camada:** **NÃO rotulado de propósito.** "5 demissões" puxa pra camada Ignição completo (recontratação de equipe inteira) — camada errada pra entrada. O Matheus deixou o João descarregar a frustração (válido pra catarse), mas sem ancorar Label pra não comprometer a porta de entrada (prospector solo).

---

> João: "o gerente, ele fala bem, ele conversa, só que ele não gosta, e ele tinha uma restrição quanto a isso, só que ele não transparecia."

**Movimento do prospect:** rotulou sozinho — gerente que não comprava o método.
**Decisão estratégica de camada:** mesmo critério. Termo ligado a gerente comercial / liderança interna = camada Ignição completo. Camada de entrada (prospector solo) não tem gerente. Ignorar foi coerente.

---

## Bloco 8 — Matheus bate de frente (41:18–49:00)

> Matheus: "tá, mas e daí, será que não tinha um, não sei, às vezes não tinha a parte de desmotivação da turma porque não tava dando resultado, às vezes não tinha... Cara, a gente cada vez mais ia ficando desmotivado, desmotivado e a gente mesmo diminuía a performance. Será que foi o primeiro ponto, a primeira engrenagem ali, não?"

**Conceito:** Bateu de frente com a versão do João.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [122:00] — *"Concordo, contorno, sugiro. Nunca bater de frente."*
**Por que falhou:** o João disse "demiti porque equipe não fazia volume". Tu sugeriu a tese oposta. Ele se fechou e defendeu por 3 minutos. **Esse foi erro de execução real, não escolha estratégica.** Era pra ter sido: *"Faz total sentido, João. Treinou, cobrou, equipe não respondeu. E o que tu sente que faltou pra eles destravarem?"* — concordar e perguntar.

---

## Bloco 9 — Clarificação tardia + Label da dor-alvo (49:00–51:14)

> Matheus: "E João, agora o que a gente entende ali que, vou até ter que encerrar aqui a nossa reunião aqui, trazendo para os finalmentes, eu queria entender o que você está conseguindo, o que você está fazendo agora para manter o faturamento, porque a gente entende que, pô, saiu esse pessoal, eles vão, isso daí vai implicar no seu faturamento mensal, ou vai para ter a mesma, porque elas não estavam performando, como que está isso hoje?"

**Conceito:** **C + L encadeados na janela "como vai segurar as pontas".**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] + [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [9:30]
**Por que funcionou parcialmente:** ✅ **AQUI tu clarificou a dor real.** Forçou o João a verbalizar como ele ia segurar faturamento sem equipe. Era a pergunta que devia ter aberto a reunião, mas funcionou mesmo tardia.
**⚠️ Onde escorregou:** o "vou ter que encerrar" no meio da pergunta mata energia — sinaliza pressa. Pra próxima, fazer essa pergunta sem o aviso de encerramento.

---

> João: "Cara, hoje estou desmoniciado, Matheus, estou desmoniciado... estou com pouco volume, perto daquilo que eu preciso para poder manter a constância, né? Cara, hoje eu tenho o plano de fazer um negócio maior, é esse o meu plano, eu tenho que fechar algo maior... eu acredito que nesse momento, se eu estou sendo bem sincero, posso estar completamente errado aqui."

**Movimento ouro do prospect:** verbalizou (a) dor emocional, (b) destino dele (1 contrato grande), (c) abertura pra contestação ("posso estar errado").
**Conceito:** **Dor-alvo entregue de bandeja: "precisa de mais vendas, não sabe como chegar, e tá apostando numa estratégia que ele mesmo duvida".**
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [30:37]
**Por que era o momento do L explícito:** essa era a janela pra cravar verbalmente: *"Então, João, o que eu tô entendendo é que tu precisa de mais vendas pra cobrir os próximos 60 dias e hoje tu não tem um caminho claro de como chegar nelas — tu tá apostando num contrato grande mas tu mesmo diz que pode estar errado. É isso?"* — Label puro pra ele confirmar. Tu fez o L em movimento (sem verbalizar o nome), mas a frase explícita teria amarrado mais forte.

---

## Bloco 10 — Plantio do destino reframado: SDR em 3-4 dias (51:14–55:50)

> Matheus: "Total, mas você falou que tinha outros, ficou dois vendedores ainda né... Por que que você não, em paralelo a isso, você não desenvolve com eles essa parte de prospecção?... cara, e por que que você não traz uma pessoa só para trabalhar nessa parte da ligação, cara, e para gerar demanda?"

**Conceito:** **Plantio do destino reframado — SDR/PDR como caminho mais curto.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [47:29] — *"Bater numa barreira lógica para que ele mesmo justifique a compra."*
**Por que funcionou:** ✅ tu reframou o problema. O João pensava "preciso de 1 contrato grande em 60 dias porque não consigo formar vendedor rápido". Tu trouxe outro caminho: "não precisa formar vendedor, traz uma pessoa só pra prospectar". Reframe legítimo do destino. Esse é o gancho da R2.

---

> Matheus: "daí a curva de aprendizado, cara, você pega um júnior aí, dois, três dias ele já está ligando, velho."

**Conceito:** **Reframe de tempo — 60 dias do João → 3 dias do SDR.**
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [37:15] — *"Quanto menor o tempo de espera, mais valor o teu projeto tem."*
**Por que funcionou:** ✅ comparação de tempo direta. O João estava pensando em 60 dias pra ROI. Tu plantou 3 dias pra começar a gerar demanda. **Equação do valor sendo manipulada já na R1** — denominador (tempo) caindo, valor percebido subindo. Movimento avançado.

---

> João: "Então, cara, como é que funciona esse processo? Eu já até considerei fazer isso, sabe? Mas eu não sei nem como que eu poderia levantar no formato tipo... Qual seria o formato que você enxerga isso, Matheus?"

**Movimento ouro do prospect:** **PEDIU explicação.** Curiosidade ativa = sinal de que o plantio funcionou.
**Conceito:** Aqui era a transição pra R2 perfeita.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [13:18] — *"Vou montar um projeto. Pode ser amanhã 13h?"*
**Por que poderia ter sido melhor:** o ideal era: *"Excelente pergunta, João. É exatamente isso que a gente formata caso a caso. Vou montar um projeto personalizado pra te apresentar quinta 14h. Topa?"* — segurar detalhe pra R2.

---

> Matheus: "Um fixo de ajuda de custo e aí pensar em alguma bonificação por métodos... bonificar até por volume... se esse cara conseguir trazer duas, três visitas por dia, ou o quê?... daria em torno de pelo menos uns, entre 60 a 100 mil reais os dois ali."

**Conceito:** ⚠️ **Plantio da visão com ROI calculado — misto.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [47:29]
**Por que misto:** matemática de ROI funciona como **barreira lógica forte** ("se 2 visitas/dia geram 60-100k em vendas, o custo do SDR se paga"). Bate na lógica do João e abre a R2. ✅ Mas entregou estrutura de remuneração completa (fixo + bonificação por volume) — isso é detalhe operacional que poderia ficar pra R2 sob formato de projeto. Pra próxima: plantar o ROI, **segurar a estrutura de remuneração** como entrega de proposta.

---

## Bloco 11 — Fechamento (55:50–58:54)

> Matheus: "isso daí a gente vê como, a gente chama isso daí de PDR... a gente viu como um formato novo que era mais fácil de implementar."

**Conceito:** Plantio do nome do método.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [110:48]
**Por que misto:** dar nome ("PDR") ancora autoridade e diferencia do que ele já conhece (SDR padrão). ✅ Mas sem explicação de origem ou prova social, fica solto. Pra próxima: *"A gente chama de PDR porque é uma adaptação do SDR clássico — em vez de qualificar lead inbound, ele faz outbound qualificado. Foi o que a gente implementou na Synergy no mês passado."* — nome + autoridade.

---

> Matheus: "Hoje é difícil contratar uma pessoa assim. É difícil pessoa."

**Conceito:** **Plantou objeção que o cliente não fez.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [97:18] — *"Não plantar narrativa que o cliente não pediu."*
**Por que falhou:** o João não tinha levantado dificuldade de contratação. Tu plantou. Ele pegou: "vou pesquisar". Essa frase enfraqueceu o gancho da R2.

---

> Matheus: "Ô João, o seguinte, se fizer sentido para ti, a gente pode trazer alguma formatação... Se fazer sentido para a gente, a gente pode marcar um segundo bate-papo... O tu acha? Faria sentido hoje ou você acha que nesse momento não seria ideal?"

**Conceito:** **Convite de R2 com framing tentativo.**
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [13:18] — *"Você sai com uma próxima reunião marcada, com data específica."*
**Por que falhou:** três "se fizer sentido" + pergunta de saída ("ou não seria ideal?") + sem data específica = convite tentativo. Comparar com Nimoto vs V4: *"Vou montar um projeto. Pode ser amanhã 13h?"* — afirmativo, com data.

---

> João: "Matheus, eu vou amadurecer essa ideia aqui primeiro, mas acho que a princípio sim."

**Movimento do prospect:** "vou amadurecer" + "a princípio sim". Não é sim cravado, mas não é não.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [97:18]
**Por que poderia ter sido melhor:** isolar a objeção. *"Claro, João. Antes de tu amadurecer, deixa eu te perguntar — o que precisa ficar claro pra tu decidir? Se eu te mando uma proposta concreta amanhã com formato, ROI e garantia, tu tem condição de me dar sim ou não na quinta?"*. Tu aceitou o "amadurecer" sem isolar — mas combinou follow-up pra amanhã, o que dá margem pra retomar.

---

> Matheus: "João, até finalizei um pouquinho mais rápido aqui, que minha esposa tá até passando mal aqui."

**Conceito:** Encerramento por motivo pessoal sem ter fechado a R2 com data.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [76:53]
**Por que falhou:** justificar saída por motivo pessoal numa R1 que ficou em "vou amadurecer" entrega controle pro prospect. Pra próxima: se precisar sair, fecha data primeiro.

---

## Decisões estratégicas de escopo / camada (não são falhas)

Termos do João **ignorados de propósito** porque puxavam pra **camada errada do Ignição** (Ignição completo com gerente / estruturação de equipe inteira / recontratação em massa) em vez da camada de entrada planejada (prospector solo):

1. **"Demiti 5 em 2 meses"** — puxava pra Ignição completa (recontratação). Camada de entrada é 1 prospector, não 5 vendedores.
2. **"Fadiga de formar time"** — puxava pra Ignição completa (estruturação de equipe). Camada de entrada não pede formar time, pede 1 pessoa rampada em 3-4 dias.
3. **"Nada mais caro do que contratar errado"** (cliente rotulou sozinho) — puxava pra debate sobre processo seletivo de vendedor. Camada de entrada é mais leve.
4. **"Liderança que não compra a régua"** (cliente rotulou sozinho) — puxava pra debate sobre gerente comercial. Camada de entrada não tem gerente, tem 1 prospector.
5. **"Buraco mais embaixo"** — genérico demais pra ancorar na camada de entrada.

**Como ressuscitar esses termos na escalada pós-fechamento:**
- *"João, lembra quando tu disse 'nada mais caro do que contratar errado'? A próxima fase do Ignição é exatamente isso — depois que o prospector tá rodando, a gente entra no recrutamento e treinamento dos vendedores de fechamento pra não cair nesse buraco de novo."*
- *"Tu falou 'fadiga de formar time'. A gente vai resolver isso na fase 3 do Ignição com o playbook de onboarding que rampar vendedor em 30 dias em vez de 90."*

Essas escolhas demoraram a reunião (45min de derramamento antes da clarificação) mas mantiveram a venda na camada certa. **Tradeoff válido — entrar barato é melhor do que tentar vender o produto inteiro de cara com fricção alta.**

---

## Mapa-resumo

| # | Movimento | Etapa CLOSER | Status | Aula |
|---|---|---|---|---|
| 1 | Tino sai na abertura | — | ⚠️ Quebra de autoridade | Call 1 [76:53] |
| 2 | Abertura sem metodologia | Pré-C | ❌ Faltou framing | R1/R2 [16:05] |
| 3 | "Me fala suas dificuldades" empilhado | C | ❌ Sem isolar | R1/R2 [16:05] |
| 4 | Deixou João derramar 25min | — | ⚠️ Tradeoff: contexto vs controle | Call 1 [116:46] |
| 5 | "Demiti 5 em 2 meses" | L/O | ✅ Ignorado (camada errada do Ignição) | — |
| 6 | "Fadiga de formar time" | L | ✅ Ignorado (camada errada do Ignição) | — |
| 7 | "Nada mais caro contratar errado" | L | ✅ Ignorado (camada errada do Ignição) | — |
| 8 | "Liderança não compra régua" | L | ✅ Ignorado (camada errada do Ignição) | — |
| 9 | 4min de aula sobre Coppel | — | ❌ Não cortou | Call 1 [116:46] |
| 10 | Furo lógico do pivot industrial | C | ⚠️ Boa intenção, formato fraco | Call 1 [47:29] |
| 11 | "Perdi venda por R$400" | O | ⚠️ Janela perdida (encaixava no alvo) | R1/R2 [22:17] |
| 12 | "Ticket maior, menos competitivo" | L | ⚠️ Destino não ancorado | R1/R2 [30:37] |
| 13 | Plantio "rejeição alta na abordagem" | — | ⚠️ Plantio bom, detalhe demais | Call 1 [110:48] |
| 14 | Hack "reunião → convite" | — | ⚠️ Plantio bom, palavra entregue | Call 1 [110:48] |
| 15 | Bateu de frente sobre "equipe desmotivada" | — | ❌ Não concordou+reframe | Call 1 [122:00] |
| 16 | Pergunta-C no minuto 49 ("como vai segurar pontas?") | C | ✅ Clarificou dor-alvo (tardio mas funcionou) | Imersão [311:25] |
| 17 | "Estou desmotivado" + "posso estar errado" | L | ⚠️ L feito em movimento, sem verbalizar | R1/R2 [9:30] |
| 18 | "Por que não traz uma pessoa só pra prospectar" | S em embrião | ✅ Reframe do destino | Call 1 [47:29] |
| 19 | "Em 2-3 dias o cara já está ligando" | S | ✅ Reframe de tempo (Equação do Valor) | R1/R2 [37:15] |
| 20 | João pediu "qual seria o formato?" | — | ⚠️ Janela perdida pra cravar R2 | R1/R2 [13:18] |
| 21 | Cálculo de ROI 60-100k | — | ⚠️ Barreira lógica boa, detalhe demais | Call 1 [47:29] |
| 22 | "PDR" sem ancorar autoridade | — | ⚠️ Nome solto sem prova social | Call 1 [110:48] |
| 23 | "Hoje é difícil contratar" | — | ❌ Plantou objeção que cliente não fez | Call 1 [97:18] |
| 24 | "Se fizer sentido" 3x na R2 | Transição R2 | ❌ Convite tentativo, sem data | R1/R2 [13:18] |
| 25 | Aceitou "vou amadurecer" sem isolar | — | ❌ Não isolou objeção | Call 1 [97:18] |
| 26 | Encerrou por motivo pessoal | — | ❌ Quebra de framing | Call 1 [76:53] |

**Score CLOSER R1:** **C ⚠️ (tardio mas executado) | L ⚠️ (em movimento, sem verbalizar nome) | O ❌ (não fez tríade na dor-alvo)**

---

## ⚠️ Onde Matheus falhou no próprio framework (R1: C + L + O)

**1. C tardio + acompanhado de "vou ter que encerrar".**
A pergunta-clarificação só veio no minuto 49 e veio com aviso de pressa. Funcionou, mas perdeu energia. Pra próxima: clarificar nos primeiros 10 minutos, sem aviso de encerramento.

**2. L feito em movimento, não verbalizado.**
Tu sabia qual era a dor-alvo ("precisa de mais vendas, não sabe como chegar") e conduziu pra lá, mas nunca falou em voz alta: *"Então o problema é X, certo?"* O João nunca confirmou em voz alta o nome do problema. Pra próxima: depois de clarificar, **sempre verbalizar o L explícito** e esperar o "é isso mesmo".

**3. O do CLOSER (tríade) zerado na dor-alvo.**
Quando o João disse "estou desmotivado, estou desmotivado" e "perdi venda por R$400 semana passada", essas eram janelas pra tríade que encaixavam no produto-alvo SDR (sem ir pra estruturação de equipe). Era pra ter sido: *"R$400 te custou 2 vendas semana passada. No mês passado, quantas vendas tu perdeu nessa mesma diferença porque não tinha funil qualificado entrando?"* — tríade direcionada pra "falta de fluxo qualificado", não pra "falta de equipe".

**4. Bateu de frente sobre causa da demissão.**
Quando o João disse "demiti porque equipe não fazia volume", tu sugeriu "talvez era falta de resultado". Ele se fechou e defendeu por 3 minutos. Erro de execução real. Pra próxima: *"Faz sentido, e o que tu sente que faltou pra eles destravarem?"* — concordar e perguntar.

**5. Plantou objeção que o cliente não fez.**
"Hoje é difícil contratar uma pessoa assim" — o João não tinha levantado isso. Tu plantou e ele pegou. Pra próxima: nunca antecipar objeção que o cliente não verbalizou.

**6. R2 com "se fizer sentido" 3x + pergunta de saída + sem data.**
Convite tentativo. Pra próxima: *"Vou montar um projeto pra ti. Quinta 14h tá bom?"* — afirmativo, com data.

**7. Detalhe operacional demais no plantio de SDR.**
ROI completo + estrutura de remuneração na R1 = matéria pra R2 sendo entregue na R1. Pra próxima: plantar visão (3 dias rampa, 60-100k pode pagar) e **segurar estrutura de remuneração** como entrega de proposta.

---

## ✅ O que funcionou bem

**1. Disciplina de escopo.**
Ignorou 4+ termos do João ligados a "estruturação de equipe / contratação" porque sabia que o produto-alvo era SDR, não Ignição completa. Movimento maduro — vendedor júnior teria caído na armadilha de rotular tudo que aparecesse.

**2. Reframe do destino na hora certa.**
Quando o João verbalizou "1 contrato grande em 60 dias", tu não bateu de frente. Tu plantou um caminho paralelo: "e se em 3 dias tu já tiver alguém gerando demanda?". Equação do Valor sendo manipulada na R1 — denominador (tempo) caindo. Movimento avançado.

**3. Curiosidade ativada no fim.**
Apesar do convite de R2 ter sido fraco, o João pediu "qual seria o formato?" — sinal de que o plantio funcionou. Isso já é metade do trabalho.

---

## Aplicação na próxima R1

- [ ] **Apresentar metodologia em <5min na abertura** (oferta da LM em 1 frase).
- [ ] **C do CLOSER nos primeiros 10 minutos** — sem aviso de encerramento.
- [ ] **L verbalizado em voz alta** assim que clarificar dor-alvo: *"Então o problema é X, certo?"* e esperar confirmação.
- [ ] **Tríade dirigida pro produto-alvo** — pegar dor numérica/emocional que encaixa no SDR (perda por funil ruim, desmotivação por falta de fluxo) e não nas que levam pra estruturação.
- [ ] **Manter disciplina de escopo** — termo que leva pro produto errado, ignorar de propósito. Continuar fazendo.
- [ ] **Cortar aula técnica do prospect** depois de 60 segundos.
- [ ] **Plantar visão sem entregar passo-a-passo** — segurar estrutura de remuneração e detalhe operacional pra R2.
- [ ] **Concordar + reframe, nunca bater de frente.**
- [ ] **Nunca plantar objeção que o cliente não fez.**
- [ ] **R2 afirmativa com data específica** — *"Vou montar um projeto. Quinta 14h tá bom?"*.
- [ ] **Em "vou amadurecer", isolar** — *"o que precisa ficar claro? Se eu te mando X amanhã, tu decide quinta?"*.

---

## Próximo passo prático com o João

Não esperar a mensagem dele. Mandar tu primeiro amanhã cedo:

*"João, depois da nossa conversa pensei no que tu me trouxe — a aposta de 1 contrato grande pra cobrir os próximos 60 dias. Montei uma proposta concreta de um caminho mais curto: começar a Ignição Comercial pela porta de entrada — 1 prospector rampado em 3-4 dias entregando 20+ visitas qualificadas/mês com decisores grupo A, sem você precisar contratar gerente novo nem perder tempo de gestão. Quinta 14h tá bom pra eu te mostrar em 30 minutos?"*

**Pra R2: vender Ignição Comercial entrando pelo prospector solo, com fases de escalada mapeadas.**

1. **Oferta-frase decorada (MAGIC) da fase de entrada:** *"Em 60 dias, ter 20+ visitas qualificadas com decisores grupo A entrando no funil toda semana, começando a gerar demanda em 3 dias, sem você precisar contratar gerente novo agora."*

2. **3 pilares no Miro pra fase de entrada (prospector solo):**
   - Recrutamento do prospector (perfil + filtro)
   - Treinamento + rampa em 3-4 dias
   - Monitoramento da primeira semana + estrutura de remuneração

3. **Mapa de escalada do Ignição** (mostrar que existe sem vender agora):
   - **Fase 1 (entrada — o que estamos vendendo agora):** prospector solo gerando demanda
   - **Fase 2:** entra recrutamento + treinamento dos vendedores de fechamento — *"resolve o que tu falou de 'nada mais caro do que contratar errado' — a gente entra com método pra tu não cair nesse buraco de novo"*
   - **Fase 3:** entra liderança comercial — *"resolve o que tu falou de 'liderança que não compra a régua' — a gente forma gerente que executa o método"*
   - **Fase 4:** estruturação completa do comercial (CRM, playbook, métricas)

   Isso resolve o problema de "tu tá vendendo pouco". O João compra a fase 1 hoje porque é barata e rápida, e vê o caminho completo de saída do "buraco mais embaixo".

4. **Reframe explícito do destino:** *"Tu pensava em 1 contrato grande em 60 dias. Eu te mostro como ter 4-6 oportunidades qualificadas em 30 dias E ainda fechar o grande junto, porque a Ignição começa rápido pelo prospector e escala depois."*

5. **Garantia antes do preço:** padrão Synergy — indefinida sem custo até gerar visitas qualificadas.

6. **Ancorar termos do João que ENCAIXAM na fase de entrada agora:** "ticket maior, menos competitivo", "posso estar errado", "como vou segurar as pontas". E **ressuscitar os termos da camada maior** ("contratar errado", "fadiga de formar time", "liderança que não compra") **como argumentos das fases 2-4** — mostrando que a Ignição resolve TUDO o que ele falou, só não tudo de uma vez.

---

## Documentos relacionados

- [[2026-04-22 — Matheus e Tino vs Synergy (R1)]] — R1 com mesmo padrão de clarificação tardia
- [[2026-05-05 — Matheus e Tino vs Synergy (R2)]] — referência de R2 com escopo bem definido
- [[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]] — referência canônica

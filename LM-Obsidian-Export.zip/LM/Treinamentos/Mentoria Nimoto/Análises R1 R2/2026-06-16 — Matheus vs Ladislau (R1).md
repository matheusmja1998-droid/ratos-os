---
tipo: análise R1
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Ladislau Asturiano (Fotovoltaico, BH)
nicho: energia solar
resultado: R2 marcada para 16/06 às 10h
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Mentoria Nimoto — Fundamentos Comercial]]"
---

# Análise — Matheus vendendo para Ladislau (Fotovoltaico)

R1 de 27 minutos com o Ladislau, dono de uma empresa de energia solar de 14 anos em BH, em crise pesada (encolheu de 17 pra 6 pessoas, vendeu dois caminhões pra sobreviver, é o único vendedor da operação). Produto-alvo: Ignição Comercial (prospecção B2B). Camada de entrada vendida: usar o time atual (Thaís + Camila) pra gerar visita de cliente comercial, sem contratar ninguém. R2 marcada pra hoje 10h.

> [!info] Resultado e diagnóstico geral
> R1 funcionou. R2 marcada com data e hora, lead quente, e o cliente entregou de bandeja: a dor, o número, a objeção futura e ainda confirmou que o método JÁ funcionou uma vez pra ele. O que pesou contra foi o Matheus amolecer no L e no O: rotulou só a camada racional e deixou a dor emocional (caminhões vendidos, empresa refém dele) no chão, sem devolver. Munição de sobra pra R2.

---

## Bloco 1 — Abertura e entrega da metodologia

> "deixa eu te perguntar se você conseguiu participar do nosso evento, o que você achou?" (call [01:33])

**Conceito:** tentativa de ancorar a Clarity no evento, mas não chega a ser a pergunta de clareza ("o que te trouxe aqui hoje / o que você busca resolver").
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [16:05] — *"deixa eu entender qual que está sendo a maior dificuldade de vocês hoje."*
**Por que falhou parcial:** abriu puxando rapport pelo evento, ok, mas não fechou o C. Quem preencheu a clareza foi o cliente sozinho no item seguinte.

---

> "Eu queria que você me explicasse direitinho como é que vocês trabalham... Vocês falaram que não é com lead, né, essas coisas, como é que é o negócio?" (call [01:42])

**Conceito:** cliente assume o C sozinho, verbaliza o motivo de estar ali (curiosidade sobre o método "sem lead").
**Aula:** R1/R2 [2:39] (clarity) + Call 1 [80:24] — *"não é o problema que ele te fala, é a intenção."*
**Por que funciona:** o cliente entregou a deixa por interesse genuíno. Sorte de lead quente. Matheus só precisava ancorar e seguir.

---

> "a gente trabalha sempre focado na parte comercial, a parte dos seus vendedores a venderem mais, a gerar a própria demanda. E essa demanda que a gente gosta de trabalhar é somente com clientes comerciais, que são aqueles clientes de açougue, padaria, academia, supermercado... Porque são clientes que têm uma conta de luz maior, são clientes que a concorrência desleal não consegue estar atacando" (call [02:01])

**Conceito:** entrega da metodologia logo na abertura + Blue Ocean (recorta o nicho comercial onde a guerra de preço não chega).
**Aula:** R1/R2 [16:05] *"evidenciar a metodologia de vocês"* + [[Mentoria Nimoto — Fundamentos Comercial]] (Blue Ocean).
**Por que funciona:** define categoria própria (gerar demanda comercial com o time atual), não vende "lead", justo o que o cliente já odeia.

---

> "Deu para ficar claro essa explicação mais breve?" (call [02:01])

**Conceito:** checagem de entendimento, mas pula a pergunta de clareza isolada ("dentro disso que falei, qual a sua maior dificuldade hoje?").
**Aula:** R1/R2 [18:09] — o próprio Matheus já descreveu a pergunta certa na mentoria: *"relacionado a isso que eu acabei de explicar, qual que a sua dificuldade?"*
**Por que falhou:** faltou fechar o C com a pergunta-âncora. De novo, o cliente preencheu o vácuo.

---

## Bloco 2 — Cliente entrega a dor de bandeja

> "três equipes de marketing... a gente estava com o lixo parado... a gente não estava conseguindo acertar isso" (call [03:25])

**Conceito:** cliente confessa fracasso com a solução que o concorrente vende (agência de lead). Reforça o Blue Ocean do Matheus.
**Aula:** Call 1 [80:24] — *"não é o problema que ele fala, é a intenção."* Intenção real: "já me queimei com agência, me prova que você é diferente."

---

> "A gente tem 14 anos no Fotovoltaico. Nós chegamos com 17 colaboradores, hoje nós temos seis... regrediu muito a empresa" (call [03:25])

**Conceito:** confissão de número (17 → 6). Dor quantificada espontânea.
**Aula:** R1/R2 [22:17] — repetir o número em tom de questionamento. Matheus deixou passar (ver falhas).
**Por que importa:** número de dor entregue de presente e ninguém devolveu.

---

> "vendedor sou eu, né... eu já tentei tudo com o vendedor, para você pensar, eu tenho carro zero para vendedor, eu já paguei fixo, comissão... e nada funcionou, só eu indo na rua mesmo que eu consigo vender" (call [03:25])

**Conceito:** cliente quebra a própria objeção sobre contratar. Ele mesmo diz que contratar não resolve. Abre o caminho pro entry-level "usa o time que você já tem, sem contratar".
**Aula:** Call 1 [47:29] — *"você precisa bater numa barreira lógica para que ele mesmo justifique a compra."* + Imersão [116:46].
**Por que é ouro:** o argumento central da oferta (sem contratar) saiu da boca do cliente.

---

> "no fim, você não viaja, você não tem vida própria, porque se você sair da empresa, a empresa para... por isso que eu preciso de alguém de marketing, alguma coisa diferente, alguma coisa que faça a empresa andar também sozinha" (call [03:25])

**Conceito:** cliente verbaliza o DESTINO emocional. Não é "mais vendas", é liberdade, empresa que roda sem ele.
**Aula:** R1/R2 [30:37] — *"a gente sempre vende o destino final."* + Call 1 [80:24] (intenção).
**Por que é ouro pra R2:** ESSE é o destino a vender hoje. Matheus não devolveu (ver falhas).

---

> "essa é a dificuldade, essa aí. Meu pepino maior. Você acha que pode ajudar a gente com isso?" (call [09:01])

**Conceito:** cliente entrega o problema rotulado por ele mesmo ("meu pepino maior") e pede ajuda. Bandeja pro Label.
**Aula:** R1/R2 [21:49] — rotular o problema.
**Por que importa:** Matheus respondeu "dá pra ajudar sim" e foi pra pergunta operacional. Podia ter cravado o rótulo ali, com a emoção quente.

---

## Bloco 3 — Diagnóstico e qualificação

> "você tinha falado com o Valentino... que tinha cinco na equipe comercial. Essas pessoas saíram, ou tem mais alguma pessoa? Como que está aí?" (call [09:12])

**Conceito:** pergunta de diagnóstico pra mapear a estrutura atual (necessário pra montar a oferta dentro do time existente).
**Aula:** Imersão [116:46] — *"quem faz as perguntas está no controle da conversa."*

---

> "a gente ensinar e fazer junto com a pessoa... gerando demanda de clientes comerciais através por ligação... a gente está gerando pelo menos uma, duas visitas por dia, com o time ligando no telefone" (call [12:03])

**Conceito:** prova social do meio do funil (visitas/dia) + planta o mecanismo.
**Aula:** Call 1 [67:47] — *"você abre o seu CRM e mostra: olha quantas reuniões a gente trouxe."*

---

> "quando você vai ali com dono de empresa... você mostra o benefício, o cara fala, isso é muito bom, é muito racional, Ladislau" (call [12:03])

**Conceito:** B2B é lógica (vende no racional, não na emoção). Reforça que o ticket comercial é mais previsível.
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] (B2B é lógica).

---

## Bloco 4 — Cliente aprofunda a dor sozinho

> "o essencial pra nós, sinceramente, é o feijão com arroz. É pra todo dia cozinhar" (call [13:13])

**Conceito:** cliente verbaliza a necessidade de recorrência e previsibilidade, justo o que o método comercial entrega.
**Aula:** R1/R2 [31:00] — resultado = *"vender mais caro para clientes melhores, fazendo com que você tenha previsão de receita."*

---

> "a gente está numa situação muito complicada... O capital de dinheiro já foi todo embora, tinha dois caminhões, já foi vendido. Então, a gente está tentando estar em pé" (call [15:21])

**Conceito:** dor máxima verbalizada, o "corda no pescoço" do Ladislau. Vendeu dois caminhões pra sobreviver.
**Aula:** Imersão [322:00] — *"eu quero ver meu cliente triste."* Aqui o cliente bateu na própria dor sozinho. + Call 1 [88:50] (escassez real dele).
**Por que importa:** sinal verde pra avançar. Mas Matheus não devolveu essa imagem como rótulo (ver falhas).

---

## Bloco 5 — Reframe e Label (C... L do CLOSER)

> "se a gente continuar fazendo aquilo que a gente está fazendo, acaba que se mantém o resultado até piora" (call [15:42])

**Conceito:** reframe do status quo. Não decidir é decidir piorar. Cria custo de inação.
**Aula:** Call 1 [47:29] (barreira lógica) + Imersão (custo de inação).
**Por que funciona:** tira o "deixa pra depois" de um cliente que já está sangrando capital.

---

> "para eu ter certeza que eu entendi, então, basicamente hoje seu problema é o que? É trazer mais vendas, principalmente de cliente comercial... e sem necessariamente precisar contratar outras pessoas... seria isso, né?" (call [15:42])

**Conceito:** L do CLOSER. Rotula o problema e pede confirmação, já embutindo o entry-level (sem contratar).
**Aula:** R1/R2 [21:49] e [24:24] — *"dar um nome ao problema do seu cliente"* e fazer ele confirmar.
**Por que funciona em parte:** fez o Label e o cliente confirmou. Mas rotulou só a camada racional ("mais vendas sem contratar") e deixou de fora a dor emocional que o cliente deu de graça (caminhões vendidos, 17 virou 6, empresa refém dele, sem vida própria). Rótulo morno (ver falhas).

---

> "Seria isso, exatamente isso... hoje a gente não pode correr risco de nada, porque tudo a gente está tirando do bolso... a gente não pode reinvestir e nem sabe se vai dar certo" (call [17:00])

**Conceito:** cliente confirma o rótulo E entrega a objeção futura (medo de investir sem garantia). Pré-anuncia a objeção de risco e preço da R2.
**Aula:** R1/R2 [40:32] — segunda pergunta de fechamento ("você acredita que funciona pra você?"). Essa objeção vai voltar hoje.
**Por que importa pra R2:** a objeção real não é preço, é "não tenho capital e não sei se dá certo". Preparar garantia / risco reverso.

---

## Bloco 6 — O do CLOSER (tríade) e validação do método

> "o pessoal ali que trabalha, principalmente atendendo o telefone, na parte de orçamento, ele tem algum tempo durante o dia para estar trabalhando essa prospecção ativa por telefone?... As duas horas por dia, a gente já consegue extrair pelo menos uma, duas visitas por dia" (call [17:26])

**Conceito:** pergunta de qualificação operacional (viabiliza a oferta no time atual) + planta a probabilidade de sucesso (2h/dia = 1-2 visitas/dia).
**Aula:** R1/R2 [37:15] — *"a maior parte da R2 é você falando sobre probabilidade de percepção de sucesso."*

---

> "Eu vou pedir que a gente marque até segundo bate-papo, que aí eu vou trazer uma proposta formatada para o teu negócio... eu vou montar todo o organograma que precisa, entre treinamento, ajuda com CRM... e te trazer uma projeção de quanto que isso pode estar te ajudando mensalmente" (call [19:08])

**Conceito:** transição pra R2. Promete o projeto personalizado, gancho clássico de fechamento da R1.
**Aula:** R1/R2 [13:18] — *"eu preciso fazer um projeto, eu quero realmente te apresentar isso. E aí você já sai com uma próxima reunião marcada."*
**Por que funciona:** cria razão forte pra R2, o cliente quer ver a projeção dele.

---

> "Você já tentou prospecção ativa, já tentou essa parte de ligação? Como que foi isso aí?" (call [19:08])

**Conceito:** O do CLOSER, primeira pergunta da tríade ("já tentou antes?").
**Aula:** R1/R2 [27:28] — *"você já tentou alguma solução para resolver isso?"*
**Por que funciona:** abre a enfatização. Mas parou na primeira pergunta (ver falhas).

---

> "Já, a gente já tentou, a gente já teve curso com o pessoal de Londrina... aí ele acompanhou legal... a gente conseguiu desenvolver bem, foi bom, não foi ruim, não... O curso foi quase ano... ela vendeu muito bem para a gente, mas depois ela se adoeceu" (call [20:19])

**Conceito:** cliente confirma que o EXATO método (prospecção B2B + treinamento + acompanhamento junto, por quase um ano) JÁ FUNCIONOU pra ele. Prova de conceito dada pela própria boca do cliente.
**Aula:** Call 1 [67:47] (prova social). Aqui a prova é a história dele mesmo.
**Por que é ouro:** na R2 isso vira *"você já viveu isso funcionando, eu só vou reinstalar e ficar do seu lado pra não parar de novo."*

---

> "isso daí é muito importante... você vê que realmente funciona algo ali que você consegue estar gerando resultado. E ter uma pessoa na equipe que já entende muito bem sobre o produto..." (call [22:45])

**Conceito:** Matheus capitaliza a validação e transforma a Thaís (conhecimento técnico) em ativo da operação.
**Aula:** R1/R2 [37:15] (eleva a probabilidade de sucesso).
**⚠️ Por que parcial:** aqui ele também entrega um pedaço de método de graça (como elevar o nível de consciência do lead facilita a venda na visita). Plantar a visão pra R2 é ok, mas o detalhe executável beira a consultoria grátis (Call 1 [110:48] — *"cobra antes de ensinar"*).

---

## Bloco 7 — Planta o destino e marca a R2

> "Hoje, com a sua estrutura hoje, a gente consegue estar extraindo, no mínimo, de uma, duas vendas por mês... duas, três vendas ali, a gente está falando ali de em torno de uns 100, 150 mil no total... o ticket do cliente comercial é bem mais alto" (call [24:38])

**Conceito:** planta o destino e o resultado (preview do Sell the Vacation) com número.
**Aula:** R1/R2 [30:37] (vende o destino) + [37:15] (probabilidade).
**⚠️ Por que parcial:** entregou a projeção na R1. Esse número deveria ser o ápice da R2. Funciona como teaser, mas tira munição de hoje. Na R2 vai ter que ancorar mais específico (projetos comerciais de R$X) pra não repetir o mesmo número genérico.

---

> "como que está a tua agenda amanhã? Que a gente senta e bate esse papo, eu te trago a proposta... 10 horas... aí nós vamos trazer ali uma formatação para vocês" (call [24:38] e [26:09])

**Conceito:** marca a R2 com DATA e HORA específicas. Encerramento correto da R1.
**Aula:** R1/R2 [13:18] — data específica, não "essa semana".
**Por que funciona:** compromisso concreto, não fica no "se fizer sentido".

---

> "É muito parecido, Ladislau, o trabalho que a gente faz, que você falou que faz de ano... Ela, muitas vezes, entrava junto, ligava junto, acompanhava as pessoas junto. A gente trabalha nessa linha" (call [26:30])

**Conceito:** amarra o método dele (que já funcionou) ao método do Matheus. Viés de certeza + familiaridade.
**Aula:** Call 1 [90:00] — *"já apresento a reunião falando: quando a gente fizer isso, a consequência é isso."*

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| Abre no evento, não faz a pergunta de clareza | C incompleto | R1/R2 [16:05] |
| Cliente pede pra explicar o método sozinho | Cliente assume o C | R1/R2 [2:39] |
| "Foco comercial, cliente de açougue/padaria" | Metodologia + Blue Ocean | Fundamentos |
| Cliente: "três equipes de marketing, lixo parado" | Confessa fracasso com concorrente | Call 1 [80:24] |
| Cliente: "17 virou 6" | Número de dor (não devolvido) | R1/R2 [22:17] |
| Cliente: "tentei tudo com vendedor, nada funcionou" | Quebra a própria objeção de contratar | Call 1 [47:29] |
| Cliente: "empresa que ande sozinha, sem mim" | Verbaliza o destino emocional | R1/R2 [30:37] |
| Cliente: "vendi dois caminhões pra estar em pé" | Corda no pescoço dele | Imersão [322:00] |
| "Continuar fazendo igual, piora" | Reframe do status quo | Call 1 [47:29] |
| "Seu problema é mais venda comercial sem contratar, né?" | L do CLOSER (morno) | R1/R2 [21:49] |
| Cliente: "não posso correr risco, tiro do bolso" | Pré-anuncia objeção da R2 | R1/R2 [40:32] |
| "Já tentou prospecção? Como foi?" | O do CLOSER (1ª da tríade) | R1/R2 [27:28] |
| Cliente: "curso de Londrina, quase um ano, funcionou" | Prova de conceito do próprio cliente | Call 1 [67:47] |
| "Extraio 1-2 vendas/mês, R$100-150k" | Planta destino com número | R1/R2 [30:37] |
| R2 marcada 16/06 10h | Encerramento CLOSER | R1/R2 [13:18] |

---

## Decisões estratégicas de escopo / camada

**Produto-alvo:** Ignição Comercial (prospecção B2B pra integradora solar).
**Camada de entrada vendida:** usar o time atual (Thaís + Camila), sem contratar, gerar 10 a 15 visitas comerciais por mês. Menor unidade vendável, fricção psicológica mínima. Perfeita pra um cara que vendeu os caminhões e tira tudo do bolso.

**Termos que puxavam pra camada maior (corretamente NÃO rotulados):** "preciso de alguém de marketing", reconstruir a empresa, voltar pros 17 colaboradores. Puxar pra lá num cara sem capital = "vou ter que investir pesado" = venda morre. Manteve no entry. ✅

**Termo que NÃO pode morrer, ressuscita na R2:** "uma empresa que ande sozinha, sem depender de mim". Esse é o destino emocional. Na R2 vira a visão do Sell the Vacation (empresa que roda sem o Ladislau), mas o mecanismo entregue continua sendo o entry barato (time atual gerando demanda).

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não fechou o C (Clarity).** Abriu no evento, explicou a metodologia, mas nunca fez a pergunta-âncora: *"dentro disso que falei, qual a sua maior dificuldade hoje?"* Quem preencheu a clareza foi o cliente, por sorte de lead quente. Num lead frio isso custa a reunião. R1/R2 [16:05] e [18:09].

**2. L morno, só racional.** Rotulou "mais vendas comerciais sem contratar" e largou no chão a dor emocional que o cliente deu de presente: vendeu dois caminhões, encolheu de 17 pra 6, empresa refém dele, sem vida própria. Faltou dar nome próprio e devolver com as palavras dele. R1/R2 [21:49] e [24:24].

**3. Tríade incompleta no O.** Perguntou "já tentou?" e soube por que parou (a pessoa adoeceu), mas NÃO enfatizou a perda: *"e desde que ela saiu, quanto você deixou de faturar parando essa prospecção que estava funcionando? quanto tempo ficou parado?"* Tinha a deixa perfeita (o método funcionou e ele parou) e amoleceu na empatia. R1/R2 [9:54] e [27:28].

**4. Não repetiu os números de dor em tom de espanto.** "17 virou 6", "vendi dois caminhões", "o capital foi todo embora" passaram sem devolução. Repetir o número faz o cliente quebrar a própria objeção sobre o status quo, igual o Nimoto fazendo *"11 mil de CAC?"*. R1/R2 [22:17].

---

## Aplicação na próxima R1

- [ ] Fechar o C com a pergunta-âncora antes de deixar o cliente discursar: "dentro do que expliquei, qual sua maior dificuldade hoje?"
- [ ] Rotular com nome próprio + as palavras emocionais do cliente ("empresa refém de você", "corda no pescoço")
- [ ] Tríade completa: já tentou? por que parou? quanto tempo? quanto deixou de faturar? como seria sem isso?
- [ ] Repetir o número de dor em tom de espanto ("você vendeu DOIS caminhões pra segurar a empresa?")
- [ ] Segurar a projeção e o destino pro ápice da R2, não entregar na R1

---

## 🎯 Destino pra R2 (hoje, 16/06 às 10h) — roteiro CLOSER

Lead quente que já entregou dor, número, objeção e prova de conceito. A R2 é pra reinstalar a certeza e fechar. Segue a linha:

**C — Recap (1 min):**
> "Ladislau, desde ontem você continua querendo a mesma coisa: voltar a vender de cliente comercial usando o time que você já tem, sem contratar ninguém, sem tirar mais do bolso, e ter uma empresa que anda mesmo quando você não está nela. Mudou alguma coisa ou esse continua sendo o destino?"

**L — Devolver a dor, agora com a emoção que faltou na R1:**
> "Você me falou uma coisa ontem que ficou na minha cabeça: que vendeu dois caminhões pra segurar a empresa, e que hoje, se você sai, a empresa para. Pra mim teu problema não é falta de venda. É que a empresa inteira depende de uma pessoa só, você. É isso que a gente vem resolver."

**O — Urgência presente (comprimida):**
> "E cada mês nesse modelo é mais capital saindo do seu bolso, igual você falou. Desde que a moça de Londrina saiu e a prospecção parou, quanto você acha que deixou de faturar?"
(faz ele dizer o número, deixa a dor presente)

**S — Sell the Vacation (destino + 3 pilares, máx 3 min):**
Destino: "Em uns 60 dias, seu time atual gerando 10 a 15 visitas comerciais por mês sozinho, 2 a 3 vendas/mês, R$100 a 150k de ticket comercial entrando, sem você na rua todo dia."
1. Treinamento + script de prospecção B2B pro time (Thaís na parte técnica, Camila no telefone)
2. Acompanhamento junto (ligo junto, ouço call, ajusto), igual a Londrina fazia e você já viu funcionar
3. CRM + lista de cliente comercial (açougue, padaria, academia) pra alimentar a máquina
Oferta-frase: "Eu reinstalo na sua empresa a máquina de prospecção comercial que você já viu funcionar uma vez, usando o time que você já paga, pra empresa rodar sem depender de você."

**E — Quebra de objeção (a certa: "não tenho capital / e se não der certo"):**
Resgata a fala dele e não bate de frente:
> "Você mesmo me disse ontem que não pode correr risco porque tira tudo do bolso. Eu entendo 100%. É exatamente por isso que a gente não pede pra você contratar ninguém nem montar estrutura nova. A gente usa a Thaís e a Camila, que você já paga. O investimento é no método, não em folha."
Garantia / risco reverso ANTES do preço.

**R — Reinforce (3 perguntas de fechamento, nessa ordem, antes do preço):**
1. "Você acredita que prospecção comercial ativa funciona?" (ele já disse que sim, Londrina)
2. "Você acredita que funciona pra TUA empresa, com a Thaís e a Camila?" (se travar aqui = objeção tempo/capital, contorna com os 3As)
3. "Você acredita que eu sou a pessoa certa pra reinstalar isso com você?"
Sim/sim/sim, só sobra preço. "Como posso facilitar pra gente começar agora?"
Primeiras 48h: já deixa onboarding marcado + script entregue + primeira call de prospecção acompanhada, pra ele sentir movimento na hora (ele está ansioso, isso segura a decisão).

**Cuidados táticos:**
- Não repetir a projeção genérica de ontem, ancorar específico (projetos comerciais de R$X)
- Não bater de frente quando ele chorar capital, concordar + reframe (time atual)
- Ser objetivo. Ontem ele puxou muito papo (futebol, mão de obra). Ele mesmo pediu isso na call [24:15]: "a gente tem que ser mais objetivos"

---

## Documentos relacionados
- [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]
- [[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]]
- [[Mentoria Nimoto — Índice]]

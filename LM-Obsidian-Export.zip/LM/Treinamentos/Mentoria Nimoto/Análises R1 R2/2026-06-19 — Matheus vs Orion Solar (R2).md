---
tipo: análise R2
data: 2026-06-19
vendedor: Matheus Jardim
prospect: Aires Martin + Fernando + Ricardo Fioravante (Orion Solar)
nicho: energia solar
oferta: Ignição Comercial — 45 dias, R$4.000, teste de fogo (SDR contratado pra Orion, paga por resultado), garantia 20 visitas/mês
resultado: EM ABERTO — Aires vai sentar com a empresa e dar resposta na terça. Não fechou na call.
tags: [mentoria, nimoto, r2, análise, lm, vendas]
fontes:
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[CLOSER R2 — Versão Matheus]]"
  - "[[2026-05-05 — Matheus e Tino vs Synergy (R2)]]"
---

# Análise — Matheus vendendo para Orion Solar (R2)

R2 de ~28 minutos com a Orion Solar: Aires Martin (decisor), Fernando (o closer da operação) e Ricardo. Follow-up da R1 do dia 16. Sexta de jogo do Brasil, o Matheus cravou logo o frame de "meia hora pra dar tempo de churrasco". Oferta: Ignição Comercial, 45 dias, R$4.000, teste de fogo (LM contrata + treina um SDR pra Orion, paga por resultado), garantia de 20 visitas/mês. **Não fechou.** O Aires precisa sentar com a empresa (as vendas caíram, cashflow apertado) e dá resposta na terça.

> [!info] Resultado e diagnóstico geral
> A R2 mais bem executada das três do ciclo. C ✅, L ✅ (devolveu uma dor específica e dolorida: o vendedor que levou R$4k de comissão sem fazer o trabalho), S ✅, e dois acertos grandes: **garantia ANTES do preço** (consertou o erro da R2 do Ladislau) e **portas distribuídas** pro Aires E pro Fernando (multi-stakeholder). Não fechou por três pontas: **O ❌** (não mediu urgência), **decisão não isolada** (o "sentar com a empresa / sócios" só apareceu no fim, como saída) e a **3ª porta** (confiar no executor) que não veio. A objeção real é cashflow ("vendas deram uma caída"), e ela ficou pra terça.

---

## Bloco 1 — Abertura + C (recap)

> "sexta-feira dia de jogo do Brasil e França, a gente acaba sendo mais rápido... meia horinha a apresentação, pra não tomar o tempo e dar tempo de chegar em casa, acender a churrasqueira" (call [01:00] e [27:51])

**Conceito:** calibrou o tempo e criou um frame de objetividade (30 min). Rapport leve com a Copa pra abrir.
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] (estrutura de reunião).
**Por que funciona parcial:** ✅ respeita o tempo de uma sala de 3 pessoas numa sexta de jogo. ⚠️ mas o frame apertado acabou comprimindo a urgência e o fechamento (ver falhas). Velocidade é boa, pressa não.

---

> "o que eu entendo hoje é que vocês não precisam de mais vendedor, porque você tem o Aires, tem o Fernando, a máquina de fechamento. Vocês precisam do cara que gera visita comercial constante. Continua sendo isso ou teria algo a acrescentar?" → Aires: "é exatamente isso" (call [01:00])

**Conceito:** C do CLOSER. Recap do problema da R1 + pergunta-âncora de confirmação. Já embute o reframe (não é vendedor, é gerador de demanda).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] + [[CLOSER R2 — Versão Matheus]] (recap + "é isso mesmo?").
**Por que funciona:** ✅ recap limpo, devolveu o problema na boca deles e confirmou em voz alta. C bem feito.

---

## Bloco 2 — L (rótulo com dor específica)

> "vocês são muito bons nas vendas, falta o volume no topo do funil... igual aquele caso que o Fernando contou, o vendedor chegou no cliente e não conseguiu vender, aí o Fernando montou a proposta e fechou, e o vendedor ainda puxou 4 mil de comissão sem ter feito quase nada. Teve mais casos como esse?" (call [02:46])

**Conceito:** L do CLOSER com uma dor ESPECÍFICA e dolorida deles (o vendedor que levou R$4k sem fazer o trabalho), e ainda perguntou "teve mais casos?" pra torcer a faca.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [317:35] (rotular) + [320:10] (*"quero ver meu cliente triste"*).
**Por que funciona:** ✅ esse é o L mais forte das três R2 do ciclo. Não rotulou genérico ("falta venda"), pegou uma cena concreta de prejuízo deles e devolveu. Ancora a dor de pagar caro por quem não entrega, justo o que o teste de fogo resolve.

---

## Bloco 3 — S (destino + oferta-frase)

> "uma maneira de vocês receberem 10 a 20 visitas por mês de clientes comerciais... seria esse o destino que vocês gostariam, que a gente trouxesse um projeto pra chegar nesse destino?" → Aires: "de forma geral é isso, não só a venda, mas também a manutenção e a limpeza" (call [04:00])

**Conceito:** S — destino + pergunta-âncora ("é esse o destino?"). Cliente confirma e AMPLIA (quer manutenção e limpeza junto).
**Aula:** R1/R2 [30:37] (vende o destino) + [[CLOSER R2 — Versão Matheus]] (confirma destino antes do produto).
**Por que funciona:** ✅ destino confirmado e o cliente até agregou escopo (sinal de engajamento). Matheus aproveitou pra plantar a quebra de objeção de manutenção/limpeza dentro do treinamento.

---

> "o nome desse projeto é Ignição Comercial, dar a partida na geração de demanda... projeto de 45 dias... a gente contrata uma pessoa pra Orion, vaga de SDR/pré-vendedor, e a gente chama de teste de fogo: nos primeiros 30 dias ela recebe só bônus por meta, e o fixo dela só entra depois que ela trouxer uma venda. O salário sai da venda que ela gerou, não do teu bolso" (call [07:35] a [12:00])

**Conceito:** oferta-frase + mecanismo (teste de fogo / risco reverso). O custo da pessoa se autofinancia pela venda que ela gera.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] (garantia/risco reverso) + [37:15] (probabilidade de sucesso).
**Por que funciona muito:** ✅ pra uma equipe que ACABOU de relembrar a dor de pagar R$4k de comissão a quem não entregou, o "ela só vira fixo depois de provar, e o salário sai da venda" é desenhado pra esse trauma. E ainda desmonta o medo de contratar SDR ("rampa em 3-4 dias, mais fácil que vendedor").

---

## Bloco 4 — Apresentação técnica (Passo D)

> "treinamento: como ela acha empresa no Google, lista, script de ligação, cadência (quantas vezes liga até desistir), visita agendada + confirmação no dia anterior, no dia, 1h antes; depois CRM, playbook, acompanhamento ao vivo, dailys de 15 min, previsibilidade das métricas (a cada 50 ligações sai 1 visita), dashboard de metas" (call [13:05] a [18:00])

**Conceito:** apresentação técnica do produto (Passo D). Detalha a engrenagem inteira.
**Aula:** [[CLOSER R2 — Versão Matheus]] — *"apresentação do produto, pode ser técnico, pode mostrar mapa mental."*
**Por que funciona:** ✅ detalhar o COMO aqui é correto (Passo D). Pra uma equipe técnica que já contratou e sofreu com vendedor, ver o método estruturado (script, cadência, dailys, previsibilidade) gera confiança de execução. Não é "vender o voo", é a etapa certa.

---

## Bloco 5 — Portas distribuídas (multi-stakeholder)

> "vocês acreditam que esse pré-vendedor dedicado gerando visita comercial daria certo pra vocês hoje? Quero saber o que vocês acharam do projeto" → Aires: "acredito que sim, a ideia parece boa, é como uma prospecção sem ser o vendedor, faz a ponte. Quem determina o fechamento somos nós" (call [18:00] e [19:20])

**Conceito:** porta 1 do R (faz sentido / é pra você). Cliente confirma e reforça que o controle do fechamento é dele (bom sinal de ownership).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00].
**Por que funciona:** ✅ porta feita e respondida com sim qualificado.

---

> "Fernando, queria saber a tua opinião, porque você vai ser quem chuta a bola pro gol na visita" → Fernando: "acho que é uma tática boa, traz o norte, é certeiro, não perde tempo, e hoje a gente não pode perder tempo" (call [21:57] e [22:12])

**Conceito:** distribuiu a porta pro segundo decisor (Fernando, o closer). Fez o homem-chave da execução verbalizar o buy-in.
**Aula:** Call 1 [98:50] (isolar/alinhar decisão) + [330:00] (portas).
**Por que funciona muito:** ✅✅ esse é o melhor movimento da call. Numa sala de 3, ele não deixou o Fernando calado, foi buscar o sim dele explicitamente. Dois decisores verbalizando "isso funciona" antes do preço. Munição forte pro fechamento.

---

> "tirando o preço, a parte de produto se encaixa na estrutura de vocês, vocês acreditam nisso? Porque se vocês acreditam no produto, o preço é o de menos" → "pra mim tá ok, agora é questão de preço" (call [23:37])

**Conceito:** porta 2 (é pra você) + isolamento da objeção pra sobrar só preço.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"se sim/sim/sim, sobra só valor."*
**Por que funciona parcial:** ✅ isolou pra preço e o Aires confirmou. ⚠️ mas faltou a 3ª porta explícita ("vocês acreditam que a GENTE é a pessoa certa pra executar?") e, principalmente, o isolamento da DECISÃO (quem mais decide?), que voltou pra morder no fim.

---

## Bloco 6 — Garantia ANTES do preço + preço

> "eu até esqueci de trazer a garantia: a gente só larga vocês nos 45 dias quando a pessoa estiver gerando pelo menos 20 visitas/mês. Pagamento único, e a garantia é que só finaliza depois que ela estiver rampada. E o valor desse projeto de 45 dias é 4 mil" (call [24:00])

**Conceito:** garantia de execução ANTES do preço, depois o número direto.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] (garantia) + [330:00] (número direto).
**Por que funciona:** ✅✅ aqui ele CONSERTOU o erro da R2 do Ladislau (onde a garantia veio depois do preço). Zerou o risco percebido e só então soltou os R$4.000. Ordem certa.

---

> Aires: "essa pessoa vem da minha região ou é uma pessoa sua?" → "é uma pessoa da Orion, a gente faz a contratação pra vocês, pode ser local, regional ou home office" + "qual a forma de pagamento?" → "Pix à vista, cartão parcelado, ou entrada + dividir no 30 e 45" (call [25:45] a [27:00])

**Conceito:** E — quebra de objeções operacionais (de quem é a pessoa, como paga). Respostas claras e flexíveis.
**Aula:** [[CLOSER R2 — Versão Matheus]] (3As).
**Por que funciona:** ✅ objeções de logística respondidas sem fricção. Deixou claro que a pessoa fica com a Orion (não é dependência eterna da LM).

---

## Bloco 7 — A objeção real + adiamento

> Aires: "eu vou ter que sentar com a minha empresa e conversar, porque as vendas deram uma caída, eu preciso ver o que eu consigo comprometer sem dar minha operação" (call [27:19])

**Movimento crítico do prospect:** AQUI saiu a objeção real, e são DUAS: (1) decisão não é só dele ("sentar com a empresa") e (2) cashflow ("vendas caíram, não posso apertar a operação"). Não é objeção de produto, é de capacidade financeira + decisão compartilhada.
**Aula:** Call 1 [98:50] — *"isolar a decisão antes de avançar."*
**Por que importa:** essa decisão compartilhada devia ter sido isolada LÁ NO COMEÇO ("além de vocês três, tem mais alguém que decide?"). Apareceu só no fim, como porta de saída. E o cashflow é a mesma trava do Ladislau.

---

> "tranquilo, Aires. Vê o que vocês conseguem de entrada e a gente flexibiliza o restante dos 45 dias. Pode ser? E até que dia você me dá resposta? Terça? Fechou, me manda no WhatsApp na terça, e a gente pode puxar um meet pra acertar a forma de pagamento" (call [27:29] a [28:30])

**Conceito:** quebra parcial da objeção financeira (flexibilizar entrada) + ancoragem de prazo (terça) + oferta de meet pra negociar pagamento.
**Aula:** R1/R2 [13:18] (compromisso com data específica).
**Por que funciona parcial:** ✅ não deixou no ar, cravou terça e ofereceu continuar a negociação de pagamento. ⚠️ mas aceitou o adiamento sem fazer mais uma tentativa de fechar na hora (ex: "qual o valor de entrada que caberia HOJE pra gente já dar o start?"), e sem isolar quem é "a empresa" que ele vai consultar.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Meia hora, dia de jogo" | Frame de tempo (mas apressado) | Fundamentos |
| "Não precisam de vendedor, precisam de quem gera visita. É isso?" → "exatamente" | C do CLOSER | Imersão [311:25] |
| "O vendedor levou 4 mil de comissão sem fazer o trabalho" | L com dor específica ✅ | Imersão [317:35] |
| "10-20 visitas/mês, é esse o destino?" → "isso, e manutenção e limpeza" | S + destino confirmado e ampliado | R1/R2 [30:37] |
| Teste de fogo (bônus no teste, fixo após venda, salário sai da venda) | Risco reverso sob medida | Imersão [222:54] |
| Treinamento, script, cadência, CRM, dailys, dashboard | Apresentação técnica (Passo D) ✅ | CLOSER R2 |
| Aires: "acredito que sim, a ideia é boa" | Porta 1 (faz sentido) | Imersão [330:00] |
| Fernando: "tática boa, traz o norte, certeiro" | Porta distribuída ao 2º decisor ✅✅ | Imersão [330:00] |
| "Tirando o preço, acreditam? Agora é questão de preço" | Isolou pra preço (faltou 3ª porta) | Imersão [330:00] |
| Garantia (só larga após 20 visitas) → "valor é 4 mil" | Garantia ANTES do preço ✅✅ | Imersão [222:54] |
| "A pessoa é da Orion?" / "forma de pagamento?" | Objeções operacionais resolvidas | CLOSER R2 |
| "Vou sentar com a empresa, vendas caíram" | Decisão não isolada + cashflow | Call 1 [98:50] |
| "Resposta terça + meet pra pagamento" | Ancorou prazo (sem fechar) | R1/R2 [13:18] |

**Score CLOSER R2:** **C ✅ · L ✅ · O ❌ · S ✅ · E ⚠️ · R ⚠️** — não fechou (resposta terça).

---

## ⚠️ Onde o Matheus deixou pontas

**1. Não mediu urgência (O).** Em nenhum momento perguntou o nível de urgência. O sinal estava na mesa ("as vendas deram uma caída") mas ele não extraiu nem ancorou. Sem urgência fincada, o "vou pensar com a empresa" fica barato. **O do CLOSER em R2 = urgência presente.** Faltou. **Imersão [320:10].**

**2. Não isolou a decisão.** O "vou ter que sentar com a minha empresa" apareceu só no fim, como saída. Numa sala com Aires + Fernando + Ricardo, devia ter perguntado no começo: "além de vocês três, mais alguém participa da decisão?". Isolar decisão é pré-requisito pra não ser surpreendido com um sócio fantasma no fechamento. **Call 1 [98:50].**

**3. Faltou a 3ª porta.** Fez faz-sentido (Aires) e é-pra-você (Fernando), mas não a 3ª: "vocês acreditam que a GENTE é a pessoa certa pra executar isso com vocês?". Numa decisão que vai pra "conversar com a empresa", reforçar a confiança no executor antes ajuda o Aires a defender a escolha lá dentro. **Imersão [330:00].**

**4. Aceitou o adiamento sem uma última investida.** Quando o cashflow apareceu, dava pra puxar um micro-fechamento: "qual valor de entrada caberia HOJE, sem apertar, pra gente já travar a contratação?". Em vez de mandar pra terça inteira, ancorar um compromisso menor na hora. **Imersão [330:00] (como posso facilitar pra fechar agora?).**

**O que foi acerto grande (manter e repetir):**
- **Garantia ANTES do preço** (consertou o erro do Ladislau).
- **L com cena de dor concreta** (o vendedor dos R$4k), muito mais forte que rótulo genérico.
- **Portas distribuídas** numa sala de 3, indo buscar o sim do Fernando (o closer) explicitamente.
- **Isolou pra preço** antes de soltar o número.

---

## Aplicação na próxima R2

- [ ] **Medir urgência (O)** sempre, mesmo com cliente que parece confortável. Aqui tinha "vendas caíram" de bandeja e passou batido.
- [ ] **Isolar a decisão no começo:** "além de vocês, mais alguém decide?" — pra o sócio/empresa não virar saída no fim.
- [ ] **Fechar as 3 portas** (incluindo "vocês acreditam que a gente é a pessoa certa?") antes do preço.
- [ ] **Cashflow apareceu? Puxa o micro-compromisso na hora** (entrada mínima hoje) em vez de mandar a decisão inteira pro futuro.
- [ ] **Manter:** garantia antes do preço, L com dor concreta, portas distribuídas, isolar pra preço.

---

## Documentos relacionados
- [[2026-05-05 — Matheus e Tino vs Synergy (R2)]] — referência de R2 que fechou
- [[CLOSER R2 — Versão Matheus]] — método
- [[Mentoria Nimoto — Índice]]
</content>

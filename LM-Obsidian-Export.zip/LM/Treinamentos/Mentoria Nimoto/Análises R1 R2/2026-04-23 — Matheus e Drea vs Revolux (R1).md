---
tipo: análise R1
data: 2026-04-23
vendedor: Matheus Jardim + Drea
prospect: Marcelo (Revolux Energia Solar) — São Carlos
sócio_ausente: Luiz (aposentado, decisor compartilhado)
nicho: energia solar
resultado: R2 tentativa pra quinta 19h com Luiz junto, mas Marcelo recuou ("não tinha pretensão de investimento esse ano")
tags: [mentoria, nimoto, r1, análise, revolux]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Mentoria Nimoto — Fundamentos Comercial]]"
---

# Análise — Matheus e Drea vendendo para Revolux (Marcelo)

R1 de 35 min com Marcelo, sócio da Revolux Energia Solar em São Carlos. Sócio Luiz (aposentado) ficou de fora. A reunião teve um ritmo invertido: o cliente abriu dizendo "tô tranquilo, não quero crescer" e o Matheus passou metade da call procurando dor pra se agarrar. A Drea entrou no meio segurando o frame com Mar Azul + linha linear, mas a oferta apresentada (prospecção ativa B2B com a secretária) bateu de frente com uma tentativa anterior que o próprio cliente já tinha desistido. Marcelo recuou no fim ("não tinha pretensão de investimento esse ano, vou conversar com o Luiz"). R2 marcada mas frágil.

> [!info] Resultado e diagnóstico geral
> Não foi uma R1 perdida, mas faltou o que o Nimoto chama de **destino verbalizado pelo cliente**. O Matheus tentou rotular volatilidade como dor, mas Marcelo nunca disse "isso é meu problema". A R2 vai entrar morna se não houver reframe entre uma reunião e outra.

---

## Bloco 1 — Abertura e contexto da terceirização

> "Hoje nosso tudo terceirizados né, eu acho que não é novidade pra qualquer uma. (...) o calcanhada de aquilizado de qualquer empresa é a mão de obra."

**Conceito:** cliente abrindo voluntariamente uma dor estrutural (mão de obra).
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real:** Marcelo está dizendo que **não tem alavanca operacional pra crescer mesmo se quisesse**. Esse é o constraint real, não a "volatilidade".

---

> "Eu já aconteceu lá em 2019... 2020 com a pandemia eu cheguei a bancar durante seis meses sem instalar, sem nada funcionários. Depois daquilo a gente mandou todo mundo embora."

**Conceito:** trauma do passado plantando objeção futura ("crescer = risco de quebra").
**Aula:** Imersão [322:00] — *"Eu quero ver meu cliente triste."* — mas aqui a tristeza é **sobre crescer**, não sobre estagnar.
**Por que importa:** todo pitch que envolva "estrutura", "contratação", "expansão" vai bater nesse trauma. O Matheus precisa vender **crescimento sem estrutura nova**.

---

## Bloco 2 — Transição malfeita pra meta

> Matheus: "É um dos seus desafios mesmo é a questão da mão de obra. E a meta, o que que tu quer alcançar em 2026 com a Revolux, onde vocês querem chegar?"

**Conceito:** pergunta de S (Sell the Vacation) sem ter passado pelo L e O do CLOSER.
**Aula:** [[closer-perguntas-oficiais]] — etapa **Label** ("dê nome ao problema, faça o cliente repetir em voz alta") foi pulada.
**Por que falhou:** Matheus pulou direto pra "qual o destino?" sem rotular nenhuma dor. Resultado: o cliente respondeu "não quero chegar a lugar nenhum, tô tranquilo". O destino não pode ser perguntado antes da dor estar instalada.

---

> Marcelo: "Estranho falar né mas assim conta pra nós tá tranquilo. Eu como o Luís a gente não quer aumentar mais do que isso. (...) A gente nem chegou a pensar em aumentar de 15 pra 20 por mês."

**Movimento:** cliente verbaliza o **anti-destino**. É o oposto do que Falante 2 da V4 fez ("quero chegar em 50/50 inbound/outbound"). Aqui o destino dele é **manter**.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [30:37] — *"A gente sempre vende o destino final."*
**Por que importa:** a partir desse momento, **vender crescimento = perder a venda**. Toda a R1 dali pra frente teria que ser sobre **proteger o que ele tem**, não sobre aumentar.

---

## Bloco 3 — Drea entra e segura o frame

> Drea: "A pessoa que não fecha com a gente, falando bem a verdade, muitas vezes não é preço. (...) o retorno dele tá em um ano e meio."

**Conceito:** prova social aplicada à objeção de mercado, não à venda.
**Aula:** Call 1 [76:53] — autoridade por demonstração de domínio do nicho.
**Por que funciona:** a Drea entra mostrando que **conhece o jogo do cliente melhor do que ele esperava**. Plantou autoridade sem dizer "sou autoridade".

---

> Drea: "Energia solar é um ativo, nunca vai ser um passivo pra ele."

**Conceito:** reframe que o **cliente vai usar pra vender pros próprios clientes** = entrega de valor já dentro da R1.
**Aula:** Call 1 [47:29] — *"Você precisa bater numa barreira lógica para que ele mesmo justifique a compra."*
**Por que funciona:** Marcelo concordou ("a gente ganha muito nessa argumentação"). A Drea acabou de entregar uma munição comercial gratuita = reciprocidade real (Call 1 [48:38]).

---

## Bloco 4 — Matheus tenta cavar a dor

> Matheus: "Tô falando, eu vou cara vou tendo autoavaliações aqui também. (...) Eu me perguntei: por que que ele não olhou aí? Eu queria saber de você, por que vocês não olharam?"

**Conceito:** vulnerabilidade tática pra abrir o cliente.
**Aula:** Call 1 [48:38] — reciprocidade real ("eu também passei por isso").
**Por que funciona PELA METADE:** quebra o gelo, mas **não é uma pergunta da tríade**. Ele perguntou "por que não cresceram?" em vez de "o que vocês já tentaram pra crescer? Por que falhou? Por quanto tempo? Quanto perderam?". Faltou o **O do CLOSER** ([[closer-perguntas-oficiais]]).

---

> Marcelo: "Luiz é aposentado e ele entrou nesse investimento como algo paralelo. Eu tenho minha outra empresa, a Madrid. Não é principal fonte de renda do Luiz, nem a minha. A gente não é aquela pessoa alucinada em dominar o mercado."

**Movimento:** cliente entrega de bandeja **a verdadeira intenção**: a Revolux é hobby de luxo, não negócio principal. O destino dele não é faturamento, é **autonomia operacional sem dor de cabeça**.
**Aula:** Call 1 [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real:** "Quero que isso aqui continue rodando sozinho, dando dinheiro, sem me obrigar a contratar e sem risco de quebrar como em 2020."
**Esse é o ouro da R1 e o Matheus passou batido.** Era pra ter parado tudo e rotulado: *"Marcelo, então pra ti não é sobre crescer, é sobre proteger o que já funciona com o mínimo de envolvimento teu, certo?"*

---

> Marcelo: "A demanda fecha conta. Pra aumentar demanda tem que aumentar estrutura, eu não quero aumentar estrutura porque tenho problema com funcionário que pede a conta sem avisar."

**Conceito:** cliente desenhou a equação dele com clareza cirúrgica.
**Aula:** Imersão [208:30] — Equação do Valor (Esforço/Sacrifício no denominador).
**Como ler:** o **denominador da equação dele é GIGANTE**. Qualquer oferta que aumente esforço vai ser rejeitada. Qualquer oferta que **mantenha resultado e diminua esforço** vai ser aceita. **Esse era o ângulo certo da venda.**

---

## Bloco 5 — Momento chave: Matheus abre a guarda

> Matheus: "Qual seria o pilar que a gente conseguiria ajudar vocês? Porque é melhor, é mais fácil. Eu acho que eu não consegui chegar numa resposta tentando te entender."

**Conceito:** vulnerabilidade real (não tática). Matheus admite que não sabe.
**Aula:** —
**Por que falhou:** isso é o **oposto** do que o Nimoto ensina. Quem pergunta domina (Imersão [116:46]). Devolver a pergunta pro cliente é entregar o controle. O cliente respondeu **com outra pergunta** ("qual o seu segmento?") porque sentiu o vácuo.
**Crítica honesta:** essa frase mostra que o Matheus entrou na R1 sem hipótese pré-formada. Faltou pesquisa prévia (Imersão [73:30]).

---

> Marcelo: "Qual o segmento exato de vocês hoje?"

**Movimento:** cliente assume o controle da call. **Inversão de quem pergunta.**
**Aula:** Imersão [116:46] — *"Quem faz as perguntas está no controle da conversa."*
**Como ler:** a partir desse ponto, o Matheus e a Drea precisaram **vender o serviço deles**, não diagnosticar o cliente. Mudou de R1 pra apresentação, sem terem terminado o diagnóstico.

---

## Bloco 6 — Drea reposiciona com Mar Azul

> Drea: "A gente entra na Revolux e te coloco no mar azul do seu setor. Mar azul é você sair da concorrência, sair da comparação de preço. Seu cliente parar de ver você como empresa de energia solar e começar a ver você como especialista do setor dele."

**Conceito:** Big Idea + Blue Ocean.
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] (Blue Ocean) + R1/R2 [193:14] — *"Vende o destino, não a passagem."*
**Por que funciona:** É o melhor frame da R1 inteira. A Drea **renomeou o jogo**. Mas faltou amarrar isso ao destino real do Marcelo (proteção, não crescimento). Ficou abstrato.

---

> Drea: "Hoje a capacidade sua é entre 10 a 15 projetos fixos por mês. A gente conseguiria estar ajudando vocês a sair dessa volatilidade ou mesmo manter uma linha linear. Se você manda a linha linear você já tá aumentando o faturamento sem preço."

**Conceito:** reframe genial. **Tira "crescimento" da equação e coloca "estabilidade".**
**Aula:** R1/R2 [30:37] — destino final.
**Por que funciona:** isso é o **único pitch que cabe no perfil dele**. Marcelo não quer crescer, mas quer parar de oscilar. **Esse é o destino real que devia ter sido amarrado a partir daqui em diante.**
**Onde travou:** em vez de fazer o Marcelo **verbalizar** "sim, é isso que eu quero", ela continuou pitchando. Faltou silêncio + confirmação.

---

## Bloco 7 — Eletropostos: cliente verbaliza desejo real

> Marcelo: "Eletropostos, é uma coisa que a gente quer começar a focar nessa parte. A ideia nossa é a parceria, você reserva uma vaga de um restaurante, coloca um carregador, cobra um valor."

**Movimento:** cliente verbaliza **um destino que ele já tem na cabeça mas ninguém ofereceu pra ele ainda**. Isso é mais quente que volatilidade.
**Aula:** R1/R2 [30:37] — *"A gente sempre vende o destino final."*
**Como ler:** **eletroposto é o destino emocional do Marcelo, não prospecção ativa.** Ele falou disso animado, com história pronta, com modelo de negócio na ponta da língua. **Esse é o ângulo que entra na R2.**
**Onde travou:** Drea/Matheus tocaram no assunto mas não amarraram. Voltaram pra "açougues em São Carlos". Erro.

---

## Bloco 8 — Pitch da prospecção ativa (com tela do Google)

> Drea: "Olha minha tela aqui, é São Carlos. Açougues em São Carlos. Olha o tanto de oportunidade que você tem na tua cidade."

**Conceito:** demonstração visual de mercado disponível.
**Aula:** Imersão [94:30] — viés de certeza via demonstração.
**Por que funciona pela metade:** mostrar a lista é forte, mas o exemplo "açougue" é fraco emocionalmente pra quem fala em eletroposto e parceria com restaurante. **Errou o avatar do exemplo.**

---

> Drea: "Você se vende como especialista. Liga com o intuito de marcar uma visita."

**Conceito:** pitch da metodologia.
**Aula:** R1/R2 [11:01] — terceira parte da tríade ("como eu resolvo isso").
**Por que falhou no contexto:** Marcelo já tentou e desistiu. **A oferta entrou batendo de frente com uma experiência ruim que ele não tinha nem rotulado ainda.**

---

## Bloco 9 — Cliente quebra a oferta (e ninguém intercepta)

> Marcelo: "A gente parou de fazer isso porque a gente pagava uma pessoa. Ela ficava ali procurando, ligando e agendando visita. Mas como começou a entrar várias indicações e teve um volume legal, a gente parou. (...) De 10 ligações, 2 deu certo, marcava a visita. Mas quando a gente vai lá pra explicar o serviço, mostrar muita coisa, não tinha interesse. **É muito diferente da indicação. Nunca vai ser igual a indicação.**"

**Movimento:** cliente acabou de **destruir o pitch da Drea com a própria experiência dele**. Ele não está abstratamente cético, ele já viveu isso e desistiu.
**Aula:** Call 1 [122:00] — *"Não bata de frente. Concorde, contorne, sugira."*
**Resposta certa que faltou:** *"Marcelo, faz total sentido. Indicação fecha 98%, prospecção fecha 20%. Concordo. **Mas o objetivo da prospecção não é substituir indicação, é segurar você nos meses ruins.** Você fechar 2 vendas comerciais de R$30k em vez de 6 residenciais de R$15k é o mesmo dinheiro com menos esforço da tua estrutura."*
**O que rolou:** Matheus fez parte desse reframe ("braço comercial te traz previsibilidade") mas sem usar a frase do Marcelo de volta. Faltou o **E do CLOSER** com 3As.

---

## Bloco 10 — Tentativa de fechamento

> Drea: "Só em prospecção ativa a gente conseguiu gerar mais de 119 reuniões com empresários só ligando no telefone, com duas horas por dia, em torno de 50 ligações por dia."

**Conceito:** prova social numérica.
**Aula:** Call 1 [67:47] — *"O maior prova social é o compromisso sério. Abre o CRM e mostra."*
**Por que funciona pela metade:** o número é forte, mas chegou tarde demais. **Devia ter sido plantado lá no Bloco 1, não no fechamento.**

---

> Marcelo: "A gente não tinha pretensão nenhuma assim de investimento e distância do negócio esse ano pra falar bem a verdade. Eu vou conversar com Luiz. (...) Vai ter eleições, várias coisas."

**Movimento:** cliente verbaliza **objeção de tempo + objeção de decisor + objeção de macroeconomia** em uma só frase. Recuo claro.
**Aula:** Call 1 [122:00] — bater de frente perde.
**Resposta certa que faltou:** isolar **uma** objeção. *"Marcelo, sobre o Luiz a gente alinha na próxima reunião. Sobre eleições, deixa eu te perguntar uma coisa: se a gente fosse começar **hoje**, em 90 dias você teria seu primeiro fechamento comercial pré-eleição. Faz sentido eu te mostrar como na quinta?"*

---

> Matheus: "A gente não quer expandir super mega empresa. Aproveitar o que vocês fazem. Trazer projeto comercial de 90 placas, R$25-30k em 3 dias = mais ganho em menos tempo, libera engenheiros, sem contratação, sem folha. Qualidade de cliente, não crescimento."

**Conceito:** reframe final brilhante. **Bate exatamente no perfil do Marcelo.**
**Aula:** Imersão [208:30] — Esforço/Sacrifício baixo.
**Por que importa pra R2:** **esse parágrafo é o pitch certo da R2.** Devia ter sido a abertura, não o fechamento. **Decora isso e abre a R2 com isso.**

---

## Bloco 11 — Saída

> Matheus: "Não no intuito de vender, trazer uma proposta, aquela reunião pesada. A gente bate um papo com o Luiz. (...) A gente fala lá no início que não precisa comprar nada da gente, pode guardar a carteira."

**Conceito:** desarmar a R2.
**Aula:** R1/R2 [13:18] — encerramento R1.
**Por que funciona pela metade:** baixou a guarda do Marcelo, mas **enfraqueceu a próxima reunião**. Se você diz "não precisa comprar nada", o Luiz entra com expectativa de **bate-papo**. Vai ser muito mais difícil pedir cartão.
**Crítica:** o Nimoto ensina o oposto — *"posso contar com uma resposta na próxima reunião?"* (Call 1 [64:43]). Compromisso emocional explícito. Aqui foi o oposto: compromisso explícito de **não cobrar resposta**.

---

## Mapa-resumo

| Movimento da reunião | Conceito | Aula | Status |
|---|---|---|---|
| Cliente abre dizendo "tô tranquilo, não quero crescer" | Anti-destino verbalizado | R1/R2 [30:37] | ⚠️ Matheus não reposicionou |
| Cliente revela "Revolux é renda paralela, Luiz aposentado" | Intenção real (proteção, não crescimento) | Call 1 [80:24] | ❌ Não rotulado |
| Drea entra com "energia solar é ativo, não passivo" | Reciprocidade real + munição comercial | Call 1 [48:38] | ✅ |
| Matheus admite "não consegui chegar numa resposta" | Quem pergunta domina (invertido) | Imersão [116:46] | ❌ Cedeu controle |
| Drea: "te coloco no mar azul" | Big Idea + Blue Ocean | Fundamentos | ✅ Frame forte |
| Drea: "manter linha linear sem aumentar preço" | Reframe estabilidade > crescimento | R1/R2 [30:37] | ✅ Mas não amarrou |
| Cliente verbaliza "eletroposto" com história pronta | Destino emocional real | R1/R2 [30:37] | ❌ Ignorado |
| Drea pitcha açougues em São Carlos | Demonstração visual | Imersão [94:30] | ⚠️ Avatar errado |
| Cliente: "já tentei prospecção, parei, indicação é diferente" | Cliente destrói oferta com experiência própria | Call 1 [122:00] | ❌ Sem 3As |
| Drea: "119 reuniões com 2h/dia" | Prova social numérica | Call 1 [67:47] | ⚠️ Tarde demais |
| Cliente: "não tinha pretensão, eleições, vou falar com Luiz" | Objeção tripla | Call 1 [122:00] | ❌ Sem isolamento |
| Matheus: "qualidade de cliente, não crescimento" | Reframe perfeito | Imersão [208:30] | ✅ Mas no fim |
| "Não precisa comprar nada, pode guardar a carteira" | Desarmar R2 | R1/R2 [13:18] | ⚠️ Enfraqueceu fechamento |

### Score CLOSER

| Letra | Status | Por que |
|---|---|---|
| **C** — Clarity | ⚠️ | Não perguntou "por que aceitou essa reunião?" |
| **L** — Label | ❌ | Nunca rotulou a dor com nome próprio. "Volatilidade" foi tentada mas o cliente não confirmou |
| **O** — Overview | ❌ | Tríade incompleta. Não explorou trauma de 2020, não perguntou "quanto perdeu na pandemia?" |
| **S** — Sell the Vacation | ⚠️ | Drea acertou com "linha linear" mas pitchou prospecção em vez de eletroposto |
| **E** — Explain Away | ❌ | Cliente verbalizou 3 objeções no fim e ninguém isolou |
| **R** — Reinforce | ❌ | "Pode guardar a carteira" é o oposto do reforço |

---

## ⚠️ Onde Matheus e Drea falharam no próprio framework

**1. Não rotularam a dor com nome próprio.** Marcelo entregou de bandeja a fala "Revolux é renda paralela, Luiz é aposentado, não somos perfil agressivo". Isso É o problema. Devia ter virado: *"Marcelo, então o que tá em jogo aqui pra ti não é faturamento. É **autonomia operacional** — manter a Revolux rodando sem te obrigar a entrar dentro dela. Certo?"* Faltou o **L do CLOSER** ([[closer-perguntas-oficiais]]). Sem isso, todo pitch dali pra frente foi chute.

**2. Pitcharam o destino errado.** Marcelo verbalizou eletroposto com história pronta, modelo de negócio, animação na voz. Drea/Matheus voltaram pra prospecção de açougues. **Eletroposto era o destino emocional, prospecção era o voo.** Vendeu-se a passagem em vez do destino (Imersão [193:14]).

**3. Não usaram 3As quando o cliente destruiu a oferta.** Quando Marcelo disse *"prospecção nunca vai ser igual a indicação"*, devia ter vindo "concordo, contorno, sugiro": *"Concordo, indicação é melhor. Mas indicação não te protege nos meses de 5 vendas. Sugiro a gente desenhar prospecção só pra cobrir o piso, não pra substituir indicação."* Em vez disso, vieram com mais provas (119 reuniões) — bater de frente em afirmação do cliente (Call 1 [122:00]).

**4. Cederam o controle no momento "qual seria o pilar?".** Faltou pesquisa prévia (Imersão [73:30]). Matheus entrou na R1 sem hipótese sobre o que oferecer. Quando admitiu isso em voz alta, virou consultor pedindo briefing em vez de vendedor diagnosticando.

**5. Desarmaram a R2 com "pode guardar a carteira".** O Nimoto ensina o oposto: compromisso emocional explícito (Call 1 [64:43]). Entrar na R2 sem cobrança de resposta = R3 garantida ou perda do lead.

---

## 🎯 O destino real do Marcelo (pra calibrar a R2)

**Ele NÃO quer:**
- Crescer faturamento
- Aumentar estrutura
- Contratar gente
- Investir agressivamente
- Virar grande empresa

**Ele QUER (mesmo sem ter falado todas com essas palavras):**
- Que a Revolux continue rodando dando dinheiro **sem ele se envolver mais do que hoje**
- Que pare de oscilar entre 5 e 20 vendas/mês (volatilidade tira o sono dele, mesmo que ele finja que não)
- **Substituir vendas residenciais chatas por vendas comerciais maiores** (mesma estrutura, mais ticket)
- **Entrar em eletropostos** (mercado novo, ticket alto, narrativa de pioneirismo — ele se anima)
- Ter argumento contra a concorrência de importadores baratos

### Ponto B (destino que cabe no perfil)

> "Em 6 meses a Revolux vira **a empresa de eletropostos e solar comercial de São Carlos**, com piso de faturamento estável (mínimo 10 projetos/mês garantidos), sem ter contratado um único engenheiro novo, mantendo o time PJ atual. O Marcelo trabalha menos, ganha o mesmo ou mais por projeto, e o Luiz vê a Revolux deixar de ser hobby e virar autoridade local sem ter virado dor de cabeça."

### Caminho A → B (3 passos pra R2)

1. **Trocar mix de cliente, não aumentar volume.** Em vez de 15 residenciais de R$15k/mês, mirar 3-5 comerciais de R$25-30k. Mesma capacidade dos engenheiros PJ, ticket 2x.
2. **Posicionar Revolux como especialista em eletroposto + comercial em São Carlos.** Ângulo que ele já quer. A LM entra como quem operacionaliza o posicionamento (não como quem traz "leads de açougue").
3. **Prospecção ativa só pra cobrir o piso (3-5 reuniões/semana, não 50 ligações/dia).** Usar a secretária dele 2h/dia. Discurso: "não é pra substituir indicação, é pra garantir que mês ruim não exista mais."

---

## Aplicação na R2 (quinta com Luiz)

- [ ] **Abrir com o reframe que o Matheus achou no fim**: "qualidade de cliente, não crescimento. Liberar engenheiros, não contratar. Mais ganho em menos tempo." Esse é o pitch certo, em 3 linhas.
- [ ] **Rotular o problema com nome próprio na primeira fala**: "Marcelo me contou que pra vocês a Revolux é uma operação que tem que rodar sem dor de cabeça. Vou chamar isso de **operação de autonomia**. Concordam com esse rótulo?"
- [ ] **Trazer eletroposto como ângulo principal, não prospecção de açougue.** Marcelo entregou esse desejo de bandeja. Amarrar: "vocês querem entrar em eletroposto, a gente faz vocês entrarem como **a referência da cidade** antes da concorrência acordar."
- [ ] **Tríade completa sobre 2020**: "Quando vocês mandaram todos embora na pandemia, quanto perderam? Por quanto tempo bancaram funcionário sem instalação? Como foi a sensação?" — instalar a dor da volatilidade via memória do trauma.
- [ ] **3As preparados pras objeções já conhecidas**: "indicação fecha melhor", "já tentei prospecção", "Luiz é conservador", "ano de eleição". Cada uma tem que ter resposta de "concordo, contorno, sugiro" decorada antes de entrar.
- [ ] **Isolar decisão**: "Luiz, se a proposta fizer sentido pros dois hoje, vocês decidem aqui ou precisam de mais tempo?"
- [ ] **Compromisso emocional no fim**: "Posso contar com uma resposta hoje?" — não "guarda a carteira".
- [ ] **Não falar em "investimento" nem "expansão"**. Falar em "trocar tipo de cliente" e "garantir piso". Vocabulário do Marcelo, não vocabulário de agência.

---
tipo: análise R1
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Orion Solar (Aires dono, Fernando supervisor de vendas, Ricardo administrativo)
nicho: energia solar
resultado: R2 pré-marcada para sexta 19/06
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
---

# Análise — Matheus vendendo para Orion Solar

R1 de 55 minutos, três do lado deles: Aires (dono), Fernando (supervisor de vendas, ex-25 anos de venda de bebida, o falante e crente) e Ricardo (administrativo). Empresa de energia solar reativada pelo Aires faz cerca de um ano. Vendem por indicação e PAP, tráfego pago começando essa semana com outra agência. Produto-alvo: Ignição Comercial (pré-vendedor in-house gerando visita comercial). R2 pré-marcada pra sexta.

> [!info] Resultado e diagnóstico geral
> R1 de boa leitura mas de execução cansada. O acerto grande: tu leu que eles não precisam de mais vendedor e sim de gerador de demanda (pré-vendedor), e o Aires JÁ viveu isso funcionando (o "indicador" dele). O Fernando é teu champion interno, já tá aberto. Os erros são os de sempre, e fortes aqui: não rotulou, não enfatizou perdas que estavam na mesa (R$4k de comissão sem merecer, cara que vendeu zero em 15 dias), e despejou o modelo inteiro + teste de fogo + preço + a ideia do evento, tudo R2, dentro da R1. Call longa porque tu falou demais e deixou o Fernando monologar.

> [!note] Contexto (feedback do Matheus)
> Essa R1 foi feita ANTES do insight de encurtar a R1 (não soltar o produto inteiro, o "como funciona", e segurar pitch/preço pra R2). Por isso ela ficou longa e com o dump de modelo + teste de fogo + preço. Os erros de escopo abaixo são desse momento pré-correção. A partir do Denner (17/06) a régua já mudou. Ler com esse filtro: o que vale aqui é a leitura estratégica (pré-vendedor, Aires já validou, Fernando champion), não o tamanho/dump.

---

## Bloco 1 — Abertura, posicionamento e clareza

> "a gente da LM é focado sempre na área comercial, na prospecção, na venda ativa, não tem nada de tráfego, nada de Instagram, nada de marketing" (call [01:40])

**Conceito:** posicionamento Blue Ocean. Recorta a categoria e se separa do que eles já tentaram (tráfego).
**Aula:** Fundamentos (Blue Ocean).

---

> "eu queria entender hoje, qual o motivo que você está batendo esse papo aqui hoje? Qual a dificuldade que você tem, principalmente em vendas, time comercial?" (call [01:40])

**Conceito:** C do CLOSER feito direto.
**Aula:** R1/R2 [16:05].

---

> "a gente já investiu mais de 8 milhões em anúncios... pro nicho do solar está cada vez mais desafiador o marketing" (call [03:47])

**Conceito:** flex de autoridade, mas longo e fora de hora.
**Aula:** Call 1 [76:53] (autoridade) — porém aqui virou tangente que desviou do diagnóstico antes de entender a dor deles. Autoridade vale depois de rotular, não no lugar de escutar.

---

## Bloco 2 — Diagnóstico e a dor real

> Aires: "a maior dificuldade é formar equipe... manter uma equipe funcionando é muito difícil, todo mundo quer renda fixa mas não quer compromisso... eu fico com risco gigante de pagar fixo pro cara e ele não vender nada" (call [06:37])

**Conceito:** a dor central entregue pelo dono. Formar e manter equipe, e o risco do fixo sem retorno.
**Aula:** R1/R2 [21:49] — material puro pra rotular (não foi rotulado, ver falhas).

---

> "então o problema é equipe pra tracionar vendas, né? Seria isso?" → Aires: "isso" (call [08:50])

**Conceito:** Label descritivo, sem nome próprio nem as palavras deles.
**Aula:** R1/R2 [24:24].
**Por que falhou parcial:** o rótulo afiado era *"vocês não conseguem formar nem manter equipe, e quando têm vendedor ele não tem compromisso e ainda leva comissão sem fechar."* Ficou no genérico.

---

> Fernando: "a gente já tentou de tudo. O problema é que as pessoas querem emprego, não trabalho... abro vaga com comissão acima do concorrente, chove currículo, mas na hora do contato a pessoa demora 3 dias pra responder. Mandei mensagem na segunda, responderam na sexta" (call [10:49])

**Conceito:** o cliente entrega a dor de comprometimento/comunicação de bandeja, com exemplo concreto.
**Aula:** Call 1 [80:24] — a intenção: "tô exausto de apostar em gente que não aparece."

---

> Fernando: "eu vim de 25 anos de venda de bebida. Como você explica um cara que não conhecia nada vender 60 mil em 3 semanas? É a garra do vendedor" (call [14:18])

**Conceito:** o Fernando se posiciona como o vendedor-estrela e o crente da metodologia. É o teu champion interno.
**Aula:** Call 1 [67:47] — usa o Fernando como prova viva interna na R2.

---

## Bloco 3 — O pivô pra pré-vendas (boa leitura)

> "vocês já chegaram a tentar, em vez de trazer cara de vendas pra fazer todo o processo, trazer um cara de pré-vendas pra gerar demanda?" (call [17:11])

**Conceito:** leitura certa. Eles não precisam de mais vendedor (o Fernando fecha bem), precisam de quem gere a visita. Pivota pro pré-vendedor.
**Aula:** R1/R2 [3:53] — escolheu a trilha certa dos 225 caminhos.

---

> Fernando: "já pensei, mas o povo acha que é pouco... e eu não vou pagar comissão de vendedor pra cara ficar só indicando, não acho justo" (call [17:50])

**Conceito:** objeção de remuneração plantada. Não paga comissão cheia pra quem só marca visita.
**Aula:** R1/R2 [40:32] — objeção a contornar na R2 (a resposta é fixo + bônus, não comissão cheia). Tu já mapeou.

---

> Fernando: "a gente fechou um cliente, o vendedor foi, foi enxotado, eu e o Aires fechamos meses depois... e o cara levou quase R$4 mil de comissão sem merecer, sem fazer nada" (call [21:56])

**Conceito:** PERDA concreta verbalizada. R$4k pago a quem não trabalhou.
**Aula:** R1/R2 [9:54] — era ouro pra enfatizar a dor ("quanto vocês já pagaram de comissão pra quem não fechou?"). Passou sem amplificar (ver falhas).

---

> Aires: "eu já tentei, eu chamo de indicadores. Tinha um cara de 65-70 anos super conversador que puxava papo na fila da padaria, do banco, e indicava. Eu pagava 10% da minha comissão pra ele e fechei mais de 60 vendas com ele em meses" (call [24:07])

**Conceito:** OURO. O dono JÁ VIVEU o modelo de pré-vendedor funcionando, na versão informal dele. Prova de conceito interna.
**Aula:** Call 1 [47:29] (barreira lógica que ele mesmo justifica) + R1/R2 [30:37].
**Por que é ouro pra R2:** "Aires, você já viveu isso dar certo com o teu indicador. A gente só profissionaliza e escala o que você já provou que funciona." Esse é o coração da R2.

---

## Bloco 4 — Erro de escopo: dump do modelo, teste de fogo e preço na R1

> "o pré-vendedor pega o telefone, liga pra empresa, fala com o atendente, com o decisor, marca a visita... a gente tem dois modelos... o ICT pega 15+ visitas" (call [27:31])

**Conceito:** começa o dump do mecanismo completo na R1.
**Aula:** R1/R2 [13:18] — R1 é diagnóstico. Isso é R2.

---

> "a gente chama de teste de fogo de 45 dias, a gente tenta fazer ele desistir, fala que vai ligar meia noite, pedir relatório no domingo... o fixo a gente paga entre 1.500 e 2.100 mais comissão" (call [34:08])

**Conceito:** despejou o método inteiro do teste de fogo MAIS a faixa de preço dentro da R1.
**Aula:** Call 1 [110:48] (cobra antes de ensinar) + R1/R2 [13:18].
**Por que falhou:** entregou o mecanismo e o preço antes da R2. Esvazia a reunião de fechamento e dá pra eles montarem o teste de fogo sozinhos (o Fernando é vendedor faro, capta na hora).

---

> "a pessoa é contratada da Orion, a estrutura é de vocês, eu não gosto de trazer terceirizado, quero que você tenha controle do seu comercial... a gente faz a gestão, plano de carreira" (call [45:39])

**Conceito:** framing in-house. Bom (responde o medo de "terceirizado some"), mas é mais detalhe de R2 na R1.
**Aula:** Fundamentos. O conceito é forte, só tava na hora errada.

---

## Bloco 5 — Consultoria grátis e fechamento frouxo

> "por que vocês não chegam num bar que tá passando a Copa, pedem 15% de desconto, trazem os clientes, e no outro dia ligam pedindo indicação?... a gente vai trazer isso no evento" (call [49:33])

**Conceito:** entregou a ideia do evento da Copa com passo a passo executável completo.
**Aula:** Call 1 [110:48] — plantar a visão era gancho pro evento; entregar o how-to é dar de graça.

---

> Aires: "a gente já liga pra todos os clientes fazendo pós-venda e pedindo indicação, esse processo a gente já faz" (call [53:26])

**Conceito:** o cliente rebate a dica (já faz). Sinal de que a consultoria grátis nem agregou, só gastou tempo.
**Aula:** Imersão [116:46].

---

> Aires: "deixa eu fazer uma adenda: você vai fazer a pré-venda, me conectar com o cliente, me colocar na porta dele pra eu fechar, sem garantia de venda porque isso depende de nós" (call [44:46])

**Conceito:** o dono resume o modelo perfeitamente e sozinho. Sinal verde forte, ele entendeu e comprou a lógica.
**Aula:** R1/R2 [30:37] — ele verbalizou o destino. Aproveita isso na R2.

---

> "deixa pré-marcado quarta ou sexta, e aí eu mando a mensagem no grupo confirmando" (call [44:27])

**Conceito:** R2 frouxa, sem data travada, ônus de confirmar jogado pro cliente.
**Aula:** R1/R2 [13:18] — encerramento pede data e hora firmes.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Não é tráfego, é comercial" | Posicionamento Blue Ocean | Fundamentos |
| "Qual o motivo de você estar aqui?" | C do CLOSER | R1/R2 [16:05] |
| "8 milhões em anúncios" | Autoridade fora de hora | Call 1 [76:53] |
| Aires: "não consigo formar nem manter equipe" | Dor central (não rotulada) | R1/R2 [21:49] |
| "O problema é equipe pra tracionar, né?" | Label descritivo | R1/R2 [24:24] |
| Fernando: "mandei segunda, responderam sexta" | Dor de comprometimento | Call 1 [80:24] |
| Pivô pra pré-vendedor | Trilha certa | R1/R2 [3:53] |
| Fernando: "vendedor levou R$4k sem merecer" | Perda concreta (não enfatizada) | R1/R2 [9:54] |
| Aires: "fechei 60 vendas com meu indicador" | Dono já validou o modelo | Call 1 [47:29] |
| Dump do teste de fogo + preço | Escopo de R2 na R1 | R1/R2 [13:18] |
| Ideia do evento da Copa em detalhe | Consultoria grátis | Call 1 [110:48] |
| Aires resume o modelo sozinho | Cliente verbaliza o destino | R1/R2 [30:37] |
| "Deixa pré-marcado quarta ou sexta" | R2 frouxa | R1/R2 [13:18] |

---

## Decisões estratégicas de escopo / camada

**Produto-alvo:** Ignição Comercial, na camada pré-vendedor in-house (teste de fogo 45 dias + gestão).
**Por que essa camada:** eles têm vendedor que fecha (o Fernando é fera), o que falta é geração de demanda. Pré-vendedor é a peça exata. E o dono já validou o conceito na versão informal (o indicador de 60 vendas).

**Os dois ativos a usar na R2:**
1. **O sucesso do Aires (o indicador).** "Você já viveu isso funcionando, a gente só escala e profissionaliza."
2. **O Fernando como champion.** Ele já tá vendido ("é válido"), é ex-vendedor e o Aires confia nele. Deixa o Fernando puxar pelo seu lado.

**A objeção já mapeada:** não paga comissão cheia pra quem só marca. A resposta é fixo (1.500-2.100) + bônus, nunca comissão de vendedor. Já alinhado.

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não rotulou.** A dor riquíssima (não forma nem mantém equipe, vendedor sem compromisso, comissão paga a quem não fecha) nunca virou um rótulo nomeado e confirmado. Ficou em "problema de equipe". R1/R2 [21:49] e [24:24].

**2. Tríade sem enfatização, com perdas na mesa.** O Fernando te deu duas perdas concretas (R$4k de comissão sem merecer, cara que vendeu zero em 15 dias) e tu não amplificou. Era pra doer: "quanto vocês já queimaram pagando e treinando gente que não entregou?" R1/R2 [9:54].

**3. Dump de modelo, teste de fogo e preço na R1.** O mecanismo inteiro e a faixa de preço (1.500-2.100) saíram na R1. Isso é a R2. Esvaziou a reunião de fechamento. R1/R2 [13:18] e Call 1 [110:48].

**4. Consultoria grátis (o evento).** A ideia do evento da Copa entregue com passo a passo, e o Aires ainda rebateu que já faz pós-venda/indicação. Tempo gasto sem agregar. Call 1 [110:48].

**5. Deixou o Fernando monologar e perdeu o controle do tempo.** A call foi a 55 min muito por causa dos monólogos não conduzidos. Rapport é bom, mas quem pergunta conduz. Imersão [116:46].

---

## 🎯 Destino pra R2 (pré-marcada sexta 19/06)

Multi-decisor: Aires decide, Fernando influencia forte e já tá comprado. Eles já ouviram o modelo todo, então NÃO repete o mecanismo. A R2 é amarrar no sucesso do Aires e fechar.

**C — Recap:**
> "Aires, Fernando, Ricardo, desde terça o ponto continua o mesmo: vocês não precisam de mais vendedor, o Fernando fecha bem. Falta quem gere a visita comercial constante. Continua sendo isso?"

**L — Crava o rótulo:**
> "O problema de vocês nunca foi vender, é alimentar o funil. Vocês queimam tempo e dinheiro tentando formar vendedor que não tem compromisso, e quando aparece um, ele às vezes leva comissão sem nem fechar. Falta uma máquina que entregue a visita pronta pro Fernando converter."

**O — Urgência (usa as perdas que eles deram):**
> "Você me falou do vendedor que levou R$4 mil sem fechar, e do cara que vendeu zero em 15 dias. Quanto vocês já queimaram nisso? E quantas vendas comerciais deixaram de fazer por não ter quem prospecte?"

**S — Sell the Vacation (ancora no que o Aires já viveu):**
> "Aires, você já fez isso dar certo com o teu indicador, 60 vendas pagando 10% da tua comissão. A diferença é que aquilo dependia de um senhor de 70 anos na fila da padaria. A gente profissionaliza isso: um pré-vendedor in-house, contratado da Orion, gerando 10 a 20 visitas comerciais por mês, ticket alto, pro Fernando fechar. A estrutura é de vocês."
Sem reabrir teste de fogo passo a passo. Mostra o projeto formatado.

**E — Quebra de objeção:**
- Comissão: "não é comissão cheia de vendedor. É fixo + bônus por visita e por venda. Você não paga 5% pra quem só marca."
- Risco de contratar errado: "é pra isso que existe o teste de fogo, a gente filtra antes de você bancar."
- "Já faço pós-venda/indicação": "isso é manter quem já é cliente. A prospecção é trazer cliente comercial novo que você nunca alcançou."

**R — 3 perguntas antes do preço:**
1. "Vocês acreditam que um pré-vendedor dedicado gera visita comercial qualificada?" (o Aires já sabe, viveu)
2. "Acreditam que funciona pra Orion, com o Fernando fechando?"
3. "Acreditam que a gente é quem monta e mantém isso de pé com vocês?"

**Preço:** ancora no ticket comercial (2 vendas comerciais altas pagam o projeto com folga). Trava a decisão no dia, e usa o Fernando como acelerador interno.

**Cuidados:** não repete o mecanismo (já ouviram). Deixa o Fernando falar a favor. Trava data e fecho.

---

## Documentos relacionados
- [[2026-06-16 — Apanhado geral das R1 (padrões)]]
- [[2026-06-17 — Matheus vs Denner (Termo Clima) (R1)]]
- [[Mentoria Nimoto — Índice]]

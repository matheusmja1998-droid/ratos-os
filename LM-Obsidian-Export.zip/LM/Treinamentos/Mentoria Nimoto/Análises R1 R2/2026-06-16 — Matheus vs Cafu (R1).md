---
tipo: análise R1
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Cafu (Nalla Energia Solar, Caxias do Sul)
nicho: energia solar / advocacia agronegócio (esposa)
resultado: R2 a marcar (três vias com a esposa) + convite evento Copa quinta
tags: [mentoria, nimoto, r1, análise]
fontes:
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Mentoria Nimoto — Fundamentos Comercial]]"
---

# Análise — Matheus vendendo para Cafu (Nalla Energia Solar)

R1 de 52 minutos com o Cafu, dono da Nalla Energia Solar em Caxias do Sul. 22 anos de elétrica, ~500 obras solares, opera 100% sozinho depois que o irmão (sócio/vendedor) deu um golpe (superfaturava obras, embolsou R$17k numa só). Teve infarto em 2022 de tanta pressão e perdeu ~R$200k num restaurante. Quer ficar solo, enxuto e SEM volume. Produto-alvo original (SDR comercial pro solar) não encaixou. A oportunidade real apareceu no meio: a IA pra advocacia da esposa (agronegócio, dívida rural).

> [!info] Resultado e diagnóstico geral
> Boa call de DESCOBERTA, fraca de CLOSER. O grande acerto foi desqualificar com honestidade o que não servia (SDR e IA pro solar) e achar a oportunidade real (a esposa). Isso gerou confiança real ("isso é papo sério, transparente"). Os erros: deixou o Cafu impor o frame e nunca fez o C, não rotulou a dor da esposa, não fez tríade, entregou a estratégia de brand de graça, e no fim amoleceu na objeção da crise endossando o adiamento, quando tinha na mão o melhor reframe da call (o nicho da esposa CRESCE na crise).

---

## Bloco 1 — Abertura e o cliente impõe o frame

> "legal você ter topado aqui essa consultoria... deixa eu te perguntar se você conseguiu participar do nosso evento, o que tu achou?" (call [03:11])

**Conceito:** abertura via evento (rapport), mas ainda não é a pergunta de clareza.
**Aula:** R1/R2 [16:05].

---

> "eu tenho três perguntas para te fazer. Como funciona? Quanto vai me custar? E qual o retorno que eu vou ter? Isso que eu preciso saber" (call [05:56])

**Conceito:** o CLIENTE impõe o frame e a agenda. Entra como comprador racional avaliando, não como dor latente.
**Aula:** Call 1 [80:24] — *"não é o problema que ele fala, é a intenção."* Intenção: "me prova rápido se vale meu dinheiro."
**Por que importa:** aqui o Matheus tinha que decidir entre seguir o frame de comprador ou retomar com o C. Ele seguiu, e perdeu a chance de conduzir.

---

> "a gente trabalha focado na área comercial dos integradores solares... prospecção ativa... gerar demanda de clientes comerciais (padaria, açougue, supermercado, academia)... aqui a parte de valor a gente tem de R$500 a R$20.000... pode gerar de 15 a 20 visitas por mês" (call [06:11])

**Conceito:** entrega da metodologia + Blue Ocean, e já responde as 3 perguntas (preço e retorno) na abertura.
**Aula:** R1/R2 [16:05] (metodologia) + [13:18] (R1 é diagnóstico, preço é R2).
**Por que falhou parcial:** soltou faixa de preço (R$500-20k) e projeção (15-20 visitas) na R1. Foi meio forçado (o Cafu exigiu), mas ancorou cedo e vago. Faixa de preço larga assim confunde mais que ajuda.

---

## Bloco 2 — A história do Cafu (movimentos do prospect)

> "esse ano eu descobri que ele [o irmão] estava superfaturando as obras pra pegar uma grana a mais... ele faturou pra ele 17 mil reais numa obra" (call [~22:00])

**Conceito:** o cliente entrega a ferida central (traição do sócio/irmão). Dor profunda, define a tese de "solo".
**Aula:** Imersão [322:00] (a dor dele). Matheus só empatizou ("caraca"), não minerou.

---

> "tive infarto em 2022 por causa disso... fiquei 12 dias no hospital... era pressão demais" (call [~23:00])

**Conceito:** custo físico/emocional da operação. Reforça o medo de crescer.
**Aula:** Call 1 [80:24] (intenção: proteger a saúde e o controle).

---

> "nessa brincadeira do restaurante eu acho que perdi uns 200 mil... hoje eu tô perdendo sozinho, acho que é a melhor coisa que tem" (call [~28:00])

**Conceito:** trauma de sociedade + perda de capital. Objeção futura plantada (medo de investir e perder).
**Aula:** R1/R2 [40:32] — vira a objeção da R2 ("e se eu fizer e não der certo?").

---

> "eu consigo tocar sozinho tranquilamente... eu não quero também mais tanto volume... negócio mais enxuto" (call [~30:00])

**Conceito:** o cliente CRAVA que não quer crescer, contratar nem volume. Desqualifica o produto solar de cara.
**Aula:** Imersão [116:46] (escutar o que ele realmente quer). Sinal claro: o SDR comercial não serve.

---

## Bloco 3 — Desqualificação honesta (o acerto da call)

> "pelo que você falou, você não tem tanta intenção de colocar uma pessoa pro comercial, pra aumentar venda... isso não é seu objetivo hoje, né?" (call [31:29])

**Conceito:** lê o cliente e não empurra o produto que não encaixa.
**Aula:** R1/R2 [16:05] — *"não faz sentido a gente perder tempo."*
**Por que funciona:** respeita o que o cliente quer. Não vende geladeira pra esquimó.

---

> "o problema é achar o cara bom pra isso, Jardim" (call [31:58])

**Conceito:** o cliente abre uma fresta. Ele teria interesse, SE achasse a pessoa certa.
**Aula:** Call 1 [80:24] (a intenção por trás). Aqui tinha gancho (a terceirização resolve "achar o cara"), mas o Matheus seguiu pra desqualificar.
**Por que importa:** janela de reframe deixada na mesa (ver decisões de escopo).

---

> "vamos fechar o ciclo da IA. Hoje, na sua estrutura, não tem algo que a IA te ajude a economizar... você não investe em tráfego, é bem pouco volume no WhatsApp, então não compensa pra ti" (call [32:09])

**Conceito:** desqualifica a IA pro solar com honestidade. Não vende o que não entrega valor.
**Aula:** Call 1 [48:38] (reciprocidade real) + Fundamentos (transparência).
**Por que funciona:** gera o gatilho de confiança no item seguinte.

---

> Cafu: "isso é bom, é papo sério, né, cara? O negócio é transparente" (call [33:02])

**Conceito:** a honestidade comprou a confiança do cliente. Reciprocidade real funcionando.
**Aula:** Call 1 [48:38] — *"reciprocidade é entender: cara, eu entendo como você se sente."*

---

## Bloco 4 — O pivô pra advocacia da esposa (a oportunidade real)

> "a questão de advocacia, isso aí funciona ou não?" (call [33:30])

**Conceito:** o CLIENTE puxa a oportunidade real sozinho. Movimento de ouro do prospect.
**Aula:** R1/R2 [3:53] — dos 225 caminhos, o cliente apontou a trilha certa.

---

> "minha esposa é advogada do agronegócio... colono endividado... a gente já conversou e tem a intenção de conhecer isso pra botar e você trabalhar pra ela também" (call [34:04])

**Conceito:** intenção de compra declarada, mas a compradora/usuária real (a esposa) não está na call.
**Aula:** Call 1 [98:50] — isolar/trazer o decisor. Matheus precisa dela na R2 (acertou em querer trazer).

---

> "minha esposa tá abrindo estrada sozinha, pau, pique, facão e foice... não existe advogado especializado no agronegócio... às vezes ela fica estressada, não aguento mais" (call [35:36])

**Conceito:** a dor real da oportunidade. Esposa sobrecarregada + desconhecida no nicho. Material puro pra Label.
**Aula:** R1/R2 [21:49] — era pra rotular: *"então o problema é que ela é a única no nicho, mas tá afogada e desconhecida, certo?"* Não rotulou (ver falhas).

---

> "eu penso nisso pra dar fôlego pra ela, pra ela raciocinar nos processos... que a IA trouxesse esses leads pra ela já mastigados" (call [~36:30])

**Conceito:** o cliente verbaliza o DESTINO emocional (aliviar a esposa, dar fôlego). Não é "mais leads", é tirar peso dela.
**Aula:** R1/R2 [30:37] — vende o destino. Esse é o destino a vender na R2.

---

## Bloco 5 — Consultoria grátis e volume baixo

> "pega os vídeos com mais visualização, turbina, coloca pino na cidade, raio nos agricultores, 10 reais por dia... e isso a gente chama de social sale: chega na pessoa que te seguiu, opa, tudo bom, vi que você me seguiu, me conta, você tem plantação de soja?..." (call [37:18] a [40:00])

**Conceito:** entregou a estratégia de brand + social selling com passo a passo executável. O cliente sai sabendo fazer sozinho.
**Aula:** Call 1 [110:48] — *"cobra antes de ensinar."*
**Por que falhou:** plantar a visão ("dá pra crescer ela barato com impulsionamento") era gancho legítimo de R2. Entregar o how-to completo (qual vídeo, qual raio, qual script) é consultoria grátis. Esvazia a R2.

---

> Matheus: "a parte da IA, qual o volume de demanda que ela tem por dia no WhatsApp? Se for pouca, pelo custo, talvez não vale a pena" → Cafu: "umas 5, 8 pessoas por dia, nem todo mundo fecha" (call [40:00] a [41:11])

**Conceito:** honestidade de novo, mas revela que a IA sozinha é fraca (volume baixo). O caminho real é brand primeiro (gerar volume), IA depois.
**Aula:** R1/R2 [37:13] — esforço/retorno. Vender IA em 5-8/dia tem ROI ruim. Sequência certa: crescer volume, depois automatizar.

---

## Bloco 6 — Objeção da crise e o amolecimento

> Matheus apresenta o modelo: "teste de fogo de 45 dias, comissão agressiva, depois PJ fixo + bônus... mas pra isso preciso saber se você tá disposto a abrir essa possibilidade do comercial, porque na estrutura atual eu não consigo te ajudar... tá disposto ou fechado?" (call [41:51] a [43:45])

**Conceito:** apresenta o modelo de SDR que ele MESMO já tinha desqualificado dois blocos antes. Confunde o foco.
**Aula:** R1/R2 [13:18]. Misturou o produto que não serve com a oportunidade real (a esposa). Devia ter travado só na advocacia.

---

> "tá uma crise por causa desse governo, ninguém tá investindo, tá todo mundo parado... minha preocupação é fazer esse trabalho e não gerar resultado... aulas custam dinheiro, onde tu erra no investimento tu não vê mais aquela grana" (call [43:45] a [47:11])

**Conceito:** objeção macro (medo de investir na crise) + trauma dos R$200k. O cliente projeta o medo.
**Aula:** R1/R2 [40:32] (a objeção real) + Call 1 [122:00] (não bater de frente, mas reframar).
**O reframe que faltou:** a advocacia da esposa é COUNTER-cíclica. Quanto pior a crise, mais colono endividado, mais demanda pra ela. O próprio Cafu disse *"36 se enforcaram por dívida"*. A objeção "crise, não vou investir" NÃO se aplica ao negócio dela. Era a hora de virar: *"no solar eu até concordo que o cliente segura. Mas o trabalho da tua esposa é o oposto, ele EXPLODE na crise. Investir nela agora é pegar a onda na subida."* O Matheus tinha o contra na mão e não usou.

---

> Matheus: "se tu julgar necessário, te espero até setembro, não tem problema, vou tá em follow-up de qualquer jeito" (call [48:11])

**Conceito:** amoleceu e endossou o adiamento em vez de reframar.
**Aula:** Call 1 [88:50] — *"trago a escassez que é real dele."* Aqui ele tirou a urgência em vez de criá-la.
**Por que falhou:** "te espero até setembro" dá permissão pro cliente procrastinar. Em cima de um cara já medroso de investir, isso quase fecha a porta.

---

## Bloco 7 — Fechamento

> "a gente pode marcar o segundo bate-papo, você traz ela, conversa nós três... e eu trago a formatação comercial pra ti... me manda hoje os horários que batem a agenda de vocês dois" (call [48:11] a [49:04])

**Conceito:** marca R2 (três vias com a esposa), mas sem data firme. Deixa o ônus de agendar no cliente.
**Aula:** R1/R2 [13:18] — encerramento clássico pede DATA específica, não "me manda os horários".
**Por que falhou parcial:** acertou em querer trazer a esposa (a decisora), mas o fecho ficou frouxo. Compare com a R1 do Ladislau, onde travou data e hora na hora.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Tenho 3 perguntas: como, quanto, retorno" | Cliente impõe o frame de comprador | Call 1 [80:24] |
| Solta preço (R$500-20k) e projeção na abertura | Preço de R2 na R1 | R1/R2 [13:18] |
| História: irmão deu golpe, infarto, perdi 200k | Trauma que ancora o "solo" | Imersão [322:00] |
| "Não quero mais volume, negócio enxuto" | Cliente desqualifica o produto solar | Imersão [116:46] |
| "Isso não é seu objetivo, né?" | Desqualificação honesta | R1/R2 [16:05] |
| "Não compensa IA pro teu solar" | Transparência que compra confiança | Call 1 [48:38] |
| Cafu: "isso é papo sério, transparente" | Reciprocidade real funcionando | Call 1 [48:38] |
| Cafu: "na advocacia funciona?" | Cliente puxa a oportunidade real | R1/R2 [3:53] |
| "Esposa abrindo estrada sozinha, estressada" | Dor real (não rotulada) | R1/R2 [21:49] |
| "Que a IA traga os leads mastigados pra ela" | Cliente verbaliza o destino | R1/R2 [30:37] |
| Passo a passo de Instagram + social selling | Consultoria grátis | Call 1 [110:48] |
| "5 a 8 por dia no WhatsApp" | Volume baixo: brand antes da IA | R1/R2 [37:13] |
| "Te espero até setembro" | Amoleceu, matou a urgência | Call 1 [88:50] |
| "Me manda os horários" | R2 sem data firme | R1/R2 [13:18] |

---

## Decisões estratégicas de escopo / camada

**Produto solar (SDR comercial):** corretamente DESqualificado. O Cafu é solo por trauma, não quer volume nem contratar. Forçar mataria a confiança. ✅ Bom julgamento.

**Oportunidade real:** a advocacia da esposa (agronegócio, dívida rural). Compradora/usuária = a esposa, que NÃO estava na call. Tem que estar na R2.

**Camada de entrada certa:** brand-building barato primeiro (impulsionamento R$300/mês + social selling) pra GERAR volume, e a IA DEPOIS, quando tiver demanda pra justificar. Vender IA agora em 5-8 contatos/dia é ROI fraco (o próprio Matheus flagou). Sequência: crescer → automatizar.

**O ângulo de venda mais forte (não usado):** o nicho dela é COUNTER-cíclico. Crise = mais colono endividado = mais demanda. Isso desarma a objeção macro do Cafu de forma definitiva e devia ser o coração da R2.

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Não fez o C.** Deixou o Cafu impor as 3 perguntas e seguiu o frame de comprador a call inteira. Nunca fez a pergunta de clareza própria ("o que te trouxe aqui / o que você busca resolver"). R1/R2 [16:05].

**2. Não rotulou o L.** A dor da esposa (única no nicho, mas afogada e desconhecida) foi entregue de bandeja e nunca devolvida como problema nomeado e confirmado. R1/R2 [21:49] e [24:24].

**3. Tríade ausente no O.** Nenhuma enfatização ("ela já tentou crescer a base? por que não cresce? quanto cliente ela perde por não ser conhecida / por não dar conta?"). R1/R2 [9:54].

**4. Consultoria grátis.** Entregou a estratégia de brand + social selling com passo a passo executável. Plantar a visão era gancho; entregar o how-to esvaziou a R2. Call 1 [110:48].

**5. Amoleceu na objeção e matou a urgência.** Diante do medo de investir na crise, endossou o adiamento ("te espero até setembro") em vez de usar o reframe counter-cíclico que tinha na mão. E não isolou a esposa como decisora. Call 1 [88:50] e [122:00].

---

## Aplicação na próxima R1

- [ ] Quando o cliente impõe o frame ("tenho 3 perguntas"), responder rápido e RETOMAR o controle com a pergunta de clareza, não virar refém da agenda dele
- [ ] Rotular a dor com nome próprio mesmo quando ela é do terceiro (a esposa)
- [ ] Tríade completa, com enfatização de perda, na oportunidade real
- [ ] Plantar a visão da estratégia, não entregar o passo a passo executável
- [ ] Nunca endossar adiamento. Reframar com a escassez/urgência real do cliente (aqui: o nicho counter-cíclico)
- [ ] Travar R2 com data e hora, e isolar o decisor ("se fizer sentido pra vocês dois, decidem na próxima?")

---

## 🎯 Pra R2 com o Cafu e a esposa

A R2 é três vias, com a esposa (a decisora real). Trava na advocacia, esquece o SDR do solar. Pontos:
- **Destino:** tirar peso da esposa. Ela sozinha abrindo o nicho, a gente coloca a máquina que traz o cliente já mastigado pra ela só fechar.
- **Sequência honesta:** brand primeiro (impulsionamento R$300/mês + social selling) pra gerar volume, IA depois quando o WhatsApp encher. Não vender IA num volume de 5-8/dia.
- **Reframe da objeção (o mais importante):** o medo de investir na crise não vale pra ela. O negócio dela CRESCE na crise (mais colono endividado, "36 se enforcaram"). Investir agora é pegar a onda na subida.
- **Isolar a decisão:** "se fizer sentido pra vocês dois, vocês decidem aqui mesmo?"
- **Travar data**, não deixar no "me manda os horários".

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Ladislau (R1)]]
- [[2026-06-09 — Matheus vs Marcos (R1)]]
- [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]
- [[Mentoria Nimoto — Índice]]

---
tipo: análise R2
data: 2026-05-05
vendedor: Gustavo Nimoto (Ascend) + Wesley
prospect: V4 Company (Pedro, Lucas Susini, Guilherme — 3 sócios)
nicho: agência de marketing (V4)
resultado: a confirmar (transcrição truncada antes do fechamento de preço)
referência: true
tags: [mentoria, nimoto, r2, análise, referência]
fontes:
  - "[[2026-05-04 — Nimoto vendendo Assim para V4 (referência)]] (a R1)"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[CLOSER R2 — Versão Matheus]]"
---

# Análise — Nimoto vendendo Ascend para V4 (R2)

R2 do Nimoto com a V4. Os três sócios entraram (Pedro, Lucas, Guilherme), o que é diferente da R1 que tinha só o Pedro. **Esse é o cenário onde a R1 ficou aberta** — o Nimoto não tinha isolado decisão dos sócios na R1 (era um dos erros listados), e agora chegou na R2 com os 3 que ele não conhecia.

Apesar disso, a R2 foi um aula. **Cumpriu CLOSER inteiro com calibração de R2** (versão comprimida). É a referência-mestre que o Matheus pediu pra estudar e replicar com o Flávio.

> [!info] Resultado e diagnóstico geral
> Apresentação técnica densa mas com 3 portas distribuídas, autoridade dos sócios usada com precisão na abertura, e oferta amarrada em "30 dias com máquina rodando". A R2 funcionou porque o Nimoto vendeu **MUITO** o destino antes de qualquer entrega técnica.

---

## Bloco 1 — Abertura com uso de autoridade (00:00–01:30)

> Nimoto: "Pedrão já me conhece, mas me apresentando pra vocês, meu nome é Gustavo. Esse aqui do meu lado é o Wesley... O meu objetivo aqui hoje é apresentar pra vocês realmente uma proposta pra que vocês consigam ali implementar essa parte de outbound."

**Conceito aplicado:** **Uso da autoridade do sócio ausente** (técnica explicada na call de coaching de hoje [11:30]).
**Por que funciona:** Pedro já tinha rapport, então ao mencionar "Pedrão já me conhece" o Nimoto importa autoridade do Pedro pros outros 2 sócios. Lucas e Guilherme não vão questionar do zero o que o sócio deles já validou.

> Nimoto: "O Pedro chegou a dar um pouquinho mais de contexto pra vocês?"

**Conceito aplicado:** **C do CLOSER (versão R2)** — verifica nivelamento de informação antes de avançar. Imersão [311:25].
**Por que funciona:** descobre o que ele precisa recapitular ANTES de apresentar. Quando o Pedro respondeu "foi um panorama bem raso", o Nimoto soube que tinha que reapresentar do zero pra Lucas e Guilherme.

---

## Bloco 2 — Apresentação curta da Ascend (01:30–03:10)

> Nimoto: "Vou dar uma apresentação breve, então, sobre mim, rapidinho, vai levar um minuto..."

**Conceito aplicado:** **Apresentação curta + metodologia** (regra dos 5 minutos do CLOSER, R1/R2 [16:05]).
**Por que funciona:** anuncia o tempo ("1 minuto") e cumpre. Mostra que respeita o tempo deles. Encaixa o crescimento da Ascend ("50, 100, 300 reuniões") como **prova social do meio do funil**, não do resultado final (Call 1 [67:47]).

> Nimoto: "ele me trouxe um pouco das dificuldades de vocês, até nessa parte realmente de outbound, até nessa parte do custo de aquisição, que ele é um pouco elevado."

**Conceito aplicado:** **L do CLOSER (recap rápido)** — devolve a dor que foi rotulada na R1 com o Pedro, em forma de afirmação.
**Por que funciona:** os outros sócios ouvem o problema **vindo do mentor**, não do sócio deles. Cria autoridade externa sobre o diagnóstico.

---

## Bloco 3 — Sócios se apresentam, Nimoto valida o destino (03:10–04:40)

> Lucas (espontaneamente): "Nosso principal guidance é baixar nosso CAC pra outras avenidas de crescimento, outras avenidas de rentabilidade pra nós."

> Guilherme (espontaneamente): "As levantadas de mão estão vindo bastante da minha parte no sentido do CAC, que é uma preocupação, dado o investimento alto que a gente precisa fazer."

**Movimento ouro do prospect:** os 2 sócios novos verbalizaram a dor sem o Nimoto perguntar. **A R2 já entrou alinhada** porque o Pedro tinha plantado a semente.

> Nimoto: "Eu acho bacana que os três, por mais que cada um atue em uma área diferente, a comunicação de vocês é bem coesa ali entre si."

**Conceito aplicado:** **Reciprocidade** (Call 1 [48:38]) — elogia coesão antes de pedir alinhamento de decisão. Coloca os 3 num mesmo time pra evitar que se desunam na hora de fechar.

---

## Bloco 4 — Apresentação do destino com número específico (04:40–05:30)

> Nimoto: "Coloquei ali de **40 a 50 reuniões qualificadas por mês**, considerando ali o BDR que você já tem disponível... eu sempre prefiro chutar para baixo do que chutar para cima e frustrar as pessoas."

**Conceito aplicado:** **S do CLOSER — Sell the Vacation com destino mensurável**. Imersão [326:50].
**Por que funciona:** ele não vendeu "outbound estruturado" (commodity). Vendeu **40-50 reuniões qualificadas/mês em 30 dias**. Número + qualificação + prazo. Destino totalmente concreto.

**Plus:** ele justifica o "chutar pra baixo" como honestidade — vira credibilidade. Imersão [219:35] (escassez/promessa real).

---

## Bloco 5 — Antecipação e quebra de objeções (05:30–06:20)

> Nimoto: "Quando a gente vem do outbound, a primeira impressão que a gente tem é que o lead é desqualificado, ou que o lead não tem condições para pagar, ou que o lead vai entrar desinteressado. No nosso funil, quando a gente faz esse funil, realmente não acontece muito isso."

**Conceito aplicado:** **E do CLOSER ANTECIPADO** (3As preventivos). Quebra a objeção **antes dela ser falada**.
**Por que funciona:** ele sabe que agência de marketing tem trauma de outbound. Em vez de esperar Lucas ou Guilherme jogarem a objeção, ele já levanta e quebra: aceita ("é a primeira impressão"), contorna ("no nosso funil não acontece"), e justifica.

---

## Bloco 6 — Storytelling de 2 minutos (06:20–08:10)

> Nimoto: "A primeira agência que eu tive... eu fazia uma ligação, nessa ligação a pessoa perguntava, pô, quem é você, não estou interessado... Estava voltando de um evento, e aí desse evento eu falei assim, cara, e se eu fizesse o mesmo evento online?"

**Conceito aplicado:** **Reciprocidade real + autoridade adquirida** (Call 1 [48:38]) + **Big Idea com nome próprio** ("evento online outbound").
**Por que funciona:** não vende "ele é o melhor". Conta que **passou pela mesma dor** que a V4 tem hoje. Cria conexão emocional. Imersão [193:14] — "vende o destino, não a passagem", mas **a passagem entra como história** pra dar contexto.

> Nimoto: "Eu falhei ela não por falta de vendas, a gente vendeu 150 mil reais em três meses, foi por falta de gestão... a gente realmente faliu por conseguir vender muito."

**Movimento crítico:** o Nimoto **conta que faliu uma empresa**. Isso é vulnerabilidade calculada — gera mais autoridade que sucesso, porque mostra que aprendeu na dor.

---

## Bloco 7 — Apresentação técnica do funil + 1ª PORTA INTERCALADA (08:10–13:45)

> Nimoto: "O meu único objetivo é fazer com que esse cara chegue em uma reunião de vendas comigo. O que eu vou fazer? Literalmente, eu pego, por exemplo, um produto que vocês vão vender, um serviço que vocês vão vender..."

**Conceito aplicado:** **Apresentação técnica do produto** (S detalhado). Pode ser técnico, sem problema. Mas amarrando com a oferta-frase.

> Nimoto: "Eu não me inspirei em ninguém... naquela época, Lucas, não era normal você fazer um evento e ao invés de você fazer um pitch de vendas, você chamar para uma reunião de vendas."

**Conceito aplicado:** **Blue Ocean explícito** (Fundamentos cap. 2) + **autoridade por pioneirismo**.

> Nimoto (final do bloco): "Deu para entender basicamente? Lucas, Guilherme, Pedro?"

**Conceito aplicado:** **1ª PORTA — "Você acredita que isso faz sentido?"** (versão Nimoto: "deu pra entender?").
**Por que funciona:** chama os 3 nomes específicos. Força resposta individual. Não dá pra um sócio ficar calado — vira pacto público.

> Pedro: "Cara, 100%."

**1ª porta fechada.** ✅

---

## Bloco 8 — Aprofundamento do funil + 2ª PORTA (13:45–22:00)

Pedro e Lucas começam a fazer perguntas de quem **já tá vendido** ("vocês têm temas específicos?", "entrega de valor?", "isca?"). Sinal verde gigante.

> Nimoto explica reativação, nutrição, eventos recorrentes...

> Nimoto (final): "Pessoal, quando eu faço esses eventos, normalmente, você não vai vender um produto de, sei lá, 40, 50 mil reais de uma vez... seria um problema a gente focar nesses produtos de recorrência mesmo? Nesses produtos de MRR?"

**Conceito aplicado:** **2ª PORTA — "Você acredita que isso é pra você?"** (versão Nimoto: "seria problema focar em MRR?").
**Por que funciona:** transforma a porta em **escolha de escopo**. Faz o cliente declarar publicamente que o produto serve. E ainda valida o ICP (MRR baixo, não enterprise).

> Pedro: "Na real é o grande objetivo... a gente tá muito tendenciado, cara, a validar da forma que vai ser sugerido, entendeu?"

**2ª porta fechada.** ✅

---

## Bloco 9 — Apresentação dos entregáveis + 3ª PORTA (22:00–32:00)

> Nimoto: "Cara, se vocês pegarem esse funil, que eu dei a ideia aqui para vocês e aplicarem, provavelmente vai dar certo. O grande quesito é o tempo que isso vai levar... Eu não estou aqui para realmente ensinar o funil para vocês."

**Conceito aplicado:** **Reframe de "ensinar" pra "acelerar"** + **antecipação de objeção** "posso fazer sozinho".
**Por que funciona:** ele já assumiu publicamente que o método "provavelmente vai dar certo" se eles fizerem sozinhos. Tira o medo deles. E imediatamente posiciona o serviço como **velocidade**, não como conhecimento.

> Nimoto: "Nós somos uma consultoria executiva. Ou seja, a gente vai literalmente montar a parte do script... o meu objetivo é que em 30 dias, toda essa estrutura, ela esteja rodando dentro da empresa de vocês."

**Conceito aplicado:** **Probabilidade de Sucesso + Esforço/Sacrifício baixo** (Equação do Valor — Imersão [208:30]).

Aí Nimoto detalha:
- 4 encontros estratégicos
- Script de prospecção (entregue + validado ao vivo)
- Playbook de rotina comercial
- Estrutura de metas e expansão de time
- 1h/dia de acompanhamento por 30 dias úteis

> Nimoto: "Em 30 dias, parece pouco tempo, mas não é. É literalmente tempo suficiente para a gente conseguir fazer tudo isso rodar. Pessoal, dentro dessas entregas que a gente faz aqui, vocês têm alguma dúvida, algum questionamento?"

**Conceito aplicado:** **3ª PORTA implícita** ("vocês acreditam que eu sou a pessoa?") em forma de "tem dúvida?". Quem não tem dúvida fechou a porta sozinho.

---

## Bloco 10 — Quebra de objeções operacionais (32:00–43:00)

Pedro, Lucas e Guilherme jogam objeções concretas:
- Quais ferramentas precisa contratar?
- Quem cria as listas?
- Quanto tempo do gestor?
- Vamos fazer evento juntos durante os 30 dias?
- Não temos CRM, vai impactar?

**Pra cada objeção, Nimoto aplica 3As perfeito:**

> Pedro: "no caso da nossa estrutura aqui, que não tem CRM..."
> Nimoto: [resposta cortada na transcrição, mas a estrutura é clássica 3As]

**Movimento crítico:** ele **NUNCA capitula**. Toda objeção vira "boa pergunta" + redireciona pra força do método. Imersão [97:18].

---

## Bloco 11 — Promessa de resultado dentro do prazo (41:00–42:00)

> Pedro: "Nesse período de 30 dias, a gente chega a fazer um evento juntos?"
> Nimoto: "Perfeita pergunta. O cronograma, assim que a gente inicia, o nosso objetivo é para que em 15 dias você já tenha o seu primeiro evento. Porque eu quero que você tenha um resultado enquanto o meu acompanhamento está rolando."

**Conceito aplicado:** **Garantia de execução implícita** + **prova durante o período** (Imersão [222:54]).
**Por que funciona:** desarma o medo de "pagar e não ver retorno". Ele compromete entregar resultado **antes** do contrato acabar. **Reduz risco percebido a quase zero.**

---

## Mapa-resumo CLOSER R2

| Etapa CLOSER | Aplicado? | Como apareceu |
|---|---|---|
| **C — Clarity** | ✅ | "Pedro chegou a dar contexto pra vocês?" |
| **L — Label** | ✅ | Recap da dor (CAC alto, outbound) na abertura |
| **O — Overview (urgência)** | ⚠️ | Não fez explícito, mas Lucas e Guilherme verbalizaram urgência sozinhos no início |
| **S — Sell the Vacation** | ✅✅✅ | "40-50 reuniões qualificadas em 30 dias" + 3 pilares (funil, gestão, evento em 15 dias) |
| **E — Explain Away** | ✅ | Antecipou objeção "lead desqualificado" + 3As em todas operacionais |
| **R — Reinforce / 3 portas** | ✅ | 3 portas distribuídas pela apresentação ("deu pra entender?", "seria problema MRR?", "tem dúvida?") |
| **3 perguntas-chave** | ⚠️ | Não fez literais, fez **versão suavizada** integrada ao discurso |
| **Compromisso emocional** | ⚠️ | Truncado na transcrição, mas estrutura de fechamento já estava montada |

**Score CLOSER R2:** **C ✅ L ✅ O ⚠️ S ✅✅ E ✅ R ✅** — 5,5 de 6 letras com execução forte.

---

## ⚠️ O que o Nimoto fez DIFERENTE do slide oficial

**1. As 3 portas não são literais. São naturalizadas.**
No slide ele recomenda perguntar literal "você acredita que isso atende? que se encaixa? que sou a pessoa?". Na prática ele faz:
- "Deu pra entender?"
- "Seria problema focar em MRR?"
- "Tem dúvida?"

São as **mesmas 3 portas**, mas em linguagem natural. Cliente não sente que tá numa script de fechamento.

**2. Antecipou objeções antes delas surgirem.**
Em vez de esperar Lucas ou Guilherme falarem "lead desqualificado", ele jogou a objeção primeiro e quebrou. **Imuniza o cliente** contra resistência futura.

**3. Storytelling de 2 minutos no meio do S.**
Quebra a apresentação técnica com narrativa pessoal (faliu uma empresa, descobriu o método). Reinicia a atenção. Sem isso a apresentação técnica fica monótona.

**4. Falou de FALÊNCIA antes de sucesso.**
"Eu faliu uma empresa por vender demais." Vulnerabilidade calculada > prova social pura.

**5. Promessa de resultado DENTRO do contrato (15 dias = 1º evento).**
Reduz risco percebido a zero. Cliente pensa: "se em 15 dias eu vejo resultado, e o contrato é 30, eu tenho margem de segurança."

**6. Nichou ICP de produto durante a R2.**
"Produtos abaixo de R$8-10k de recorrência funcionam." Filtra antes de fechar — só fecha cliente onde o método dá certo. **Reduz churn futuro.**

---

## Comparação direta: Nimoto na R1 vs R2 com a V4

| Etapa | R1 com Pedro (04/05) | R2 com os 3 sócios (05/05) |
|---|---|---|
| **C** | "Como tá a operação de vocês?" — descoberta nova | "Pedro chegou a dar contexto?" — calibragem de informação |
| **L** | Rotulou "outbound caro + dependência inbound" | Recap da dor com vocabulário dos sócios novos |
| **O** | Tríade completa com Pedro ("11k CAC?", "qual conversão?") | Não precisou — Lucas e Guilherme verbalizaram urgência sozinhos |
| **S** | Genérico ("a gente faz evento outbound") | **Específico**: "40-50 reuniões qualificadas em 30 dias" |
| **E** | Não apareceu (lead vendeu sozinho) | Antecipado + 3As em cada objeção operacional |
| **R** | Marcou R2 amanhã 13h | 3 portas distribuídas + promessa de 15 dias |

**A R2 é a R1 inteira COMPRIMIDA na frente, mais a apresentação técnica nos 30 minutos finais.**

---

## Aplicação na R2 do Flávio (Synergy) — terça 19h

Os principais aprendizados pra replicar:

- [ ] **Importar autoridade do Tino** na abertura: "Tino já te conheceu na primeira call, agora a gente trouxe a proposta..."
- [ ] **Anunciar o tempo** das partes: "vou apresentar isso em 5 minutos"
- [ ] **Vender destino com NÚMERO**: "em 45 dias tu sai com pipeline rodando, lista de 50-100 empresas, time treinado"
- [ ] **Antecipar a objeção "já tentei consultoria"** antes do Flávio falar
- [ ] **Storytelling de 1-2 minutos** sobre cliente similar (Jonas Hypertech, ou outro caso)
- [ ] **3 portas naturalizadas, não literais**: "fez sentido?", "isso é pra Synergy?", "tem dúvida do método?"
- [ ] **Promessa dentro do contrato**: "em 15 dias tu já tem lista pronta + scripts rodando"
- [ ] **Filtrar ICP de produto** se ele tiver dúvida de escopo: "esse método funciona se tu vender comercial. Tu quer focar nisso?"

---

## Frases de ouro do Nimoto na R2 (pra estudar)

1. "Eu sempre prefiro chutar para baixo do que chutar para cima e frustrar as pessoas."
2. "Eu não estou aqui para realmente ensinar o funil para vocês."
3. "Eu faliu uma empresa por vender muito."
4. "Em 15 dias você já tem o seu primeiro evento, porque eu quero que você tenha um resultado enquanto o meu acompanhamento está rolando."
5. "O que ele tem que fazer durante todo o evento? A gente tem que dar aqueles micro-resultados, ou seja, aquelas micro-vitórias."
6. "Você tem que mudar o lugar que você está enviando o seu lead, sabe?"

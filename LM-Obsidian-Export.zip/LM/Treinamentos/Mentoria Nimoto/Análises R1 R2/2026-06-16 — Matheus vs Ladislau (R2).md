---
tipo: análise R2
data: 2026-06-16
vendedor: Matheus Jardim
prospect: Ladislau Asturiano + Thaísa (Fotovoltaico)
nicho: energia solar
oferta: Ignição Comercial — 45 dias, R$4.000, entrada R$1.500 + saldo dividido em 30/45 dias
resultado: EM ABERTO — Ladislau levou pro financeiro, prometeu resposta até 20h via WhatsApp. Não fechou na call.
tags: [mentoria, nimoto, r2, análise, lm, vendas]
fontes:
  - "[[2026-06-16 — Matheus vs Ladislau (R1)]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[2026-05-05 — Matheus e Tino vs Synergy (R2)]]"
  - "[[2026-05-13 — Matheus vs Daniel Daolio (R2)]]"
---

# Análise — Matheus vendendo para Ladislau (R2)

R2 com o Ladislau (dono da Fotovoltaico, integradora solar em crise, único vendedor da operação) e a Thaísa (funcionária que vai prospectar). Call de ~44 minutos, recheada de quedas de conexão que cortaram a apresentação e, pior, o fechamento. Oferta: Ignição Comercial, 45 dias, R$4.000. **Não fechou.** Ladislau levou pro financeiro e prometeu resposta até 20h no WhatsApp. Essa é a R2 logo após a R1 de ontem, onde a análise já tinha entregue o roteiro CLOSER pronto pra hoje.

> [!info] Resultado e diagnóstico geral
> Não fechou na call, mas o CLOSER foi executado bem melhor do que parece. C ✅, L ✅, O ✅, S ✅ (oferta-frase curta certa + apresentação técnica do produto, que é o Passo D do método e PODE ser detalhada). O que de fato segurou a venda: **E ⚠️** (a objeção de marketing não morreu, e ainda bateu de frente em vez de "concordo") e **R ⚠️** (só 1 das 3 portas foi feita — a 3ª, de confiar na gente, nunca veio — então no fechamento não tinha sim/sim/sim armado pra ancorar; e a garantia veio depois do preço). Some a isso a restrição financeira real do cliente ("não consigo o valor hoje, vou passar pro financeiro") e as quedas de conexão que mataram o embalo do reframe. O reframe de pagamento por marco foi a melhor jogada da call.

---

## Bloco 1 — Abertura caótica + C do CLOSER

> "[00:04 a 07:30] áudio embolado, futebol, Fathom repetido, sem o prospect na sala" (call [00:04])

**Conceito:** os primeiros 7 minutos foram perdidos (problema técnico, link errado, prospect não estava). Não é método, mas é contexto: a call já começou fria e atrasada.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — recepção e ambiente importam.
**Por que importa:** energia da abertura é tudo numa R2. Começou capenga e nunca pegou ritmo.

---

> "Ladislau, seguinte, como tu tá de tempo, tá com tempo mais corrido, pra gente ser mais sucinto, como que tá aí?" (call [08:26])

**Conceito:** calibra o tempo do cliente logo na entrada. Bom reflexo, ainda mais com o Ladislau que ontem mesmo pediu objetividade.
**Aula:** [[2026-06-16 — Matheus vs Ladislau (R1)]] — ele pediu "a gente tem que ser mais objetivos" na R1.
**Por que funciona:** ✅ respeitou o pedido dele e calibrou a régua de tempo logo na entrada.

---

> "deixa eu te perguntar, de ontem para hoje mudou alguma coisa? Você tem mais alguma coisa para acrescentar naquilo que a gente conversou ou seria aquilo mesmo?" (call [09:03])

**Conceito:** C do CLOSER em versão R2. A pergunta de atualização decorada, mesma fórmula da R2 Synergy e da R2 Daniel.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] — *"A primeira coisa numa reunião não é se apresentar. É descobrir por que aquele cliente aceitou."*
**Por que funciona:** ✅ memória muscular consolidada. Saiu natural. Abriu a R2 do jeito certo.

---

> "é basicamente aquela parte de trazer mais clientes comerciais... e trabalhar realmente com a equipe que você já tem, sem precisar contratar outras pessoas, e pouco a pouco a gente ir calçando ali e crescendo a equipe, né? Seria isso, né?" (call [09:03])

**Conceito:** recap do problema (L embrionário) + pergunta-âncora de confirmação. Embutiu o entry-level (sem contratar) na devolução.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [317:35] — *"Dê um nome ao problema. Faça o cliente repetir em voz alta."*
**Por que funciona:** ✅ L feito conforme o método de R2 (recap do problema da R1 + "seria isso, né?" + cliente confirma em voz alta "Isso, show de bola, perfeito"). Cumpriu a etapa. **Oportunidade (não falha):** dava pra somar a dor emocional que ele deu ontem (vendeu dois caminhões, 17 virou 6, empresa refém dele) pra deixar o L mais quente. A análise da R1 sugeriu isso. Mas o L racional confirmado já é etapa cumprida, não é erro.

---

## Bloco 2 — O do CLOSER + tentativa de destino

> "como é que tu está aí de urgência para a gente estar colocando isso em prática aí? É para ontem? É de 0 a 10?" (call [09:46])

**Conceito:** O do CLOSER em versão R2 (urgência presente). Pergunta limpa, comprime a tríade num termômetro.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [320:10] — *"Eu quero ver meu cliente triste."*
**Por que funciona:** ✅ pergunta certa de O na R2.

---

> Ladislau: "Agora eu estou sem. Eu estou sem marketing agora." (call [09:57])

**Movimento do prospect:** confessou urgência máxima de bandeja (está sem captação nenhuma rodando). Sinal verde.
**Aula:** Call 1 [80:24] — *"não é o problema, é a intenção."* Intenção: "tô na seca, preciso de algo agora."
**Por que importa:** urgência 10/10 confirmada. Mas repara que a dúvida dele já vem embutida: "estou sem marketing" = a cabeça dele associa solução a marketing, não a ligação. Essa semente vira a objeção principal do Bloco 5.

---

> "em 45 dias a gente está gerando pelo menos 10 a 20 visitas por mês de clientes comerciais... esse daí seria o destino que a gente queria te entregar" + "tirar vocês de praticamente zero prospecção ativa... pra 10 a 20 visitas no mês, e está fechando pelo menos uma, duas, três, quatro por mês desses clientes" (call [10:03] e [11:55])

**Conceito:** S (Sell the Vacation) feito de forma sólida. Encadeou o destino completo: tempo (45 dias) + saída de (zero prospecção) + mecanismo (time atual) + resultado de negócio (10-20 visitas → fechar 1-2 clientes comerciais/mês).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final, não o voo."*
**Por que funciona:** ✅ NÃO foi métrica seca de visita. Tu amarrou a visita ao que importa pro dono: fechar cliente comercial todo mês, saindo do zero. Destino com resultado de negócio e ingredientes MAGIC. A frase do destino tava certa.
**Único ajuste fino (não é falha):** dava pra somar a camada emocional que ele deu na R1 ("uma empresa que ande sozinha, sem depender de mim") por cima do resultado de negócio. O destino racional tava completo; o emocional só turbinaria. Plus, não correção.

---

> "Na tua visão, teria alguma outra coisa que você queria que a gente entregasse no final desses 45 dias?" (call [10:03])

**Conceito:** pergunta-âncora do destino (confirma o destino antes de detalhar o produto). Movimento certo, o mesmo que o Tino fez bem na Synergy.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [30:37] — *"a gente sempre vende o destino final."*
**Por que funciona:** ✅ devolveu a régua pro cliente antes de abrir o mapa mental.

---

> Ladislau: "O que a gente quer, na verdade, é a venda, a gente quer o bicho-bicho, é isso que a gente precisa. É urgente... porque esse mês é mês de paradeira, rapaz" (call [11:32])

**Movimento do prospect:** ele mesmo cravou o destino dele em uma palavra: VENDA ("o bicho-bicho"). E reforçou urgência.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — material puro pra oferta-frase.
**Por que importa:** ele entregou o termo. "Bicho-bicho" / venda fechada era pra virar âncora ("o destino é tu fechando o bicho-bicho com cliente comercial todo mês sem depender de você na rua"). Passou batido.

---

## Bloco 3 — Apresentação técnica do produto (Passo D do método)

> "Eu vou apresentar aqui... vou mostrar mapa mental, basicamente, com tudo aquilo que a gente vai te entregar dentro desses 45 dias" + apresentação operacional do mapa mental (call [11:55] a [29:56])

**Conceito:** apresentação técnica do produto (Ignição Comercial). Isso é o **Passo D do CLOSER R2**, que vem DEPOIS da oferta-frase e da confirmação do destino, e que o método diz explicitamente que pode ser técnico e detalhado.
**Aula:** [[CLOSER R2 — Versão Matheus]] (roleplay com Nimoto) — *"Apresentação do produto. Pode ser técnico, pode mostrar mapa mental. E durante a apresentação, fechar as portas."*
**Por que funciona:** ✅ a regra "vende o destino, não o voo / pitch ≤3 min" vale só pra OFERTA-FRASE, que tu fez curta antes. Detalhar a entrega aqui (script, cadência, playbook, CRM, acompanhamento) é o que o método pede nessa etapa. Não é erro.
**O que de fato faltou (vai pro R):** o Passo D fecha com as 3 portas ("faz sentido?" / "é pra você?" / "você acredita que a gente é a pessoa?"). Tanto faz em bloco ou distribuída, mas as 3 precisam ser feitas antes do preço. Tu fez só 1 (a 3ª, de confiar na gente, nunca veio). Esse é o furo real, e ele explode lá no fechamento (ver Bloco 6).

---

> "a gente tem três tópicos principais ali, que é o tópico de leads de marketing, o time estruturado e a previsibilidade" (call [16:46])

**Conceito:** os 3 pilares existem (máquina de leads / time estruturado / previsibilidade). Estrutura certa.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Divida sua solução em 3 pilares."*
**Por que funciona:** ✅ os 3 pilares estão lá e bem nomeados. Bom esqueleto pra apresentação técnica. Dica: dá pra usar cada pilar pra encaixar uma das 3 portas (faz sentido? / é pra você? / a gente é a pessoa?) ao longo do caminho. A forma é livre (bloco ou distribuída), o que não pode é faltar porta.

---

> "objeção comum, você ligou pro estabelecimento, a pessoa falou 'aqui eu já tenho energia solar instalada', aí você fala 'nossa que legal, seu sistema é com bateria? ...a gente faz manutenção...'" (call [17:00] em diante)

**Conceito:** demonstração do entregável "quebra de objeção na ligação" com exemplo concreto (manutenção, bateria, mercado livre, os 30% vs 15%).
**Aula:** [[CLOSER R2 — Versão Matheus]] — apresentação técnica do produto, pode mostrar o conteúdo.
**Por que funciona:** ✅ mostrar O QUE tem dentro da entrega (que você treina o time a quebrar essas objeções) é prova de capacidade, faz parte do Passo D. Não é consultoria grátis: ele não vai conseguir replicar a operação inteira (lista + script + cadência + acompanhamento) só por ouvir um exemplo. **Único cuidado:** com cliente desconfiado e sem caixa, vale dosar o exemplo (um, não cinco) pra não dar a sensação de "já entendi, faço sozinho". Calibragem, não erro.

---

> "exemplo, 50 ligações as duas juntas. Dessas 50, 20 atendem. Dessas 20, ela fala com 5 donos. Desses 5, ela agenda 3, 2, 1 visita... 4 semanas no mês, 20 visitas" (call [25:00] aprox.)

**Conceito:** pilar da previsibilidade com o funil de números. Bom em si (cria percepção de probabilidade de sucesso, [37:15] da R1/R2).
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [37:15] — *"a maior parte da R2 é você falando sobre probabilidade de percepção de sucesso."*
**Por que funciona:** ✅ a lógica de previsibilidade é o melhor pedaço da apresentação técnica (pinta o resultado provável com número). Só perdeu um pouco de impacto porque a conexão caiu bem nesse trecho. Aqui era um ótimo ponto pra fechar a porta "faz sentido essa previsibilidade pra você?".

---

## Bloco 4 — Primeiras 48h plantadas

> "a gente quer marcar a primeira visita depois de sete dias que a gente faz o onboard... fechou hoje, marca o onboard amanhã ou quinta no máximo... e o onboard ali em 48 horas" (call [25:00] aprox.)

**Conceito:** R do CLOSER antecipado, plantio das primeiras 48h + primeira visita em 7 dias. Cria movimento imediato pra um cliente ansioso.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — *"As primeiras 48h são decisivas."*
**Por que funciona:** ✅ deu sensação de "começa já". Bom pra segurar a decisão de quem quer resultado pra ontem.

---

## Bloco 5 — E do CLOSER: a objeção real (marketing)

> Ladislau: "eu acho que o método de vocês é ótimo... o que eu falo é que tem que ter marketing junto... a gente tem que captar o cliente, né, qual que é o meio que você põe pra captar?" (call [31:00])

**Movimento crítico do prospect:** ESSA é a objeção que decide a venda. Ele não acredita 100% em ligação como única fonte. A crença dele é "precisa de marketing".
**Aula:** Call 1 [97:18] — *"toda objeção é falta de uma narrativa bem contada."*
**Intenção real:** "me convence que ligação sozinha enche minha agenda, senão eu vou querer marketing junto e adiar."

---

> "é 100% ligação... quando você faz campanha de anúncio você não consegue controlar quem vem, 99% vem cliente residencial, não vem comercial, que é o que a gente quer... no seu caso não é necessário marketing" (call [31:37])

**Conceito:** contorno da objeção, mas sem o "concordo" antes. Foi direto pro contra-argumento.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [97:18] — *"Concordo / Contorno / Sugiro."*
**Por que funciona parcial:** ⚠️ o argumento é bom (anúncio traz residencial, ligação mira comercial). Mas pulou o "concordo, faz sentido você pensar em marketing" e foi pro "não precisa". Sem validar a visão dele primeiro, a objeção não morre, só recua.

---

> Ladislau: "telefonema hoje com vocês dá resultado? Porque, por exemplo, eu não atendo o telefone." → Matheus: "mas você atendeu o nosso, não atendeu?" (call [32:42])

**Conceito:** aqui bateu de frente. Usou o próprio Ladislau como contra-exemplo ("você atendeu o nosso").
**Aula:** Call 1 [122:00] — não bater de frente com a versão do cliente. + [48:38] reciprocidade.
**Por que falhou:** o cliente rebateu na hora ("porque estava programado, né"). Quando você confronta a experiência dele com um "mas você...", ele defende a posição dele em vez de comprar a sua. O caminho era concordar ("verdade, muita gente não atende mesmo") e reframar (a gente liga no telefone fixo da empresa, fala com a atendente, ela passa pro dono).

---

> Ladislau: "a gente está estudando o jeito de fazer marketing... aqueles anúncios não viram nada, a gente já fez muito... se é vídeo, se é integração com o pessoal... está estudando isso ainda" (call [36:15])

**Movimento do prospect:** ele revelou que está com energia mental investida em montar marketing PRÓPRIO. A objeção não é só "preço", é "eu tenho outro plano na cabeça (marketing) competindo com o seu".
**Aula:** Call 1 [80:24] — *"não é o problema, é a intenção."*
**Por que importa:** essa objeção ficou viva até o fim. Matheus afirmou que ligação resolve, mas nunca converteu a CRENÇA do Ladislau. Saiu da call ainda dividido entre "fazer marketing meu" e "contratar a LM". Objeção não isolada = venda adiada.

---

## Bloco 6 — R do CLOSER: portas e isolamento incompletos

> "dentro dessa estrutura da nossa entrega, você acredita ali que isso pode estar ajudando vocês a sair do vermelho... ou teria mais alguma coisa que você julgaria necessário acrescentar?" (call [30:39])

**Conceito:** porta do R (faz sentido / é pra você). Só 1 das 3 portas foi feita.
**Aula:** [[CLOSER R2 — Versão Matheus]] — as 3 portas antes do preço (forma livre: bloco ou distribuída).
**Por que falhou:** ❌ esse é o furo central da call, mas não é a forma e sim a completude. Das 3 portas (faz sentido? / é pra você? / você acredita que a GENTE é a pessoa?), tu fez só 1. A 3ª (confiar no executor) nunca veio, justo o calcanhar de um cara queimado por 3 agências. Consequência direta: no fechamento tu não tinha o "sim / sim / sim" armado pra dizer "você falou que faz sentido, que é pra você, que confia na gente, só falta o valor, sim ou não?". Sem as 3 portas, o R fica sem chão.

---

> "está bem alinhado, faz sentido ali... hoje teria alguma dúvida em cima disso para a gente começar, ou seria somente preço mesmo agora?" (call [34:08])

**Conceito:** tentativa de isolar a objeção pra sobrar só preço. Movimento certo (igual a jogada de ouro do Daniel).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Se sim/sim/sim, sobra apenas valor."*
**Por que falhou:** ⚠️ a resposta do Ladislau foi "seria preço E a gente dá uma estudada" e logo voltou pro marketing. Ou seja: NÃO sobrou só preço. Tinha objeção viva (marketing + financeiro). Mesmo assim Matheus tratou como se fosse só preço e soltou o número. Isolou no papel, não na prática.

---

## Bloco 7 — Preço e garantia (fora de ordem)

> "Ladislau, o valor que a gente tem desse projeto aqui é R$4.000, esses 45 dias." (call [38:20])

**Conceito:** preço direto, sem rodeio. Bom em si.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"número direto após sim/sim/sim."*
**Por que falhou de contexto:** ❌ soltou o número ANTES da garantia e com objeção (marketing) ainda viva. A R2 Synergy fez o oposto e fechou: garantia ANTES do preço pra zerar o risco percebido. Aqui o R$4.000 caiu no colo de um cara que acabou de dizer "tiro tudo do bolso" sem o amortecedor da garantia na frente.

---

> Ladislau: "no Pix eu não consigo hoje... é valor agregado alto pra gente hoje por causa do nosso movimento. Eu vou analisar e te passo pelo WhatsApp" (call [39:21])

**Movimento crítico do prospect:** a objeção real da R1 se materializou — "não posso correr risco, tiro do bolso" virou "não consigo o valor hoje, vou analisar". Exatamente o que a análise da R1 previu.
**Aula:** Call 1 [80:24] — intenção: "não é que não quero, é que não cabe e eu não confio o bastante ainda."

---

> "a gente sempre traz uma garantia... se em 45 dias a Taísa e a Camila não estiverem gerando 10 a 20 visitas, a gente fica com vocês fazendo o mesmo trabalho até conseguir... só finaliza depois que vocês tiverem o resultado" (call [40:06])

**Conceito:** garantia de execução (risco reverso). Forte, é a mesma da Synergy.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [222:54] — *"garantia de execução."*
**Por que funciona parcial:** ✅ a garantia é ótima e bem fraseada. ❌ mas veio DEPOIS do preço e depois do cliente já ter recuado ("vou analisar"). Garantia serve pra derrubar o risco ANTES do número. Usada como tapa-buraco depois do recuo, perde metade da força.

---

> "a gente consegue pegar uma parte de entrada no início e dividir isso dentro dos 45 dias... quanto você conseguiria dar de entrada?" → Ladislau: "1.500" → "depois de 30 dias paga 50%, no final dos 45 dias paga o restante" (call [39:41] a [41:30])

**Conceito:** reframe criativo de pagamento (entrada + parcelas por marco), sem baixar o preço. O mesmo movimento de closer experiente que fechou a Synergy.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"nunca dar desconto, trocar a estrutura."*
**Por que funciona:** ✅ não derrubou valor, trocou a forma. Tirou o "1.500 que ele topou de entrada" da boca dele. Melhor movimento tático da call. Quase virou o jogo.

---

## Bloco 8 — O fechamento que não fechou

> Ladislau: "se a gente der resultado já, sim" → [conexão cai] → "manda pra mim a proposta e aí a gente já retorna pra você dizendo sim ou não" (call [41:27] a [42:21])

**Movimento do prospect:** recuou do quase-fechamento pro "manda a proposta, eu retorno". Clássico adiamento. E a queda de conexão bem nesse ponto matou o embalo do reframe.
**Aula:** Call 1 [97:18] — objeção viva (marketing + financeiro) não foi resolvida, então o "sim" não veio.
**Por que importa:** o reframe de pagamento tinha trazido ele pra beira do sim. Faltou um empurrão final ancorado em confiança (3ª porta) e a conexão tirou o momento.

---

> "pelo que você tinha falado, 1.500 de início e depois divide no 30 e no 45, né? Eu posso considerar vocês quase fechado ou fechado, ou tem mais alguma coisa?" (call [42:30])

**Conceito:** tentativa de fechamento por pressuposição (resgatar o acordo de pagamento que ele topou).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Pode ser? Sim ou não?"*
**Por que funciona parcial:** ✅ boa tentativa de cravar usando o que ele já aceitou. ❌ mas a essa altura o Ladislau já tinha escapado: "não sabia o teu valor, agora vou passar pro financeiro pra ver se consigo". A objeção financeira + a objeção de marketing seguraram.

---

> "se você conseguir dar a resposta hoje, amanhã ou na quinta a gente já marca a reunião pra começar... você consegue dar a resposta hoje?" → Ladislau: "até umas 8 horas" (call [42:55] a [43:22])

**Conceito:** criou vigência/prazo e ancorou compromisso de resposta com hora marcada (até 20h). Encerramento correto pra uma R2 que não fechou na hora.
**Aula:** [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] [13:18] — compromisso com data/hora específica, não "qualquer dia".
**Por que funciona:** ✅ não deixou no ar. Saiu com prazo (20h) e próximos passos (proposta escrita no WhatsApp + onboard amanhã/quinta se fechar). Dá pra fechar no follow-up.

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| 7 min de áudio perdido + quedas | Abertura fria, sem ambiente | Imersão [307:00] |
| "Como tá de tempo, pra ser sucinto?" | Calibra tempo do cliente | R1 Ladislau |
| "De ontem pra hoje mudou alguma coisa?" | C do CLOSER (R2) | Imersão [311:25] |
| "Mais comercial, sem contratar, né?" | L feito (recap + confirma) ✅ | CLOSER R2 |
| "Urgência de 0 a 10?" | O do CLOSER (urgência presente) | Imersão [320:10] |
| Ladislau: "estou sem marketing agora" | Urgência 10 + semente da objeção | Call 1 [80:24] |
| "45 dias, 10-20 visitas → fechar 1-2 clientes/mês" | S sólido (destino com resultado) ✅ | Imersão [326:50] |
| Ladislau: "a gente quer o bicho-bicho" | Cliente cravou o destino (venda) | Imersão [326:50] |
| Apresentação técnica do mapa mental | Passo D (pode detalhar) ✅ | CLOSER R2 |
| Mostrou exemplo de quebra de objeção | Demonstra entregável ✅ | CLOSER R2 |
| Só 1 das 3 portas feita (faltou a 3ª) | Furo central (portas incompletas) ❌ | CLOSER R2 |
| Funil 50→20→5→1 visita | Previsibilidade (bom) ✅ | R1/R2 [37:15] |
| "Onboard em 48h, 1ª visita em 7 dias" | Plantio das primeiras 48h | Imersão [307:00] |
| Ladislau: "tem que ter marketing junto" | Objeção principal (crença) | Call 1 [97:18] |
| "É 100% ligação, no seu caso não precisa marketing" | Contorno sem "concordo" | Imersão [97:18] |
| "Mas você atendeu o nosso, não atendeu?" | Bateu de frente com o cliente | Call 1 [122:00] |
| Ladislau: "tô estudando fazer meu marketing" | Objeção viva até o fim | Call 1 [80:24] |
| "Você acredita que sai do vermelho?" | só 1 das 3 portas (faltou a 3ª) | CLOSER R2 |
| "Seria só preço ou tem dúvida?" | Isolamento incompleto | Imersão [330:00] |
| "R$4.000, 45 dias" | Preço antes da garantia | Imersão [330:00] |
| Ladislau: "no Pix não consigo, vou analisar" | Objeção da R1 se materializou | Call 1 [80:24] |
| "Garantia: fico até gerar as visitas" | Garantia forte, mas fora de ordem | Imersão [222:54] |
| Entrada 1.500 + saldo em 30/45 dias | Reframe de pagamento (ótimo) | Imersão [330:00] |
| "Manda a proposta, retorno sim ou não" | Adiamento, objeção não resolvida | Call 1 [97:18] |
| "Resposta até 20h" | Fechou com prazo e hora | R1/R2 [13:18] |

**Score CLOSER R2:** **C ✅ · L ✅ · O ✅ · S ✅ · E ⚠️ · R ⚠️** — não fechou.
**Comparação:** Synergy fechou 6/6, Daniel fechou 4-3. Aqui o começo do CLOSER (C, L, O, S) saiu certo e no método. O que segurou a venda foi o E (objeção de marketing viva + bateu de frente) e o R (só 1 das 3 portas feita, então sem sim/sim/sim pra ancorar o fechamento; garantia depois do preço), somados à restrição financeira real e às quedas de conexão. Ficou em aberto, mas é fechável no follow-up.

---

## ⚠️ Onde o Matheus falhou no próprio framework

**1. Só 1 das 3 portas foi feita (o furo central).** O R do CLOSER fecha com as 3 perguntas: "faz sentido?", "é pra você?", "você acredita que a GENTE é a pessoa?". A forma é livre (em bloco no fechamento ou distribuída na apresentação, tanto faz), mas as 3 têm que sair antes do preço. Tu fez só a 1ª. A 3ª (confiar no executor) nunca veio, justo o calcanhar de um cara queimado por 3 agências. Resultado: chegou no fechamento sem o sim/sim/sim, então não deu pra ancorar "você falou que faz sentido, que é pra você, que confia na gente, só falta o valor, sim ou não?". É a peça que faltou pro R ter chão. **[[CLOSER R2 — Versão Matheus]].**

**2. Bateu de frente na objeção de marketing/telefone, e ela saiu viva.** "Mas você atendeu o nosso, não atendeu?" confronta a experiência do cliente e faz ele defender a posição dele ("porque estava programado"). Faltou o "concordo, muita gente não atende mesmo" antes do reframe. A objeção de marketing foi a crença que mais segurou a venda e nunca morreu (ele saiu falando que vai "estudar fazer o marketing dele"). **Call 1 [122:00] e [97:18].**

**3. Garantia depois do preço.** Soltou R$4.000 e só DEPOIS trouxe a garantia, quando o cliente já tinha recuado ("vou analisar"). A Synergy fechou fazendo o contrário: garantia antes do número pra zerar o risco percebido. A garantia é forte, só veio na ordem errada. **Imersão [222:54].**

**4. Tratou como "só preço" sem ter isolado de verdade.** Perguntou "seria só preço?" mas o Ladislau respondeu "preço E estudar" e voltou pro marketing. Tinha objeção viva. Soltar o número ali foi cedo, devia ter matado a objeção de marketing primeiro. **Imersão [330:00].**

**Não é falha (eu tinha marcado errado e retratei):** detalhar os pormenores da entrega / abrir o mapa mental é o Passo D do método, pode e deve ser técnico. Mostrar exemplo de quebra de objeção é demonstrar o entregável, não consultoria grátis. E a oferta-frase/destino tava certa. O L racional confirmado é etapa cumprida; a dor emocional seria um plus, não correção.

---

## Aplicação na próxima R2 (e no follow-up de hoje 20h)

- [ ] **Fazer as 3 portas antes do preço** (forma livre): "Faz sentido?" / "É pra você?" / "Você acredita que a gente é a pessoa certa?". O furo de hoje foi fazer só 1. Chegar no fechamento com sim/sim/sim na mão, com atenção especial à 3ª (confiar no executor).
- [ ] **"Concordo" antes de contornar, nunca bater de frente.** Validar a visão do cliente ("faz sentido pensar em marketing") e só então reframar. Matar a objeção antes do preço.
- [ ] **Garantia SEMPRE antes do preço.** Zera o risco, depois solta o número.
- [ ] **Isolar de verdade:** só soltar preço quando sobrar SÓ preço. Se tiver objeção viva, resolve primeiro.
- [ ] **Plus opcional:** somar a dor emocional no L e no destino ("empresa que roda sem você") pra esquentar. Não é obrigatório, mas turbina.
- [ ] **Manter o que funcionou:** C decorado, L feito, O limpo, oferta-frase/destino certos, apresentação técnica detalhada (Passo D), garantia forte, reframe de pagamento por marco, prazo de resposta com hora.

---

## 🎯 Próximo passo prático (follow-up até 20h de hoje)

O cliente está dividido entre dois pesos: **financeiro** ("tiro do bolso, valor alto hoje") e **crença em marketing** ("tem que ter marketing junto, tô estudando fazer o meu"). A mensagem do WhatsApp não pode ser só "segue a proposta". Tem que matar essas duas objeções por escrito.

- [ ] **Mandar a proposta escrita** (ele pediu print/texto curto, não PDF gigante).
- [ ] **Reabrir com a dor emocional** que faltou na call: "Ladislau, teu problema não é falta de venda. É uma empresa que hoje depende só de você. A Ignição existe pra ela rodar sem você na rua todo dia."
- [ ] **Matar a objeção de marketing por escrito:** "Você falou que tá estudando montar marketing. Justo por isso ligação comercial é o caminho: anúncio te traz residencial (o que você já tem demais), e ligação mira o comercial de ticket alto. O marketing você monta com calma depois, sem travar a venda agora."
- [ ] **Garantia em destaque, antes do valor:** "A gente só encerra os 45 dias depois das 10-20 visitas acontecerem. Se não bater, a gente continua sem cobrar mais nada."
- [ ] **Reforçar o pagamento que ele já topou:** entrada R$1.500 + saldo em 30 e 45 dias. Ancorar que ele mesmo desenhou.
- [ ] **3ª porta + CTA com hora:** "Você confia na gente pra reinstalar isso com você? Se sim, me confirma até 20h que amanhã às 10h a gente já faz o onboard e em 7 dias você tem a primeira visita marcada."

---

## Documentos relacionados
- [[2026-06-16 — Matheus vs Ladislau (R1)]] — a R1 de ontem, com o roteiro CLOSER que era pra rodar hoje
- [[2026-05-05 — Matheus e Tino vs Synergy (R2)]] — referência de R2 que FECHOU (garantia antes do preço)
- [[2026-05-13 — Matheus vs Daniel Daolio (R2)]] — referência de R2 que fechou pelo R bem feito
- [[Mentoria Nimoto — Índice]]

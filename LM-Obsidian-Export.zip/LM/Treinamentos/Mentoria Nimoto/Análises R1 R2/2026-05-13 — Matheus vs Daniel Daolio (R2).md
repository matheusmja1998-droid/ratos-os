---
tipo: análise R2
data: 2026-05-13
vendedor: Matheus Jardim
prospect: Daniel Daolio (Meta Mavi)
nicho: agência de tráfego (solo, Guarulhos/SP)
contexto: R2 após R1 do dia 08/05
oferta: Cockpit Setup — mentoria 30 dias, 4 encontros semanais, R$1.000 parcela única
resultado: FECHADO — R$1k via Pix, contrato + nota fiscal, kickoff a marcar
tags: [mentoria, nimoto, r2, análise, lm, daniel-daolio, fechamento]
fontes:
  - "[[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]"
  - "[[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]]"
  - "[[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]]"
  - "[[CLOSER R2 — Versão Matheus]]"
  - "[[2026-05-05 — Matheus e Tino vs Synergy (R2)]]"
---

# Análise — Matheus vendendo para Daniel Daolio (R2)

R2 com o Daniel Daolio (Meta Mavi), agência solo de Guarulhos, 8 clientes, contratou Cockpit Setup pela L.M Agência. Call de ~56 minutos. **Fechou R$1k via Pix, contrato + nota fiscal combinados, kickoff a marcar.** Diferente da R2 Synergy (que fechou pelo método clássico), essa fechou por um caminho mais lateral: demos pesadas no início + Daniel se vendendo sozinho ao descarregar a operação Takaki + Matheus aplicando o R do CLOSER com recap das 3 portas no momento certo.

> [!info] Resultado e diagnóstico geral
> Fechou. CLOSER apareceu em 4 das 6 letras (C ✅ L ⚠️ O ⚠️ S ⚠️ E ✅ R ✅✅). O fechamento foi limpo: recap das 3 portas → isolou objeção de preço → confirmou com pergunta-âncora → soltou número → fechou. **A grande sacada foi aguentar o tempo de descarrego do Daniel sobre Takaki e voltar pro fechamento sem perder o fio.** O que ficou aberto: não fez L com nome próprio, não construiu oferta-frase MAGIC, não distribuiu as portas durante apresentação. Mas FECHOU — método é meio pelo resultado, não pela ortodoxia.

---

## Bloco 1 — Abertura e C do CLOSER

> Matheus: "Mudou alguma coisa desde a última conversa para essa? Tem alguma coisa nova acrescentar que você gostaria de estar pensando em fazer com Cloud?"

**Conceito:** **C do CLOSER em versão R2** — pergunta de atualização desde a última call.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [311:25] — *"A primeira coisa numa reunião não é se apresentar. É descobrir por que aquele cliente aceitou."*
**Por que funciona:** ✅ exatamente a fórmula do roleplay com Nimoto, mesma da R2 Synergy. Memória muscular consolidada. Frase decorada saindo natural.

---

> Daniel: "Cara, de forma geral, acho que tem a parte da gestão financeira aqui da agência que eu queria terceirizar pro Cláudi... aí tá falando com o meu contador agora se ele já viu alguém fazendo essa conexão lá no Conto Azul."

**Movimento do prospect:** Daniel verbalizou avanço numa dor que ele trouxe na R1 (financeiro). Está executando, está engajado, está validando o caminho.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema que ele te fala, é a intenção."*
**Intenção real:** "tô comprometido com o caminho, tô buscando solução, valido a tese". Sinal verde imediato.

---

> Daniel: "Não consegui parar, cara. Eu só realmente usei o cloud por enquanto mesmo... ainda não conseguia parar para fazer."

**Movimento do prospect:** confessou que NÃO executou o setup técnico. Verbalizou a própria barreira (tempo).
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema, é a intenção."*
**Intenção real:** "preciso de mão, sozinho eu travo." **Esse era o L do CLOSER se apresentando sozinho.** Matheus pegou parcialmente (lá adiante usa essa fala como pivô do fechamento) mas devia ter ancorado na hora: *"Daniel, é exatamente essa dor que a mentoria de 30 dias mata."*

---

## Bloco 2 — Demos do Cockpit (mistura de prova social com voo prematuro)

> Matheus: "Quer ver, mano? Deixa te compartilhar uma parada que eu fiz ontem... Aí mostro carrosséis, vídeos motion, cortes virais de 1 reunião."

**Conceito:** **Demos de prova social — carrossel Cockpit, vídeo motion, cortes virais.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] — Princípio da prova social.
**Por que funciona parcialmente:** ✅ mostrou capacidade técnica concreta (3 produtos rodando), Daniel ficou impressionado ("muito visual"). ⚠️ mas foi vender voo antes de vender destino — o S correto vinha depois da tríade da dor (O). Inverteu a ordem do CLOSER. Acabou funcionando porque a prova social era forte. Mas o caminho ortodoxo é: L → O → S (com oferta-frase + 3 pilares) → demo só dentro do S.

---

> Daniel: "No caso, a criação da imagem foi pelo próprio cloud ou se usou outra plataforma?"

**Movimento do prospect:** pergunta operacional curiosa. Indica que a demo gerou curiosidade técnica.
**Por que importa:** sinal de que o prospect tá processando informação, não tá vendendo objeção. Bom sinal de engajamento.

---

> Matheus: "Hoje o a gente entende do seu problema ali, é basicamente um uma falta de tempo para terminar de organizar o cloud, colocar tudo em dia também e também a falta de tempo na realidade de trazer o cloud para te ajudar nessa liberar mais espaço de tempo no teu dia a dia ali."

**Conceito:** **Tentativa de L do CLOSER — rotular o problema.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [317:35] — *"Dê um nome ao problema."*
**Por que funciona parcialmente:** ✅ resumiu o problema corretamente (falta de tempo pra terminar setup + falta de tempo pra trazer IA pra rotina). ⚠️ mas usou linguagem genérica ("falta de tempo"), não pegou um TERMO DO DANIEL pra devolver. Daniel falou "calcanhar de Aquiles master", "uma porrada de coisinha", "umas semanas configurando" — qualquer um desses viraria L mais forte que "falta de tempo". **Aceita.**

---

> Matheus: "Seria isso mesmo essa linha, mano?"
> Daniel: "É isso mesmo. Ah, show de bola, mano."

**Conceito:** **Pergunta-âncora de validação do L** — força o prospect a confirmar em voz alta.
**Aula:** [[CLOSER R1 — Versão Matheus]] — *"Faça o cliente repetir o problema em voz alta."*
**Por que funciona:** ✅ Daniel confirmou em voz alta ("é isso mesmo"). Comprometeu-se publicamente com o problema. Movimento limpo do L.

---

## Bloco 3 — O do CLOSER (urgência)

> Matheus: "E como que tu tá de urgência para resolver isso? É urgente para ti? Tu quer resolver logo? Como que tá isso daí hoje?"

**Conceito:** **O do CLOSER em versão R2 — pergunta de urgência presente.**
**Aula:** [[CLOSER R2 — Versão Matheus]] — *"Eu preciso entender uma única coisa: qual é o teu nível de urgência pra resolver esse problema hoje?"*
**Por que funciona:** ✅ fez a pergunta certa de O. Em R2 o O é só urgência presente — a tríade (já tentou? por que falhou? quanto perdeu?) é da R1. Aqui o foco é só medir temperatura. ⚠️ formato meio amassado ("tá urgente? quer resolver logo? como tá?") — a versão Nimoto pura é mais limpa: *"Eu preciso entender uma única coisa: qual é o teu nível de urgência pra resolver esse problema hoje?"* Pra próxima R2 vale decorar essa frase.

---

> Daniel: "Cara, tem uma coisa que é muito mais urgente que eu já tô resolvendo, que é da alimentação dos perfis novos... Agora nessa parte do da configuração e tudo mais, uma outra... a segunda maior urgência é aquela clínica que eu te mostrei na nossa última reunião."

**Movimento ouro do prospect:** Daniel verbalizou **ranking de urgência** (alimentação de perfis = #1, Takaki = #2, Cockpit Setup implícito = #3). Confessou prioridade interna sem ser perguntado.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema, é a intenção."*
**Intenção real:** "quero falar de Takaki, deixa eu descarregar isso aqui antes de seguir." Daniel pediu pra contar a história da Takaki. Matheus aceitou ouvir — decisão correta, mesmo que não-ortodoxa.

---

## Bloco 4 — Descarrego da Takaki (Matheus aguenta o tempo)

Daniel passa ~15 minutos contando a operação Takaki em detalhe: stack (Cláudia + Versátiles), números (502 leads, 25% conversão no robô, R$33k receita), histórico de testes de fluxo, dor da equipe, orçamento concorrente (R$4k pela integração), até quanto ele cobra (R$2k/mês) e quanto subiria se conseguisse vender automação (R$600-700 a mais).

> Daniel: "eu não consegui pensar em nada para vender ainda para esse cliente porque o nível de complexidade tá num nível que eu ainda não conseguia achar uma solução."

**Movimento do prospect:** confessão de incapacidade. Sinal de confiança alta (admitiu fraqueza pra Matheus). Janela explícita pra upsell futuro.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [48:38] — *"Reciprocidade é entender."*
**Por que importa:** Daniel se abriu inteiro. Indica que ele confia em Matheus o suficiente pra mostrar gargalo. Munição pra Matheus aterrar argumento de autoridade depois.

---

> Daniel: "O meu contrato com eles hoje é 2.000 por mês. Se eu conseguisse, por exemplo, vender uma automação mesmo que eu jogasse na mensalidade com mais 600, 700 conto pelo menos por mês ali, pô, já me dava um um maior ticket médio aqui na agência."

**Movimento ouro do prospect:** entregou número de contrato + número de upsell desejado. **Daniel pintou o quadro do ROI da mentoria sozinho** — se a mentoria de R$1k destrava R$700/mês de upsell num cliente, paga em 6 semanas.
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [116:46] — *"Quem faz as perguntas está no controle da conversa."*
**Como Matheus usou:** lá adiante (no bloco do R) Matheus traz isso de volta indireto ("você vai conseguir fazer isso") — não amarra com número específico, mas o cliente já tinha o número na cabeça. **Aceitável.**

---

> Matheus: "Aqui a gente já fez automações de 8N para fazer atendimento assim. E só para ter noção, lá dentro dessa clínica, tinha oito médicos atendendo oito agendas diferentes que a IA cruzava... voltava pra agenda, ela marcava."

**Conceito:** **Prova social específica e operacional.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] — Princípio da prova social + autoridade.
**Por que funciona:** ✅ caso real, com números (8 médicos, 8 agendas), descrição operacional de cada etapa (paciente chega → robô pergunta convênio → checa agenda → marca → confirma 1 dia antes). Posicionou Matheus como executor experiente. Daniel ficou em silêncio reverente. **Elemento de venda mais forte da call.**

---

## Bloco 5 — Tentativa de S do CLOSER (mistura sutil de venda + consultoria)

> Matheus: "Eu acho, mano, que isso daí tu trabalhar com a gente com N8N para fazer essa parte ali do atendimento no WhatsApp e linkar esse atendimento dentro do da plataforma de gestão deles. Bate certo."

**Conceito:** **Tentativa de plantar destino sem oferta-frase MAGIC pronta.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final, não o voo."*
**Por que funciona parcialmente:** ⚠️ apontou caminho técnico ("trabalhar com a gente com n8n") mas sem fórmula MAGIC pronta. A oferta-frase decorada seria: *"Daniel, em 30 dias, a gente vai te tirar da operação travada por falta de tempo através de um Cockpit organizado e skills personalizadas, pra você atender mais clientes com a mesma equipe."* Tu falou isso em pedaços ao longo da call, mas nunca em uma frase fechada.

---

> Matheus: "Mano, e tipo assim, você poderia estar fazendo isso daí é como se fosse um atendimento... tu poderia fazer isso até com N8N, trabalhar um bote de atendimento no WhatsApp."

**Conceito:** **Sugestão técnica que mistura consultoria com posicionamento.**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [110:48] — *"Cobra antes de ensinar."*
**Por que funciona parcialmente:** ⚠️ entregou o caminho técnico (n8n + bot + atualizar CRM). Risco era Daniel pegar e fazer sozinho. **Funcionou porque:** Daniel já confessou que não consegue fazer sozinho ("não consegui pensar em nada pra vender pra esse cliente"). A entrega técnica reforçou autoridade SEM destruir a venda — o problema dele não é "não saber o caminho", é "não ter tempo nem visão estratégica". **Aceita pelo contexto.**

---

## Bloco 6 — O pivô (Matheus volta pro fluxo de venda)

> Matheus: "Daí, mano, o que que eu pensei para tá te ajudando aqui de maneira mais fácil? Cara, tu tá, sinceramente, tu tá no caminho certo, tu tá mexendo já com Cloud Pro, já tá com VPS montada, tá montando o Open Cloud ali. E tu mesmo falou que, cara, às vezes tem semanas ali que tem, ó, que tá configurado, tá configurando, só que ainda não terminou."

**Conceito:** **Movimento de retomada — Matheus reconhece autoridade do prospect + devolve a fala dele (que não conseguiu terminar).**
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [48:38] — *"Reciprocidade é entender: cara, eu entendo como você se sente."*
**Por que funciona:** ✅ reciprocidade real ("tu tá no caminho certo") + devolveu a barreira do próprio Daniel ("ainda não terminou"). Sem bater de frente. Movimento de espelho que reforça aliança antes de propor.

---

> Matheus: "O que que eu pensei aqui, cara? Trazer ali contigo um mês pra gente tá fazendo a estruturação do teu cloud."

**Conceito:** **Apresentação da oferta — Cockpit Setup, 1 mês.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Oferta simples, clara e objetiva."*
**Por que funciona parcialmente:** ✅ oferta clara ("um mês, estruturação do teu Cloud"). ⚠️ mas sem oferta-frase MAGIC completa. Faltou tempo + saída de + mecanismo + destino numa frase única. Funcionou porque o terreno já tava preparado pela demo + descarrego da Takaki.

---

> Matheus: "Eh, e estruturação no sentido do sentido que a gente traz aqui, mano, que é estruturação de pasta, como que você salvar os dados do cliente, como que tudo deixar o cloud com cada vez mais contexto. E no teu caso, mano, que é o plano pro, tem que ter uns macetes."

**Conceito:** **Apresentação dos pilares (versão informal).**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Divida sua solução em 3 pilares."*
**Por que funciona parcialmente:** ⚠️ pilares aparecem espalhados (organização de pasta, salvar dados, macetes de token) mas não foram numerados nem nomeados como 3 pilares. A Synergy teve "máquina de leads / time estruturado / previsibilidade" — fórmula limpa. Aqui ficou prosa. **Aceita pela ocasião** (cliente já tava vendido) mas pra próxima R2 vale formatar 3 pilares numerados.

---

> Matheus: "Tem várias mini coisas dentro da tua operação que tu consegue ver ajustando para você trabalhar mais inteligente, sacou? E se o teu cloud te entregar mais resultado e aí a gente consegue vir te ajudando nisso daí."

**Conceito:** **Plantio de destino — "trabalhar mais inteligente, ter mais resultado".**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final."*
**Por que funciona:** ✅ destino claro (trabalhar mais inteligente + mais resultado dos clientes). Linguagem direta. Daniel já tinha verbalizado o mesmo destino antes ("encantar antes do cliente pedir") — Matheus ecoou. Aliança.

---

## Bloco 7 — 1ª e 2ª portas do R do CLOSER

> Matheus: "Faz sentido na sua realidade? Faz sentido a gente fazer algo nesse sentido ou..."

**Conceito:** **1ª e 2ª portas do R do CLOSER** (faz sentido + é pra você).
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Você entende que esse serviço atende suas necessidades? Você acredita que isso se encaixa pra sua empresa hoje?"*
**Por que funciona:** ✅ portas certas, pergunta certa, em bloco igual o Nimoto faz. As 3 portas podem vir juntas no fechamento — o Nimoto faz assim. O importante é estarem armadas antes do preço, não distribuídas.

---

## Bloco 8 — Objeção do preço (E do CLOSER)

> Daniel: "Vai só vai depender mesmo de de preço mesmo para ver caixa tal. E aí... porque igual eu falei, eu nem finalizei ainda algumas configurações que eu precisava."

**Movimento crítico do prospect:** **objeção dupla** — preço + caixa + execução em débito. Não é "não quero", é "tô na dúvida se cabe agora".
**Aula:** [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] [80:24] — *"Não é o problema, é a intenção."*
**Intenção real:** "se for caro eu não tenho. se for justo, tô dentro."

---

> Daniel (continua): "E aí, tipo, ter talvez um um compromisso ali, tipo, ah, uma, duas vezes por semana vai sentar, tá, para poder ajudar alguém a a configurar as paradas para já deslumbrar essa questão de como economizar tokens, o que conectar com o quê."

**Movimento ouro do prospect:** **Daniel desenhou o formato que aceitaria** — 1-2x/semana de mentoria sentando junto. Sem ser perguntado. **Sinal de compra no formato dele.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Como posso facilitar pra você fechar comigo agora?"* (variante: cliente facilita sozinho).
**Por que importa:** o prospect entregou de bandeja o formato + ritmo + valor percebido. Matheus precisava só amarrar.

---

> Daniel: "Eu consegui fazer uma coisa que eu acho que é é muito válido, eh, no sentido de encantamento dos clientes, é quando eu trago uma solução ou uma visão de melhora, alguma coisa assim, antes do cliente precisar pedir."

**Movimento do prospect:** Daniel verbalizou o destino dele com palavra própria — **"encantamento dos clientes"**. **Material puro pra oferta-frase MAGIC.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final."*
**Oportunidade que apareceu (e foi usada parcialmente):** Matheus devia ter pegado "encantamento" e devolvido como L+S num único movimento: *"Daniel, é exatamente o destino que a gente vai construir contigo — agência que encanta antes do cliente pedir."* Tu não fez explícito, mas no bloco do R amarrou indireto. **Funcionou mas dava pra ser mais cirúrgico.**

---

## Bloco 9 — Fechamento: R do CLOSER (esse foi a obra-prima)

> Matheus: "Isso daí, velho, a gente eh a partir do momento que tu vai trabalhando cada vez mais assertivo ali dentro do cloud, mano, tu vai ver que eh ele mesmo vai tá te ajudando... a gente consegue formatar um mês ali, um encontro por semana e daí a gente senta na CUD on board ali do do primeiro encontro e faz o setup do cloud."

**Conceito:** **Reapresentação da oferta amarrada com promessa de evolução do Daniel.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [326:50] — *"Venda o destino final."*
**Por que funciona:** ✅ trouxe oferta de volta DEPOIS de Daniel ter desenhado o formato. Confirmou o formato que ele pediu (1 encontro por semana, 1 mês, setup no primeiro). Espelho perfeito.

---

> Matheus: "E a partir disso a gente vem tentando pegar problemas ali que você tem no teu dia a dia pra gente vir ajustando e e a gente vir criando coisas dentro do teu cloud para facilitar o trabalho do teu trampo no dia a dia."

**Conceito:** **Plantio de valor contínuo — não é só setup, é construção colaborativa.**
**Por que funciona:** ✅ posicionou a mentoria como construção conjunta, não como entrega passiva. Reforçou autonomia futura do Daniel ("não ficar 100% dependente das pessoas, de pagar para ninguém").

---

> Matheus: "Tu falou ali, cara, que faz sentido hoje para você, que você acredita que isso é para ti, que a gente consegue tá te ajudando ali, ficava só a parte de preço. É isso mesmo, né?"

**Conceito:** **JOGADA DE OURO — recap das 3 portas + isolamento da única objeção restante + pergunta-âncora de confirmação.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Se sim/sim/sim, sobra apenas valor."*
**Por que funciona MUITO:**
- Resgatou as 3 portas (sentido + é pra ti + sou a pessoa) em uma frase
- Isolou a ÚNICA objeção restante (preço) — fora dela, fechou tudo
- Pergunta-âncora "é isso mesmo, né?" obriga confirmação
- Daniel só pode responder sim ou apresentar objeção nova (que ele não tem)

**Exatamente o que o Nimoto ensina na fórmula de fechamento.** ✅✅

---

> Daniel: "Sim."

**Movimento do prospect:** **compromisso público com a estrutura toda.** A partir daqui só falta o número.

---

> Matheus: "E aí se não for tirando isso, a gente consegue dar o start nisso daí, né?"

**Conceito:** **Sugestão de start condicional — pré-fechamento.**
**Por que funciona:** ✅ jogou a bola pra Daniel decidir o gatilho. Não pressionou número direto. Manteve elegância.

---

> Daniel: "Sim."

**Movimento do prospect:** **segundo sim consecutivo.** Praticamente já fechado.

---

> Matheus: "Ah, fechou, mano. Mano, hoje a gente tem pega esse acompanhamento aí de um mês, um encontro por semana e daí dentro desse primeiro encontro a gente faz o setup... E, mano, nesse nesse mês aí, que que a gente pensou aqui nesses encontros aí semanais? A gente pensou no valor fixo ali no mês de R$ 1.000, mano, pra gente tá te ajudando aí nesse setup."

**Conceito:** **Recap da entrega + soltar o preço SEM rodeio.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Se sim/sim/sim, sobra apenas valor."*
**Por que funciona:**
- Reafirma escopo na hora do preço (1 mês, 1 encontro/semana, setup no primeiro)
- Solta o número direto (R$1.000) sem floreio
- Diz "fixo no mês" — implica simplicidade, parcela única, sem letra miúda

---

> Daniel: "Beleza, fechou."
> Matheus: "Aê, tu prefere Pix ou prefere cartão, mano?"

**Conceito:** **Pergunta-âncora de fechamento operacional** — duas opções concretas que pressupõem a compra.
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [330:00] — *"Como posso facilitar pra você fechar comigo agora?"*
**Por que funciona MUITO:**
- "Beleza, fechou" do Daniel = compromisso público
- Matheus emenda com pergunta operacional (Pix ou cartão) que assume o sim
- Não pergunta "tu quer?" — pergunta "como tu vai pagar?"
- Movimento clássico de fechamento por pressuposição ✅✅

---

> Daniel: "Não, vamos de Pix mesmo. Melhor Pix."

**Movimento do prospect:** escolheu o método e validou ("melhor Pix"). **Compromisso operacional concreto.**
**Por que importa:** o prospect tomou decisão prática — saiu do plano da intenção pro plano da execução. Venda saiu do verbal pro real.

---

> Matheus: "O seguinte, eh, a gente, tu, ó, a gente tem dois modelos aqui, mano. A gente tem um, e a gente pode fazer o contrato ou pode ficar tranquilo sem um contrato. O que que tu prefere? A gente prefere fazer um contratozinho explicando o que que vai fazer para ficar mais tranquilo."

**Conceito:** **Oferta de contrato com sugestão de preferência.**
**Aula:** [[Mentoria Nimoto — Fundamentos Comercial]] — formalização.
**Por que funciona parcialmente:** ✅ ofereceu contrato (boa prática). ⚠️ deu opção de "sem contrato", que é desnecessária — sempre fazer contrato. Aceita pelo Daniel ("pode sim, pode sim").

---

> Matheus: "E daí a gente assina o contrato, você faz o pagamento pra gente, a gente emite a nota fiscal para ti, para mandar pra contabilidade para ter tudo certinho e aí a gente já marca primeiro C de onboard. Pode ser?"

**Conceito:** **Sequência de pós-fechamento — contrato → pagamento → nota → onboard.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — *"As primeiras 48h são decisivas."*
**Por que funciona:** ✅ encadeou os 4 passos numa frase só. Profissionaliza a entrega. Promete nota fiscal (sinal de PJ formal, não freelancer). Marca onboard como próximo evento.

---

> Matheus: "Parabéns por estar junto com a gente aqui pra gente tá cada vez mais organizando a tua casa, deixar o seu mais produtivo e conseguir tá resolvendo os problemas dos clientes ali. E vamos para cima."

**Conceito:** **R do CLOSER — recepção calorosa imediata + reforço da decisão.**
**Aula:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]] [307:00] — *"Faça uma recepção calorosa."*
**Por que funciona MUITO:** ✅ "parabéns por estar junto" = reforço positivo da decisão (reduz remorso pós-compra). "Organizar a casa, deixar mais produtivo, resolver problema dos clientes" = recap dos 3 vetores de valor da mentoria, na ordem do Daniel. **Manual.**

---

> Daniel: "Fechou. Beleza."

**Movimento do prospect:** confirmação tripla (fechou + beleza + voltou no "estamos junto"). ✅

---

## Mapa-resumo

| Movimento | Conceito | Aula |
|---|---|---|
| "Mudou alguma coisa desde a última conversa?" | C do CLOSER (R2) | Imersão [311:25] |
| Daniel: "já tô resolvendo financeiro com contador" | Cliente validou caminho | Call 1 [80:24] |
| Daniel: "não consegui parar pra configurar" | Cliente confessou barreira (será o L) | Call 1 [80:24] |
| Demos pesadas (carrossel, motion, cortes) | Prova social + voo prematuro | Imersão (prova social) |
| Matheus resume: "falta de tempo" + "é isso mesmo?" | L do CLOSER com pergunta-âncora | Imersão [317:35] |
| "Como tu tá de urgência?" | O do CLOSER (urgência presente) | CLOSER R2 |
| Daniel: "Takaki é minha segunda maior urgência" | Cliente entregou ranking de dor | Call 1 [80:24] |
| Descarrego Takaki (15 min) | Daniel se abriu inteiro | Call 1 [48:38] |
| Daniel: "25% conversão, R$4k de cotação, R$700 de upsell" | Cliente entregou números | Call 1 [116:46] |
| Daniel: "não consigo pensar em solução" | Confissão de incapacidade | Call 1 [48:38] |
| Caso 8 médicos/8 agendas | Prova social específica + autoridade | Imersão (prova social) |
| "Trazer um mês contigo pra estruturação do Cloud" | Apresentação da oferta | Imersão [326:50] |
| "Tem várias mini coisas... trabalhar mais inteligente" | Plantio de destino | Imersão [326:50] |
| "Faz sentido na tua realidade? Faz sentido a gente fazer?" | 1ª e 2ª portas do R | Imersão [330:00] |
| Daniel: "vai depender de preço e caixa" | Objeção isolada | Call 1 [97:18] |
| Daniel: "1-2x/semana sentando junto" | Cliente desenhou formato | Imersão [330:00] |
| Daniel: "encantamento dos clientes" | Cliente verbalizou destino próprio | Imersão [326:50] |
| **"Tu falou que faz sentido, é pra ti, a gente te ajuda, ficava só preço. É isso?"** | **Recap das 3 portas + isolamento de objeção** | **Imersão [330:00]** |
| Daniel: "Sim" | Compromisso público | — |
| "Valor de R$1.000 fixo no mês" | Preço direto, sem rodeio | Imersão [330:00] |
| Daniel: "Beleza, fechou" + Matheus: "Pix ou cartão?" | FECHAMENTO + pressuposição operacional | Imersão [330:00] |
| "Contrato → pagamento → nota fiscal → primeiro C de onboard" | Sequência pós-fechamento + R | Imersão [307:00] |
| "Parabéns por estar junto, vamos para cima" | Recepção calorosa | Imersão [307:00] |

**Score CLOSER R2:** **C ✅ L ⚠️ O ⚠️ S ⚠️ E ✅ R ✅✅** — 4 letras sólidas, 3 com execução parcial mas suficiente.

**Comparação com a R2 Synergy (8 dias atrás):** Synergy fechou 6/6 (ortodoxo). Daniel fechou 4-3 (não-ortodoxo). **Os dois fecharam.** A diferença: na Synergy tu seguiu o método à risca. No Daniel tu confiou no tempo do prospect e fechou pelo R bem executado.

---

## ⚠️ Onde Matheus escorregou (mesmo fechando)

**1. Não rotulou o problema com NOME PRÓPRIO do Daniel.**
Daniel deu pelo menos 3 termos próprios: "calcanhar de Aquiles master", "encantamento dos clientes antes deles pedirem", "porrada de coisinha". Nenhum foi devolvido como L. Matheus rotulou genericamente ("falta de tempo"). **Imersão [317:35]** — nome próprio compromete mais.

**2. Não construiu oferta-frase MAGIC fechada.**
Faltou: *"Em 30 dias, a gente vai te tirar de [calcanhar de Aquiles master] através de [Cockpit Setup + skills personalizadas] pra você [atender mais clientes sem aumentar equipe]."* Saiu em pedaços ao longo da call. Fechou mesmo assim porque o terreno tava preparado. **Imersão [326:50]** — frase fechada vende mais.

**3. 3 pilares não numerados.**
Apresentação dos pilares saiu como prosa, não como "três pilares numerados". Pra próxima R2 vale formatar: *"1. Organização de pasta + contexto. 2. Skills personalizadas pra sua rotina. 3. Macetes de token e VS Code."*

**4. Demos antes do L.**
Mostrou carrossel + motion + cortes virais ANTES de rotular o problema. Ortodoxia manda: L → O → S (e demo dentro do S). Funcionou porque demos eram fortes, mas correu risco de Daniel pensar "isso é demais pra mim" antes de rotular dor.

**5. Ofereceu opção "sem contrato".**
Sempre fazer contrato. Não dar opção. **Aceita** porque Daniel aceitou contrato na hora, mas o fraseado deixou brecha.

---

## ✅ O que funcionou MUITO

**1. C do CLOSER decorado.**
Abriu com a frase exata do roleplay com Nimoto. Memória muscular consolidada.

**2. Aguentou o tempo do prospect.**
Daniel descarregou 15 minutos de Takaki. Matheus não cortou, não acelerou, não tentou voltar pro fechamento antes da hora. **Confiar no tempo do cliente é movimento de closer experiente.** O Nimoto fala muito disso (escutar pra ouvir, não pra responder).

**3. Caso 8 médicos/8 agendas.**
Prova social cirúrgica. Específica, operacional, com números. **Elemento de venda mais forte da call.** Posicionou autoridade sem ostentação.

**4. Recap das 3 portas + isolamento de objeção em UMA frase.**
*"Tu falou que faz sentido, que é pra ti, que a gente te ajuda. Ficava só preço. É isso mesmo, né?"* — essa frase é manual. **Replicar em toda R2.**

**5. Preço direto, sem rodeio.**
R$1.000 fixo no mês. Sem floreio, sem desconto, sem "podemos conversar". **Imersão [330:00]** — número direto após sim/sim/sim.

**6. Sequência pós-fechamento profissional.**
Contrato → pagamento → nota fiscal → onboard. 4 passos, 1 frase. Profissionaliza a entrega e mata objeção de "será que é gente séria?".

**7. Recepção calorosa imediata.**
"Parabéns por estar junto" + recap dos 3 vetores de valor. Reduz remorso pós-compra. **Imersão [307:00]** — primeiras 48h.

**8. Confiou no método mesmo sem seguir à risca.**
Não entrou em pânico quando viu que a estrutura tava saindo da ordem clássica. Voltou pro R no momento certo e fechou. **Maturidade de vendedor.**

---

## Aplicação na próxima R2

- [ ] **Decorar oferta-frase MAGIC completa antes da call:** *"Em [tempo], a gente vai te tirar de [problema com nome próprio do cliente] através de [mecanismo], pra você [destino]."*
- [ ] **Rotular com NOME PRÓPRIO do cliente:** anotar 2-3 termos próprios dele durante a call e devolver no L.
- [ ] **O do CLOSER em R2 = só urgência presente** — decorar versão Nimoto pura: *"Eu preciso entender uma única coisa: qual é o teu nível de urgência pra resolver esse problema hoje?"*
- [ ] **Numerar os 3 pilares na apresentação.**
- [ ] **Demo só dentro do S, depois de L+O.**
- [ ] **Não oferecer "sem contrato" — sempre contrato.**
- [ ] **Manter:** C decorado + aguentar tempo do prospect + prova social específica + recap das 3 portas + preço direto + sequência pós-fechamento + recepção calorosa.

---

## Frases de ouro pra repetir

1. *"Mudou alguma coisa desde a nossa última conversa? Tem alguma coisa que tu queira acrescentar?"* (C decorado)
2. *"Tu falou que faz sentido, que é pra ti, que a gente te ajuda. Ficava só a parte de preço. É isso mesmo, né?"* (recap 3 portas + isolamento)
3. *"O valor fixo no mês fica em R$1.000."* (preço direto)
4. *"A gente faz contrato, você faz o pagamento, a gente emite nota fiscal pra ti, e já marca o primeiro encontro de onboard. Pode ser?"* (sequência pós-fechamento)
5. *"Parabéns por estar junto com a gente. Vamos para cima."* (recepção calorosa)

---

## Próximo passo prático

- [ ] Mandar contrato pro Daniel hoje via WhatsApp (já tem link do Google Doc)
- [ ] Confirmar pagamento R$1k via Pix CNPJ LM
- [ ] Combinar data do 1º encontro (kickoff/onboard) — ideal nas próximas 48h pra cumprir [Imersão 307:00]
- [ ] Emitir nota fiscal da LM após pagamento
- [ ] **Plantar semente do upsell pós-Setup:** no 1º encontro, abrir já dizendo *"Daniel, da R2 tu trouxe que aceitaria mais R$600-700 na mensalidade da Takaki se conseguisse vender automação. Vamos focar o Setup já com isso em mente — construir automação Takaki como caso real e tu virar produto pra outros clientes."*

---

## Documentos relacionados

- [[Daniel Daolio — Meta Mavi (Dossiê)]]
- [[2026-05-13 — Call Daniel (Follow-up Cockpit)]] — transcrição completa
- [[Contrato — Daniel Daolio x LM Agência (Cockpit Setup)]]
- [[2026-05-05 — Matheus e Tino vs Synergy (R2)]] — referência canônica de R2 (ortodoxa)
- [[CLOSER R2 — Versão Matheus]] — método estudado
- [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]

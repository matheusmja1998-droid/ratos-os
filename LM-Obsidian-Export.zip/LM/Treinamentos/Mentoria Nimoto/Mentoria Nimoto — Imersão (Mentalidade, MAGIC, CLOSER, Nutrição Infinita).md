---
tipo: nota
agência: LM
evento: Imersão Gustavo Niimoto (25-04-2026)
fonte: [[Transcrição Imersão Niimoto (25-04-2026) - 7h]]
tags: [mentoria, nimoto, comercial, imersão, frameworks]
data: 2026-04-25
---

# Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)

Aprofundamento operacional do que veio na imersão de 7h. Complementa [[Mentoria Nimoto — Fundamentos Comercial]] e [[Mentoria Nimoto — Execução e Webinar]] — aqui ficam os 12 frameworks novos que não apareceram nas notas anteriores.

---

## 1. Mentalidade & Comportamento (módulo 1 — [00:00])

### Mito da paixão vs realidade do dever
Ninguém ama 100% do trabalho. Você não precisa amar prospectar. Precisa fazer.
**A única emoção verdadeira é orgulho ao deitar a cabeça no travesseiro.**

> "Você não precisa amar o teu trabalho. A maior parte do teu tempo será gastar com tarefas difíceis." [02:09]
> "O único sentimento que eu tenho de mim mesmo é orgulhoso. Orgulhoso é diferente de motivado." [05:13]

### Tolerância à frustração
Capacidade de realizar a mesma tarefa repetidamente sem recompensa e seguir em frente. Atletas (Phelps, Kobe) repetem o mesmo até virar referência. **A maioria muda script depois de 2 semanas sem resultado.**

> "Em uma semana você não vê resultado, em duas semanas você não vê resultado, mas em um ano é impossível você não ver resultado." [13:54]

### Paixão pela excelência (não pela tarefa)
A paixão tem que ser por ser excelente, não pelo trabalho em si.
> "Excelência é olhar e falar: cara, eu fiz tudo que eu podia." [22:13]

### Não carregar pessoas
A maior razão de pobre não vencer é assumir os problemas de 10 outras pessoas quando começa a ganhar.

> "Aguenta fome. A fome é suportável." [41:55]

### Separação total do caixa (PJ vs PF)
Dinheiro da empresa é da empresa. Pague-se **só comissão** (no caso dele 20%).

> "O dinheiro da empresa não é o seu dinheiro. Você é literalmente o seu primeiro funcionário." [51:39]
> "Parem de ser frouxos. Se você não vive do comissionamento da sua empresa, não oferece isso pra outras pessoas." [58:09]

### Fórmula 12h x 2 anos
> "O homem que eu quero ser está a dois anos trabalhando 12h/dia. Cada dia que não faço, aumento um dia de distância." [60:55]

---

## 2. Prospecção Ativa (módulo 2 — [66:00])

### Estudo profundo do nicho via NotebookLM
**Nunca prospecte sem 8h+ de podcast/vídeos do nicho consumidos passivamente** (lavando louça, esteira). Joga tudo no NotebookLM e pede top 5 insights por especialista, sem repetir. Cria sensação de familiaridade durante a venda. [73:30–82:00]

### O próprio convite É o melhor script
Ele recusa scripts prontos: "qualquer idiota copia, satura, para de funcionar." Em vez disso, perguntas-guia: motivo do convite, exclusividade, autoridade do convidador, número de empresas, três pilares do tema, limite de tempo. [82:00]

### Viagem de Confirmação (técnica nova)
Ligar como se a empresa já tivesse confirmado:
> "Tudo bem Leandro, liguei pra confirmar que a empresa de vocês tem um convite confirmado dentro do nosso evento quinta-feira 19h30."

Funciona pra passar pela secretária e pra remarcar reuniões com leads que sumiram. "As pessoas nem tinham nada marcado comigo." [82:10–94:30]

### Viés de Certeza
Tratar a presença do cliente no evento/reunião como já decidida. [94:30]

### Quem pergunta domina
> "Não sou eu que quebra a objeção do meu cliente. O meu cliente que quebra a própria objeção. Quem faz as perguntas está no controle da conversa." [116:46]

### Framework 3As (quebra de objeção, Hormozi adaptado)
1. **A**ceitar/reconhecer
2. **A**ssociar (com cliente de sucesso ou figura de autoridade)
3. **A**fundir/perguntar para o cliente quebrar a própria objeção

> "Toda objeção é falta de uma narrativa bem contada." [97:18]

---

## 3. Webinar (módulo 3 — [125:00])

### Vender o destino, não a passagem
> "Você não precisa de tráfego pago pra vender. Vende o destino, não a passagem." [193:14]

Cliente não compra "tráfego pago", compra "20 agendamentos a mais por mês".

### Como o cliente fazia ANTES da sua solução existir
Pergunta-chave do roteiro. Ensina o caminho difícil completo, depois oferece o atalho. Cliente compra pelo esforço evitado. [130:55]

### 5 crenças centrais do público
Mapear crenças que ele nunca resolve (medo do produto não ser bom, "tem cara mais burro vendendo mais que eu"). É o coração do evento. [136:00]

### Autoridade pela quebra de expectativa
Não tem experiência no nicho? Diga isso de cara. A honestidade vira diferencial. [145:00]

### Estrutura de blocos emocionais
Abertura (atenção) → 1ª revelação (surpresa) → cenários de consequências (5min de dor) → liberação (alívio) → 2ª revelação/demonstração (confiança) → chamado (não pitch). **5–10 min de pitch máximo.** [152:48–168:00]

> "Nada gera mais urgência do que esperança." [157:50]

### CTA = reunião, não venda direta
> "Quero conhecer sua empresa individualmente. Marca reunião." [161:00]

### B2B2C via comunidade R$5/mês
Para clínicas/profissionais, comunidade R$5/mês como nutrição. Captar via parceria com lojas que têm o mesmo público. [177:00–186:00]

---

## 4. Ofertas — Fórmula MAGIC (módulo 4 — [188:00])

### Equação do Valor
```
Valor = (Resultado × Probabilidade de sucesso) / (Tempo de espera × Esforço/sacrifício)
```
Toda oferta forte ataca esses 4 fatores. [189:46]

### 5 passos para criar oferta [203:58]
1. Específico (resultado desejado tangível)
2. Listar problemas/obstáculos
3. Transformar em soluções (narrativa)
4. Veículo de entrega (1-pra-1 = caro, escalável = barato)
5. Cortar irrelevante

### Esforço pequeno DO CLIENTE = preço alto
> "Quanto menos esforço o seu cliente tiver, mais caro você cobra." [208:30]

### SUI — Serviço Ultra Escalável
Sempre desenhar para que a entrega seja replicável. [213:30]

### Escassez REAL
Só funciona se for verdade verificável. Inventar escassez quebra a confiança. [219:35]

### Bônus = resolver o PRÓXIMO problema
Após implementar CRM, próximo problema é o time não preencher. Bônus = treinamento pra virar hábito. [222:30]

### Garantia de execução (não de resultado)
"Se em 30 dias não estiver implementado, devolvo o dinheiro." [222:54]

### Fórmula MAGIC [226:30]
- **M**otivo magnético
- **A**vatar
- **G**ol/destino
- **I**ntervalo de tempo
- **C**aminho/sistema

**Exemplo:** "Protocolo de Vendas para Agências e Prestadores | 20 mil em contratos assinados | sem trabalho comercial | em 60 dias | no nosso Sistema de Aquisição Sem Esforço."

---

## 5. CLOSER + R1/R2 (módulo 6 — [307:00])

### As 6 letras
1. **C — Clareza** [311:25] — A primeira coisa numa reunião NÃO é se apresentar. É descobrir por que aquele cliente aceitou se reunir.
2. **L — Label (rotular o problema)** [317:35] — Dar nome ao problema e fazer o cliente confirmar.
3. **O — Overview/enfatização da dor** [320:10] — Já tentou? Quanto perdeu? Quanto tempo? "Eu quero ver meu cliente triste."
4. **S — Sell the destination** [326:50] — Vender o destino final, NUNCA o voo. **Pitch máximo 3 minutos com 3 pilares.**
5. **E — Eliminar objeções** (3As: aceitar/associar/perguntar)
6. **R — Resolver com fechamento das 3 perguntas** [330:00]

### As 3 perguntas-chave de fechamento
1. "Você entende que esse serviço atende suas necessidades?"
2. "Você acredita que isso se encaixa pra sua empresa hoje?"
3. "Você acredita que eu sou a pessoa que consegue te entregar isso?"

Se sim/sim/sim, sobra apenas **valor**. "Como posso facilitar para você fechar comigo agora?" — **nunca dar desconto**.

### Quando fazer 1 reunião vs R1+R2
**1 reunião:** decisor único, urgência clara nos primeiros 5 min, lead pronto, vindo de webinar bem feito, presencial. [371:24]

**R1+R2:** tem sócio, ticket alto, resistência inicial. R1 = diagnóstico/insight; R2 = oferta personalizada (mesmo escopo, só o magic muda). [371:43]

---

## 6. Nutrição Infinita (módulo 7 — [394:00])

### Joey Girard como referência
Vendeu 1.435 carros em 1980 sem CRM, sem celular. 3 milhões de cartões de visita/ano. **O que segura: relacionamento.** [395:21]

### A maior parte do dinheiro está nos leads que NÃO compraram na primeira call
> "É impossível você abrir 10 milhões em propostas e não fechar 1 milhão no ano." [400:50]

### CRM como projeto de pesquisa
Anotar tudo (problema com funcionário X, evento na quinta, briga com sócio). **Espionagem de magia branca.** [407:01]

### Triângulo do amor aplicado [408:30]
1. Centelha química (entusiasmo de trabalhar junto)
2. Interesses comuns (metas alinhadas)
3. Intenção de comunicação contínua (segredo do follow-up)

### Lead só sai do funil se ele explicitamente recusar
Caso contrário, segue na nutrição infinita por 1 ano, 2 anos, indefinidamente. [418:11]
**Mínimo:** 1 reunião por mês com cada lead em proposta aberta. [419:35]

### Distribuição de fechamento
- 40-50% no curto prazo
- 35% no longo prazo (nutrição)

> "Você está jogando seu tempo e seu dinheiro fora porque está perdendo a maior parte do volume de vendas que vem do longo prazo." [422:01]

---

## Aplicação na L.M Agência

### Top 5 ações concretas

1. **Biblioteca NotebookLM Solar** — 8-15h de podcast/conteúdo do nicho (Canal Solar, Greener, ABSOLAR, casos de integradoras). Nenhuma R1 sai sem briefing extraído daí.

2. **Webinar B2B pro Jonas/Hypertech** — substituir mídia paga inicial por convite via viagem de confirmação → webinar mensal → R1+R2 → nutrição infinita. Piloto pros outros solares.

3. **Atualizar [[doc-de-guerra]] com CLOSER** — incluir as 3 perguntas-chave antes do fechamento da R2. Skill já existe, só calibrar.

4. **Nutrição infinita como diferencial vendável** — "Setor solar tem ciclo médio de 8 meses. Sua integradora perde 60% das vendas porque ninguém nutre. A gente nutre." Implementar trilha de 12 meses pros leads dos clientes.

5. **Conversa caixa PJ/PF com Valentino** — antes da L.M crescer e a desorganização virar problema. Prolabore zero, cada sócio puxa só comissão/% lucro pré-definido.

---

## Frases marcantes (para guardar)

1. "Você não precisa amar o teu trabalho. A maior parte do teu tempo será gastar com tarefas difíceis." [02:09]
2. "O único sentimento que eu tenho de mim mesmo é orgulhoso. Orgulhoso é diferente de motivado." [05:13]
3. "Em uma semana você não vê resultado, em duas semanas você não vê resultado, mas em um ano é impossível você não ver resultado." [13:54]
4. "Aguenta fome. A fome é suportável." [41:55]
5. "O dinheiro da empresa não é o seu dinheiro. Você é literalmente o seu primeiro funcionário." [51:39]
6. "O homem que eu quero ser está a dois anos de distância, trabalhando 12 horas por dia." [60:55]
7. "Toda objeção é falta de uma narrativa bem contada." [97:18]
8. "Quem faz as perguntas está no controle da conversa." [116:46]
9. "Nada gera mais urgência do que esperança." [157:50]
10. "Vende o destino, não a passagem." [193:14]
11. "Quanto menos esforço o seu cliente tiver, mais caro você cobra." [208:30]
12. "Eu quero ver meu cliente triste. Eu preciso elevar o nível de consciência da dor dele." [322:00]
13. "O lead entrou no funil é semente interno. Só regar que uma hora vai." [422:13]

---
tipo: índice
agência: LM
tags: [mentoria, nimoto, comercial]
criado: 2026-04-12
---

# Mentoria Nimoto — Índice

Mentoria de comercial comprada para escalar as vendas da L.M.

## Notas

1. [[Mentoria Nimoto — Fundamentos Comercial]]
   - Dominar antes de escalar
   - Blue Ocean em vendas
   - B2B é lógica, não emoção
   - Estrutura de reunião de vendas
   - Checkpoints

2. [[Mentoria Nimoto — Execução e Webinar]]
   - Oratória e transformar fraqueza em vantagem
   - Quebra de crenças
   - Checkpoints operacionais (7 dias antes, dia, durante, depois)
   - Prospecção ativa como motor
   - Metodologia com nome próprio

3. [[Webinars/Mentoria Nimoto — Webinário de Alto Impacto]]
   - Estrutura em 6 blocos
   - Outbound vs. Inbound
   - Checklist pré-webinar
   - 90%+ de retenção

4. [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]
   - Mentalidade aprofundada (PJ/PF, "pague-se só comissão", 12h x 2 anos)
   - Viagem de Confirmação + Viés de Certeza
   - Equação do Valor + Fórmula MAGIC
   - CLOSER (6 letras) + 3 perguntas-chave de fechamento
   - Nutrição Infinita (Joey Girard, triângulo do amor, 35% do faturamento)

## Transcrições

### Mentoria (calls de treinamento)
- [[Transcrição Mentoria Niimoto — Call 1 (18-04-2026) - 3h]] — primeira call de treinamento (18/04, ~3h): reunião de vendas → oferta → webinar
- [[Transcrição Mentoria Nimoto — R1 e R2 (01-05-2026)]] — continuação da Call 1 (01/05)

### Imersão (evento à parte)
- [[Transcrição Imersão Niimoto (25-04-2026) - 7h]] — imersão presencial 25/04 (~7h): Mentalidade → Tornando-se Imparável

### Outras
- [[Transcrição Webinar Nimoto]]

### Análises de R1/R2 (framework aplicado)
- [[Análises R1 R2/2026-05-04 — Nimoto vendendo Assim para V4 (referência)|2026-05-04 — Nimoto vs V4 (referência-mestre R1)]] — R1 do próprio Nimoto, serve de calibração pras minhas análises
- [[Análises R1 R2/2026-05-05 — Nimoto vs V4 (R2 referência)|2026-05-05 — Nimoto vs V4 (referência-mestre R2)]] — R2 do Nimoto, referência canônica da R2
- [[Análises R1 R2/2026-04-22 — Matheus e Tino vs Synergy (R1)]] — R1 do Synergy (CLOSER 0/6, vendemos por exaustão)
- [[Análises R1 R2/2026-04-23 — Matheus e Drea vs Revolux (R1)]] — R1 do Revolux
- [[Análises R1 R2/2026-05-05 — Matheus e Tino vs Synergy (R2)]] — R2 do Synergy (FECHADO R$4k, CLOSER 6/6)
- [[Análises R1 R2/2026-05-12 — Matheus vs João Luiz (R1)]] — R1 Doria Solar (escopo SDR/PDR, disciplina de escopo + clarificação tardia)
- [[Análises R1 R2/2026-06-09 — Matheus vs Marcos (R1)]] — R1 Fotovoltaico Brasil (perdeu frame, bateu de frente, dumpou R2 na R1; cliente ditou a oferta done-for-you)
- [[Análises R1 R2/2026-06-16 — Matheus vs Ladislau (R1)]] — R1 empresa solar em crise (cliente entregou dor/número/destino; faltou rotular e tríade). Inclui destino R2
- [[Análises R1 R2/2026-06-16 — Matheus vs Cafu (R1)]] — R1 Nalla (boa desqualificação, achou a oportunidade da esposa; amoleceu na objeção da crise). Inclui destino R2
- [[Análises R1 R2/2026-06-16 — Matheus vs Orion Solar (R1)]] — R1 multi-decisor (Aires/Fernando/Ricardo). Dono já validou o modelo (indicador); dumpou modelo+teste de fogo+preço na R1 (pré-ajuste). Inclui destino R2
- [[Análises R1 R2/2026-06-16 — Matheus vs BID (Matheus Garcia) (R1)]] — R1 integradora (caiu de 30 vendas pra 5). Ponte lógica impecável + isolou o decisor (pai); deixou passar o número de dor e bondou na política (pré-ajuste). Inclui destino R2
- [[Análises R1 R2/2026-06-17 — Matheus vs Denner (Termo Clima) (R1)]] — R1 climatização+solar (R1 mais limpa, segurou o pitch; nome errado o tempo todo). Pós-ajuste. Inclui destino R2
- [[Análises R1 R2/2026-06-19 — Matheus vs Cematech (Eduardo) (R1)]] — R1 player premium na arena errada (serviço forte preso na guerra de preço residencial). Pós-ajuste: segurou pitch + travou R2. Inclui destino R2
- [[Análises R1 R2/2026-06-16 — Apanhado geral das R1 (padrões)]] — apanhado cruzado de vários R1: o que acerto sempre (abertura) e erro sempre (não rotulo, falo demais, fecho R2 frouxo)

## Aplicação prática (scripts e roleplay)

- [[CLOSER R1 — Versão Matheus]] — script CLOSER aplicado à R1 (versão Matheus)
- [[CLOSER R2 — Versão Matheus]] — script CLOSER aplicado à R2 (versão Matheus)
- [[Call Roleplay R2 Synergy (05-05-2026)]] — roleplay aplicando o framework

---

## Principais aprendizados para aplicar na L.M

- [ ] Montar o script padrão de reunião de vendas com checkpoints
- [ ] Definir e nomear as ofertas com metodologia própria
- [ ] Estruturar o próximo webinar nos 6 blocos
- [ ] Fazer pesquisa de mercado com clientes do nicho antes de criar nova oferta
- [ ] Criar protocolo de follow-up pós-webinar (não deixar esfriar)

---
fonte: 04_Transcricao_Webnar_Nimoto
tipo: transcrição
agência: LM
tags: [nimoto, webinar, outbound, narrativa]
data: 2026-03-19
---

# Transcrição — Webinar Nimoto (19/03)

## Contexto
Evento ao vivo da Asset Sales (CEO: Nimoto). Participantes selecionados a dedo pelo time (Gustavo, Adriano e outros). Evento de outbound — leads escolhidos, não captados por anúncio.

## Conceito central apresentado
> "A gente faz o produto vender de forma muito mais tranquila através de uma narrativa."

O processo ensinado gira em torno de construir uma **narrativa de produto** que faz o cliente se mover em direção à compra antes mesmo de receber uma oferta direta.

## Princípios principais

### Engajamento no evento ao vivo
- Câmera ligada aumenta engajamento do palestrante
- Interação no chat gera valor mútuo
- Evento outbound = lead já qualificado = maior conversão esperada

### Narrativa como motor de vendas
- Não é sobre pitch — é sobre narrativa estruturada
- A narrativa conduz o cliente logicamente até a decisão
- Funciona em B2B porque respeita o processo racional do decisor

## Ver também
- [[Mentoria Nimoto — Fundamentos Comercial]]
- [[Mentoria Nimoto — Webinário de Alto Impacto]]

---

**Conteúdo destrinchado em:** [[Webinars/Mentoria Nimoto — Webinário de Alto Impacto]]
**Hub:** [[Mentoria Nimoto — Índice]]

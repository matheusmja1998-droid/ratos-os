---
tipo: método
data: 2026-05-05
autor: Matheus Jardim
fonte: estudo do método CLOSER aplicado em R1 (Nimoto)
tags: [closer, r1, método, nimoto]
---

# CLOSER NA R1 — Versão Matheus

Resumo do método CLOSER aplicado em R1, do jeito que entendi.

R1 é diagnóstico. Fica nas primeiras 3 letras (C, L, O) e fecha marcando R2 com promessa de projeto personalizado. O resto do CLOSER (S, E, R completos) acontece na R2.

---

## Abertura

- Fazer o rapport
- Uma apresentação breve sobre a minha empresa e como eu ajudo as empresas
- Partir pro método CLOSER

---

## C — Clareza

Perguntar pro cara, fulano, qual é o motivo de você estar aqui hoje? Eu quero saber qual é o problema que você busca resolver hoje na sua empresa, relacionado a:

- vendas
- time comercial
- aquisição de leads
- aumento de faturamento

Então eu quero entender um pouquinho mais sobre o seu problema, especificamente sobre isso, pra gente ter uma ótima reunião aqui hoje. Trazer essa linha de raciocínio pra ter clareza.

---

## L — Rotular o problema

Aqui você vai pegar o que ele falou na fase de clareza, transformar em um problema e trazer pra ele.

Então, fulano, hoje você precisa disso? Exemplo: ele falou que hoje é mais indicação, que não tem outro canal de aquisição de leads, que tem volatilidade. Então, basicamente, esse seria o problema.

> "Fulano, você me falou que o seu principal canal de leads é indicação. Então eu entendo que o seu principal problema hoje na sua operação é trazer um novo canal de vendas que traga o mesmo tanto de vendas como indicação. Que aí, automaticamente, a gente ia dobrar o seu faturamento. Seria isso mesmo? A abertura de um novo canal de vendas ou um novo canal de entrada de vendas? Ou eu estou enganado?"

---

## O — Revisão da dor

Aqui a gente vai bater em cima do problema dele.

> "Fulano, você já tentou outro canal de aquisição de leads? Por quanto tempo você tentou? Por que falhou? Por que nunca tentou? E nessa abertura de cada novo canal de leads de entrada de vendas, chegou a perder dinheiro com isso?"

---

## Fechamento da R1 (transição pra R2)

Aqui a gente fecha o ciclo da R1 falando:

> "Fulano, a gente entende que o seu problema hoje é trazer um novo canal de aquisição de leads de vendas pra tua empresa crescer e parar de depender da indicação e ter volatilidade.
>
> Eu vou montar um projeto específico pra você de como a gente pode resolver o seu problema. Deixar você sair do ponto A, que é o ponto em que você trabalha somente com indicação pra vender, e te levar pro ponto B, que tem um canal lado a lado com indicação, te ajudando nas vendas mês a mês.
>
> Fulano, eu gostaria de trazer esse projeto pra você na semana que vem ou nos próximos dias pra gente debater e te entregar o melhor escopo de projeto. Como que tá a tua agenda?"

Basicamente, linkar o problema dele pra fazer um projeto e linkar que eu vou apresentar esse projeto na próxima reunião. Essa é a finalização da reunião.

---

## Resumo numa tabela

| Etapa | O que fazer |
|---|---|
| **Abertura** | Rapport + apresentação breve da empresa |
| **C** | "Qual o motivo de tu estar aqui hoje? Qual problema busca resolver: vendas, time, leads, faturamento?" |
| **L** | Pega o que ele falou no C, transforma em problema, devolve. "É isso ou tô enganado?" |
| **O** | "Já tentou? Quanto tempo? Por que falhou? Por que nunca tentou? Perdeu dinheiro?" |
| **Fechamento** | Linka problema + promessa de projeto + marca R2 com data |

---

**Base teórica:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]
**Versão R2:** [[CLOSER R2 — Versão Matheus]]
**Hub:** [[Mentoria Nimoto — Índice]]

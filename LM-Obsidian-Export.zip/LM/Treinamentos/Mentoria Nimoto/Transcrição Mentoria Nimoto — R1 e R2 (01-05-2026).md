---
data: 2026-05-01
tipo: transcrição
mentor: Gustavo Nimoto (Ascend Sales)
participantes: Matheus Jardim, Valentino Pascual
duração: 106 min
tema: Reuniões de vendas R1 e R2
status: parcial (parte 1 de 2 — call anterior ainda será enviada)
---

# Transcrição Mentoria Nimoto — R1 e R2

> Tem uma call antes dessa, mas depois mando.

**Link:** Impromptu Google Meet Meeting - May 01

---

## 0:00 - Ascend Sales
Mano, tinha uma doida lá, Matheus. Tipo assim, a mulher tava full drogada, mano, numa call do Discord. Te mandei o vídeo depois que tu olha, mano.

## 0:08 - Valentino (leadmachineads@gmail.com)
Caralho, que doideira, mano.

## 0:09 - Ascend Sales
Que doideira. Mas bora lá. Pessoal, seguinte, tá? Hoje a gente vai bater... Vocês chegaram a assistir aquela imersão que a gente fez de 7 horas?

## 0:18 - Matheus Jardim
Não, não mandam pra gente.

## 0:20 - Ascend Sales
Boa, depois eu mando lá pra vocês. Me lembra lá que eu mando. Mas bora lá. Agora eu vou passar aqui pra vocês o nosso processo de vendas, que é o processo que funciona, tá? Hoje, como vocês já fazem R1 e R2, vai facilitar bastante pra gente colocar esse processo dentro do que vocês já fazem. Só uma dúvida que eu preciso tirar com vocês. Hoje, como que vocês separam na R1 e na R2? Hoje, o que vocês fazem, essencialmente, na R1 e o que vocês fazem na R2? Só pra eu entender.

## 0:51 - Matheus Jardim
Basicamente, a gente faz um diagnóstico, entende como que tá o cara. Só que agora a gente não teve um volume de reuniões... Então a gente colocou uma pré-call antes da reunião, pra entrar na R1, pra ter mais dores, mesmo um pouco antes da R1, pra ficar mais fácil pra gente. E aí na R1 basicamente é o que a gente entendeu na pré-call, é uma profunda nas dores, e aí, provavelmente, na maioria dos casos, a decisão não vai ser na primeira reunião, mesmo fazendo a pré-call, às vezes a decisão não leva a decisão, ou as duas decisões, que geralmente tem uma fonte, na primeira reunião, então, a gente parou de apresentar uma proposta sem a decisão, então a gente coloca na próxima call, pra ver a decisão, ver todo mundo, e aí a gente bate e traz a proposta pra ele. Basicamente é isso, Valentino.

## 1:51 - Ascend Sales
Boa.

## 1:53 - Valentino (leadmachineads@gmail.com)
Aí, Nimoto, acho que em questão de reunião, mano, tá bem fraco, mano.

## 1:58 - Matheus Jardim
É.

## 1:58 - Valentino (leadmachineads@gmail.com)
Bem fraco... Por exemplo, no mês de maio, né? Maio? Abril? Quando que é? Mês passado? Abril.

## 2:08 - Ascend Sales
Abril? O mês acabou ontem, pô.

## 2:12 - Valentino (leadmachineads@gmail.com)
No mês de abril, mano, a gente não vendeu, viado. Caraca.

## 2:16 - Matheus Jardim
Mas teve reunião? Teve, teve reunião.

## 2:19 - Valentino (leadmachineads@gmail.com)
Tá. No mês de março a gente não vendeu também, né, Matheus? Não.

## 2:23 - Matheus Jardim
Também tá parado. Se eu vou parar pra fazer essa análise, tá parado. Março e abril a gente não vendeu.

## 2:30 - Valentino (leadmachineads@gmail.com)
Tá.

## 2:32 - Ascend Sales
Ó, o que que eu tava falando até pro Matheus? Hoje a gente tá vendendo quase... É, você fica lá no Discord. Todo dia, mano. Todo dia a gente vende, todo dia, todo dia, todo dia. Mas qual que é o grande ponto, tá? E eu vou explicar pra vocês. Eu acho que tu chegou até eu assistir, eu falar um pouco sobre isso dentro do webinário, mas eu vou falar isso aqui voltado pra reunião de vendas mesmo, voltado pra reunião de vocês, no caso de vocês.

O que que eu uso hoje pra fazer, por exemplo, a minha R1? Vamos falar sobre R1 e R2. R2, fazer a primeira R1, que eu considero uma reunião de diagnóstico e apresentação. Ou, R1 é tipo a primeira reunião. Eu escuto eles, um pouco sobre eles, mas eu escuto eles e entendo eles. R2, eu crio uma oferta. Eu literalmente vejo essa fórmula aqui. Na minha R2, sempre que eu vou fazer uma proposta, eu vou fazer baseado nessa fórmula. Resultado versus percepção de probabilidade de sucesso, dividido por tempo de espera versus sacrifício e esforço.

Quando a gente coloca isso, até para vocês entenderem, a primeira R1 de vocês, ok, é a reunião de diagnóstico e tudo mais. O que eu preciso entender nesse primeiro momento é, após a R1, as pessoas tendem a aparecer na R2?

## 3:53 - Matheus Jardim
Na maioria das vezes? Na maioria das vezes, não?

## 3:57 - Valentino (leadmachineads@gmail.com)
Não, mano. Não aparece na R2. Boa, boa.

## 4:01 - Ascend Sales
E eu te faço essa pergunta justamente porque eu sei que talvez isso seja um problema de uma coisa que a gente chama de tríade de ofertas, tá? Eu vou explicar aqui. A gente tem esse processo, esse processo ele é como se fosse uma linha reta, é o closer ali, é uma linha reta para que você consiga realmente fazer uma venda para um cliente.

Então quando a gente começa nesse processo, a primeira parte que a gente precisa clarificar em qualquer reunião que a gente entra é qual que o motivo que o meu cliente está aqui comigo hoje. Então eu abri uma reunião, o que eu vou fazer? Basicamente eu vou me apresentar, e é importante que vocês se apresentem, falar, ó, minha metodologia é essa, é essa, essa, tipo, de forma bem resumida em menos de cinco minutos, tá?

O que vocês vão fazer? Vocês vão se apresentar, vão colocar, evidenciar a metodologia de vocês e vão falar, ó, para mim fazer um trabalho personalizado e entender como a minha metodologia se aprofunda no seu caso, eu preciso te fazer algumas perguntas para que eu possa fazer uma proposta personalizada. Para que eu possa fazer um projeto personalizado para você, e aí sim eu começo a parte do closer, porque se eu não começo ali a reunião abrindo falando o mínimo sobre mim, e aí nesse mínimo que eu falo sobre mim, eu não coloco ali que um dos meus objetivos é fazer ali essa pessoa entender que eu vou fazer um projeto separado, vou fazer um projeto personalizado para ela, ela não vai se abrir para conversar comigo.

A partir do momento que eu faço isso, qual que é a próxima coisa que eu preciso fazer? Aí eu entro nesse ciclo aqui. A primeira coisa, eu preciso entender qual que o motivo que ele está aqui com a gente, então, pô, deixa eu entender por que você aceitou essa reunião, qual que é o motivo que você está aqui com a gente, qual que é o problema que você busca resolver hoje, porque é muito importante para mim entender qual que o problema que o meu produto resolve, que ele também busca resolver hoje. Então, sem essa parte, sem entender o problema, eu não avanço para a próxima parte.

E aí, nisso que eu estou tentando entender o problema da pessoa, qual que o próximo passo que eu preciso fazer? Pô, eu faço algumas perguntas e entendo o problema. Seu problema, o meu problema é não conseguir leads qualificados. O meu problema é realmente não conseguir vender mais. Beleza. Você vai identificar um dos problemas dos seus clientes. A maioria vocês já identificaram. A maioria das reuniões que vocês fizeram, vocês identificaram o problema do seu cliente.

Só que pensa comigo aqui. Eu costumo falar que quando você inicia uma reunião, tem 225 caminhos que você pode seguir, ou seja, pensa que você está em uma trilha, e aí essa trilha abre para 225 caminhos diferentes, quando você descobre o problema do seu cliente, o que você faz é escolher um desses caminhos, e aí você vai seguir esse caminho até o final. Então um dos pontos que vocês precisam entender é, identifiquei o problema do meu cliente, que é a primeira parte da reunião, sem identificar o problema do seu cliente, não avança a reunião de jeito nenhum, porque se vocês avançarem, vocês vão estar chutando em qual desses 225 caminhos o seu cliente está, e muito provavelmente vocês vão errar.

Então você pode entender o primeiro ponto, às vezes vocês entram na própria reunião já sabendo o problema do cliente, só que existe um próximo passo, que é você **rotular** o problema do seu cliente. Quando o seu cliente ele te falou o problema, quando você acredita que você identificou o problema, não é somente você achar, você precisa ter 100% de certeza. E aí você precisa dar um nome ao problema do seu cliente.

Então aí você chega e você fala assim: "então hoje você está aqui porque você precisa de mais clientes, certo? Hoje você está aqui para resolver problema X, Y, Z, certo?" Quando eu falo isso e a pessoa confirma comigo, opa, agora eu tenho certeza do caminho, agora é só trilhar.

Isso na primeira reunião é muito forte porque eu entendi realmente o que esse cara, ele literalmente faz, eu entendi o que esse cara realmente precisa de mim, e se eu entendi o que ele precisa de mim, agora eu consigo realmente seguir a reunião de forma coesa com o que ele está falando.

E aí eu vou para a próxima parte. Nessa próxima parte, e é aqui que eu vou encerrar a R1, mas nessa próxima parte, o que eu vou fazer? Eu vou fazer a **revisão da dor**. Então a própria revisão da dor, que é enfatizar a dor que ele está sofrendo. Eu vou fazer uma coisa que eu chamo de **tríade de ofertas**. E é muito importante vocês prestem atenção nessa parte, porque essa é a parte que vai definir se o cara vai entrar numa segunda reunião ou não.

Quando eu dei, vamos lá, eu descobri qual é o problema do cara, eu descobri, eu fiz ele repetir comigo o que é que ele realmente é o problema dele, e nisso que eu fiz ele repetir, eu vou enfatizar a dor dele, só que fazendo uma coisa que eu chamo de tríade de ofertas para a gente realmente ter uma autoridade sobre o que a gente está falando.

Quando eu vou perguntar, eu vou fazer esse cara sofrer um pouco. "Dentro dessa situação que você passou, deixa eu entender, você já tentou alguma solução antes?" E isso eu estou fazendo o quê? Eu estou fazendo ele lembrar das dores, eu estou fazendo ele lembrar que ele não conseguiu resolver isso. "Por que você fracassou? Por quanto tempo você tentou? Por que você nunca tentou fazer isso? Qual foi a trava que impediu você de fazer isso?"

Por que eu preciso entender isso? Porque eu preciso que ele enfatize a dor dele para que aquilo se torne algo urgente.

**Primeira parte da tríade**: você vai bater na dor dele de novo.

**Segunda parte da tríade**: "Cara, vamos supor que, pô, qual foi sua trava para vender?"

## 10:30 - Matheus Jardim
Então, primeira parte da tríade.

## 10:32 - Ascend Sales
Tô enfatizando a dor, tô revisando a dor. Segunda parte da tríade. Ele vai falar, pô, minha trava para vender foi que eu não consigo me comunicar bem na reunião. E aí eu falo, pô, de zero a dez, quanto que você acha que isso atrapalha dentro da tua reunião de fato? Essa trava que você tem? Você acha que é o motivo que mais te atrapalha mesmo? Como que seria se você resolvesse esse problema?

Então eu pergunto. Então, nessa parte, eu faço uma construção simplesmente para perguntar. Cara, como tu acredita que seria se a gente resolvesse esse problema?

E a **terceira parte da tríade** é: como eu resolvo esse problema? Então, para ficar muito claro, o cara trouxe, ó, qual que a trava que você tem? Por que que você falhou? Ah, eu falhei por causa disso, disso, disso. Como você acredita que seria se você não tivesse isso que você acabou de falar, que foi o motivo pelo qual você falhou? Cara, seria incrível, a gente conseguiria fazer as coisas. Deixa eu te explicar como que a gente faz para a gente não falhar nessa mesma coisa que você falhou.

E aí sim, eu trago uma parte técnica rápida, sabe? Então, todas as perguntas que eu vou fazendo, eu vou fazer nessa tríade de ofertas. E aí eu passo muito tempo na minha R1 explicando para esse cara. Por que? Eu enfatizei a dor dele e eu mostrei. Por que que a dor dele, ela não acontece comigo e acontece com ele?

Então, dentro dessa primeira reunião, ele vai sair dali com o quê? Com uma percepção de, pô, o Gustavo realmente entendeu minha dor e ele realmente tem uma solução. Só que aí eu faço a transição: "agora eu vou fazer o projeto para você, eu vou te apresentar o projeto, a partir desse projeto você vai entender como que funciona". Só que é muito importante que vocês entendam o seguinte: dentro disso que eu falei, se você realmente pegar e fizer isso aqui à risca, não tem como você fazer uma R1 que o cliente não vai participar da próxima reunião, porque você identificou a dor, você deu o nome para a dor e o cliente confirmou com você, você revisou a dor fazendo uma tríade de ofertas, você demonstrou que você sabe realmente resolver aquele problema, e agora você falou para ele que você vai fazer um projeto para ele, independente dele fechar ou não com você, você tem certeza que vai ser muito proveitoso ele ver como que vai ser aquele projeto numa segunda reunião, cara, aqui acabou, fica muito difícil o cliente não fechar de você, porque, cara, 80%.

## 13:33 - Matheus Jardim
Acho que deu para entender a lógica e pelo que você foi explicando, tem algumas coisas ali, algumas perguntas-chave, igual que você falou ali, qual que foi a trava para resolver isso, qual que é o seu problema, fazer ele falar sobre o problema e em cima disso entender as soluções que ele já tentou para resolver o problema e depois mostrar para ele que a gente não tem esse problema no nosso dia a dia, porque mostrando para ele ele vai saber que a gente... A gente consegue resolver o problema dele, ele não vai pensar isso claramente, mas no intuitivo dele ele vai estar sacando isso daí, a cabeça dele já vai estar processando isso, e daí quando você fala que quando ele percebe, sem a gente falar que a gente consegue solucionar isso pra ele, fica muito mais atrativo, e aí ele ir pra outra reunião, e quando você fala, cara, a gente vai montar isso daqui, a gente vai te trazer isso daqui organizado, como que vai ser estruturado na tua empresa, mas pra isso, eu preciso marcar uma segunda reunião pra te apresentar isso de forma mais concreta, e sentar e analisar no seu caso aqui de maneira mais concreta, então, tem um gancho muito forte pra ir pra segunda reunião, porque tá 100% atrelado dentro do que ele disse, é mais ou menos isso ou eu viajei?

## 14:46 - Ascend Sales
Exatamente, exatamente, tá, e até um ponto, eu faço minhas reuniões com essa imagem aqui de canto, pra eu nunca esquecer em qual ponto da reunião eu tô, então tipo assim, eu sempre tô seguindo, cara, eu identifico o problema. Eu clarifiquei aqui qual que o problema e qual que o motivo dele estar comigo, eu já dei nome pra isso, eu tô na onde? Eu tô na revisão da dor? Opa, beleza. Então eu faço minhas reuniões com isso aberto, tá? Pra eu nunca me perder e nunca ir pra um lado totalmente aleatório.

## 15:13 - Matheus Jardim
E tuas reuniões eu acho que acaba sendo muito mais sucinta e mais rápida também, gerando mais valor com isso, né? Tu não fica dando volta, dando volta, dando volta. Quanto dura uma reunião tua, Nimoto?

## 15:23 - Valentino (leadmachineads@gmail.com)
Cara, é que vai depender muito do cliente, mano.

## 15:26 - Ascend Sales
Tem cliente que gosta de falar pra caramba e tem cliente que quase não fala. O cliente que quase não fala vai levar 25 minutos e eu não tenho problema nenhum com isso. O cliente que fala pra caramba vai levar no máximo uma hora porque provavelmente eu tenho outra logo em seguida, entendeu?

## 15:39 - Matheus Jardim
E, Tino, você ficou com alguma dúvida aí, mano? São perguntas que a gente faz, né, Matheus?

## 15:45 - Valentino (leadmachineads@gmail.com)
Mas parece que a gente tá perguntando sem... A gente pergunta sem o caminho pra seguir, mano. Basicamente, a gente faz um pouco dessas perguntas. Vocês estão prospectando qual nicho agora? Cara, energia solar, energia solar, basicamente. Boa, boa.

## 16:05 - Ascend Sales
Quando você chega numa reunião, qual que o primeiro ponto que eu vou recomendar vocês fazerem? Eu vou meio que simular como se eu estivesse fazendo uma reunião com uma energia solar.

Eu vou entrar, eu vou falar assim: "oi, tudo bem? Valentino, Matheus, muito prazer estar aqui com vocês, é um prazer enorme. Obrigado por participar desse bate-papo, obrigado por topar falar aqui comigo. Um dos meus objetivos aqui é agregar valor na operação de vocês, antes mesmo de vender alguma coisa, antes mesmo de te oferecer algum produto, o meu objetivo é fazer com que vocês enxerguem valor e que eu possa ajudar de alguma forma, antes de qualquer coisa. Matheus, Valentino, deixa até te explicar um pouco sobre mim, um pouco sobre o que eu faço."

Aí eu explico um pouco sobre mim, e aí eu venho com a minha metodologia. "A minha metodologia hoje é pegar uma empresa e trabalhar, sei lá, toda a jornada do consumidor, desde o ponto A ao ponto B. A gente faz isso, isso, isso e isso." E eu explico aqui o que a gente faz, tá? Não falo da jornada do consumidor.

E aí eu pego e falo para ele: "dentro disso, como vai funcionar nosso bate-papo hoje? Eu preciso te fazer algumas perguntas para que eu faça um projeto totalmente personalizado, que você vai, ou usando comigo ou não, você vai ter uma clareza muito grande do que você pode fazer, mas eu vou te fazer algumas perguntas, a gente vai entender um pouco sua situação, eu vou te demonstrar algumas possíveis soluções, e depois eu vou fazer esse projeto totalmente personalizado para vocês, ok?"

Ok. E aí a gente vai para o próximo passo. "Deixa eu entender, Matheus e Valentino, dentro da operação de vocês hoje, qual que está sendo a maior dificuldade quando a gente fala dessa própria jornada que eu mostrei, ou dessa própria metodologia que eu falei, está sendo na parte de captação, está sendo na parte de fechamento de vendas, está sendo na parte de encontrar bons leads qualificados ou trazer pessoas interessadas. Qual que é a tua maior dificuldade hoje? E fala assim, pô, se eu resolvesse essa dificuldade que eu tenho aqui, eu realmente transformaria minha empresa."

E aí eu trago.

## 18:09 - Matheus Jardim
E essa forma de tu perguntar deu uma clareza enorme, porque a gente chega e pergunta, ô Adriano, eu quero entender um pouquinho mais sobre as suas dificuldades hoje, me fala um pouquinho hoje, qual que são os seus maiores gargalos hoje na sua operação? Só que daí fica amplo e ele fala uns corpos que talvez a gente não entregue, e aí lá na frente a gente tem que estar quebrando a cabeça na própria reunião e pensando em soluções. Só que aí na tua pergunta, tu amarra em cima da explicação que você deu sobre o que você faz. Então vamos supor, então falando aqui a gente fala sobre comercial, ajuda o seu time comercial, treina os seus vendedores, ajuda você a vender mais, ajuda você a prospectar. Então fala ali, relacionado ao comercial e você vem então, Adriano, relacionado a isso que eu acabei de explicar sobre comercial, sobre vendedor, sobre tráfego, sobre... Qual que a sua dificuldade em cima disso, que você olhasse, você falasse assim, se eu resolvesse isso, isso daqui iria aumentar meu faturamento, isso daqui iria ajudar muito dentro da minha operação. Qual dentro disso seria a sua dificuldade? Porque daí, mas essa é lógica, né?

## 19:18 - Ascend Sales
Exatamente, exatamente. Porque se eu não isolo isso, eu estou vendendo qualquer coisa para esse cara. Vamos supor que, vamos para um lado totalmente aleatório, estou fazendo uma reunião de contabilidade para vender para esse cara. Se eu estou fazendo uma reunião de contabilidade para vender para esse cara, eu não vou falar quais são os seus problemas, ele vai falar, o comercial, pô, tá louco? Eu vou fazer o seguinte, ó, hoje eu trabalho fazendo essa parte de reforma tributária, trabalho fazendo essa parte de contabilidade, planejamento financeiro, só para eu entender, dentro dessas partes que eu falei agora, e dentro do que você conhece do financeiro da sua empresa, hoje, qual que é a parte que te traz mais dificuldade nisso que eu falei?

Então, pô, às vezes ele vai falar todas, às vezes ele vai falar tudo, aí ele vai falar, pô, todas. Então, hoje você não... Eu um financeiro bem definido, olha o que eu estou fazendo, estou dando o nome, financeiro não bem definido, financeiro não planejado, porque eu preciso resumir tudo o que ele está falando em um nome só, hoje o meu problema é a aquisição de leads, então hoje o seu problema está em fazer anúncios online que captem bons leads, que captem bons possíveis clientes, então eu preciso nomear, porque essa nomeação eu vou ter certeza do que ele está me falando, pode falar, Valentino.

## 20:29 - Valentino (leadmachineads@gmail.com)
Sabe que eu sinto, mano, que a gente identifica a dor fácil, a gente traz a solução certa, mas a gente não enfatiza a dor do cara, tipo assim, ele pensa, ele fala, pô, faz sentido sim fazer isso, a gente, por exemplo, assim, prospectar para empresas, mas aí, ah, não é necessário, tá ligado?

## 20:56 - Matheus Jardim
Não, mas eu acho que a gente perde ele, você sabe aonde, é porque, né, na... Transição, porque a gente não mostra que aqui, tipo assim, não mostra com clareza, a gente fala, não, aqui a gente faz isso, mas tipo assim, basicamente a gente fala, quando vamos com o problema de comercial, não, fulano, aqui a gente faz exatamente isso, a parte comercial, ligação B2B, prospecção, inclusive você veio para a gente através de prospecção, só que a gente não traz aprofundado isso, o cara entender talvez isso seja o nosso gap, mano, entre descobrir a dor e enfatizar ela, mostrando que a gente resolve o problema, gente, a gente não tem esse problema por conta disso, e aí ele não associa isso, por isso que ele não vai para a próxima reunião e vai avançando, talvez seja esse gap aí. Sim, sim. É, esse...

## 21:44 - Valentino (leadmachineads@gmail.com)
Junta, né, junta a gente com a solução, né? Exatamente, exatamente.

## 21:49 - Ascend Sales
Quando a gente vai, e eu acredito que o grande problema de vocês está também nessa parte de rotular o problema, porque vocês entendem várias coisas, só que vocês não resumem essas... Então, exemplo, eu tenho muito problema de, por exemplo, se a metodologia de vocês, vocês vão falar de prospecção para o cliente, se vocês vão falar de prospecção para o seu cliente, o que você precisa entender? O que eu faço é isso, hoje a gente está nessa parte de prospecção e tudo mais, eu quero entender para você, hoje qual é a tua dificuldade dentro dessa parte de prospecção, se você já tentou, se há um objetivo seu, deixa eu entender um pouco mais o que você tem, a sua visão sobre isso e qual é o teu problema nessa parte.

Porque eu preciso entender se o meu cliente, ele tem aquele problema que eu estou oferecendo. Se ele não tem, o meu próprio problema é ele não ter essa solução ainda e descobrir porque ele não tem aquilo. E aí ele vai falar, eu não faço prospecção por causa que eu não acredito nisso, naquilo, naquilo lá. Então, um grande problema é não acreditar. Então, um grande problema que eu posso seguir na minha reunião é ele não acreditar nisso, entendeu? Pode falar, Tino.

## 22:52 - Valentino (leadmachineads@gmail.com)
Daí, a gente teve uma reunião que foi semana passada, na terça, e aí... O cara falou assim, ele antes da reunião, já falou para mim, e na reunião ele repetiu, ele falou assim, eu tenho problema com os engenheiros, eu tenho poucos engenheiros.

## 23:11 - Ascend Sales
Mas isso daí é porque você não está pré-definindo o lado que você vai para a sua reunião, esse que é o grande ponto, tá? Esse que é o grande ponto.

## 23:19 - Valentino (leadmachineads@gmail.com)
Mas peraí, aí ele falou assim, eu tenho problema nos engenheiros, e a forma que eu pensei de resolver foi meio que fazer uma matemática, quanto tempo leva para atender uma casa, e quanto tempo leva para atender um comercial, entende? Ah, era um dia para atender o residencial e três dias para atender o comercial, só que o residencial era 15 mil e o comercial era 30, entende? Duas vezes a mais, isso iria dois dias a mais também, e daí eu mostrei para ele, falei, ou seja, tu vai fazer menos tempo, vai ganhar mais, a gente pode ocupar teus engenheiros em projetos maiores, entende? Mas aí eu sinto que eu não consegui... Deixar tão claro que isso era por meio de prospecção. Eu peguei esse lado. O Matheus falou que ele tinha volatilidade no faturamento. E o Matheus quis ir para um meio mais desse tipo, mais para os engenheiros. Acho que era a dor principal dele, os engenheiros. Ele falou na pré-call e na reunião também.

## 24:24 - Ascend Sales
Vamos lá. Olha, é isso que eu estou falando. Vocês estão com um problema em rotular o problema do cliente. Isso aqui parece que a parte mais fácil, mas não é. Vamos lá. Ele falou dos engenheiros. O Tino teve uma resposta boa. E o Matheus falou ali da própria volatilidade, que também foi um problema que ele trouxe. Tino, a tua linha de raciocínio foi certa. Só que olha a importância de eu saber dar um nome, de eu saber rotular o problema do meu cliente.

Vamos lá. "Hoje, então, hoje, Tino, Matheus, o que vocês estão falando para mim é que você... Você tem poucos engenheiros, porque não tem tantos profissionais assim disponíveis no mercado, e esses engenheiros estão fazendo muitos projetos, e talvez esses projetos ali você não consiga alavancar muito mais, isso faz com que você nunca consiga ter uma receita previsível, e isso faz com que você também não consiga ter um bom resultado. Então, hoje, o seu principal problema e a coisa que você gostaria de resolver é, ao invés de contratar mais engenheiros, trazer ali projetos maiores, que te pagam melhor, que tomem menos tempo, mas que te tragam mais previsibilidade, é isso?"

Acabou, eu não liei.

## 25:40 - Matheus Jardim
E aí ele fala, pô, é isso, agora a gente está indo para caminho. Entendeu? A maneira que o Tino falou, ele não trouxe clareza nas palavras para explicar para a pessoa, porque quando você não vem convicto na linha, aí não trouxe clareza. E tanto é, não falei essa linha porque eu não tinha entendido essa linha. No início, aí eu fiquei rodando, rodando, rodando para tentar achar alguma coisa e o que eu encontrei foi a volatilidade da indicação, um mês eu fechava 10 ou 15 e outro mês eu fechava 6, aí o que eu achei foi essa, só que aí eu não rotulei desse jeito.

## 26:15 - Valentino (leadmachineads@gmail.com)
Aí ele tinha falado quatro vezes dos engenheiros e acho que uma ou duas vezes da volatilidade das indicações.

## 26:21 - Matheus Jardim
Mas eu vou te explicar agora aonde que você encaixa a prospecção nisso, tá?

## 26:26 - Ascend Sales
Vamos lá, eu rotulei, então o teu problema é encontrar bons trabalhos que te paguem muito mais para que você não precise ficar o tempo todo recrutando novos engenheiros e nesses trabalhos que te paguem mais, isso te traz mais previsibilidade para a sua empresa, certo? Eu já já vou te mostrar como que você pode fazer isso, só que eu quero entender agora, Tino, você já tentou alguma solução para resolver isso?

Pronto, iniciei aqui a enfatização de dor. "Por que você nunca tentou? Você nunca teve clareza desse problema ou foi algo que você nunca pensou que... Teve uma resolução. Deixa eu entender porque nunca tentou essa parte de realmente encontrar esses clientes melhores."

## 27:06 - Valentino (leadmachineads@gmail.com)
Eu nunca pensei como encontrar. Não, eu tô exemplificando isso.

## 27:10 - Ascend Sales
Eu sei, mas eu tô te respondendo como é que seria, ligado? Como assim? Não entendi a tua pergunta agora.

## 27:16 - Valentino (leadmachineads@gmail.com)
Eu não soube como encontrar as soluções de resolver esse problema.

## 27:21 - Ascend Sales
Mas você vai linkar isso à prospecção, pô? Não, eu falo como se eu fosse cliente.

## 27:26 - Valentino (leadmachineads@gmail.com)
Ah, você não soube como encontrar essas soluções?

## 27:28 - Ascend Sales
É. Ah, beleza. Cara, é normal isso, tá? Você não conseguir encontrar essas soluções. E aí, dentro da enfatização da dor, você pode seguir vários caminhos, tá? O que você tem que colocar é literalmente aquela tríade que eu falo. "Tino, ô Tino, se realmente, se você resolvesse esse problema de encontrar essa solução, de encontrar esses clientes ali, você acredita que resolveria a tua empresa? Você acredita que mudaria alguma coisa?"

Uhum. "Beleza, posso te mostrar como a gente..." E aí eu inicio a parte da prospecção, entendeu? Por quê? Cara, eu pergunto pra ele, ó, se você resolvesse isso aqui, daria certo? Bum, acabou. E aí eu já puxo pra ele.

Então eu enfatizei a dor, eu perguntei, cara, por que você nunca tentou resolver isso? Depois que eu enfatizei a dor, eu pergunto pra ele, cara, você sente que se você resolvesse isso, melhora aí o teu faturamento, depois eu já vou lá pra minha solução. E aqui eu demonstro que eu tenho domínio. E aqui eu demonstro a minha autoridade, entendeu? E aí eu posso ficar a reunião inteira, às vezes, falando sobre isso, conversando com ele sobre isso, trocando ideias só sobre essa parte. Por quê? Você percebe que eu peguei tanto o problema que ele falou pro Matheus, quanto o problema que ele falou pro Tino e conectei as duas coisas como se fosse uma coisa só?

## 28:52 - Matheus Jardim
Pior que um resolveu o outro.

## 28:55 - Valentino (leadmachineads@gmail.com)
E ele falou que ele não queria contratar mais engenheiro. Exatamente, exatamente.

## 29:06 - Ascend Sales
E aí você só precisava ter nomeado, então eu acredito que um dos grandes problemas de vocês é rotular esse problema. Rotulando esse problema, você já vai fazer isso aqui, vocês viram como a transição foi suave? Tipo assim, "Tino, como que você faz pra resolver esse problema? Você já tentou resolver esse problema antes? Como que foi essa solução? Por que que ela falhou? Quanto tempo você tentou", sabe? Então isso aqui faz com que você tenha uma transição muito suave.

E aí vai vir a parte final, né, que você vai falar, pô, beleza, você entendeu, entendeu como a minha solução funciona. A partir desse momento que você entendeu como a solução funciona, eu preciso fazer um projeto, eu quero realmente te apresentar isso. E aí você já sai com uma próxima reunião marcada, entendeu? Sim. A R1 até agora ficou clara? Ficou bom.

## 29:54 - Valentino (leadmachineads@gmail.com)
Tá marcada a R2 pra semana que vem, Matheus, tá terça? Do Flávio, da Synergy. Qual que o Flávio? Não lembro, mano.

## 30:06 - Matheus Jardim
Acho que era a mesma dor dos dois.

## 30:10 - Valentino (leadmachineads@gmail.com)
Os dois são parecidos até fisicamente, mano.

## 30:14 - Ascend Sales
É, mas vai começar, vai começar, você vai ver que conforme cada nicho, você vai ver que é muito parecido as dores, tá ligado? É muito parecido, de verdade.

## 30:23 - Valentino (leadmachineads@gmail.com)
Pior que energia solar, mano, tipo assim, o cara fala um negócio e já me vem na mente a solução, mano. Sim, sim. De tanta call que a gente fez, sabe? Ó, bora lá.

## 30:37 - Ascend Sales
E agora, até pra terminar a venda, o que a gente faz? **A gente sempre vende o destino final e não realmente o voo. A gente não vende a passagem, a gente vende o destino final.** E eu preciso que vocês entendam isso pra vocês fazerem isso numa R2.

Deixa eu falar uma coisa pra vocês. Quando vocês vão no aeroporto, vocês não vão no aeroporto e... Você assim, eu quero comprar uma passagem, a moça pergunta para você, para onde? Você fala, eu não sei, não existe isso. Aí, na hora de vender uma reunião, as pessoas ficam falando muito mais sobre a passagem, que é as ferramentas, que é tudo mais ali o que elas fazem, e não falam sobre o destino. Ou seja, mais importante do que o voo é o destino. Então, se as pessoas não entenderem que sem o destino não existe o voo, e pararem de tentar vender um monte de coisa técnica, e começarem a vender o voo final, ou o destino final, elas não vão conseguir vender.

E aí, é o que eu coloco dentro da própria oferta, tá? Dentro da própria oferta, que aí é o que a gente entra numa segunda reunião.

Vamos lá, existe essa fórmula de ofertas, e é o que eu faço nas minhas segundas reuniões, eu sempre coloco na minha segunda reunião. Qual que é o resultado que eu preciso entregar para esse cliente? Vamos colocar o caso de vocês, para a gente montar uma oferta bacana?

Então, vamos lá. O caso, no caso de vocês, **resultado**, tá? Vender melhor para, ou vender mais caro para clientes menores, ou melhores, fazendo com que você tenha previsão de receita.

## 32:31 - Matheus Jardim
Pronto.

## 32:32 - Ascend Sales
Então, a primeira coisa que eu tenho dentro da minha fórmula é o resultado. E aí, qual que é o próximo ponto? É a **percepção de probabilidade de sucesso**, ou seja, o quanto o teu cliente acredita que você consegue entregar aquele resultado. O quanto o seu cliente acredita que você consegue entregar aquilo que você está prometendo para ele.

Então, essa percepção é muito importante. Quanto que ele vai acreditar que eu consigo entregar isso para ele? Então, vamos lá. Dentro da minha reunião, o que eu vou acrescentar para fazer ele acreditar que a gente consegue entregar isso para ele? Então, vamos lá. A prospecção deu uma forma onde ele tenha X, Y, Z. Não vou aprofundar muito aqui, mas qual que a probabilidade de sucesso disso acontecer? Por que isso vai acontecer? Aí vem os depoimentos, aí vem a autoridade, aí vem o ensinamento que vocês vão fazer para ele sobre isso.

Primeiro, vocês viram que eu comecei com o resultado, o destino final? Agora vem o **mecanismo** de como eu farei isso. E é muito importante que vocês entendam como que vocês vão fazer isso para o seu cliente que fique de forma clara e que ele entenda que essa solução é para ele. Beleza?

E aí vem a parte de baixo da fórmula: **tempo de espera**, quanto tempo ele precisa esperar pra esse primeiro resultado, ou quanto tempo ele precisa esperar pra esse primeiro resultado. Em 60 dias, vamos supor que sejam 60 dias. E aí a gente vai colocar **esforço versus sacrifício**, quanto de esforço meu cliente vai ter que colocar pra fazer isso. Se forem duas horas por dia, é uma call por semana com você, qual o esforço que esse cliente tem? Tem que colocar duas horas por dia.

Então, quando eu tenho isso, o que eu preciso entender nessa fórmula? **O resultado versus a percepção de probabilidade de sucesso...** Então, se eu tenho um resultado aonde eu quero chegar, quanto mais claro for esse resultado, por exemplo, vender mais e mais caro para clientes melhores, eu poderia melhorar isso, vender projetos acima de 200 mil reais para clientes melhores, eu posso ser mais específico ainda. Então quanto mais específico eu for, melhor a minha oferta fica.

Só que eu preciso depois multiplicar isso pela percepção, tá, de probabilidade de sucesso. A percepção de probabilidade de sucesso que vai vir é do próprio cliente, não de vocês. Então essa percepção de probabilidade de sucesso é o quão bem você vai fazer o seu cliente acreditar que aquilo lá vai funcionar, fechou? Então é você explicar realmente aquilo de uma forma onde ele entenda que aquilo vai funcionar, e aí você divide.

Ou seja, você tem o resultado vezes a percepção de probabilidade de sucesso, você chegou num valor ali, aí você divide pelo tempo de espera versus esforço e sacrifício. Ou seja, **quanto menor o tempo de espera, mais valor o teu projeto tem**, quanto maior o tempo de espera até ele chegar ao resultado, porque a gente vende o destino e não o voo, menor é o seu resultado, menor é a percepção de valor do seu projeto, tá?

E aí vem o esforço e sacrifício, ou seja, **quanto maior o sacrifício do seu cliente para executar o que vocês falam, menor é a percepção de valor**, quanto menor o sacrifício, maior é a percepção de valor, entendeu? Quanto menos ele tem que fazer, mais ele vai perceber valor no que vocês estão falando.

Então quando eu pego a minha R2, para montar a R2, eu sempre vou separar ela, tipo, nessas etapas, a minha oferta por si só, eu sempre vou separar elas assim, eu sempre vou olhar para elas e aí eu vou desenhar elas com base nisso. Fechou? Se eu desenho minhas ofertas nela, minhas ofertas com base nisso, o que eu tenho que fazer? Cara, o meu pitch por si só, tá? Ele não vai durar muito tempo.

## 37:14 - Matheus Jardim
Por quê?

## 37:15 - Ascend Sales
O meu pitch, ele é literalmente, ó, então eu vou te entregar isso, essa parte, essa parte e essa parte por X valor. Não é algo que eu vou construir muito, não é algo que eu vou demorar muito. Aonde que eu vou demorar? Aonde que eu vou passar a maior parte do meu tempo? É aqui, ó, nessa parte realmente de **percepção de probabilidade de sucesso**.

Então, a maior parte da sua R2 é você falando sobre a probabilidade realmente de percepção de sucesso. Então, você vai começar a segunda reunião falando o seguinte:

"Oi, Tino. Oi, Matheus. Tudo bem? Tino, Matheus, hoje meu objetivo é fazer com que vocês cheguem em X lugar." Aqui eu tô falando... resultado, literalmente, o resultado que eu quero que você chegue. "Mudou alguma coisa desde o nosso último bate-papo, ou esse continua sendo o destino que você quer chegar, ou esse continua sendo o resultado que você quer chegar? Continua sendo o resultado." Beleza?

Aí eu vou para o próximo passo. "Deixa eu te explicar como que a gente vai chegar nesse resultado." Aí eu vou para a percepção de probabilidade de sucesso. Aí você vai explicar por que funciona, como funciona. Vocês vão tirar dúvidas sobre como funciona, e aí vocês vão falar em quanto tempo isso vai funcionar, e vocês vão para o próximo passo.

E aí o pitch de vocês, no final das contas, vocês sempre vão dividir eles ali em três pilares, ou em uma oferta simples, não precisa ser necessariamente em três pilares, mas em uma oferta simples. Então, o que eu coloco é: "Matheus, Tino, então para eu fazer essa parte, aonde eu vou te entregar, esse processo de vendas, com esse processo... em até 60 dias, vai te custar X reais."

Tu fala, vai te custar?

## 39:09 - Matheus Jardim
Sim.

## 39:10 - Ascend Sales
Cara, eu não me apego muito não, às vezes eu falo umas palavras que não eram para falar, mas assim, às vezes eu falo, às vezes eu não falo. Então, quando você vai colocar isso, é muito importante vocês entenderem que **a oferta por si só, se ela for lógica, ela não vai fazer com que o cliente saia por causa de micro detalhe**.

Só que o micro detalhe é importante na onde? Na hora de formar essa oferta, tá? Na hora de formar essa oferta. Então, quando eu vou vender o destino, quando eu falo o destino final onde o meu cliente vai chegar, então: "ó, Valentino, Matheus, hoje o meu objetivo é que você chegue em tal lugar fazendo isso, isso e isso. E para a gente fazer isso e realizar isso com você, custa tanto." Acabou.

## 39:58 - Matheus Jardim
Entendeu? Então...

## 40:00 - Ascend Sales
Então, quando eu faço isso, é muito importante que o meu cliente já tenha quebrado três grandes portas ali que a gente tem, tá? Então, durante a própria R2, existem **três perguntas** que vocês precisam fazer durante a R2, tá? Para que vocês concluam isso e vocês consigam fazer com que a sua R2, a única objeção que você tenha, sejam os valores.

As três perguntas que o seu cliente sempre deve responder são essas aqui, ó.

## 40:31 - Matheus Jardim
Vamos lá.

## 40:32 - Ascend Sales
Quando eu tô com o meu cliente, eu pergunto diretamente pra ele o quê?

## 40:36 - Matheus Jardim
**Primeiro ponto**, você acredita que essa solução aqui, ela funciona?

## 40:42 - Ascend Sales
Porque eu apresentei, sabe, na percepção de probabilidade de sucesso? Eu pergunto pra ele, "você acredita que isso aqui que eu falei pra você funciona?" E eu vou perguntar diretamente, "ah, acredito". E aí eu venho com a próxima pergunta.

**Segunda pergunta**: "Você acredita que isso funciona para você?" Aqui ele vai trazer objeções antes mesmo de eu falar o valor, porque ou ele vai falar assim, "acredito que isso não funciona para mim", ou ele vai falar, "pô, não sei, porque eu não tenho tanto tempo, blá, blá, blá", aí você entra num processo de quebra de objeções, que já já eu vou mostrar como que você quebra a objeção.

Isso antes do preço, né? Antes do preço, enquanto você está apresentando ainda, quando você terminou de apresentar a parte de percepção de probabilidade de sucesso, que é onde você apresenta como que vai funcionar, você vai perguntar, "você acredita que isso aqui funciona para você? Você acredita que isso funciona? Você acredita que isso funciona para você?"

E aí a última pergunta que eu faço, depois que eu apresento tudo é: **"você acredita que nós somos as pessoas ideais para fazer isso para você? Você acredita na gente para realizar isso aqui junto com você?"**

Por quê? Se ele fechou essas três portas, ele acredita que funciona, ele acredita que funciona para ele, ele acredita que nós somos as pessoas ideais para ele, a percepção de probabilidade de sucesso dele está a 100%, entendeu? Não tem o que eu quebrar nisso.

Agora, dentro disso é onde que quebro as objeções. Por que que eu consigo vender muito? Porque eu consigo fechar essas três portas. O cliente acredita em mim, ele acredita que aquilo funciona e ele acredita que aquilo funciona para ele. E aí, se ele não acredita em algum desses três pilares, enquanto eu estou apresentando a solução, o que que eu vou fazer? Eu vou quebrar a objeção dele antes de chegar no valor.

Então, como que eu quebro a objeção? Isso aqui é importante. Como que vocês vão quebrar essas objeções? Como que vocês vão literalmente fazer com que essas objeções não existam? Tá?

Vamos supor que ele fala assim, pô, eu acredito que isso não funciona. E aí você pergunta, e você acredita que isso funciona para você? Ele fala, pô, não acredito.

Quando a gente vai falar sobre isso, vamos supor que ele fala, pô, acredito que isso funciona, não acredito que isso não funciona para mim, e aí você vai perguntar, pô, por que que isso não funciona para você. Muitas das vezes ele já vai falar o motivo, mas você precisa entender o motivo por qual ele acredita que isso não funciona para ele.

Primeira coisa que ele vai falar, ah, vai ser por questão de tempo, ah, porque o meu time não está motivado, ah, por causa disso, X, Y, Z. Primeira coisa que eu faço dentro de uma quebra de objeções **não é bater de frente**, porque quando eu bato de frente numa quebra de objeções, o que que eu faço? Eu crio um conflito com o meu cliente.

O que que eu vou fazer? Eu vou **reconhecer**: "cara, eu entendo, hoje o seu dia é corrido, né, hoje o seu dia realmente é um tempo, você tem um tempo corrido que não permitiria que você fizesse duas horas de prospecção por dia, certo? Certo."

E aí, eu vou **associar** ele com uma coisa positiva ou associar ele com uma história de um cliente, dar um exemplo. "Tino, você falou que não tem tempo. Cara, eu entendo. Hoje o seu dia é corrido e realmente para você é difícil de dedicar essas duas horas, correto? Correto. Tino, é exatamente essa mesma pergunta que os nossos melhores clientes fazem para a gente. Exatamente esse mesmo questionamento, esse mesmo problema que os nossos melhores clientes trazem para a gente. Olha como que eu contorno isso."

Eu estou elogiando ele e estou falando que existe uma solução. Ou eu pego e falo assim, "Tino, o seu caso é muito parecido com o do Matheus que a gente conversou ontem e posso te falar exatamente o que eu falei para ele?" E aí eu falo exatamente o que eu falei para o Matheus. Só que eu uso o Matheus como **espantalho** para eu falar o que eu quero falar realmente para esse cliente.

Aqui eu vou criar a sensação de, pô, deixa eu, primeiro eu fiz, eu reconheci o problema dele, o problema dele é um problema real, então eu reconhecendo o problema dele, ele entende que eu estou do lado dele. Eu trazendo esse outro ponto, ele vai entender o que? Que, pô, eu não estou ofendendo ele na hora de responder ele sobre esse problema, que é um problema válido. Então, essa associação, eu faço com que isso seja um problema válido. Então, só que realmente fácil de quebrar.

"Então, esse é o maior questionamento que os nossos melhores clientes têm, Tino. Só que olha esse ponto aqui que a gente vai trazer para ti. Se a gente fizer isso, isso, isso, isso, a gente consegue resolver um problema de tempo que muitas das vezes o empresário tem."

Enfim, isso aqui tem que ser pensado. Mas, "ou, Matheus, ele tinha esse mesmo problema que você. Ele não tinha tempo para cuidar do comercial. O que a gente fez? A gente foi iniciando aos poucos. Nisso que a gente iniciou aos poucos, ele foi vendendo projetos maiores... Ascendendo projetos maiores, ele tinha menos coisas para prestar atenção, cada vez ele tinha mais tempo para o comercial e cada vez mais tempo ali para fazer as outras coisas."

E aí eu vou para a última etapa, que é o quê? **A pergunta**. Então, a parte da pergunta, o que eu vou fazer? Nessa própria parte da pergunta, vou falar assim, "Tino, você reconhece que hoje você está na mesma situação que o Matheus estava lá atrás?" Porque se ele falar que sim, ele vai confirmar que a solução do Matheus funciona para ele.

Então, eu associei as coisas e eu quebrei essa objeção sem necessariamente eu precisar falar para ela. Então, a última pergunta que eu faço para ele é, "Tino, vamos resolver isso assim como a gente resolveu a do Matheus, então?"

Olha que bacana. Então, eu fiz uma quebra de objeções que eu não vou fazer um script gigantesco junto com o cliente, tentando enrolar ele ou sendo agressivo com ele. Não, eu não criei um conflito. A gente chegou a uma conclusão lógica juntos.

Então, quando eu pego essa percepção dentro da probabilidade de sucesso ali, onde eu estou apresentando como funciona, nessa segunda reunião vai ficar muito fácil para vocês venderem, beleza? Vai ficar muito fácil para vocês venderem.

Então, dentro desses pontos aqui, é quase que inegável que vocês vão conseguir fazer com que isso aconteça, fechou? Pessoal, até aqui. Ok? Alguma dúvida?

## 47:27 - Matheus Jardim
Beleza.

## 47:28 - Ascend Sales
E aí, sobra ali a última etapa, que é realmente você fazer o teu pitch ali, falar o valor, e aí a única objeção que vai sobrar é a questão dos valores. E aí, eu sempre falo assim, **cara, quem tem que resolver o problema financeiro do meu cliente não sou eu, é ele mesmo**. E aí, a única pergunta que eu faço dentro de uma negociação é "como que eu posso facilitar para que isso aconteça e a gente saia com isso aqui agora, porque eu quero muito ter você como cliente".

"Ah, Gustavo, não dá, eu recebo... Eu recebo só dia 10, então hoje o seu único motivo para não fechar comigo é que você recebe dia 10 e você gostaria de começar dia 10 porque você vai ter dinheiro só nesse momento, certo? Certo. Então vamos fazer o seguinte, se eu fechar agora com você e você me pagar dia 10, a gente está fechado." Acabou.

Então, dentro disso daqui que eu vou fazendo, eu vou isolando objeções. No final, no quesito financeiro, eu deixo o meu cliente solucionar o problema dele. Só que nessa de solucionar o problema dele, eu vou literalmente isolar esse quesito.

Então eu pergunto para ele, "pô, então hoje o seu único quesito, então hoje o seu único questionamento para fechar com a gente, seu único impeditivo é realmente essa questão financeira? É realmente essa questão financeira? Então responde para mim, como que eu posso facilitar para você de forma com que a gente consiga fazer esse projeto e fazer com que esse projeto se inicie?"

Pode falar, Tino. Tu manda contrato daí?

## 48:59 - Valentino (leadmachineads@gmail.com)
Manda. Tu não faz contrato?

## 49:00 - Ascend Sales
Manda o contrato. Então, quando a gente vai fazer essas vendas, e é importante que você entenda isso, Tino, quando a gente faz essas vendas e a gente faz isso dessa forma e você seguiu todo esse processo que eu te mostrei, **o cliente não vai desistir**.

E ele não vai desistir por conta desse motivo aqui, **as primeiras 48 horas são decisivas** para o cliente colocar se ele gostou ou não de um produto. Faça uma recepção calorosa. Ou seja, receba o seu cliente de forma onde ele se sinta valorizado já nas primeiras 48 horas. Tenta marcar um onboarding para as primeiras 48 horas. Tenta mandar mais materiais nas primeiras 48 horas. Reforça o quão feliz vocês estão ali por fazer esse projeto nas primeiras 48 horas. Ou seja, vocês estão reforçando a decisão deles. Demonstra algum trabalho que vocês estão fazendo internamente para ele nessas primeiras 48 horas.

Então, tudo isso vocês fizerem vai fazer com que esse cliente ele traga para vocês essa percepção, beleza?

## 50:08 - Matheus Jardim
Basicamente é isso.

## 50:09 - Ascend Sales
Então, dentro da R1 e R2, vou usar essa metodologia de closer mais a metodologia de ofertas. Vocês trazendo isso, vocês se preparando para realmente fazer essas reuniões, muito difícil com que vocês não façam venda. E aí, para vocês praticarem até você ter uma segunda reunião. Cara, nessa segunda reunião, já implementa isso.

## 50:29 - Matheus Jardim
Cara, eu só não entendi como construir a oferta segundo aquela fórmula sua. Bora lá. Assim...

## 50:36 - Ascend Sales
É que, na real, não é a construção da oferta. Isso aqui é o que as pessoas... É como as pessoas enxergam a oferta e como fazer com que uma oferta esteja boa ou ruim. Então, a própria construção da oferta, vocês já vão fazer o projeto do cliente, certo? Vocês já vão fazer o projeto para R2.

Então, quando eu preciso que vocês entendam que... Dentro desse projeto, quando vocês forem apresentar esse projeto, a primeira coisa que vocês fazem é colocar o resultado, ou seja, o destino final que ele va

---

> ⚠️ **Transcrição truncada** — atingiu o limite de caracteres por volta dos 50:36. Falta a parte final da call (cerca de 56 minutos restantes).

---

**Conteúdo destrinchado em:** [[Mentoria Nimoto — Fundamentos Comercial]] | [[Mentoria Nimoto — Execução e Webinar]]
**Hub:** [[Mentoria Nimoto — Índice]]

---
data: 2026-05-05
tipo: roleplay / coaching ao vivo
mentor: Gustavo Nimoto
participantes: Matheus Jardim, Valentino Pascual
contexto: preparação da R2 com Flávio (Synergy) marcada pra terça
duração: 35 min
tags: [mentoria, nimoto, roleplay, r2, closer, oferta]
---

# Call Roleplay R2 Synergy — Coaching Nimoto

Sessão de coaching ao vivo do Nimoto pra calibrar a R2 com o Flávio. Pegamos a oferta, ajustamos a estrutura e o Nimoto rodou um roleplay simulando o início da R2 pra deixar a sequência clara.

> [!info] Diagnóstico do Nimoto
> A oferta tava confusa. A apresentação tava embolada. Tem que **simplificar a abertura** com um destino tangível em 1 frase, e a apresentação do produto vem **depois** que o destino é confirmado, não antes.

---

## 1. A oferta final (versão validada pelo Nimoto)

> "Em 45 dias a gente vai te tirar da **autofagia de mercado** através da **prospecção ativa estruturada**, fazendo você vender pra **clientes que nem sabem que existe pica-fio** e que valorizam **qualidade**, que é uma coisa que você tem."

**4 ingredientes da fórmula:**
1. **Tempo:** 45 dias
2. **Saída de:** autofagia de mercado (palavra do Flávio, dor rotulada por ele)
3. **Mecanismo:** prospecção ativa estruturada
4. **Destino:** clientes que nem sabem que existe pica-fio e valorizam qualidade

---

## 2. A estrutura nova da R2 (segundo o Nimoto)

A inversão crítica que o Nimoto fez:
**Não apresenta o produto pra depois apresentar a oferta. Apresenta a OFERTA primeiro pra atrair interesse no produto.**

### Sequência:

**1. Recap rápido + confirmação do problema** (1 min)
> "Flávio, semana passada tu falou de autofagia de mercado, comparação de preço no setor solar, teus vendedores não preenchem CRM, não seguem processo. É isso?"

**2. Apresentação do destino (a oferta-frase)** (1 min)
> "Em 45 dias a gente vai te tirar da autofagia através da prospecção ativa estruturada, fazendo você vender pra clientes que nem sabem que existe pica-fio."

**3. Pergunta-âncora** (30s)
> "Esse é o destino que tu quer? A gente entendeu bem o que tu quer?"

Se sim → continua. Se não → cria narrativa, ajusta antes de apresentar produto.

**4. Pergunta de conexão antes da apresentação**
> "Antes de eu iniciar a apresentação do trabalho, da nossa última conversa pra cá, mudou alguma coisa? Algo que tu queira acrescentar?"

**5. Pergunta da urgência** (antes de apresentar o produto, antes de falar valor)
> "Flávio, antes de eu iniciar minha apresentação, eu preciso entender uma única coisa: qual é o teu nível de urgência pra resolver esse problema hoje?"

**6. Apresentação do produto (Ignição Comercial)**
Aqui pode ser técnico. Apresenta entregas, processo, semana a semana. **Durante a apresentação**, vai fechando as 3 portas (não no fim).

**7. As 3 portas (intercaladas durante a apresentação, não em bloco)**
- "Você acredita que isso faz sentido?"
- "Você acredita que isso é pra você?"
- "Você acredita que eu sou a pessoa que pode resolver isso?"

**8. Fechamento direto**
> "Você falou que é urgente, falou que confia na gente, falou que isso é pra você. Eu vou te passar o valor. Eu só quero uma resposta de sim ou não. Pode ser?"

---

## 3. Insights novos do Nimoto nessa call

### "Apresentação de produto é o de menos."
A apresentação técnica não vende. O que vende é o destino + as 3 portas. Cliente não compra processo, compra resultado tangível.

### A oferta vem ANTES do produto
> "O teu produto não tem nada a ver com a tua oferta no primeiro momento. A oferta é pra atrair a pessoa, pra ela ter interesse no teu produto."

Inversão importante: oferta-frase abre a R2. Produto detalhado vem depois que o destino é confirmado.

### Usar autoridade dos sócios ausentes
Quando tem 3 sócios e só 1 falou contigo, na R2 com os outros tu usa a autoridade do que conversou:
> "O Valentino falou comigo, ele curtiu o processo, e como ele é responsável pelo comercial, ele me trouxe informações importantes. Baseado nisso, montei o projeto."

Isso desativa a postura crítica dos outros sócios — eles não vão questionar a autoridade do parceiro deles.

### Adaptar linguagem pra idade do cliente
Flávio tem 40 anos. Sem boné, postura, sem gírias. **"Tu tem que puxar a régua pro cliente."** Sem deixar de ser tu, mas adaptando.

### "Quanto mais informação você tem, mais você descobre que precisa de mais informação."
Resposta do Nimoto pro Tino que disse "não me sinto preparado". É exatamente o sinal de que está aprendendo de verdade.

### Crítica forte sobre uso de IA
> "Você está transcrevendo muita coisa em IA, mas você não está aprendendo, você precisa absorver."
>
> "A IA não pode ser muleta, tem que ser ferramenta de expansão. Igual ver vídeo no Instagram — você tem sensação de aprendizado, mas me fala um vídeo de aprendizado que você viu semana passada."
>
> "Você ia estudar 5 horas, agora você vai estudar 5 horas de maneira mais eficiente. Não 2 horas porque a IA tá te ajudando."

**Aplicação prática:** parar de pedir resumo. Ler o documento bruto. Só depois usar IA pra reforçar.

### Método David Goggins de leitura (pra decorar o CLOSER)
- Lê linha 1
- Lê linha 1 e 2
- Lê linha 1, 2 e 3
- Lê linha 1, 2, 3 e 4
- Continua até o fim, sempre relendo do começo

> "Vou ler isso 58 vezes até ficar na minha cabeça. Aí eu fecho o livro e se alguém me perguntar pelo resto da vida, eu vou saber."

---

## 4. Pontos práticos pra próxima R2

- [ ] **Sem boné** os dois (cliente tem 40 anos, valoriza postura)
- [ ] **Tirar gírias** — "viado", "porra", "mano" cortados
- [ ] **Tino conduz** se o Matheus não tiver memorizado a sequência ainda. **Mas pode dividir:** quem tem mais rapport abre, o outro fecha.
- [ ] **Não ler de papel ao vivo.** O mapa mental só pra preparação.
- [ ] **Decorar a oferta-frase** (Goggins).
- [ ] **Decorar a sequência das 8 etapas** acima.
- [ ] Assistir a R2 do Nimoto que ele vai mandar hoje (~14h30) antes da nossa terça.

---

## 5. O que vem DEPOIS do caminho (instrução central da call)

Essa foi a peça-chave que o Nimoto trouxe. Depois de apresentar o destino e ele confirmar, **a apresentação do produto não vai direto na entrega técnica.** Vem essa sequência:

### Passo A — Confirmação do destino
> "Esse é o destino que tu quer chegar? A gente entendeu bem o que tu quer?"

Se sim → avança. Se não → cria narrativa pra alinhar antes de apresentar produto.

### Passo B — Pergunta de atualização
> "Da nossa última conversa pra cá, mudou alguma coisa? Alguma informação que tu queira acrescentar?"

### Passo C — Isolar a urgência ANTES da apresentação técnica
> "Antes de eu iniciar minha apresentação, eu preciso entender uma única coisa, qual é o teu nível de urgência pra resolver esse problema hoje?"

Se ele falar "alta" → tu já tem o gancho pro fechamento depois.

### Passo D — Apresentação do produto (Ignição Comercial)
Agora sim, técnica. Pode mostrar mapa mental. **Durante a apresentação**, vai intercalando as 3 portas:
- "Você acredita que isso faz sentido?"
- "Você acredita que isso é pra você?"
- "Você acredita que eu sou a pessoa?"

### Passo E — Resgatar urgência + fechar
> "Você falou que é urgente. Você falou que confia na gente. Você falou que confia no processo, que isso é pra você. Vou te passar o valor. Eu só quero uma resposta de sim ou não. Pode ser?"

### Passo F — Quebra de objeção (se vier)
3As. Não capitula.

### Passo G — Reforço (R do CLOSER)
Recepção calorosa nas primeiras 48h. Próxima sessão dentro de 48h.

---

## 6. Trabalho até terça

- [ ] Ler 30x o doc do CLOSER (método Goggins)
- [ ] Decorar a oferta-frase
- [ ] Decorar a sequência A→G acima
- [ ] Assistir R2 do Nimoto (chega à tarde)
- [ ] Roleplay entre Matheus e Tino (1h)
- [ ] Definir quem conduz qual parte na R2 (não pode ser sobreposição igual a R1)

---

**Framework aplicado:** [[CLOSER R2 — Versão Matheus]] | [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]
**Hub:** [[Mentoria Nimoto — Índice]]

---
tipo: método
data: 2026-05-05
autor: Matheus Jardim
fonte: roleplay com Gustavo Nimoto (05-05-2026)
tags: [closer, r2, método, nimoto]
---

# CLOSER NA R2 — Versão Matheus

Resumo do método CLOSER aplicado em R2, do jeito que entendi depois do roleplay com o Nimoto.

---

## C — Clareza
Perguntar se da última conversa pra essa mudou alguma coisa e se ele tem alguma coisa a acrescentar.

> "Da nossa última conversa pra cá, mudou alguma coisa? Alguma informação que tu queira acrescentar?"

---

## L — Rotular o problema
Falar novamente do problema que ele trouxe na R1 e perguntar se é isso mesmo, só pra gente entender bem.

> "Flávio, semana passada tu falou de autofagia de mercado, comparação de preço, vendedores que não preenchem CRM. É isso mesmo?"

**Espera ele responder em voz alta.** Quando ele fala "é isso", ele se compromete publicamente com o problema.

---

## O — Revisão da dor
Perguntar pra pessoa o nível de urgência que ela tem pra resolver esse problema.

> "Eu preciso entender uma única coisa, uma única coisa: qual é o teu nível de urgência pra resolver esse problema hoje?"

Na R2 não precisa fazer tríade de dor passada (já fez na R1). Comprime em urgência presente.

---

## S — Vender destino
Tem que trazer o destino concreto pra ele, depois perguntar se é esse destino que ele quer chegar e se a gente entendeu bem o que ele quer. Depois apresentar o produto, pode ser mais técnico. E durante a apresentação do produto, fechar as portas.

**Sub-passos:**

1. Destino concreto (oferta-frase):
> "Em 45 dias a gente vai te tirar da autofagia de mercado através da prospecção ativa estruturada, fazendo você vender pra clientes que nem sabem que existe pica-fio e que valorizam qualidade, que é uma coisa que tu tem."

2. Pergunta-âncora:
> "Esse é o destino que tu quer chegar? A gente entendeu bem o que tu quer?"

3. Apresentação do produto (Ignição Comercial). Pode ser técnico, pode mostrar mapa mental.

4. As 3 portas intercaladas DURANTE a apresentação (não em bloco no fim):
- "Você acredita que isso faz sentido?"
- "Você acredita que isso é pra você?"
- "Você acredita que eu sou a pessoa que pode resolver isso pra você?"

---

## E — Quebrar objeções
Quebrar as objeções que ele trouxer.

**Fórmula 3As:**
- **Concordo:** "Faz total sentido o que tu tá dizendo." (não bate de frente)
- **Contorno:** "E é exatamente por isso que [reframe a favor]"
- **Sugiro:** [pergunta que devolve a bola pra ele]

**Movimento ouro:** resgatar afirmações que ele mesmo deu nas etapas anteriores. "Tu mesmo me disse há 10 minutos que é alta urgência."

---

## R — Fechamento
Ancorar em cima das três perguntas. Por quê? Ele falou que é urgente, ele falou que confia na gente, ele falou que confia no processo e que isso é pra ele. Daí, falar:

> "Eu vou te passar o valor, Flávio. Eu só quero uma resposta de sim ou não. Pode ser?"

A pergunta "pode ser?" no fim é o que arma o compromisso. Se ele responder "pode", já tá fechado mentalmente antes do número.

---

## Resumo numa tabela

| Letra | O que fazer | Frase-chave |
|---|---|---|
| **C** | Reconfirmar | "Mudou alguma coisa desde a última conversa?" |
| **L** | Recap do problema | "Tu falou de autofagia, é isso?" |
| **O** | Urgência presente | "Qual tua urgência pra resolver isso hoje?" |
| **S** | Destino + produto | Oferta-frase → "esse é o destino?" → produto + 3 portas intercaladas |
| **E** | 3As | Concordo / contorno / sugiro |
| **R** | Fechar | "Você falou que é urgente, vou passar o valor, sim ou não?" |

---

## O que falta antes da R2 de terça

- [ ] Ler esse doc 30 vezes em voz alta (Goggins)
- [ ] Decorar a oferta-frase de cor
- [ ] Decorar as 3 portas
- [ ] Decorar a frase de fechamento do R
- [ ] Roleplay com Tino (1h)
- [ ] Definir quem abre, quem fecha

---

**Base teórica:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]
**Versão R1:** [[CLOSER R1 — Versão Matheus]]
**Hub:** [[Mentoria Nimoto — Índice]]

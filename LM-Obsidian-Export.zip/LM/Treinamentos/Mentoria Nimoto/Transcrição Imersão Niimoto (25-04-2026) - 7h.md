---
tipo: transcrição
agência: LM
evento: Imersão Gustavo Niimoto
data: 2026-04-25
duração: 7h05min
tags: [mentoria, nimoto, comercial, imersão, transcrição]
fonte: Google Drive (Recording 2)
modelo: faster-whisper small (pt)
---

# Transcrição — Imersão Gustavo Niimoto (25-04-2026)

Gravação completa da imersão presencial. 10.520 segments, ~7h de conteúdo dividido em 5 módulos (Mentalidade, Módulos 2-4, "Tornando-se Imparável").

> [!info] Estrutura aparente
> - **Módulo 1:** Mentalidade para trabalhar, estudar e vender por horas seguidas
> - **Módulo 2-4:** [a definir após leitura]
> - **Final:** Tornando-se Imparável

---

[00:00] É importante a gente iniciar naquele módulo que a maioria das pessoas iniciam
[00:04] e sempre é bom a gente passar por mentalidade, por quê?
[00:08] Porque a maioria das pessoas, elas falam disso, eu acho que de uma maneira muito genérica.
[00:11] Hoje eu quero aprofundar um pouquinho mais isso,
[00:14] especificamente para a prospecção e vendas.
[00:16] Eu quero colocar para vocês como que eu faço isso,
[00:19] como que eu faço para me manter engajado,
[00:21] como que eu faço para me manter sobre uma certa, sei lá,
[00:27] a constância durante horas e horas e horas seguidas,
[00:30] fazer, sei lá, 12 reuniões, às vezes num dia, acordar cedo, dormir tarde
[00:35] e fazer várias outras coisas ali que exigem uma dedicação enorme do nosso tempo
[00:40] para que a gente consiga trabalhar, para que a gente consiga ter um resultado.
[00:43] Sei que muitos de vocês passam por coisas que é, por exemplo,
[00:47] eu acordei hoje de manhã, não quero prospectar,
[00:49] ou você tem algum bloqueio mental para prospectar,
[00:52] ou você tem algum bloqueio mental, caraca,
[00:54] eu vou ter que trabalhar aqui 8, 10, 12 horas seguidas,
[00:57] não quero fazer isso, e aí é melhor você ficar deitado na cama,
[01:01] é melhor você procurar uma estratégia nova,
[01:03] é melhor você ficar fazendo várias outras coisas
[01:05] que você faz no seu dia a dia que te impedem de ter sucesso hoje.
[01:09] Então, vocês sempre estão buscando algo novo para fazer,
[01:12] ou para evitar fazer o que vocês precisam fazer.
[01:15] E isso que eu quero passar aqui para vocês.
[01:17] Então, essa primeira parte da aula, essa primeira parte da imersão,
[01:21] ela não é somente uma parte de mentalidade, é uma parte de comportamento.
[01:25] Porque o que a gente faz é muito mais sobre o nosso comportamento do dia a dia,
[01:30] é muito mais sobre como a gente interage com nós mesmos ali
[01:34] para ter um sucesso dentro de uma empresa, ou dentro de um negócio,
[01:38] ou dentro do que for, que você for executar dentro de qualquer projeto,
[01:42] do que realmente é motivações externas, ou coisas bonitas, ou enfim.
[01:47] Por aí vai.
[01:48] Então, a primeira coisa que eu começo é o mito da paixão
[01:52] e a realidade do dever.
[01:54] Sabe qual que é a coisa que mais me incomoda
[01:56] e que é mais dita ali, tipo, por todo mundo?
[02:00] Nossa, ama o que você faz, aproveita o que você faz,
[02:03] goste muito do seu trabalho.
[02:05] Alguém aqui já ouviu isso?
[02:07] Você não precisa amar o teu trabalho,
[02:09] você não vai amar cada minuto do teu trabalho.
[02:11] Você não vai amar acordar de manhã e dormir tarde,
[02:14] trabalhar 12, 10 horas seguidas,
[02:15] às vezes por 5, 6 anos para você ficar milionário,
[02:19] para você construir uma empresa,
[02:20] para você realmente construir um patrimônio gigantesco.
[02:23] Você não vai amar cada parte disso.
[02:25] Isso é uma ilusão.
[02:26] Você não vai se divertir o tempo todo.
[02:28] Isso é uma ilusão.
[02:29] A maior parte do teu tempo será gastar com tarefas difíceis.
[02:34] A maior parte do seu tempo será gastar com tarefas que você não quer fazer.
[02:40] E aí, a primeira mentalidade de quem não quer fazer uma tarefa é fazer o quê?
[02:44] Pô, deixa eu delegar essa tarefa para outra pessoa,
[02:47] deixa eu colocar essa tarefa que eu não gosto de fazer para outras pessoas,
[02:51] deixa eu delegar a minha parte de vendas,
[02:53] ou deixa eu delegar a minha parte operacional,
[02:55] ou deixa eu delegar a minha operação inteira
[02:58] por mais que eu não possa, por mais que eu não tenha condições,
[03:01] por quê? Porque eu não quero fazer.
[03:03] E aí acontece isso o tempo todo.
[03:06] E a maioria das pessoas estão travadas no resultado
[03:10] porque elas não fazem o que elas deveriam fazer.
[03:12] Porque elas estão na falsa sensação de que eu preciso o tempo todo,
[03:16] amar o que eu faço,
[03:18] e para amar o que eu faço,
[03:19] eu preciso que esse trabalho seja nosso,
[03:22] que trabalho divertido, que trabalho legal,
[03:25] eu amo fazer isso que eu faço, cara, eu não amo.
[03:29] De verdade mesmo, vamos colocar aqui,
[03:32] acordar oito horas da manhã, de um sábado,
[03:35] e ficar até, sei lá, quatro da tarde,
[03:39] dando aula, realmente fazendo ali, ensinando,
[03:42] cara, eu gosto de fazer isso, gosto,
[03:44] mas eu vou gostar de cada minuto?
[03:46] Não, é impossível isso.
[03:48] É impossível alguém trabalhar oito horas seguidas,
[03:51] dez horas seguidas, vinte horas seguidas,
[03:53] e amar cada segundo, cada minuto.
[03:55] Existem processos chatos, existem processos legais.
[03:58] Pô, eu amo dar aula, mas criar o material da aula,
[04:01] nossa, que saco, que difícil.
[04:04] Pô, aqui, parte chata, mas a aula não acontece se eu não crie o material.
[04:09] Eu não tenho um cliente para atender se eu gosto do operacional
[04:11] ou se eu não tenho a parte comercial.
[04:13] Então, vocês precisam entender que
[04:15] a primeira regra que eu quero colocar na cabeça de vocês
[04:18] é a primeira coisa que eu quero tirar na cabeça de vocês é...
[04:21] Cara, não é divertido, não vai ser prazeroso,
[04:24] não vai ser fácil,
[04:25] você não precisa estar apaixonado pelo seu trabalho.
[04:29] Essa é a primeira coisa.
[04:30] Não se luda acreditando que você vai aprender a gostar
[04:34] do seu trabalho e de todos os aspectos do seu trabalho.
[04:37] Nossa, eu me divirto, eu amo o que eu estou fazendo.
[04:40] Não, você não ama todos os aspectos.
[04:43] Você ama uma coisa ou outra,
[04:44] ou você ama mais do que você ama outro trabalho,
[04:47] mas você não vai amar todo o processo.
[04:49] E isso é a primeira coisa que você precisa entender,
[04:52] porque se você não entender isso,
[04:55] o que vai começar a acontecer com você?
[04:58] Quando for em tarefas que você não quer fazer,
[05:00] você não vai fazer, você não vai realizar.
[05:02] E aí, você sempre vai ficar estagnado.
[05:05] Por quê?
[05:05] Quando você precisa crescer, você não faz,
[05:07] porque não é uma parte que você ama.
[05:09] Então, você não precisa se sentir motivado,
[05:11] você não precisa se sentir inspirado.
[05:14] O único sentimento que eu tenho de mim mesmo
[05:17] é esse aqui, ó.
[05:19] Eu vou até colocar em negrito.
[05:21] Orgulhoso.
[05:23] Você tem que ficar orgulhoso do que você faz.
[05:26] E orgulhoso é diferente de você se sentir motivado.
[05:29] Orgulhoso é diferente de você ficar ali,
[05:32] nossa, eu estou super motivado, não?
[05:35] Você tem que olhar para o que você faz
[05:37] e falar assim, nossa, que trabalho bacana.
[05:39] Que representação bacana.
[05:41] De quem eu sou.
[05:43] Que o meu trabalho transpareceu
[05:45] e aí você deita no final do dia e fala assim,
[05:47] caraca, que legal.
[05:49] Realmente isso que eu fiz me deu orgulho.
[05:51] Deixa eu fazer uma pergunta para vocês
[05:53] e é muito importante que vocês respondam
[05:55] essa pergunta com sinceridade.
[05:57] Hoje vocês se orgulham do trabalho
[05:59] que vocês estão fazendo.
[06:01] Hoje vocês se orgulham dentro do final do dia.
[06:03] Não precisa me responder, mas responda internamente.
[06:05] Quando acaba o dia, quando acaba o dia a dia,
[06:07] você olha para trás e fala assim,
[06:09] cara, eu fiz tudo o que eu precisava ser feito.
[06:11] O que eu odiava.
[06:13] O que eu não queria fazer.
[06:15] Mas tudo o que precisava ser feito,
[06:17] eu fiz tudo o que eu precisava ser feito.
[06:19] Se você não chega no final do dia
[06:21] e olha para si mesmo,
[06:23] e olha e fala assim, porra,
[06:25] eu não fiz tudo o que eu...
[06:27] eu literalmente não fiz tudo o que eu precisava fazer.
[06:29] Você não sente orgulho de si mesmo.
[06:31] Você vira uma pessoa vitimista
[06:33] que vai olhar sempre e vai falar assim,
[06:35] ah, mas aconteceu tal coisa
[06:37] porque o seu nosso cérebro
[06:39] ele vai trabalhar para quê?
[06:41] Ele vai trabalhar para que
[06:43] nós fiquemos confortáveis com isso.
[06:45] Ah, mas eu não consegui
[06:47] por causa de tal motivo.
[06:49] Ah, eu tive, sei lá,
[06:51] eu tive um imprevisto tal horário,
[06:53] eu tive um imprevisto tal dia,
[06:55] eu tive um imprevisto em tal momento
[06:57] e aí essas pessoas,
[06:59] elas vão ficar colocando
[07:01] um monte de desculpas para elas mesmas
[07:03] pelo qual elas não fizeram
[07:05] e elas nunca vão se orgulhar
[07:07] verdadeiramente para elas
[07:09] verdadeiramente delas
[07:11] então a primeira pessoa
[07:13] que tem que se orgulhar de si é você
[07:15] se você tem que ter a cabeça no travesseiro
[07:17] e
[07:19] não olha o seu dia e fala assim, caraca
[07:21] hoje eu dei o meu melhor
[07:23] hoje eu fiz o que precisava ser feito
[07:25] hoje eu tomei decisões difíceis
[07:27] hoje eu tive um dia cansativo
[07:29] mas eu tive um dia que eu me orgulho
[07:31] isso não é motivação
[07:33] quando você olha
[07:35] e você fala assim, nossa, queria
[07:37] ter feito isso hoje
[07:39] ah, mas não deu, tudo bem
[07:41] tá isso, você não sente orgulho de você mesmo
[07:43] então, muitas das vezes
[07:45] você tá na situação que você tá
[07:47] e muitas das vezes as pessoas ignoram
[07:49] isso e falam assim, pô, Gustavo, vamos para o conteúdo
[07:51] técnico logo porque vocês acham que
[07:53] vocês precisam de mais conteúdo técnico
[07:55] quando na verdade vocês precisam
[07:57] tomar um rumo em si mesmo
[07:59] eu tenho certeza de noite
[08:01] você pega, deita a cabeça no travesseiro e fala assim
[08:03] nossa, eu tenho várias ideias de como eu vou melhorar
[08:05] eu tenho várias ideias de como eu vou evoluir
[08:07] eu tenho várias ideias de como eu vou crescer
[08:09] ou eu vou fazer aquilo, vou fazer aquilo outro
[08:11] e aí você tem esses picos
[08:13] durante a sua semana
[08:15] você tem esses picos durante o seu mês
[08:17] e aí você fala assim, esses picos
[08:19] eles são resumidos aqui
[08:22] há um processo que muitas das vezes
[08:24] você nunca vai realizar
[08:26] e você nunca vai realizar porque você se acostumou
[08:28] a só fazer o que você quer
[08:30] então, assuma a primeira realidade
[08:32] e começa a colocar para ti
[08:34] para si mesmo
[08:36] uma sensação de orgulho
[08:38] uma sensação de orgulho de si mesmo
[08:40] e aí vem um próximo ponto
[08:42] o desenvolvimento
[08:44] da tolerância à frustração
[08:46] caras, a verdadeira métrica
[08:48] de resistência, eu coloquei isso aqui
[08:50] a tolerância, a frustração
[08:52] definida como a capacidade
[08:54] de realizar a mesma tarefa repetidamente
[08:56] sem recompensa
[08:58] e continuar seguindo em frente
[09:00] vamos falar uma coisa
[09:02] tolerância
[09:04] à literalmente a frustração
[09:06] o dia que você não vende, como que você fica
[09:08] o dia que você não consegue
[09:10] marcar reuniões, como que você fica
[09:12] o dia que você
[09:14] alguma coisa deu errado
[09:16] um cliente brigou com você, algum lead
[09:18] cancelou uma reunião
[09:20] você não conseguiu fazer uma venda
[09:22] a sua mulher brigou com você
[09:24] e você não conseguiu trabalhar
[09:26] e você lida com essa frustração
[09:30] e aí esse que é o grande
[09:32] problema da maioria das pessoas
[09:34] eu voltei a vender
[09:36] eu voltei a vender
[09:38] ali no finalzinho do mês passado
[09:40] e no início de abril
[09:42] e aí no início de abril
[09:44] pra cá, eu tenho feito todos os dias
[09:46] de
[09:48] 8, 7, 7, 8
[09:50] a 10, 12 horas
[09:52] de reuniões seguidas
[09:54] sabe qual que está sendo o resultado
[09:56] 3, 4, 10 mil reais
[09:58] vendidos todos os dias
[10:00] mas sabe o que é muito louco isso?
[10:02] a tolerância
[10:04] a frustração
[10:06] cara, é muito chato isso
[10:08] é muito chato você acordar de manhã
[10:10] e ter que fazer um monte de reuniões
[10:12] é muito chato você escutar sempre as mesmas
[10:14] as mesmas objeções
[10:16] as mesmas histórias
[10:18] as mesmas desculpas, os mesmos todos
[10:20] não é só o dinheiro
[10:22] literalmente
[10:24] quando você leva um não, o que você faz?
[10:26] o que você faz
[10:28] quando você se frustra?
[10:30] leva um não
[10:32] em uma, duas, três, quatro, cinco
[10:34] reuniões seguidas e você vai pra sexta
[10:36] como que o seu cérebro está?
[10:38] você tem que resetar
[10:40] porque se o seu foco principal
[10:42] tá, ele for
[10:44] essa frustração, se o seu foco principal
[10:46] ele for sempre vencer
[10:48] ele sempre tipo nossa
[10:50] quando eu estou vencendo eu estou bem
[10:52] quando eu estou vencendo acabou o meu dia
[10:54] não, você não pode se comportar assim
[10:56] a real é que eu entro em todos os jogos
[10:59] pra ganhar
[11:01] eu entro em todas as reuniões pra ganhar
[11:03] isso que eu ainda tenho uma taxa de conversão muito alta
[11:05] eu ainda recebo muito mais sim do que não
[11:07] mas
[11:09] se eu perco
[11:11] eu não fico frustrado
[11:13] eu trato isso como
[11:15] mais um obstáculo
[11:17] mais um percurso
[11:19] mais uma trilha que eu tentei caminhar
[11:21] para a próxima
[11:23] boa hora de próxima
[11:25] ou se você precisa ligar o dia inteiro
[11:27] cara, você vai ficar frustrado
[11:29] você vai ficar fazendo um monte de coisa
[11:31] que você não vai ver recopência
[11:33] que você não vai ver dinheiro entrando
[11:35] que você não vai ver um monte de coisa fazendo
[11:37] isso eu estou falando de reunião de vendas
[11:39] e a prospecção então
[11:41] às vezes você pega uma semana inteira
[11:43] você faz 100 ligações por dia
[11:45] e aí chega ali no final da semana
[11:47] e você falou assim cara, não vem de nada
[11:49] com essas 100 ligações por dia
[11:51] e aí na semana que vem você já diminui
[11:55] e aí passa um mês
[11:57] você já nem está mais fazendo
[11:59] e eu tenho certeza
[12:01] que isso já aconteceu com muitas de vocês
[12:03] sabe por que? porque a sua tolerância
[12:05] a frustração ela é muito baixa
[12:07] a sua capacidade
[12:09] de seguir sem realmente ter uma
[12:11] recompensa ela é muito baixa
[12:13] e aí o que você precisa fazer?
[12:15] você precisa lidar com esse tédio
[12:17] quando você vai
[12:19] se treinando mentalmente
[12:21] para realmente lidar
[12:23] com esse tédio
[12:25] cara, você começa a ter
[12:27] um resultado incrível
[12:29] se você pega, eu li isso
[12:31] num livro, eu não lembro qual livro foi
[12:33] mas eu li isso, eu lembro do trecho
[12:35] claramente, escrito assim cara
[12:37] se você pegar ali, eu acho que foi
[12:39] no livro Outlier, alguém confirma pra mim
[12:41] se você pegar ali
[12:43] colocasse a vida de um atleta
[12:45] em, sei lá
[12:47] em
[12:49] milhões ali de vezes mais rápido
[12:51] você ia ver que o dia a dia dele
[12:53] normalmente é fazendo a mesma
[12:55] coisa todos os dias fazendo
[12:57] alguns ajustes
[12:59] você vai ver que literalmente
[13:01] o dia a dia do atleta
[13:03] é você ele acordar
[13:05] treinar, acordar, treinar
[13:07] acordar, acordar, acordar
[13:09] acordar, treinar, jogou um jogo
[13:11] ganhou, perdeu, perdeu
[13:13] acordou, treinou, acordou, treinou
[13:15] acordou, treinou, acordou
[13:17] perdeu de novo, acordou, treinou
[13:19] depois de um ano, ganhou
[13:21] parabéns, caraca, esse cara é muito bom
[13:23] só que ninguém tá olhando
[13:26] o percurso atrás
[13:28] acordei, treinei, acordei
[13:30] acordei, liguei, acordei
[13:32] vendi, acordei, fiz reunião, acordei
[13:34] fiz o processo, acordei, prospectei
[13:36] prospectei, prospectei, prospectei
[13:38] perdi, não vendi nada
[13:40] e aí eu reincio
[13:42] prospectei, prospectei, prospectei
[13:44] prospectei, prospectei, prospectei, prospectei
[13:46] perdi, não vendi nada
[13:48] e eu tenho que continuar
[13:50] porque se eu continuar isso, talvez em
[13:52] uma semana você não veja resultado
[13:54] talvez em duas semanas você não veja resultado
[13:56] mas em um ano é impossível você não ver resultado
[13:58] é literalmente impossível
[14:00] você não ter resultado
[14:02] então, o que a gente
[14:07] faz aqui mentalmente
[14:09] Michael Phelps
[14:11] exatamente, exatamente
[14:13] cara, olha a vida do Michael Phelps
[14:15] olha a vida do Kobe Bryant, por exemplo
[14:17] ele chegava
[14:19] o treino dele era
[14:21] cara, deixa eu fazer mil arremessos
[14:23] deixa eu falar uma coisa pra vocês
[14:25] eu já joguei basquete, alguém aqui já jogou basquete
[14:27] você sabe o que é fazer mil arremessos
[14:29] o cara, ele fazia mil arremessos
[14:31] todos os dias
[14:33] e 100 deles, eu acho que se eu não me engano 100
[14:35] 200 arremessos era antes do treino dele
[14:37] principal
[14:39] você já fez mil arremessos, você sabe
[14:41] o quanto é chato fazer isso
[14:43] e o quanto é chato você tentar acertar
[14:45] mil vezes ali, é uma mesma sess
[14:47] você sabe o quanto isso é difícil
[14:49] o quanto isso é doloroso
[14:51] o quanto isso é interdíante
[14:53] o quanto que o esforço físico
[14:55] e mental você precisa pra fazer isso
[14:57] só que
[15:01] a melhor maneira de você conseguir fazer
[15:03] uma coisa consistentemente
[15:05] por exemplo, eu tô fazendo eventos
[15:07] Arturia, quanto tempo eu tô fazendo evento?
[15:09] acho
[15:11] deixa eu te conhecer, faz quase um ano já
[15:13] eu acho que faz um ano
[15:15] antes disso você já tava fazendo
[15:17] se pá mais ainda
[15:19] acho que mais de um ano eu já faço eventos
[15:21] todas as semanas
[15:23] todas as semanas, semana, semana
[15:25] semana, semana, semana, semana
[15:27] às vezes mais de uma vez por semana
[15:29] e eu faço evento, faço evento, faz evento
[15:31] faço evento, faço evento
[15:33] só que se você pegar o meu primeiro evento
[15:35] e o evento de hoje você vai falar
[15:37] caraca, não parece mesmo Gustavo
[15:39] sabe qualquer coisa que eu mais escuto
[15:41] em dia, nossa Gustavo
[15:43] esse foi o melhor evento que você fez
[15:45] nossa Gustavo, esse foi o melhor
[15:47] webinário que você fez e não foi
[15:49] sabe qual que é o ponto?
[15:51] eu sempre vou fazendo
[15:53] eu tenho uma tarefa repetitiva
[15:55] cara, eu faço isso toda semana
[15:57] se eu pegar e repetir exatamente o mesmo webinário
[15:59] meu time pode comprovar isso pra vocês
[16:01] se eu falar exatamente a mesma coisa
[16:03] em dois webinários diferentes, vocês vão ver
[16:05] a minha expressão triste
[16:07] eu mais desanimado do que no primeiro
[16:09] porque eu sempre vou mudar alguma coisa
[16:11] e aí
[16:13] tá escrito isso aqui ó
[16:15] a dor de fazer tarefas repetitivas que você odeia
[16:17] é a
[16:19] oportunidade de tentar descobrir
[16:21] maneiras melhores de executá-la
[16:23] cara, não que eu odeio
[16:25] o webinário, não que eu odeio fazer eventos
[16:27] mas eu odeio e a partir
[16:29] de um momento passou quatro meses eu falando
[16:31] exatamente as mesmas frases, eu comecei a odiar
[16:35] e aí eu fui buscando maneiras melhores
[16:37] de executar essa mesma coisa
[16:39] e aí eu estou sempre me descobrindo na mesma coisa
[16:41] eu estou sempre melhorando na mesma coisa
[16:43] mas sem perder a consistência
[16:45] porque às vezes você fala assim
[16:47] cara, eu vou mudar meu jeito de prospectar
[16:49] aí você fazer 100 ligações por dia e você confundir
[16:51] nossa, mudar o jeito de prospectar é fazer 20 ligações por dia
[16:53] só que de uma maneira diferente
[16:55] não, você continua fazendo a 100
[16:57] só que com um script diferente, alguma coisa diferente
[16:59] fala uma coisa diferente
[17:01] e outra
[17:03] é pra você mudar
[17:05] somente depois, de muito tempo
[17:07] é pra você otimizar
[17:09] o que for dando certo, mas não é pra você mudar
[17:11] toda hora, não é pra você mudar
[17:13] o escopo completo, é pra você continuar persistente
[17:17] esse processo
[17:19] de buscar as coisas
[17:21] odiáveis de forma mais eficiente
[17:23] é exatamente o que significa
[17:25] ficar melhor em uma habilidade
[17:27] você já parou pra pensar que
[17:31] pensa comigo, eu faço uma ligação
[17:33] beleza
[17:35] eu percebi que nessa ligação
[17:37] meu tom de voz não foi tão bom
[17:39] eu vou tentar falar com um tom de voz um pouco mais alto
[17:41] faço outra ligação
[17:43] e aí eu faço outra ligação
[17:45] e aí eu prospecto outra empresa
[17:47] eu vou atrás de outro cliente
[17:49] eu vou atrás de outro e eu melhore
[17:51] eu melhore, eu melhore, eu melhore
[17:53] eu sabe porque a maioria de vocês não tem
[17:55] consistência na ligação, na prospecção
[17:57] porque vocês usam o mesmo script
[17:59] vocês continuam sendo
[18:01] pessoas medíocres que vocês eram
[18:03] há um mês atrás
[18:05] a maioria
[18:07] das pessoas que não
[18:09] prossegue e não consegue
[18:11] aguentar um processo tedioso
[18:13] são pessoas que não melhorem
[18:15] que não buscam
[18:17] melhorar, que não buscam se aprimorar
[18:19] e aí essas pessoas que não buscam
[18:21] se aprimorar elas acabam
[18:23] não fazendo, porque elas acabam não fazendo
[18:25] porque elas não enxergam o resultado
[18:27] nem no curto, nem no médio, nem no longo prazo
[18:31] deixa eu perguntar, hoje
[18:33] o quanto você é referência no que você faz
[18:35] hoje, depois de tanto tempo
[18:37] depois de tanto fazer
[18:39] depois de tanto fazer consistentemente
[18:41] melhorando a cada dia, o quanto que você é referência
[18:43] porque é impossível
[18:45] hoje e é muito engraçado
[18:47] porque às vezes eu pego um evento
[18:49] eu pego um ebinário, às vezes eu vou palestrar
[18:51] para um monte de empresário que eu nunca vi na vida
[18:53] sobre um assunto que eu nunca vi na vida
[18:55] eu consigo palestrar, fazer um bom evento porque
[18:57] porque eu sou incrível, não
[18:59] eu tenho várias e várias outras vezes
[19:01] porque eu fui criando ferramentas
[19:03] que compõem essa habilidade
[19:05] e fazem com que isso se torne fácil
[19:07] agora, pega qualquer pessoa que nunca fez isso
[19:09] para fazer isso
[19:11] é difícil
[19:13] cara, é quase impossível
[19:15] se eu for contar
[19:17] as horas que eu tenho dando aula
[19:19] versus as horas que eu tenho fazendo eventos
[19:21] ou entregando algum tipo de conteúdo
[19:23] de verdade mesmo, eu acho que já passa
[19:25] ali das 4 mil horas
[19:27] tranquilamente
[19:29] e aí, por que para mim é muito fácil
[19:31] explicar às vezes uma coisa e entender um conceito
[19:33] novo, porque eu estou sempre ensinando conceitos
[19:35] e é isso que eu quero que vocês entendam
[19:37] o processo tedioso
[19:39] vai construir coisas em você
[19:41] que vai fazer com que você enriquece
[19:43] e vai fazer com que você não se perca
[19:45] e consiga continuar crescendo para sempre
[19:47] então, cria essa tolerância
[19:49] frustração
[19:51] só que também trabalha essa tolerância
[19:53] a modo que você sempre continue
[19:55] melhorando, evoluindo
[19:57] quem aqui colocou um objetivo
[19:59] por exemplo, no início desse mês
[20:01] isso que eu gostaria
[20:03] de saber, eu gostaria de saber
[20:05] com honestidade, quem aqui colocou um objetivo
[20:07] no início desse mês falou
[20:09] eu vou fazer tantas ligações, eu vou fazer isso de prospecção
[20:11] eu vou fazer isso de vendas
[20:13] eu vou fazer tal coisa e na metade do mês
[20:15] você já não estava mais fazendo
[20:17] alguém aqui aconteceu isso com algum
[20:19] de vocês aqui?
[20:24] se aconteceu isso, com algum de vocês
[20:26] o Jefferson falou
[20:28] todo mês é um início novo
[20:30] e aí todo mês é a mesma frustração
[20:32] quando eu comecei
[20:34] esse mês
[20:36] e a galera do meu time
[20:38] eles sempre tendem a duvidar
[20:40] porque as vezes eu dou uns sumiços
[20:42] mas eu falei assim, eu vou fazer
[20:44] todas as reuniões
[20:46] eu vou assumir a porra de todas as reuniões
[20:48] e vou fazer venda pra caralho
[20:50] aí o meu time olhou, eu olhei para duas pessoas
[20:52] e as duas pessoas olharam pra mim
[20:54] e falaram assim, fogo, estavo
[20:56] eu acho que tu não vai conseguir
[20:58] eu falei foda-se, eu não quero saber a sua opinião
[21:00] eu disse que eu vou fazer e eu vou realmente fazer
[21:02] e aí eu fiz no dia que eu estava triste
[21:05] eu fiz no dia que eu estava feliz
[21:07] eu fiz no dia do meu aniversário
[21:09] no dia do meu aniversário
[21:11] eu trabalhei quantas horas Artur
[21:13] eu acordei de manhã, acho que foi até umas 11 da noite
[21:15] mais que 12 horas
[21:17] de reunião
[21:19] no dia do meu aniversário
[21:21] por que? porque eu falei que eu ia fazer
[21:23] porque eu falei cara, se eu não construir isso
[21:25] mentalmente
[21:27] eu vou ficar mais fraco
[21:29] eu estava no estado aonde eu estava
[21:31] me acostumando com fracasso
[21:33] e qual que é o fracasso? você falar que vai fazer algo e não fazer
[21:37] não importa o resultado e o final
[21:39] pra mim não importa quanto que eu vou vender esse mês
[21:41] por mais que eu metrifique
[21:43] por mais que eu me planeje, por mais que eu faça tudo
[21:45] eu só quero chegar aqui, chegue no final
[21:47] desse mês e eu olho para trás e falo assim
[21:49] cara, eu fiz tudo que eu podia
[21:51] se tiver um momento, se tiver uma hora
[21:53] se tiver uma reunião que eu poderia ter feito
[21:55] e eu não fiz, eu vou ficar frustrado
[21:57] se tiver um momento aonde eu
[21:59] gastei um tempo fazendo merda
[22:01] onde eu poderia realmente estar sendo produtivo
[22:03] e fazendo o que eu me propuso a fazer
[22:05] eu vou ficar frustrado
[22:07] eu não vou me sentir orgulhoso
[22:09] então o primeiro passo é você sentir orgulhoso
[22:11] e você tolerar essa frustração
[22:13] tolerar esse tédio
[22:15] e aí a tua paixão
[22:17] ela não vem pelo que você faz
[22:19] pelo que? pela excelência
[22:22] e essa paixão pela excelência
[22:24] vai fazer com que você venda muito
[22:26] essa paixão pela excelência
[22:28] vai fazer com que você tenha um propósito
[22:30] essa paixão pela excelência
[22:32] vai fazer com que você se torne uma pessoa diferente
[22:37] ontem eu estava jogando com os meninos
[22:39] e aí eu peguei e comecei a jogar
[22:41] eu estava conversando com o Tito
[22:43] e aí o Tito falou assim
[22:45] Gustavo, você é muito
[22:47] arrogante, orgulhoso
[22:49] porque você iniciou o jogo falando assim
[22:52] é melhor que vocês que jogam isso há muito tempo
[22:54] não é que eu sou arrogante
[22:56] orgulhoso ou vocês podem achar que eu sou
[22:58] mas não importa
[23:00] o que importa é que eu vou fazer
[23:02] eu vou aprender, eu vou me adaptar
[23:04] eu vou realmente melhorar
[23:06] e as pessoas sempre vão te confundir
[23:08] como um arrogante se você
[23:10] quiser melhorar o tempo todo
[23:12] as pessoas vão te olhar diferente
[23:14] e vocês têm que se acostumar com isso
[23:16] então quando a gente coloca ali
[23:18] até o próprio foco que vocês
[23:20] têm que ter
[23:22] o próprio foco que vocês têm que ter
[23:24] não é você ser
[23:26] ali, tentar ser apaixonado pela tarefa
[23:28] como está escrito ali
[23:30] isso aí não vai sustentar 10 horas de esforço
[23:32] isso aí não vai sustentar um dia de esforço
[23:34] cara, você tem que
[23:36] literalmente ser apaixonado
[23:38] em ser excelente
[23:40] o qual que é a paixão de ser excelente
[23:42] não é ser perfeito, não é nossa
[23:44] que cara, incrível, nossa, ele faz tudo muito bem
[23:46] não
[23:48] isso aí
[23:50] cara, você fez tudo que você podia
[23:52] e não é na visão dos outros, é na sua visão
[23:56] a grande excelência é você olhar e falar assim
[23:58] cara, eu sou apaixonado
[24:00] em ser muito bom em vendas
[24:02] eu sou apaixonado
[24:04] em ter realmente
[24:06] a consistência absurda de fazer mais reuniões
[24:08] que todo mundo, eu sou apaixonado
[24:10] em saber que se eu entrar em algum lugar
[24:12] eu vou realmente alavancar esse lugar
[24:14] eu vou fazer com que esse lugar
[24:16] essa pessoa ela tenha resultados diferentes
[24:18] a minha paixão é ser excelente
[24:20] nos mínimos detalhes
[24:22] a minha paixão
[24:24] é ser excelente em ser obcecado
[24:26] não necessariamente na quantidade
[24:28] de reuniões que eu faço, mas sabendo o que
[24:32] se eu tiver que fazer, eu vou estar lá
[24:34] e aí eu vou construir
[24:36] isso aos poucos
[24:38] porque eu falho também, o ser humano é falho
[24:40] nós falhamos
[24:42] cara, às vezes eu remarco mais reunião
[24:44] sem motivo, às vezes eu dou um no show
[24:46] às vezes eu faço coisas ali que não era pra eu fazer
[24:48] só que se a gente
[24:50] somar os meus acertos
[24:52] com meus erros
[24:54] vai dar a ser ir lá, 95%
[24:56] de vantagem
[24:58] pra parte que está executando
[25:02] ah Gustavo, mas você deixou aquela e aquela vez
[25:04] foda-se
[25:06] o que importa pra mim é a minha excelência
[25:08] a minha percepção de excelência
[25:10] e aí eu pergunto pra vocês qual é a percepção
[25:12] de excelência de vocês
[25:14] mesmo
[25:16] coloca a mão na consciência de vocês
[25:18] vocês realmente são excelentes no que
[25:20] vocês executam
[25:22] vocês teriam uma confiança o suficiente pra falar
[25:24] cara, se eu faço uma ligação
[25:26] eu marco reunião
[25:28] eu tive uma conversa com o Adriano
[25:30] o Adriano sem dúvidas
[25:32] ele é o melhor de outbound do Brasil
[25:34] eu não tenho dúvidas disso
[25:36] tá, que o Adriano ele é o melhor
[25:38] de outbound do Brasil
[25:40] não sei nem se o Adriano está aí
[25:42] um dia eu lembro exatamente o que a gente conversou
[25:44] ele falou assim
[25:46] nem outro, se eu e você competisse
[25:48] marcando reuniões
[25:50] quem ganharia, eu falei com certeza eu
[25:55] porque
[25:57] eu realmente, eu sou excelente
[25:59] eu vou começar perdendo
[26:01] às vezes eu vou começar em desvantagem
[26:03] mas pode ter certeza, eu vou melhorar
[26:05] a ponto de não aceitar perder
[26:07] a ponto de eu realmente conseguir fazer o que eu preciso fazer
[26:09] e eu preciso que vocês mudem o foco de vocês
[26:11] não pra competir com o Adriano
[26:13] não pra competir com qualquer outra pessoa
[26:15] mas eu sei que se eu ficar excelente
[26:17] a ponto de não errar
[26:19] se eu ficar excelente a ponto de
[26:21] conseguir executar tudo
[26:25] eu vou ser o melhor
[26:29] e sinceramente, eu já sou muito bom
[26:31] em algo que eu nem pratico
[26:33] no dia a dia
[26:35] o Arthur ontem, eu tirei ali
[26:37] acho que foi, sei lá
[26:39] acho que eu tirei 5, 7 minutos
[26:41] né Arthur
[26:43] 5, 7 minutos
[26:45] Arthur, eu vou fazer algumas vendas pelo telefone
[26:47] eu liguei
[26:49] em 5, 7 minutos, eu fiz acho que
[26:51] 3, 4 vendas
[26:53] alguma coisa assim
[26:57] vendas, eu não estou falando de reuniões marcadas
[26:59] nem nada do tipo, estou falando de vendas
[27:01] eu estou falando de produtos que eu precisava de follow up
[27:03] outras coisas que eu precisava fazer
[27:05] às vezes até um ingresso de vocês ali
[27:07] que eu precisava conversar com vocês pra vocês entrarem aqui
[27:09] mas por que que eu era muito bom
[27:11] e por que que eu fui muito bom nisso
[27:13] porque eu simplesmente liguei com uma confiança absoluta
[27:15] de que ia dar certo
[27:17] por que que eu tenho essa confiança
[27:19] porque eu sei que eu sou um profissional excelente no que eu faço
[27:21] acabou
[27:23] por que que a minha aula é boa
[27:25] por que que eu considero a minha aula boa
[27:27] e por que que isso afasta as pessoas
[27:29] por que que às vezes esse ponto afasta as pessoas
[27:31] por que quando você é cheio de si
[27:33] e confia no que você está fazendo
[27:35] você automaticamente
[27:37] incomoda quem não confia em si mesmo
[27:39] e tá tudo bem
[27:41] se você está se sentindo assim nesse momento
[27:43] porque eu vou trazer um próximo ponto pra vocês
[27:45] que realmente
[27:47] vocês precisam
[27:49] entender
[27:51] tá
[27:53] deixa eu passar por essa parte aqui
[27:55] que eu acho que isso aqui é essencial pra todo mundo que quer
[27:57] ter ali algum
[27:59] algum quesito de sucesso dentro da tua vida
[28:01] trabalhar por horas a fio
[28:03] envolve
[28:05] lidar com problemas não resolvidos e frustrações
[28:07] gente
[28:09] vamos lá
[28:11] e que tem algum problema que não está resolvido
[28:13] alguém aqui tem alguma frustração que está
[28:15] ali dentro de si
[28:17] você precisa resolver isso
[28:19] e muitas das vezes
[28:21] resolver um problema que te incomoda
[28:23] vai fazer com que você
[28:25] libere bagagem
[28:27] só que nós seres humanos
[28:29] nós pessoas comuns
[28:31] nós meros mortais
[28:33] estamos sempre evitando problemas
[28:35] deixa eu falar qual que é a digação difícil que você precisa fazer
[28:37] qual que é o não que você precisa falar
[28:39] qual que é a pessoa
[28:41] que você precisa falar com ela agora
[28:43] sobre algo que você não gosta
[28:45] quais são as coisas que você precisa resolver
[28:47] eu vou resolvendo
[28:49] uma por dia
[28:51] todos os dias eu resolvo problemas difíceis
[28:53] todos os dias eu resolvo coisas que eu não quero resolver
[28:55] e aí o que a gente faz
[28:57] pra conseguir resolver coisas que a gente não quer resolver
[28:59] sempre que eu pego um problema
[29:01] gigantesco
[29:03] sempre que eu pego alguma coisa
[29:05] alguma coisa que eu não quero lidar
[29:07] eu falo assim cara se eu lidar com isso
[29:09] eu vou ser mais forte
[29:11] e eu sendo mais forte eu vou ser um melhor pai
[29:13] eu vou ser um melhor marido
[29:15] eu vou ser um melhor empresário
[29:17] eu vou ser um melhor chefe
[29:19] eu vou ser um melhor vendedor
[29:21] então se eu resolver isso aqui
[29:23] por maior que seja esse problema
[29:25] no final eu vou ter orgulho de mim mesmo
[29:27] por ter conseguido lidar com esse problema
[29:29] e muitas das vezes é um problema que você não quer resolver
[29:31] é uma conversa difícil de que você não quer ter
[29:33] com alguém
[29:35] sai das batalhas que você quer lidar
[29:37] sai das batalhas que você quer enfrentar
[29:39] mas se isso tira sua paz
[29:41] mental a ponto de você não conseguir
[29:43] performar
[29:45] cara vai lá e resolve
[29:47] às vezes isso tá impedindo de você ser a mulher
[29:49] de você ser o homem que você queria ser
[29:51] de você ser o homem que você admira
[29:53] de você ser a mulher que você admira
[29:55] deixa a gente fazer uma pergunta
[29:57] se você tá carregando
[30:02] alguém nesse exato momento
[30:04] que você ou precisa pedir desculpa pra ela
[30:06] ou você precisa ser sincero
[30:08] ou você tá com uma dívida enorme
[30:10] ou seja lá o que você esteja
[30:12] diga pra essa pessoa e resolve
[30:14] resolve
[30:16] de verdade mesmo isso tá te atrapalhando
[30:18] se você pensa no problema
[30:20] o tempo todo eu já tive isso
[30:22] eu tive uma época
[30:24] que se o meu whatsapp
[30:26] tocasse
[30:28] cara eu sabia que era problema
[30:30] então eu ficava até hoje
[30:32] pode ver se você não consegue me ligar direto
[30:34] que eu tinha que mandar notificação porque
[30:36] eu tive uma época da minha vida
[30:38] que eu tive tantos problemas
[30:40] e cada mensagem dentro do meu whatsapp
[30:42] era um problema diferente
[30:44] e aí o que que eu fiz naquela época
[30:46] eu agi como um covargue eu fui fugindo
[30:48] daqueles problemas sabe quanto tempo
[30:50] eu levei pra resolver aqueles problemas
[30:52] quando eu decidi enfrentar eles
[30:54] um dia
[30:56] um dia de ligações difíceis
[30:58] um dia de reuniões chatas
[31:00] um dia de palavras difíceis
[31:02] e coisas que eu não queria engolir
[31:04] que feria meu ego, meu orgulho
[31:06] de escutar quieto
[31:08] de abaixar a cabeça quando eu estava certo
[31:10] sabe porquê?
[31:12] porque o que mais importava pra mim
[31:14] e o que mais importa pra mim até hoje é minha paz
[31:16] e não minha paz
[31:18] porque eu quero viver em paz
[31:20] não, não é minha paz porque eu acho
[31:22] nossa eu quero ter um estado de vida zen
[31:24] eu quero ter um estado de vida xyzen
[31:26] não
[31:28] é minha paz porque
[31:30] eu preciso performar
[31:32] eu sei qual que é o meu 80-20
[31:34] eu sei qual que é o objetivo que está na minha frente
[31:36] e se o que
[31:38] eu estou passando
[31:40] ou o problema ele está me incomodando
[31:42] a ponto de impedir o que eu preciso fazer
[31:44] eu tenho que resolver ele
[31:46] então resolvam os problemas de vocês
[31:48] Gustavo não tem solução
[31:50] então um problema que não tem solução
[31:52] você precisa falar e comunicar
[31:54] cara eu não tenho solução pra isso agora
[31:56] eu preciso que
[31:58] eu tenho um tempo pra me resolver isso
[32:00] eu preciso que você faça isso e isso
[32:02] eu preciso de um tempo pra realmente pensar
[32:04] e aí você trabalha
[32:06] tira o problema da tua cabeça
[32:08] pega um papel e a caneta agora
[32:10] tira o problema da tua cabeça
[32:12] e outra
[32:14] e é bom eu ter chegado nessa parte porque
[32:16] você vai ter que lidar com a solidão do esforço
[32:20] você vai ter que lidar com a solidão do esforço
[32:22] tá?
[32:24] porque no dia a dia vai ser só você
[32:26] agustável
[32:28] eu tenho Deus no meu coração mas você
[32:30] ocupa sua mente com tantas vozes
[32:32] que aí às vezes você nem escuta a voz de Deus
[32:34] pra você escutar a voz de Deus
[32:36] você precisa estar com você mesmo
[32:38] você estar ali realmente
[32:40] pensando você ter a solidão
[32:42] porque o sucesso ele é
[32:44] solitário e eu não estou falando de religião
[32:46] aqui não tá
[32:48] mas trabalhar 7 a 10 horas por dia
[32:50] significa que você vai fazer o que
[32:52] você vai te sair
[32:54] um pouco da nossa própria biologia
[32:56] um pouco
[32:58] da nossa própria sociedade
[33:00] que foi estruturada pra gente fracassar
[33:02] que é um exemplo disso
[33:04] você tá sempre buscando a validação
[33:06] você tá sempre buscando a opinião de alguém
[33:08] você tá sempre buscando alguma coisa de
[33:10] alguém algum reforço algum carinho
[33:12] algum elogio alguma coisa
[33:14] você tá sempre rolando
[33:16] a tela do seu celular sem fazer nada
[33:18] pra que você não precise pensar nos problemas
[33:20] que você tem
[33:23] eu falei assim cara hoje eu não vou usar o celular
[33:25] eu vou usar
[33:27] para as coisas do trabalho que eu preciso fazer
[33:29] às vezes postar uma história de outro
[33:31] mas eu não vou usar o celular
[33:33] eu não vou jogar conversa fora com ninguém
[33:35] eu não vou fazer nada com ninguém porque hoje
[33:37] eu tenho uma missão a minha missão é o que dá aula
[33:39] a minha missão é o que fazer com que
[33:41] essa imersão seja a melhor imersão de todas
[33:43] então você tem que se acostumar
[33:45] com a solidão
[33:50] às vezes até dorme demais pra não poder lidar
[33:52] com os problemas
[33:54] e isso acontece com todos os seres humanos
[33:56] eu não sou perfeito
[33:58] tem dias que eu pego
[34:00] eu olho o celular e eu fico horas e horas no celular
[34:02] saber pra quê
[34:04] pra esquecer todos os problemas que eu tenho
[34:06] só que em algum aspecto
[34:08] em algum minuto eu pego e falo assim
[34:10] povo esse aqui não é o Gustavo
[34:12] e eu vou lá, levanto e resolvo
[34:18] eu vou lá, levanto e resolvo
[34:20] então
[34:22] muitas das vezes
[34:24] o que vai acontecer
[34:26] o que vai acontecer
[34:28] sabe por que a maioria das pessoas é pobre
[34:30] sabe por que a maioria das pessoas
[34:32] não vencem na vida
[34:34] sabe por que a maioria das pessoas não tem dinheiro na conta
[34:36] eu vou te falar
[34:39] isso vai doer em vocês e vai parecer
[34:41] que vocês não conseguem fazer isso
[34:43] mas se vocês conseguirem vocês vão ter dinheiro
[34:45] eu vou te falar exatamente por que isso acontece
[34:47] primeiro
[34:49] elas se importam demais com a opinião dos outros
[34:51] e quando a gente fala isso
[34:53] Gustavo, como assim essa pessoa se importa demais com a opinião dos outros
[34:55] deixa eu falar uma coisa
[34:57] sabe por que um pobre ele não vence
[34:59] vamos supor, se você tá ali
[35:01] dentro de um ecossistema, se você tá dentro de uma casa
[35:03] ou dentro de uma família
[35:05] e aí vamos supor que todo mundo
[35:07] e eu vou colocar isso e vocês vão entender de forma
[35:09] prática por que a maioria dos pobres não vencem
[35:11] todo mundo ali ganha 2 mil reais
[35:13] todo mundo ali tem problemas
[35:15] todo mundo ali tem problemas financeiros
[35:17] beleza? ou menos que isso
[35:19] ou não ganha nada, ou sei lá
[35:21] tá numa situação mega difícil
[35:23] todo mundo ali tem uma situação difícil
[35:25] e aí vamos supor que você começa a vencer
[35:27] e aí você começa a ganhar um pouquinho de dinheiro
[35:29] e aí você ganha um dinheiro suficiente
[35:31] pra começar a resolver os seus problemas
[35:33] deixa eu falar
[35:35] se essa família tem 10 pessoas
[35:37] e você começou a vencer pra resolver os seus problemas
[35:39] automaticamente você tem um problema
[35:41] de outras 10 pessoas
[35:43] alguém que já ganhou algum pouco de dinheiro
[35:45] parece que começou a surgir muito mais problemas
[35:47] aí você fala nossa
[35:49] não importa quanto eu ganho quanto mais eu ganho
[35:51] mais problemas aparecem e aparecem problemas do nada
[35:53] que eu não poderia evitar
[35:55] que eu não poderia realmente escolher
[35:57] não fazer
[36:01] e aí se você ganha as vezes você ganhava 2 mil
[36:03] e aí você fala nossa eu ganho 5 vai ser muito bom
[36:05] mas se você ganha 5 agora você precisa de 6
[36:07] por que?
[36:09] não é só você aumentando a sua qualidade de vida
[36:11] não é só você aumentando
[36:13] a quantidade de coisa que você precisa fazer
[36:15] sabe o que você tá fazendo você tá carregando um monte de pessoa
[36:17] se você não tivesse dinheiro
[36:21] aquele micro-ondas que quebrou
[36:23] da tua família
[36:27] não ia ser responsabilidade tu
[36:29] eles iam se virar e iam resolver
[36:31] mas agora que você tem dinheiro você fala
[36:33] eu não posso deixar minha família ser um fogão
[36:35] eu não posso deixar minha família ser um micro-ondas
[36:37] e aí a sua vida é inteira
[36:39] se você nasceu pobre pra quem já é rico
[36:41] vocês não vão entender muito bem o que a gente tá falando
[36:43] que é linguagem de
[36:45] papo de mendingo
[36:47] papo de pobre
[36:50] mas assim
[36:52] você iria conseguir
[36:54] você não iria conseguir ignorar aquele problema
[36:56] você iria ignorar aquele problema na verdade
[36:58] porque você não tinha como resolver
[37:00] se você esse papo não é pra você
[37:02] tá aderendo só pra deixar claro
[37:04] vamos lá então
[37:06] se você
[37:08] realmente tem alguma dificuldade
[37:10] financeira e aí você
[37:12] eleva um pouco seu nível
[37:14] quem aqui já passou de 5 mil reais por mês
[37:16] é importante perguntar isso
[37:18] pra quem tá assistindo gravado depois
[37:20] de 5 mil reais por mês
[37:22] eu tenho certeza que quando você ganhava
[37:24] menos de 5 mil
[37:26] às vezes você conseguia aguardar até mais
[37:28] dinheiro
[37:30] porque a primeira vez que você passa pelo 5 mil
[37:32] é o que eu falei é a barreira dos problemas
[37:34] assim que você ultrapassa o nível
[37:36] você começa a assumir o problema de todo mundo
[37:38] porque agora você não pode mais ignorar
[37:40] que tá faltando detergente na tua casa
[37:42] agora você não pode mais ignorar
[37:44] que só tem
[37:46] arroz e feijão e não tem uma mistura
[37:48] agora você não pode mais ignorar
[37:50] que tal pessoa precisa de um exame
[37:52] médico
[37:54] mas eu vou deixar essa pessoa esperando na fila do upa
[37:56] sabe qual que é o problema e sabe
[38:00] qual que é a coisa mais tenebrosa que eu
[38:02] identifiquei na maioria das pessoas de sucesso
[38:04] elas são
[38:07] nas pessoas que ficaram pobres
[38:09] e depois tiveram sucesso
[38:11] elas são
[38:13] ou elas têm uma ascensão muito rápida
[38:15] que é tipo assim um
[38:17] cresci muito rápido
[38:19] e não é o caso da maioria das pessoas
[38:21] ou elas são extremamente
[38:23] individualistas
[38:25] não tem como você
[38:27] crescer
[38:29] com um monte de gente
[38:31] sendo carregada por você
[38:33] não tem como você crescer
[38:35] ajudando um monte de gente
[38:37] não tem como você crescer
[38:39] pagando um monte de coisas
[38:41] deixa eu falar
[38:43] por alguns meses
[38:45] por alguns anos
[38:47] não terão que ser das pessoas
[38:49] por mais que doa
[38:51] você vai ter que fazer isso
[38:55] Gustavo, quando que eu o ajudo
[38:57] e quando que eu não ajudo
[39:01] faça uma oração sincera
[39:03] você que é cristão
[39:05] se você não é cristão
[39:09] faça uma reflexão junto com você
[39:11] se eu não fizer isso
[39:13] essa pessoa vai morrer
[39:15] se eu não fizer isso
[39:17] essa pessoa vai dar um jeito de resolver
[39:19] vai doer, vai
[39:21] de me apegar nas pessoas
[39:23] cadê o Jorge que está aqui na Cal?
[39:25] cara, seria incrível se o Jorge estivesse aqui na Cal
[39:27] que eu ia pedir para contar uma história dele
[39:30] não tá, eu vou contar a história de outra pessoa
[39:32] então, que realmente aconteceu isso
[39:34] o pessoal vai achar que é a história do Jorge
[39:36] mas não é não, a do Jorge
[39:38] é um pouco mais pesada que isso
[39:40] enfim, teve um amigo meu
[39:42] esses dias ele ligou
[39:44] e ele falou assim, Gustavo
[39:46] eu preciso de um conselho seu
[39:48] eu tenho um irmão
[39:50] ele tem, cara, eu vou contar a história do Jorge mesmo
[39:52] de Jorge, se eu não pudesse contar isso aí
[39:54] você me desculpa, mas ele contou em algum lugar
[39:56] então eu vou contar também
[39:58] fechou, é a história do Jorge
[40:00] eu não vou ficar mentindo aqui não
[40:02] mas o Jorge ele ligou para mim e falou assim
[40:04] Gustavo, eu tenho um irmão e esse irmão
[40:06] ele precisa de uma cirurgia, essa cirurgia é 4 mil reais
[40:08] só que se eu gastar esses 4 mil reais
[40:10] eu vou gastar um dinheiro que estava separado para a empresa
[40:12] para eu fazer tal e tal e tal coisa
[40:17] sabe qual que foi a primeira pergunta que eu fiz para o Jorge?
[40:19] tentem adivinhar qual que foi a primeira pergunta que eu fiz para o Jorge
[40:21] alguém chuta aí no chat
[40:23] qual que foi a primeira pergunta que eu fiz para o Jorge
[40:25] porque isso talvez vai libertar vocês
[40:27] de uma
[40:29] escravidão que vocês vivem
[40:31] com vocês mesmos
[40:33] a primeira pergunta
[40:35] que eu fiz para o Jorge foi
[40:37] o teu irmão não tinha uma moto
[40:39] por que que teu irmão não vende a moto?
[40:43] por que que vocês não vendem a televisão da sala?
[40:45] por que que ele não vende a televisão da sala?
[40:47] o computador dele é moto?
[40:49] se a moto dele é mais importante
[40:51] do que a vida dele, por que que você tem que pagar
[40:53] pela cirurgia dele?
[40:58] o Jorge falou que ele estava pressionado
[41:00] porque a família inteira estava pedindo para ele
[41:02] e aí a partir do momento que eu falei isso
[41:04] ele falou é mesmo
[41:08] e aí ele deu a sugestão, sabe o que acontece
[41:10] quando você dá esse tipo de sugestão?
[41:12] todo mundo te enxinga, todo mundo não fala
[41:14] nossa Gustavo, é uma conquista
[41:16] a gente usa isso para trabalho, a gente usa
[41:20] mas é
[41:22] as pessoas elas são egoístas e elas vão
[41:24] ter um problema delas para você sempre que elas puderem
[41:28] então deixa eu te falar uma coisa
[41:30] para de carregar as pessoas
[41:34] Gustavo
[41:36] eu não tenho dinheiro para jantar
[41:38] se almoçou, almocei, então faz um jejum
[41:40] é nesse nível
[41:45] e essa é a coisa mais dura
[41:47] que eu preciso falar para vocês
[41:49] porque se eu não falar isso para vocês
[41:51] e vocês não pararem de carregar as pessoas
[41:53] vocês não vão ter tempo para enriquecer
[41:55] aguenta fome cara
[41:57] a fome
[41:59] ela é suportável
[42:01] aceite não, se estiver faltando água
[42:03] aí você compra água pai
[42:05] porque se não aí a pessoa realmente morre
[42:07] mas assim, a fome ela é suportável
[42:09] por alguns tempos
[42:11] ela não precisa ser a comida específica que a pessoa que ela
[42:13] precisa ser uma comida
[42:17] sua família ela não precisa de uma televisão
[42:19] às vezes você vai precisar
[42:21] esperar na fila do UPA
[42:23] mesmo você tendo 50 mil na ponta
[42:25] às vezes você vai precisar esperar
[42:29] em algum outro momento
[42:31] para realizar o sonho de alguém que você quer
[42:33] às vezes você vai precisar falar um não
[42:35] durante um aniversário de alguém
[42:37] e cara, eu me emociono isso
[42:41] eu me emociono nisso
[42:43] porque foi isso que fez eu ter sucesso
[42:45] só que esse sucesso que eu tenho hoje
[42:47] eu transbordo para minha família inteira
[42:49] eu lembro um dia específico
[42:51] que eu tinha um dinheiro na conta
[42:53] e esse dinheiro que eu tinha na conta
[42:55] era um dinheiro consideravelmente bom
[42:57] só que era um dinheiro que eu precisava
[42:59] para lavar no caminho de empresa
[43:01] para fazer com que eu fosse ter sucesso
[43:03] e aí eu lembro do meu pai
[43:05] o cara que me ajudou a minha vida inteira
[43:07] chegando em mim falando, Gustavo
[43:09] eu sei que você tem esse dinheiro
[43:11] eu preciso desse dinheiro por causa disso
[43:13] e era uma coisa importante
[43:20] eu tive que falar não
[43:24] eu falei não e deu muito errado
[43:26] muitas coisas para ele
[43:33] quando eu falei isso não
[43:35] só que se eu tivesse falado sim
[43:37] isso foi isso
[43:39] porque meses depois eu dei a volta por cima
[43:41] ganho dinheiro e ajudei muito ele
[43:44] porque quando eu distribuo em abundância
[43:46] o meu coração se alegra
[43:48] mas quando eu distribuo
[43:50] sem ter
[43:55] eu realmente
[43:57] crio um modus operante dentro da minha cabeça
[43:59] que aquilo lá
[44:02] é o certo
[44:04] que o certo é errado ter dinheiro
[44:06] é errado ter dinheiro na conta
[44:08] alguém aqui
[44:10] e eu vou fazer
[44:12] cara você
[44:14] que nasceu numa família pobre
[44:16] independente de quanto dinheiro você ganha
[44:18] a maioria de vocês
[44:20] tem dificuldade de guardar dinheiro
[44:22] eu estou certo ou estou errado
[44:24] a maioria de vocês
[44:26] nunca viu
[44:28] cara eu conheço gente que ganha 15 mil por mês
[44:30] e nunca viu 20 mil na conta
[44:32] eu estou certo ou errado
[44:34] que a maioria de vocês
[44:36] que venham de família pobre e não tem dinheiro guardado
[44:38] ou não consegue
[44:43] guardar muito dinheiro
[44:45] ou não tem ali sempre uma reserva de emergência
[44:47] ou consegue guardar coisa sabe o porquê
[44:49] porque a gente aprendeu
[44:51] que ter dinheiro
[44:53] era errado e não que era errado
[44:55] porque é errado ter dinheiro
[44:57] não porque as vezes a gente estava
[44:59] deixando de fazer alguma coisa pra quem a gente amava
[45:01] e aí o nosso subconsciente
[45:03] ele sempre foi escravo dos nossos desejos
[45:05] e das nossas emoções
[45:07] e aí as nossas emoções
[45:09] é sempre querer fazer o que
[45:11] que a gente se sinta bem
[45:13] e aí a gente nunca lida com a frustração
[45:15] e essa frustração nunca lida com
[45:17] realmente
[45:19] algo que você precisa fazer
[45:21] entenda se você é um empresário
[45:23] o dinheiro da sua empresa é da sua empresa
[45:25] lide com contas
[45:29] lide com problemas
[45:31] e automaticamente dentro da própria acende
[45:33] e eu falo isso pra vocês
[45:35] eu cometi esse erro dentro da própria acende
[45:37] e eu nunca misturei o meu dinheiro físico
[45:39] com o meu dinheiro da empresa
[45:41] a partir do momento dentro da acende
[45:43] que eu fiz isso, sabe o que começou a acontecer
[45:45] cara, eu desestabilizei o meu financeiro
[45:47] físico que já era um bagulho
[45:49] muito consolidado
[45:51] e eu desestabilizei o financeiro da empresa
[45:53] e eu falei o que que tá acontecendo
[45:55] porque eu gastava o dinheiro da empresa
[45:57] como se fosse o físico e o físico como se fosse da empresa
[45:59] e aí foi embolando e eu fui, caralho, eu tô sem fluxo de caixa
[46:01] e o meu time foi percebendo isso
[46:06] porque eu fui parando de ter atitudes
[46:08] que eu não tinha mais antes
[46:10] eu fui começando a entender
[46:13] eu fui começando a entender que, caraca
[46:15] se eu não tenho isso, eu não vou fazer isso
[46:17] e aí eu separei completamente
[46:20] e sabe qual que é a maior dor da separação
[46:22] completamente? porque hoje
[46:24] eu não sei se isso me esporta
[46:26] demais
[46:28] deixa eu ver quem tá aqui na col
[46:30] ah, tá só aluno, tá só a gente boa aqui
[46:32] tá só aluno, gente do time
[46:34] cara, hoje o meu custo
[46:36] e físico, Gustavo, físico mensal
[46:38] é
[46:40] um médio ali
[46:42] 30, 35 mil reais mensais
[46:44] inclusive é um custo maior
[46:46] do que da empresa, tá
[46:48] hoje o meu custo físico
[46:50] Gustavo é 30, 35 mil reais
[46:52] só que sabe o que que aconteceu
[46:54] eu sempre consegui
[46:56] pagar o meu custo físico
[46:58] com
[47:00] só a renda passiva que eu tenho
[47:02] então hoje se eu quisesse me aposentar
[47:04] e continuar na minha
[47:06] infância, tá, eu que eu vivo hoje
[47:08] eu conseguiria
[47:10] aí o que começou a acontecer
[47:12] eu comecei a gastar o dinheiro da empresa
[47:14] como se fosse físico e físico como se fosse da empresa
[47:16] sabe o que aconteceu, eu comecei a falta dinheiro
[47:18] mesmo a empresa sendo lucrativo
[47:20] mesmo eu sendo lucrativo, sabe por que? porque eu comecei a fazer besteira
[47:22] comecei a gastar mais dinheiro
[47:24] e olha o que aconteceu, eu tive que
[47:26] você parar, de novo
[47:28] e aí sempre que a gente separa, dói, sabe por que?
[47:30] porque agora, olha que louco isso
[47:32] e eu to falando de uma pessoa que já tem muito
[47:34] dinheiro e tem uma inteligência patrimonial
[47:36] até que relevante
[47:40] começou a falta dinheiro no físico e começou a falta
[47:42] dinheiro na empresa
[47:44] sabe o que eu falei? por os dois, eu falei foda-se
[47:46] eu vou fazer o que preciso ser feito
[47:48] porque senão eu não consigo depois de um tempo
[47:50] deixar o Arthur Rico, por exemplo
[47:52] eu não consigo deixar o Adriano Rico, eu não consigo fazer nada
[47:54] eu não consigo terminar de construir
[47:56] o patrimônio que eu construo na minha pessoa física
[47:58] ao mesmo tempo eu não consigo evoluir as pessoas da minha empresa
[48:00] então eu preciso separar de volta
[48:02] e essa separação dói porque aí você
[48:04] tem um fluxo de caixa instável
[48:06] e aí você diminui o fluxo de caixa dos dois lados
[48:08] e do lado financeiro pessoal
[48:10] você tem um problema financeiro pessoal
[48:12] e do lado da empresa você tem um problema da empresa
[48:14] e isso eu falando de um cara
[48:17] que fatura muito bem e de um cara
[48:19] que já tem um dinheiro do caralho
[48:21] eu to falando isso pra vocês
[48:23] se vocês não separarem as coisas
[48:25] se vocês não forem individualistas
[48:27] cara não importa
[48:29] o quanto a empresa tiver precisando do meu dinheiro físico
[48:31] se não encaixar
[48:34] se não encaixar com o que eu tenho de condições
[48:36] se estiver sobrando tudo bem
[48:38] se não encaixar e se não estiver sobrando
[48:40] eu não vou colocar
[48:42] e não importa quanto meu dinheiro físico ele precise da empresa
[48:44] se não encaixar eu não vou colocar
[48:46] porque eu dividi as duas coisas
[48:48] porque hoje eu tenho sócios, tenho responsabilidades
[48:50] tenho outras coisas pra fazer
[48:52] eu não posso olhar pro Arthur e falar assim
[48:54] Arthur eu vou te deixar rico sendo que
[48:56] eu to gastando o patrimônio dele
[48:58] porque o dinheiro da empresa não é um patrimônio do chefe
[49:00] é o patrimônio
[49:02] eu vou cortar isso e falar que eu sou comunista
[49:04] mas o dinheiro da empresa
[49:06] é o patrimônio de todos os colaboradores
[49:08] e de toda a construção que essa empresa tem
[49:10] você já virou esse conceito
[49:12] que o patrimônio da empresa não é auto patrimônio
[49:16] agora deixa eu te fazer uma pergunta
[49:18] quantas vezes você comprar um hambúrguer com dinheiro da empresa
[49:20] quantas vezes você pagar uma conta física
[49:22] com dinheiro da empresa
[49:24] foda-se, corta a luz
[49:26] se a luz é algo essencial pra eu trabalhar
[49:28] então vai vindo custo da empresa
[49:30] se a internet é algo essencial pra eu trabalhar
[49:32] vai vindo custo da empresa
[49:34] o mida é essencial pra eu trabalhar, não
[49:36] não é
[49:38] eu tenho que me virar, nem isso na minha vida pessoal
[49:40] e várias outras coisas eu tenho que me virar
[49:44] eu tenho que ter pro laborio, eu tenho que ter
[49:46] não sei o que, não sei o que lá, mas você tem que se virar
[49:48] e eu to fazendo essa
[49:50] eu nunca tinha falado isso pro meu time
[49:52] que os dois caixes tinham se confundido
[49:54] cadê o Adriano, o Adriano ta aí
[49:56] ou ele já foi da aula dele lá
[49:58] foi buscar a irmã
[50:00] o Adriano é o único que sabe
[50:02] que os dois caixes tinham conflitado
[50:04] e eu não conto
[50:06] e aí muitas das vezes sabe qual que é a situação que a gente vai passar
[50:08] às vezes a gente vai precisar atrasar uma comissão
[50:10] às vezes a gente vai precisar atrasar um salário
[50:12] às vezes a gente vai precisar atrasar alguma coisa
[50:14] porque você tomou a decisão de ser responsável
[50:16] e tomar a decisão de ser responsável
[50:18] é fazer com que
[50:20] todas as pessoas te odeem
[50:26] a pergunta que eu tenho pra vocês é
[50:28] vocês estão prontos pra ser odiados
[50:30] vocês estão prontos pra ser chamados de estranhos
[50:32] de arrogantes
[50:34] de prepotentes
[50:39] vocês estão prontos pra às vezes
[50:41] ter só o almoço
[50:43] pra construir uma empresa rica
[50:47] quem tiver pronto coloca aí
[50:49] eu to pronto
[50:52] quem tiver pronto de verdade faz esse compromisso
[50:54] consigo mesmo
[50:56] eu to pronto
[50:58] eu to pronto pra separar o meu caixa da empresa
[51:00] completamente do meu caixa pessoal
[51:03] a primeira coisa que você vai estabelecer
[51:05] é um salário pra ti
[51:07] se ela não consegue pagar o seu salário
[51:09] você vai arrumar outro emprego enquanto você toca a sua empresa
[51:11] mas você vai fazer
[51:13] com que o caixa da sua empresa
[51:15] seja 100% independente de você
[51:17] é isso
[51:19] e aí você vai manter esse salário
[51:23] e você vai manter esse padrão de vida merda
[51:25] até que a sua empresa
[51:27] ela fique muito rica
[51:29] até que o dinheiro ele vem em abundância
[51:31] você não faz doação com o dinheiro da empresa
[51:33] você faz doação quando você a pessoa
[51:35] está rico
[51:37] o dinheiro da empresa não é o seu dinheiro
[51:39] repete isso
[51:41] e Arthur
[51:43] você tem que se considerar uma empresa também
[51:45] se você trabalha com a gente aqui você tem que se considerar uma empresa também
[51:47] coloca
[51:49] o dinheiro da empresa não é o meu dinheiro
[51:51] sabe qual que é o único dinheiro que eu aceitei
[51:54] tirar da acende hoje em dia
[51:56] eu pago 20%
[51:58] de comissão pros meus closers
[52:00] eu pago 20%
[52:02] de comissão pra mim fora isso não vou tirar mais nada
[52:04] é o dinheiro que eu tenho
[52:06] e aí eu vou construir fluxo de caixa e eu vou fazer uma empresa rica
[52:08] e é isso
[52:13] ah Gustavo eu ganho um fixo de tanto
[52:15] mas eu ganho comissão
[52:17] então a comissão é o teu salário
[52:19] todo o resto
[52:21] ou ao contrário tu pode pegar o seu fixo
[52:23] e viver com o seu fixo
[52:25] mas a comissão é a construção da sua riqueza
[52:27] então você precisa ter a construção
[52:29] da sua riqueza
[52:31] de verdade mesmo só o antonio
[52:33] e o Thiago falaram que eles estão prontos
[52:38] a maioria não está
[52:42] difícil
[52:44] e aí eu sei que essa aula é sobre
[52:46] como se preparar mentalmente pra trabalhar
[52:48] 8, 10 horas seguidas
[52:53] nada motiva mais do que uma
[52:55] barriga arruncando
[52:57] nada motiva mais do que
[52:59] você que é pai e olhar pro seu filho e falar assim
[53:01] cara eu não sei se eu vou conseguir comprar o leite
[53:03] desse cara aí
[53:05] a fraude desse cara aí
[53:07] nada motiva mais Arthur do que você olhar
[53:09] pra si mesmo e falar assim cara será que
[53:11] eu quero morar aqui pra sempre
[53:13] será que esse é o destino que eu quero ter
[53:15] nada motiva mais que isso
[53:17] o único bom do fundo do poço
[53:23] é que você só tem duas opções
[53:25] você deita e dorma e você escala
[53:27] só que separa
[53:29] e se você criar mentalidade de separar
[53:31] completamente a sua empresa de você
[53:33] meu amigo eu tenho certeza
[53:35] que você pode passar o inferno na tua vida
[53:37] talvez a sua mulher te abandone
[53:39] talvez os seus funcionários te abandone
[53:41] talvez
[53:43] algumas pessoas briguem com você
[53:45] talvez você atrase contas
[53:47] talvez você decepcione pessoas da sua família
[53:49] mas deixa eu falar uma coisa
[53:51] vamos supor que você decepcione todas essas
[53:53] pessoas
[53:55] só que daqui 3 anos
[53:57] você esteja ganhando 1 milhão de reais por mês
[53:59] você acha que é a sua família
[54:02] que ficou decepcionada com você naquele momento
[54:04] ela vai ficar feliz ou triste
[54:08] por você estar conseguindo
[54:10] dar uma mansão pra ela
[54:12] por você estar conseguindo dar um carro
[54:14] por você estar conseguindo fazer várias outras coisas
[54:16] que você precisaria fazer
[54:20] responde pra mim a sua família
[54:22] ela ficará feliz ou triste
[54:24] só que a gente nunca enxerga os 2 anos pra frente
[54:26] a gente enxerga o agora
[54:28] e o agora dói
[54:31] e esse é um desabafo pessoal
[54:33] de alguém que está tendo
[54:35] que reorganizar uma empresa
[54:37] que é bizarramente lucrativo
[54:39] por causa de desorganização pessoal
[54:43] olha que louco
[54:46] Nimoto quando você começou sua empresa ano passado
[54:48] no ano 0 como desenhou quanto você poderia ter gasto
[54:50] ter de gasto pra você
[54:52] ir uma parte pra sua empresa
[54:54] cara sabe qual que foi o problema Diego?
[54:56] eu não desenhei isso
[54:58] o grande problema da Acendi
[55:00] o único gargalo da Acendi foi o controle financeiro
[55:02] não foi lucro
[55:04] não foi operacional
[55:06] não foi
[55:08] nada foi controle financeiro
[55:10] esse foi o único gargalo
[55:12] eu resolvi isso não faz muito tempo
[55:14] eu resolvi isso a
[55:16] 2 meses atrás e 2 meses atrás pra agora
[55:18] tipo assim
[55:20] teve muito impacto nisso
[55:22] só que agora a gente está saudável de novo
[55:24] a gente está começando a ficar saudável de novo
[55:26] e aí Diego
[55:28] é o que eu falo pra você
[55:30] você vai ter que decepcionar pessoas no meio do caminho
[55:32] você vai ter que lidar com as consequências
[55:34] da sua irresponsabilidade do passado
[55:38] isso é ser homem
[55:40] isso é ser mulher isso é ser empreendedor
[55:42] lidar com as consequências
[55:44] por exemplo o exemplo da clínica
[55:46] sabe que é louco?
[55:48] eu tinha um prolabore de 40 mil reais por mês
[55:50] não importava se a gente vendia 800 mil
[55:52] ou se a gente vendia 600
[55:54] ou se a gente vendia 500
[55:56] ou se a gente vendia 400
[55:58] eu tinha um prolabore de 40 mil reais por mês
[56:00] não mudava
[56:02] e aí eu te faço uma pergunta
[56:04] porque que não mudava?
[56:06] porque que as vezes a empresa
[56:08] tinha 2 milhões em caixa
[56:12] e a gente não tirava 1 real dela
[56:14] eu não tenho nada a ver
[56:16] eu só fui realmente
[56:18] liquidar muito dinheiro quando eu vendia a minha parte
[56:20] o dinheiro
[56:22] é da empresa
[56:24] você é literalmente o seu primeiro funcionário
[56:26] e se você
[56:28] cara, quem aqui?
[56:30] já pensou em contratar
[56:32] um BDR
[56:34] ou alguém por comissionamento
[56:36] algum vendedor por comissionamento
[56:38] alguém aqui já pensou?
[56:40] cara, eu gostaria do máximo de respostas
[56:42] possíveis
[56:44] alguém já pensou? o Antônio já pensou
[56:46] o Jefferson já pensou
[56:48] tem 17 pessoas aqui
[56:50] eu quero que o máximo de pessoas responda
[56:52] o Diego Reis já pensou
[56:54] o Gabriel Oliveiro já pensou
[56:56] o Antônio já pensou
[56:58] vai, mais alguém já pensou nisso?
[57:00] fala aí pra mim
[57:02] o Lucas Paulo pensou nisso
[57:04] ele já pensou em contratar alguém por comissionamento
[57:06] beleza, bacana
[57:08] o Edder já pensou
[57:10] geral, o Diego já pensou
[57:12] vamos lá
[57:16] então vamos fazer o seguinte
[57:18] a partir de hoje
[57:20] para de viver
[57:22] do lucro da tua empresa e viver de comissão
[57:24] porque o primeiro funcionário da tua empresa
[57:26] é você, é isso que eu estou fazendo
[57:28] eu tirei meu prolabore completamente e eu vivo só de comissão
[57:30] se você acredita que isso é bom
[57:32] pra alguma pessoa, você tem que experimentar isso por si só
[57:34] e se você não tá rico ainda
[57:36] e se sua empresa não tá rica ainda
[57:38] tira todo o salário da tua empresa
[57:40] e viva de comissão
[57:42] Gustavo, você tá louco? como que eu vou pagar minhas contas?
[57:44] e por que que você tá oferecendo isso pra alguém?
[57:46] se isso daí não serve pra você
[57:51] por que que serviria pra alguém?
[57:53] te perguntando bem sincero
[57:55] se isso não serve pra você
[57:57] por que que serviria pra alguém?
[57:59] por que que essa pessoa teria oportunidade
[58:01] de crescer se nem você tem coragem
[58:03] de arriscar isso no seu negócio?
[58:07] parem de ser froshos
[58:09] parem de ser froshos
[58:11] se você vai contratar alguém
[58:13] só por comissionamento, seja corajoso
[58:15] o suficiente pra falar
[58:17] eu vivo do meu comissionamento
[58:19] hoje, dentro da Acendi, eu vivo do meu comissionamento
[58:21] como closer
[58:25] você tem coragem?
[58:27] você confia em si mesmo? você confia no seu negócio?
[58:29] confia no seu potencial? porque na hora de contratar alguém
[58:31] e falar assim, confia em mim
[58:33] que eu vou fazer com que isso dê certo?
[58:35] você fala, nossa, vai dar certo
[58:37] olha isso, olha a sua prejeção de ganho
[58:40] faz isso
[58:44] eu quero ver, a primeira pessoa que tiver coragem
[58:46] de atrasar conta na vida pessoal
[58:48] de atrasar coisas na vida pessoal
[58:50] de as vezes, meu filho tá numa escola particular
[58:52] e vai ter que ir pra uma pública porque você não bate a minha meta
[58:54] ou isso aqui
[58:56] várias outras coisas que vão acontecendo
[58:58] consequências, conta de luz atrasada
[59:00] um monte de coisa empréstimo
[59:02] cartão estourando, não sei o que na sua vida pessoal
[59:04] só que a sua empresa cada vez crescendo mais
[59:06] você vivendo de comissão
[59:08] eu quero ver, qual de vocês tem coragem?
[59:10] qual de vocês tem peito pra fazer isso?
[59:12] porque se você não tem peito pra fazer isso
[59:14] não oferece isso pra outras pessoas
[59:16] porque você não é digno de ter isso com outras pessoas
[59:20] se você não vive do comissionamento
[59:22] da sua empresa, não oferece isso pra outras pessoas
[59:24] e eu cometi esse mesmo erro
[59:29] que vocês por muito tempo
[59:31] e sabe porque hoje eu consigo falar pra pessoa
[59:33] cara, se você estiver no meu time
[59:35] 100% comissionado, você vai viver
[59:37] sabe por que? porque eu vivo dessa porra
[59:39] e eu provo
[59:44] e aí sim você vai ser foda
[59:46] e aí sim a sua empresa vai te respeitar
[59:48] e aí sim as pessoas que estão ao seu redor
[59:50] vai te respeitar
[59:52] e aí sim você vai conseguir ter um time
[59:54] que performa mesmo sendo 100% comissionado
[59:56] por que?
[59:58] você fez algo que é possível
[60:00] você mostrou que é possível ganhar 10, 15, 20, 30, 40, 50
[60:02] 100 mil reais na porra da tua empresa
[60:04] sem ter um salário fixo
[60:06] agora, se você não consegue fazer isso
[60:08] o processo só, se você sente que você vai
[60:10] passar dificuldades dentro da tua empresa
[60:12] ou dentro do seu dia a dia, fazendo isso
[60:14] cara, não faz isso com as outras pessoas
[60:16] beleza? é uma mensagem dura
[60:20] mas que eu preciso passar para a maioria de vocês
[60:22] fechou?
[60:24] pessoal
[60:26] então
[60:28] só para finalizar esse ponto e ir para o próximo
[60:30] ponto e começar realmente conteúdo técnico
[60:32] tornando-se imparável
[60:34] suportar
[60:36] longas e monótonas jornadas de trabalho
[60:38] é o preço
[60:40] o sofrimento necessário para se transformar
[60:42] no homem ou na mulher que você deseja
[60:44] ser no futuro
[60:49] eu vou falar para vocês uma frase
[60:51] que eu coloquei para mim
[60:53] mesmo
[60:55] o homem que eu quero ser
[60:57] ele só tá a dois anos de distancia
[60:59] trabalhando
[61:01] 12 horas por dia
[61:03] só isso
[61:06] o homem que eu quero me tornar, ele só está
[61:08] a dois anos de distância
[61:10] trabalhando 12 horas por dia
[61:12] só está ali
[61:14] é logo ali, o homem que eu quero ser
[61:16] o homem que eu quero me tornar, o homem que eu acredito
[61:18] que eu tenho um potencial para ser
[61:20] dois anos de distância trabalhando 12 horas por dia, pertinho, vai lá e executa.
[61:28] E todo dia que eu não trabalho 12 horas e todo dia que eu não faço e todo dia que eu não
[61:32] me deito e me orgulho de mim mesmo, eu aumento um dia de distância. Eu aumento dois, três, quatro,
[61:37] cinco dias de distância. O meu está há quatro anos. E é isso. Beleza? Pessoal, tudo ok nessa
[61:48] parte? Tudo ok nessa parte de mentalidade? Vocês conseguiram entender porque a maioria
[61:53] das pessoas elas são pobres e elas continuam pobres. Vocês conseguiram entender que a visão
[61:58] às vezes da sua empresa ela está limitada não por causa da sua empresa, não por causa da sua ideia,
[62:03] não por causa do seu processo, mas por causa de vocês? Vocês conseguiram entender isso?
[62:08] Fez sentido para vocês? Alguém discorda disse que eu falei? A gente tem três minutinhos para
[62:14] discutir isso antes de eu passar para a próxima aula. Tudo ok? Alguém tem alguma dúvida?
[62:19] Algum feedback? Gostaria de ouvir de vocês. Sim, muito sentido. Boa. Deixa até parar de
[62:27] compartilhar para ele já começar a compartilhar a próxima aula daqui a pouco. Olha o Eder ali.
[62:31] Cara, eu fico muito feliz de ver o Eder aqui, sabe? Esse cara eu conheci ele em...
[62:37] Estou tentando lembrar, é KGR po. Lembra que o Pablo Marcel estava fazendo umas paradas de
[62:44] KGR e tudo mais? Olha o Leandrão aí também está aí. Boa. Então cara, eu conheci
[62:49] o Eder e esse cara é tipo assim... Mano, ele não sabe disso, mas ele me aproximou muito de Deus,
[62:54] cara. Muito obrigado, Eder. Você é uma pessoa que todos os lugares que eu passo em alfavílias
[63:00] inteiras... Cara, alfavílias inteiras conhecem o Eder e todo mundo fala a mesma coisa. Cara,
[63:04] às vezes ele não precisava fazer o que ele faz e ele faz de bom grado e ele faz de bom coração
[63:09] para os outros. Às vezes, muitas das vezes sem ganhar nada. Então, Eder, eu quero falar
[63:14] uma coisa para você, mano. Eu aproveito nesse momento que você está aqui. Você é um
[63:18] cara que todos os lugares que você passa, as pessoas sempre têm a mesma percepção de você.
[63:24] Cara, esse cara é incrível. Esse cara é um cara que me ajuda. Esse cara é um cara que ele se
[63:29] entrega mesmo nas coisas que ele faz. Então, parabéns, cara. De verdade, você é o tipo de
[63:33] pessoa que eu admiro, tá? Porque a maioria das pessoas vão admirar, sei lá, um empresário
[63:39] bilionário ou alguma coisa do tipo, eu admiro o teu coração, irmão. De verdade mesmo,
[63:44] é bem suado que eu me sinto até emocionado de falar de tipo. Faz muito tempo que a gente
[63:50] não conversa, mas, cara, eu tenho orgulho de ter te conhecido, de ter sido direcionado em algum
[63:56] momento por você. De verdade, você é incrível, cara. Você se manteve ali e até hoje,
[64:04] pô. Às vezes eu falei com o Davi há uns meses, anos atrás ali. Ele falou,
[64:08] caraca, se conhece o Eder também, conheço. Ele me ajudou nisso naquilo, naquilo
[64:12] que, pô, ele nem pediu nada, ele não me perguntou nada, ele só começou a me ajudar sem
[64:17] eu pedir. E, cara, vocês querem um exemplo de homem generoso? Realmente é esse, cara. Se você
[64:24] está nesse evento e você tem a oportunidade de fazer um network com uma pessoa que não só
[64:28] tem contato com muita gente, mas também tem um coração muito bom e um coração bom de verdade,
[64:33] eu não costumo falar isso, tá? Mas um coração bom de verdade, cara. Chamei o Eder ali,
[64:37] inclusive, mano, eu recomendo demais qualquer oportunidade de negócio que
[64:42] vocês querem e tudo mais, falem com ele que ele provavelmente vai conhecer alguém que vai
[64:45] poder ajudar vocês. Esse cara, de verdade mesmo, ele é incrível. Fechou? Deixa essa homenagem aqui
[64:51] pra você também, Eder. De verdade mesmo, porque eu vejo você aqui, quando você me chamou pra
[64:56] participar da aula, cara, me enchei de orgulho ali, realmente saber que você estava interessado.
[65:01] Fechou? Pessoal, é isso o primeiro ponto que conseguiu entender. Leandrão, você está aqui
[65:07] há horas, pô. Entrou agora? Não, pô, desde oito e, sei lá, oito e pouca. Nice e demais, pô.
[65:14] Tem foi mais. Nice e demais. Então, bora lá. Pessoal, quando a gente fala disso, essa parte
[65:21] de mentalidade, ela é extremamente necessária, tá? Ela foi extremamente necessária. Eu não
[65:28] sei pra vocês, mas pra mim, sempre que eu falo de glória a Deus, irmão, muito bom estar aqui.
[65:34] Valeu, irmão. De verdade mesmo, espero que você aproveite conteúdo que seja
[65:38] proveitoso pra você. Então, essa parte de mentalidade, muitas
[65:43] vezes ela não vai ser algo genérico ou, é, de verdade, eu não acredito que seja um conteúdo,
[65:49] ah, ou tem esse princípio tal, tem aquele princípio outro lá. Não, eu falei sobre coisas que eu
[65:55] realmente acredito que você precisa pra você construir ali pra seguir crescendo. Beleza? Então,
[66:01] eu quero que a maioria das pessoas aqui cresçam, eu quero que a maioria das pessoas cresçam ali e
[66:06] consigam ter um sucesso. Se você discorda de mim ou se eu falei alguma coisa dentro dessa parte
[66:11] de mentalidade, que te ofendeu, que te deixou triste ou alguma coisa do tipo, mil perdões,
[66:16] mas eu falo literalmente o que funciona pra mim e o que funciona pra maioria das pessoas que eu
[66:21] conheço. Fechou? Espero que vocês tenham gostado dessa parte de mentalidade. Vou iniciar a
[66:27] técnica agora. A parte prospectando pra um webinário. Beleza? Pode iniciar a parte técnica, pode
[66:34] mudar o ciclo agora, de motivação pra ação, pode mudar? Tá tudo ok? Sim, bora lá. Bora lá,
[66:43] então galera. Então, vamos de motivação pra ação. Organização de ICP, de nicho e ICP, tá?
[66:51] Vamos lá. Primeiro ponto, tá? Pra quem não sabe e pra quem não conhece e
[66:56] eu vou estar assistindo isso pela primeira vez. Hoje dentro da ACEM a gente tem uma metodologia,
[67:00] uma metodologia de caque zero. Quem precisar e quiser assistir um evento onde eu falo só sobre
[67:06] essa metodologia, a gente vem ao link. Mas a metodologia caque zero, simplificando ela, é a
[67:11] onde a gente convida empresários e ao invés da gente realmente gastar com anúncios online e
[67:17] ao invés da gente gastar dinheiro pra convidar esses empresários e pra fazer venda pra
[67:21] todos, ou seja, Egaocess, B2B ou B2B2C. A gente consegue fazer muito bem isso, que é um modelo de
[67:28] prospección. Qual que foi o insights que eu tive? Eu falei ao invés de convidar um empresário
[67:33] pra uma reunião, eu vou convidar esse empresário pra um evento e se eu convidar ele pra uma,
[67:36] duas horas de evento, eu consigo vender o meu peixe e vender muitos produtos. Porque é
[67:41] muito mais fácil educar alguém que ela precisa de algo em um ambiente onde ela tem
[67:46] várias outras pessoas do que eu realmente tentar vender direto. E a fórmula que a
[67:51] isso foi uma fórmula de graça a gente pegou o telefone ligou e falou oi você está convidado
[67:55] para tal dia tal horário aparecer nesse evento beleza tão simplificando é isso mas a gente
[67:59] tem um evento realmente onde eu falo só sobre isso e quem quiser realmente pode pedir
[68:03] o link ali para o tour que ele manda para vocês o dia ontem mesmo a gente falou sobre
[68:07] isso o artur manda para vocês fechou bora lá pessoal qual que é a primeira coisa
[68:13] que é a mais importante para você estudar e para você criar qualquer evento online
[68:17] para você criar qualquer ali estilo de prospecção o que que é o script o que que é
[68:22] prospecção prospecção é quando você liga para uma pessoa para você convidar
[68:26] prospecção para evento tá é quando você liga para uma pessoa para você convidar para ela
[68:30] participar do seu evento online vamos supor que o leandro ele tem uma empresa de sei lá uma
[68:35] doceria foi ali que ele começou acho que ele começou doceria e confeitaria você não me
[68:39] engano vamos supor que o leandro ele tem uma confeitaria e aí o leandro ele tem essa
[68:43] confeitaria eu ligo para o leandro e fala assim o leandro tudo bem leandro você tem uma
[68:48] confeitaria eu gostaria que você participasse é o leandro você tem uma confeitaria você foi
[68:55] convidado para um evento onde terão outras 50 confeitarias e bla bla bla esse evento vai
[68:59] acontecer online e tal dia e tal horário basicamente o evento o jeito que a gente chama
[69:03] essas pessoas é assim tá ou assim ou pelo whatsapp então vocês não vão precisar
[69:08] gastar em anúncio não vão precisar gastar nada então em uma semana vocês conseguem
[69:12] ver o evento de vocês vocês conseguem realmente fazer com que o evento de vocês
[69:15] funcione e que vocês convidem 10 15 pessoas por dia tem um evento de 100 200 empresários
[69:21] qualificados porque quando eu faço um anúncio vem qualquer pessoa quando eu divulgo no
[69:25] instagram vem qualquer pessoa a gente não sabe quem é qualificado quem não é mesmo tem
[69:29] no formes quando eu seleciono quem eu vou convidar através do google meu negócio
[69:33] através de vários outros sites que a gente pesquisa as empresas o que que eu
[69:37] quero dizer eu consigo selecionar quem eu quero que esteja nesse evento se você é sdr
[69:43] barb d r do nosso time também presta muita atenção nessa aula porque ela vai ser
[69:47] essencial para todo mundo a primeira coisa que a gente faz antes de prospectar o
[69:51] prospectar uma empresa e é uma coisa que a maioria das pessoas erram dentro do meu
[69:56] time também erram mas a gente não pode cobrar isso das pessoas a gente não
[69:59] pode cobrar excelência das pessoas e essa é uma aula para quem quer realmente
[70:03] ter um nível de excelência beleza então você pode pegar a parte desse conteúdo
[70:09] falar gostável sei qual é a parte que eu vou aplicar e vai dar certo vai dar
[70:13] resultado tá se você não aplicar essa primeira parte mas se você aplicar essa
[70:16] primeira parte você vai ser um cara diferente você vai ser uma mulher
[70:19] diferente que vai ter muito mais resultado que as outras pessoas vamos lá organização
[70:24] de nicho e cp qual que é a primeira coisa que eu preciso fazer para fazer um
[70:28] time entender qual que é o empresário quais são os empresários às vezes o
[70:33] nicho ele não necessariamente é somente o o setor ali que a gente vai falar às
[70:41] vezes o nicho é uma região tanto que eu quero fazer um evento aqui em
[70:45] São Paulo inclusive eu vou chamar o éder para a gente fazer esse web
[70:49] na área junto é fazer um evento aqui em São Paulo só com empresas que estão
[70:53] no seu alfabio não setorizar não falar vou falar com confeitaria vou falar com o
[70:58] seu que vou falar com o seu que ou vou falar com confeitaria vou falar com clínica
[71:02] não setorizar só nesse ponto mas setorizar ali pela região chamar todos
[71:06] os empresários enfim dentro dessa parte de nicho ou você setoriza por
[71:11] região ou você setoriza por setor seja uma clínica aí você pode ser mais
[71:16] específica clínica beleza você vou fazer com clínica ou ontológica ou
[71:20] vou fazer com clínica ou ontológica que faz procedimentos estéticos você pode
[71:23] setorizar e quanto maior segmentado mais resultado você vai ter em vendas
[71:27] fechou então beleza a primeira coisa que você precisa fazer para você é
[71:32] começar a prospectar para o seu web na área para você começar a prospectar
[71:36] para o seu evento é você definir ali um produto ou um setor específico que
[71:41] você vai abordar fechou até aqui ok eu preciso dessa explicação para quem não
[71:46] conhece ainda beleza faça uma pesquisa extensa sobre experts do
[71:50] seu próprio nicho deixa eu falar uma coisa para vocês a maior o maior
[71:55] diferencial que eu tenho é o quantidade de horas que eu estudo sobre o nicho que
[72:00] eu estou fazendo evento sobre o nicho que eu estou realmente me propondo a
[72:06] trabalhar com esse nicho alguém aqui já viu fazendo um web na área de
[72:09] corretores de seguros sem nunca ter falado com uma corretora de seguro
[72:12] antes cara algumas pessoas sim ou outras não mas por exemplo eu já falei com
[72:17] corretora de seguro sem nunca ter falado com corretora de seguro e
[72:20] com imobiliária sem nunca ter vendido imóvel sei lá com clínicas eu já tinha
[72:25] uma experiência mas enfim com sei lá é né é empresa de energia solar sem nunca
[72:31] ter visto um painel de energia solar na minha frente com cofeitarias eu já
[72:36] tinha experiência mas enfim com sas sem eu nunca ter tido um produto de
[72:40] tecnologia então eu já conversei com várias empresas e eu já fiz muita
[72:45] venda para essas empresas sem nunca necessariamente ter nenhum resultado
[72:49] de corretora de seguros solve num podcast o cara fez um web na área um dia
[72:54] eu fiz um web na área de loja de carros e esse web na área que eu fiz de loja de
[72:59] carros no final desse web na área todos os donos de loja de carro estavam
[73:03] falando assim cara esse foi o conteúdo mais insano para loja de carros que eu
[73:06] já vi na vida sabe qual que foi o conteúdo que eu peguei sabe qual
[73:10] conteúdo que eu fiz eu associei tá é uma associação então você pega
[73:15] você sabe e você mistura ali com que você realmente é aprendeu com os
[73:21] expert com os sites dentro do nicho então você precisa ter um conhecimento
[73:24] prévio alguém aqui tem conhecimento em marketing alguém tem conhecimento em
[73:27] alguma coisa de vendas ou alguma habilidade específica que você tem muito
[73:31] boa beleza se você tem essa habilidade você já tá meio caminhandada qual
[73:35] que é o outro meio caminhandado entender esse nicho entender as pessoas
[73:38] desse setor entender os empresários do setor e aí qual que é o insight
[73:42] que você deveria fazer primeiro mapear pelo menos 15 vídeos longos ou
[73:49] podcasts de especialistas daquele nicho daquele setor daquela área a gente vive
[73:54] numa geração que ela é totalmente privilegiada vou abrir meu notebook em
[73:58] m aqui e eu vou mostrar para vocês porque que nós somos totalmente
[74:02] privilegiados porque qualquer setor qualquer nicho de empresários que eu
[74:06] for falar hoje em dia se eu for falar com mercados gente se eu for falar
[74:10] com mercados é possível eu vou até fazer isso aqui junto com vocês
[74:15] mergó por de cash
[74:20] donos de mercado olha que isso sei lá ó o segredo de um supermercado familiar
[74:29] 50 minutos uma hora e 21 uma hora esse aqui não o que que tá acontecendo no
[74:37] super supermercado
[74:40] faturamento de 21 não esse aqui não enfim aqui você já acharam quatro conteúdos
[74:46] ali longos pelo menos umas quatro horas de conteúdo aí se você pesquisa como
[74:50] alavancar o meu supermercado estratégia para o meu supermercado e bla bla bla bla
[74:54] e achar um monte de vídeo longos desse é impossível que você não ache 15
[74:57] vídeos longos desse setor específico do setor de supermercado ou do setor
[75:01] que você escolher vocês concordam comigo que hoje a gente é
[75:04] privilegiado 100% por ter ali conseguir ter acesso esse conteúdo certo
[75:11] se a gente é privilegiado por ter acesso esse conteúdo isso é o feedback tá a
[75:16] única pessoa que eu vi seguir esse esse conselho que eu estou dando agora foi
[75:20] o leandro a única eu não vi mais ninguém tá e eu já dei esse conselho
[75:25] várias várias vezes primeiro ponto o que você precisa fazer você pegou
[75:29] aqueles setores aqueles podcasts cara você vai precisar consumir pelo menos
[75:33] 8 horas de conteúdo sobre aquele setor sabe por que porque se eu vejo um
[75:38] expert falando supermercado por mais que meu produto ele não tenha nada a ver com a
[75:41] gondola por mais que meu produto não tenha nada a ver com a gestão de
[75:44] funcionários por mais que meu produto não tenha nada a ver com que eles estão
[75:47] falando o que eu vou fazer eu vou causar uma sensação de familiaridade ou
[75:52] seja a pessoa ela vai entender que eu estou falando do nicho dela porque
[75:55] eu entendo do nicho dela porque eu entendo o que ela está fazendo
[75:59] eu entendo que ela está falando então a primeira coisa antes de você pegar o
[76:03] telefone prospectar e eu quero fazer uma pergunta para vocês todos vocês que já
[76:07] pegaram o telefone para prospectar ou já mandaram mensagem para alguma empresa
[76:11] para marcar uma reunião com elas quanto de vocês consumiram pelo menos
[76:14] 8 horas de podcast 20 horas de conteúdo 30 horas de conteúdo sobre o setor de
[76:20] vocês estão prospectando algum de vocês já fizeram isso ou vocês estão
[76:24] seguindo a manada da nova geração que vai no cloud code e vai no gpt vai
[76:29] falar me faça um resumo sobre esses não precisa ouvir gente real você precisa
[76:35] saber como que a voz como que essa pessoa se comunica você precisa saber como que
[76:39] são os três jeitos você precisa saber como são as expressões porque talvez o
[76:43] cloud code ele vai ignorar o fato de que o cara falou que é engraçado que
[76:47] quinta-feira parece que os funcionários não trabalham e ele ignora
[76:51] isso e às vezes isso é um site que você vai gerar uma conexão com
[76:53] decisoria ele vai falar cara aí na sua empresa você tem a sensação que
[76:57] parece que quinta-feira os funcionários não trabalham são esses pequenos
[77:02] detalhes que vão fazer total diferença são esses pequenos detalhes que vão te
[77:06] fazer uma pessoa excelente então ignora ia na hora de estudar não seja um cara
[77:11] robotizado pelo menos nesse momento use a ia como ferramenta de expansão
[77:16] ferramenta para você tem um arsenal armamento melhor mas não para você ser
[77:22] uma pessoa menos intelectual fechou já tinha pensado isso pedir o cloud para
[77:31] pegar os vídeos e criar um resumo com um ponto de dor sabe quando que eu faço
[77:34] isso depois que eu ouvi todos os podcasts e aí vem esse ponto exemplifique
[77:42] e estude sobre o conteúdo organize os insights de cada experte eu consumo
[77:47] conteúdo passivamente então enquanto eu escuto o podcast eu estou lavando a
[77:51] louça sabe aquelas tarefas que a gente não quer fazer lavar louça lavar roupa
[77:55] é sei lá e no mercado fazer um esteira fazer qualquer coisa que você precisa
[78:00] fazer eu fico escutando especialista sobre o nicho que eu estou atuando
[78:04] então escuto uma hora escuto duas horas que o 8 10 15 20 sabe que eu estou
[78:09] consumindo agora conteúdo de agência cara eu vejo que a maior parte dos
[78:12] caras são burros e a gente é melhor que eles mas assim eu consumo porque
[78:16] às vezes esse cara tem um site que eu posso ajudar meus alunos então
[78:20] eu estudo pra caramba e aí o que eu vou fazer eu vou organizar esses insights
[78:24] de cada experte e aí eu vou gravar ou criar uma aula que eu explico sobre esses
[78:29] insights e aí eu vou criar um notebook em em focado estava mas eu sou um bdr
[78:33] gostava mas eu faço prospecção para que eu vou criar uma aula sobre o
[78:38] nicho que eu estou prospectando cara pra você consumir oito horas de
[78:41] conteúdo eu prefiro muito vocês consumam oito horas de conteúdo
[78:45] antes mesmo de vocês começarem a prospectar porque vocês vão
[78:49] vão ter muita noção sobre o nicho depois que vocês tiverem muita noção
[78:53] sobre o nicho o que vai acontecer vocês vão chegar em alguém vão falar assim
[78:56] ó posso te explicar um pouco sobre esse setor chega em outras pessoas do seu
[79:00] time chega no seu próprio time chega no seu próprio cliente dá uma aula
[79:03] sobre isso e aí sim você usa ia e aí é o que eu usa ia eu vou colocar
[79:10] corretora de seguros imobiliárias deixa eu achar aqui de imobiliárias eu
[79:13] vou mostrar exatamente pra vocês o como que eu organizo isso
[79:17] ó imobiliárias bem vindo ao luxo cara olha que louco isso aqui
[79:24] isso aqui é o meu notebook m aonde eu falo sobre imobiliárias eu fiz um
[79:30] web nário de imobiliária esses dias cadê o davi davi meu só está aí não
[79:36] sei se está aí mas eu fiz um web nário de imobiliárias cara eu
[79:39] assisti esse vídeo aqui eu assisti esse vídeo aqui eu assisti esse
[79:42] vídeo aqui eu assisti esse vídeo aqui esse esse esse esse esse esse
[79:47] esse assiste todos aí depois eu coloquei todos os vídeos que eu assisti
[79:51] todos os vídeos que eu ouvi no cloud e aí eu coloquei aí sim eu coloco
[79:55] quais todos os especialistas que eu mandei aí olha o tanto de especialista
[79:59] diferente que eu mandei só esses certeza e aí ainda tava faltando um porque
[80:04] eu sabia que tava faltando um porque eu ouvi todos e aí eu sabia que tava
[80:07] faltando um que era o dar lan no caso não sei se conhece dar lan e aí eu
[80:11] pedi uns cinco principais em site de cada um sem repetir os outros olha
[80:17] e aí eu não precisava pegar esses insights e ficar lendo o texto sabe por
[80:21] que porque ele falava um site aqui eu li esse site e eu lembrava de toda a fala
[80:26] desse cara e aí durante meu evento sabe qual que foi a sensação nas pessoas
[80:31] da imobiliária foi o que nossa esse cara conhece bastante sobre o nosso
[80:34] mercado mesmo ele nunca tem vendido imóvel tudo que ele tá falando faz
[80:38] muito sentido tudo que ele tá falando encaixa mesmo sem ele ter vendido
[80:42] imóvel sem ter deixado ter deixado claro isso pra gente agora imagina na
[80:46] prospecção que é muito mais fácil imagina na prospecção na hora de você
[80:51] criar um script na hora de você com criar um convite as você vai saber um
[80:56] único detalhe que vai criar um diferencial tão grande que a cara vai
[80:59] falar nossa eu vou participar só por causa disso
[81:01] então não negli não negligência em o estudo não se torna em pessoas menos
[81:08] intelectuais só porque vocês têm tecnologia beleza então a primeira
[81:13] coisa que vocês vão fazer é realmente ouvir oito horas de conteúdo vocês vão
[81:17] colocar essas oito horas de conteúdo no notebook lm que não usa notebook lm eu
[81:20] recomendo pesquisem e usem o notebook lm a partir do notebook lm que vocês
[81:25] utilizarem que vocês pesquisarem aí vocês vão fazer o que ao davi tá aí aí
[81:30] vocês vão fazer o que dentro do notebook lm vocês vão pedir dicas vocês vão
[81:35] pegar questionários vocês vão entender a partir disso vocês vão
[81:38] fazer o que montar um evento montar uma aula alguma coisa que faz muito
[81:41] sentido e aí vai parecer que quando você entrar numa prospecção quando você
[81:47] for entrar numa reunião ou quando você for entrar no evento as pessoas vão falar
[81:50] assim nossa mas como você é tão bom nesse nicho sendo que você não sabia nada
[81:53] dele semana passada estuda e aí a gente vem para a parte do script o seu
[82:02] melhor script e o melhor script que você pode fazer para o convidar alguém
[82:06] pro evento é o próprio evento é o próprio convite o melhor convite que
[82:11] você pode fazer para uma pessoa é o próprio convite quer que eu
[82:14] exemplifique isso vamos lá quando a gente pega a primeira coisa que eu faço
[82:20] tá e eu tenho uma estratégia mas é uma estratégia um pouquinho dar que é uma
[82:24] estratégia que é um pouquinho cara é uma estratégia um pouco proibida tá pra
[82:30] quem faz prospecção testa isso eu vou passar uma estratégia que ela é um
[82:34] pouco proibida que vocês vão chegar no decisor que vocês vão chegar na
[82:37] pessoa ali que está dentro da clínica eu tenho duas estratégias para você
[82:41] chegar no decisor tem algum sdr bdr nosso aqui deixa eu ver se tem algum dos
[82:46] nossos aqui eu acho que não em acho que no meu time tá dormindo essa hora tudo
[82:51] bem o dia de folga deles mas beleza o antonio eu sei que ele prospecta pra
[82:57] evento eu vou te dar essa dica então antonio só eu não sei quem é só eu
[83:00] pô enfim é porque você tá na conta do miti quando a gente coloca isso a
[83:07] gente tem duas estratégias para passar pela secretária nota isso a
[83:10] primeira estratégia que eu já ensinei várias outras vezes eu não vou
[83:14] ensinar ela de novo e eu não quero que vocês utilizem mais ela eu quero que
[83:17] vocês utilizem isso aqui vocês vão ligar pra empresa cara isso aqui é
[83:21] realmente é o beira o anti ético de tão roubado que é isso aqui pra vocês
[83:28] conseguirem agendar pessoas dentro do evento foi tudo bem leandro eu liguei
[83:34] pra confirmar que a empresa de vocês ela tem um convite uma
[83:39] confirmação dentro do nosso evento quinta-feira 19 meia eu quero saber se o
[83:43] decisor realmente vai tá presente se o responsável pela clínica realmente vai
[83:46] tá presente e eu preciso confirmar isso agora consegue me passar pra ele me
[83:51] passar o número dele se não vou ter que cancelar o convite de vocês cara olha
[83:55] que louco isso eu chamo isso de viagem certeza sabe qual que é o viagem
[84:00] certeza é você chamar a pessoa se ligar pro dono da empresa e você
[84:04] ligar pra secretária que seja como se essa pessoa já tivesse sido
[84:08] convidada
[84:10] olha que louco isso quantas coisas a gente fala no dia a dia que a gente marcou e
[84:18] que às vezes a gente nem lembra e alguém lembra a gente mas é menos a gente não
[84:22] lembrando a gente vai lá e faz isso aconteceu comigo esses dias e aí eu
[84:26] falei assim caraca se eu fizer isso numa prospecção e aí eu comecei a
[84:30] testar isso pra marcar reunião e aí leandro olha que engraçado isso eu
[84:34] liguei pra três lides eu falei assim oi tudo bem cara a gente tem uma reunião
[84:37] quarta-feira marcada é deixa eu te fazer uma pergunta tá confirmado
[84:41] aí ele nossa gente tem você não lembra que a gente conversou nossa foi mal
[84:48] esqueci tudo mais a gente pode marcar pra outra horário não sei o que sim tudo
[84:51] bem sabe que louco as pessoas elas nem tinham nada marcado comigo esse é
[84:57] minha estratégica eu tô fazendo pra vender marcar reunião pra caralho sabe
[85:01] que sabe aqueles horários leandro que eu tô sempre aparecendo com uma
[85:05] estratégica que tipo a gente toma no show aí por mim outro não é possível que ele
[85:09] conseguiu uma reunião em tão pouco tempo eu ligo pra pessoa inclusive tem pessoa
[85:13] aqui já recebeu essa ligação oi tudo bem cara tá confirmado nosso bate papo
[85:16] agora que a gente havia marcado quando a gente havia marcado pô tu não lembra
[85:22] que dois meses atrás eu te lentei a gente marcou esse bate papo esse dia de
[85:25] seu horário não então cara de verdade mesmo você marcar você marca ou
[85:32] reunião individual ou para convidar para evento qualquer coisa que você for
[85:34] que resta isso foi tudo bem cara eu tenho uma reunião com o responsável pela
[85:39] empresa que a gente passou aí convidou presencialmente e ele tinha confirmado
[85:43] pra hoje a tarde eu gostaria de saber se ainda tá confirmado pode me passar
[85:48] pro responsável a com quem você iria fazer a falar no que é passar pro
[85:51] responsável que já estava marcado é qual quem é o responsável daí ou quem
[85:57] é o responsável daí no momento a eu é o Carlos então eu tinha uma reunião
[86:02] dos hoje as duas horas eu posso falar com ele rapidinho para bater esse
[86:05] alimento dessa reunião nem existir reunião e é muito louco
[86:11] ah posso fazer posso ligar pra ele para confirmar esse convite nem existia
[86:16] convite estava isso é errado tudo bem se eu não quiser não face mas eu eu
[86:21] testei aqui e validei e tô marcando um monte de reuniões e as pessoas não
[86:24] estão ficando bravas comigo e aí vem um ponto tá porque que eu falo que o
[86:29] convite ao convite gente pra você passar pela secretária é só você fazer esse
[86:33] viagem de confirmação tá então anotado né vocês nunca mais vão ser impedidos
[86:38] pela secretária certo vocês conseguiram em compreender o viagem
[86:42] de confirmação beleza então aí a gente vem pros pontos do convite você
[86:49] elaborou seu evento você elaborou o que você vai fazer no seu evento
[86:52] você elaborou qualquer cronograma do seu evento e aí eu te faço com
[86:55] perguntas e com base nessas perguntas eu quero que você monte o seu script
[87:00] primeiro qual que é o motivo do seu convite o seu evento é algo exclusivo
[87:04] o cara é exclusivo para aquele setor é exclusivo para aquela região você
[87:10] reforçou que você é o responsável por convidar aquela clínica e fazer com
[87:13] que ela que com que aquela clínica ou com que aquela empresa participe do seu
[87:17] evento você é o responsável você colocou isso dentro do telefone
[87:22] gostável sou o responsável pela região de alfavíli e de realmente eu tô
[87:27] responsável pela sua clínica também para confirmar aquele convite que eu fiz
[87:31] aquele convite exclusivo que fizemos exatamente pra você olha como que o
[87:37] próprio convite ele já vira uma cópia você avisou que você vai ter empresas
[87:42] do brasil todo ou daquela região toda ou de todos os setores ou a maioria dos
[87:46] empresários ali naquele setor e que você por mais que existam várias outras
[87:52] empresas que você é o cara que tá responsável pela empresa dele você avisou
[87:56] isso pro seu cliente até agora não falei de um script pronto tô te fazendo
[88:01] perguntas e olha como essas perguntas elas te levam a respostas que fazem com
[88:05] que você tenha uma prospecção ativa muito boa a pessoa que você tá
[88:10] conversando ela tem o poder decisivo para recusar um convite importante
[88:15] vamos supor liguei para uma empresa agora vou cair na tendente ou na
[88:18] secretária certo essa ser essa tendente essa secretária ela tem um poder decisivo
[88:24] para aceitar o recusar esse convite se ela não tem o poder para recusar o que
[88:29] que impede ela de passar o telefone ois você pode recusar esse convite então no
[88:34] nome dele não posso aí então eu preciso realmente falar com ele você
[88:38] prefere que eu te ligo daqui cinco minutos você me manda o whatsapp dele
[88:41] você prefere passar o telefone pra ele o whatsapp qual que fica melhor pra ti
[88:45] qual que é a melhor opção pra mim conversar com ele porque eu não consigo
[88:48] falar pelo whatsapp eu tenho um tempo limitado para realmente conversar com
[88:51] essa pessoa ou você pode recusar o convite no nome dele ou você me passa
[88:54] para essa é responsável para mim conseguir realmente confirmar esse
[88:57] convite ou não ela não tem o poder de decidir pra quem que é o convite que
[89:04] você tá fazendo é pro gestor é pro dono da empresa é pro diretor de rh é
[89:10] para a equipe de marketing para equipe de não ser que cara é pra quem que você tá
[89:14] fazendo esse convite se você entendeu pra quem você tá fazendo esse convite
[89:19] acabou você vai conseguir realmente convidar essa pessoa de maneira
[89:23] eficiente fechou porque você não vai travar na secretária qual que é o tema
[89:28] central do seu evento falando com o empresário sobre o que que a gente vai
[89:32] falar nesse evento cara aí eu te pergunto quando a gente vai explicar o
[89:36] evento pras pessoas quais são os três principais pilares do evento que
[89:40] eu vou apresentar quais são os três principais pilares ou três principais
[89:44] coisas do nicho que mais chamam a atenção Gustavo como que eu vou saber as três
[89:48] principais coisas do nicho que mais chamam a atenção óbvio você não sabe porque
[89:52] você não ouviu os podcasts o conteúdo que eu falei pra você ouvi você só
[89:55] vive de chat gpt porra e aí o cliente te faz uma pergunta você não sabe
[89:59] responder então quais são os três pilares do nicho que mais chamam a
[90:06] atenção aí você fala oi tudo bem eu tô te convidando eu tô aqui
[90:11] vindo aqui porque eu sou responsável pela sua clínica pra falar sobre o evento
[90:16] que vai acontecer na quinta-feira esse evento a gente vai falar sobre
[90:19] prospecção o ebinário e ofertas e eu fui o responsável por realmente falar
[90:26] desse evento pra você é um evento que ajuda na prospecção ajuda você
[90:32] conseguir prospecitar de maneira eficiente no webinar você conscientizar o seu
[90:38] cliente e na oferta você fazer com que ele nunca mais compare com o preço
[90:41] dos outros acabou é difícil eu coloco três pilares eu não preciso decorar em um
[90:48] script porque se eu conheço o nicho eu sempre vou conseguir colocar três pilares
[90:51] aleatório que faz sentido para o meu cliente para o tamanho para qualquer
[90:55] coisa da empresa esse cara quanto tempo você tem para fazer esse convite você
[91:00] limitou o tempo para o seu cliente aceitar ou não com você se limitou o
[91:04] tempo ó oi tudo bem Leandro é o seguinte Leandro eu preciso que você envia
[91:08] esse convite no meu e-mail e você tem até duas horas da tarde para aceitar esse
[91:11] convite pelo e-mail beleza eu vou te enviar o convite pelo e-mail eu preciso
[91:15] que você aceite se não você não vai ter ali realmente esse convite em poder
[91:19] em mãos cara que que eu vou causar no Leandro não eu preciso realmente
[91:26] aceitar esse convite eu preciso aceitar esse convite no meu e-mail até
[91:30] duas da tarde você limitou o tempo você limitou o tempo que ele tem que
[91:34] te dar uma resposta você só aceitou sim para os bdrs que estão
[91:38] para as pessoas que prospectam que estão assistindo vocês aceitam só o
[91:41] sim do seu cliente ou vocês limitam o tempo que ele tem que aceitar o seu
[91:44] convite dentro do google agendas se você não limita o tempo que o seu cliente
[91:48] tem que aceitar o convite dentro do google agendas ele não está nem
[91:51] compromissado com você nem você com ele acabou a gente está gerando
[91:56] compromisso quantas pessoas que vão nesse evento oi teremos 50 empresários
[92:00] com como você nesse evento teremos 80 empresários como você nesse
[92:05] evento desse setor em específico ó nessa região de alfaville e aí se você
[92:10] tiver prospectando por região você pode citar o nome das empresas que já
[92:14] aceitaram a empresa do Leandro já acertou a empresa do Jefferson já aceitou a
[92:19] empresa do eder do lucas do sei lá o antonio já aceitaram participar
[92:25] dentro da sua região então a gente vai ter mais 50 empresários e
[92:30] realmente a gente quer que a sua presença também seja importante
[92:35] sua presença se eu utilizou esse recurso de efeito manada de autoridade
[92:39] por efeito manada eu não preciso nem falar que eu sou
[92:41] e se eu falo que eu tenho um sem outras empresas e eu começo a aceitar
[92:46] empresas da região dele que aceitaram ir eu já criou autoridade
[92:52] instantaneamente caraca todo mundo que está ali dentro desse evento é todo
[92:57] mundo que está aqui da minha região ele citou várias pessoas que aceitaram
[93:00] esse convite e cada pessoa que aceita esse convite cara começa a notar o
[93:03] nome olha que louco isso daí é cavalo de troia se você pega uma empresa e uma
[93:08] empresa dessa região ela aceita um convite para participar de um evento seu
[93:11] você usa isso como cavalo de troia porque você sempre começa você sempre se
[93:16] esforça mais para conseguir a principal empresa aquela empresa que você sabe que
[93:20] a maior da cidade que você está prospectando se você consegue aquela
[93:23] empresa você usa ela de referência para convidar todas as outras empresas
[93:26] inclusive essa outra empresa ela vai estar aqui também você conhece eles
[93:30] inclusive essa outra também vai estar essa outra também vai estar essa
[93:33] outra também vai estar você conhece eles conhece eles aceitaram convite eles vão
[93:36] participar você vai participar qualquer qualquer sensação que eu causa nisso e
[93:44] eu fiz de propósito essa aula de script próprio para convite porque eu não
[93:48] vim aqui com um monte de script pronto vocês perceberam que eu não vim com
[93:51] um script pronto porque esse mapa mental é justamente para vocês pensarem
[93:57] nisso é justamente para vocês pensarem no convite é justamente para
[94:01] vocês pensarem para vocês estudarem eu tô cansado de pessoas que não estudam
[94:06] que não fazem as coisas por si só isso daí é realmente você assumir a
[94:13] responsabilidade é você ser um profissional de excelência e aí volta
[94:16] com o que a gente falou de mentalidade então só essa parte que de verdade só
[94:22] essa parte de viés de certeza se você entendeu isso aqui eu te garanto você
[94:27] vai marcar mais reuniões que todo mundo alguém aqui já tinha ouvido falar
[94:30] disso de viés de certeza eu tenho certeza que eu sou a primeira
[94:33] pessoa a falar de prospecção de outbound com viés de certeza e olha que louco
[94:39] isso eu uso esse viés de certeza nas minhas reuniões inconscientemente e aí eu
[94:43] percebi isso e aí eu falei assim cara isso serve para a prospecção ainda não
[94:49] fazer isso não cara eu acho que a maioria das pessoas não ouviu falar disso e
[94:53] agora que eu comecei a falar disso vai todo mundo falar ó viés de
[94:56] certeza você tem que falar com o dono como se tivesse assim blá blá blá blá
[95:00] blá blá blá e aí eu vou falar uma coisa para vocês sabe qual que é
[95:04] porque que eu trouxe essas perguntas e não script pronto porque o script qualquer
[95:08] idiota pode copiar porque o script qualquer pessoa pode começar a fazer e aí
[95:14] elas vão começar a admitar e aí as empresárias vão saturar disso e aí
[95:18] vai parar de funcionar e você vai fazer o que agora se eu te trago as
[95:21] perguntas para que você consiga desenvolver as suas próprias coisas eu
[95:24] consigo fazer com que você sempre esteja no oceano azul não importa se
[95:28] eu estava vendendo em 2019 eu só estou vendendo hoje aqui em 2026 eu
[95:33] estou no oceano azul porque quem faz as perguntas e quem entende o meu
[95:37] cliente sou eu não são terceiros essa que é uma aula para te ensinar
[95:42] prospectar eu estou te ensinando a prospectar eu não estou te passando
[95:47] script de prospecção porque senão isso seria uma aula de script de
[95:50] prospecção o script de prospecção validado para você prospectar não é
[95:55] uma aula para te ensinar a prospectar beleza todo mundo entendeu alguma
[96:01] coisa que agora quando você fala com o gestor da empresa você diz como se
[96:07] já estivesse agendado ou só usa isso para passar pela secretária cara tanto faz
[96:11] porque se eu chegar no gestor da empresa ou Leandro você lembra que há 3 meses
[96:16] atrás alguém te ligou ali e perguntou se você queria participar desse evento
[96:19] que vai acontecer semana que vem pô não lembro cara posso te explicar
[96:24] novamente para que você refresca memória e eu explico e eu faço convite
[96:28] não importa sabe assim não tem problema qualquer coisa que você fala ali não tem
[96:34] problema e aí vem um ponto que eu vou até pular uma parte da aula mas só
[96:39] para falar essa frase aqui ó eu não sei se eu coloquei ela aqui não coloquei
[96:43] ela que droga não coloquei essa frase mas eu vou colocar essa frase aqui para
[96:48] vocês agora que é qualquer objeção que surge é falta de uma
[96:54] narrativa bem controlada qualquer objeção que você tem é falta de uma
[96:59] narrativa bem controlada porque todas objeções elas se tornam ali coisas
[97:03] vantagens estava eu não tenho dinheiro cara e bom é exatamente isso para você
[97:07] até quando você pretende ficar sem dinheiro
[97:10] Gustavo eu não tenho isso beleza isso aqui é para você até quando você
[97:13] pretende ficar sem tempo toda objeção é falta de uma narrativa
[97:19] bem contada beleza então confirmando presença há uma coisa que você
[97:24] precisa fazer foi eu te ensinei a chegar num decisório de ensinei a
[97:27] prospectar de ensinei como que você vai fazer esse convite agora você precisa
[97:31] pensar no seu script pensa no seu script individualmente artura eu não
[97:34] quero ver você marcando menos de 12 por dia a partir semana que vem como que
[97:39] você confirmar presença primeira coisa calendário
[97:43] calendário as pessoas elas precisam receber essa notificação não
[97:47] importa quantas mensagens você manda no whatsapp elas precisam receber a
[97:50] notificação ó vamos lá
[97:54] dentro daqui do calendário é porque eu acho que o time atrasou um pouquinho para
[97:57] mandar mensagem por exemplo o gabriel aqui o gabriel aceitou o convite para
[98:03] participar do evento de hoje quando gabriel aceita o convite para
[98:06] participar do evento de hoje que começa a fazer o gomit começa a
[98:09] avisar então se eu pego por exemplo o evento kq zero aqui ó convidados 13
[98:15] convidados ó meu time ele tem ele errou muito nisso tá ele errou muito
[98:19] nisso porque olha olha o tanto de convidado e as pessoas não confirmando
[98:23] a presença sabe o que acontece as pessoas elas não vão receber na
[98:27] notificação essa notificação não vai cair no de 10 em 10 minutos de 20 20
[98:31] minutos de 30 em 30 minutos e aí essa notificação não faz com que essas
[98:34] pessoas elas cheguem a reunião e dentro do google próprio google ele tem
[98:40] prioridade na notificação do seu celular sabia quem aqui tem um google
[98:43] calendário google agendas dentro do seu celular você percebe que quando
[98:47] tem notificação que a sua reunião vai começar o que você tem reunião
[98:49] da que 10 15 20 40 minutos ele às vezes toca uma notificação mesmo quando seu
[98:55] celular tá silenciado o google ele tem prioridade nisso porque ele entende que
[98:58] se está na sua agenda é um compromisso e aí nas coisas que você aceita você
[99:03] só consegue é realmente desativar essa notificação do google calendar se
[99:07] você for ali nas configurações e desativar
[99:09] unicamente a notificação do google calendar senão ele sempre vai ficar
[99:13] te avisando deixa eu falar uma coisa você não consegue mandar 300
[99:17] mensagens para o seu cliente confirmando se ele vai no evento ou não mas você
[99:20] consegue tá consegue mandar 300 notificações sem ser ele se
[99:26] incomodar por ó lembrando que amanhã teremos o evento
[99:29] cá que zero e aí o próprio google mandando pra ele lembrando que daqui 40
[99:33] minutos começa eu começará o evento lembrando que você tem um
[99:36] compromisso em 30 minutos cara você não aceitar o convite sabe a parte que
[99:41] eu falei ó preciso que você confirme no teu e-mail que você aceitou esse
[99:44] convite você não aceitar e você não ter isso no seu e-mail vai fazer com que o
[99:50] seu cliente ele tenha muito menos nutrição para ele aparecer no seu
[99:53] evento para ele aparecer numa reunião para ele aparecer seja lá o que for do que
[100:00] você teria antes aí você vai precisar fazer muito mais mensagem você vai
[100:03] precisar fazer muito mais ligação para você fazer ter menos resultado do que
[100:07] uma pessoa que simplesmente confia o morro ali uma agenda fechou
[100:13] Leandro quantas vezes você esqueceu que você tinha uma reunião e aí às vezes o
[100:16] google calender ele notificou pra tu e tu lembrou que tu tinha uma reunião já
[100:19] aconteceu isso contigo cara comigo acontece todo dia todo dia tipo é três
[100:25] vezes ali antes da reunião ele manda notificação e às vezes te avisaram
[100:29] no WhatsApp e mesmo assim você não tinha visto certo
[100:32] um exato olha que louco olha que louco isso então gente as pessoas estão no
[100:37] celular o tempo todo você precisa você precisa que você seja notificado eu
[100:42] não tô falando você comprar uma ferramenta não tô falando você pagar
[100:44] alguma coisa e eu tô falando uma coisa tão óbvia eu tô insistindo tanto nisso
[100:48] porque eu sei que a maioria das pessoas não fazem isso não tratam como
[100:50] importante uma coisa que vai fazer uma nutrição que vai confirmar uma pessoa
[100:54] dentro de um evento seu que vai confirmar uma pessoa dentro de algo que
[100:57] elas vão comprar de vocês só que você não faz isso ontem entrei numa
[101:05] cópia foi lembrado por o ati exatamente então às vezes vai ser
[101:09] lembrado pelo WhatsApp às vezes vai ser lembrado pelo calendário às vezes
[101:12] você vai ser lembrado por vários outros meios mas você precisa você precisa
[101:18] ser lembrado e aí porque que a gente precisa ter o número do decisor porque
[101:23] que eu preciso ter o número do decisório não da empresa
[101:25] vamos supor o cara confirmou o evento comigo eu pego o e-mail de quem eu
[101:30] falo assim por qual e-mail você vai entrar porque eu preciso enviar esse
[101:33] e-mail especificamente para quem vai entrar porque a sua vaga ela vai estar
[101:36] associada esse meio então esse meio que será aceito dentro do evento
[101:41] qual que é o seu número de WhatsApp para que a gente envia a sua
[101:44] confirmação e o seu código dentro desse dentro desse número não pode ser o
[101:48] número da empresa a gente precisa do seu número para que esse convite ele seja
[101:51] mais personalizado envia um código cara não tem um código para que que eu
[101:55] vou enviar um código só para a pessoa ter a percepção em ser usar isso de
[101:58] argumento para você ter um é para essa pessoa ela sentir que ela está sendo
[102:02] realmente especial que ela está sim que ela está sendo convidada de maneira
[102:05] especial então qual que é o número do decisor qual que é o calendário e você
[102:11] aceitou você pegou o e-mail você pegou o número você está fazendo
[102:14] nutrição você envia um código é realmente individual para essa pessoa
[102:19] cara se sim a coisa que você tem que fazer tá é trazer um môpa
[102:30] tá tá tá tá tá tá bom se sim a coisa que você tem que fazer é
[102:36] somente garantir com que essa pessoa apareça no seu evento você já
[102:38] sabe que mais difícil você convenceu ela aparecer no seu evento agora você
[102:42] precisa lembrar ela o tempo todo que ela se comprometeu com você aparecer nesse
[102:45] evento fechou então aqui eu coloco três coisas eu não escrevo um monte de
[102:50] texto porque eu quero que você sprinte a tela e vocês coloquem cara o meu
[102:53] decisor um convite ele só é um convite de fato quando alguém aceitou o
[102:56] convite dentro do e-mail quando o número do decisor o número do decisor e não
[103:01] da empresa está em contato comigo porque ele as pessoas elas respondem
[103:04] pessoal mas não respondem o WhatsApp da empresa quando eu envio um código
[103:08] individual esse cara confirmou que ele pegou o código dele que esse código foi
[103:13] feito pra empresa dele acabou velho olha como se torna algo personalizado porque
[103:17] a gente está convidando uma empresa que nunca ouviu falar da gente e quanto mais
[103:21] profissional a gente é mais exclusiva essa empresa sente e ela vai falar assim
[103:24] caraca mano olha esses caras aqui como que eu não conheci eles antes que
[103:28] doideira beleza até aqui tudo ok tão conseguindo compreender tão conseguindo
[103:36] entender tá fazendo sentido alguma dúvida se tiver se houver dúvidas ali vocês
[103:42] podem me perguntar podem falar ali que aí eu realmente vou tirando essas dúvidas
[103:46] de vocês fechou tudo ok por hora beleza bora lá vamos pro próximo ponto tá
[103:54] quebrando objeções que tem dificuldade quebrar objeção cara eu vou eu tenho uma
[104:02] metodologia de quebra de objeções e aí eu peguei alguns frameworks ali que
[104:06] realmente se baseiam nessa metodologia que eu tenho pra trazê-la pra vocês fechou
[104:11] então eu vou trazer essa metodologia dos 3a tá que essa metodologia que ela
[104:16] vem do ormose pra vocês terem ideia e aí eu adaptei ela com a minha linguagem
[104:20] com as coisas que eu acredito pra dentro de uma prospecção dentro de uma
[104:23] prospecções pra que vocês possam quebrar objeções dos seus clientes fechou
[104:27] então bora lá pessoal depois disso e depois disso aqui o cara ele só não vai
[104:32] participar se realmente você errar em alguma das coisas ou se ele tiver ocupado
[104:36] no dia beleza porque se você fizer e seguir todas as etapas que eu passei até
[104:41] agora um dia eu e o adreano a gente quebrou um recorde de prospecção eu e
[104:46] o adreano a gente conseguiu enviar 200 convites em um único dia cara esse
[104:50] é louco a gente chamou o time inteiro a gente fala assim eu e o adreano sozinhos
[104:55] a gente vence todos vocês sabe que a gente fez eu ligava para as empresas eu
[105:00] convidava elas o adreano e a confirmando a presença pelo whatsapp e a gente fez
[105:04] isso e a gente chegou a 200 convites inclusive a gente podia fazer outra
[105:07] competição dessa dentro da empresa né essa é muito bacana mas enfim a gente
[105:11] fez isso sabe porque eu conseguia fazer vários convites sabe por que minhas
[105:15] ligações elas não eram desperdiçadas porque toda objeção que o meu
[105:19] cliente dava eu conseguia contornar então eu sou muito bom em quebrar objeção
[105:23] por mais que eu seja totalmente a favor de você adiantar as objeções que o seu
[105:26] cliente pode ter se o cliente ele me mandar objeção e eu quiser forçar ele a
[105:31] comprar inclusive eu fali uma empresa sim tá a gente tinha a gente vendia tanto
[105:36] que eu conseguia vender para qualquer pessoa e aí esse nessa de vender para
[105:41] qualquer pessoa eu fiz merda e nessa merda que eu fiz de vender para
[105:44] qualquer pessoa a gente foi tendo um monte de cliente ruim aí foi o
[105:47] operacional estragou a gente vendia muito mas era sempre uma loucura sabe então
[105:52] cara eu sou muito bom em quebrar objeção se eu quiser forçar alguém a
[105:56] comprar alguma coisa eu vou forçar essa pessoa porque não porque eu sei que essa
[106:01] pessoa gostava porque ser um gênio e tudo mais não eu vou fazer essa pessoa
[106:05] fazer o que ela tem na conta de entrada vou fazer não sei o que porque eu
[106:08] consigo fazer isso mas eu não faço hoje em dia porque não vai a favor dos
[106:13] meus princípios porque vai me dar muito mais problema do que não ter
[106:16] problema então eu estou ensinando vocês a quebrar objeções não é para vocês
[106:20] fazerem qualquer venda e venderem a qualquer custo eu tô fazendo ensinando
[106:24] vocês a quebrarem objeções para que as pessoas entrem dentro do seu evento e
[106:28] para que você venda para as pessoas certas ok estamos combinados quanto a
[106:31] isso porque na aula de closer vocês vão aprender algumas coisas que vocês
[106:35] podem utilizar sim para coisas ruins mas assim de verdade mesmo não
[106:40] compensa porque vocês vão ganhar e ter muito mais resultado usando para
[106:44] encontrar coisas boas fechou eu nem gosto muito de abrir isso publicamente
[106:49] porque eu acho que existe o conteúdo de vendas e existe o conteúdo de
[106:54] persuasão e o conteúdo de persuasão ele beira a manipulação e a manipulação
[106:59] cara é algo que estraga a vida das pessoas então vamos lá como que você
[107:04] contorna qualquer objeção a primeiro passo que todo mundo quando recebe
[107:08] qualquer objeção é falar pô eu não tenho esse problema que aí a
[107:11] pessoa tem sim mas tem esse outro que a pessoa fica tentando fazer o que ela
[107:16] fica tentando contornar ela fica tentando bater de frente se eu falo para você
[107:21] nossa isso aqui tá caro e aí você fala não não tá caro aí ou você vem com
[107:26] aquelas com aquelas frases ali que você decorou gente não decora em frases tá
[107:32] não decora em frases não decora em scripts sejam bons o suficiente para
[107:37] as pessoas decorem as suas frases os seus scripts porque se você for muito bom
[107:42] e você entender o conteúdo técnico você entender como fazer você não precisa
[107:46] decorar frase porque ela vai vir instantaneamente dentro da sua cabeça
[107:49] a primeira coisa que eu faço quando uma pessoa ela me entrega uma objeção não
[107:56] é conflitar não é rebater não não tá caro não não é isso não não é
[108:00] aquilo ou não você tem tempo sim você só não tá enxergando porque isso
[108:05] vai bater diretamente com uma crença isso daí eu vou bater diretamente com
[108:10] algo que essa pessoa acredita e aí eu vou fazer o que agora não sou eu e ela em
[108:15] busca de um caminho melhor para a empresa dela em busca de alguma venda ou algum
[108:19] produto melhor ou alguma coisa que vai resolver a vida dela agora sou eu
[108:22] contra ela se eu faço isso e eu não posso fazer isso e aí o que eu faço o
[108:27] primeiro passo não é rebater a objeção mas sim repetir ou resumir o
[108:32] que a pessoa acabou de falar ou seja reconhecer eu cheguei numa cliente ela
[108:39] falou assim gostava eu tô realmente sem tempo e eu falei cara eu entendo isso hoje
[108:45] qual que é o motivo pelo qual você está sem tempo vocês percebem que eu
[108:50] não comecei nem quebrar objeção mas a pessoa ela se tornou muito mais minha
[108:54] amiga ela se tornou muito mais próxima de mim então o primeiro passo para você
[108:58] quebrar qualquer objeção é você reconhecer porque que isso funciona faz
[109:02] os dois grandes benefícios faz dois grandes benefícios imediatos tá o primeiro
[109:07] faz com que o cliente se sinta que você está ouvindo ativamente o que
[109:11] constrói conexão ou seja lembra que eu falei e se eu pego e eu falo assim cara eu
[109:18] entendo que você está sem tempo hoje qual que está sendo a principal causa
[109:21] que você está sem tempo essa pessoa ela tem a sensação que eu tô
[109:25] combatendo ela o que eu tô querendo ouvir ela o que eu tô atentamente
[109:29] com atenção nela obviamente eu gero conexão com a pessoa fazendo isso
[109:34] segundo ponto e mais importante para você comprar algum segundo de tempo para o
[109:40] seu cego processar qual qual que é a melhor resposta qual que é a melhor
[109:44] solução sabe quando eu vou quebrar objeções vocês nunca veio com frase
[109:48] pronta porque porque a frase pronta ela te impede de fazer uma coisa que você
[109:53] tem vantagem durante uma reunião durante uma negociação sabe qualquer
[109:58] essa vantagem que você perde é literalmente a capacidade de adaptar o
[110:04] seu conhecimento e a solução para esse cliente para aquela para o próprio
[110:10] cliente para realmente algo que ele traz teve um cliente meu que eu quebrei
[110:16] todas as objeções dele olha que louca esses dias eu fiz mais reunião o cliente
[110:20] ele mentiu para mim tá eu quebrei todas as objeções dele e ele olhou
[110:24] para mim ele fala assim gostava posso ser sincero com você inclusive ele está
[110:27] aqui agora ele falou gostava posso ser sincero com você eu menti para tipo eu
[110:33] não faturo isso eu não faço isso nem isso nem isso nem isso nem isso por isso que
[110:37] eu não vou comprar de você agora falei tudo bem mas eu quero te ajudar e aí ele
[110:41] comprou essa essa esse convite por 47 reais mas eu quebrei tantas objeções
[110:46] desse cara que e eu não fiz isso de uma forma agressiva que ele não inventou
[110:51] desculpa ao invés de inventar desculpa sabe o que ele foi comigo ele foi
[110:54] sincero que ele não tinha dinheiro realmente para comprar de mim quanto de
[111:00] vocês recebem uma desculpa de um cliente de vocês que dá uma pequena
[111:03] desculpa e some do nada
[111:06] aconteceu isso com algum de vocês se acontece isso com vocês é porque ele não
[111:10] confia o suficiente para desabafar o real motivo pelo qual ele não está comprando
[111:13] você naquele momento e aí vem um ponto tá a associar essa é a parte
[111:20] onde ocorre a mágica persuasiva você deve associar a objeção ou
[111:23] pergunta a um o pergunta do cliente a um comportamento positivo a um cliente de
[111:29] sucesso ou uma figura de autoridade que reduzirá as defesas dele
[111:33] ou seja associação positiva vou ler isso aqui para depois eu explicar isso com de
[111:37] maneira mais calma associação positiva quando ele trouxe uma dúvida você
[111:41] diz essa é uma pergunta excelente na verdade bababá quando vou ler isso aqui
[111:45] não eu vou falar aqui vou dar aula para vocês depois vocês lê um mapa
[111:48] mental porque eu não sou aquele cara que decora as coisas e nem que ler as
[111:52] coisas eu prefiro realmente trazer para vocês uma solução alguns pontos que
[111:57] você pode trazer para essa quebra de objeção cara eu te entendo
[112:02] te entendo perfeitamente e aí eu faço aquela pergunta reconheço o problema
[112:05] dele eu ganhei um tempo que que eu posso fazer nesse tempo eu posso ou
[112:09] associar ele com uma pessoa de sucesso que ele tem referência ou um case de
[112:12] sucesso meu posso falar ó eu tenho caso do jorge que é o caso que ele
[112:16] passava exatamente pelo menos um problema que você tem um caso do
[112:19] calil tem um caso da vi que ele passava exatamente esse mesmo problema que
[112:22] você aconteceu isso isso isso e a grande solução foi essa e ele teve que tomar
[112:27] uma decisão importante porque às vezes eu vou precisar fazer uma crítica tá para
[112:30] o meu cliente você sabe como que você faz uma crítica para o seu cliente sem
[112:34] necessariamente ofender ele por exemplo você sabe que seu cliente não está
[112:39] fazendo as coisas porque ele é vagabundo ou ele não vai comprar de
[112:42] você porque ele sabe que ele é vagabundo e não vai executar ou
[112:45] alguma coisa do tipo aí sabe como que você faz uma crítica ser realmente
[112:50] espelha espelha tudo que você está identificando nele em outra pessoa
[112:54] o leandro cara tinha esse mesmo problema com o leandro o leandro ele é ficava o
[112:59] dia inteiro corrido ele falava que não tinha tempo nem nada do tipo qual foi a
[113:03] primeira coisa que a gente fez a gente organizou o dia dele depois que a gente
[113:06] organizou o dia dele a gente viu que ele realmente tinha tempo para fazer
[113:09] isso aqui só que aí entrou em outra barreira porque era difícil para o
[113:13] leandro ficar fazendo isso ele não gostava e era um monte de outra eu
[113:16] percebi a objeção que estou fazendo eu estou espelhando a objeção dele no
[113:19] leandro e aí fica muito mais fácil falar a solução sem bater nele diretamente
[113:24] porque se eu falo de outra pessoa e essa pessoa se conecta logo essa pessoa
[113:29] ela entende que ela tem um problema e ela tem uma solução e ela concorda
[113:32] que pode ser uma solução para o problema dela agora se eu falo isso
[113:35] diretamente polêndo então é um vagabundo mas tu é desorganizado tu não
[113:40] sei o que você vai eu vou falar um monte de coisa a qualquer sensação que o leandro
[113:44] vai ter porra vai usar falar sim tá tchau mano obrigado pela apresentação
[113:49] aí cara fica até triste mas às vezes eu vejo os closers quebrando objeção o
[113:54] cliente ele não sai da reunião feliz ele sai triste porque o closer humilhou o
[113:58] cara isso não é cara isso daí não é venda não tá não esquecem esquecem
[114:03] esses caras por da internet que vão falar de venda em qual que vão falar
[114:07] de processo comercial agressivo o melhor processo comercial é o que o cliente
[114:11] ele compra de ti sorrindo que ele abre o bolso ele compra de ti sorrindo e ele
[114:16] sai feliz então primeiro passo você bota pressão você bota pressão mas você
[114:21] bota uma pressão que o seu cliente ele fala assim caraca que conquista eu
[114:24] tenho comprado isso dessa pessoa então primeiro eu reconheço depois eu
[114:29] associo e associar não necessariamente precisa ser só você
[114:35] associar a uma pessoa tá a uma pessoa em específico a um case de sucesso seu você
[114:41] pode associar isso a outros clientes ou uma situação genérica cara leandro você
[114:46] sabia que a maior parte dos meus bons clientes eles tiveram esse mesmo
[114:51] problema financeiro no início que você tem sabe que a maior parte dos meus
[114:57] clientes e a melhor os melhores clientes as pessoas que mais têm sucesso elas
[115:01] têm essa mesma dúvida que você eles têm esse mesmo receio que você olha o que
[115:06] eu tô fazendo eu tô elogiando as pessoas e eu tô falando que ele igual essas
[115:10] pessoas de foda e que essas pessoas elas têm isso também e até mesmo e aí eu
[115:19] vou para o próximo passo e aqui eu posso construir eu posso construir uma
[115:22] resposta onde eu vou contornar isso beleza então tem como se contornar
[115:26] objeções tem como você fazer isso só que a última coisa que você
[115:30] precisa fazer é pergunta eu não chego afirmando um monte de coisa eu posso
[115:35] contar a história de como resolve eu posso falar que a pergunta maravilhosa que a
[115:38] maioria das pessoas tem problema e como que elas resolvem esse problema mas eu
[115:42] não posso deixar de fazer perguntas para que o leandro quebra a objeção dele
[115:47] anota isso não sou eu que quebra a objeção do meu cliente o meu
[115:50] cliente que quebra a própria objeção não sou eu que resolvo os
[115:55] problemas do meu cliente na hora de comprar tá na hora de finalizar uma
[115:59] compra quem resolve é os problemas do cliente para comprar é o próprio
[116:03] cliente então o que eu faço quem faz as perguntas está no controle da
[116:07] conversa esses dias eu estava numa reunião e aí um cara ele abriu ele
[116:14] queria me vendo uma ideia ele abriu uma ferramenta que transcrevia a reunião em
[116:20] tempo real e ele lia uma resposta de yaman eu achei bizarramente ruim tá
[116:24] quem sabe de qual ferramenta eu tô falando já sabe o que eu tô
[116:28] falando mas o cara ele abriu uma ferramenta essa ferramenta me escutava e
[116:32] aí com a partir da minha resposta e a dava uma resposta pra ele ele ficava lendo tá
[116:36] ele nossa interessante seu ponto e aí ele falava igualzinho meia mano muito
[116:39] engraçado foi essa reunião e aí chegou no momento que a própria abogou porque
[116:45] cara eu sou muito bom em fazer pergunta e aí ele começou a fazer umas
[116:51] respostas tão difíceis e eu consegui levar a idade ele fazer ela lucinar
[116:55] tanto que eu peguei e falei pra ele no momento cara eu sei que você está
[116:58] usando meia para de usar isso deixa eu ver quem você realmente é e aí o cara
[117:04] deslanchou ali por aí acabou que ele queria me ver um negócio que vende pra ele
[117:08] o que que acontece tá o que que acontece quem faz a pergunta vai dominar a
[117:12] reunião quem faz a pergunta vai dominar aquele processo de reunião quem
[117:17] faz a pergunta tem o controle da conversa então você reconheceu você
[117:21] associou com algo positivo e qual que é o próximo passo perguntar
[117:27] Leandro você falou que não tem tempo
[117:30] tá você falou que não tem tempo Leandro deixa eu deixa eu entender e eu uso a
[117:36] associação e tudo mais Leandro deixa eu entender eu te falei algumas soluções
[117:39] falei alguns casos ali que aconteceram mas eu quero ouvir de você o que que eu
[117:43] poderia fazer para ajudar você a ter mais tempo o que que eu poderia acrescentar
[117:49] para que você tivesse mais tempo o que que eu poderia fazer para que a
[117:51] gente conseguisse executar esse projeto de uma melhor forma eu deixo Leandro
[117:55] responder porque a partir da resposta dele ele encontrou a solução dele ou um
[117:58] cliente ele pede ali para mim nossa você tem certificação em tal área ou quais
[118:03] certificações você tem tá deixa eu entender só um ponto antes quais
[118:08] certificações você busca para que eu consiga te ajudar você tem case de
[118:12] sucesso Gustavo tá beleza é antes de eu te falar sobre isso o que que você
[118:17] busca num case de sucesso é confiar mais em mim é realmente ver se meu trabalho
[118:21] funciona é importante que eu pergunto porque eu tô fazendo a pessoa se
[118:27] justificar porque alguém que já perdeu o cliente porque não tinha que sucesso eu
[118:32] perdi antes depois que eu aprendi a quebrar objeção nunca mais perdi o
[118:40] antonio falou que sim o antonio só o antonio perdeu o cliente porque não
[118:44] tinha case de sucesso só o antonio não conseguiu fazer uma venda porque não
[118:47] tinha que sucesso não tinha uma referência caraca vocês tudo começaram
[118:50] brabo então vamos lá quando eu pego esse ponto desse case de sucesso do
[118:55] case de sucesso específico o que eu vou fazer cara o que você tá buscando dentro
[118:59] de um case de sucesso você tá buscando a validação que eu consigo realmente
[119:04] executar esse processo certo certo tá então você confia que o processo funciona
[119:09] pra você com confia o que funciona confia o que isso aqui é o essencial eu posso
[119:14] fazer essas perguntas você confia que esse processo funciona confia você
[119:17] confia que esse processo é pra você confia então o único quesito do case é
[119:21] você realmente ver se eu sou capaz de executar esse processo certo
[119:26] olha a pergunta que eu fiz pro cara olha se esse cara ele não fica realmente preso
[119:32] dentro da minha prova se eu não estou controlando a conversa ele fala não
[119:35] certo gostar deixa eu te falar uma coisa não tem o case de sucesso como que eu
[119:40] posso fazer pra provar pra você que eu consigo aplicar isso porque você disse
[119:43] que funciona pra você e você disse que isso funciona pra sua empresa isso é
[119:47] um fato agora a única coisa que resta é você saber se eu sou capaz de
[119:50] executar isso pra você e aí eu te faço uma pergunta como que eu posso provar isso
[119:54] pra você qual que foi a opção que o cliente sobrou eu falei que não tinha
[120:01] case e quem que ficou com a autoridade dentro da conversa e quem que trouxe essa
[120:07] autoridade dentro da conversa e quem que tá comandando a união quem que tá
[120:10] comandando a negociação mesmo eu falando que não tinha mesmo eu falando
[120:13] um ponto de desvantagem eu porque quem faz a pergunta controla a conversa
[120:18] quem pergunta controla a conversa quando você é abordado por um
[120:21] policial na rua você que já foi abordado por um policial na rua seja de
[120:25] carro seja pego qualquer coisa quem faz as perguntas o policial você se perguntar
[120:30] por que está me parando
[120:31] ah quer qual documento ou ele que pega fala assim cara me dá documento tal está
[120:36] indo pra onde está voltando aonde está fazendo o que em passagem tem o que
[120:40] quem que pergunta autoridade então autoridade ela vai perguntar beleza e
[120:46] você precisa ser autoridade dentro de uma ligação dentro de uma reunião
[120:49] quando você está fazendo uma prospecção e o cliente ele pergunta assim cara é e
[120:55] quem são vocês realmente para apresentar um evento de clínica você tem uma
[120:58] clínica ou você tem tal empresa nesse setor para apresentar esse evento eu te
[121:03] pergunto tá exatamente o que que você está procurando é realmente saber pra
[121:08] saber se esse evento é pra você porque eu entendo a gente não tem tá
[121:12] mas eu preciso saber o que que você precisa entender se a gente sabe ou
[121:16] não para você participar desse evento porque muitas das vezes o cara ele está
[121:21] fazendo perguntas para te testar mesmo e aí se você mente e aí se você treme na
[121:27] autoridade o que acontece
[121:29] se não vende sabe que eu fiz nas últimas todas as reuniões que eu fiz
[121:35] cara eu tenho os queis que eu apresento quando o cara me pede mais queis e
[121:38] pede o contato de alguém eu pergunto o que você está buscando com esse
[121:41] contato eu não passo contato qual que eu sou eu antigamente passava e eu
[121:48] não tenho problema em passar o contato dos meus queis só que eu tô treinando
[121:51] cada vez mais a ter menos objeções dentro de uma reunião e fazer com que a
[121:55] minha reunião ela seja mais concreta independente do que das coisas que
[121:59] acontecem então eu se eu pergunto pro cara o que que você está buscando com
[122:02] essa pergunta eu ele literalmente ele precisa me falar ele vai falar e a
[122:07] partir disso eu falo tá como que eu posso provar isso sem passar um
[122:10] contato porque eu acho deselegante ficar passando contato das pessoas como
[122:17] que eu posso provar isso você não pode provar tem certeza não tem nenhuma
[122:21] maneira que posso provar isso é muito difícil que a gente fale
[122:24] de lá não não de jeito nenhum sem contato não passa lá mas é bom que você
[122:30] quebra objeções porque se você aprender a quebrar objeções ele vai
[122:35] falar eu não eu não faço ser um contato e aí você volta pra esse ciclo
[122:38] você reconhece cara eu entendo eu entendo é difícil de confiar nas
[122:42] pessoas hoje em dia olha eu reconhecendo e eu volto pro mesmo
[122:46] ciclo e eu volto pra esse mesmo ciclo esse mesmo framework de três passos
[122:50] dentro de uma ligação dentro de uma reunião dentro de qualquer coisa você vai
[122:54] quebrar objeções dessa maneira gente o que eu ensino tá o que eu ensino é a
[122:59] lógica por trás eu ensino vocês realmente o quando eu dou um zoom aqui
[123:04] não dá um zoom no maps né eu tô sendo meio burro na verdade o zoom no maps é
[123:08] aqui ó mas enfim quando quando eu ensino pra vocês eu não quero que
[123:13] vocês simplesmente copiam o que eu faço eu quero que vocês aprendam o que
[123:17] eu faço beleza até aqui nessa parte de convite pro evento vocês conseguiram
[123:24] entender como que você convida para um evento vocês conseguiram entender como
[123:28] que você faz esse convite alguém conseguiu entender beleza gabriel ok
[123:35] gabriel oliver eu tenho uns outros oito gabriel que também tá aqui é o
[123:41] gabriel da das clínicas ontológica das clínicas de coisa né seu produto de
[123:46] reconhecimento mensal ah tá o gabriel é brabo o gabriel é brabo gente vou
[123:51] conectar o gabriel com quem faz o web na área de clínica quem atende clínica
[123:55] ontológica ali pra ele tem um produto muito foda muito foda mesmo clínica
[124:00] ontológica clínicas no geral ele tem um produto muito bom vou conectar vocês
[124:04] com ele bora lá pessoal até aqui tudo ok conseguiram entender posso passar
[124:10] para a próxima aula gente tá valendo a pena esses 40 7 reais tá valendo a
[124:14] pena eu tá até agora até agora tá valendo a pena do pouco estava que eu
[124:21] desperticei dinheiro se tiver se estiver despertizado dinheiro até aula 2 tá a
[124:27] gente ainda tem mais algumas aulas a gente ainda tem mais algumas horas ali de
[124:32] conteúdos então por como vamos continuar em frente pessoal eu peço
[124:37] somente uma coisa tá postem pelo menos um stories dentro desse evento aqui
[124:44] por favor que isso me ajuda a incentivar mais pessoas incentivar ali a galera
[124:49] participar mais fechou os primeiros 30 minutos já estava pago do evento de lá
[124:54] pra cá é só o ver delivery ou então vou fechar aqui o evento estou brincando
[124:57] bora lá gente mapa do zero ao primeiro evento agora sim eu vou ensinar você
[125:02] fazer seu evento porque que eu começo pelo convite e não começo pelo
[125:05] evento porque as pessoas elas são procrastinadoras elas não vão fazer
[125:10] o evento se elas não fizerem convites então cara primeiro de coisa de
[125:13] tudo gostava não tem escopo de evento nunca fiz evento no estudei o nicho não
[125:17] fiz nada cara estuda ali faz segue o modelo de prospecção começa a
[125:20] prospectar pro evento decide uma data ó vamos fazer o seguinte todo mundo aqui tá
[125:25] todo mundo aqui anota data do seu próximo evento
[125:28] Gustavo eu não tenho evento eu não sei conduzir evento Gustavo eu
[125:32] prospecto ali pros seus eventos Gustavo eu faço não sei o que não importa anota
[125:36] uma data pra você fazer o seu evento próximo
[125:38] Gustavo eu sou do seu time a gente pode fazer um evento junto posso conduzir
[125:42] um evento pode a gente a gente conversa depois mas anota uma data pro seu
[125:46] próximo evento anota anota ó meu evento vai acontecer tal dia tal horário
[125:50] acabou essa data então você começa a convidar ali mesmo que você não tem um
[125:55] evento pronto amanhã você pega você segue aquele escopo de cp e aí a
[125:59] partir daquele escopo de cp você realmente consegue colocar ali a data do
[126:04] teu evento aí você já começa a convidar mesmo que você não tem um
[126:07] evento pronto fechou vamos fazer esse acordo
[126:11] Gustavo eu não sei o que eu vou falar não sei sobre o que eu vou vender não sei
[126:14] sobre o que eu vou fazer cara coloca data do evento faz um evento vai ser
[126:18] transformador para você falar com um monte de empresários e assistir um
[126:20] monte de empresários discutando é der isso aqui é pra você tá você é um
[126:27] cara incrível que precisaria estar conversando com 300 400 empresários
[126:31] todos as semanas como você escolhe a o horário e leva em leva em conta o
[126:37] perfil do prospect com certeza tá com certeza vamos lá se eu tô atendendo uma
[126:42] confeitaria e essa confeitaria ela fica aberta das 8 às 6 da tarde cara é bom
[126:46] fazer um evento de 19 horas é bom fazer um evento 20 horas porque ela
[126:50] provavelmente vai tá em casa vai tá descansando e tudo mais
[126:53] estava vou fazer o evento que dia da semana vou fazer um evento numa
[126:57] sexta-feira à noite o meu perfil de cliente é um cliente que sai
[127:00] sexta-feira à noite então opa pera aí não vai ser esse cliente eu fiz um
[127:06] evento para clínicas ontológicas clínicas no geral na verdade é sexta-feira
[127:11] meio dia porque que eu fiz sexta-feira meio dia porque que eu sei que meio dia a
[127:15] maioria dos dentistas param independente se tem paciente ou não eles vão
[127:19] parar vão arrumar uma desculpa vão deixar os cara lá esperando então a
[127:22] gente sabia que as pessoas iam ficar ali é realmente prestando atenção em
[127:26] quanto assistem e tudo mais foi um evento que a gente marco muita coisa então a
[127:29] gente escolhe o data e o horário do evento com base no nosso cliente então
[127:34] normalmente eu faço quinta-feira de 19 horas porque quinta-feira de 19 horas eu
[127:38] consigo quase qualquer outro nicho ninguém quase sai quinta-feira 19 horas
[127:43] é uma boa data tá quase acabando a semana e tudo mais então a gente consegue
[127:47] fazer ali uma construção muito boa fechou então mapa do zero ao seu
[127:52] primeiro evento bora lá ideia central então a primeira coisa dentro do evento
[127:57] que a gente precisa entender é ideia central então a ideia central é como
[128:03] escolher o tema do seu webinar como escolher o tema do seu evento que você
[128:07] vai trazer pessoas primeiro ponto que você precisa entender tá e eu preciso
[128:12] que vocês vão anotando tá é bom fazer evento no final do mês pensando que
[128:15] nos início dos meses as empresas tem que pagar os funcionários cara eu faço
[128:18] evento toda semana se você for fazer só um evento considera a época do mês que
[128:23] é melhor para essa pra essa empresa se você for fazer eventos por exemplo a
[128:28] gente tá indo para os para cinco eventos por semana aqui
[128:30] a ganhos vai ser meio início final do mês e vocês vão ver isso no modo de
[128:37] nutrição infinita vocês vão aprender que pouco importa o dia e o horário que
[128:41] o seu líder entrou o que importa que ele entrou tá vocês vão ver isso no
[128:44] modo de nutrição infinita primeira coisa pra você escolher o tema do seu
[128:47] webinar meu produto para seu produto
[128:51] Gustavo quem eu não tenho um produto definido quem é o produto é você o que
[128:55] você sabe fazer tá então a partir de você o que você sabe fazer se define
[128:59] um produto Gustavo eu tenho um produto eu tenho um serviço aqui que eu já faço
[129:03] beleza a gente vai começar o seu evento pelo seu produto porque lembra
[129:06] que eu mandei você fazer a pesquisa do seu cliente você já tem que ter essa
[129:09] pesquisa do seu cliente nessa etapa beleza então na etapa de prospecção
[129:12] eu mostrei que você precisa ter ali o seu cliente mas vamos lá pro meu
[129:16] e quais dores o seu produto resolve a nota gente para em de usar inteligência
[129:22] artificial para tudo beleza utilizem isso para otimizar o processo de vocês eu
[129:27] utilizo muita e a mas é para fazer coisas e otimizar coisas que eu já sei coisas
[129:31] que me levariam tempo que eu posso delegar mas coisas intelectuais passam
[129:35] a nota em escrevam criem um documento esses mapas mentais aqui óbvio alguns
[129:44] são escritos por ia mas a maioria foi eu que escrevi e os que foram escritos
[129:48] por ia eu só transcrevi para que o texto ele ficasse mais coeso só isso mas
[129:53] todos os mapas mentais que estão vendo aqui eu que elaborei eu não falei ó
[129:57] crie um mapa mental cheese 11 não eu elaborei beleza então meu produto
[130:02] quais dores do seu produto resolve quais dores do seu cliente seu produto
[130:06] o serviço resolve fala pra mim gabriel quais dores o seu serviço ou produto
[130:11] do seu cliente quais problemas latentes do seu público ou que seu público
[130:16] continuar atendo fazendo isso manualmente ou não tendo seu produto
[130:21] quais são as dores seu público ele continuar atendo caso seu produto não
[130:26] existisse não existisse caso seu serviço ele não existisse caso o que
[130:31] você faz não tivesse dentro do mercado quais as dores do seu público ele
[130:35] teria quais as dores que seu público ele tem de não contratar você nesse
[130:40] momento seja seu produto seu serviço caso seu cliente realmente é tenha não
[130:48] tenha contratado seu produto seu serviço como que ele resolve isso ou como que
[130:53] era isso era resolvido antigamente eu vou dar um exemplo essa pergunta é muito
[130:56] importante porque essa pergunta eu me baseio todo meu webinário nessa
[130:59] pergunta tá como que seu cliente fazia esse produto antes mesmo ou fazer
[131:06] fazia pra resolver essa dor antes mesmo da solução que você trouxe existir
[131:12] por exemplo o estável faço tráfego pago tá antes do tráfego pago existir como
[131:16] que seu cliente ele fazia captação de clientes é importante você sabe bom disso
[131:20] porque a maioria das pessoas que vão falar de tráfico pago elas vão falar de
[131:24] tráfico pago mas como que esse cliente ele faz para atrair mais clientes como
[131:28] que eles faziam isso como que ele cresceu em empresa dele como que outras
[131:32] antigamente cresciam as empresas deles. É uma pergunta que você deve se fazer,
[131:38] porque existem empresas muito ricas de setores diversos que hoje em dia ainda não
[131:44] investem em tráfego pago e você está falando, tráfego pago você precisa investir e
[131:47] tudo mais e às vezes o cara ele fatura milhões. Por que ele fatura milhões? Qual
[131:52] que é a melhor maneira de fazer isso sem ser com o seu serviço? Ou qual que é a
[131:56] melhor maneira de entregar o resultado do seu serviço ou produto sem necessariamente
[132:02] ser com o seu produto serviço? Ah, Gustavo, é impossível fazer o que eu faço sem o meu
[132:08] produto serviço. Vamos supor que você vende srm, cara? O cara não pode anotar no papel,
[132:12] ele não pode criar numa planilha. A pergunta que eu tenho e essa pergunta ela vai fazer
[132:18] muito sentido para vocês. Vocês têm que saber como resolver o problema do seu
[132:21] cliente sem ele ter o seu produto serviço. Sabe por que? Porque você vai ensinar ele.
[132:26] Olha como é mais impactante durante um evento, você pega e fala assim,
[132:32] pessoal, vocês precisam anotar, vocês precisam ter métricas x, y, z, aí você precisa anotar
[132:37] quantos clientes entram, quantos clientes respondem, quantos clientes respondem,
[132:41] quantos continuam a uma conversa, de quantos continuam a uma conversa, você precisa anotar
[132:45] quantos compram e aí você precisa dessa métrica porque essa métrica você
[132:49] vai analisar ela e ajustar ela nesse setor, você consegue fazer isso, isso, isso.
[132:52] E aí eu mostro um monte de coisa e eu mostro para ele como que ele faz isso
[132:56] sem o meu serviço, o produto. Só que olha que louco e aí no final eu posso falar assim
[133:00] e se você precisa fazer tudo isso, se você não tem tempo para anotar
[133:04] ou fazer tudo isso, se você quer alguma coisa mais automatizada, a gente consegue
[133:07] instalar um CRM para você porque ele te dá todas essas métricas automaticamente
[133:11] sem você precisar ficar se preocupando, aí você só analisa mesmo.
[133:15] Vocês percebem como é muito mais impactante?
[133:18] Vocês percebem como é muito mais impactante se eu falo para o meu cliente
[133:21] como que ele resolve o problema dele antes do meu serviço ao invés do meu serviço?
[133:25] Cara, para você captar cliente sem tráfego pago, você vai fazer uma publicidade
[133:30] assim, você vai produzir tantos conteúdos, você vai fazendo isso, aquilo, aquilo
[133:33] outro, não sei o que, não sei o que lá, não sei o que lá, aí você vai falando
[133:36] um monte de coisa, e o cliente vai ficar caralho, ou você faz tudo isso
[133:39] aqui com anons online, que é bem mais rápido e assim, qual que você prefere?
[133:46] Vocês entenderam? Vocês entenderam porque essa parte de mostrar para ele
[133:52] o antes do seu produto de serviço é importante?
[133:57] Eu não falo para ele, nossa, você vai resolver tal dor, você não vai precisar
[134:00] fazer isso aquilo, aquilo outro, não ensino ele o que ele precisa fazer.
[134:04] Só que ele vai olhar, ele vai falar, cara, é tanta coisa para eu me fazer
[134:06] que eu não consigo, e aí por isso que ele te contrata.
[134:08] E aí por isso que você é caro.
[134:11] Como empresas que não têm o seu serviço se destacam nisso?
[134:14] É uma pergunta que eu tenho.
[134:16] Como empresas que não investem pesado no seu serviço,
[134:19] do setor de clientes que você quer atender, se destacam nisso?
[134:23] Então sempre vão ter empresas grandes que não vão utilizar o serviço
[134:27] ou o produto que você vende.
[134:30] Mas essas empresas grandes, existe alguma empresa que tem algo parecido
[134:34] ou que tem alguma metodologia que ela consegue crescer
[134:37] e ela consegue faturar muito bem, mesmo sem isso?
[134:41] Se você consegue entender isso, você consegue entender o que eu falei
[134:44] ali em cima. Se você consegue entender o que eu falei
[134:46] ali em cima, essas empresas grandes, elas concordam com você
[134:49] e elas venham o que você faz, ainda um caminho para facilitar
[134:52] o que elas já fazem. Pronto, acabou.
[134:54] Então você começa pelo seu produto, mas não para você falar
[134:57] para o seu cliente sobre o seu produto dentro do evento,
[134:59] mas para você falar tudo que o seu produto engloba
[135:01] e que pode ajudar ele. Fechou?
[135:04] E aí a gente vai para a parte do meu público.
[135:07] Quais coisas eles sempre escutam?
[135:09] Quais coisas no meu cliente potencial eles sempre escutam? Anota.
[135:13] Anota, quais coisas eles sempre escutam?
[135:15] Cara, você precisa investir em tráfego pago, você precisa fazer isso,
[135:17] você precisa fazer aquilo. Quais são as coisas que eles estão cansados de escutar?
[135:20] Cara, quais são as coisas que eles escutam o tempo todo?
[135:23] Chega a ser maçante, você precisa produzir conteúdo,
[135:26] você precisa fazer isso, aquilo, aquilo outro. Anota isso, isso é importante.
[135:30] Porque muitas das vezes eu inicio o evento,
[135:32] quem já viu um evento meu, eu vou falar assim.
[135:35] Cara, sabe aquelas pessoas que ficam falando que precisa fazer Y, X, Z?
[135:38] E aí eu fico falando um monte de coisa que as pessoas falam para eles
[135:40] fazer no tempo todo. Eu falo, cara, vamos deixar isso de lado?
[135:43] Vamos falar sobre esse outro assunto agora?
[135:45] E aí, sabe o que as pessoas fazem? Elas abaixam a defesa.
[135:48] Porque se eu falo, se eu chego ali,
[135:51] tirando coisas que elas sempre escutam e elas já estão cansadas de escutar,
[135:54] o que que eu faço? Eu ganho atenção deles.
[135:57] Porque eles falam, nossa, ele não é igual aos outros.
[135:59] Ele não vai falar de novo desse assunto chato pra caramba.
[136:03] Quais são as crenças centrais do meu público?
[136:06] Tanto sobre o meu produto, sobre as crenças dele.
[136:09] O que que o meu público acredita?
[136:11] O que que o meu público acredita realmente que é sucesso?
[136:14] O que que o meu público acredita que a empresa dele precisa?
[136:17] O que que o meu público acredita sobre o mercado, sobre as pessoas, sobre o funcionário, sobre tudo?
[136:22] Uma vez eu fiz um evento de delivery, sabe qualquer coisa que eu mais tenho
[136:25] o taxa de resposta dentro de um evento de delivery?
[136:28] É quando eu pergunto de motoboy, sabe porquê?
[136:30] Porque eu sei que uma das crenças centrais que o meu público tem
[136:35] é que motoboy vai dar problema pra eles.
[136:39] Olha que louco.
[136:40] Então se eu sei que isso, mesmo que isso não esteja nada correlacionado
[136:44] com o meu produto, eu falo sobre vendas.
[136:46] Eu consigo correlacionar vendas com ele.
[136:50] Vender um bom relacionamento com motoboy pra que o motoboy
[136:53] trabalhe de maneira mais eficiente?
[136:55] Consigo? Consigo.
[136:56] Eu consigo associar várias outras coisas.
[136:59] Eu consigo associar o meu produto com quase qualquer coisa.
[137:02] Mas primeiro eu preciso saber quais são as crenças centrais do meu público.
[137:05] Como que eu descubro as crenças centrais do meu público?
[137:07] Cara, começa a ouvir aqueles experts ali que eu falei pra ti.
[137:10] Que é impossível tu não saber.
[137:14] Leandro, você foi um dos únicos caras que escutou o conselho que eu te dei.
[137:18] E olha que louco isso.
[137:20] Depois que você escutou esse conselho que eu te dei,
[137:22] você não ficou sabendo muito mais crenças sobre o público,
[137:24] sobre o mercado, sobre jargões que eles falam, sobre crenças que eles têm?
[137:29] E é muito louco isso.
[137:31] Porque se você começa a descobrir isso, você sabe o que falar.
[137:34] E aí, dentre essas crenças, quais eles nunca resolvem?
[137:39] Quais são as crenças que eles têm?
[137:41] Que impedem ele de prosperar, impedem ele de crescer,
[137:44] impedem ele em vários outros aspectos que eles nunca resolvem?
[137:47] Porque essa é a dor que eu dou.
[137:49] Essa é aquela crença que eu literalmente resolvo.
[137:54] Só que se eu não resolver, eu vou dar uma cutucadinha pra resolver.
[137:57] Ou vou dar uma cutucadinha pra esse cara e ele sentir essa dor.
[138:01] Deixa eu te trazer uma visão sobre isso.
[138:03] E eu vou te trazer essa visão sobre isso,
[138:05] porque eu sei que é uma das crenças internas do nosso público
[138:09] que está aqui hoje, ou que está assistindo essa aula,
[138:13] que realmente eles nunca resolvem isso.
[138:16] Alguém aqui já sentiu que tem alguém mais idiota que você,
[138:21] mais buro que você, que tem menos conhecimento que você,
[138:23] vendendo muito mais.
[138:24] Porque ou está famoso no Instagram, ou tem sucesso,
[138:27] ou sei lá, deu sorte, ou escalou alguma coisa,
[138:29] mesmo com um produto merda, mesmo com alguma coisa.
[138:31] E aí você se sente meio mal, às vezes,
[138:33] porque você sabe que você é muito mais inteligente,
[138:35] mais capacitado que aquela pessoa,
[138:37] mas ela tem muito mais resultado financeiro.
[138:39] É, eu, isso é foda de ver.
[138:42] Cara, isso é uma crença do meu público que ele tem,
[138:45] e que eu realmente sei que ele tem.
[138:47] E que conectou aqui, talvez não 100% com as pessoas.
[138:53] Mas sei lá, 95% de vocês já sentiu isso, de alguma forma.
[138:57] Vem naquele cara, todo estranho, que não tem conhecimento nenhum,
[139:00] que fala tudo errado, que vende pra caramba.
[139:03] Porque às vezes ele é famoso no Instagram e tudo mais.
[139:06] E aí, como que eu associa essa crença pro meu público?
[139:09] Eu falo assim, cara, eu também tinha isso.
[139:13] E por eu ter isso,
[139:15] eu não queria produzir conteúdo no Instagram,
[139:17] porque eu não queria ser igual a esses caras.
[139:19] Sabe o que eu fiz? Eu fui lá e criei meus próprios eventos.
[139:21] E hoje eu supero que todos esses caras
[139:23] sem necessariamente aparecer.
[139:26] E aí eu sou muito melhor que eles.
[139:28] E aí eu consigo fazer com que eles,
[139:30] que eu tenho literalmente a visibilidade deles,
[139:32] sem necessariamente ter o público deles.
[139:35] Eu faço isso através de um evento,
[139:37] eu faço isso através disso, daquilo, daquilo outro.
[139:40] E aí eu conecto com o meu público e ele fala assim,
[139:42] caraca Gustavo, eu preciso disso.
[139:44] Olha que louca, estou mostrando pra vocês algo,
[139:46] e vocês estão sentindo, talvez,
[139:48] muito de vocês estão sentindo isso,
[139:50] mesmo em exemplificando isso,
[139:52] mesmo mostrando que isso é um exemplo pra vocês,
[139:54] porque isso são crenças,
[139:56] são coisas internas que vocês têm dentro de vocês.
[139:58] Vocês precisam anotar?
[140:00] Anota as principais 5 crenças que o seu público tem,
[140:03] e associe isso com seus produtos,
[140:05] seus serviços, com a sua resolução.
[140:07] Beleza?
[140:08] Como eu posso comunicar isso de maneira diferente?
[140:11] Como que eu posso comunicar uma solução
[140:13] pra essa crença que ele tem de maneira diferente
[140:15] como ninguém nunca comunicou?
[140:17] Ou como que eu posso comunicar
[140:19] essa crença, ou isso que ele está passando
[140:22] e nunca soube descrever,
[140:24] de uma maneira que ninguém nunca descreveu?
[140:29] Vou dar um exemplo.
[140:31] Muitas pessoas têm medo de prospectar
[140:33] porque elas têm medo do produto delas
[140:35] não ser bom o suficiente pra eles entregar.
[140:39] E quando eu mapei essa crença,
[140:41] eu falo isso de maneira diferente.
[140:43] Eu falo assim, cara, sabe por que estou num prospecto?
[140:45] Porque eu não acredito que você consegue
[140:47] ficar rico escalar esse produto
[140:49] e entregar uma qualidade boa pra seu cliente.
[140:51] Quando eu percebo isso pro meu cliente,
[140:53] ele fala, caralho, é isso.
[140:55] É pronto.
[140:57] Crenço.
[140:58] Isso vai me ajudar no evento.
[141:00] Tem várias dessas crenças dentro do evento.
[141:02] Mas aqui eu preciso que vocês anotem cinco crenças dessas.
[141:05] Fechou?
[141:07] Anotem cinco crenças do seu público.
[141:09] Então, nessa parte, pra escolher o tema do teu webinário,
[141:12] você realmente...
[141:14] Você vai entender o teu produto e o teu público.
[141:16] Aqui você escolheu o teu tema,
[141:18] o tema central, o que vai ter dentro do webinário.
[141:20] Não é o nome, não é a oferta ainda,
[141:22] mas é o tema central do seu webinário.
[141:24] Fechou?
[141:25] O nome, por si só,
[141:26] vocês vão aprender na aula de ofertas,
[141:28] que é daqui a pouco.
[141:29] Beleza?
[141:30] Anotações.
[141:31] Então, você vai pra parte de anotações.
[141:33] Escreva todos os conteúdos
[141:35] que acreditar ser relevante em tópicos.
[141:38] Ou seja, você estudou os expertos,
[141:40] você entendeu seu público, você entendeu crenças,
[141:42] você entendeu seu produto.
[141:43] Agora você vai anotando.
[141:44] Deixa eu selecionar todos os conteúdos
[141:46] que eu acredito ser relevante.
[141:47] Aí você vai fazer o quê?
[141:49] Coloca um ranking.
[141:51] Aí você vai rankar.
[141:52] Cara, eu acredito que esse aqui
[141:53] é o mais importante de todos.
[141:55] E aí você vai escolher os top 5.
[141:57] Você acha mais relevante.
[141:59] E aí você vai falar sobre esse top 5.
[142:01] Porque quem tenta comunicar tudo também
[142:03] acaba não comunicando nada.
[142:04] Então você vai falar sobre esses top 5 temas.
[142:06] E é isso que vai ser dentro do seu evento.
[142:08] Mas Gustavo, por que que eu anoto todos os outros?
[142:10] Então Gustavo, por que que eu anotei 50 tópicos então?
[142:13] Deixa eu falar uma coisa pra você.
[142:16] Você anotou 50 tópicos,
[142:17] mas às vezes você tá falando desse 5,
[142:19] alguém te faz uma pergunta no chat
[142:20] e você sabe todos os outros.
[142:23] Isso faz com que você faz uma venda.
[142:25] Porque uma pessoa dentro do seu chat,
[142:26] dentro de um webinário,
[142:27] dentro de um evento de uma hora,
[142:29] é um possível cliente.
[142:30] E às vezes esse possível cliente
[142:31] ele compra 36 reais de vocês.
[142:34] Teve um caso de um cara
[142:36] que eu vendi um produto pra ele.
[142:37] Eu falei assim, cara, relaxa.
[142:39] Você me paga tanto.
[142:41] Você não precisa prospectar
[142:42] e também não precisa vender.
[142:43] Eu vendo pra você,
[142:44] eu prospecto pra você
[142:45] e eu entrego isso pra você.
[142:47] Ou eu entrego o cliente pronto.
[142:49] Ele entrega o serviço.
[142:50] E aí ele pegou e falou assim,
[142:51] cara, quero isso, vamos lá.
[142:53] Sabe o que eu fiz?
[142:54] Eu fiz, literalmente.
[142:56] Três prospecções.
[142:57] Levei, acho que duas pessoas
[142:59] pra dentro do evento de clínicas
[143:00] que foi ontem.
[143:02] E ontem mesmo.
[143:04] Eu fiz uma das maiores vendas.
[143:06] Eu fiz a maior venda desse mês que eu fiz.
[143:09] Fiz uma venda de 35 mil reais.
[143:11] 34, né?
[143:12] Porque teve desconto.
[143:13] Cara, eu levei numa hora
[143:17] pra entregar o serviço
[143:18] que eu tinha vendido pro cara.
[143:19] Foi sorte minha também, né?
[143:20] Nem todo líder vai comprar ali,
[143:22] sei lá, 34 mil de cara com você.
[143:24] Foi uma hora e meia de reunião.
[143:25] Mas assim,
[143:26] depois eu quero mandar essa gravação
[143:27] pra vocês, mas assim, cara,
[143:28] foi muito fácil.
[143:29] Sabe por quê?
[143:30] Porque tudo o que o meu público falava,
[143:32] tudo o que a pessoa falava ali
[143:33] e que ela tinha visto no evento,
[143:35] ela trazia outros pontos
[143:37] e esses outros pontos
[143:38] estavam em tópicos que eu já tinha notado,
[143:40] tópicos que eu já sabia.
[143:41] Então fica muito fácil de vender.
[143:43] Fica muito fácil de vender
[143:44] quando você entende muito mais
[143:46] sobre o seu público
[143:47] do que seu produto.
[143:51] Porque a maioria das pessoas
[143:52] entende muito sobre o seu produto,
[143:53] mas entende quase nada sobre o seu público.
[143:55] Eu entendo muito mais sobre o meu público
[143:57] do que o meu produto.
[143:59] E eu falo isso bem sincero.
[144:01] Quando se trata de clínica e de agência, tá?
[144:04] Quando se trata de outras áreas, não.
[144:07] Aí eu entendo um pouquinho mais
[144:09] sobre o meu produto,
[144:10] mas é muito importante
[144:11] que você entenda o seu produto tanto quanto...
[144:13] O seu público tanto quanto
[144:14] você entende do seu produto.
[144:15] É muito importante que você entenda
[144:17] das crenças das pessoas,
[144:18] como o humano funciona,
[144:19] como o ser humano funciona,
[144:20] comportamento,
[144:21] comportamento do seu cliente específico.
[144:23] Cara, você vai estudar persuasão,
[144:25] tá bom, estuda persuasão,
[144:26] estuda persuasão,
[144:27] aplicada para o seu cliente específico.
[144:29] Não perca tempo tentando entender tudo da vida.
[144:32] Porque você não vai conseguir.
[144:34] E ao mesmo tempo,
[144:35] você vai acabar não aprendendo quase nada, tá?
[144:37] Então, aí a gente vem
[144:39] com um próximo ponto, autoridade.
[144:41] Gente, eu sei que eu coloquei aqui
[144:43] como você criar o seu evento do zero aqui,
[144:45] mas eu preciso passar os conceitos
[144:47] para que eu passe alí o passo a passo.
[144:49] Fechou?
[144:50] E todo mundo que está nessa aula
[144:53] pode anotar,
[144:54] vocês vão receber uma aula minha chamada
[144:56] Web Nário de Auto Impact,
[144:57] que aí sim eu ensino,
[144:58] oh, você vai falar isso nesse horário,
[145:00] você vai falar isso nesse horário, blá blá blá.
[145:02] Fechou?
[145:03] Então, pode me cobrar depois alí
[145:04] que vocês ganham isso de presente.
[145:06] Você tem experiência real na área?
[145:08] Então, vamos falar sobre a autoridade.
[145:10] Gustavo, beleza,
[145:11] eu vou apresentar o evento,
[145:12] vou iniciar o evento.
[145:13] E aí, a primeira coisa que a pergunta
[145:15] que eu tenho e a grande objeção
[145:16] que eu tenho,
[145:17] meus clientes provavelmente têm,
[145:19] cara, você tem experiência na aula?
[145:21] Na área?
[145:23] Você tem experiência na área
[145:24] que você vai executar?
[145:25] Por mais que você tenha visto
[145:27] os conteúdos e tudo mais,
[145:29] você tem experiência, sei lá,
[145:30] em construtora?
[145:32] Você tem experiência e não sei o que,
[145:33] você trabalhou com isso?
[145:34] Você tem algum cliente
[145:35] que teve muito sucesso nisso?
[145:36] Se não tem, não tem problema, cara.
[145:38] Sabe qual que é o maior problema
[145:39] das pessoas?
[145:40] Elas tentam o tempo todo
[145:41] ser o que elas não são.
[145:43] Eu cheguei no evento de imobiliárias.
[145:46] Sabe qual que foi a primeira coisa
[145:47] que eu falei?
[145:49] Eu falei assim, cara,
[145:50] muito obrigado por estarem no evento.
[145:52] E eu vou explicar porque
[145:53] vocês devem me escutar.
[145:55] Sabe quantos imóveis eu já vendi?
[145:57] Sabe quantas coberturas
[145:58] eu já vendi?
[145:59] Sabe quantos lançamentos
[146:00] eu já vendi?
[146:01] Está gravado, tá?
[146:02] Posso mostrar para vocês
[146:03] depois eu falo isso para os corretores.
[146:05] Eu vendi zero.
[146:06] Eu nunca vendi um imóvel
[146:07] e eu nem sei como funciona
[146:08] o processo de venda de um imóvel.
[146:10] Agora eu vou te falar o que
[146:11] eu sei muito bem.
[146:12] Eu sei muito bem
[146:13] sobre processos comerciais.
[146:14] Por isso que eu fui convidado
[146:15] aqui para falar para vocês
[146:16] e conduzir esse evento.
[146:17] Porque eu não estou na bolha
[146:18] de vocês e por não estar na bolha
[146:20] de vocês, às vezes,
[146:21] eu posso te mandar um insight
[146:22] que você vai se diferenciar
[146:23] e você vai trazer algo diferente
[146:25] para o teu mercado.
[146:26] Então, se você quer ser
[146:27] uma pessoa desulpitiva
[146:28] que realmente escuta pessoas
[146:30] e consegue transformar
[146:31] o conhecimento de outras pessoas
[146:32] de outras áreas,
[146:33] no conhecimento para sua área,
[146:34] cara, esse é o evento
[146:35] perfeito para você.
[146:37] O que eu fiz?
[146:38] Eu quebrei expectativas, cara.
[146:41] Olha que louco.
[146:42] Esse cara, ele está acostumado
[146:44] a ouvir eventos do tempo todo
[146:46] de pessoas que já passaram
[146:47] pelo que ele passou.
[146:49] Ele está acostumado
[146:50] a ver vários lançamentos,
[146:52] a seguir vários influenciadores
[146:53] que entendem exatamente a vida dele.
[146:56] Agora olha que louco.
[146:57] Esse cara quebrou a minha expectativa.
[146:59] Então, quem sou eu?
[147:00] Quanto resultado eu tive na sua área?
[147:02] Zero?
[147:03] Eu tive zero resultado na sua área.
[147:05] A única coisa que eu sei
[147:06] é que eu domino essa ferramenta
[147:07] e eu sei que se a gente
[147:08] pegar essa ferramenta
[147:09] com o seu conhecimento
[147:10] que você tem na sua área,
[147:11] que é impossível
[147:12] ter mais conhecimento que você,
[147:14] e a gente unir as duas coisas
[147:15] vai fazer com que você
[147:16] tem um resultado incrível.
[147:19] Quebrei expectativa.
[147:20] Eu poderia mentir para vocês,
[147:22] porém, eu poderia mentir para vocês
[147:24] falando que eu tenho várias experiências,
[147:26] várias coisas dentro dessa área.
[147:28] Mas é mentira.
[147:29] Não ia colar.
[147:30] Não é da minha natureza mentir para vocês.
[147:32] Eu quero realmente passar
[147:33] o que eu sei e o que eu sou muito bom.
[147:35] E se o que eu sou muito bom
[147:36] conectar com o que você faz,
[147:37] cara, a gente tem um resultado incrível.
[147:39] E aí vem o próximo ponto.
[147:41] Eu estou aqui justamente
[147:42] por não conhecer sua área,
[147:43] mas entender a conexão que eu faço,
[147:45] aí você se posiciona.
[147:47] A conexão que eu faço com marketing,
[147:49] a conexão que eu faço com social mídia,
[147:51] com redes sociais, com um monte de coisa,
[147:54] com o que vocês entendem.
[147:56] Ou seja, eu crio sinergias entre uma pessoa
[147:58] que é muito bom
[147:59] e essa ferramenta que eu vou falar
[148:00] sobre elas para vocês hoje.
[148:02] Cara, eu vou perder minha autoridade
[148:06] se eu fizer isso dentro do evento?
[148:07] Sejam sinceros.
[148:09] Eu vou perder minha autoridade?
[148:11] Eu vou fazer com que as pessoas
[148:12] não curta um evento?
[148:14] Na real, eu acho que
[148:15] eu vou ganhar muito mais autoridade.
[148:17] E quando eu falei isso,
[148:19] sabe qual foi a primeira coisa
[148:20] que eles mandaram no chat?
[148:22] Obrigado pela transparência.
[148:24] Foi bacana isso.
[148:28] A primeira coisa
[148:29] que mandaram no chat do evento foi,
[148:31] obrigada pela transparência.
[148:33] Mas sabe por que que eles mandaram isso?
[148:35] E porque um monte de cliente
[148:37] começou a mandar?
[148:39] Cara, obrigado por falar isso.
[148:41] Obrigado por não mentir.
[148:43] Eles começaram a falar isso.
[148:44] Sabe por quê?
[148:45] Porque o mercado está cheio de gente mentirosa.
[148:49] E é legal porque
[148:51] hoje a honestidade é um diferencial, mano.
[148:53] A honestidade deveria ser obrigada.
[148:55] Não, é diferencial, pô.
[148:57] É louco isso, tá? É louco isso.
[148:59] Então, a honestidade
[149:01] e sinceridade
[149:03] não deveriam ser diferenciais em seu mercado.
[149:05] Deveria ser obrigação. Não, é diferencial sim.
[149:07] Você pega ali a taxa da população
[149:09] que não é honesta, que não tem diferencial,
[149:11] que não tem princípios, que não tem um monte de coisa
[149:13] e você tem, cara, você tem um diferencial sim, tá?
[149:15] Pode ficar tranquilo.
[149:17] Eu, eu
[149:19] pode mandar qualquer pessoa debater comigo.
[149:21] Sinceridade, honestidade, um bom atendimento,
[149:23] um bom relacionamento é diferencial sim, tá?
[149:25] Não é obrigação, é um diferencial.
[149:27] Dentro do Brasil é diferencial.
[149:29] Eu debato com quem vocês quiserem sobre isso.
[149:31] Fechou? Então,
[149:33] se a pessoa, se você tem experiência,
[149:35] aí você cria outra estrutura.
[149:37] Você mostra resultados, seu principal diferencial
[149:39] que é o que? Pô, como que você chega
[149:41] nesses resultados?
[149:43] O que que você é apaixonado?
[149:45] Nas duas situações, vocês vão mostrar o que que você é apaixonado, tá?
[149:47] É importante.
[149:49] Não é só eu falar de resultados,
[149:51] não é só falar do que eu entendo,
[149:53] não é só falar de diferencial,
[149:55] não é só falar de cases que eu já tive,
[149:57] cara, é eu falar do que que eu sou apaixonado.
[149:59] Porque as pessoas, elas se conectam com
[150:01] pessoas.
[150:03] Cara, eu sou apaixonado por vendas
[150:05] desde que eu sou garoto.
[150:09] Eu comecei assim, assim, assim
[150:11] e eu me apaixonei por vendas, então
[150:13] minha carreira inteira foi vendendo,
[150:15] literalmente tudo isso.
[150:17] Cara, o Wether,
[150:19] ele me conheceu antes de eu ter o primeiro salto
[150:21] financeiro. Na real, acho que eu estava
[150:23] ganhando uma grana já, mas ele me conheceu antes
[150:25] de eu ter o primeiro salto grande financeiro.
[150:27] Pergunta pra ele, se eu já não falava
[150:29] de um monte de coisa de vendas, de um monte
[150:31] de coisa de crescimento de empresa naquela época,
[150:33] se eu não parava de falar isso?
[150:35] Parece até, se você pegar uma pessoa,
[150:37] se você pegar eu de 2000, sei lá,
[150:39] 20, 2019, 2021, 2022,
[150:41] sei lá, vocês vão ver que
[150:43] obviamente minha comunicação agora é maior,
[150:45] meus resultados são maiores, às vezes
[150:47] os exemplos que eu uso são melhores, mas
[150:49] a grande vontade, boa parte
[150:51] do conhecimento é o mesmo, porque
[150:53] eu sou muito, muito,
[150:55] muito convicto do que eu sou apaixonado.
[150:57] E aí vocês têm que passar
[150:59] essa convicção e essa paixão, ela
[151:01] contagia as outras pessoas, beleza?
[151:03] Então, regras de ouro,
[151:05] toda objeção é criada
[151:07] por falta de uma narrativa que faz sentido.
[151:09] Falava, teve um encontro
[151:11] do KGR sobre negócios e o Gustavo
[151:13] foi o que mais falou e vendeu o seu conhecimento.
[151:15] Cara, sabe o que é louco?
[151:17] Nessa época ainda estava começando
[151:19] a construir uma empresa grande.
[151:21] Nessa época tinha, dentro do KGR, eu acho que
[151:23] tinha, sei lá, quase 100% das pessoas
[151:25] ali dentro, tinha mais resultado que eu.
[151:27] E aí quando eles me deram a oportunidade
[151:29] de falar, eu estava quietinho, eles me deram
[151:31] a oportunidade de falar, eu me transformei, porque
[151:33] eu amo isso, cara, você tem que saber
[151:35] o que você é apaixonado.
[151:37] Cara, expõe o que você é apaixonado
[151:39] com essas pessoas. Começa uma reunião
[151:41] e fala assim, que é só apaixonado
[151:43] nisso que eu faço. E aí você pega
[151:45] e exemplifica o que você é apaixonado.
[151:47] Só apaixonado em ajudar pessoas e só
[151:49] apaixonado em interpretar pessoas.
[151:51] O Leandro, cara, ser apaixonado por atuação.
[151:53] Cara, eu lido com pessoas porque
[151:55] eu sou apaixonado em atuação.
[151:57] E eu vi com esse trabalho
[151:59] uma maneira de eu conseguir fazer com
[152:01] que essas pessoas encontrem a melhor
[152:03] versão delas e não que elas interpretam
[152:05] e elas acreditam que elas são
[152:07] uma boa narrativa. Olha que negócio
[152:09] incrível.
[152:11] E aí eu falo pra vocês, toda objeção
[152:13] é criada por falta de uma narrativa
[152:15] que faça sentido.
[152:18] Se eu falo que eu não tenho experiência
[152:20] nenhuma com imóveis, num ebinário
[152:22] de imóveis, num evento de imóveis
[152:24] e eu não crio uma boa narrativa
[152:26] pra isso, o que vai acontecer?
[152:28] Eu vou perder completamente a autoridade,
[152:30] as pessoas nem vão me escutar.
[152:32] Só que se eu tenho uma boa narrativa,
[152:34] o que era ruim pra mim, eu transformei
[152:36] tudo pra ti é uma questão de narrativa.
[152:38] Fechou?
[152:40] Tudo pra vocês é uma questão de narrativa.
[152:42] Beleza? Ok?
[152:44] Então, aí a gente vai pra
[152:46] organização das ideias.
[152:48] A gente vai literalmente pra organização
[152:50] do seu evento. Então,
[152:52] vamos começar o seu evento e vamos começar a escrever
[152:54] o evento, vocês já entenderam basicamente
[152:56] o princípio inteiro. Vamos começar
[152:58] e escrever o teu evento.
[153:00] A gente tem alguns objetivos sequenciais
[153:02] pra que o seu evento ele dê certo.
[153:04] A primeira coisa que você precisa fazer
[153:06] anota isso. Primeira coisa no meu evento
[153:08] quando eu inicio, capturar e manter a atenção.
[153:10] Quem abre meus eventos hoje,
[153:12] na maioria das vezes é o Leandro, mas quando
[153:14] eu abro eu faço a mesma coisa.
[153:16] Capturar e manter a atenção.
[153:18] Como você vai capturar e manter a atenção?
[153:20] Cara, primeiro, promessas.
[153:22] Anota aí o que a gente vai fazer.
[153:24] Eu faço um preparamento mental.
[153:26] Abre a câmera, se prepara, se conforta
[153:28] na cadeira, se prepara pra escutar,
[153:30] vai ter isso, vai ter aquilo.
[153:32] Isso aqui, esse outro fator que a gente vai falar.
[153:34] Então eu capturo e manter a atenção.
[153:36] E aí, nisso de capturar e manter
[153:38] a atenção, ainda nesse ponto
[153:40] eu já chego apresentando um evento
[153:42] e aí sabe o que eu faço?
[153:44] Eu faço afirmações fortes.
[153:46] Cara, sabe quantos
[153:48] imóveis eu vendi? Zero.
[153:50] Ah,
[153:52] o mercado de agência tá mentindo pra ti.
[153:54] Ah, você caiu numa ilusão.
[153:56] Eu fali de tanto que eu vendi.
[153:58] Olha que louco isso.
[154:00] Eu vou manter a atenção.
[154:02] Eu preciso trazer coisas impactantes
[154:04] que eu mantenho a atenção.
[154:06] Que eu captura a atenção que a pessoa entrou
[154:08] no evento, ela não vai entrar no evento
[154:10] vidrado em você.
[154:12] Ela não vai entrar no evento, nossa, que incrível
[154:14] esse evento. Eu quero prestar totalmente
[154:16] atenção no que essa pessoa está falando.
[154:18] Não, ela vai entrar no evento fazendo o que?
[154:20] Meio distraída. Pô, será que esse cara
[154:22] é bom mesmo? E aí nos primeiros segundos
[154:24] você dá o boom, choque mental nessa pessoa.
[154:26] E aí esse choque mental vai fazer o que?
[154:28] Caraca.
[154:30] Mano, que louco isso.
[154:33] Esse choque mental vai fazer com que essas pessoas
[154:35] olham pra você e vão falar assim, caraca, que incrível.
[154:37] Deixa eu prestar atenção.
[154:39] A gente estava sombrando aqui.
[154:41] Eu estava numa reunião com o cara, né?
[154:43] Posteriormente, o evento que você fez.
[154:45] O cara falou assim, pô, o evento muito massa e tal.
[154:47] Mas quando o Gustavo falou isso,
[154:49] eu falei, nossa.
[154:51] E aí você tá trazendo isso, entendeu?
[154:53] Exatamente, exatamente.
[154:55] Então, tipo assim, cara, são pequenos detalhes.
[154:57] Só que
[154:59] a primeira coisa que você vai fazer com a sua audiência
[155:01] hoje, eu entro no evento
[155:03] e quem é do marketing tradicional
[155:05] sabe que isso não é normal em lançamento.
[155:07] Eu entro no evento, o evento tem 200 pessoas.
[155:09] Ou eu termino o evento
[155:11] com 210 pessoas, ou seja,
[155:13] com mais pessoas do que ele iniciou,
[155:15] ou eu termino ele com 100 e 98.
[155:17] Tipo, uma retenção absurda.
[155:19] Eu acho que o cara só sai quando a internet cai,
[155:21] a mulher bate nele, o carro
[155:23] acontece alguma coisa,
[155:25] ou a pessoa acontece alguma coisa com ela.
[155:27] Muita gente, eu acho que ela só sai nessa condição.
[155:29] A nossa taxa de retenção do evento
[155:31] é bizarra.
[155:33] É bizarra.
[155:35] As pessoas não saem, as pessoas anotam, as pessoas vêm.
[155:37] E aí a gente cria um engajamento continuo.
[155:39] Como que eu crio
[155:41] um engajamento continuo?
[155:43] Percebem que o tempo todo
[155:45] eu falo com vocês aqui?
[155:47] Percebem que o tempo todo
[155:49] eu interajo com vocês?
[155:51] Eu trago para a percepção de vocês,
[155:53] que vocês fizeram isso.
[155:55] Quanto de vocês pensa ali na última vez
[155:57] que você fez tal coisa?
[155:59] Pensa ali na última vez que você fez,
[156:01] você já tentou fazer isso aqui?
[156:03] Pensa que você não me responda
[156:05] dentro do chat,
[156:07] você vai responder mentalmente.
[156:09] Alguém aqui respondeu alguma pergunta
[156:11] que eu fiz hoje mentalmente?
[156:13] Tenho certeza que vários de vocês.
[156:15] E aí isso cria o que?
[156:17] Engajamento continuo.
[156:19] O engajamento é o que?
[156:21] O que você está falando?
[156:23] E aí eu crio mais uma coisa.
[156:25] Então primeiro eu captei a atenção,
[156:27] chamei a atenção. Bum, está todo mundo
[156:29] prestando atenção. E aí eu faço o que?
[156:31] Eu crio o engajamento, a pessoa começa a interagir.
[156:33] Pode ver, quando você não interage em algo
[156:35] você começa a ter sono.
[156:37] Quem não está prestando atenção nessa aula
[156:39] está começando a ter sono.
[156:41] Quem realmente está prestando atenção
[156:43] está falando assim, caraca, nem parece
[156:45] que já são 10, 42.
[156:50] Então quando você tem um engajamento
[156:52] você consegue fazer com que as pessoas
[156:54] elas criem essa percepção
[156:56] de tempo de, porra,
[156:58] caraca, que legal, eu estou participando.
[157:00] E aí eu venho para um outro ponto,
[157:02] gerar percepção de aprendizado.
[157:04] Então vamos lá, objetivos sequenciais,
[157:06] capturar e manter a atenção, criar
[157:08] engajamento continuo e gerar
[157:10] percepção de aprendizado. Como que eu
[157:12] gera percepção de aprendizado, Gustavo?
[157:14] Cara, em sites práticos que elas podem aplicar
[157:16] no dia a dia.
[157:18] Cara, aplica isso na sua empresa, vai dar certo.
[157:20] Você já vai ver o resultado.
[157:22] E aí você vai dar vários insights
[157:24] que essa pessoa pode aplicar
[157:26] e ela vai sentir a vontade de sair
[157:28] da cadeira e aplicar. Eu tenho certeza
[157:30] que hoje, durante a nossa aula, durante
[157:32] todo esse período, você já tiveram
[157:34] vários insights que você, porra,
[157:36] que vontade de sair da cadeira e fazer isso
[157:38] que o Gustavo falou para mim.
[157:40] Que vontade de sair da cadeira e realmente
[157:42] participar disso que o Gustavo me trouxe.
[157:44] E aí você vai gerando
[157:46] essa percepção de aprendizado.
[157:48] Anota uma frase e essa frase foi
[157:50] a minha mulher que me ensinou.
[157:55] Nada, nada gera
[157:57] mais urgência do que esperança.
[157:59] Esperança gera urgência. Eu amo
[158:01] essa frase. Sabe por que a esperança
[158:03] gera urgência?
[158:05] Porque se a pessoa tem
[158:07] a percepção de aprendizado
[158:09] e aprendizado real e prático para a vida
[158:11] dela, ela tem vontade de
[158:13] aplicá-lo imediatamente.
[158:15] O viés de
[158:17] conformação dela tem vontade de ligar na hora.
[158:19] É muito louco, né, Jefferson?
[158:21] Então, quando a gente tem
[158:23] essa percepção de aprendizado e a gente
[158:25] precisa passar isso dentro do evento, ainda
[158:27] não estou falando da estrutura do conteúdo, estou
[158:29] falando que tem que ter
[158:31] em cada objetivo, o objetivo
[158:33] sequencial que você tem que ter. Então,
[158:35] primeiro eu vou gerando essa percepção
[158:37] de aprendizado. E aí eu vou fazendo
[158:39] essas pessoas terem
[158:41] essa vontade de agir.
[158:43] E aí depois que eu faço essa pessoa ter
[158:45] vontade de agir, aí eu coloco
[158:47] um monte de coisa que ela não explora
[158:49] dentro da empresa dela.
[158:51] E aí quando eu começo a colocar
[158:53] um monte de coisa e eu elevo o nível de
[158:55] consciência do meu público, de um monte de coisa
[158:57] que ela não explora, ela chega na reunião como?
[158:59] Caraca!
[159:01] Gustavo, você falou aquilo, aquilo outro,
[159:03] eu não faço isso, eu queria fazer, e aí
[159:05] você coloca um monte de coisa, você desperta
[159:07] a consciência dessa pessoa e essa pessoa
[159:09] que tem a consciência não explorada
[159:11] que tem essa
[159:13] consciência de oportunidades não exploradas,
[159:15] o que vai acontecer com ela?
[159:18] Ela vai ter plena ciência,
[159:20] ela vai ter plena convicção
[159:22] de que tem muito
[159:24] processo para melhorar.
[159:26] De que o seu produto, o seu serviço, o que
[159:28] você faz, não sei, o Gabriel ainda
[159:30] está online aí?
[159:32] Gabriel, seu produto de recorrência, ele é incrível.
[159:34] Por mais que eu acho que você
[159:36] está vendendo ele de um jeito mais estranho,
[159:38] mas seu produto, ele é incrível.
[159:40] E se a gente pega esse produto e a gente
[159:42] gera a consciência sobre oportunidades
[159:44] da pessoa, por exemplo, cara, você não vai ter mais custo de funcionário,
[159:46] você não vai ter mais custo disso, daquilo, daquilo outro
[159:48] e aí você vai colocando várias coisas
[159:50] que eles têm ali e aí a gente coloca
[159:52] po, imagina a oportunidade de você ter isso,
[159:54] de você fazer isso, de você reformar isso,
[159:56] de você ter aquilo outro e aí você vai colocando
[159:58] um monte de oportunidades que elas não exploram
[160:00] e a cabeça dela vai explodindo
[160:02] e ela já tinha aquela sensação de aprendizado
[160:04] e aí vai acontecendo com ela e ela vai fazer
[160:06] cara,
[160:08] que doideira esse evento,
[160:10] que doideira isso que está acontecendo comigo
[160:12] e tudo isso que eu falei pra vocês
[160:14] vai gerar um sentimento
[160:16] vai motivar pra uma ação concreta
[160:18] e aí quando você motiva seu cliente
[160:21] pra uma ação concreta, sabe o que que acontece?
[160:23] vai acontecer uma coisa muito estranha pra você
[160:27] eles vão precisar de de alguma forma
[160:29] e olha o que acontece quando eles agem
[160:31] a sua agenda ela fica assim
[160:33] lotada
[160:35] a gente nem começou a semana que vem
[160:37] e olha como que está a minha agenda
[160:39] da semana que vem
[160:43] e ainda a gente parte pra esse ponto
[160:45] e a gente gera essa motivação pra ação
[160:47] a gente tem que dar o que essa pessoa vai agir
[160:49] a gente tem que dar o passo
[160:51] pra essa pessoa agir
[160:53] e essa vem a minha diferença da minha metodologia
[160:55] pra todos os metodologias de webinário
[160:57] eles vão vender ali
[160:59] um produto, alguma coisa
[161:01] dentro desse evento, eu não, eu vou vender a minha reunião
[161:03] eu vou falar cara, sabe tudo isso que eu falei pra você
[161:05] eu tenho uma solução que a gente vai
[161:07] implementar tudo isso
[161:09] mas eu quero conhecer a sua empresa
[161:11] individual e ela tem processos
[161:13] que nenhuma outra tem
[161:15] que ela vende coisas que nenhuma outra vende
[161:17] que ela tem nuances que nenhuma outra tem
[161:19] mas eu quero avaliar isso e eu quero te mostrar isso
[161:21] e como você pode comprar isso
[161:23] ou como você pode solucionar isso
[161:25] e eu tenho uma solução pra isso também
[161:27] e aí eu quero te apresentar, eu te apresentando
[161:29] se fizer sentido e a gente conseguir mapear
[161:31] tanto isso que eu falei pra você
[161:33] mas o meu produto também faz sentido
[161:35] a gente fecha uma parceria e a gente faz alguma coisa junto
[161:37] marco um dia um horário com uma pessoa
[161:39] e tudo mais, cara
[161:41] o meu motivar a ação concreta
[161:43] é chamar essa pessoa pra uma reunião
[161:47] eu nunca mais tive no show
[161:49] eu nunca mais tive um lead desinteressado dentro
[161:51] de uma reunião, que venham de um webinário
[161:53] cara, é muito difícil
[161:55] muito difícil
[161:57] muito de vocês já fizeram reuniões comigo
[161:59] pós o webinário
[162:01] próprio Gabriel que eu estou citando aqui, ele já fez
[162:03] reunião comigo pós o webinário
[162:05] ele falou cara, aquilo que tu falou faz sentido
[162:07] nisso, nisso, nisso
[162:09] ele já fez reunião comigo e entendeu que eu tinha pra falar pra ele
[162:11] e às vezes o que eu tinha pra falar pra ele
[162:13] eu falei, Gabriel, você não precisa mudar tudo isso não
[162:15] muda só esse ponto aqui, já vai dar certo
[162:17] ele falou, caraca, verdade
[162:21] então, o que eu falo pra vocês é
[162:23] vocês
[162:25] vão condensando essa atenção
[162:27] vocês vão fazendo com que seu público
[162:29] ele tem a vontade de dirigir e aí você pega essa motivação
[162:31] concreta, que eles estão cheios de vontade
[162:33] de fazer esse
[162:35] faz comigo, sua solução
[162:39] e aí essas pessoas, elas vão conversar com você
[162:41] e aí você vai marcar
[162:43] 50, 150
[162:45] 200, 300, 400 reuniões por mês
[162:47] com isso
[162:49] beleza
[162:51] e aí vem a parte de roteiro de eventos
[162:53] pessoal, eu não vou conseguir passar
[162:55] tudo o que a gente pode fazer dentro de um evento
[162:57] beleza, não vou conseguir
[162:59] mas eu prometi pra vocês
[163:01] que eu vou entregar aquela aula lá de Webinário de alto impacto
[163:03] e nessa aula de Webinário de alto impacto
[163:05] vocês já vão ter
[163:07] ali, nos mínimos detalhes
[163:09] pra vocês escreverem um evento de vocês
[163:11] beleza, agora o que eu tô fazendo
[163:13] é pra vocês iniciarem os primeiros eventos do zero
[163:15] fechou, a gente pode fazer esse acordo
[163:17] vocês ganham ali essa aula
[163:19] de duas horinhas e tudo mais
[163:21] porque hoje tem muito conteúdo pra passar
[163:23] e todo mundo falou, caraca, você tem conteúdo pra 8
[163:25] horas de aula, eu falei, cara, eu acho que
[163:27] eu precisaria de mais umas 10 mano
[163:29] porque é muita coisa
[163:31] de verdade, muita coisa
[163:33] e eu não tô enrolando, eu acho
[163:35] então, quando a gente cria isso
[163:37] eu vou até passar os blocos
[163:39] ali que você precisa dentro de seu Webinário
[163:41] ali eu passei os objetivos
[163:43] aqui eu vou passar os blocos
[163:45] e qual emoção você espera em cada bloco
[163:47] então, primeira coisa
[163:49] abertura, vocês vão ver que vai bater
[163:51] com o que eu passei com a sequência ali
[163:53] com a sequência de objetivos
[163:55] abertura, qual que é a primeira coisa
[163:57] que a gente faz? Indentificação e promessa
[163:59] cara, eu entendo vocês, qual é disso, eu também sou vendedor
[164:01] eu também sei, eu também isso
[164:03] eu vi que tinha um problema, blá blá blá
[164:05] e nessa pra vocês é que eu não vou vender nada aqui
[164:07] eu vou entregar um conteúdo de qualidade
[164:09] que provavelmente vai estudar a cabeça de vocês
[164:11] bom, promessa
[164:13] e quando eu falo, eu não vou vender nada aqui
[164:15] e fica tranquilo, eu escuto o que eu tenho pra falar
[164:17] o que que eu faço, eu abaixo as defesas dessa pessoa
[164:19] então, a emoção que eu quero ali
[164:21] o ponto que eu quero pra essa pessoa
[164:23] nesses primeiros 5 minutos é somente a atenção
[164:25] a única coisa que eu quero do meu público
[164:27] nos primeiros 5 minutos é a atenção
[164:29] eu não quero mais nada
[164:31] eu não quero que eles me achem incrível
[164:33] eu quero que eles tenham atenção
[164:35] e eu vou fazer o que eu precisar
[164:37] pra fazer que o meu público tenha a minha atenção
[164:39] ou que o meu público preste atenção nos primeiros 5 minutos
[164:41] e aí a gente vem pro próximo bloco
[164:43] que é a primeira revaluação
[164:45] conceito simples e potente
[164:47] surpresa, sabe aquela surpresa
[164:49] sabe aquele conteúdo, cara
[164:51] você não precisa de tráfego pago pra vender
[164:53] eu fiz, eu resolvi esse problema, blá blá blá
[164:55] sabe aquilo que eu falei sobre o seu produto
[164:57] sabe aquela resolução ali que eu falei
[164:59] lá em cima pra você fazer
[165:01] nessa parte você precisa passar um conceito
[165:03] simples
[165:05] que se você falar, ele vai
[165:07] bater com a crença do seu cliente
[165:09] e vai ser super potente porque ele vai ficar
[165:11] surpreso com o que você vai falar
[165:13] eu vou exemplificar
[165:15] quando eu falo pra clínica
[165:17] e eu abro
[165:19] o evento de clínica
[165:21] eu falo assim cara, nada adianta você investir
[165:23] na tua empresa porque eu tenho empresa isso aqui
[165:25] é um balde furado
[165:27] você coloca água, água, água, água nele
[165:29] você está vazando por causa disso, disso, disso
[165:31] quer um exemplo?
[165:33] que a gente consegue resolver?
[165:35] sabe aquele cliente que te chama e nunca mais te responde
[165:37] no WhatsApp, alguém de você já passou por isso
[165:39] pô eu passei por isso
[165:41] eu consigo resolver ele assim e assim e assim
[165:43] cara eu trago um conceito simples que surpreende
[165:45] a pessoa e ela fica caraca mano
[165:47] esse cara realmente é bom
[165:49] então essa sensação de surpresa
[165:51] faz com que a pessoa é lá, cara
[165:53] primeiro eu chamei a atenção
[165:55] depois que eu fiz essa surpresa
[165:57] qual que foi a primeira coisa que eu fiz?
[165:59] eu fiz uma revelação
[166:01] eu fiz uma revelação sobre qual motivo
[166:03] essa pessoa está passando pelos problemas que ela tem
[166:05] e aí essa revelação
[166:07] que eu fiz com essa pessoa, ela vai abrir um leque
[166:09] de possibilidades na cabeça dela
[166:11] e aí nesse leque de possibilidades
[166:13] que eu abri na cabeça dela, eu vou gerar atenção
[166:15] cenários de consequências reais
[166:17] desconforto produtivo, o que eu vou fazer?
[166:19] eu vou amplificar a dor
[166:21] eu vou falar assim, cara, se tu não fizer isso
[166:23] vai ser uma merda
[166:25] o teu processo vai continuar assim
[166:27] vai continuar bagançado
[166:29] você sempre vai acontecer isso com você
[166:31] a consequência disso é isso
[166:33] a consequência daquilo outro é aquilo aqui
[166:35] então eu vou fazendo várias coisas
[166:37] que vão gerar atenção no seu público
[166:39] e aí a grande pergunta que eu trago pra vocês é
[166:41] o que gera atenção no seu público?
[166:43] o que gera atenção, quais são as crianças
[166:45] quais são as coisas que você fez na primeira revelação
[166:47] que vai gerar uma atenção no seu público
[166:49] quais são as consequências
[166:51] das coisas que o seu público não resolve
[166:53] que vai gerar uma atenção nele
[166:55] e aí eu faço propositalmente
[166:57] durante cinco minutos eles se sentirem desconfortáveis
[166:59] então
[167:03] dentro desses cinco minutos que eu faço
[167:05] eles se sentirem desconfortáveis
[167:07] aí eu já vou para a próxima etapa
[167:09] que é a liberação
[167:11] na prática deixa eu te mostrar como a gente resolve isso
[167:13] por que que eu faço isso?
[167:15] porque se eu amplifico a dor
[167:17] antes de mostrar a prática
[167:19] a vontade de agir aumenta
[167:21] deixa eu exemplificar isso
[167:23] cara, se eu ensino vocês
[167:25] um alongamento
[167:27] para aliviar a dor na coluna
[167:29] pô, é bacana
[167:31] e aí esse alongamento é diferente de tudo
[167:33] caraca, você sabe que bacana esse alongamento
[167:35] mas você não está com dor na coluna
[167:37] então você não vai ficar com tanta vontade
[167:39] de realmente executar isso
[167:41] agora
[167:43] se eu demonstro para você que você está com uma puta dor na coluna
[167:45] e aí você fala, caraca eu estou mesmo morrendo de dor na coluna
[167:47] e aí depois eu mostro
[167:49] o alongamento para você realmente resolver
[167:51] a dor na coluna
[167:53] como que vai ficar a tua
[167:55] percepção? cara, eu preciso muito fazer isso
[167:57] a pessoa vai se aliviar
[167:59] caraca, então tem isso, então tem solução
[168:01] então a solução é essa
[168:03] então eu gero alívio
[168:05] esperança, deu para entender
[168:07] por que que eu gera atenção?
[168:10] até que todo mundo entendeu
[168:12] eu gera atenção, depois eu gera a liberação
[168:14] e aí eu vou para uma segunda
[168:16] revelação
[168:18] que é literalmente uma demonstração ou caso
[168:20] eu demonstro exatamente como que essa pessoa faz isso na prática
[168:22] sabe quando eu demonstro
[168:24] se você substituir um evento
[168:26] ou uma reunião
[168:28] por um evento
[168:30] ou se você fizer o seu CRC assim assim assim
[168:32] ou se você fizer tal coisa assim
[168:34] cara, quando eu demonstro
[168:36] uma prática, uma coisa prática, um caso
[168:38] de sucesso ou uma demonstração
[168:40] de como essa pessoa vai fazer isso, o que eu gerei nela
[168:42] eu gerei confiança, então a emoção que eu quero
[168:44] nesses 10 minutos alí
[168:46] antes do meu evento acabar
[168:48] 10 minutos antes dos 10 minutos
[168:50] do evento acabar, é confiança
[168:52] que essa pessoa confia que eu sou a pessoa certa
[168:54] para resolver isso
[168:56] e aí vem o chamado, que é o próximo passo lógico
[168:58] que eu não preciso fazer um pitch
[169:00] mirar bolante
[169:02] e olha que louco isso tá
[169:04] muitas das vezes a gente vê as caras
[169:06] da internet
[169:08] cara, às vezes eu vejo pitch de 20 minutos mano
[169:10] eu acho louco, cura isso
[169:12] o que é que já assistiu um lançamento?
[169:14] o cara fica 20 minutos em pitch
[169:18] eu não tenho essa paciência não
[169:20] e aí o meu pitch fica tão fácil
[169:22] porque todo o meu processo conduziu
[169:24] meu cliente conscientemente pro pitch
[169:26] eu falo assim cara, vamos resolver isso
[169:28] cara, se eu literalmente falar só isso
[169:30] vamos resolver isso
[169:32] marco o bate-papo, eu vou te falar o que você
[169:34] precisa fazer, eu vou te falar o que a gente
[169:36] pode fazer pra você enquanto de horário
[169:38] e a gente vai resolver isso
[169:41] eu juro pra você, se eu fizer só esse pitch aqui
[169:43] eu vou marcar um monte de reunião
[169:45] porque é simples
[169:47] e acabou
[169:51] eu coloquei de 5 a 10 minutos e ainda acho muito
[169:53] porque eu falo isso, eu faço pitch
[169:55] e depois eu faço discurso motivacional
[169:57] falando de outras coisas
[169:59] mas assim, o pitch não é pra demorar
[170:01] porque ele é uma consequência lógica
[170:03] o próximo passo é lógico
[170:05] cara, se eu mostrei que o Gustavo
[170:07] ele resolve um problema que eu tenho
[170:09] e esse problema eu não vou conseguir resolver sozinho
[170:11] ele tem uma solução boa e ele vai me adiogandar
[170:13] pra mim ter essa solução boa
[170:15] e ele me convidou pra um bate-papo
[170:17] entenderam?
[170:20] fez sentido?
[170:22] até aqui ok, vocês entenderam
[170:24] essa parte de criar o primeiro evento de vocês
[170:26] Gustavo, isso daqui
[170:28] não tem algo prático que eu vou fazer e vou criar
[170:30] meu evento aqui, só de olhar pra você
[170:32] Gustavo, você não falou a palavra
[170:34] falar isso no momento tal
[170:36] e bla bla bla bla, não
[170:38] porque eu estou realmente ensinando vocês
[170:40] dentro de uma era de IA
[170:42] eu quero que realmente vocês aprendam
[170:44] eu vou ser o cara que mais vai falar
[170:46] eu vou ser o cara, o aprendizado com IA
[170:48] nos próximos tempos
[170:50] eu não sou contra usar a inteligência artificial
[170:52] eu sou contra as pessoas em burro e cema
[170:56] as pessoas estão ficando burras
[170:58] elas não pensam mais
[171:00] antigamente quando a gente consumia conteúdo na internet
[171:02] sabe porque a gente tinha mais resultado
[171:04] do que as pessoas que consomem hoje
[171:06] porque o conteúdo
[171:08] ele não era tudo machigadinho
[171:10] eles ensinavam o conceito
[171:12] eles ensinavam a fazer
[171:14] eles ensinavam, eles mostraram um caminho
[171:16] a gente ia lá e fazia o caminho
[171:21] acabou
[171:23] não era copia e cola
[171:25] cara, o copia e cola sempre vai ser
[171:27] cara, quando você copia e cola
[171:29] algo de alguém exatamente a mesma coisa
[171:31] você sempre vai desperdiçar
[171:33] o potencial que você tem dentro de você
[171:35] sempre vai desperdiçar o potencial que a sua empresa tem
[171:37] você sempre vai limitar o seu crescimento
[171:39] no copia e cola
[171:41] aprenda, cara
[171:43] deixa eu aprender o que essa empresa está fazendo
[171:45] deixa eu aprender o que o Gustavo está fazendo
[171:47] deixa eu aprender qual é a lógica do Gustavo
[171:49] para um evento para eu fazer o meu
[171:51] beleza, e aí sim eu faço
[171:53] fechou?
[171:55] pessoal, até aqui alguma dúvida sobre
[171:57] a parte 3
[171:59] mapa 0, seu primeiro evento
[172:02] cara, agora escrevam o seu evento com base
[172:04] nisso aqui
[172:06] nisso aqui
[172:11] escrevam o seu evento com tudo que vocês aprenderam
[172:13] escrevam todos esses processos
[172:15] pega esse mapa mental depois
[172:17] escreve com base nisso aqui
[172:19] fechou?
[172:21] ok?
[172:23] com base nisso aqui
[172:25] e aí vocês vão escrever o evento de vocês
[172:27] pessoal, alguém tem alguma dúvida?
[172:29] se quiser abrir um microfone é só levantar a mão
[172:31] que a gente libera e depois a gente coisa
[172:33] alguém quer
[172:35] tirar alguma dúvida, quer realmente mandar
[172:37] uma mensagem no chat
[172:39] para perguntar alguma coisa
[172:41] deixa eu parar a apresentação
[172:43] para esse stop para ir para a próxima aula
[172:45] deixa eu beber uma água
[172:52] beleza, ninguém tá com dúvida?
[172:54] a galera tá dormindo então
[172:56] bora lá
[172:58] é isso sem prever o que isso poderia acontecer
[173:00] cara, antonio
[173:02] eu fico muito feliz toda vez que
[173:04] eu vejo uma IA avançando
[173:06] porque eu sei que eu vou usar isso
[173:08] para otimizar o meu resultado
[173:10] e meu concorrente vai usar isso para ficar mais burro
[173:12] então toda vez que surge
[173:14] uma tecnologia, caraca
[173:16] meu concorrente vai ficar mais burro
[173:18] e eu vou ficar mais produtivo
[173:20] então comemore
[173:22] se você é uma pessoa
[173:24] que é intelectualmente
[173:26] e pessoas intelectuais
[173:28] na verdade
[173:30] que eu coloco, não são pessoas que
[173:32] nossa, é uma pessoa culta
[173:34] que lê um monte de livro
[173:36] não, pessoas intelectuais na minha versão
[173:38] na minha tradução, o que é uma pessoa intelectual
[173:40] para o Gustavo? são pessoas
[173:42] que buscam realmente aprender, entender
[173:44] e conseguir fazer algo
[173:46] não de forma superficial
[173:48] mas que elas consigam entender algo profundamente
[173:50] tá, que elas saem
[173:52] ali da primeira camada
[173:54] elas vão ali realmente até o fundo
[173:56] para entender como aquela coisa funciona
[173:58] beleza, e isso são pessoas intelectuais
[174:00] para mim
[174:02] sabe o que está fazendo exatamente
[174:04] então, pessoas intelectuais
[174:06] elas vão ganhar das pessoas realmente
[174:08] ali que não pensam nos próximos anos
[174:10] a única vantagem
[174:12] do burro é que ele
[174:14] executa sem questionar
[174:16] essa é a maior vantagem do burro
[174:18] e a única que você tem que modelar
[174:20] ele vai executar sem questionar
[174:22] e ele vai executar um processo
[174:24] muitas das vezes que, tipo assim
[174:26] tá, esse cara me passou, vou executar isso que ele falou
[174:28] por exemplo, se tem alguém
[174:30] que tem um costume, cara, que eu falar
[174:32] que a pessoa é burra, eu sou burro também
[174:34] em muitas coisas, tá
[174:36] quando eu identifico que eu sou burro
[174:38] em algum aspecto diferente
[174:40] ou não tenho conhecimento de alguma coisa
[174:42] naquela coisa que está falando
[174:44] então, existem coisas que a gente é burro
[174:46] e existem coisas que a gente é intelectual
[174:48] e a gente é inteligente e a gente realmente consegue
[174:50] discernir
[174:52] então, a única vantagem da pessoa burra
[174:54] é que ela vai pegar aquilo que a pessoa inteligente
[174:56] falou pra ela
[174:58] e aí, olha que louco, ela deixa de ser burro
[175:00] quando ela faz isso
[175:02] e aí ela executa aquilo sem pensar
[175:04] e vai executando infinitamente
[175:06] e ela tem muito resultado
[175:08] por isso que muita gente que você considera
[175:10] porque ela simplesmente executa muito mais que você
[175:12] porque ela executa sem pensar
[175:14] às vezes eu estou passando isso pra cá
[175:16] e aí o maior defeito do intelectual é isso também
[175:18] ele vai pegar isso que eu falei pra vocês
[175:20] e ao invés de ele aplicar
[175:22] isso que eu estou falando pra vocês, ele vai pensar
[175:24] nossa, peguei tudo que o Gustavo falou
[175:26] agora eu vou modelar tudo e vou refazer tudo
[175:28] de uma maneira melhor ainda
[175:30] parabéns, é o caminho mais rápido
[175:32] pra você pra caçar e se frustrar
[175:34] e não ter um sucesso
[175:36] é mais fácil você pegar, ter micro resultados
[175:38] e depois você enxergar últimas ações
[175:40] e melhorar o que já estão funcionando
[175:42] então, bora lá
[175:44] deixa eu dar o co-organizador
[175:46] pro Antônio
[175:48] na real eu vou liberar o microfone de todo mundo
[175:50] que é mais fácil aqui
[175:52] na hora que eu voltar a
[175:54] dar a outra aula
[175:56] eu já tiro esse microfone
[175:58] só deixa eu achar onde que tá isso
[176:00] configuração
[176:02] já fiz aqui
[176:04] Antônio, pode abrir o microfone
[176:06] bora
[176:08] pessoal, primeiramente
[176:10] obrigado por compartilhar com a gente
[176:12] essa informação, esse conteúdo tá incrível
[176:14] parabéns mesmo, Deus abençoe a vida de você
[176:16] por ter tomado esse iniciativo
[176:18] e queria abrir o microfone
[176:20] pra falar sobre o que o John
[176:22] acabou de perguntar no chat
[176:24] e eu tive um cliente no passado
[176:26] que ele vendia produto encapsulado
[176:28] e aí ele vivia muito com
[176:30] na verdade já era um problema que eu passava
[176:32] tinha muito problema com bloqueio
[176:34] porque a oferta era black, era muito agressiva
[176:36] e tal
[176:38] e diante do que eu aprendi
[176:40] estou aprendendo aqui nessa aula
[176:42] se eu preparo um ebina
[176:44] pra um doutor
[176:46] falar sobre uma dor
[176:48] específico, vou dar um exemplo
[176:50] disfunção erética
[176:52] é uma dor que tem muito no nosso caso
[176:54] só um adendo, pode terminar
[176:56] sua pergunta
[176:58] mas eu vou falar o título
[177:00] do próximo aula
[177:02] das suas produtos e serviços
[177:04] mas pode perguntar
[177:06] e aí o cara faz um ebina
[177:08] trazendo as pessoas que têm esse tipo
[177:10] de problema pra dentro do ebina
[177:12] e o doutor fala sobre os ativos
[177:14] como melhorar o processo
[177:16] é com certeza esse cara vai fazer venda
[177:18] dentro do ebina de um produto físico
[177:20] não é um serviço que a gente tá fazendo
[177:22] então eu vou responder a pergunta do John
[177:24] e acredito que isso funcionaria muito bem
[177:26] vamos lá, gente, tem algumas maneiras
[177:28] de vocês fazerem isso
[177:30] ele funciona em todas as situações
[177:32] ele funciona mas tem situações que é melhor
[177:34] você não fazer, existem funis melhores
[177:36] para algumas outras situações
[177:38] respondendo a pergunta de novo
[177:40] tem como eu fazer um ebinário
[177:42] de prospecção ativa
[177:44] pra vender um produto físico
[177:46] ou pra vender um produto final
[177:48] tem se a gente transforma isso em bitio bitio C
[177:50] mas eu vou explicar pra vocês
[177:52] e vou explicar alguns conceitos pra vocês
[177:54] se eu for fazer um ebinário pra produto físico
[177:56] eu vou provavelmente trazer esse ebinário
[177:58] às pessoas desse ebinário por tráfego pago
[178:00] tem como você trazer ela sem tráfego pago
[178:02] mas eu já vou explicar isso mais pra frente
[178:04] mas você vai trazer essas pessoas
[178:06] e aí o scope ele continua o mesmo
[178:08] você fala sobre um problema, sobre uma solução
[178:10] fala como ela pode solucionar isso naturalmente
[178:12] se não precisa, e aí o maior erro das pessoas
[178:14] é, nossa, meu produto é a única solução
[178:16] pra seu problema, não é?
[178:18] a terra tá aí, Jesus Cristo tá aí
[178:20] a gente nasceu há muito tempo atrás
[178:22] a gente veio de muito tempo atrás
[178:24] e já existiam soluções pra esses problemas
[178:26] então a sua solução não é a única
[178:28] as pessoas já resolviam isso de alguma forma
[178:30] elas já tratavam, elas já faziam isso de alguma forma
[178:32] então você precisa entender
[178:34] o seu evento pode ser coisas que a pessoa pode aplicar naturalmente
[178:36] mas que vão exigir esforço dela
[178:38] então, por exemplo, eu vou fazer um ebinário de emagrecimento
[178:40] eu posso falar sobre várias coisas que essa pessoa precisa fazer
[178:42] pra ativar certo mecanismo
[178:44] dentro do corpo dela que vai fazer ela emagrecer
[178:46] eu falo de milhares de exercícios
[178:48] eu falo de centâner de coisas
[178:50] falo de centâner de coisas que fazem sentido pra ela ativar isso daí
[178:52] ou sei lá, um certo hormônio
[178:54] alguma coisa específica dentro da genética dela
[178:56] eu não sei, não entendo desse assunto
[178:58] mas eu posso fazer um evento que eu falo sobre isso
[179:00] como ela ativa isso naturalmente
[179:02] no final eu falo assim, pra quem não quer
[179:04] ter todo esse esforço
[179:06] e não tem tempo pra ter todo esse esforço
[179:08] a gente consegue fazer isso com esse produto aqui
[179:10] acabou, eu consigo fazer a venda desse produto
[179:12] e isso encaixa ali com o que eu falei
[179:14] mas quando a gente vai pra certos nichos
[179:16] por exemplo, Pô, Gustavo
[179:18] você faria um ebinário pra clínica de estética?
[179:20] cara, eu não faria um ebinário pra clínica de estética
[179:22] cara, eu não faria um ebinário pra clínica de estética
[179:24] num sentido que vocês pensam
[179:26] por exemplo, eu tenho uma cliente que vem de botox
[179:28] o ebinário seria interessante pra ela
[179:30] vamos lá, o que eu faria?
[179:32] se a clínica, ela tem uma profissional
[179:34] que ela é muito renomada e ela é muito boa
[179:36] por exemplo, em estética
[179:38] ela é muito boa em estética e ela tem uma comunicação
[179:40] você sente que ela tem uma autoridade
[179:42] pra ser uma profissional, pra ser uma especialista
[179:44] o que eu faria na situação dela
[179:46] caso você queira fazer eventos
[179:48] e caso você não queira que os seus leads
[179:50] ou as clientes, as pacientes dela
[179:52] venham ali de qualquer jeito
[179:54] gente, isso aqui é muito importante
[179:56] isso vai trazer uma autoridade, uma visão de mercado
[179:58] muito diferente pra vocês
[180:00] eu não faria o ebinário nem pra agendar visitas
[180:02] e nem pra realmente vender um produto
[180:04] eu faria o ebinário pra quê? pra ela educar
[180:06] mulheres sobre estética
[180:08] então, com o tempo, eu ia criar uma comunidade
[180:10] e a maior comunidade
[180:12] é a comunidade mais acessível pra esses especialistas
[180:14] sei lá, R$ 5 por mês
[180:16] olha que louco, eu ia pegar aquela cidade específica
[180:18] todo mundo quer dessa cidade específica
[180:20] vem percebendo que eu vou te dar dica de estética pra mulheres
[180:22] aí você fala de dica de estética pra mulheres
[180:24] e ela vai falando várias dicas práticas
[180:26] e aí todo mundo sabe que ela é dona daquele salão
[180:28] que ela faz essas dicas e que ela executa
[180:30] muitas das coisas
[180:32] e aí ela lança uma comunidade aonde ela tem aulas
[180:34] semanalmente, que ela dá dicas pra mulheres
[180:36] de estética que as pessoas pagam R$ 5 por mês
[180:38] é muito mais fácil, quando a gente
[180:40] tem um produto abaixo de R$ 5, eu vi o João
[180:42] adipo falando isso, eu não sei se é verdade
[180:44] mas eu acredito, um produto abaixo de R$ 5
[180:46] a pessoa ela compra sem pensar
[180:48] por exemplo, se eu fizer um pite de R$ 5
[180:50] agora eu tenho certeza que 100% das pessoas
[180:52] que estão aqui comprariam um pite de R$ 5
[180:54] quando a gente fala sobre um produto
[180:56] de R$ 5, ele é um produto de que?
[180:58] um produto de nutrição, o que eu montaria
[181:00] estar adionando? eu faria
[181:02] literalmente, essa comunidade
[181:04] eu tornaria esse especialista
[181:06] estética, é dona
[181:08] dessa comunidade o que acontece?
[181:10] eu tenho uma cidade de 300 mil habitantes
[181:12] sei lá, 100 mil habitantes são mulheres
[181:14] só que dessas 150 mil habitantes
[181:16] sei lá, 30 mil são meu público alvo
[181:18] e aí eu consegui colocar 20 mil
[181:20] dentro desse produto
[181:22] dentro dessa comunidade de mulheres
[181:24] onde todas elas conversam
[181:26] o que vai acontecer consequentemente com a minha clínica?
[181:28] é uma dúvida que eu trago pra vocês
[181:30] o que acontece consequentemente com a sua clínica?
[181:34] você lotou isso
[181:36] e essa é uma visão de mercado
[181:38] que você pode usar e que ninguém usa
[181:40] e eu sei que ninguém usa porque
[181:42] é uma das pessoas que estão usando isso
[181:44] eu utilizo isso, eu tenho alguns produtos
[181:46] que eu vendo em alguns eventos
[181:48] que é um produto de ticket baixo
[181:50] e eu vou usar esse produto pra que pra nutrir a galera
[181:52] pra vender muita coisa
[181:54] pra essas pessoas me terem como referência
[181:56] e elas me procurarem pra fazer um procedimento
[181:58] elas me procurarem pra fazer alguma coisa
[182:00] então quando vocês fizerem isso
[182:02] eu recomendo que vocês façam assim, beleza?
[182:04] então Gustavo, eu tenho um salão de beleza
[182:06] cara, vamos fazer uma comunidade
[182:08] R$ 5 que a mulher vai ter
[182:10] um cabelo diário
[182:12] nem toda mulher vai querer comprar
[182:14] o seu produto de primeira mão
[182:16] mas se ela é nutrida e se ela aprende com você
[182:18] sabe o que que a sua especialista vai se tornar
[182:20] vai se tornar um desejo
[182:22] cara, imagina se atendida
[182:24] por essa mulher aqui
[182:26] que faz esse cabelo
[182:28] por mais que eu consiga fazer sozinho
[182:30] nossa, imagina se atendida por ela
[182:32] imagina se atendida por essa pessoa que é referência
[182:34] e eu não tô falando de produzir milhares de conteúdos no instagram
[182:36] eu não tô falando disso
[182:38] eu tô falando com um evento
[182:40] você consegue convencer as mulheres com um evento
[182:42] e aí o que que eu vou colocar pra vocês
[182:44] isso serve pra quase qualquer profissão
[182:46] quase qualquer
[182:48] então Gustavo, serviria pra uma loja de ferramento?
[182:50] serviria se o dono fosse especialista
[182:52] falar de cuidar de casa e tudo
[182:54] mas assim, gente, tem estratégias melhores
[182:56] pra alguns nichos, é o que eu falo pra vocês
[182:58] então, você tem que avaliar primeiro
[183:00] será que é a melhor estratégia
[183:02] será que o público teria um puta engajamento nisso?
[183:04] faz uma pesquisa de mercado e faz uns testes
[183:06] outro ponto, e aí como que eu faço
[183:08] essa especialista, por exemplo, ter clientes
[183:10] sem necessariamente
[183:12] eu
[183:15] eu gastar dinheiro
[183:17] aí você pode fazer a prospecção bit by bit o si
[183:19] o que é bit by bit o si
[183:21] cara, você vai ter uma empresa
[183:23] essa empresa, ela tem...
[183:25] você vai poder prospecitar uma empresa
[183:27] essa empresa que você prospectou, ela tem mulheres
[183:29] mas esse é o primeiro passo e é o que todo mundo acha obvio
[183:31] mas essa empresa que tem mulheres
[183:33] essa empresa, ela tem interesse
[183:35] dessa empresa, é também a agradar cliente, certo?
[183:37] e se essa empresa
[183:39] ela dá de presente pra todos os clientes delas
[183:41] essa imersão com essa autoridade
[183:43] e aí você pode
[183:45] prospecitar com essa prospecção, você pega a base de leads
[183:47] você prospecita os clientes do seu cliente
[183:49] e aí você pode fazer isso também
[183:51] você pode postar no Instagram, pode usar o Instagram das pessoas
[183:53] então você pode prospecitar várias empresas
[183:55] e usar a base de clientes deles
[183:57] o que você tem que fazer? um mapeamento
[183:59] um mapeamento
[184:01] de realmente conexões
[184:03] eu tenho mulheres
[184:05] e eu sou uma clínica de estética
[184:07] e eu atuo exatamente com botox
[184:09] essas outras coisas
[184:11] quais são os lugares que as mulheres também frequentam?
[184:13] po, loja de roupas femininas
[184:15] então eu posso pegar e fazer parceria
[184:17] com loja de roupas femininas? todo mundo
[184:19] que compra uma roupa, ela vai ganhar
[184:21] um evento gratuito
[184:23] dentro desse...
[184:25] dentro dessa... com essa especialista
[184:27] pode
[184:29] ou você vai pegar e disparar
[184:31] todas as clientes dela que vai ter esse evento
[184:33] pode
[184:35] e olha que louco quando você traz isso
[184:37] você tá fazendo ali parcerias
[184:39] comerciais e aí você pega esses 5 reais
[184:41] que você ia ganhar, você dá pra essa pessoa
[184:43] só que os outros ali
[184:45] você vai ganhar muito mais com as pessoas
[184:47] que vão vir até você
[184:49] ou você dá uma parte, uma porcentagem, enfim
[184:51] tanto faz, eu tô dando um exemplo
[184:53] que eu criei agora
[184:55] mas o que eu quero falar pra vocês
[184:57] literalmente é, tem como você captar
[184:59] você só precisa de base de clientes
[185:01] pra você prospectar, você só precisa de base de clientes
[185:03] você precisa de um motivo, base de clientes
[185:05] e pessoas qualificadas
[185:07] a grande pergunta é, aonde que eu acho
[185:09] uma lista de pessoas
[185:11] qualificadas, eu vou postar
[185:13] vaga de emprego e não vou dar emprego
[185:15] eu vou chamar a pessoa pra um evento
[185:17] não, eu vou buscar no instagram um grupo de
[185:19] não, cara, você pode
[185:21] pegar uma empresa, uma loja de roupas
[185:23] um salão de beleza
[185:25] ou sei lá, você quer homem
[185:27] e aí você quer atender
[185:29] você tem uma DEGA e aí você vai fazer algum tipo de
[185:31] promoção, você vai fazer uma rifa
[185:33] dentro da sua DEGA ou dentro da sua distribuidora
[185:35] de cervejas
[185:37] qual que é a empresa que conecta com isso
[185:39] cara, eu posso fazer um evento pra barbearias
[185:41] pra essas barbearias divulgarem uma rifa
[185:43] dentro da
[185:45] do que a gente tá fazendo e ganharem
[185:47] essa parada
[185:49] e ganhar uma porcentagem disso
[185:51] e aí eu falo com todas as barbearias dentro da minha cidade
[185:53] todas elas indicam a rifa
[185:55] a minha distribuidora se torna mais conhecida
[185:57] e aí vai por aí vai
[185:59] então a gente consegue fazer esse bitio-bitio-si
[186:01] gente, eu sempre
[186:03] penso, lembra que eu falei que eu penso muito
[186:05] como que as pessoas faziam
[186:07] antes de o meu processo existir
[186:09] esses insights que eu tenho
[186:11] eles vêm antes do meu processo existir
[186:13] cara, o Flávio Augusto, ele ficou bilionário
[186:15] com venda de indicação e porta a porta
[186:19] ele só aumentou o time e ensinou
[186:21] o time deles a pedir indicação
[186:23] do que você chama
[186:25] Antônio, você topou o participado do evento
[186:27] Antônio, manda um número de mais cinco pessoas
[186:29] para me convidar para esse evento também
[186:31] tá bom, entendeu?
[186:34] beleza, até aqui tudo ok?
[186:38] respondido à dúvida aí Antônio, Jonathan
[186:40] boa, espero ter ajudado
[186:42] vou liberar aqui
[186:44] e vou iniciar a próxima aula aqui já
[186:46] fechou?
[186:48] pessoal, cara, eu tô gostando muito desse evento
[186:50] eu espero de verdade que vocês estejam gostando
[186:52] também porque eu tô gostando muito aqui
[186:54] de conduzir esse evento
[186:56] então vocês entendendo que o próprio web
[186:58] na área ele pode ser bit by bit o si
[187:00] esse próprio web na área que pode ser
[187:02] bit by bit o si, ele vai fazer com que
[187:04] vocês tenham uma base de leads
[187:06] de verdade mesmo, olha o que eu tô falando
[187:08] pra vocês, eu tô falando uma das coisas
[187:10] mais difíceis do mercado
[187:12] inclusive Edder, imagina os caras
[187:14] é que a maioria das pessoas elas
[187:16] ignoram isso, mas imagina os caras
[187:18] que você vê no dia a dia que são gigantes
[187:20] e o pessoal ouvindo isso também
[187:22] os caras iam ficar malucos, sabe por quê?
[187:24] porque o cara quando ele é muito grande
[187:26] e ele escuta esse tipo de ideia e ele fala assim
[187:28] cara eu vou pegar e vou fazer isso
[187:30] eu vou saturar isso aqui dentro do mercado
[187:32] quando o cara é muito grande e ele escuta algo
[187:34] que faz sentido e que realmente tem resultado
[187:36] ele fala assim cara eu vou saturar isso no mercado
[187:38] eu vou fazer até não dar mais
[187:40] aí depois que o cara é muito grande
[187:42] faz aí todos vocês falam assim
[187:44] nossa deveria ter feito, vou fazer agora
[187:46] que já tá todo mundo fazendo
[187:48] eu tô falando, pensem como gente grande
[187:50] pensem ali como grandes players
[187:52] fechou? inclusive
[187:54] tem um membro da V4
[187:56] aqui, tá? dentro desse evento
[187:58] muito bacana porque
[188:00] vocês já tentaram tá V4
[188:02] vocês já tentaram fazer esse evento uma vez
[188:04] e vocês falharam, eu espero que
[188:06] eu consiga ajudar vocês a fazer direito
[188:08] dessa vez, fechou meu lindo
[188:10] tô brincando cara
[188:12] o cara é meu amigo mas ele é da V4
[188:14] então a gente tem essa rivalidade mesmo
[188:16] fechou? então bora pra cima
[188:18] gente, agora
[188:20] vai vir uma parte
[188:22] muito foda, oh Leandro só faz um favor pra mim
[188:24] liga pro tito e pergunta se ele vai conseguir
[188:26] participar da entrevista
[188:28] do horário do almoço, vai começar
[188:30] meio de e-mail a entrevista
[188:32] com a Nuno, fechou?
[188:34] pergunta pra ele
[188:36] bora lá, como criar boas ofertas
[188:38] para os seus produtos e serviços
[188:40] então agora a gente vai vir no ponto
[188:42] gente, vender é muito bom
[188:44] fazer evento é muito bom
[188:46] fazer com que as pessoas assistam sobre
[188:48] seu evento, seu produto é muito bom
[188:50] mas melhor ainda é quando
[188:52] você cria uma oferta tão forte que o seu produto
[188:54] ele quase se vende sozinho
[188:56] algumas pessoas já ouviram falando sobre isso
[188:58] cara, um cara que mais me ensinou
[189:00] foi um cara chamado Alex Dormose
[189:02] foi um cara ali, um americano
[189:04] entrou pro Guinness Books, com o maior
[189:06] lançamento e menos tempo e tudo mais
[189:08] o cara é muito foda
[189:10] então quando ele me destravou nessa parte
[189:12] realmente para os meus produtos e serviços
[189:14] eu comecei a vender muito mais
[189:16] então eu misturei o que eu já sabia sobre vendas
[189:18] e misturei junto com oferta
[189:20] cara, tornou uma explosão, minha taxa de conversão
[189:22] foi lá em cima, você consegue escalar muito
[189:24] você consegue crescer muito
[189:26] e você entra no Oceano Azul
[189:28] onde ninguém compete com você no mercado
[189:30] beleza? então prestem muita atenção nessa
[189:32] parte para vocês criarem oferta de vocês
[189:34] a primeira coisa que vocês precisam entender
[189:36] da oferta, confirmado Nimooto
[189:38] beleza
[189:40] beleza
[189:42] bora lá
[189:44] bora lá
[189:46] equação do valor, a primeira coisa que vocês precisam
[189:48] entender para fazer uma boa oferta
[189:50] é equação do valor
[189:52] então essa equação do valor
[189:54] como ela funciona, qual é o valor do seu produto
[189:56] vou ensinar vocês a calcularem
[189:58] o quanto de valor tem esse produto, não o valor real
[190:00] mas o valor ali que vocês
[190:02] a percepção de valor que o seu cliente tem
[190:04] beleza? vamos lá
[190:06] o valor é igual o resultado
[190:08] vezes a percepção
[190:10] de probabilidade de sucesso
[190:12] dividido pelo tempo de espera
[190:14] versus o esforço e sacrifício
[190:16] então vou simplificar isso
[190:18] para quem não é bom em matemática
[190:20] para quem realmente
[190:22] não conseguiu compreender
[190:24] o resultado
[190:26] vezes a percepção de probabilidade de sucesso
[190:28] ou seja
[190:30] o valor é igual
[190:32] o resultado que essa pessoa vai ter
[190:34] ou seja, qual que é o resultado que seu cliente vai ter
[190:36] qual é o problema que você vai resolver
[190:38] para ele, é um problema de tempo, de dinheiro
[190:40] de realmente, sei lá
[190:42] organização, qual que é o problema
[190:44] que você vai resolver para ele, qual que é o resultado que você tem
[190:46] beleza
[190:48] você entrega esse resultado
[190:50] qual que é a percepção de probabilidade
[190:52] de sucesso que esse cliente tem
[190:54] sobre esse
[190:56] resultado que você vai entregar
[190:58] então ele percebe
[191:00] a probabilidade de sucesso disso que você vai entregar
[191:02] é alta
[191:04] é 100%
[191:06] vou vender a metrificação de uma empresa
[191:08] é 100%
[191:10] a probabilidade de sucesso de eu conseguir metrificar essa empresa
[191:12] beleza
[191:14] o resultado versus essa percepção
[191:16] sucesso já vai gerar um valor
[191:18] e o que que divide
[191:20] e que faz o seu valor diminuir
[191:22] ou seja, que faz o seu valor
[191:24] ele ficar menor
[191:26] o tempo de espera que esse cliente precisa
[191:28] para isso que isso seja executado
[191:30] versus o esforço
[191:32] e o sacrifício que ele precisa fazer para que aquilo aconteça
[191:34] então
[191:36] quanto menos esforço e sacrifício meu cliente
[191:38] fizer, mais valor ele vai enxergar
[191:40] quanto menos tempo ele precisar até o resultado
[191:42] mais valor ele vai enxergar
[191:44] entenderam? Então a fórmula seria
[191:46] resultado versus
[191:48] percepção de probabilidade de sucesso
[191:50] dividido por tempo
[191:52] de espera versus esforço e sacrifício
[191:54] é igual a um valor
[191:56] e aí o valor vai ser delimitado
[191:58] por isso
[192:00] então o resultado é desejado
[192:02] o que o seu cliente quer alcançar
[192:04] então vamos pelo resultado desejado
[192:06] fala aqui no chat para você já ir
[192:08] entreinando a mente de vocês
[192:10] qual que é
[192:12] o objetivo que seu cliente quer
[192:14] qual que é o final, o destino que seu cliente quer
[192:16] o resultado que ele quer alcançar
[192:18] ah Gustavo
[192:20] o resultado que o meu cliente
[192:22] quer alcançar
[192:24] sei lá, aumentar as vendas
[192:26] não, seja mais específico
[192:28] que você conseguir
[192:30] qual que é o resultado que seu cliente quer
[192:32] ah meu cliente quer vender mais
[192:34] gastando menos e tendo menos esforço
[192:36] beleza, esse é o resultado que ele quer
[192:38] meu cliente quer aumentar o faturamento dele
[192:40] em 30 mil reais
[192:42] em tantos dias
[192:44] sem ter que fazer isso
[192:46] ou meu cliente quer
[192:48] ganhar 30 mil reais a mais
[192:50] meu cliente quer chegar nos 20 mil reais
[192:52] então qual que é o resultado desejado desse cliente
[192:54] vender mais estar mais organizado
[192:56] no comercial, beleza
[192:58] o que seria vender mais, vender quanto a mais
[193:00] qual é o valor exato
[193:02] qual que é a organização do comercial
[193:04] qual que é a consequência da organização do comercial
[193:06] isso é a passagem, gente
[193:08] eu vou falar muito sobre isso na aula de closer
[193:10] mas eu preciso que vocês entendam
[193:12] beleza
[193:14] a passagem, ela é o que
[193:16] ela não é o que você vende
[193:18] a companhia aérea não existiria
[193:20] se as pessoas não soubessem o destino
[193:22] você tem que saber o destino do seu cliente
[193:24] cara eu vou comprar uma passagem
[193:26] ah pra onde, não sei
[193:28] então a pessoa fala
[193:30] nossa eu preciso para esse destino
[193:32] logo vou comprar uma passagem
[193:34] então o que eu estou falando aqui é do destino
[193:36] não da passagem
[193:38] a passagem ela é organizar o processo comercial
[193:40] e vender mais, beleza
[193:42] vender quanto a mais
[193:44] qual que é o objetivo desse cara
[193:46] agora sim
[193:48] qual que é o objetivo tangível
[193:50] o resultado desejado
[193:52] tem a
[193:54] 50 agendamentos a mais por mês
[193:56] isso é um resultado
[193:58] específico
[194:00] beleza, aqui está até um exemplo
[194:02] perder 10 quilos, então é um resultado específico
[194:04] não é treinar todos os dias
[194:06] é o resultado desejado
[194:08] fechou
[194:10] percepção de sucesso
[194:12] o quanto ele acredita
[194:14] que você pode entregar isso
[194:16] o quanto ele acredita que você consegue
[194:18] fazer ele emagrecer 10 quilos
[194:20] o quanto ele acredita que você consegue lotar a agenda dele
[194:22] com 50 reuniões
[194:24] o quanto ele acredita que você consegue
[194:26] fazer com que ele chegue
[194:28] naquele resultado específico
[194:30] se essa nota
[194:32] e aí você vai classificando
[194:34] por aqui de 0 a 10
[194:36] essa é o 10 ali o resultado desejado
[194:38] que ele quer
[194:40] e aí o que ele acredita que eu consigo fazer
[194:42] de 0 a 10 ele acredita 10
[194:44] cara está perfeito
[194:46] mas ainda não é uma venda garantida
[194:48] que a gente subtrai essas outras coisas
[194:50] o tempo de espera que ele tem
[194:52] e o esforço de sacrifício que ele tem que fazer
[194:54] gente o valor ele não é
[194:56] o preço está, ele não é o valor
[194:58] ou ele não é a coisa mais determinante
[195:00] para você fechar uma venda não
[195:02] inclusive a venda que eu fechei
[195:04] ontem
[195:06] que passou os 30 mil reais
[195:08] cara o cara
[195:10] ele comprou muito mais
[195:12] porque ele acreditava na gente
[195:14] ele entendeu o resultado final
[195:16] e o esforço dele sacrificia ser quase zero
[195:18] logo ele comprou da gente
[195:20] então o antonio falou assim
[195:22] preciso pesquisar mais sobre o meu cliente
[195:24] mesmo quando o cliente chega
[195:26] no resultado ele não pode
[195:28] ele não pode perceber
[195:30] que precisa mais de mim
[195:32] cara esse é um grande problema
[195:34] dos profissionais
[195:36] sabe qual que é o problema antonio
[195:38] a maioria dos profissionais estão pensando nisso
[195:40] cara se o meu cliente ele chegar no resultado
[195:42] e eu vender o resultado e não vender
[195:44] o produto, trabalho que eu faço
[195:46] dia a dia e tudo mais e eu vender o resultado final
[195:48] quando ele chegar no resultado final ele vai cancelar comigo
[195:50] cara
[195:52] o seu cliente ele não vai nem comprar de você
[195:54] se você não vender o resultado final
[195:56] se você não entender qual que é o resultado final
[195:58] qual que é o destino que ele quer chegar
[196:00] é isso, esse é o ponto
[196:02] ah e se ele chegar ali
[196:04] dentro do que ele quer
[196:06] dentro do que ele espera
[196:08] cara você vai ter um ponto
[196:10] você vai ter feito ele chegar no resultado final
[196:12] em outro lugar e sabe o que vai acontecer
[196:14] ele vai comprar outra coisa de você
[196:16] ele vai comprar outra coisa de você
[196:20] porque agora ele acredita que você consegue
[196:22] ele acredita ainda mais que você consegue
[196:24] levar ele para outro nível
[196:26] para outro patamar e ele vai comprar outro
[196:28] oferta outro upsell outra coisa
[196:30] vende um produto muito mais caro
[196:32] não se preocupa com isso não
[196:34] o seu desejo tem que ser com que seu cliente
[196:36] chegue ao resultado e mesmo que ele chegue ao resultado
[196:38] e ele nunca mais cumpre de você
[196:40] usa esse cara de queijo de sucesso
[196:42] não vai faltar cliente no mercado pra
[196:44] ir ficar tranquilo
[196:46] não vai
[196:48] então a minha cliente disse
[196:50] preciso de alertas para fazer follow up
[196:52] para organizar meu lead
[196:54] ela está revelando o resultado desejado
[196:56] ou só uma dor pontual
[196:58] cara o resultado desejado que ela quer
[197:00] é não esquecer
[197:02] mas os leads ou não ter mais a dor de
[197:04] cabeça de tem que ficar lembrando o tempo todo
[197:06] a atendente dela
[197:08] ela não quer mais ficar pensando
[197:10] no tempo todo
[197:12] qual cliente ela vai responder
[197:14] ela não quer ver verificando a agenda dela
[197:16] o tempo todo
[197:18] ela não quer ter essa preocupação mental
[197:20] que às vezes faz com que ela perca dinheiro
[197:23] e realmente não aconteça
[197:25] ela não quer sua ferramenta
[197:27] ela quer resolver o problema que isso causa
[197:29] qual que é o problema que isso causa
[197:31] qual que é o problema que ela não tem um alerta
[197:33] para fazer follow up e ela não está organizada
[197:35] com os leads dela
[197:37] causa dentro da empresa dela
[197:39] às vezes ela não sabe onde ela está perdendo a venda
[197:41] às vezes ela está desperdiçando o lead
[197:43] às vezes ela esquece de fazer um follow up
[197:45] às vezes ela esquece de fazer alguma coisa
[197:47] que faz ela não vender mais
[197:49] e aí você calcula quantos por cento
[197:51] você acredita que você perde fazendo isso
[197:53] e aí você tem um resultado desejado
[197:55] então se a gente melhorar isso
[197:57] a gente melhora tanto
[197:59] o meu objetivo é fazer com que você chegue
[198:01] nesse número
[198:03] e aí o que você faz é a ponte
[198:05] para você chegar no resultado que ela falou
[198:07] beleza? acho que ficou claro assim
[198:09] então quando a gente traz isso
[198:11] dentro dessa oferta
[198:13] é percepção de sucesso
[198:15] ou seja o quanto que ele acredita que você pode entregar aquilo
[198:17] tempo de espera
[198:19] quanto tempo leva
[198:21] para ele ver o primeiro resultado
[198:23] quanto menor o tempo melhor
[198:25] quem aqui vende CRM
[198:27] tem alguém aqui que vende CRM
[198:29] sabe qual que é uma das ofertas
[198:31] mais agressivas que você pode fazer?
[198:33] você que vende CRM
[198:35] você pode operacionalizar
[198:37] eu tenho certeza que você consegue entregar
[198:39] mas é uma oferta mega agressiva
[198:41] e que vai fazer com que você se diferencie
[198:43] do mercado e vai fazer com que você venda muito mais
[198:45] ou você que vende automação
[198:47] cara em 3 dias vai estar pronto
[198:49] em 4 dias vai estar pronto na tua empresa
[198:51] e aí a gente só precisa ajustar
[198:53] o que for realmente tendo o dia justo
[198:55] mas em 4 dias está rodando e está pronto
[198:57] dentro da sua empresa
[198:59] o tempo quanto menos esse cliente tiver que
[199:01] esperar até o resultado
[199:03] que eu implemento
[199:05] mais percepção de valor ele vai ter
[199:07] obviamente coloco um tempo realista
[199:09] junto com a sua operação
[199:11] mas pensa dentro da sua oferta
[199:13] e pensa no seu serviço e no seu produto
[199:15] também pensando na oferta
[199:17] peraí se eu consigo
[199:19] oferecer para esse cliente
[199:21] normalmente eu levo duas semanas para implementar isso
[199:23] que eu implemento
[199:25] mas se eu consigo fazer
[199:27] meu cliente e eu implementar isso
[199:29] e ele enxergar isso pronto
[199:31] as vezes as duas semanas que eu levo
[199:33] eu consigo cobrar 4 vezes mais
[199:35] porque ele vai ver uma velocidade
[199:37] de entrega e as pessoas têm essa sensação
[199:39] sabe qual é a sensação das pessoas
[199:41] e eu converso com muito cara do digital
[199:43] e eu acho louco isso
[199:45] ele se fala assim
[199:47] nossa se eu passar para o meu cliente que vai ser rápido
[199:49] e faça assim
[199:51] ele não vai comprar de mim, ele vai desvalorizar
[199:53] meu trabalho e é exatamente contrário
[199:55] está louco
[199:57] você deixa de fazer uma cirurgia
[199:59] porque ela tem 30 minutos
[200:01] porque ela tem
[200:03] meia hora, porque ela tem uma hora
[200:05] e não oito horas
[200:07] se você
[200:11] for ali ser enxergado
[200:13] como um profissional
[200:15] como uma autoridade no que você faz
[200:17] quanto menos tempo você levar é melhor
[200:19] e aí você pode comparar
[200:21] se essa é uma preocupação sua, compara
[200:23] sabe quanto tempo os nossos concorrentes
[200:25] eles levam para implementar isso para você
[200:27] você sabe disso
[200:29] 30 dias, 60, 80 dias
[200:31] sabe quanto tempo eu levo? 4 dias
[200:33] sabe por que eu levo isso? porque eu sou melhor que eles
[200:35] cara que oferta forte
[200:40] é muito forte
[200:42] e aí vê um ponto
[200:44] a gente bate contrato
[200:46] e como eu só levo 4 dias
[200:48] assim no contrato comigo
[200:50] obviamente vão ter as manutenções e algumas alterações
[200:52] que a gente vai precisar fazer nesses 4 dias
[200:54] mas nesses 4 dias isso vai estar implementado
[200:56] dentro da sua empresa
[200:58] e se dentro desses 4 dias não estiver
[201:00] implementado, aí beleza
[201:02] você não precisa me pagar
[201:04] e eu ainda termino o serviço
[201:06] mas se estiver implementado e você já paga o valor
[201:08] integral dentro desses próximos 4 dias
[201:10] cara é muito difícil que a gente não compre de você
[201:12] você percebe como a oferta fica agressiva e fica forte?
[201:14] Gustavo, mas isso é um problema
[201:16] cara eu estou falando de 4 dias
[201:18] para você receber
[201:20] você bater um contrato e assinar
[201:22] o mundo real não é esse mar de rosas
[201:24] que o pessoal mostra na internet
[201:26] sobre a sua oferta ficar forte
[201:28] vocês percebem que um grande
[201:30] um único fator
[201:32] que é o tempo
[201:34] ele faz com que
[201:36] as pessoas comprem mais de você
[201:40] ou ele faz com que as pessoas comprem mais de você
[201:42] ou ela faz com que elas comprem menos
[201:44] por isso que ali na fórmula
[201:46] a gente divide
[201:48] quando a gente fala de tempo de espera a gente divide
[201:50] porque isso diminui o valor
[201:52] esforça o sacrifício
[201:54] e aí vem um ponto
[201:56] quanto que o meu cliente vai precisar executar
[201:58] para que o meu processo dê certo
[202:00] quanto mais o seu cliente executa
[202:02] menos valor
[202:04] a sua oferta tem
[202:06] quanto mais o seu cliente
[202:08] não precisa fazer as coisas
[202:10] mais valor a sua oferta tem
[202:14] beleza?
[202:16] então quando a gente coloca isso
[202:18] dentro do esforço de sacrifício
[202:20] tem até um exemplo aqui
[202:22] se ele não precisar cozinhar
[202:24] o quanto ele sofre mudar de rotina
[202:26] se ele não precisar cozinhar
[202:28] ou ir à academia ou o valor esplode
[202:30] ou seja, cara, vamos supor que eu estou vendendo
[202:32] um produto
[202:34] e aí esse produto ele ensina a cozinhar
[202:36] mas a pessoa não tem tempo
[202:38] mas ele ensina a cozinhar em 5 minutos por dia
[202:40] opa, beleza
[202:42] ficou muito melhor
[202:44] você vai conseguir em 5 minutos
[202:46] fazer suas marmitas
[202:48] ou seja, você vai ter pouco esforço
[202:50] vai ser fácil
[202:52] de preparar no seu que
[202:54] e aí a gente coloca esforço de sacrifício
[202:56] o quanto que essa pessoa precisa se esforçar
[202:58] para isso dar certo
[203:02] beleza?
[203:04] cara, vocês percebem que só de vocês
[203:06] pensarem isso aqui
[203:08] vocês já pensam quanto a oferta de vocês fica agressiva
[203:10] e muitas das vezes
[203:12] vocês conseguem cobrar muito mais caro nisso
[203:14] sabe por que você não consegue fazer uma oferta agressiva dessa?
[203:16] porque você vai fazer uma oferta agressiva dessa
[203:18] e cobrar 500 contos
[203:20] sai para lá, doida
[203:22] e aí vocês vendem um projeto de 30 mil
[203:24] que é fácil entregar em 4 dias
[203:26] não foi 4 dias
[203:28] foi 60 dias inclusive
[203:30] mas é fácil de você entregar
[203:32] porque você tem dinheiro, ficar fácil, ficar muito dinheiro
[203:34] como que você é bem pago
[203:36] por que as pessoas que são bem pagas
[203:38] elas são cada vez mais bem pagas
[203:40] porque elas resolvem um problema
[203:42] as pessoas sabem que ela vai resolver o problema
[203:44] e elas sabem que vão precisar de menos esforço
[203:46] para que essa pessoa resolveu o problema para ela
[203:48] então, os grandes profissionais
[203:50] os grandes executivos eles são muito bem pagos
[203:52] por causa disso
[203:54] e a sua oferta tem que ter isso
[203:56] fechou? beleza
[203:58] então vamos para os 5 passos
[204:00] para você criar sua oferta
[204:02] primeiro, o que a gente tinha falado
[204:04] seja específico
[204:06] identifique o resultado desejado
[204:08] então
[204:10] não vem da consultoria de marketing
[204:12] venda como colocar 20 agendamentos
[204:14] na sua agenda em 30 dias
[204:16] acabou
[204:19] não vem da consultoria de marketing
[204:21] venda como você ter 4 mil pedidos
[204:23] a mais por mês
[204:25] não venda um CRM
[204:27] venda, cara
[204:29] gaste menos tempo do seu time comercial
[204:31] e verifique exatamente o que ele está fazendo
[204:33] em tempo real sem tomar o seu tempo
[204:35] aumentando em 30%
[204:37] sua receita
[204:39] alguma coisa
[204:41] se você for específico
[204:43] quanto mais específico você for
[204:45] você vai conseguir realmente identificar o resultado
[204:47] o que o meu cliente deseja
[204:49] e aí eu vou ser específico
[204:51] e aí eu vou falar sobre o destino
[204:53] destino, não sobre a passagem
[204:55] lixe os problemas
[204:57] e obstáculos
[204:59] cara quais são os problemas que o seu lead tem
[205:01] qual que é o problema que o seu lead tem
[205:03] ele não sabe quantos clientes entram na loja dele
[205:05] ele não sabe que são vários problemas
[205:07] e aí eu poderia exemplificar para cada um de vocês
[205:09] quais são os problemas
[205:11] mas a segundo passo é você exemplificar
[205:13] e trazer os problemas que esse cara tem
[205:15] aqui a gente está no exemplo
[205:17] de emagrecimento
[205:19] não tem o tempo para cozinhar
[205:21] não sei quais exercícios fazer
[205:23] tem o fome à noite
[205:25] ou seja, quais são todos os problemas e obstáculos
[205:27] que o seu cliente tem
[205:29] beleza? anota isso
[205:31] transforme problemas em soluções
[205:33] lembra que eu falo de narrativa
[205:35] lembra que eu falei ali da autoridade
[205:37] se você pega e você tem um polo
[205:39] onde você não tem autoridade
[205:41] é tudo uma questão de narrativa
[205:43] o cliente
[205:45] cara, todo problema que seu cliente tem
[205:47] é uma oportunidade para você
[205:49] você não consegue prospectar
[205:51] se eu arrumar alguém para prospectar
[205:53] esse cara vai me pagar mais
[205:55] você não consegue vender
[205:57] esse cara vai me pagar mais
[205:59] então todo problema e solução que eu tiver
[206:01] vai ficar cada vez mais caro
[206:03] não tem o tempo para cozinhar
[206:05] ou seja
[206:07] é igual a guia de marmitas
[206:09] em 15 minutos é aquele exemplo que eu tinha dado
[206:11] mas cada obstáculo que seu cliente der
[206:13] então, gente
[206:15] eu vou fazer uma boa aqui para vocês
[206:17] algum de vocês, o primeiro de vocês que falar isso
[206:19] eu vou responder e vou trazer exemplificando para vocês
[206:21] fala um obstáculo que seu cliente tem
[206:23] no dia a dia que seu produto
[206:25] resolve ou alguma coisa que seu produto
[206:27] resolve ou que seu cliente tem no dia a dia
[206:29] e que impede ele de comprar seu produto
[206:31] sei lá, algum de vocês consegue citar isso?
[206:33] pode ser do meu time também
[206:35] eu só queria que uma pessoa citar isso para eu exemplificar isso de uma maneira melhor
[206:37] sem pressa
[206:41] um de cada vez
[206:43] a dificuldade de que?
[206:45] fechar consultas, beleza?
[206:47] ele tem a dificuldade de fechar consultas
[206:49] e eu vou exemplificar isso
[206:51] eu vou trazer uma
[206:53] exemplificação grotesca
[206:55] grotesca
[206:57] mas assim
[206:59] é o que vai fazer o seu problema ser resolvido
[207:01] cara, ele tem dificuldade de
[207:03] fechar consultas
[207:05] se eu ofereço um serviço
[207:07] aonde eu feche
[207:09] a gente diz fechar consultas
[207:11] dentro do consultório
[207:13] ele fechar ali com o cliente e vender para ele
[207:15] ou realmente
[207:17] ele fazer com que o paciente
[207:19] ele vá na consulta com ele
[207:21] se for o paciente ir na consulta com ele
[207:23] e ele tem essa dificuldade
[207:25] de fechar essas consultas
[207:27] o que que eu recomendo?
[207:29] cara, se você me pagar um valor muito maior
[207:31] uma reconhecência muito maior
[207:33] eu consigo colocar alguém para fechar essas consultas para você
[207:35] usando a minha metodologia
[207:37] isso não vai ter trabalho nenhum
[207:39] a gente vai aumentar a sua conversão
[207:41] e essa pessoa vai fechar para você
[207:43] ou eu vou acompanhar seu time assim
[207:45] ou eu vou acompanhar os fechamentos
[207:47] ou eu vou entrar uma vez por dia
[207:49] duas vezes por dia com o seu time comercial
[207:51] vou ver todas as consultas que tiveram
[207:53] todas as oportunidades que tiveram
[207:55] a gente vai avaliar
[207:57] e a gente vai planejar isso
[207:59] quanto menos esforço eu tirar
[208:01] quanto melhorar a narrativa
[208:03] quanto melhorar a minha oferta
[208:05] uma pessoa aqui por exemplo
[208:07] eu tenho um cliente aqui
[208:09] que ele contratou a gente
[208:11] para ele ter um time
[208:13] para ele, ele tem um time comercial
[208:15] para ele que a gente gera esse time
[208:17] esse cara ele paga 15 mil por mês
[208:19] se esse cara ele paga 15 mil por mês
[208:21] e ainda paga os funcionários dele
[208:23] ele está pagando valor justo
[208:25] porque ele não está tendo esforço
[208:27] ele não está tendo sacrifício
[208:29] então quanto menor esforço, menor sacrifício
[208:31] mas bem pago você vai ser
[208:33] e cobre justamente
[208:35] obviamente, faça algo que faça sentido para ti também
[208:37] não vai sair metendo um monte de produtos
[208:39] só para vender, fechou?
[208:41] que você não vai conseguir entregar
[208:43] quanto menos esforço e menos sacrifício
[208:45] que a gente tiver
[208:47] mais caro você cobra disso
[208:49] quanto mais ele tiver
[208:51] mais barato você cobre
[208:53] então todos os problemas que a gente trouxer
[208:55] você transforma em solução
[208:57] cara eu não tenho tempo, exatamente
[208:59] estou entrando para realmente tirar esse tempo
[209:01] com aquilo, com aquilo outro
[209:03] então eu entro para resolver esse problema
[209:08] dificuldade, o cliente dele faz leilão
[209:10] de proposta entre empresas até conseguir um menor preço
[209:12] não entendi essa pergunta
[209:14] não entendi nenhum contexto em geral
[209:16] você puder explicar melhor
[209:18] eu exemplifico isso aí pra ti também
[209:20] passo 4
[209:22] escolha o veículo de entrega
[209:24] ou seja, aí vem um ponto do seu produto
[209:26] como que você vai entregar essa solução
[209:28] como que você vai entregar
[209:30] isso ali para o seu cliente
[209:32] mostrar, demonstrar e entregar isso para o seu cliente
[209:34] sobre o problema
[209:41] sobre o problema resolver do cliente
[209:43] eu ainda não entendi Jefferson
[209:45] mas é uma hora eu entender
[209:47] uma hora eu vou entender
[209:49] bora lá, então um para um
[209:51] ou seja, high tot mais caro
[209:53] ou seja, se for você
[209:55] resolver um problema diretamente de uma pessoa
[209:57] você vai cobrar ou mais caro
[209:59] vai ter mais esforço, beleza
[210:01] então, cara
[210:03] se você resolve, eu vou explicar isso de uma maneira
[210:05] simples aqui para vocês
[210:07] se você resolve um problema específico
[210:09] para uma pessoa específica, por exemplo
[210:11] se essa aula fosse individual 8 horas para vocês
[210:14] imagina quanto eu cobraria
[210:16] para dar 8 horas de treinamento para vocês aqui seguido
[210:18] cara, seria no mínimo ali uns 10 mil reais
[210:20] beleza
[210:22] no mínimo uns 10 mil reais
[210:24] para me passar 8 horas entregando conteúdo
[210:26] entregando tudo isso que eu estou fazendo somente para você
[210:28] mas como eu posso atingir
[210:30] várias outras pessoas a gente cobra mais barato
[210:32] então, quanto menos pessoas
[210:34] mais baratos, quanto mais personalizado
[210:36] mais caro, beleza
[210:38] isso dá para entender
[210:42] acredito que ele quer saber o contexto dessa empresa
[210:44] cara, eu não estou entendendo nada
[210:46] que vocês estão falando no chat
[210:48] enfim, eu vou prestar atenção aqui na aula
[210:50] menor esforço para você, mais menor
[210:52] percepção de valor, ou seja
[210:54] quanto menos esforço tem para você
[210:56] também é menor a percepção de valor
[210:58] do seu cliente, lembra que a gente falou
[211:00] cara, eu implemento isso em 4 dias
[211:02] beleza, você pode implementar isso em 4 dias
[211:04] você tem que mostrar o esforço que você faz
[211:06] para implementar isso em 4 dias também
[211:08] você tem que mostrar porque você é melhor
[211:10] e você consegue implementar isso em 4 dias
[211:12] e as outras pessoas não
[211:14] então, essa questão de esforço para você
[211:16] ela é muito subjetiva
[211:18] por exemplo, para mim é um grande esforço
[211:20] eu fazer uma entrega, sei lá
[211:22] de 12 horas seguidas
[211:24] para um cliente específico
[211:26] mas para uma pessoa
[211:28] cara, imagina eu receber 3 mil por 12 horas de trabalho
[211:30] para mim não vale
[211:32] é muito esforço para mim por pouco dinheiro
[211:34] mas às vezes para a pessoa, caraca
[211:36] eu trabalho o mês inteiro, às vezes para ganhar
[211:38] 3 mil, então é pouco esforço
[211:40] mais muito dinheiro, então essa percepção de valor
[211:42] é um pouco individual, beleza
[211:44] mas quanto menor esforço para você
[211:46] é menor a percepção
[211:48] de valor ali para o seu próprio cliente
[211:50] isso você tem que entender internamente
[211:52] com você mesmo
[211:54] isso você tem que entender calculando a sua especialidade
[211:56] um monte de coisa, eu não vou bater muito fundo
[211:58] nisso porque senão eu vou mais bugar a cabeça de vocês
[212:00] do que ajudar vocês
[212:02] e aí o passo 5 é
[212:04] remover o que é irrelevante
[212:06] foco nas soluções que entregam maior valor
[212:08] com menor custo para você
[212:10] empilha essas soluções em um pacote único
[212:12] cara, alguém que conhece
[212:14] ou você, você vai fazer uma reunião
[212:16] com o cliente, aí você tem uma agência
[212:18] aí você oferece tráfego pago
[212:20] aí você oferece socialmente, aí você oferece R&M
[212:22] aí você oferece ok, aí você oferece
[212:24] todas as outras coisas para o cliente
[212:26] eu já fui idiota nesse nível e aí você oferece
[212:28] um monte de coisa
[212:30] que é desnecessário
[212:32] cara, foco
[212:34] na solução
[212:36] que te dá um menos trabalho
[212:38] e mais resultado para o seu cliente
[212:40] e ele vai te pagar a cara do mesmo jeito
[212:42] que que é adianta você resolver
[212:44] um monte de coisa para o seu cliente
[212:46] sendo que ele tem um destino final
[212:48] sendo que você ainda ficou um destino final
[212:50] sendo que na tua oferta você vai falar
[212:52] sobre um destino final
[212:55] que que é adianta
[212:57] que precisa com que o seu cliente
[212:59] ele entenda que
[213:01] existe
[213:03] que existe ali uma percepção
[213:05] de valor e que você tem essa percepção
[213:07] de valor e que você não vai
[213:09] entregar várias outras coisas porque
[213:11] você resolve um problema específico
[213:13] e que seu problema específico resolve
[213:15] ou te dá aquele resultado
[213:17] que você pretende
[213:19] te dá aquele resultado que você espera
[213:21] então quando você vai empilhando
[213:23] essas pequenas coisas que não te dão tanto
[213:25] que o seu cliente atinge o resultado final
[213:27] aí sim você consegue
[213:29] então dentro das ofertas
[213:31] eu sou muito a favor de uma coisa que eu chamo de SUI
[213:33] serviço ultra escalável
[213:35] ou seja, serviços que eu consigo vender
[213:37] para as pessoas
[213:39] e que elas são mega escaláveis
[213:41] que eu consigo entregar para várias pessoas
[213:43] sem uma quantidade de esforço tão grande
[213:45] então o serviço ultra escalável
[213:47] vai fazer com que
[213:49] com que você continue crescendo sua empresa
[213:51] e sempre continue crescendo sua empresa
[213:53] e você entrega um resultado final
[213:55] bem parecido para a maioria dos clientes
[213:57] fechou? você consiga padronizar
[213:59] você consegue crescer sua empresa
[214:01] então, cara, remove o que é irrelevante
[214:03] dentro do que você faz
[214:05] muitas das vezes você identifica o que seu cliente quer
[214:07] e aí ele começa a falar
[214:09] um monte de coisa que ele quer para você
[214:11] e aí você tenta resolver todos os problemas dele
[214:13] não, cara, entende o que
[214:15] não que ele está falando que ele quer
[214:17] que eu quero social media, eu quero trafico, quero isso, quero aquilo
[214:19] entende qual que é o resultado final que ele quer
[214:21] às vezes ele só quer autoridade
[214:23] às vezes ele só quer
[214:25] sei lá
[214:27] vender mais
[214:29] e aí falaram para ele que para vender mais
[214:31] ele precisa de social media, tráfego, CRM
[214:33] e aí você mostra um detalhe
[214:35] assim você pode resolver tudo isso em tanto tempo
[214:37] e aí você consegue entregar para ele
[214:39] então, hoje, abre a sua oferta
[214:41] abre o seu produto, abre o seu serviço
[214:43] e fala assim, cara, o que é irrelevante
[214:45] o que realmente
[214:47] não chamaria a atenção do meu cliente
[214:49] o que realmente
[214:51] faria com que, ou o que eu estou desperdiçando
[214:53] de potencial aqui, que o meu cliente
[214:55] ele não precisaria disso
[214:57] e aí a gente vai para esse ponto, beleza
[214:59] a gente vai para esse ponto
[215:01] então, elemento de escassez
[215:03] e urgência
[215:05] bora lá
[215:07] até aqui, todo mundo entendeu
[215:09] cinco passos aqui ou ficou meio confuso
[215:11] para vocês, se ficou confuso eu repito aqui
[215:13] de uma forma mais organizada
[215:15] eu vou repetir porque eu acho que ficou meio confuso
[215:17] porque eu vi alguns rostos não entendendo muito bem
[215:19] cara, primeiro
[215:21] identificar o resultado desejado
[215:23] identificar onde seu cliente quer chegar
[215:25] segundo, coloca todos os problemas
[215:27] que eles têm, todos os problemas e obstáculos
[215:29] que ele tem, se o produto resolve
[215:31] ou para comprar o teu produto
[215:33] todas as objeções que ele tem, enfim
[215:35] você anota isso para você criar a oferta
[215:37] transforme esses problemas que ele tem
[215:39] em uma possível solução, seja por
[215:41] narrativa, ou seja ali por um entregar
[215:43] o novo
[215:45] escopo, ou seja o veículo
[215:47] de entrega, ou seja como que você
[215:49] vai entregar isso, como que você vai fazer isso
[215:51] como que você entrega isso para o cliente
[215:53] para quantos clientes você entrega de forma personalizada
[215:55] de forma individual, de forma em grupo
[215:57] ou como que é isso, como que isso é feito
[215:59] beleza, então você precisa ter isso
[216:03] corte, ou seja
[216:05] deixa eu colocar aqui
[216:07] corte em pilho, ou seja
[216:09] você vai remover o que é irrelevante
[216:11] então dentro do seu produto que você já tem
[216:13] normalmente, você remove tudo que é irrelevante
[216:15] você falar para o seu cliente
[216:17] que não vai ser o foco principal, que não vai fazer com
[216:19] que ele compre de você, que às vezes
[216:21] vai te dar mais trabalho e é um trabalho
[216:23] desnecessário, porque a gente tem a percepção
[216:25] que a gente precisa entregar um monte de coisa
[216:27] para a gente vender um produto bom
[216:29] na verdade a maioria dos produtos bons
[216:31] são o que entrega uma coisa específica e faz
[216:33] o cliente chegar no resultado rápido, beleza
[216:38] demonstrar o que eu não vou vender
[216:41] o que o cliente quero, mas o que
[216:43] precisa ganhar confiança como consultor
[216:45] que não vou vender o que o cliente quer
[216:47] mas não precisa ganhar a confiança dele
[216:49] como consultor e parceiro, também não entender
[216:51] acredito
[216:53] demonstrar que não vou vender o que
[216:55] o cliente quer
[216:57] mas precisa ganhar a confiança dele
[216:59] como consultor e parceiro
[217:01] ah, entendi, entendi
[217:03] isso é exatamente
[217:05] entendi, entendi, às vezes ele quer
[217:07] mas ele não precisa
[217:09] e às vezes ele quer, a gente precisa entender
[217:11] por que ele quer aquilo
[217:13] porque, lembra que quando eu falei sobre
[217:15] resultado final, ninguém quer social media
[217:17] a gente quer alguma coisa
[217:19] dentro desse contexto de social media
[217:21] a gente às vezes quer parecer mais bonito
[217:23] que o nosso concorrente
[217:25] às vezes a gente quer ter mais curtido que o nosso
[217:27] cara, você tem que entender qual que é o resultado final
[217:29] que esse cara quer
[217:31] se você não entender, você não consegue fazer uma venda pra ele
[217:33] fechou?
[217:35] é muito difícil você fazer a venda
[217:37] não é que você não consegue
[217:39] ou você vai cobrar muito mais barato do que você poderia
[217:41] cobrar, fechou?
[217:43] elemento de escassez e urgência
[217:45] ou seja, tá?
[217:47] uma oferta sem o motivo pra comprar agora
[217:49] é uma oferta morta
[217:51] gente, eu não pressiono o cliente dentro da minha reunião
[217:53] a minha oferta pressiona
[217:55] e eu preciso que vocês entendam isso
[217:57] tá? eu preciso que vocês entendam isso
[217:59] existe uma grande diferença
[218:01] entre eu pressionar o meu cliente
[218:03] numa reunião e eu pressionar o meu cliente
[218:05] na reunião e a minha oferta
[218:07] pressionar o cliente na reunião
[218:09] que a oferta é algo pronto
[218:11] você é um ser humano
[218:13] beleza?
[218:15] diferenciinhos, o seu produto de serviço
[218:17] ele tem que ter uma oferta, ele tem que ter algo mapeado
[218:19] tanto que foi uma das coisas que mais trabalhei
[218:21] esse mês, foi uma das coisas que mais
[218:23] fez eu vender esse mês
[218:25] eu tô vendendo bem, muito bem
[218:27] sendo que eu tô voltando como closer agora dentro
[218:29] da minha própria operação
[218:31] bora lá, escassez
[218:33] quantidade, ou seja, eu só tenho 3 vagas pra
[218:35] mentorar desse mês, ou seja
[218:37] eu vou falar, cara, como é seu serviço?
[218:39] que eu entrego esse resultado, você tem esse mínimo de
[218:41] esforço, você gasta isso de tempo
[218:43] e a gente tem isso aqui
[218:45] e você confia em mim pra fazer isso
[218:47] e pelas pessoas confiarem em mim também
[218:49] eu só consigo atender 3 clientes
[218:51] desse por mês, e não é brincadeira
[218:53] eu só consigo atender 3 clientes desse por mês
[218:55] por isso que eu cobro 10 mil reais por mês
[218:57] deixa eu falar uma coisa pra vocês
[218:59] eu falei que
[219:01] eu tenho esse discurso até hoje
[219:03] tá? se um dia eu fechar, assim
[219:05] não tiver mais equipe
[219:09] eu literalmente, eu vou atender 5 clientes
[219:11] e eu vou ganhar 100 mil por mês com esses 5 clientes
[219:13] porque eu vou cuidar
[219:15] do comercial dele de uma forma
[219:17] genial, e aí eu vou ter 5 clientes
[219:19] de 20 mil
[219:21] e eu vou ganhar 100 mil por mês
[219:23] somente com os 5 clientes
[219:25] e aí essa escassez vai fazer com que
[219:27] eu sempre tenha mais possibilidade de clientes
[219:29] que as pessoas criem fila de espera pra
[219:31] me contratar
[219:33] então, deixa eu colocar, a escassez
[219:35] quando ela é real
[219:37] a escassez ela só vale quando ela é real
[219:39] e ela é perceptiva pro seu cliente
[219:41] não adianta você colocar uma escassez que não é real
[219:43] tá?
[219:45] ah, eu só atendo 5 pessoas por mês
[219:47] cara, é mentira
[219:49] se o seu cliente perceber que isso é mentira
[219:51] ele vai falar isso pra você
[219:53] ele vai falar isso pra você
[219:55] então, só utiliza a escassez quando ela for real
[219:57] ou encontre uma escassez real pra
[219:59] você utilizar dentro do seu produto
[220:01] fechou?
[220:03] ó, por exemplo, uma escassez real
[220:05] você pode colocar
[220:07] e aí ela entra junto com bônus
[220:09] mas ela entra
[220:11] nisso que a gente falou
[220:13] normalmente a gente entrega as nossas entregas
[220:15] no período de um mês
[220:17] como a gente está finalizando o mês
[220:19] e faltam somente, sei lá, 5 dias pro mês acabar
[220:21] se você entrar hoje
[220:23] a sua oferta ela vai ser finalizada
[220:25] o seu produto, o seu processo vai ser finalizada ainda esse mês
[220:27] então a gente só tem mais tantas vagas pra finalizar
[220:29] a gente só tem hoje
[220:31] pra gente conseguir realmente finalizar isso
[220:33] e pra você entrar e a gente conseguir te entregar um processo
[220:35] ainda muito mais rápido que os outros clientes
[220:37] se você entrar no outro período
[220:39] provavelmente você vai ter que esperar 30 dias
[220:41] cara, um exemplo
[220:43] tá, bem tosco, mas é um exemplo
[220:45] então você pode usar isso, urgência
[220:47] cara, se você usa, ah, esse bônus
[220:49] só vale pra quem fechar nas próximas 24h
[220:51] só vale pra quem fechar em call
[220:53] só vale pra quem fechar isso, aquilo, aquilo outro
[220:55] se você for usar esse bônus
[220:57] usa esse bônus de maneira com
[220:59] na call
[221:01] você não pega o seu cliente no longo prazo
[221:03] o que eu vejo a maioria das pessoas fazendo
[221:05] cara, fecha comigo agora
[221:07] e aí você vai ter esse, esse desconto
[221:09] você vai ter isso, você vai ter aquele benefício
[221:11] e se você não fizer comigo, você vai perder
[221:13] e aí, bababla, aí o seu cliente não compra contigo na call
[221:15] e ele nunca mais compra, porque ele fala, ah, eu perdi tudo aquilo
[221:17] não quero mais aquilo, e se você voltar na palavra
[221:19] ele vai falar, pois, o cara voltou na palavra
[221:21] ele tava me enganando pra me fechar naquele momento
[221:23] vocês percebem
[221:25] então, até a urgência e o tempo
[221:27] que você vai usar, tá
[221:29] como que você pode realmente trazer
[221:31] essa urgência
[221:33] e aí você pode trazer essa urgência na entrega
[221:35] então lembra aquela oferta que eu falei
[221:37] em quatro dias eu consigo resolver isso pra você
[221:39] se o cliente ele entra comigo
[221:41] e toma essa decisão agora
[221:43] eu sei que vai estar implementado em quatro dias
[221:45] então ele precisa pagar só em quatro dias
[221:47] mas ele assina o contrato hoje comigo
[221:49] e a gente inicia esse trabalho
[221:51] ou a gente entrega em oito dias
[221:53] porque ele tem um dia de enrembolsa ali
[221:55] é bom correr esse risco
[221:57] mas enfim, então o cliente que entra agora
[221:59] tem esse dia, mas o cliente que entra depois
[222:01] ele vai ter ali 16 dias, 17 dias
[222:03] 20 dias, 30 dias de espera
[222:05] porque ele entra no ciclo novo
[222:07] e a gente dá prioridade pra quem confia na gente aqui também
[222:09] pra quem confia na gente mais rápido
[222:11] você não concorda comigo, cliente, que você precisa confiar
[222:13] que você também dá prioridade pra quem confia mais em você
[222:15] mais rápido? sim, então beleza
[222:17] ah, eu trato todos os meus clientes igual
[222:19] então melhor essa oferta aí, meu amigo
[222:21] enfim, quando a gente vem
[222:23] de urgência, vocês têm que gerar uma urgência
[222:25] só que a urgência ela não pode impedir
[222:27] com o que você venda pro seu cliente no futuro
[222:29] fechou? bonus
[222:31] devem resolver o problema
[222:33] o próximo problema que o cliente terá
[222:35] após comprar seu produto, por exemplo
[222:37] eu vendo CRM, se eu vendo CRM
[222:39] o próximo problema que o meu cliente vai ter
[222:41] após ele comprar esse produto vai ser
[222:43] processo comercial pro meu time
[222:45] realmente utilizar esse CRM
[222:47] e preencher esse CRM todos os dias
[222:49] a gente sabe que vai ter esse problema
[222:51] e a gente agora, eu ainda coloco um treinamento
[222:53] aonde eu acompanho o time dele
[222:55] e faço com que o time dele preenche CRM
[222:57] isso vire um hábito dentro do time dele
[222:59] pra que ele não tenha essa dificuldade
[223:01] beleza? garantias
[223:03] tire o risco das costas do cliente
[223:05] e coloque na SUS
[223:07] então aqui você pode usar
[223:09] vários tipos de garantia
[223:11] você pode usar vários tipos de garantia
[223:13] por exemplo, Gustavo, eu não gosto
[223:15] de dar garantia de resultado, beleza
[223:17] nem dê
[223:19] isso em tanto tempo, se você não tiver isso
[223:21] e isso e isso e rodando em tanto tempo
[223:23] eu te devolvo teu dinheiro, cara, você pode colocar
[223:25] garantia de execução
[223:27] mas você tem que ter uma garantia só oferta
[223:29] ela fica mais forte e o seu time ele fica mais
[223:31] engajado pra trabalhar dentro dessa garantia, beleza?
[223:33] então, cara, se eu não executar
[223:35] e não fizer isso aqui em tanto tempo
[223:37] eu te devolvo teu dinheiro
[223:39] isso é uma garantia
[223:41] você tira o peso das costas dele, cara
[223:43] se torna a decisão dele mais leve
[223:45] ó, você me paga a metade agora
[223:47] e ela me paga quando eu entregar
[223:49] se eu não entregar, você não precisa pagar outra metade
[223:51] e ainda assim eu termino de fazer
[223:53] ou, cara, eu vou fazer esse processo com você
[223:55] por 60 dias, 60 dias
[223:57] se eu não tiver esse resultado
[223:59] eu vou te acompanhar ainda por mais 3 meses
[224:01] garantia
[224:03] beleza?
[224:05] então, essa garantia você precisa ter
[224:07] toda
[224:09] oferta boa, ela tem uma garantia
[224:11] e a garantia
[224:13] ela não necessariamente é uma garantia de resultado
[224:15] pode ser uma garantia de tempo
[224:17] uma garantia de execução
[224:19] alguma garantia que coloque a objeção dele
[224:21] em check, fechou?
[224:23] beleza? então, tem como você dar
[224:25] uma garantia
[224:27] cara, vocês que vendem a implementação de alguma coisa
[224:29] coloca a garantia, se em 30 dias
[224:31] não estiver implementado, eu devolvo teu dinheiro
[224:33] se em 60 dias eu não estiver
[224:35] implementado, eu devolvo teu dinheiro
[224:37] ah, Gustavo, e se eu não conseguir implementar
[224:39] porra, pelo amor de Deus, você criou uma oferta
[224:41] que você não consegue entregar também
[224:43] então, cria algo que você consegue entregar
[224:45] e obviamente
[224:47] dá um prazo ali, realmente, já com alguma folga
[224:49] para que você consiga fazer essa oferta
[224:51] para que você consiga dar uma garantia
[224:53] mas tem uma garantia dentro de seus produtos
[224:55] beleza? objeção
[224:57] o bônus de treinar, o time comercial usa o CRM
[224:59] e não teria que fazer parte do produto principal
[225:01] não, necessariamente
[225:04] se eu estou vendendo um produto
[225:06] aonde esse cara vai ter esse processo inteiro
[225:08] e eu coloco isso como bônus, eu agrego
[225:10] para o meu produto, o bônus necessariamente
[225:12] pode ser algo que você já ia entregar
[225:14] o seu só apresenta é separado
[225:16] para que você gere ainda mais valor
[225:18] para o seu cliente, tá?
[225:20] beleza?
[225:22] então, tipo assim, cara, eu vou treinar
[225:24] o seu time comercial para usar o CRM
[225:26] agora, eu posso colocar um treinamento
[225:28] ou uma rotina de acompanhamento
[225:30] durante tanto tempo, para conferir se seu time
[225:32] está fazendo o preenchimento de forma correta
[225:34] para isso se tornar um hábito dentro da sua empresa
[225:36] como que você vai gerir isso
[225:38] como que você vai manter ele realmente
[225:40] que aí é uma questão mais cultural dentro do time
[225:42] várias outras vezes você pode colocar
[225:44] isso foi um exemplo, mas assim
[225:46] dentro do bônus, vocês vão pensando em coisas
[225:48] que fazem sentido para o seu cliente
[225:50] fechou que são problemas que eles vão ter
[225:52] a partir do momento que eles compram seu produto
[225:54] fechou?
[225:56] então, até aqui tudo ok?
[225:58] está dando para entender essa parte de oferta?
[226:00] boa
[226:05] ó, e aí
[226:07] o nome da oferta, fórmula magic
[226:09] ou seja
[226:11] como que a gente cria uma oferta
[226:13] de maneira efetiva
[226:15] uma oferta realmente que vai fazer
[226:17] o nome de uma oferta que realmente vai fazer
[226:19] o nosso cliente comprado a gente
[226:21] beleza? então, quando a gente coloca isso
[226:23] é importante
[226:25] e é importante o nome que você vai ter na sua oferta
[226:27] porque o nome da sua oferta
[226:29] vai ser o que vai definir e o cliente
[226:31] vai entender em poucos segundos o que ele faz
[226:33] então, aqui tem o nome de uma oferta
[226:35] por exemplo, magic
[226:37] campanha de preenchimento labial
[226:39] ou protocolo de inverno
[226:41] ou seja, isso aqui
[226:43] é um dos nomes aqui
[226:45] que a gente pode colocar, ou seja
[226:47] o M, qual que é a razão
[226:49] qual que é literalmente o motivo magnético
[226:51] que vai fazer com que essa pessoa
[226:53] atrai a atenção dela
[226:55] que atrai
[226:57] realmente
[226:59] ela no primeiro momento com o resultado dela
[227:01] e aí vem o A
[227:03] de avatar, ou seja, quem é a pessoa
[227:05] quem é o público que você faz
[227:07] então, aqui vocês vão ver que vai se formando
[227:09] o protocolo de inverno para clínicas de estética
[227:11] ou seja
[227:13] aqui a gente colocou, cara, o que eu quero vender
[227:15] qual que é a coisa que eu quero vender
[227:17] qual que é a coisa que eu quero trazer
[227:19] então, magic, qual que é a razão magnética
[227:21] que vai atrair o meu cliente? ah, é um protocolo de inverno
[227:23] beleza, é um protocolo de inverno
[227:25] eu sei que eu estou no inverno
[227:27] eu sei que eu vou atender clínicas de estética
[227:29] então, eu vou criar um protocolo de inverno
[227:31] porque eu entendo que o meu público
[227:33] se comunica com essa palavra
[227:35] acha isso e efetivo
[227:37] depois eu vou criar uma oferta que é ao vivo com vocês
[227:39] e vou mostrar isso pra vocês na prática
[227:41] mas assim, eu sei que o meu público
[227:43] gosta disso, então, a razão magnética
[227:45] vai ser essa
[227:47] pra quem que vai ser esse público?
[227:49] dona de clínicas de estética
[227:51] quanto tempo ali, ou qual que é o objetivo final
[227:53] qual que é o gol, qual que é
[227:55] o voo final, qual que é o destino
[227:57] do voo que essa pessoa vai ter
[227:59] cara, 30 novos agendamentos confirmados
[228:01] ou seja, 30 pessoas dentro da agenda dela
[228:03] quanto tempo, intervalo de quanto tempo
[228:05] 21 dias
[228:07] e aí, literalmente
[228:09] até aqui a gente fez o que
[228:11] o protocolo de inverno para clínicas de estética
[228:13] 30 novos agendamentos
[228:15] de preenchimento, em 21 dias
[228:17] com nosso sistema
[228:19] de aceleração
[228:21] ou de atração acelerada
[228:23] ou seja, qual que é o caminho, qual que é
[228:25] realmente o escopo desse projeto
[228:27] qual que é o sistema, qual que é o nome disso
[228:29] qual que é o nome, é um grupo VIP
[228:31] é um sistema
[228:33] qual que é o nome disso
[228:35] que você coloca
[228:37] que essa pessoa ela tem
[228:39] para ela ter o resultado que você falou ali
[228:41] então, eu vou criar uma oferta aqui
[228:43] para vocês em tempo real
[228:45] e vocês vão ver como que
[228:47] se cria isso aqui no passo a passo
[228:49] porque eu acho que o exemplificando vai ficar muito mais fácil
[228:51] você entender, primeiro ponto
[228:53] qual que é o motivo magnético que um cliente
[228:55] meu compraria de mim
[228:57] então, o motivo magnético que um cliente compraria
[228:59] e aí uma oferta magnética
[229:01] que eu posso colocar
[229:03] pode ser o que? Cara, eu posso colocar
[229:05] sei lá
[229:07] eu vou usar o protocolo
[229:09] não, deixa eu ver
[229:13] ah, eu vou colocar
[229:15] protocolo de vendas
[229:17] beleza, eu posso colocar
[229:19] o protocolo de vendas
[229:21] ou seja, para
[229:23] agências
[229:25] e prestadores
[229:27] serviços, ou seja
[229:33] eu tenho um protocolo de vendas
[229:35] para agências e prestadores de serviços
[229:37] e aí que vem um ponto, tá
[229:39] qual que é o final que eu entrego
[229:41] cara, sei lá
[229:43] 20 mil
[229:45] em contratos
[229:50] em 60 dias
[229:54] no nosso
[230:00] sistema
[230:02] de aquisição
[230:05] sem esforço
[230:09] deixa eu ver aqui, 20 mil em contratos
[230:11] beleza, aqui
[230:13] eu preciso ser mais específico ainda
[230:15] comecei a criar o primeiro escopo da minha oferta
[230:17] ó, protocolo de vendas
[230:19] para agências e prestadores de serviços
[230:21] SASE, etc, então beleza, até aqui
[230:23] tudo ok, protocolo de vendas
[230:25] eu posso colocar protocolo de aceleração
[230:27] eu posso colocar sistema de alavancagem de empresa
[230:29] eu posso colocar qualquer coisa aqui nesse início
[230:31] para agências e prestadores de serviços
[230:33] 20 mil em contratos
[230:35] ainda não tá específico, 20 mil em contratos
[230:37] assinados
[230:41] sem
[230:50] com zero trabalho
[230:52] comercial
[230:54] ou seja
[230:56] quando eu faço essa oferta
[230:58] olha que oferta forte
[231:00] eu tenho esse produto, eu vendi esse produto
[231:02] inclusive esse produto
[231:04] foi o produto que eu vendi ali
[231:06] e depois eu vendi esse produto
[231:08] é um pouco diferente disso, eu já tenho formulado isso
[231:10] mas eu vendi esse produto para um cliente
[231:12] e eu vendi ele por 5 mil
[231:14] e aí esse produto
[231:16] ele basicamente funciona assim
[231:18] é um produto onde ele me paga 5 mil
[231:20] eu prospecto para ele
[231:22] eu trago o cliente para ele, até ele bater 15 mil reais
[231:24] quando ele bate 15 mil reais
[231:26] aí eu não preciso mais prestar esse serviço
[231:28] para ele
[231:30] então ele me paga 5 mil para ter um ROID 3
[231:32] então basicamente é isso
[231:34] mas os clientes dele normalmente são recorrentes
[231:36] ou é um ROID 3 de clientes recorrentes
[231:38] ou é simplesmente um ROID 5
[231:40] que seria 25 mil
[231:42] então a gente coloca esse produto
[231:44] que a pessoa não precisa adquirir clientes
[231:46] a gente faz essa parte de revisição
[231:48] para ela, mas só funciona
[231:50] ali para agências e serviços
[231:52] então para deixar ainda mais específico
[231:54] pensa se eu monto a oferta e eu divulgo essa oferta
[231:56] protocolo de vendas para agências
[231:58] e prestadores de serviços
[232:00] 20 mil encontrados assinados com zero
[232:02] trabalho comercial
[232:04] sem que você precisa mover um dedo
[232:06] fazer uma ligação
[232:08] sem que você precise fazer uma reunião de vendas
[232:10] realmente só atender o seu cliente
[232:12] em 60 dias com isso entrega
[232:14] no nosso sistema de aquisição
[232:16] sem esforço
[232:18] então isso aqui torna uma oferta muito forte
[232:20] isso aqui faz com que essa oferta
[232:22] seja muito cara, inclusive
[232:24] então quando a gente tangibiliza
[232:26] isso eu criei uma oferta ridícula
[232:28] por isso que a oferta tem que ser pensada
[232:30] eu não sou bom em criar ofertas
[232:32] esse que é o ponto, eu não sou bom em criar ofertas
[232:34] as minhas ofertas são muito boas
[232:36] por que?
[232:38] porque eu capricho muito criando elas
[232:40] então essas ofertas funcionam
[232:42] lembro que eu falei para você
[232:44] do cliente
[232:46] se o meu cliente atingiu o resultado final
[232:48] ele não
[232:50] isso não vai fazer com que
[232:52] ele não enxergue mais valor no meu serviço
[232:54] eu fiz essa oferta para um cliente
[232:56] esse cliente comprou essa oferta
[232:58] ele pagou essa oferta
[233:00] olha que louco isso, ele pagou essa oferta
[233:02] nisso que ele pagou, eu fiz duas reuniões para ele
[233:04] e eu entreguei o resultado em duas reuniões
[233:06] e uma reunião na verdade
[233:08] o que aconteceu, a gente agendou duas reuniões
[233:10] e a gente já fez uma venda
[233:12] então nisso eu entreguei
[233:14] em uma hora eu entreguei o resultado que eu prometi
[233:16] sabe qual que foi a consequência disso, Antônio?
[233:18] automaticamente ele já fez um pixie e comprou de novo
[233:20] porque a oferta foi boa
[233:24] a minha oferta
[233:26] ela tem recorrência
[233:28] eu montei essa oferta inclusive com o título no telefone
[233:30] e aí eu falei tito
[233:32] quer ver eu vendo essa oferta pelo whatsapp
[233:34] e eu vendi e aí eu fiz essa venda
[233:36] e essa pessoa trouxe
[233:38] uma oferta parecidíssima disso
[233:40] eu vou elaborando e eu estou fazendo com que isso
[233:42] torne algo que a gente vai conseguir fazer
[233:44] então o único ponto que eu quero trazer
[233:46] para vocês é
[233:48] eu preciso que vocês entendam
[233:50] que a oferta de vocês
[233:52] quanto menos esforço seu cliente tiver
[233:54] o nome da oferta de vocês
[233:56] ele é importante
[233:58] ele é relevante, só que
[234:00] mais relevante que o nome, o nome bonitinho
[234:02] é você ser específico
[234:04] é você seguir esse protocolo aqui
[234:06] esse mágico aqui
[234:08] exatamente como que esse cliente
[234:10] ele vai acontecer, ou o que esse cliente vai fazer
[234:12] ou o que vai ter em cada parte da estrutura de ofertas
[234:14] não importa se o nome está bonito, se está feio
[234:16] se está esquisito falar ou se não está esquisito
[234:18] você precisa ficar muito claro
[234:20] para o seu cliente o que você faz
[234:23] que é um exemplo?
[234:25] cara, vocês que estão aqui
[234:27] eu estou fazendo um protocolo de vendas
[234:29] pra agências, precedores, serviços
[234:31] pessoas que têm um produto
[234:33] ou pessoas que vendem um produto bitube
[234:35] beleza, se você vem de um produto bitube
[234:37] é pra você, o que eu vou te entregar?
[234:39] eu vou te entregar
[234:41] literalmente, 20 mil reais
[234:43] em contratos, ou
[234:45] 5 vezes o valor que você investiu
[234:47] sem que você
[234:49] faça uma prospecção
[234:51] sem que você
[234:53] faça um trabalho comercial
[234:55] sem que você realmente
[234:57] fale com nenhum cliente
[234:59] o cliente ele vai vir pronto
[235:01] ele vai vir em entregue e você só vai atender
[235:03] e vai lucrar, vai trazer 5 vezes o ROY
[235:05] disso
[235:07] ou 3 vezes o ROY, só que esse ROY
[235:09] é recorrente
[235:11] então vamos supor que você colocou 500 reais
[235:13] realmente eu vou te entregar 1.500 em contratos
[235:15] só que se eu te entregar 1.500
[235:17] em contratos, já está pago
[235:19] e você vai ter um contrato recorrente
[235:21] se não for contrato recorrente, você vai me pagar 500 reais
[235:23] e eu tenho que te entregar pelo menos 2.500 reais
[235:25] isso, em 60 dias
[235:27] no nosso sistema de aquisição
[235:29] e quem vai fazer isso
[235:31] e aí eu torno mais específico ainda
[235:33] e eu tenho, sei lá
[235:35] 4 vagas disso porque quem vai fazer isso
[235:37] pessoalmente sou eu
[235:39] acabou, a oferta ficou muito forte
[235:41] a oferta ela ficou
[235:43] muito forte, então
[235:45] não necessariamente a gente vai fazer isso
[235:47] isso aqui eu estou exemplificando
[235:49] mas o que eu quero passar pra vocês
[235:51] eu quero passar pra vocês que não precisa ser tão forte
[235:53] não precisa ser tudo isso
[235:55] mas você pode fazer algo assim
[235:57] você pode fazer algo assim
[235:59] você pode pensar dentro
[236:01] dos seus produtos como que a sua oferta
[236:03] ela pode ficar assim, só que
[236:05] pra você cobrar e quanto que você vai cobrar
[236:07] da sua oferta, todas as ofertas
[236:09] elas vão ser fortes
[236:11] o que vocês precisam entender
[236:13] vocês precisam entender que
[236:15] tá, vocês precisam entender que
[236:17] essas ofertas que vocês
[236:19] fazem, o cliente
[236:21] ele tem que entender ela no máximo 2, 3 minutos
[236:23] beleza
[236:25] então o sistema médica é pra você entender
[236:27] pro seu cliente entender a sua oferta
[236:29] em 2, 3 minutos, Gustavo quanto que
[236:31] eu vou cobrar do meu cliente
[236:33] Gustavo quanto que eu vou cobrar por essa oferta
[236:35] que eu estou criando, e aí você volta
[236:37] ali pra aquela
[236:39] continha, tá, resultado
[236:41] é percepção de probabilidade
[236:43] de sucesso
[236:45] dividido por tempo
[236:47] de espera versus esforço
[236:49] e sacrifício, então você vai colocando
[236:51] tudo isso e aí você vai ter o valor do seu produto
[236:53] e você calcula isso com base na sua realidade
[236:55] com base na realidade de sua empresa
[236:57] o Jefferson falou, já estava com cartão na mão
[236:59] cara, se você quiser
[237:05] se quiser sim, porra, se quiser sim
[237:07] imagina, prospecto
[237:09] vendo, entrega o cliente
[237:11] você só entrega o serviço
[237:13] quem quiser, manda mensagem no whatsapp
[237:15] a gente pode fazer uma oferta assim pra vocês
[237:17] mas realmente aí seria uma oferta
[237:19] limitada mesmo, não é escassez
[237:21] lembra que eu falei de escassez real
[237:23] o Jefferson acabou de me mostrar
[237:25] uma coisa e eu acabei de ter um site
[237:27] aqui, então a escassez real é
[237:29] quem que teria que fazer essa reunião pra que isso custasse
[237:31] menos pra minha empresa, seria eu
[237:33] então
[237:35] se sou eu que preciso
[237:37] executar isso pra fazer menos reuniões
[237:39] ou seja, eu entregar essa venda pra vocês
[237:41] em uma, duas reuniões de vendas
[237:43] cara
[237:45] pra eu fazer isso, eu literalmente
[237:47] teria que dedicar o meu tempo
[237:49] e a minha agenda limitada, então eu conseguiria atender
[237:51] um monte de gente, e isso sim é uma escassez real
[237:53] e vocês sabem que isso é uma escassez real
[237:55] porque se trata de mim
[237:57] e vocês tratam ali da minha agenda, e eu posso provar
[237:59] minha agenda, vocês já conhecem meu dia a dia e tudo mais
[238:01] então quando a gente cria uma oferta, e isso sim
[238:03] é uma escassez real, beleza? agora ficou
[238:05] perfeito isso que o Jefferson falou
[238:07] porque isso cria uma escassez real
[238:09] porque isso cria uma escassez real
[238:11] não tem o seu whatsapp cara
[238:13] pode chamar lá, pode chamar lá
[238:15] vocês quiserem, tamo junto
[238:17] a gente negocia ali, a gente faz uma ligação
[238:19] depois e a gente entende isso, beleza?
[238:21] mas não é o objetivo aqui
[238:23] é que vocês entendam a oferta por si só
[238:25] pessoal, vocês conseguiram entender
[238:27] a oferta, como que você cria uma oferta
[238:29] eu tentei simplificar o máximo
[238:31] juro pra vocês, eu tentei simplificar
[238:33] um livro que tem quase 200 páginas
[238:35] em, sei lá, 4 linhas
[238:37] mas assim, eu acredito
[238:39] que isso ajude bastante vocês, beleza?
[238:41] cara, vocês são maluco mesmo
[238:45] vocês são maluco mesmo, obrigado por me chamar
[238:47] a gente mandei meu whatsapp aí
[238:49] chamou umas 3 pessoas aqui, não vou fazer
[238:51] nada agora, eu realmente vou focar
[238:53] no nosso evento, depois que acabar esse evento
[238:55] eu falo com vocês, mas bora pra cima
[238:57] gente, dentro disso aqui
[238:59] dentro dessa parte de criação de ofertas
[239:01] dentro dessa parte aqui de realmente como
[239:03] que você faz a oferta do teu produto
[239:05] vocês entenderam que a oferta, isso aqui é importante
[239:07] e eu preciso saber se vocês entenderam
[239:09] vocês entenderam que a oferta
[239:11] ela é totalmente diferente ali
[239:13] e de você conduzir uma reunião de vendas, né?
[239:15] vocês entenderam que isso não é a condução
[239:17] de reunião de vendas, se a oferta do seu produto
[239:19] é como você posicionar o seu produto, certo?
[239:23] vocês entenderam isso, beleza?
[239:25] roscara, ganhei até um assistente
[239:27] que é o Davi me mandando um whatsapp e tudo mais
[239:29] bom, então quando a gente
[239:31] faz isso, se vocês entenderam
[239:33] que a oferta, ela é diferente
[239:35] da reunião de vendas, o seu produto
[239:37] ele é diferente da reunião de vendas, o que
[239:39] que começa a acontecer? Você começa
[239:41] olha que louco isso, imagina-se
[239:43] antes da reunião de vendas, você consegue
[239:45] enviar um pdf ou um vários slides
[239:47] aonde você mostra sua oferta
[239:49] criada já, pro seu cliente
[239:51] onde você mostra pro seu cliente
[239:53] literalmente como funciona a sua oferta
[239:55] antes de ele entrar em reunião com você
[239:57] cara, isso adianta muito tempo, seu e dele
[239:59] porque se ele vem de um ebinário
[240:01] se ele vem de um evento, por exemplo
[240:03] ele tá pronto pra receber uma oferta
[240:05] então você pode mandar um pdf
[240:07] um slide aonde você mostra
[240:09] realmente a tua oferta, você não precisa
[240:11] colocar valor, aí você faz a venda na reunião
[240:13] você personaliza isso na reunião
[240:15] você faz o diagnóstico, adapta pro contexto
[240:17] dele dentro da reunião, mas a oferta
[240:19] é criada, fechou?
[240:21] ok pessoal, beleza
[240:23] fez sentido, tudo ok
[240:25] conseguiram entender? Beleza
[240:29] olha
[240:32] galera, eu quero que
[240:34] quem tenha alguma dúvida ou alguma coisa
[240:36] assim, eu já tô até meio gaguejando
[240:38] porque eu tô há muito tempo falando
[240:40] e o lab secou aqui
[240:45] então pessoal, quem tiver alguma dúvida
[240:47] pode ativar o microfone
[240:49] e perguntar ou pode mandar no chat
[240:51] vou responder dúvidas aqui um pouquinho
[240:53] depois a gente vai dar uma pausa
[240:55] até meio dia e meio
[240:57] e a gente vai entrevistar o título
[240:59] realmente pra ele contar um pouco do resultado
[241:01] da história dele
[241:03] que eu acho bacana, a gente não só faz um evento
[241:05] mas a gente mostrar pessoas ali
[241:07] que venceram, pessoas comuns
[241:09] que venceram e deixaram de ser pessoas comuns
[241:11] beleza? então pessoal
[241:13] alguém tem alguma dúvida? algum ponto?
[241:15] vocês querem ir ali pra pausinha
[241:17] pra depois a gente continuar o evento?
[241:19] fala pra mim
[241:21] vou dar um minuto
[241:23] pra vocês mandarem a dúvida
[241:25] se alguém tiver a dúvida, levantar a mão
[241:27] alguma coisa do tipo
[241:29] abrir um microfone e senão eu vou iniciar
[241:31] a nossa pausa ali pra que eu possa beber uma aguinha
[241:33] também
[241:35] estou suave se pausar
[241:37] tá ok? beleza
[241:39] beleza
[241:41] fechou então, pessoal, seguinte
[241:43] não vou desligar a chamada, não vou desligar nada
[241:45] todos vocês
[241:47] eu vou dar uma pausa aqui, vou comer
[241:49] eu vou beber uma água
[241:51] vou respirar um pouquinho
[241:53] meio dia e meio a gente volta
[241:55] e aí eu já vou entrevistar o Tito, uma hora da tarde
[241:57] a gente tem a sequência do nosso cronograma
[241:59] de aulas, fechou?
[242:01] não esqueçam de postar pelo menos um stories nosso
[242:03] lá e bora pra cima
[242:05] fechou pessoal? vou se ligar a câmera aqui
[242:07] e vejo vocês daqui a pouco
[242:09] bora dar esse descansinho
[265:00] ah opa
[265:02] dá dois minutinhos pra galera voltar
[265:04] e aí meu mano Tito
[265:06] tá ouvindo? você consegue beber meu microfone?
[265:08] consegue né
[265:10] eu não estou te ouvindo não
[265:12] será que é aqui?
[265:14] ou é aí?
[265:20] pior que eu não sei se alguém voltou, alguém voltou aí
[265:22] alguém já está aqui
[265:24] alô, alô, alô
[265:26] se estiver alguém ouvindo a gente
[265:28] confirma se vocês estão conseguindo ouvir o Tito
[265:32] porque eu não estou mais
[265:34] vocês estão conseguindo ouvir ele?
[265:36] ah não estou ouvindo ele, é o teu ou o Tito
[266:00] opa, opa, me ouvindo
[266:04] achou
[266:07] beleza
[266:17] estou animado
[266:19] eu também viado
[266:21] dá dois minutinhos
[266:23] só pra galera voltar, estou postando aqui também
[266:25] vamos
[266:30] bora deixa eu postar um stories
[266:47] aqui com meu mano Tito
[266:49] esse aqui merece stories meu mano
[267:00] bora lá
[267:24] enquanto a gente não inicia aqui Tito
[267:26] o que você está achando do evento?
[267:28] é real
[267:30] só aquele mapa mental
[267:32] cara
[267:34] a galera está me mandando muita mensagem
[267:36] saber sobre o que?
[267:38] sobre o viagem de confirmação
[267:40] na prospecção, não sei se eu acho que você chegou atrasado
[267:42] você nem viu essa parte
[267:44] cheguei um pouquinho atrasado
[267:46] caraca quem perdeu essa parte do viagem de confirmação
[267:48] depois vai ter que procurar
[267:50] e pensar que paguei 47 reais nesse evento
[267:52] vou tirar até um print disso aqui
[267:54] tirar um print disso aqui
[268:01] depois eu vou postar no inst
[268:07] dois minutinhos a gente inicia
[268:09] fechou meu mano Tito?
[268:11] fechou, estamos junto
[268:13] cara depois disso aqui só passando o cronograma pra galera
[268:15] teremos ali
[268:17] aula de closer
[268:19] depois teremos ali como você monta
[268:21] a tua R1 e a tua R2
[268:23] fechou?
[268:25] beleza galera
[268:27] e cara a R2 e R1
[268:29] é uma coisa diferente pra vocês
[268:31] por que?
[268:33] manda o link do seu instagram mano
[268:35] cara o link do meu instagram
[268:37] é a rouba Gustavo Nimoto
[268:40] vou passar aqui
[268:42] a rouba Gustavo Nimoto
[268:44] passa o seu link do instagram aí Tito
[268:46] cara seria bom se a galera marcar se a gente
[268:48] fez essa essa boa de marcar a gente no instagram
[268:50] porque isso dali incentiva mais pessoas
[268:52] a perguntarem o que nós estamos fazendo
[268:54] qual que é a loucura que a gente está fazendo aqui
[268:56] e isso é bom pra gente aqui
[268:58] mais pessoas dentro dos nossos
[269:00] eventos beleza
[269:02] vamos lá pessoal
[269:04] vamos iniciar
[269:10] Tito tá pronto aí?
[269:12] pronto mano
[269:14] vamos lá pessoal
[269:16] atualizando
[269:18] sobre as próximas aulas
[269:20] depois da entrevista com Tito
[269:22] a gente tem a aula de como fechar
[269:24] vendas ou seja é uma aula
[269:26] prática ali de como você vai fechar
[269:28] vendas eu falei um pouco sobre isso
[269:30] no meu último evento
[269:32] só que hoje eu vou aprofundar ainda mais
[269:34] que é realmente como fechar vendas
[269:36] depois como você organizar
[269:38] suas reuniões de vendas se você vai fazer uma
[269:40] única reunião se você vai fazer uma ou duas
[269:42] reuniões como que você organiza isso
[269:44] como que você realmente faz pra que
[269:46] isso ali seja feito de uma forma
[269:48] eficiente
[269:50] com base na aula de fechamento como base
[269:52] na aula de closer ali tá então
[269:54] a gente tem a metodologia a gente tem tudo
[269:56] ali depois disso tá
[269:58] depois dessas aulas ali da R1
[270:00] R2 depois da aula de closer a gente
[270:02] vai pro próximo ponto que é a
[270:04] nutrição infinita que é algo que
[270:06] eu venho pregando ultimamente e que
[270:08] com certeza é um dos pilares
[270:10] ali que tá fazendo a venda todo dia
[270:12] acho que o Tito tá ficando isso também
[270:14] de nutrição infinita isso faz com
[270:16] que você sempre tenha clientes isso te
[270:18] torna um profissional diferente
[270:20] te torna um profissional que sempre
[270:22] vai ter vantagem sobre os outros
[270:24] porque você sempre vai estar conectado
[270:26] com o máximo de pessoas possíveis
[270:28] fechou bora lá iniciar nossa
[270:30] entrevista o nome do Tito tá ali
[270:32] o Adson Tito tá que tá ali
[270:34] em cima do de ele não sei porque
[270:36] você tá usando essa webcam ali que coloque
[270:38] o nome do obs mas enfim
[270:40] a hora né
[270:42] eu entendi mas bora
[270:44] pra cima Tito
[270:46] é um prazer ter você aqui e eu
[270:48] achei bacana chamar você pra esse evento
[270:50] galera quem puder ligar a câmera participar
[270:52] aqui com a gente eu acho muito bacana
[270:54] a câmera e participa ali também
[270:56] eu gosto de ver o rosto de vocês a reação de vocês
[270:58] então vocês fazem parte disso
[271:00] mas Tito eu te chamei muito mais aqui porque
[271:02] cara você é um caso
[271:04] é um caso de sucesso ali
[271:06] e eu não coloco pois o Tito é um caso de sucesso nosso
[271:08] não o Tito você é um caso de sucesso seu
[271:10] tá você se esforçou você fez
[271:12] talvez a gente deu muito caminho
[271:14] talvez a gente deu muita direção a gente
[271:16] abriu acesso a gente abriu network
[271:18] a gente abriu um monte de coisa pra você conseguir
[271:20] conquistar o seu objetivo mas quem
[271:22] o resultado foi necessariamente você
[271:24] e eu acho muito legal
[271:26] começar contigo e conversar com você
[271:28] porque quando eu conheci o Tito
[271:30] ele literalmente
[271:32] cara
[271:34] ele tava numa situação um pouco difícil
[271:36] ele tava numa situação onde ele realmente
[271:38] veio conversar comigo
[271:40] eu acho que o Tito tinha sei lá R$128
[271:42] e ele falou Gustavo eu quero te pagar R$128
[271:44] me ajuda por favor não sei o que
[271:46] e acabou que não deu certo aquilo
[271:48] mas assim ainda assim a gente ajudou
[271:50] e cara esse cara que cresceu muito
[271:52] ele realmente mudou a vida dele
[271:54] se você olhar o Tito de uns meses atrás
[271:56] e não é eu não tô falando de muito tempo
[271:58] falando de que 3, 4 meses Tito
[272:00] acho que é mais ou menos isso
[272:02] né então se a gente olhar o Tito de
[272:04] antes e olhar o Tito de agora cara
[272:06] são duas pessoas completamente diferentes
[272:08] e hoje eu quero entender um pouco mais do
[272:10] que fez ele crescer
[272:12] um pouco dos resultados dele
[272:14] um pouco da história dele e Tito
[272:16] começa se apresentando aí pra galera
[272:18] como que você entrou nesse mundo
[272:20] como que você conheceu a gente
[272:22] qual que é a fase que você tava
[272:24] qual que é o resultado que você tem hoje
[272:26] eu quero ouvir um pouco da tua história
[272:28] cara
[272:30] cara
[272:32] vamos lá, primeira vez fazer isso aqui
[272:34] tá
[272:36] eu me chamo Tito
[272:38] eu conheço o Nimoto
[272:40] tem mais ou menos um
[272:42] tem um ano e um pouquinho o Nimoto
[272:44] tem né
[272:46] sabia que era tanto tempo assim
[272:48] é que a gente conversa desde o ano passado
[272:50] que eu conheço ele
[272:52] de lá pra cá
[272:54] já comprei alguns produtos dele
[272:56] é
[272:58] mais de fato pessoal
[273:00] cara
[273:02] eu acho que
[273:04] o que mais
[273:06] aconteceu comigo tipo assim a diferença
[273:08] mesmo que fez eu ter bastante resultado
[273:10] foi a iniciativa
[273:12] a iniciativa
[273:14] tem a clareza do que de fato
[273:16] eu tinha que executar
[273:18] então
[273:20] eu tinha saído de 120 reais
[273:22] na carteira
[273:24] que foi o que eu tinha utilizado pra pagar o Nimoto
[273:26] pra cara hoje
[273:28] 15 mil meios
[273:30] é surreal
[273:32] posso colocar um adendo
[273:34] o Tito olhou pra mim e ele falou assim
[273:36] cara eu tenho 120 e poucos reais
[273:38] ou eu compro comida
[273:40] ou eu compro alguma coisa com você
[273:42] aí ele pegou não eu quero
[273:44] ele ficou fazendo um follow up até
[273:46] ele conseguiu comprar alguma coisa pra ajudar ele
[273:48] pra ele realmente eu vou me dedicar
[273:50] vou me esforçar e ele tinha um outro sócio
[273:52] lembra que eu falei de não carregar as pessoas
[273:54] ele tinha um outro sócio que o cara não executava
[273:56] na mesma frequência que ele
[273:58] e ele pegou e deixou esse cara pra trás
[274:00] o Tito o que eu quero saber de verdade
[274:02] eu acho que um dos pontos até pra gente
[274:04] conseguir explorar um pouco tua história
[274:06] cara
[274:08] como que tu se sente
[274:10] sabendo que
[274:12] tu venceu
[274:14] e que tipo assim
[274:16] não necessariamente você chegou aonde você quer
[274:18] chegar ainda
[274:20] mas quando você olha
[274:22] aquele comparativo que você tá
[274:24] eu lembro que a gente já entrou em call
[274:26] e você tava desesperado
[274:28] eu lembro disso que a gente entrou em call
[274:30] você tava desesperado, aconteceu um monte de coisa
[274:32] e
[274:34] cara o que tu acha que mudou
[274:36] dentro da tua essência ali
[274:38] o que você acha que mudou dentro do Tito pra
[274:40] realmente ele virar
[274:42] essa chavinha pra ele realmente conseguir fazer as coisas
[274:44] cara
[274:46] confiança
[274:48] esquece que tem a galera aqui viu
[274:50] não fica impressionada não
[274:52] não, confiança
[274:54] de fato eu não tinha confiança
[274:56] antes, eu ia dar o pit
[274:58] todo frouxo sem
[275:00] postura na reunião e tudo mais
[275:02] eu tava tão desesperado por grana
[275:04] que eu ficava ansioso
[275:06] eu
[275:08] tipo assim, a metade da reunião
[275:10] eu nem entendi de fato o que eu ia entregar
[275:12] e eu já
[275:14] já falava o pit e ia quer fechar comigo
[275:16] bora fechar por isso e tudo mais
[275:18] então desespero
[275:20] é algo que eu não tenho mais
[275:22] a minha confiança aumentou muito
[275:24] então de fato isso fez uma grande diferença
[275:26] nos resultados
[275:28] me posicionar de fato
[275:30] ali como profissional
[275:32] como especialista naquele assunto
[275:34] como alguém que entende daquele cenário
[275:36] daquele cliente
[275:38] alguém que não necessariamente tá ali
[275:40] só pra vender mas tá ali pra ajudar ele
[275:42] então isso fez total diferença
[275:46] tito, até nesse ponto
[275:48] trazendo um pouco disso que tu falou
[275:50] que tu era meio que travado
[275:52] tava desesperado por dinheiro e tudo mais
[275:54] cara
[275:57] eu queria entender como que tu saiu
[275:59] desse desespero porque eu sei que tem uma galera
[276:01] que por, às vezes tá numa condição difícil
[276:03] às vezes nem tá numa condição tão apertada assim
[276:05] mas ainda sempre
[276:07] a conta bate ali mês a mês
[276:09] é sempre equilibrado ou às vezes fica no negativo
[276:11] ou bem pouquinho no positivo
[276:13] sempre tá naquela correria total
[276:15] eu quero saber de ti cara
[276:17] o que mudou pra fazer você não ter essa ansiedade
[276:19] e você conseguir alcançar esse resultado
[276:21] porque isso não é normal
[276:23] aquilo que eu falei hoje cedo
[276:25] não sei se você tava aqui
[276:27] mas eu falei hoje cedo que é muito difícil
[276:29] uma pessoa ela vencer quando ela tá
[276:31] de dificuldade porque ela tem que carregar
[276:33] muitas pessoas e ela tem que fazer muitas coisas
[276:35] cara eu queria que você se abrisse
[276:37] o que que fez realmente
[276:39] tu virar essa chave mano
[276:41] porque pra mim eu ainda não tá muito claro
[276:43] o que que fez você virar essa chave
[276:45] o que que tirou essa ansiedade
[276:47] o que que fez você realmente
[276:49] eu consigo de verdade acreditar em si mesmo
[276:51] cara
[276:53] eu parei pra pensar que se eu
[276:55] mano que se eu ficar
[276:57] se pensando o tempo todo antes das minhas reuniões
[276:59] na minha filha que tá representando de mim
[277:01] nos móveis
[277:03] que eu tava vendendo pra pagar o aluguel
[277:05] cara se eu
[277:07] na comida que tava acabando
[277:09] dentro da geladeira
[277:11] cara se eu ficasse pensando nisso mano
[277:13] eu ia morar na rua
[277:15] eu ia morar na rua então
[277:17] eu tinha duas opções
[277:19] eu continuava pensando nisso e ficando desesperado nas reuniões
[277:21] pô eu
[277:23] só entregar vadeus e mano
[277:25] executava
[277:27] aí eu escolhi a segunda opção e cheguei onde eu cheguei
[277:29] cara
[277:31] e que conselho você dá pra quem tá nesse momento também
[277:35] mano não adianta
[277:37] ficar pensando nos problemas
[277:39] entendeu pensei muito nos problemas
[277:41] é por isso que eu só tava me afundando
[277:43] me afundando o tempo todo
[277:45] me afundando cara eu não tinha dinheiro
[277:47] nem pra comprar uma água mineral mano
[277:49] entendeu
[277:51] água mineral 7,50
[277:53] pô
[277:55] e eu via
[277:57] tipo assim levando embora minhas coisas
[277:59] a mesa que minha mãe tinha me dado
[278:01] eu tinha que vender pra complementar o aluguel
[278:03] eu olhava
[278:05] as pessoas no meu redor e tipo assim todo mundo
[278:07] vendendo
[278:09] postando print de pô o sininho tocando
[278:11] e eu falei maluco o que que tá acontecendo isso comigo
[278:13] aí eu
[278:15] cara eu decidi que se eu ficasse
[278:17] pensando nisso com esse pensamento
[278:19] eu não iria evoluir
[278:21] eu iria ficar desesperado
[278:23] porque a gente iria sentir isso
[278:25] porque a gente não tem culpa de nada
[278:27] eu no lugar dele não fecharia com desesperado
[278:29] e daí que cara
[278:31] foi de fato isso que eu mudei mano
[278:33] esse meu posicionamento foi algo muito difícil
[278:35] muito muito difícil
[278:37] muito difícil manter a cabeça firme
[278:39] ali quando você tá desesperado
[278:41] quando você fala
[278:43] quando você faz um pitch de 2 mil
[278:45] e o cliente quer pagar 500 reais
[278:47] é muito difícil mano
[278:49] é muito difícil
[278:51] tá realmente se posicionar
[278:53] negociar com cliente
[278:55] com risco de perder a venda
[278:57] exatamente sendo que se ele falar 100 reais
[278:59] eu fechava
[279:01] entendeu?
[279:03] é foda
[279:05] chegando no momento eu já passei por isso
[279:07] algumas dificuldades na minha vida
[279:09] cara
[279:11] eu já contei um pouco pra você
[279:13] já contei um pouco pra algumas pessoas
[279:15] que teve situações onde o teto da minha casa caiu na minha cabeça
[279:17] e
[279:19] no dia de chuve e tudo mais
[279:21] e mano eu sei exatamente o que você tá falando
[279:23] que às vezes tipo 20 reais
[279:25] cara você falava mano se eu conseguir esses 20 reais
[279:27] pelo menos eu consigo comer
[279:29] pelo menos eu consigo comprar tal coisa
[279:31] sabe?
[279:33] então eu sei exatamente o que você tá falando
[279:35] e cara
[279:37] eu queria que tu
[279:41] tu passou por isso
[279:43] e a gente já vai chegar no resultado que você tem
[279:45] e eu tenho
[279:47] alguns conselhos pra algumas pessoas que estão nesse momento
[279:49] só que eu acho que
[279:51] só quem viveu esse momento e superou também
[279:53] consegue dar visões diferentes
[279:55] e realmente
[279:57] algo além do processo pra
[279:59] conseguir entregar pra essas pessoas
[280:01] o que elas podem fazer?
[280:03] eu queria saber de teto
[280:05] cara o que que
[280:07] tu acredita?
[280:09] tipo assim as pessoas que estão nessa condição
[280:11] nesse exato momento ou as pessoas que estão
[280:13] em alguma situação muito difícil nesse momento
[280:15] podem fazer pra realmente
[280:17] passar por essa dificuldade
[280:19] assim como tu passou também
[280:21] que conselho tu daria pra essas pessoas?
[280:24] cara
[280:26] nesse momento da minha vida
[280:28] foi o momento que eu mais
[280:30] me apeguei a Deus mano
[280:32] não tem muita coisa pra falar
[280:34] eu de fato me apeguei a ele
[280:36] era o tempo todo conversando com ele
[280:38] sabe aquilo que tu falou um tempo atrás
[280:40] tu acordava logo cedo e falava
[280:42] o amor soja por tua conta
[280:44] tipo assim, igual um maluco falando
[280:46] eu mano fazia literalmente isso
[280:48] eu acordava
[280:50] orava
[280:52] pedia pra tirar os problemas
[280:54] da minha cabeça me mantendo foco
[280:56] e eu só fazia mano
[280:58] eu de fato eu dava o passo e ele colocava
[281:00] o chão literalmente
[281:02] entendeu
[281:04] então o conselho que o do
[281:06] cara se eu olhasse pra mim um tempo atrás
[281:08] eu não iria acreditar
[281:10] que eu iria chegar onde eu cheguei hoje
[281:12] então um pouco tempo
[281:14] é surreal isso
[281:16] mas se eu pudesse
[281:18] dar só um único conselho mano
[281:20] é
[281:22] não deixar os problemas
[281:24] te travarem
[281:26] e tipo assim
[281:28] nunca se sentir sozinho
[281:31] eu me sentia muito
[281:33] sozinho naquele tempo
[281:35] então nunca se sentir sozinho
[281:37] e de fato saber que Deus
[281:39] está contigo que é só você se apega a
[281:41] ele e executar você já mano
[281:43] tudo aqui sabe o que executar
[281:45] todo mundo sabe
[281:47] que executar se não souber
[281:49] sabe onde é que procura o que tem que ser
[281:51] executado
[281:53] então
[281:55] cara
[281:57] eu de fato nem outro eu queria ter
[281:59] um texto enorme aqui um roteiro pra falar
[282:01] o que tem que ser feito mas
[282:03] mano é literalmente isso
[282:05] coragem
[282:07] coragem também
[282:09] você lembra uma conversa que a gente
[282:11] falou um dia
[282:13] um dia o título ele me ligou
[282:15] eu vou falar isso aqui mas por isso mesmo
[282:17] não tem problema não
[282:19] depois você cabrava comigo perdão
[282:21] mas um dia o título me ligou
[282:23] tava eu e o Jorge e o título nessa ligação
[282:25] e aí
[282:27] na primeira mão
[282:29] eu sabia que o título ele ia pedir dinheiro
[282:31] emprestado pra mim eu não sou uma pessoa
[282:33] que empresta dinheiro
[282:35] e cara
[282:39] o título ele vem totalmente abalado
[282:41] pra falar com a gente
[282:43] cara título
[282:45] eu acho que essa é uma
[282:47] sensação bacana porque eu tenho esse
[282:49] lado dessa história e eu tenho a minha
[282:51] visão dessa história de como que ela
[282:53] aconteceu
[282:55] eu quero que tu conte a tua visão
[282:57] porque pensa que
[282:59] muito de vocês às vezes
[283:01] acham que vocês estão sendo abandonados por outras pessoas
[283:03] que quando vocês pedem dinheiro emprestado
[283:05] ou quando vocês fazem alguma coisa ninguém te ajuda
[283:07] ou você tá numa situação difícil ninguém te ajuda
[283:09] ou ninguém faz nada por você
[283:11] e eu acho que
[283:13] um dos pontos de virada seu
[283:15] e pelo que eu lembro cara isso foi um dos pontos de
[283:17] viradas mesmo seu
[283:19] foi essa conversa que você teve comigo com Jorge
[283:21] eu queria a tua visão e a tua história
[283:23] de como que foi isso daí tipo na tua cabeça
[283:25] como que foi isso conta pra galera
[283:27] conta pra eu quero saber também como que
[283:29] você se sentiu nesse dia o que que tu pensou
[283:31] pode falar sem filtro
[283:33] de verdade mesmo eu queria ouvir de tipo
[283:35] porque eu acho que esse dia foi muito marcante pra mim
[283:37] eu ourei muito pra Deus depois daquele
[283:39] daquela nossa conversa
[283:41] cara eu
[283:43] eu sabia da tua história
[283:45] já tu já tinha falado
[283:47] e daí que eu pensei
[283:49] pô mano
[283:51] eu também tô quebrando a cara
[283:53] tô me fudendo muito aqui e o NemMoto já
[283:55] meio que passou por muito por isso então vou pedir
[283:57] uns conselhos a ele pra ver
[283:59] que aquele de fato ali vai ser ele mostro
[284:01] o caminho pra você executado
[284:03] e eu fiquei fazendo um follow com você
[284:05] até aconteceu acho que eu fiz uns cinco
[284:07] seis follow contigo e aconteceu
[284:09] o Jorge tava presente também
[284:11] acho que vocês conheçam o Jorge
[284:15] cara
[284:17] pô um bate-papo que eu não tava
[284:19] com intenção nenhuma de pedir dinheiro
[284:21] emprestado a única coisa
[284:23] que eu queria de fato ali era só
[284:25] ouvir da tua própria boca mano
[284:27] pra assim
[284:29] cara parece loucura
[284:31] mas eu queria ouvir de você
[284:33] que pô tito vai dar certo
[284:35] confia
[284:37] tito continua fazendo o que você tá fazendo
[284:39] que vai dar certo mano eu não tava
[284:41] nem aí se não tinha convido a minha geladeira
[284:43] eu ia continuar executando
[284:45] entendeu e tipo assim
[284:47] cara
[284:49] eu acho que se alguém visse essa conversa
[284:51] isso eu seria extremamente cancelado
[284:53] cara você iria ser cancelado
[284:55] pode falar o que rolou lá
[284:57] cara eu vou falar mano
[284:59] o NemMoto eu tava esperando
[285:01] isso que eu acabei de falar pra vocês
[285:03] só que eu não vi nada disso mano
[285:07] ele literalmente ele falou
[285:09] pô escuta passando fome a procurar o emprego
[285:13] cara foi loucura
[285:15] essa cal foi loucura
[285:17] mas abriu minha cabeça mano
[285:19] abriu minha cabeça
[285:21] literalmente
[285:23] um dos maiores insights do NemMoto
[285:25] que eu peguei nessa cal
[285:27] foi de
[285:29] mano tu tem que fazer dinheiro
[285:31] tu tem que fazer
[285:33] tu mexe aqui mexe ali mas tu tem que
[285:35] fazer dinheiro tem que colocar comida na mesa
[285:37] não importa se tipo assim se tu tá fazendo
[285:39] uma parada
[285:41] e cara você tá vendo que não tá
[285:43] sei lá dando um retorno
[285:45] você não vai morrer fazendo isso
[285:47] cara vai mexendo outras coisas
[285:49] tu não tem dinheiro
[285:51] mas a única coisa que tu tem agora é tempo
[285:53] então aproveita ele
[285:56] então de fato eu parei de ficar
[285:58] em simplesmente
[286:00] ficar só fazendo aquela
[286:02] única coisa ali que eu não tava conseguindo
[286:04] performar muito bem e comecei a expandir
[286:06] comecei a procurar outras coisas
[286:08] e meio que
[286:10] cara coragem
[286:12] fui lá e executei
[286:14] então cara pode parecer loucura
[286:16] mas se eu não tivesse tido aquela cal contigo
[286:18] eu acho que eu não estaria onde
[286:22] eu estou hoje mano
[286:24] cara isso vem muito
[286:26] do que a gente falou hoje cedo
[286:28] eu trouxe o título justamente pra perguntar isso
[286:30] hoje cedo eu tava falando de mentalidade
[286:32] tá título
[286:34] de pessoas que carregam outras pessoas
[286:36] quando o título chegou em mim
[286:38] e ele chegou em mim triste
[286:40] cara abalado, nitidamente abalado
[286:42] nitidamente triste
[286:44] e tudo mais
[286:46] cara eu falei algumas coisas de Deus
[286:48] eu falei algumas coisas que eu acredito também
[286:50] mas assim eu não fui tão
[286:52] eu não recebi ele do jeito que ele queria ser
[286:54] recebido sabe
[286:56] muitas das vezes o que que acontece
[286:58] porque que a gente carrega pessoas
[287:00] porque
[287:02] a gente não acredita nessas pessoas
[287:04] ou quando o título
[287:06] ele chegou em mim e ele falou Gustavo eu tô sem dinheiro
[287:08] eu não consigo sustentar
[287:10] os meus filhos ou eu não consigo fazer o que
[287:12] eu preciso fazer eu não preciso eu não consigo nem
[287:14] me alimentar direito
[287:16] e aí ele contou uma história
[287:18] tipo assim bizarramente
[287:20] cara pesada e era pesada tá título
[287:22] você é um grande vencedor por hoje você chegar
[287:24] e tá onde você tá
[287:26] mas ele me contou uma história
[287:28] que eu fiquei caraca
[287:30] história forte o Jorge
[287:32] ele também tava tipo caraca mano
[287:34] que história louca no seu que
[287:36] e aí cinco segundos depois eu falei assim
[287:38] título
[287:40] mas se você tá fazendo isso não dá certo
[287:42] porque que tu não arruma um trampo
[287:44] não tem desculpa pra você não arrumar um emprego
[287:46] tá cheio de obra precisando de serviço de pedra
[287:48] tá cheio de no seu que e aí eu comecei a colocar
[287:50] um monte de coisa pro título que ele poderia fazer
[287:52] e não só tipo assim mas ele
[287:54] ah eu vou desistir do meu sonho
[287:56] eu falei se você não quer desistir
[287:58] seu sonho tem esteja disposto a
[288:00] perder tudo esteja disposto a
[288:02] perder tudo por ele
[288:04] ou se não faço que você precisa
[288:06] com as responsabilidades que você tem
[288:08] primeiro sai do buraco
[288:10] depois que você sair do buraco você se
[288:12] ajeita você se arruma e mesmo assim
[288:14] ele se estiu e ele continua empreendendo
[288:16] e ele continua fazendo as coisas porque a primeira
[288:18] palavra que eu falei pra ele
[288:20] assim cara título ah eu vou te ajudar
[288:22] título fica tranquilo nossa a gente
[288:24] vai te ajudar a gente vai fazer com que isso
[288:26] aconteça a gente vai fazer com que você
[288:28] sair do buraco que é o que a maioria das
[288:30] pessoas falaria ah título faz isso faz
[288:32] aquilo eu falei não título se não tem
[288:34] dinheiro arruma um emprego se não tenho
[288:36] que fazer cara não tenho que fazer se
[288:38] não tá dando certo muda
[288:40] mas tu precisa fazer tua responsabilidade
[288:42] não é minha responsabilidade eu te
[288:44] dei conhecimento suficiente para que
[288:46] você conseguiu fazer as coisas agora faz
[288:48] isso e eu vi o rosto dele mudando
[288:50] aquele dito tá eu vi
[288:52] eu lindamente vi o rosto dele mudando
[288:54] eu vi o Jorge mudando naquele dia
[288:56] e muitas das vezes eu tenho
[288:58] certeza e eu trouxe o título aqui porque
[289:00] eu tenho certeza que eu seria cancelado
[289:02] pelo jeito que eu tratei o título
[289:04] eu tenho certeza que a maioria das pessoas
[289:06] olhariam e falarem assim cara esse
[289:08] cara na cristão esse cara não é bom
[289:10] com as pessoas esse cara é um arrogante
[289:12] esse cara é isso aquilo aquilo outro
[289:14] mas o que eu falei pra ele
[289:16] deixa eu falar uma coisa o problema das
[289:18] pessoas é delas
[289:20] não é meu
[289:22] e ele só passa a ser meu a partir do
[289:24] momento que eu vou resolver aquilo
[289:26] se eu não vou resolver 100% do
[289:28] problema o problema não é meu
[289:30] e quando a gente entende
[289:32] isso a gente consegue ajudar ainda
[289:34] muito mais as pessoas a gente consegue
[289:36] fazer porque as pessoas elas prosperem muito mais
[289:38] e cara uma das
[289:40] primeiras coisas uma das primeiras
[289:42] coisas que eu tive quando eu saí da
[289:44] empresa extrema e eu quero
[289:46] tipo perguntar isso pro título
[289:48] foi quando
[289:50] uma das minhas primeiras felicidades foi
[289:52] quando eu fui pelo mercado
[289:54] pela primeira vez eu podia comprar tudo
[289:56] que eu queria
[289:58] sabe quando você vai no mercado você pode
[290:00] comprar tipo cara se eu quiser isso
[290:02] aqui eu posso comprar eu quero saber de
[290:04] título quanto quando que você
[290:06] percebeu que cara eu estou ganhando
[290:08] dinheiro cara minha vida mudou
[290:10] qual foi a estala quais foram os pequenos
[290:12] que você sentiu assim
[290:14] cara eu até compartilhei contigo no
[290:16] WhatsApp mano foi quando eu fui no mercado
[290:18] com
[290:20] minha mulher e daí que eu
[290:22] enchei o carrinho mano enchei o carrinho
[290:24] colocou muita coisa muita coisa
[290:26] muita muita coisa ou parece loucura
[290:28] enchei
[290:30] na hora de passar o cartão
[290:34] cara não passou o cartão
[290:38] ai se liga
[290:40] eu não me preocupei nada porque
[290:42] eu tinha por dez vezes aquilo no
[290:44] px na conta mano
[290:46] ai eu falei não deixa que eu passo aqui
[290:48] você não vai passar essa vergonha
[290:51] e daí que pô paguei mano
[290:53] ali deu um estralo ali
[290:55] aquele dia
[290:57] eu chorei onimoto
[290:59] aquele dia eu chorei
[291:01] porque eu sempre pedi a deus
[291:03] pra sentir aquela situação
[291:05] qual a sensação de você no mercado
[291:07] não se preocupar com o valor quanto
[291:09] eu passei em qual a sensação mano
[291:11] e eu descobri essa sensação
[291:13] é muito bom
[291:15] entendeu é muito bom
[291:17] outra coisa também onimoto
[291:19] que aconteceu não foi somente
[291:21] referente ao mercado
[291:23] foi quando minha mãe
[291:25] ela estava precisando fazer alguns exames
[291:27] e eu
[291:29] e ela estava desesperada falando
[291:31] pô meu filho que como eu vou fazer
[291:33] e tudo mais eu
[291:35] ai eu falei mãe não se preocupa pode
[291:37] ficar que eu vou pagar sua construção
[291:39] pode ficar na minha casa
[291:41] cara aquilo
[291:43] eu dei um conforto tão grande pra ela
[291:45] deu uma segurança
[291:47] toda vez que ela lembra
[291:49] disse ela chora porque ela também nunca imaginou
[291:51] entendeu
[291:53] ela nunca imaginou que tão cedo eu iria fazer isso por ela
[291:57] então é
[291:59] é isso que
[292:01] é muito louco mano
[292:03] cara eu posso ter certeza
[292:05] se fosse preciso mano
[292:07] voltar lá atrás
[292:09] tipo assim perder tudo que eu tenho hoje
[292:11] tudo voltar lá atrás
[292:13] mesmo assim eu seria muito grato
[292:15] por tudo que eu vivi de lá até cá
[292:17] e
[292:19] eu teria total certeza que eu não iria ficar
[292:21] naquela situação por muito tempo
[292:23] entendeu
[292:25] e eu meio que ia
[292:27] dar dois passos pra trás
[292:29] pegar imposto pra
[292:31] dar mais cinco com a frente
[292:33] então cara é muito foda essa sensação mano
[292:37] é uma sensação de tipo assim
[292:39] cara
[292:41] eu não sei se a galera entende
[292:43] mas quem realmente
[292:45] teve muito pouco
[292:47] quando era criança vai entender isso
[292:49] da equipe o que ele tá falando
[292:51] às vezes você conseguir pagar um exame
[292:53] às vezes você conseguir lotar um carrinho de mercado
[292:55] é muito melhor do que comprar uma casa
[292:57] é muito melhor do que comprar um carro
[292:59] é muito melhor do que ver 50, 100, 200, 1 milhão
[293:01] 2 milhões na conta
[293:03] porque
[293:05] essa primeira sensação
[293:07] essa primeira
[293:09] apontada ali que você tipo
[293:11] caralho
[293:13] olha isso
[293:15] eu não tinha eu nem sonhava com isso aqui
[293:17] e hoje eu posso
[293:19] e eu falo pra vocês
[293:21] essas primeiras vitórias
[293:23] essas primeiras condições
[293:25] vão ser o que vai fazer vocês realmente
[293:27] irem pra frente
[293:29] tá muito preocupado cara
[293:31] eu quero ter uma Mercedes eu quero ter uma empresa de milhões
[293:33] eu quero ter uma empresa de bilhões e milhões e milhões
[293:35] e milhões
[293:37] aí você não é grato pelo que você já tem
[293:39] e também não coloca
[293:41] suas pequenas próximas vitórias
[293:43] então
[293:45] dentro disso tudo
[293:47] e
[293:49] até uma pergunta que eu tenho pra ti tito
[293:53] hoje como que tu tá
[293:55] hoje como que tá a sua condição financeira
[293:57] hoje como que você tá hoje
[293:59] como que a sua vida tá hoje
[294:01] e
[294:03] como que tá tipo assim teu processo comercial
[294:05] tuas vendas tuas coisas
[294:07] cara agora eu quero saber do título empresário
[294:09] porque eu não vi
[294:11] tipo desde o início
[294:13] desde a primeira reunião que eu fiz com o título eu falei cara
[294:15] tu seria um excelente close e um excelente vendedor
[294:17] eu só nunca te contrataria
[294:19] pelo estado que você tá
[294:21] porque sem estragar todos os meus reuniões
[294:23] tentando vender a qualquer custo
[294:25] eu falei exatamente isso pra ele
[294:27] e
[294:29] eu queria perguntar pro tito agora
[294:31] tipo cara
[294:33] como que tá as coisas hoje em dia
[294:35] até pra galera ter um cooperativo
[294:37] e até pra galera entender aonde que tu chegou
[294:39] boa
[294:41] cara
[294:43] é
[294:45] enquanto um pouco antes de entrar aqui
[294:47] eu tinha feito uma venda mano
[294:51] quase todo dia
[294:53] que ficou assim
[294:55] cara
[294:57] pô mano parece loucura isso
[295:03] mensalmente
[295:05] eu atualmente não to com tanto MRR
[295:07] assim
[295:09] algo fixo tá
[295:11] mas eu to buscando toco ainda atrás pra isso
[295:13] mas todos os meses
[295:15] tá girando em torno de 10 a 15
[295:17] desde
[295:19] um pouco
[295:21] depois daquele nosso bate-pap
[295:23] mas acho que um mês depois
[295:25] não teve nem um mês que foi menos de 10
[295:27] 10k
[295:29] entender o líquido que eu to falando
[295:31] de fato dentro do meu bolso
[295:34] praticamente isso
[295:36] teve meses que 13, 14
[295:38] aí 11, 15
[295:40] entender mas nada menos de 10
[295:42] tá
[295:46] de MRR eu não tenho um tanto assim
[295:48] de MRR eu não tenho algo tão absurdo
[295:50] MRR
[295:52] ele em torno de estar
[295:54] uns 1.700
[295:56] os 1.700
[295:58] referente a vendas
[296:02] cara toda semana eu consigo
[296:04] fazer pelo menos um ou duas vendas
[296:06] ali teve semana que eu já consegui
[296:08] fazer 4, 5 mil
[296:10] de fato ali
[296:12] tá muito bom
[296:16] cara eu processo comercial
[296:18] eu to trabalhando muito
[296:20] naquilo que tu falou Nimoto
[296:22] eu sei que agora cara meus resultados
[296:24] vão triplicar
[296:26] porque de fato eu quero entender isso
[296:28] porque tu tá em 10 a 15
[296:30] e eu sei que tu quer chegar muito mais
[296:32] eu quero entender dentro da tua operação
[296:34] mesmo agora indo pro lado mais técnico
[296:36] porque a galera conseguiu replicar isso também
[296:38] o que tu tá fazendo agora
[296:40] e como que tu pretende chegar no novo patamar
[296:42] tipo 50, 100, 200 mil
[296:44] boa
[296:46] o Nimoto ele deu um site muito
[296:48] foda, uma aula mesmo
[296:50] de
[296:52] relacionamento e follow up
[296:54] eu vendo o título
[296:56] eu fiquei pô será que ele vai falar
[296:58] sobre oi bom dia tudo bem
[297:00] vai comprar ou não
[297:02] tá aqui o PIX se quiser pagar
[297:04] eu pensei ele a falar
[297:06] sobre isso, só que foi muito mais
[297:08] a lei mano
[297:10] e foi a Linimoto que eu entendi
[297:12] eu falei pô cara
[297:14] todos os meus follow ups
[297:16] são na intenção de vender
[297:18] para ele
[297:20] perguntando se ele vai querer comprar
[297:22] literalmente
[297:24] se ele vai querer comprar
[297:26] qual a melhor forma eu posso fazer
[297:28] para facilitar essa forma de pagamento
[297:30] esse método de pagamento
[297:32] só que daí como é que tá funcionando
[297:34] meu comercial hoje
[297:36] eu abro proposta
[297:38] todo santo dia
[297:40] todo santo dia
[297:42] e daí o que acontece com essas propostas
[297:44] é
[297:46] tem vezes que o ciclo de vendas
[297:48] é curto, tem vezes que ele prolonga um pouco mais
[297:50] tá
[297:52] prolonga um pouco mais
[297:54] dura em torno ali às vezes de um mês, dois meses, três meses
[297:56] e o que é que eu estou começando a fazer agora
[297:58] o que é que de fato vou começar a aplicar
[298:00] é
[298:02] referente a
[298:04] meu que dá aulas para esse cara mesmo né
[298:06] pô se ele não comprou
[298:08] na primeira reunião e na segunda
[298:10] cara ele vai fazer dez reuniões comigo
[298:12] o cara vai comprar daqui a um, daqui a dois anos
[298:14] eu não ligo mas ele vai comprar
[298:16] então eu estou seguindo muito nisso
[298:18] assim dando aulas para ele mesmo
[298:20] o que você tá achando?
[298:22] o que você tá achando disso?
[298:24] cara eu estou me sentindo muito mais experiente
[298:26] naquele assunto mano
[298:28] muito mais experiente
[298:30] ele tá me enxergando
[298:32] com uma autoridade ali mesmo sabe
[298:34] tipo assim tudo que eu falo pra ele
[298:36] ele me ouve, ele de fato
[298:38] ele aplica
[298:40] isso
[298:42] é uma pergunta que eu tenho pra ti
[298:44] hoje você tá baseando
[298:46] a sua estrutura basicamente
[298:48] hoje o comercial é só você né
[298:50] é só eu com o time ali
[298:52] hoje você tá sozinho no comercial
[298:54] falou que tá abrindo propostas todos os dias
[298:56] beleza isso já é um bom sinônimo
[298:58] você tá trabalhando bastante no comercial
[299:00] então você tá abrindo propostas todos os dias
[299:02] e você tá nutrindo essas propostas para um longo prazo
[299:04] o que eu quero entender
[299:06] é você já tem
[299:08] um objetivo pros próximos meses
[299:10] você já mapeou isso como que você vai fazer isso
[299:12] você pode
[299:14] tipo você já tem isso ali meio que mapeado
[299:16] ou ainda não, ou você só tá fazendo
[299:18] nutrição infinita
[299:20] tá fazendo o arroz que o feijão bem feito
[299:22] e aumentando o faturamento ali de forma progressiva
[299:24] cara eu tô fazendo arroz que o feijão bem feito
[299:26] mano
[299:28] eu tô nutrindo, eu tô aplicando o que você falou
[299:32] aplicando as estratégias de follow up
[299:34] o relacionamento com os clientes
[299:36] eu tô, não só de fato
[299:38] sendo um especialista naquele assunto
[299:40] mas um especialista no nicho dele
[299:44] então eu tô de fato aplicando isso
[299:46] e fazendo o arroz que o feijão
[299:48] e tá dando certo
[299:50] top top
[299:52] e aí vamos lá
[299:54] você tá fazendo uns 10 mil por mês líquido
[299:56] e aí cara até pra gente não estander muito aqui
[299:58] porque a gente tem que continuar as aulas
[300:00] eu te trouxe aqui mais pra galera te conhecer
[300:02] inclusive
[300:04] o que eu falo uma outra informação bacana
[300:06] mas assim Tito
[300:08] qual que é o conselho que você dá
[300:10] se você fosse resumir de forma prática
[300:12] pra quem ainda não tá nos 10 mil
[300:14] 15 mil de faturamento líquido
[300:16] chegar nisso ali nos próximos meses
[300:18] nos próximos 30, 60, 80
[300:20] dias ali
[300:22] pra realmente conseguir chegar nesses 10 mil líquido
[300:24] qual que é a dica prática que tu daria
[300:26] ali que pô
[300:28] na tua opinião é muito difícil disso falhar
[300:30] boa boa
[300:32] cara isso também a gente entra no outro site
[300:34] tudo que eu aprendi com esses caras
[300:36] já entrou no outro site que tu falou
[300:38] que é de fato
[300:40] cara
[300:43] abrir propósitos todos os dias
[300:47] que consequentemente
[300:49] pô a cada
[300:51] no mínimo ali é cada 2 semanas sai uma venda
[300:53] se tu de fato fez um trabalho bem feito
[300:55] então tem certeza que não vai passar fome
[300:59] e manter e manter a constância
[301:01] e de fato ter a perseverança ali
[301:03] que eu tive um tempo atrás
[301:05] não se acomodar
[301:07] eu tava vendo que algo não estava funcionando
[301:09] muito bem
[301:11] eu não ficava
[301:13] não ficava dando um errado
[301:15] o tempo todo
[301:17] eu estudava e eu pô como é que eu vou fazer isso
[301:19] aqui bem feito mano como é que de fato
[301:21] posso executar isso eu não somente me perguntava
[301:23] como qualquer informação que eu recebia
[301:25] do nemoto e ir lá e aplicava
[301:27] então cara o que mudou
[301:29] de fato ali o conselho que eu dou cara
[301:31] pra ele chegar no espaturamento
[301:33] é
[301:35] é ter esse fluxo comercial
[301:37] de abrir propósitos
[301:39] todo santo dia mano
[301:41] é ter um funil de captação forte
[301:43] prospecção ativa, acudicar
[301:45] ligação, disparo
[301:47] é marcar reunião, tem que marcar reunião, tem jeito
[301:49] é marcar reuniões
[301:51] é abrir propósitos
[301:53] fazer essa nutrição
[301:55] trabalhar o lead
[301:57] ficar desferado pra vender
[301:59] não somente pensar em vender
[302:01] pra esse cara mas dar uma aula pra ele
[302:03] né, dar um diferencial
[302:05] as pessoas
[302:07] eu percebi isso nemoto e espadrão
[302:09] que os clientes eles tão sentindo falta
[302:11] disso sabe, tão sentindo falta
[302:13] de pessoas, de profissionais
[302:15] que não tá ali só pra vender
[302:17] mas tá ali pra gerar resultado pra ele
[302:19] então me impulsionei como esse cara
[302:21] olha não tô aqui só pra te vender isso não
[302:23] tô aqui pra gerar resultado pra você
[302:25] eu tô aqui pra você, eu tenho um parceiro estratégico
[302:27] consequentemente é uma venda mais longa
[302:29] porém é uma venda com mais certeza
[302:31] mais certeza cara
[302:33] mais certeza
[302:35] entendeu? eu tenho ni-moto
[302:37] hoje, eu tenho um
[302:39] cara, em 57 mil
[302:41] em propósitos em aberto
[302:43] eu tô nutrindo
[302:45] esse 57 mil vai estar na minha conta
[302:47] daqui a alguns meses mais vai estar
[302:49] eu tô nutrindo, eu tô dando aulas pra ele
[302:51] eu tô de fato ali
[302:53] trabalhando com esse lead
[302:55] eu enxergo esse lead
[302:57] eu tenho um CRM
[302:59] um Kanban ali
[303:01] então eu vejo ele numa coluna X
[303:03] e eu penso como é que eu vou levar ele pra coluna Z
[303:05] por exemplo
[303:07] então eu vou trabalhando ele
[303:09] vou montando estratégias pra isso
[303:13] cara e até pra finalizar
[303:15] eu vou trazer um ponto aqui
[303:17] que eu acredito tá
[303:19] o Tito nos próximos
[303:21] sei lá, um, dois anos
[303:23] vai ser o meu aluno que mais vai crescer
[303:25] e eu vou falar isso na frente de todos vocês
[303:27] e eu sei que muitos de vocês vão se sentir desafiados
[303:29] com isso
[303:31] mas ele vai ser um cara aqui que tá nesse ecossistema
[303:33] que tá nessa sala que mais vai crescer
[303:35] sabe por que?
[303:37] porque eu falei essa mesma coisa
[303:39] que eu falei pra ele, pra várias outras pessoas
[303:41] e só ele tá fazendo essa nutrição de jeito certo
[303:43] só ele realmente me manda
[303:45] mensagem todos os dias
[303:47] eu tô fazendo isso, o resultado foi esse
[303:49] tô fazendo essa nutrição, sabe por que?
[303:51] é muito difícil, e eu vou falar uma coisa pra vocês
[303:53] é muito difícil você abrir
[303:55] cinco, dez, quinze, vinte milhões
[303:57] em proposta aberta e você não fechar
[303:59] um milhão de vendas no ano
[304:01] dois milhões de vendas, três milhões, quatro milhões
[304:03] de vendas no ano se você nutra esse cliente
[304:05] infinitamente
[304:07] então a mentalidade dele já tá muito melhor
[304:09] do que a maioria dos empresários do Brasil
[304:11] que é, cara, chegou o Lidio Lidio não comprou foda-se
[304:13] vou adquirir mais pessoas
[304:15] vou sempre buscar mais pessoas, vou sempre ficar
[304:17] buscando mais e mais e mais e mais pessoas
[304:19] e hoje tem aula disso
[304:21] que a galera eles tratam uma pessoa
[304:23] por si só, cara, comprou, comprou
[304:25] não comprou descarto, vou achar outra
[304:27] e aí eles vão pra outra, vão pra outra
[304:29] agora a pessoa que nutre o Lidio infinitamente
[304:31] cara, é impossível essa pessoa ela não vencer no longo prazo
[304:33] existe aqueles caminhos
[304:35] que, cara, talvez aconteçam
[304:37] e existem uns caminhos de certeza
[304:39] o título ele tá indo pra um caminho de certeza
[304:41] a maioria tá indo pra um caminho onde há uma aposta
[304:43] só que eu falo, o caminho de certeza
[304:45] mesmo o cara dá aposta acertando
[304:47] o caminho de certeza ele vai ganhar
[304:49] no longo prazo
[304:51] porque ele continua, ele não precisa acertar o tempo todo
[304:53] ele literalmente
[304:55] ele tem vários momentos pra acertar com o cliente dele
[304:57] ele tem várias oportunidades
[304:59] ele nunca perde, ele é muito bem falado
[305:01] ele é muito bem quisto por esses clientes
[305:03] o relacionamento dele é muito bom
[305:05] então o que eu falo, pô, ele abre o propósito todos os dias
[305:07] vamos supor que essa proposta ela feche daqui um ano
[305:09] daqui um ano ele vai estar vendendo
[305:11] o que ele já vende mais as propostas
[305:13] que ele abriu todos os dias
[305:15] então duas, três, quatro
[305:17] e aí vocês vão ver ele vendendo 10, 15 mil por dia
[305:19] e aí vão perguntar pra ele qual que é o segredo
[305:21] abre proposta, faz a reunião, faz a reunião bem feita
[305:23] e trata bem o cliente
[305:25] aí as pessoas vão falar, cara, não
[305:27] não é isso
[305:29] não é isso o segredo, isso daí não vai acontecer
[305:31] não é isso, deixa eu procurar outra coisa
[305:33] deixa eu procurar outro caminho
[305:35] que é o que a maioria tá fazendo
[305:37] então título
[305:39] há uns meses atrás eu tinha apostado em outra pessoa
[305:41] hoje eu aposto em você
[305:43] o cara que mais vai crescer ali
[305:45] então nos próximos tempos
[305:47] parabéns pela sua constância
[305:49] e eu quero saber, pô
[305:51] se alguém tiver alguma dúvida, quiser pedir um conselho
[305:53] quiser fazer networking com você
[305:55] pode chamar lá no teu privado, cara?
[305:57] cara, pode sim
[305:59] pode sim, vou até colocar o número aqui
[306:01] top demais, top demais
[306:03] então pessoal, quem quiser conhecer o título
[306:05] quem quiser falar com ele
[306:07] realmente trocar um networking com ele
[306:09] entender um pouco mais sobre a operação dele
[306:11] cara, eu gostei de trazer o título aqui
[306:13] realmente porque ele é uma dessas pessoas
[306:15] que tem essa visão de consistência
[306:17] então vai casar perfeito
[306:19] com o conteúdo que eu vou passar agora
[306:21] título, parabéns, tu é um vitorioso, cara
[306:23] eu sei que você não tá acostumado a falar
[306:25] em público, você tá até um pouco nervoso
[306:27] mas você vai se acostumando com isso
[306:29] logo logo você vai falar pra milhares
[306:31] dezenas, centenas de pessoas ali
[306:33] e cara, parabéns
[306:35] de verdade mesmo, tem orgulho de ti, irmão
[306:37] obrigado, irmão
[306:39] agora eu falo, vai dar tudo certo
[306:43] tá bom, demorou, mas falou
[306:45] obrigado
[306:47] obrigado pela participação, irmão
[306:49] bora pra aula, mas fica aí, vai assistir a aula
[306:51] bora
[306:53] pessoal
[306:55] dito isso, fizemos a pausa
[306:57] deixei a galera almoçar enquanto
[306:59] entrevistava o título, fazia as coisas
[307:01] mas chegou o horário de a gente voltar
[307:03] realmente a prestar atenção no conteúdo
[307:05] o horário de a gente realmente fazer
[307:07] o que a gente precisa fazer, que é
[307:09] aprender o processo pra que a gente consiga aplicar
[307:11] e fazer com que
[307:13] as nossas vendas subam, a gente ganha
[307:15] mais dinheiro, a gente tenha mais
[307:17] dinheiro no nosso bolso, fechou?
[307:19] vou compartilhar a tela aqui
[307:21] e aí a minha promessa principal
[307:23] aqui pra vocês, dessa aula
[307:25] a minha promessa principal
[307:27] dessa aula pra vocês, dessa aula
[307:29] de closer, é que
[307:31] cara, você vai aprender a vender
[307:33] e você vai aumentar muito
[307:35] sua taxa de conversão, eu só te peço
[307:37] uma coisa com essa aula, tá?
[307:39] tome muito cuidado
[307:41] não faça vendas que você não quer fazer
[307:43] porque
[307:45] essa aula vai mostrar literalmente
[307:47] como você consegue fazer qualquer
[307:49] venda, como você consegue induzir
[307:51] seu cliente a comprar de você
[307:53] só que isso é muito perigoso pra você
[307:55] porque, muitas das vezes, o que a gente
[307:57] vai fazer? a gente vai pegar
[307:59] e a gente vai
[308:01] literalmente
[308:03] ignorar
[308:05] que a gente tem que vender um produto de qualidade
[308:07] a gente tem que vender pro cliente alinhado
[308:09] e a gente vai sair vendendo igual maluco
[308:11] então, vocês vão aprender
[308:13] a vender muito dentro dessa aula
[308:15] vocês literalmente vão aprender
[308:17] como que vocês vão fechar as reuniões de venda de vocês
[308:19] como que vocês vão conduzir a reunião de venda de vocês
[308:21] o que que vocês precisam fechar
[308:23] quais as portas vocês precisam fechar
[308:25] só que é muito importante pessoal
[308:27] de verdade mesmo, é muito importante
[308:29] que vocês não façam isso
[308:31] de maneira irresponsável
[308:33] igual eu já fiz lá
[308:35] eu estou falando sério que eu já quebrei uma empresa por tanto vender
[308:37] de tanto vender porque meu operacional
[308:39] era uma merda
[308:41] e eu sempre fui muito bom nessa parte de vendas
[308:43] então, isso que vocês vão ver
[308:45] ele é tanto bom quanto ruim
[308:47] depende de como você utilizar
[308:49] isso, depende de como você utilizar
[308:51] esse processo de vendas
[308:53] fechou? então, a minha grande
[308:55] promessa pra vocês é
[308:57] que com excelência, você vai conseguir vender
[308:59] todos os dias, desde que você tenha reuniões
[309:01] desde que você tenha demanda, mas você vai conseguir
[309:03] vender todos os dias
[309:05] o que eu preciso de vocês é realmente responsabilidade
[309:07] para que as vendas não se tornem um pesadelo
[309:09] fechou? ok
[309:11] pode começar a aula, todo mundo aqui
[309:13] eu quero saber quem está online aqui
[309:15] a gente tem 24 pessoas
[309:17] mas eu preciso saber das 24
[309:19] quantas pessoas estão aqui com a gente
[309:21] manda um oi aí no chat
[309:26] opa eu
[309:29] de verdade mesmo
[309:31] essa aula
[309:33] que eu vou passar aqui para vocês
[309:35] somente essa aula aqui
[309:37] eu acredito que
[309:39] ela vai fazer com que a sua empresa
[309:41] ela mude de rumo ali
[309:43] ou você realmente aprende a vender
[309:45] de fato de uma vez por todas
[309:47] e a sua dificuldade nunca mais seja uma reunião de vendas
[309:49] nunca mais seja uma venda
[309:51] fechou? então, cara
[309:53] eu vou passar aqui a metodologia de closer
[309:55] depois eu passo essa parte aqui
[309:57] no promesse plano
[309:59] mas eu vou passar essa metodologia de closer
[310:01] utilizando realmente a palavra closer
[310:03] para que vocês consigam entender a metodologia
[310:05] de uma vez por todas e eu
[310:07] perdi meu mapa mental, deixa eu centralizar a tela
[310:09] aqui de novo
[310:11] senão eu não vou conseguir
[310:13] falar e nem apresentar
[310:15] bora lá
[310:19] deixa eu abrir, então bora lá pessoal
[310:21] quando a gente fala sobre closer
[310:23] e é muito diferente
[310:25] você ter um processo de reuniões
[310:27] que diferenciar certas coisas
[310:29] a sua oferta
[310:31] a sua oferta
[310:33] é diferente da sua reunião
[310:35] de vendas
[310:37] o seu processo de reunião de vendas
[310:39] o seu processo de r1 r2
[310:41] é diferente do seu processo
[310:43] de condução de reunião
[310:45] de fechamento, de você aprender
[310:47] a vender porque o processo
[310:49] de vendas ele serve pra que?
[310:51] o processo de vendas ele te blinda
[310:53] para que seja algo padrão para que você consiga
[310:55] isso que eu vou ensinar pra vocês é
[310:57] vocês venderem independente do processo
[310:59] vocês venderem independente da oferta
[311:01] vocês venderem independente de tudo
[311:03] porque o que eu vou passar aqui pra vocês é
[311:05] como vocês vão vender
[311:07] isso aqui não é sua estrutura de r1
[311:09] isso aqui não é sua estrutura de r2
[311:11] depois na aula de r1 r2 a gente vai ter como
[311:13] aplicar isso aqui dentro dessa aula
[311:15] mas eu preciso que vocês entendam que isso aqui
[311:17] é realmente pra vocês aprenderem a vender
[311:19] fechou?
[311:21] beleza, quando a gente
[311:23] tem um método closer a gente
[311:25] separa em cada uma das letras
[311:27] a primeira coisa que a gente precisa ter
[311:29] é a clareza
[311:31] do qual o nosso cliente
[311:33] ele se reuniu com a gente
[311:35] gente, eu vou explicar uma coisa que a maioria das pessoas
[311:37] elas ignoram e a maioria das pessoas
[311:39] elas começam a reunião
[311:41] e ele não é a primeira coisa que elas focam
[311:43] a primeira coisa que elas focam não é isso aqui
[311:45] e isso aqui deveria ser
[311:47] a primeira coisa que qualquer vendedor
[311:49] ele vai focar dentro
[311:51] de uma reunião de vendas, dentro
[311:53] de um processo de vendas
[311:55] tanto que às vezes a minha reunião ela é até chata
[311:57] no início porque eu não passo por próximo passo
[311:59] até eu descobrir isso
[312:01] o que que é isso, o que que eu preciso
[312:03] nesse primeiro passo da reunião
[312:05] clareza, qual que é o motivo
[312:07] pelo qual o meu cliente ele está se reunindo
[312:09] comigo hoje?
[312:11] por que que ele aceitou a sua ligação
[312:13] por que que ele aceitou a sua reunião
[312:15] você tem que responder essas perguntas
[312:17] você tem que ter essa clareza
[312:19] da reunião
[312:21] qual o problema que ele quer resolver
[312:23] o que que eu falei que chamou a atenção dele
[312:25] eu preciso entender
[312:27] a primeira coisa em qualquer processo de vendas
[312:29] em qualquer processo de realmente
[312:31] aquisição de clientes
[312:33] é você entender o que
[312:35] chamou a atenção do seu cliente
[312:37] e qual que é o resultado que ele quer chegar
[312:39] é a clareza do que ele precisa
[312:41] então a primeira coisa que eu sempre entendo
[312:43] é qual que é a clareza
[312:45] qual que é o problema que essa pessoa tem
[312:47] qual que é o resultado que essa pessoa quer
[312:49] por que que essa pessoa decidiu
[312:51] se reunir comigo
[312:53] e aí trazendo até um
[312:55] comparativo lógico com vocês
[312:57] por que que vocês
[312:59] participaram desse evento por exemplo
[313:01] por que que vocês toparam participar desse evento
[313:03] por que que vocês aceitaram ver por esse evento
[313:05] por que que vocês aceitaram perder
[313:07] às vezes um dia de sábado inteiro
[313:09] para ver nesse evento por que vocês entraram nessa call
[313:11] o qual problema vocês buscam resolver
[313:13] quando eu respondo isso e quando
[313:15] eu entendo nessa resposta eu tenho o próximo passo
[313:17] então eu só
[313:19] coloco isso aqui
[313:21] eu só coloco esse problema quando isso
[313:23] sai da boca do meu cliente
[313:25] eu só enxergo que eu
[313:27] passei por essa etapa e essa é a primeira etapa
[313:29] para você conseguir fazer uma venda bem feita
[313:31] quando isso sai da boca do meu cliente
[313:33] eu vou dar um
[313:35] um exemplo
[313:37] cara eu entrei numa reunião
[313:39] e se eu entro na reunião
[313:41] a primeira coisa que eu preciso entender
[313:43] é o que você quer melhorar dentro
[313:45] da nossa empresa
[313:47] dentro da nossa abordagem
[313:49] eu queria entender um pouco da sua situação atual
[313:51] e qual que é o resultado que você busca
[313:53] o que você busca ativamente
[313:55] o que você quer resolver
[313:57] o qual que é o problema que a gente
[313:59] consegue mapear
[314:01] que você chamou a sua atenção
[314:03] às vezes numa ligação de prospecção
[314:05] às vezes numa reunião
[314:07] que você quer melhorar dentro da nossa empresa
[314:09] dentro da nossa abordagem
[314:11] da ligação de prospecção
[314:13] às vezes numa reunião, às vezes no evento
[314:15] o que chamou a atenção, o que te trouxe
[314:17] é a primeira coisa que eu vou entender do cliente
[314:19] porque se eu não entender isso
[314:21] eu não vou conseguir ter o resultado final
[314:23] que eu quero
[314:25] eu não vou conseguir ter o resultado final
[314:27] eu vou virar um vendedor de quê?
[314:29] de passagens e não do destino final
[314:31] então a primeira coisa
[314:33] que eu preciso mapear é
[314:35] qual é o objetivo do meu cliente
[314:37] preciso ter clareza do objetivo do meu cliente
[314:39] e tendo certeza do objetivo do meu cliente
[314:41] cara se torna muito mais fácil
[314:43] quando seu cliente ele fala pra você assim
[314:45] pô Gustavo
[314:47] eu quero comprar um CRM
[314:49] eu quero comprar ali a sua acessoria de marketing
[314:51] porque eu quero fazer
[314:53] eu quero resolver esse problema específico
[314:55] não se torna muito mais fácil
[314:57] ele comprar de você
[314:59] ah Gustavo eu quero resolver esse problema específico
[315:01] eu quero ter as métricas do meu time
[315:03] para que eu possa melhorar
[315:05] e vender mais
[315:07] se ele sabe isso
[315:09] se ele sabe o problema
[315:11] e se você consegue mapear esse problema
[315:13] se você consegue fazer
[315:15] sair da boca dele meio que meio confuso
[315:17] o que ele precisa
[315:19] qual é o objetivo dele da empresa dele
[315:21] aonde que ele quer chegar
[315:23] Gustavo eu não sei onde eu quero chegar
[315:25] Gustavo o meu cliente
[315:27] ele não sabe o que ele quer
[315:29] ele não sabe o que ele precisa
[315:31] cara mas ele quer chegar em algum lugar
[315:33] deixa eu entender qual é o problema que você tem hoje
[315:35] o que você tem hoje
[315:37] então é preciso entender o desejo
[315:39] o destino final
[315:41] ou eu preciso entender o problema que esse cara tem
[315:43] e deixa eu falar uma coisa pra vocês
[315:45] toda empresa tem problema
[315:47] toda empresa tem algum desejo
[315:49] todo mundo quer algum resultado
[315:51] então você precisa arrancar isso do seu cliente
[315:53] então se você cumpre esse primeiro passo
[315:55] com maestria
[315:57] de você identificar
[315:59] o que esse cliente ele precisa
[316:01] o que esse cliente ele tá buscando
[316:03] é um primeiro passo muito forte pra você seguir todos os outros
[316:05] então
[316:07] eu vou usar o exemplo do
[316:09] do Gabriel que é um exemplo mais diferente
[316:11] que eu acho que tá aqui hoje
[316:13] o Gabriel ele vende um plano
[316:15] e esse plano que ele vende ele implementa
[316:17] em clínicas e aí essas clínicas
[316:19] elas têm um serviço de assinatura que elas podem
[316:21] vender pro cliente delas
[316:23] beleza esse é o produto dele
[316:25] e aí ele entra numa reunião com esse produto
[316:27] com um cliente que se interessou por esse produto
[316:29] e aí o objetivo do Gabriel
[316:31] no primeiro momento não é apresentar o produto dele
[316:33] é entender cara por que você entrou em contato comigo
[316:35] por que você gostou disso
[316:37] por que você quer vender
[316:39] receita recorrente pro seu cliente
[316:41] você quer diminuir o custo
[316:43] você quer aumentar a margem da sua empresa
[316:45] você quer ter uma receita recorrente
[316:47] qual que é o teu objetivo final
[316:49] por que você quer ter isso
[316:51] e aí esse é o primeiro ponto
[316:53] se eu não identificar o problema
[316:55] e eu vou bater muito nessa tecla
[316:57] porque se eu não identificar
[316:59] o problema se eu não clarificar
[317:01] o que eu preciso
[317:03] eu não vou conseguir vender
[317:05] ou vai ser muito mais difícil de eu vender
[317:07] então faça o cliente já nos primeiros momentos
[317:09] de uma reunião ou de qualquer conversa
[317:11] ou até mesmo na parte de prospecção
[317:13] quem é a SDR do nosso time
[317:15] cara se você consegue me entregar
[317:17] antes da reunião
[317:19] eu conversei com o cara, liguei pro cliente
[317:21] e ele falou que o grande problema dele é esse
[317:23] que se ele resolver esse problema
[317:25] a vida dele estava resolvida
[317:27] é muito mais fácil você vender
[317:29] é muito mais fácil você vender
[317:31] e aí o que você faz com essa informação
[317:33] que você tem?
[317:35] você vai pra label
[317:37] ou seja, rotular o problema
[317:39] você vai clarificar o problema
[317:41] pro seu cliente, ele deixou muito específico
[317:43] pra você
[317:45] mas o que você vai fazer
[317:47] essencialmente no primeiro momento
[317:49] assim que você entendeu o problema
[317:51] você vai fazer uma pergunta pra ele
[317:53] então hoje você tá aqui
[317:55] porque você quer resolver esse problema
[317:57] ou você tem o desejo de fazer
[317:59] essa coisa aqui específico, certo?
[318:01] eu confirmo com ele
[318:03] pra entender
[318:05] eu nunca vou supor com o meu cliente
[318:07] que eu entendi ele e que ele me entendeu
[318:09] então eu preciso de algumas confirmações
[318:11] cara, identificou o problema?
[318:13] e eu vou perguntar
[318:15] oh Tito, hoje então o seu maior problema
[318:17] é essa aquisição de mais clientes
[318:19] oh Tito, então o seu maior problema
[318:21] hoje é esse operacional
[318:23] que você não tá conseguindo rodar
[318:25] hoje Tito, então o maior problema
[318:27] é sua oferta, alguma coisa do tipo
[318:29] cara, eu vou nomear o problema dele
[318:31] eu vou dar um nome pro problema dele
[318:33] e eu vou repetir o problema dele
[318:35] já dando esse nome
[318:37] de forma clarificada, de forma resumida
[318:39] pra que ele confirme pra mim
[318:41] ele fala, não só isso
[318:43] na real eu acho que esse nem é o principal problema
[318:45] você tem que entender
[318:47] se ele fala que esse não é o principal problema
[318:49] o que você faz e você volta
[318:51] lá pra cima, e aí você entende
[318:53] e aí sim você rotula esse problema
[318:55] você precisa entender
[318:57] e assim que você entender você rotula esse problema
[318:59] você dá um nome pra esse problema
[319:01] você literalmente
[319:03] identificou o que esse problema tem
[319:05] ou qualquer problema que esse cliente tem
[319:07] você deu um nome, você confirmou
[319:09] com ele que esse é o exato problema
[319:11] aí sim, aí você começou
[319:13] a tua reunião de vendas de verdade
[319:15] deixa eu fazer uma pergunta pra vocês
[319:17] dentro do processo de reunião de vendas de vocês
[319:19] que vocês fazem hoje
[319:21] algum de vocês já faz isso
[319:23] cara, a primeira coisa que você se identifica do cliente
[319:25] é o problema, e a segunda coisa que você faz
[319:27] é fazer com que ele fale sobre esse problema
[319:29] que ele realmente confirme
[319:31] que esse é o real problema dele
[319:33] que é isso que ele quer resolver agora
[319:35] que a maior urgência da vida dele agora
[319:37] é resolver esse problema, algum de vocês já faz isso
[319:39] pode falar, se você faz isso, cara, perfeito
[319:41] se você não faz isso, começa a fazer
[319:43] que vocês vão ver as vendas de vocês
[319:45] saindo de uma forma absurda
[319:47] vocês vão ver a taxa de conversão de vocês saindo
[319:49] de uma forma absurda, beleza
[319:51] então, esse primeiro ponto
[319:53] esse segundo ponto de você realmente
[319:55] confirmar que aquele é o problema específico
[319:57] e aí, aquele problema específico
[319:59] você rotulou o nome dele
[320:01] o que você pode fazer agora
[320:03] e as pessoas falam muito de spin-selling
[320:05] necessariamente, spin-selling é bom
[320:07] mas
[320:09] quando a gente coloca esse ponto
[320:11] e quando a gente vai seguir nessa ordem
[320:13] que eu passei pra vocês
[320:15] talvez nem precise tanto de spin-selling
[320:17] talvez nem precise tanto enrolar
[320:19] numa reunião de vendas, talvez a sua venda seja mais direta
[320:21] talvez o seu ciclo de compra seja menor
[320:23] eu faço isso sem querer
[320:25] e tem uma taxa de conversão alta em reunião
[320:27] agora sem o motivo
[320:29] beleza, vamos aumentar mais ainda
[320:31] pra que você consiga vender produtos mais caros
[320:33] e aí, isso aqui
[320:35] tem que estar no subconsentio de vocês
[320:37] isso tem que estar no consentio de vocês
[320:39] eu faço reunião de vendas com esse mapa mental aberto
[320:41] porque se eu me esquecer
[320:43] de qualquer um desses passos
[320:45] eu não vou ter concluído a reunião perfeita
[320:47] que eu gosto de fazer
[320:49] eu tenho o que eu coloco de reunião perfeita
[320:51] a reunião perfeita é onde eu pego esse
[320:53] closer ali
[320:55] e eu zero todas as etapas
[320:57] e as três perguntas chaves pra
[320:59] prender outro cliente
[321:01] então, o que eu vou fazer a partir do momento
[321:03] que eu nomeei a dor dele
[321:05] eu vou começar a entender
[321:07] cara, você já tentou fazer alguma coisa pra resolver isso antes?
[321:09] pois já tentei, não deu certo
[321:11] ah, já tentei isso, já tentei aquilo
[321:13] cara, eu vou enfatizar a dor
[321:15] quanto tempo vocês ficaram fazendo isso?
[321:17] cara, por que que deu errado?
[321:19] ou por que que você nunca tentou isso?
[321:21] qual que foi um pedimento disso?
[321:23] tu perdeu o dinheiro com isso?
[321:25] o que eu vou fazer?
[321:27] eu quero que ele sofre, eu quero que um cliente cria uma tensão de
[321:29] tipo assim, cara, o que vai acontecer
[321:31] se você não
[321:33] realmente resolver isso?
[321:35] quais são as consequências de você não resolver isso?
[321:37] quanto de faturamento
[321:39] que está perdendo por isso?
[321:41] e ele vai te falar normalmente
[321:43] por que? porque você rotulou o problema dele
[321:45] você clarificou, você levou a conversa pra uma linha reta
[321:47] muitas de vocês já ouviram falar da linha reta
[321:49] do Jordan Belford
[321:51] de realmente o cara que era o lobo de Wall Street
[321:53] quando a gente fala da linha reta
[321:55] e até um ponto pra vocês
[321:57] até um ponto pra vocês entenderem
[321:59] sobre isso, a linha reta
[322:01] quando a gente define um tema pra uma conversa
[322:03] e aí a gente vai seguindo
[322:05] conforme esse tema
[322:07] não necessariamente a metodologia que a gente está passando aqui
[322:09] mas eu preciso que vocês imaginem
[322:11] então imagine a conversa de vocês
[322:13] a conversa de toda a reunião de vocês
[322:15] por mais que você tenha oferta
[322:17] por mais que você tenha um produto que você vai vender
[322:19] por mais que você tenha várias outras coisas
[322:21] pensa que você entrou numa trilha
[322:23] e essa trilha tem 50 caminhos diferentes
[322:25] pra você vender o mesmo produto
[322:27] a partir do momento que você rotula
[322:29] e a partir do momento que você descobre
[322:31] o problema desse cliente, você faz ele repetir
[322:33] você rotula esse problema
[322:35] você criou um caminho
[322:37] você pegou desses 50 caminhos o melhor
[322:39] e aí você vai
[322:41] revisar a dor com esse cara
[322:43] essa dor ela vai fazer o que?
[322:45] ela vai fazer com que o seu cliente
[322:47] ele
[322:49] vende o teu produto
[322:51] eu vou te explicar o porquê
[322:53] porque enquanto eu enfatizo a dor
[322:55] eu posso fazer algumas perguntas
[322:57] eu posso perguntar cara
[322:59] e o teu desejo hoje é resolver isso
[323:01] cara, resolver isso
[323:03] para você seria bacana
[323:05] seria bacana
[323:07] para isso que você me falou que você já tentou
[323:09] cara, quanto dinheiro você perdeu com isso?
[323:11] perdi tanto
[323:13] quanto tempo você está querendo fazer isso?
[323:15] tanto tempo
[323:17] quanto você acha que você ia faturar com isso?
[323:19] x? então se você está atento
[323:21] tempo sem fazer isso
[323:23] querendo fazer isso, você vai faturar x a mais
[323:25] com isso, significa que nesse meio período
[323:27] você deve ter perdido tanto reais, certo?
[323:29] certo
[323:31] o cliente nessa parte é deixar ele triste
[323:33] é deixar ele triste
[323:35] isso que você está fazendo
[323:37] está te trazendo preocupação
[323:39] por que eu vou deixar ele triste?
[323:41] não intencionalmente
[323:43] eu gosto de ver meu cliente triste
[323:45] mas eu preciso que ele eleve a nível de consciência dele
[323:47] de que isso que ele tem agora
[323:49] é um problema para ele
[323:51] de que isso que ele está fazendo
[323:53] é um grandíssimo problema para ele
[323:55] se ele não entender
[323:57] que isso que
[323:59] está faltando para ele
[324:01] é uma dor
[324:03] e até o que ele deseja fazer
[324:05] que ele não te apresentou como uma dor
[324:07] mas ele te apresentou o que que acontece
[324:09] se ele não fizer
[324:11] como que ele vai se sentir? quanto que ele vai perder?
[324:13] o que que ele vai perder? é tempo, é dinheiro
[324:15] é paz
[324:17] é organização
[324:19] cara, bate nisso
[324:21] então essa é a parte onde você fica
[324:23] revisando essa dor
[324:25] pessoal, isso aqui é básico
[324:27] não é difícil de vocês entender
[324:29] mas se vocês entenderem isso
[324:31] e vocês aplicarem isso, é impossível dar errado
[324:33] e aí vem um ponto que eu estou falando
[324:35] desde o início desse evento
[324:37] venda o destino e não o voo final
[324:39] sabe que é interessante?
[324:41] durante toda essa parte
[324:43] onde você vai enfatizar na dor
[324:45] o que você vai falando? cara, sabe que é legal?
[324:47] isso dali
[324:49] e aí a gente usa triad de ofertas
[324:51] durante a apresentação da dor
[324:53] durante a enfatização da dor
[324:55] e aí o cara me fala
[324:57] eu falo assim, cara, então seu problema é esse mesmo
[324:59] eu volto pro leibo e aí eu pego
[325:01] e repito o problema que ele acabou de me falar
[325:03] a dor, a consequência da dor que ele acabou de me falar
[325:05] e aí com essa consequência
[325:07] da dor eu falo assim
[325:09] cara, sabia que existe uma solução pra isso?
[325:11] se você fizer isso, isso, isso dá certo
[325:13] você gostaria que a gente fizesse pra você? gostaria
[325:15] então beleza
[325:17] e aí eu pulgo pra outra dor
[325:19] então aqui eu vou enfatizar
[325:21] e eu vou dar pequenas soluções pra ele entender
[325:23] o que está rolando
[325:27] então aqui eu quero que esse cara entenda
[325:29] que eu entendo a dor dele
[325:31] e eu quero que ele entenda que existe soluções
[325:33] e eu quero que ele entenda que isso dali é mapeado
[325:35] só que eu não falo muito sobre as soluções
[325:37] eu só falo que existe, eu ainda não falei o como
[325:39] eu ainda não falei o que que vai ser feito
[325:41] porque
[325:43] o que vai ser feito
[325:45] você vai ter apresentação
[325:47] você vai ter ofertas, você vai ter tudo ele
[325:49] mas é muito importante
[325:51] que você entenda que
[325:53] se você quiser, eu criei um estado de incômodo
[325:55] com o meu cliente
[325:57] ele comprando ou não de mim
[325:59] ele vai deitar a cabeça no travesseiro
[326:01] e ele vai olhar assim, cara, eu tenho realmente esse problema
[326:03] eu realmente tenho esse problema
[326:07] eu realmente tenho essa dificuldade nisso
[326:09] eu realmente tenho dificuldade em x, y, z
[326:11] eu realmente tenho dificuldade em fazer tal coisa
[326:13] e esse cara ele vai ter esse problema
[326:15] esse cara ele vai pensar nisso
[326:17] e é muito mais fácil você pegar e fazer
[326:19] igual o título falou, pô, depois você nutre
[326:21] depois você faz 1, 2, 3, 4, 5, 10
[326:23] mil caos com esse cara
[326:25] ao longo prazo
[326:27] porque se você pega
[326:29] esse cliente e aí você expandiu
[326:31] o nível de consciência de dor dele
[326:33] e aí nesse nível de consciência agora
[326:35] você vai vendendo o destino final
[326:37] porque
[326:39] mesmo que ele não compre de você
[326:41] ele vai pensar, cara, eu estou com esse problema
[326:43] estou indo dormir com esse problema e eu sei a solução
[326:45] então um próximo passo
[326:47] é literalmente o S
[326:49] que é você vender
[326:51] o destino final e não voo
[326:53] então você vender o destino final
[326:55] e não voo
[326:57] significa, ou o
[326:59] o destino final e não voo significa o que
[327:01] aquilo que eu estou falando desde o início
[327:03] aquilo que eu estou falando desde o início da imersão
[327:05] desde o início das aulas que é o que
[327:07] qual que é o resultado final que seu cliente vai ter
[327:09] lembra aquela oferta que eu falei pra você
[327:12] tem que ser uma oferta simples, clara
[327:14] e objetiva
[327:16] ou divida a sua solução
[327:18] em três pilares
[327:20] e faça um pitch de não
[327:22] máximo três minutos
[327:24] deixa eu falar uma coisa pra vocês
[327:26] quanto tempo vocês passam pra explicar o pitch de vocês
[327:28] quanto tempo vocês passam pra explicar
[327:30] o que vocês fazem
[327:32] quanto tempo vocês passam ali
[327:34] pra explicar o seu entregavel
[327:36] cara, eu vou te
[327:40] dar um insight muito simples
[327:42] tem reuniões que eu faço
[327:44] e eu tenho ofertas criadas
[327:46] que eu não anoto
[327:48] não tenho slide, não tenho nada do tipo
[327:50] eu simplesmente abro um mapa mental
[327:52] escrevo três linhas e falo assim
[327:54] cara, é isso que você precisa resolver
[327:56] a gente vai resolver isso em tanto tempo
[327:58] e eu faço o pitch com oferta
[328:00] e é rápido
[328:02] o seu pitch tem que durar
[328:04] no máximo três minutos
[328:06] e o pitch quando eu digo
[328:08] cara, eu vou te entregar isso
[328:10] então o resultado final que a gente vai ter
[328:12] é isso aqui em tanto tempo
[328:14] e a gente vai pegar aquele resultado final
[328:16] aquela oferta que a gente criou
[328:18] e a gente vai levar três minutos
[328:20] e você vai falar o valor pro seu cliente
[328:22] e aí ele acabou
[328:24] claro, tem mais coisas ali nesse meio percurso
[328:26] mas eu tô te passando aqui
[328:28] a linha reta pra você conseguir essa reunião
[328:30] beleza?
[328:32] pra você conseguir fazer a venda dessa reunião
[328:34] mas vamos lá
[328:36] dentro desses três pilares
[328:38] esses três pilares é aonde você
[328:40] enxerga sua metodologia
[328:42] é aonde você coloca sua metodologia
[328:44] é aonde você coloca
[328:46] o que você pode fazer
[328:48] então cara, eu tenho uma metodologia assim
[328:50] a minha metodologia ela funciona em três partes
[328:52] ela funciona assim, assim e assim
[328:54] e aí eu te entrego o resultado
[328:56] causa disso, disso, disso
[328:58] isso conecta com o que você quer por causa disso, disso, disso
[329:00] e aí minha oferta pra você é fazer isso
[329:02] em tantos dias, de tal maneira
[329:04] pô, três minutos, acabou
[329:06] a oferta tem que ser assim
[329:08] o pitch tem que ser assim
[329:12] muito de vocês vêm pitch demorado o tempo todo
[329:14] e o pitch ele não pode ser demorado o tempo todo
[329:16] só que até agora
[329:18] eu te falei alguns pontos
[329:20] eu te falei a sequência que você precisa seguir
[329:22] dentro dessa sequência
[329:24] existem algumas coisas que vai tornar isso ainda mais forte
[329:26] dentro dessa sequência
[329:28] você precisa fechar três perguntas
[329:30] que vai fazer com que isso
[329:32] com que essa metodologia
[329:34] se torna ainda mais forte
[329:36] beleza? eu já vou pra parte de quebra de objeções
[329:38] o A e o R ali
[329:40] eu já vou pra essas partes
[329:42] mas dentro
[329:44] até o S aqui
[329:46] você tem três perguntas que você precisa matar
[329:48] antes mesmo
[329:50] antes mesmo de você chegar no pitch
[329:52] beleza?
[329:54] você pode fazer essas perguntas
[329:56] antes do pitch, você pode fazer essas perguntas dividido
[329:58] durante a sua apresentação
[330:00] eu normalmente faço isso de maneira disfarçada
[330:02] durante a minha apresentação
[330:04] mas tem casos que eu pego
[330:06] e eu faço essa pergunta direto pro cliente
[330:09] quais são as perguntas
[330:11] que eu faço pro meu cliente
[330:13] cara, eu te mostrei os três pilares e eu te mostrei o serviço que eu faço
[330:15] esse serviço
[330:17] ele
[330:19] atende as suas necessidades
[330:21] isso que eu falei
[330:23] atende as suas necessidades
[330:25] isso que eu falei, esse produto, esse serviço
[330:27] você entende que isso funciona
[330:29] é uma pergunta que eu faço pro meu cliente
[330:31] ele falou que sim
[330:33] se ele fala que não, eu pergunto pra ele
[330:35] por que tu acredita que isso não funciona
[330:37] e aí eu entro numa quebra de objeções
[330:39] eu entro numa explicação, eu entro em algo
[330:41] que eu vou apalhar minha venda lá na frente
[330:43] são três perguntas que você precisa fazer
[330:45] pra que no final da sua negociação
[330:47] só sobre a questão do valor
[330:49] fechou? então essa é a primeira pergunta
[330:51] você entende que isso
[330:53] é pra você, você entende que
[330:55] esse serviço
[330:57] ele atende suas necessidades
[330:59] que essa metodologia, ela funciona
[331:01] você entende que essa metodologia, ela funciona?
[331:03] entendo, beleza
[331:05] e aí a próxima pergunta
[331:07] deixa eu te fazer uma pergunta
[331:09] você acredita que isso
[331:11] se encaixa pra sua empresa
[331:13] pra sua realidade atual
[331:15] aqui é a pergunta mais importante
[331:17] quantas vezes vocês fizeram
[331:19] uma proposta pro seu cliente
[331:21] e aí as vezes durante a
[331:23] negociação, durante a objeção
[331:25] ele falou, pô, mas eu não sei se isso vai funcionar pra mim
[331:27] ah, o tempo aqui é corrido
[331:29] aqui é diferente, blá, blá, blá
[331:31] aqui essa pergunta é uma das mais importantes
[331:35] você acredita que isso vai funcionar pra tua operação?
[331:37] deixa ele responder
[331:39] se ele falar que não
[331:41] aí você entra numa cabra de objeções
[331:43] aí você entra numa outra narrativa
[331:45] você entra ali, realmente no que eu falei
[331:47] e eu vou trazer os 3 As de novo
[331:49] eu vou reforçar os 3 As de novo
[331:51] mas se ele falar que não
[331:53] você entra na cabra de objeções, se ele falar que sim
[331:55] olha que interessante
[331:57] aqui ele falou que o produto serviço
[331:59] ou que a metodologia funciona
[332:01] aqui ele falou que isso é pra ele
[332:03] se ele falou que a metodologia funciona
[332:05] ele falou que isso é pra ele
[332:07] a único ponto que sobra é
[332:09] agora é uma pergunta que eu tenho sincero pra você
[332:11] você acredita que eu consigo te entregar isso
[332:13] você acredita que eu sou a pessoa
[332:15] que consegue te entregar isso
[332:17] você acredita que você confia aqui comigo
[332:19] esse processo vai ser mais rápido, vai ser mais eficiente
[332:21] vai ser mais funcional
[332:23] se o cliente fala que sim
[332:27] bacana
[332:29] se o cliente fala que não
[332:31] aí eu preciso entender
[332:33] o que eu posso fazer pra ele confiar em mim
[332:35] cara literalmente
[332:37] essas 3 perguntas
[332:39] elas vão fazer o que?
[332:41] o cara falou pra você
[332:43] durante uma reunião de vendas
[332:45] que isso daí é pra ele
[332:47] que o produto funciona
[332:49] e que ele confia em você
[332:51] pra executar esse produto
[332:54] qual que é a única coisa que faltou?
[332:56] faltou a questão de valores
[332:58] faltou a questão realmente de negociar o preço
[333:00] que aí vem no pitch
[333:02] agora pega essas 3 perguntas
[333:04] e vai fazendo ela durante esse processo aqui
[333:06] de verdade mesmo
[333:08] todas as vendas
[333:10] isso aqui quando eu enxergo
[333:12] um processo de vendas
[333:14] e eu vou explicar na R1 e R2
[333:16] onde vocês vão usar cada ponto
[333:18] tanto que essa aula de R1 e R2 eu vou
[333:20] realmente trazendo pra vocês
[333:22] como que vocês vão trazer cada ponto
[333:24] mas o que eu preciso que vocês entendam?
[333:26] cara eu clarei e fiquei o problema
[333:28] clarei e fiquei o problema
[333:30] depois eu
[333:32] mostrei algumas possíveis soluções pra dor
[333:34] mostrei os pilares da minha metodologia
[333:36] perguntei pra ele se ele acredita que isso funciona
[333:38] ele falou que acredita que funciona
[333:40] perguntei pra ele se ele acredita
[333:42] que aquilo
[333:44] o que a empresa dele precisa
[333:46] e que isso vai funcionar na empresa dele
[333:48] ele falou que precisa e que vai funcionar pra empresa dele
[333:50] aí aqui durante o S
[333:52] eu pergunto pra ele
[333:54] se ele confia em mim pra executar
[333:56] essa oferta que eu tô fazendo pra ele
[333:58] aí ele fala que sim
[334:00] que acabou
[334:02] é só você negociar valor isso
[334:06] não tem muita dificuldade
[334:08] e aqui se você quiser deixar mais forte ainda
[334:10] durante a enfatização aqui da dor
[334:12] durante o overview
[334:14] você pode colocar mais uma pergunta
[334:16] hoje é sua prioridade resolver esse problema
[334:18] mas sabe porque
[334:20] não necessariamente você precisa
[334:22] fazer essas perguntas o tempo todo
[334:24] mas você pode fazer
[334:26] porque você não precisa
[334:28] perguntar se é uma prioridade pra ele resolver
[334:30] sendo que se você conseguir
[334:32] extrair o máximo de dor possível
[334:34] pra ele vai ser uma prioridade
[334:36] pô algum de vocês consegue
[334:38] ser lá dormir com uma dor de cabeça gigantesca
[334:40] sem tomar um remédio
[334:42] ou uma dor no corpo
[334:44] ou qualquer doença que seja
[334:46] você fala assim caraca eu tô muito doente
[334:48] não vira sua prioridade resolver aquilo
[334:50] é o que eu tô mostrando pro meu cliente
[334:52] então essa prioridade pra ele
[334:54] a gente faz isso na revisão da dor
[334:56] e eu faço a revisão da dor
[334:58] e eu fecho com as três perguntas o que que acontece
[335:00] o meu cliente não sobe espaço
[335:02] o que que vai sobrar pra ele
[335:04] se ele tem dinheiro ou não pra pagar
[335:07] beleza
[335:09] até aqui tudo ok
[335:14] até aqui tá fazendo sentido
[335:16] então conseguindo ouvir é que aqui é a mesma coisa
[335:18] da esplanar preocupações ali
[335:20] é a mesma coisa que o framework aqui
[335:22] mas enfim, bora lá
[335:24] sim, sim, beleza
[335:26] ok, ok
[335:28] gente
[335:30] mas quando você começar a executar isso
[335:32] ali você vai vender muito
[335:34] e aí a gente vem pra próxima parte
[335:36] que é realmente contornar as objeções
[335:38] e aí contornar
[335:40] as objeções entra naquilo lá
[335:42] que a gente falou que a gente
[335:44] passou na aula mais cedo
[335:46] tá, que é a gente fazer
[335:48] aquele processo eu reconheço o problema dele
[335:50] eu associo o problema dele
[335:52] e aí eu pergunto sobre o problema dele
[335:54] gente
[335:56] quem não pegou essa parte de contornar objeções
[335:58] que inclusive ela precisaria estar aqui
[336:00] nesse mapa mental
[336:02] boa
[336:04] ele precisaria estar aqui nesse mapa mental
[336:06] volta ali na aula depois
[336:08] e assiste essa parte de quebra de objeções
[336:10] porque ela vai servir tanto pra ligações
[336:12] quanto pra você realmente
[336:14] fazer essa venda
[336:16] pra você realmente converter esse lead
[336:18] dentro de uma reunião de vendas
[336:20] beleza, então
[336:22] quando a gente coloca isso
[336:24] e aí a gente vem pra essa parte
[336:26] e a gente literalmente conseguiu fazer a venda
[336:28] objeção de valores, a única coisa
[336:30] que sobrou ali dentro daqueles passos que eu falei
[336:32] se você fechou as três perguntas
[336:34] sem enfatizador, que gerou urgência nele
[336:36] a única coisa que resultou é
[336:38] ele tomar uma decisão
[336:40] no quesito de valores
[336:42] ele enxergar qual que é o valor
[336:44] do seu projeto, certo?
[336:46] é enxergar esse custo
[336:48] Gustavo, e se esse cara tem uma sócia
[336:50] se esse cara tem uma outra coisa e tudo mais
[336:52] isso daí a gente separa na R1, R2
[336:54] tem certas objeções que a gente faz
[336:56] na R1, R2, mas
[336:58] a gente consegue trazer isso aqui de forma clara
[337:00] fechou? Beleza
[337:02] quando eu trago
[337:04] essa dor, quando eu exponho essa dor
[337:06] e quando eu entendo tudo isso, quando eu faço
[337:08] esse processo de closer
[337:10] e aí eu falto o que? Falto eu negociar o valor
[337:12] e negociar o valor
[337:14] deixa eu falar uma coisa pra vocês, vocês não vão dar desconto
[337:16] anota aí, eu não irei
[337:18] dar desconto
[337:20] o que você vai perguntar pro seu cliente
[337:22] quando ele for negociar o valor com você
[337:24] você vai falar assim, você vai usar a seguinte frase
[337:26] foi tudo bem
[337:28] eu realmente
[337:30] tá, eu não dou descontos
[337:32] mas
[337:34] eu preciso entender como que eu poderia facilitar
[337:36] pra que você
[337:38] fechasse com a gente agora
[337:41] e como que ficaria melhor pra ti
[337:43] pra gente fazer esse processo e pra gente
[337:45] realmente avançar
[337:47] com isso juntos
[337:49] de uma forma onde fique bom pra você
[337:51] e que fique bom pra mim também
[337:53] como que eu posso te ajudar a resolver esse problema
[337:55] ou como que eu posso facilitar
[337:57] pra que você consiga fechar comigo agora
[337:59] alguém já ouviu essa pergunta de mim?
[338:01] alguém eu já fui vender alguma vez
[338:03] e eu perguntei isso
[338:05] cara, como que eu posso facilitar pra você
[338:07] pra você realmente fechar comigo agora
[338:09] eu te falo minhas métricas
[338:11] minhas métricas, acho que é
[338:13] 40% eu
[338:15] eu visualizei ela dentro do serrinho
[338:17] 40% conversão
[338:19] ali nos primeiros momentos
[338:21] e acho que mais uns
[338:23] 35% 40%
[338:25] a longo prazo dentro dos próximos 4 meses
[338:27] então o resto ali eu perco mesmo
[338:29] tá, então eu tenho mais ou menos entre 70%
[338:31] e 80% taxa de conversão
[338:33] 40% eu vendo na hora porque?
[338:35] porque eu consigo achar a solução pra esse problema
[338:37] do cliente, gente deixa eu falar uma coisa
[338:39] se você quebrou todos os objeções
[338:41] desse cliente de tempo, de tudo
[338:43] de tudo que ele poderia ter
[338:45] ali de objeção, se você fez
[338:47] uma reunião perfeita, isso aqui eu considero
[338:49] a
[338:51] execução de uma venda
[338:53] perfeita, então você pode fazer isso dentro
[338:55] de uma clínica, você pode fazer, cara
[338:57] qualquer processo comercial, que se usar essa metodologia
[338:59] você vai vender, a grande pergunta
[339:01] que eu tenho pra vocês é
[339:03] por que que vocês tentam resolver
[339:05] todos os problemas de seus clientes?
[339:07] você não precisa resolver todos os problemas de seus clientes
[339:09] às vezes o seu próprio cliente
[339:11] ele não vai ter dinheiro
[339:13] pra te pagar
[339:15] se o seu cliente não tem dinheiro pra te pagar
[339:17] o que a gente
[339:19] pode fazer?
[339:21] a gente pergunta, como eu posso facilitar isso pra você
[339:23] se ele não entende, se ele não consegue chegar
[339:25] numa solução sozinho, vou fazer o que?
[339:29] tristeza
[339:31] vida que segue, eu vou nutrindo esse cara
[339:33] até o momento que ele tem dinheiro um dia
[339:35] mas se ele não tem dinheiro
[339:37] cara, não tem muito que eu fazer
[339:39] e antigamente, por que eu falei que eu fazia errado
[339:41] antigamente na outra empresa
[339:43] mas nas vezes o cliente estava muito fudido
[339:45] eu falava assim, cara, me manda esse 50 contas
[339:47] que você tem na conta e o resto você paga até o dia
[339:49] e cara, eu tomava muito calode, tomava muita coisa
[339:51] por que? porque a gente conseguia forçar o cara
[339:53] realmente a comprar
[339:55] só que eu preciso que vocês entendam
[339:57] se o seu cliente não tem dinheiro
[339:59] cara, não tem jeito
[340:01] o máximo que você pode facilitar, cara
[340:03] ele não tem dinheiro nesse momento
[340:05] mas ele vai ter dinheiro em outro momento
[340:07] deixa eu fazer o seu pagamento assim, divido ele assim e assim
[340:10] descobrir que o dinheiro não tem dinheiro
[340:12] só dentro da call é um erro de qualificação
[340:14] na verdade, não é nem de qualificação
[340:16] da call, é um erro de lista
[340:18] de prospecção
[340:20] porque se você tá convidando, vamos lá
[340:22] se você convida clínicas, que tem mais cinco funcionários
[340:24] é muito difícil você encontrar um cliente
[340:26] que não tem dinheiro pra sua solução
[340:28] a não ser que sua solução seja muito cara
[340:30] e mesmo ela sendo muito cara, você consegue facilitar
[340:32] de alguma maneira pra esse cara pagar
[340:34] então, o erro que eu coloco
[340:36] do cliente não ter dinheiro, eu não coloco
[340:38] nem da qualificação ali dentro do whatsapp
[340:40] eu coloco na própria prospecção
[340:42] ah, Gustavo, estou fazendo um anúncio
[340:44] estou fazendo outro meio de captação
[340:46] aí sim, é da qualificação
[340:48] mas assim, eu identificar
[340:50] e eu ter estere de produtos também
[340:52] faz com que eu consiga vender pra maior parte
[340:54] dos meus clientes, entendeu?
[340:56] então, muitas das vezes eu vou fazer o pit
[340:58] mesmo sabendo que esse cara não tem dinheiro
[341:00] mas eu vou nutrir ele porque eu sei que
[341:02] em algum momento ele vai ter
[341:04] e se ele estiver em algum momento eu vou conseguir
[341:06] vender pra ele, beleza?
[341:08] então, o problema do dinheiro
[341:10] gente, não tem que você resolver
[341:12] ah, muitas das pessoas falam
[341:14] ah, pega um preste, não sei que
[341:16] liga pra alguém que tem cartão
[341:18] cara, eu não quero fazer isso
[341:20] você é desonesto, você é chato
[341:24] isso daí ferra a vida da pessoa
[341:26] que a pessoa não vai conseguir ser um bom cliente pra você
[341:28] ela vai ficar desesperado na esperança
[341:30] do produto que ela comprou de ti
[341:32] então, é possível vender pra qualquer pessoa?
[341:34] é possível, você quer vender pra qualquer pessoa?
[341:36] a maioria das vezes não
[341:38] a maioria das vezes não
[341:40] então, opa, parei de compartilhar sem querer
[341:42] então, a única coisa que a gente
[341:44] precisa entender nesse ponto
[341:46] cara, você conseguiu fazer a venda
[341:48] se você fechou todos esses pontos
[341:50] você conseguiu fechar a venda
[341:52] a única coisa que falta
[341:54] é o cliente ter dinheiro
[341:56] ele não tem dinheiro
[341:58] e honestamente você percebeu
[342:00] que ele não tem dinheiro?
[342:02] não tem o que fazer, irmão
[342:04] aí você pode, a única pergunta que você pode fazer
[342:06] é cara, como eu posso facilitar pra você
[342:08] se não houver maneiras
[342:10] vocês não conseguirem chegar a um consenso
[342:12] e algo pra que você possa facilitar
[342:14] não tem como, beleza?
[342:16] vai pro próximo
[342:18] errou, era um lead, duro, era um lead que não tinha dinheiro
[342:20] era um lead que não tava no momento
[342:22] às vezes até tinha dinheiro
[342:24] mas, porra, ele tava tão afogado
[342:26] com várias outras coisas que ele não conseguia investir na hora
[342:28] então não é, não são bons clientes pra vocês
[342:30] beleza?
[342:32] então, só que eu digo
[342:34] 90% dos seus leads
[342:36] o problema dele não é dinheiro
[342:38] tá, o problema dele é te pagar
[342:41] é quase impossível um empresário
[342:43] ele não ter 2 mil reais, é muito difícil
[342:45] um empresário não ter 2 mil reais
[342:47] pode ser que não tenha na hora, mas muito difícil
[342:49] ele não se comprometer a pagar 2 mil reais
[342:51] ele não se compromete com você
[342:53] o cara que fatura a partir de 20 mil reais
[342:55] ele consegue pagar 2, 5,
[342:57] até 10 mil reais
[342:59] ele só não paga a você
[343:01] porque o teu processo de vendas ainda tá fraco
[343:03] a tua reunião de vendas ainda tá fraco
[343:05] o seu sistema
[343:07] de vendas
[343:09] o seu sistema de realmente
[343:11] quebra de objeções, de crenças
[343:13] de formular esse problema e vender o voo
[343:15] eu vender o destino pra ele
[343:17] não vender o voo, ainda tá ruim
[343:19] talvez eu só a oferta não esteja alinhada
[343:21] então o que que você precisa entender
[343:23] tá?
[343:25] quando você fizer isso
[343:27] de maneira assertiva
[343:29] e você conseguir passar pro seu cliente
[343:31] e você chegar na etapa
[343:33] onde ele só não comprou com você
[343:35] por causa de valor
[343:37] ou ele comprou de você
[343:39] ali você teve sucesso na sua reunião
[343:41] uma reunião de sucesso
[343:43] não é uma reunião aonde o cliente compra
[343:45] todas as vezes
[343:47] uma reunião de sucesso é uma reunião
[343:49] ou uma condução de vendas
[343:51] porque eu faço muita venda por ligação
[343:53] a gente está vendo a mesma por ligação
[343:55] então uma ligação às vezes de sucesso
[343:57] é o que?
[343:59] é o cara que não só
[344:01] tá? e às vezes ele não tinha dinheiro
[344:03] mas eu quebrei todas as objeções
[344:05] e eu realmente fiz com que ele
[344:07] quisesse esse produto
[344:09] mais do que tudo
[344:11] com que o único fator que ele realmente
[344:13] não comprou de mim foi o valor
[344:15] e se você fez isso
[344:17] considera ser um vitorioso
[344:19] não comemora a venda obviamente
[344:21] mas você fez uma boa reunião
[344:23] então tem momentos que eu compro
[344:25] e eu falo assim, esse cliente não comprou por causa minha
[344:27] e tem momentos que eu falo
[344:29] que ele não comprou porque não era o momento dele
[344:31] e raramente vai ser por causa minha
[344:33] porque eu vou bater todas essas teclas
[344:35] todas essas teclas
[344:37] fechou?
[344:39] então eu fiz uma reunião com o Lid
[344:41] que tinha pouco dinheiro e achava que era o serviço
[344:43] queria pagar pouco e fiquei feliz de não ter fechado
[344:45] fechar com o cliente ruim, ferro e LTV
[344:47] e a operação no geral
[344:49] exatamente, você tem que escolher
[344:51] mas é o que eu falo pra tita
[344:53] se você seguir esse passo
[344:55] esse passo a passo
[344:57] você vai ficando, sabe como que você ancora
[344:59] seu valor? Você vai falando de outros projetos
[345:01] de outros clientes que você atende e aí você sempre vai
[345:03] jogando o valor lá em cima, você não faz aquela ancoragem
[345:05] eu cobro tanto e eu faço por tanto
[345:07] não, e você não vai ser comparado
[345:09] se você fizer isso aqui
[345:11] se você fizer isso aqui com excelência
[345:13] porque ele vai parar de te ver
[345:15] como um vendedor e ele vai começar a te ver
[345:17] como um parceiro, essa metodologia
[345:19] de closer, essa metodologia pra você fechar
[345:21] vai fazer com que você feche as vendas
[345:23] e às vezes você vai fechar no follow up
[345:25] às vezes não vai ser o momento do cara
[345:27] mas aí depois de um mês você vai ligar
[345:29] você vai fazer esse mesmo processo, você vai conseguir vender pra ele no telefone
[345:31] e é muito fácil vender pra ele no telefone
[345:37] e é muito fácil você fazer uma nutrição
[345:39] e é muito fácil você vender pra ele depois de um tempo
[345:41] você precisa trabalhar
[345:43] você precisa realmente fazer com que isso aconteça
[345:45] fechou?
[345:47] vocês entenderam o processo
[345:49] vocês entenderam passo a passo
[345:51] que vocês precisam seguir pra que uma venda
[345:53] seja bem realizada
[345:56] alguém tem alguma dúvida
[346:01] gente, de verdade, segue esse passo a passo
[346:03] não muda esse passo a passo
[346:05] segue esse passo a passo
[346:07] beleza? já vou entrar nas reuniões de vendas
[346:09] mas eu quero tirar dúvidas da galera
[346:11] pode abrir o microfone
[346:13] meu lindo, se você quiser fazer a pergunta
[346:15] no microfone, se tu não quiser
[346:17] pode fazer a pergunta no chat mesmo
[346:19] vou tirar dúvidas da galera
[346:21] quem tiver dúvidas sobre isso
[346:23] bora lá
[346:25] boa tarde pessoal, estou me ouvindo bem
[346:27] e aí?
[346:29] olha o 01
[346:31] alguém não me conhece
[346:33] eu acredito que muita gente me conhece aqui
[346:35] mas outros não, prazer aí pessoal, tudo bem
[346:37] ótimo sábado e pra todo mundo
[346:39] eu vou abrir pra pergunta agora
[346:41] fazer a pergunta pro Nemoto
[346:43] como é que tá, Nemoto?
[346:45] bom demais, cara
[346:47] também, graças a Deus
[346:49] sábado aqui em Solara, logo aqui, tudo bem
[346:51] eu estou no melhor lugar também
[346:53] que é fazendo o que eu gosto
[346:55] esse cabelo aí, Nemoto
[346:57] esse cabelo aí daqueles caras
[346:59] sabe aqueles caras gênios
[347:01] o que é isso, é o estereótipo
[347:03] que eu fiz de propósito
[347:05] bora lá
[347:07] o que você manda, meu irmão?
[347:09] a pergunta é o seguinte, eu acredito que
[347:11] teve gente que pergunta algo parecido aqui
[347:13] com relação à própria
[347:15] qualificação dos leads que entram na reunião
[347:17] acontece muito o erro
[347:19] da pessoa
[347:21] fazer uma ligação, marcar a reunião
[347:23] e não necessariamente, ou estudar
[347:25] empresa, né, não estudar empresa
[347:27] mas também não necessariamente pergunta pro lead
[347:29] por exemplo, uma coisa que pode
[347:31] ter dá uma certa noção de faturamento
[347:33] aquela pergunta de quantos colaboradores
[347:35] o lead tem, sabe
[347:37] então a pergunta é respeito assim
[347:39] como qualificar o lead
[347:41] pré-reunião pra não entrar numa reunião
[347:43] tipo, que até o
[347:45] próprio Rangel fala com o famoso
[347:47] lead cachorro, sabe, o cara que quer
[347:49] até pagar tipo 300, 500 reais
[347:51] e tu vai fazer teu pedido de 2, 3k
[347:53] ou mais, só que
[347:55] não quer perder tempo naquela reunião também
[347:57] porque, tipo
[347:59] tempo é dinheiro e tu não quer perder com o lead ruim
[348:01] como qualificar o lead antes, o que que tu faz
[348:03] vamos lá, eu vou trazer alguns pontos, tá
[348:05] hoje eu entro em reunião
[348:07] às vezes que o lead ele não tem um real, tá
[348:09] e o Gustavo entra em reunião que o lead não tem um real
[348:11] eu não tenho problema nisso porque
[348:13] é, eu tenho algumas
[348:15] estérias de produtos que são um pouco diferentes
[348:17] então, tipo assim, no final das contas
[348:19] eu vou estar no trem de alguém pro futuro
[348:21] ou vou vender um produto baratinho e tudo mais
[348:23] então, eu sei que vai durar 15 minutos da call
[348:25] pra eu me vender um produto baratinho pra esse lead
[348:27] é uma estreia de produtos é boa
[348:29] mas, pô, você que tá iniciando
[348:31] eu sei que não tem muito cliente, você que
[348:33] você precisa focar em uma coisa só
[348:35] o que que eu recomendo pra vocês, tá
[348:37] dentro da qualificação, a qualificação
[348:39] ela começa já na prospecção
[348:41] e é exatamente o que tu falou
[348:43] cara, se eu não consigo conversar com meu decisor
[348:45] muita das vezes, tá
[348:47] o qual que é o maior problema das pessoas
[348:49] elas, ah, Gustavo, eu marco reunião por dispara
[348:51] beleza, parabéns
[348:53] você marca reunião por dispara
[348:55] se o seu lead, ele não falou
[348:57] quanto funcionário ele tem, pô, como que é a agenda dele
[348:59] se ele aguenta atender mais pacientes
[349:01] se ele aguenta atender mais cliente
[349:03] se ele aguenta fazer ali o que ele precisa fazer
[349:05] então, tipo assim, você vai perguntar pra esse lead
[349:07] perguntas estratégicas que fazem
[349:09] com que ele se abra
[349:11] e que você consiga trazer algumas soluções
[349:13] por exemplo, pô, muitas pessoas que eu converso
[349:15] eu vou usar o exemplo de clínica
[349:17] mas aí vocês adaptem pra realidade
[349:19] de vocês pelo que vocês estiverem
[349:21] prospectando
[349:23] muitas clínicas que eu converso
[349:25] às vezes elas têm a agenda lotada
[349:27] pô, você tem a agenda o dia inteiro
[349:29] mas parece que, tipo assim, o faturamento
[349:31] ele não é correspondente, você nunca consegue ultrapassar
[349:33] o 100 mil reais de faturamento
[349:35] mesmo com a agenda lotada, esse é o caso de vocês aí
[349:37] pô, Gustavo, não é nosso caso
[349:39] o nosso caso eu queria ter a agenda lotada
[349:41] Gustavo, pô, é o nosso caso
[349:43] a gente tem a agenda lotada, mas a gente não consegue
[349:45] passar 100 mil de faturamento
[349:47] pela experiência do nicho, pelo conhecimento que eu tenho
[349:49] pelo estudo do nicho que eu tenho
[349:51] eu não preciso perguntar o faturamento dessa pessoa
[349:53] porque eu sei, vai estar entre 40 a 70 mil
[349:55] e aí eu sei o produto
[349:57] que eu vou vender pra essa pessoa
[349:59] então, a qualificação por si só
[350:01] ela vem por meio da dificuldade que seu cliente tem
[350:03] então, coloca aqui
[350:05] o seu cliente
[350:07] que não tem muito dinheiro
[350:09] ele tem vários problemas com o funcionário
[350:11] ele tem problemas de tipo assim
[350:13] cara, administrar a equipe de vendedores dele
[350:15] ou ele tem um problema
[350:17] e ainda de aquisição de leads
[350:19] ele ainda tem um problema de conseguir
[350:21] as primeiras
[350:23] as primeiras receitas
[350:25] ele ainda tem um problema de tempo
[350:27] então, tem certas dores que o seu próprio lead
[350:29] vai falar que vai mostrar o momento que ele está
[350:31] porque que eu encho o saco
[350:33] ó, o Arthur tá aí e ele não me deixa mentir
[350:35] cara, às vezes
[350:37] o time, ele coloca
[350:39] na agenda as informações do cliente
[350:41] e ele não coloca todas as informações
[350:43] ele não coloca a dor principal
[350:45] ele não coloca várias informações que eu peço pra o time
[350:47] colocar quando ele esmarca uma reunião
[350:49] eu exploro a reunião da agenda
[350:51] ou eu brigo com o time e eu falo assim
[350:53] cara, não dá pra eu não fazer uma reunião assim
[350:55] porque, dentro do contexto
[350:57] que esse cara falou, alguma coisa ele soltou
[350:59] eu reviso a conversa no whatsapp
[351:01] inteiro, eu reviso a conversa
[351:03] tanto, tipo, inteiramente
[351:05] no whatsapp
[351:07] do lead que a gente marcou a reunião
[351:09] ou da ligação, ou o que foi falado
[351:11] e eu tento extrair ao máximo
[351:13] e aí, quando eu extraio isso, a minha venda se torna muito mais fácil
[351:15] porque eu sei o nível do cliente que eu estou entrando
[351:17] na reunião, então eu não vou oferecer um produto
[351:19] de 30 mil reais, porque o cara fatura 10
[351:21] porque eu sei o que
[351:23] quais são as condições desse cara pelas respostas
[351:25] que ele me deu
[351:27] então, um dos grandes pontos, eu não sei se estava no início
[351:29] do evento, mas um dos grandes pontos que eu falei pra você
[351:31] assistir vários podcast de especialistas
[351:33] e mostrar alguns exemplos pra você entender
[351:35] do nicho, é o que, é você entender
[351:37] quais são as dúvidas
[351:39] de cada tamanho do empresário que você atende
[351:41] ou você pode fazer a qualificação
[351:43] cara, quantos funcionários você tem
[351:45] ou você pode até pelo Google o meu negócio
[351:47] pelo Google o meu negócio
[351:49] você olha uma empresa e aí você olha
[351:51] e pelo olhar que você tem
[351:53] há muitas das vezes você já vai conseguir
[351:55] bater e saber se ela tem 2 mil por mês
[351:57] se ela tem 3 mil
[351:59] agora, se mesmo assim você
[352:01] não sabe
[352:03] pra comprar um produto maior
[352:05] porque o cliente sempre vai falar pra você
[352:07] que a situação tá difícil, que ele tá pagando
[352:09] outras coisas, tá? daí esquece
[352:11] ele sempre vai falar pra você isso
[352:13] então, mas se você
[352:15] não sabe, aí você faz pergunta de qualificação
[352:17] essas perguntas são muito individuais
[352:19] mas é na própria prospecção
[352:21] então...
[352:23] eu tenho comentário pra fazer respeito
[352:25] eu tenho comentário pra fazer respeito disso
[352:27] acredito que o maior erro dentro
[352:29] disso começa
[352:31] dentro da gente, no sentido de
[352:33] o cara
[352:35] ele não se posiciona profissionalmente
[352:37] então, ele não leva necessariamente
[352:39] o trabalho dele a sério
[352:41] pensa que a oferta dele não é tão boa
[352:43] como ele não se posiciona profissionalmente
[352:45] como autoridade? no momento
[352:47] de ele falar com o decisor, ele já se sente
[352:49] menor que o decisor e ele fica com medo
[352:51] de tomar vácuo pro decisor
[352:53] tanto por ligação quanto por mensagem
[352:55] ele já marcou a reunião e ele não quer ficar
[352:57] enchendo muito o saco do decisor
[352:59] para não tomar vácuo e não tomar no show
[353:01] esse medo, essa falta
[353:03] de posicionamento profissional, faz com que o cara
[353:05] tenha uma pouca relação
[353:07] com o decisor e não saiba
[353:09] as informações devido da empresa dele
[353:11] então, eu acredito que é se posicionar
[353:13] como autoridade, ter profissionalismo
[353:15] e realmente conversar com o decisor
[353:17] da igual pra igual, com sinceridade
[353:19] para poder entender a real situação dele
[353:21] agora, se o cara ficar com medo e ficar
[353:23] com aquele sentimento de insegurança
[353:25] e a se achar menor que o decisor
[353:27] bom, aí ele não vai conseguir qualificar nunca
[353:29] e vai chegar na reunião insegura inclusive
[353:31] e muito provavelmente não vai fechar
[353:33] mas é normal isso, tá? é muito normal isso
[353:35] porque quando a gente tá ligando
[353:37] a maioria das pessoas já ligam
[353:39] de uma posição de submissão
[353:41] vamos lá, hoje eu falei um pouco
[353:43] sobre o VIH de confirmação, cara, aquilo vai servir
[353:45] muito pra ti, mas eu vou exemplificar
[353:47] isso aqui, eu vou exemplificar isso já
[353:49] mostrando o Google meu negócio
[353:51] realmente de algumas empresas
[353:53] quando a gente fala sobre isso
[353:55] vamos lá, a pessoa, ela se posicionar
[353:57] como uma autoridade
[353:59] e o decisor, ela já se posicionar
[354:01] tipo, ah, eu cobro barato, eu cobro no seu que
[354:03] eu cobro no seu que lá, ela já se posicionar
[354:05] nisso e o decisor
[354:07] ele entender isso às vezes não diretamente
[354:09] que ela falou, mas ele entende isso pelo jeito
[354:11] que ela comunica, pelo jeito que ela pede a reunião
[354:13] dá foto no WhatsApp
[354:15] é exatamente, então tudo isso
[354:17] vai fazer com que essa pessoa se sinta inferior
[354:19] qual que é o grande insight que eu trago pra vocês, tá?
[354:23] Mano, eu nunca vou chamar
[354:25] uma clínica
[354:27] isso daqui é uma chave que vocês precisam
[354:29] virar na cabeça de vocês pra que a comunicação
[354:31] de vocês melhore
[354:33] Mano, eu acho que eu fiz, eu não sei se foi
[354:35] com você Arthur, eu não sei se você viu esse dia
[354:37] que eu falei assim, cara, duvido eu chamar
[354:39] três empresas no WhatsApp aleatória
[354:41] e eu marcar uma reunião presencial
[354:43] eu chamei e eu marquei
[354:45] sabe por que eu marquei?
[354:47] porque quando eu comecei a chamar as empresas
[354:49] eu não chamava oito de bem, nossa
[354:51] eu gostaria de apresentar
[354:53] fazer um diagnóstico, não sei o que
[354:55] eu queria ver o congestor, o melhor dia pra
[354:57] me visitar, eu tinha falado com ele um tempo atrás
[354:59] e eu não consegui mais contato
[355:01] e eu queria visitar vocês pra gente falar
[355:03] do CRC de vocês, acabou
[355:07] e aí eu sempre vou tratar
[355:09] o meu lead, o meu tom de voz
[355:11] o que eu vou falar é, cara, tu precisa de mim
[355:13] não, eu preciso de você
[355:15] e realmente isso só vai mudar
[355:17] quando você acredita nisso
[355:19] porque se esse cara não marca reunião comigo
[355:21] eu vou marcar reunião com o próximo cara
[355:23] e esse próximo cara que eu vou marcar
[355:25] reunião, ele vai precisar de mim
[355:27] e igual esse cara precisa, só que ele
[355:29] tá sendo arrogante e o suficiente pra não querer falar comigo
[355:31] se eu tô convidando pra evento, cara, isso
[355:33] melhora ainda mais
[355:35] porque se eu tô convidando pra um ebinário, por exemplo
[355:37] cara, eu tô convidando o meu lead pra um ebinário
[355:39] e aí eu convidei esse lead pro ebinário
[355:41] e nisso que eu convidei esse lead pro ebinário
[355:43] o que que acontece?
[355:45] esse lead que eu convidei pro ebinário
[355:47] eu tô fazendo um convite pra ele
[355:49] ele que tá ganhando o convite, ele que tá ganhando isso
[355:51] cara, está louco
[355:53] de realmente
[355:55] ele debochar
[355:57] ou ele tirar com a minha cara
[355:59] ou ele fazer descaso com o convite que eu tô fazendo pra ele
[356:01] com algo que ele vai ganhar
[356:03] então isso vem muito da percepção de quem tá
[356:05] prospectando
[356:07] na aula de prospecção que eu passei hoje
[356:09] sobre prospecção pra webinário
[356:11] eu falei isso, cara, quem precisa do convite
[356:13] é o teu cliente, não você
[356:15] porque você tem várias opções
[356:17] seu cliente só tem você
[356:19] ele só vai dar o seu evento
[356:21] falando sobre aquela coisa
[356:23] sabe?
[356:25] eu acho que o problema na real
[356:27] com relação a nós, com relação ao mercado
[356:29] não é necessariamente a demanda
[356:31] eu acredito que a demanda a gente consegue gerar
[356:33] eu acredito que a maior questão é
[356:35] ter uma oferta boa, escalável
[356:37] como tu já ensinou bastante
[356:39] a respeito da Lindsay, os maiores desafios
[356:41] é ter uma oferta boa, clara
[356:43] e escalável pra realmente ter uma operação
[356:45] saudável, sabe?
[356:47] mas questão de demanda eu acredito que
[356:49] qualquer pessoa que tenha uma capacidade
[356:51] de fazer muitas ligações no dia
[356:53] pedir indicação, seja ativa
[356:55] ela consegue ter uma demanda muito suficiente
[356:57] principalmente se for uma pessoa única
[356:59] ela vai ter bastante trabalho pra fazer
[357:01] não é demanda, é questão desse serviço de qualidade
[357:03] e outro ponto
[357:05] tira a bunda da cadeira mano
[357:07] vai visitar as empresas, é muito mais fácil fechar
[357:09] uma reunião presidencial
[357:11] é muito mais fácil passar a autoridade
[357:13] e outro ponto, parem de se subestimapar
[357:15] sabe qual que é
[357:17] o grande ponto, eu acho que eu cheguei até falar disso pra ti
[357:19] muitas das vezes a gente chega
[357:21] numa empresa e a gente vê
[357:23] nossa, esse cara fatura aqui
[357:25] sei lá, 100 milhões
[357:27] cara, eu tenho um amigo que ele é literalmente bilionário mano
[357:29] e eu dou conselho
[357:31] de negócio pra ele, ele dá conselho de negócio pra mim
[357:33] mas quando eu falo eu falo com certeza e ele me escuta
[357:35] sabe por que?
[357:37] por mais que eu não esteja, sei lá
[357:39] cara, nem perto, muito
[357:41] de outro mundo, outra vida
[357:43] ali, completamente
[357:45] mas por que ele escuta meus conselhos?
[357:47] porque eu me posiciono que eu sei fazer o que eu sei fazer
[357:49] na área que eu atuo
[357:51] ele não é melhor que eu
[357:53] na área que eu me proponho a ser bom
[357:55] ele não é melhor que eu, e se ele for
[357:57] eu tenho algum problema com isso
[357:59] porque o principal objetivo por exemplo de um dentista
[358:01] não é ser melhor que você no comercial
[358:03] não é ser melhor que você no marketing
[358:05] e se ele for tem algum problema com você
[358:07] beleza
[358:09] aí qual que é o ponto? eu to me posicionando
[358:11] eu sou autoridade que, eu que entendo do assunto
[358:13] ah, ele fatura mais, ele ganha mais dinheiro
[358:15] ele fez e ele vive isso há anos
[358:17] beleza, parabéns pra ele
[358:19] agora, ele não faz isso tão bem quanto eu
[358:23] entendeu? então eu posso ser
[358:25] cara, eu sei lá
[358:27] eu tenho mais dinheiro
[358:29] que o jogador do real madrid
[358:31] vai fazer com que
[358:33] dentro de um jogo de futebol
[358:35] esse cara, ele se sinta inseguro de jogar comigo
[358:37] não vai, porque ele sabe que ele é muito melhor
[358:39] jogando bola do que eu
[358:41] porque ele sabe que ele vai ganhar de mim no campo
[358:43] ele não vai nem ligar pra quanto eu tenho na conta bancária
[358:45] e esse é o ponto
[358:47] se você não se posiciona como um jogador de futebol
[358:49] jogando contra um amador
[358:51] um jogador profissional, um jogador
[358:53] realmente de uma liga europeia
[358:55] jogando contra um amador
[358:57] você tá se posicionando errado
[358:59] esse é um problema de crença teu
[359:01] então essa parte da confiança
[359:03] ela vem de dois fatores, primeiro você não confia no todo produto
[359:05] então você tem que criar uma oferta melhor pra você cobrar mais caro
[359:07] segundo ponto você não confia
[359:09] que você é melhor que o seu cliente no que você tá se propondo a fazer
[359:11] fechou?
[359:13] é interessante isso, eu acredito que a gente já
[359:16] tocou bem no sêné do problema
[359:18] e não necessariamente no problema em si
[359:20] trabalhando nesse sêné e o pessoal consegue
[359:22] ter vários insights e conseguir mudar também
[359:24] além de eu ter feito a pergunta
[359:26] top demais mano, top demais
[359:28] bora lá
[359:30] e valeu pelas perguntas, ali tem mais alguma dúvida?
[359:32] é
[359:38] bora no momento eu não pensei assim
[359:40] esse pessoal tem alguma pergunta
[359:42] beleza, beleza
[359:44] pode falar Antônio, pode haver um microfone
[359:46] falar ali
[359:48] diante do que o Cândido falou
[359:50] e que você explicou na aula
[359:52] pra esse lead que entrou na reunião
[359:54] desqualificado, financeiramente
[359:56] de repente você acha que não valeria
[359:58] a pena vender pra ele um diagnóstico?
[360:00] a gente já ia montar um diagnóstico pro nicho dele
[360:02] é um pouco gargalo dele
[360:04] não é como esse é igual o outro intervo web
[360:06] de diótica, de clínicas
[360:08] e aí um dos clientes que eu levei pro web
[360:10] ele falou que tudo que ele viu
[360:12] no web
[360:14] já tá aplicado no
[360:16] modelo comercial dele
[360:18] aí eu falei assim beleza, mas qual outros gargalos
[360:20] que você tem?
[360:22] eu vou dar um exemplo
[360:24] mas esse do comercial está estruturado
[360:26] eu vou dar um exemplo
[360:28] ele não
[360:30] é impossível
[360:32] tá, esse é o primeiro ponto
[360:34] porque nenhuma clínica que a gente implementa
[360:36] um CRC completo, nem a minha clínica
[360:38] quando eu tinha um CRC completo
[360:40] ele tinha todos aqueles gargalos resolvidos
[360:42] e aí qual que é o grande ponto
[360:44] isso é uma objeção
[360:46] e essa objeção
[360:48] você deveria ter quebrado ela e eu já vou te explicar
[360:50] sobre essa qualificação, sobre o diagnóstico
[360:52] sobre tudo isso
[360:54] essa objeção que ele te trouxe
[360:56] ela é muito comum, o que a gente vai fazer?
[360:58] a gente reconhece, cara muito bem
[361:00] eu te chamei exatamente por causa disso
[361:02] é um ponto justamente
[361:04] e a gente convidou a empresas justamente
[361:06] que estão nesse nível de consciência
[361:08] que estão nesse nível de maturidade comercial
[361:10] por que a gente trouxe isso?
[361:12] pra vocês entenderem que a gente também entende
[361:14] o ponto de vocês, só que ainda assim dentro
[361:16] desse processo, qual que é o nosso objetivo dentro
[361:18] dessa reunião? eu realmente fazer um diagnóstico
[361:20] e a gente realmente entender
[361:22] junto com você, alguns pontos de melhorias
[361:24] com base nas métricas
[361:26] hoje você já metrificou todo seu comercial
[361:28] e eu faço uma pergunta
[361:30] e essa parte da pergunta que eu fiz pra esse cara
[361:32] ele vai falar assim, pô, eu metrifiquei
[361:34] e se ele falar que não, aí ele já
[361:36] aí você já pegou ele pra
[361:38] abrir alguma possibilidade de venda de alguma coisa
[361:40] mas se ele falar, pô, eu metrifiquei
[361:42] cara, você topa se reunir comigo
[361:44] realmente pra analisar essas métricas
[361:46] nem que seja 30 minutinhos pra gente
[361:48] bater isso dali e eu realmente te mostrar
[361:50] que existe alguns pontos que
[361:52] a gente acredita que a gente pode transformar juntos
[361:54] e aumentar isso dali
[361:56] e fazer com que isso se transforme
[361:58] em uma gestão mais eficiente
[362:00] cara, podemos, pronto, acabou
[362:02] então é muito mais fácil, você tem que quebrar
[362:04] a objeção, ali o que você trouxe foi a objeção
[362:06] então a objeção a gente vai quebrar
[362:08] ali com aquela parte que a gente deu
[362:10] de objeções, mas assim, o que você
[362:12] precisa entender? o teu lead
[362:14] ele não era disqualificado
[362:16] e essa é a grande diferença
[362:18] o teu lead ele não quis se reunir com você
[362:20] é completamente
[362:22] diferente, o lead disqualificado é o lead
[362:24] que não tem dinheiro
[362:26] ele diz que tipo assim, você tá fazendo a reunião
[362:28] de clínica, aparece uma padaria
[362:30] esse é o lead disqualificado pra ti
[362:32] agora, ele tem dinheiro, ele tem
[362:34] realmente condições
[362:36] ele já faz o que você executa
[362:38] não tem problema
[362:40] não, ele inclusive agendou a reunião
[362:42] cara, ele não era disqualificado
[362:44] eu só continuo conversando com ele
[362:46] eu falei, então, qual os outros gargalos que você tem
[362:48] ele falou que a gente pode
[362:50] marcar uma reunião pra trocar uma ideia
[362:52] eu falei, claro, eu vou, como é que tá sua
[362:54] segunda ou terça-feira, aí eu agendei com ele
[362:56] pra próxima semana fazer a R1
[362:58] entendeu?
[363:00] pra dar pra mim fazer essa reunião com você
[363:02] maravilhosa
[363:04] só que aí, quem é que eu pensei
[363:06] dependendo da como ele já falou
[363:08] que o comercial dele tá ok
[363:10] eu pensei, eu posso então
[363:12] implementar pra ele um planejamento
[363:14] e se ele não tiver condição de
[363:16] comprar o serviço
[363:18] eu vendo pra ele
[363:20] essa parte que não tá batendo
[363:22] antonio, como que ele vai tá com o comercial alinhado
[363:24] e não vai ter condições de
[363:26] pagar o serviço caro
[363:28] é isso que eu tô trazendo pra ti, que eu preciso que você entenda
[363:30] se esse cara, ele não tem
[363:32] condições de pagar, ele não tá com o processo
[363:34] comercial alinhado
[363:36] não tem bom vendedor duro
[363:38] não tem bom vendedor pobre
[363:40] não tem processo comercial eficiente
[363:42] que funciona, que o dono é fudido
[363:44] entendeu?
[363:46] então, quando a gente coloca isso e o que eu preciso
[363:48] que você entenda, tá?
[363:50] eu vou pensar no serviço que eu vou vender pra ele
[363:52] não sei o que eu não sei o que lá, cara, eu volto aqui
[363:54] eu vou literalmente voltar aqui
[363:56] a primeira coisa que você tem que fazer é clarificar
[363:58] qual que é o problema dele, você não entendeu o problema dele
[364:00] e se você não entendeu o problema dele
[364:02] não tem como você vender nada pra ele
[364:04] então, a primeira coisa que você vai fazer é uma reunião
[364:06] é um diagnóstico, é literalmente um diagnóstico
[364:08] cara, tudo bem? prazer
[364:10] e você vai se apresentar aqui, você vai pegar isso aqui
[364:12] que eu esqueci de apresentar e foi bom
[364:14] você ter perguntado que como que eu me apresento
[364:16] dentro das reuniões de vendas
[364:18] não necessariamente assim
[364:20] tá? mas algo próximo disso
[364:22] que a gente já fez a reunião comigo vai saber
[364:24] que é uma vertente disso, porque eu não decoro frases
[364:26] eu decoro ali o conceito
[364:28] e aí do conceito eu vou criando frases
[364:30] ó, eu inicio a minha reunião
[364:32] e falo assim ó, nós já fizemos isso com várias outras
[364:34] empresas, exatamente como você
[364:36] esse processo que a gente vai executar
[364:38] hoje aqui, e como o nosso bate-papo
[364:40] vai funcionar hoje, ou no final
[364:42] da ligação, ou seja, na reunião
[364:44] o que que a gente vai passar
[364:46] aqui hoje, a gente vai ver
[364:48] o que que tá se passando dentro da sua empresa
[364:50] e a gente vai ver se faz sentido a gente
[364:52] avançar junto pra gente construir algo
[364:54] que possa realmente melhorar a sua empresa
[364:56] se não fizer sentido, sem problemas
[364:58] eu vou ser a primeira pessoa a te falar
[365:00] que isso aqui não faz sentido
[365:02] então quando eu trago esse cliente
[365:04] quando eu trago essa percepção
[365:06] meu amigo, qual que é o ponto que eu consigo
[365:08] trazer para esse cara?
[365:10] que é, eu realmente
[365:12] faço isso com várias outras pessoas
[365:14] e os seus problemas, e para eu entender
[365:16] seus problemas, e para entender se a gente
[365:18] consegue avançar junto, eu preciso entender
[365:20] um pouco mais sobre a sua empresa, então hoje
[365:22] a nossa reunião vai funcionar da seguinte maneira
[365:24] aí você abre a reunião, tá
[365:26] você vai abrir a reunião falando assim, hoje
[365:28] a nossa reunião vai funcionar assim
[365:30] assim e assim, então
[365:32] hoje o processo é assim
[365:34] assim e assim, acabou
[365:36] beleza, então é isso
[365:38] que você vai fazer dentro da tua reunião de vendas
[365:40] então é isso que você vai trazer para o seu cliente
[365:42] na sua reunião de vendas, então
[365:44] a primeira coisa que você vai falar para ele
[365:46] que você precisa entender, é entender
[365:48] o principal gargalo lucrativo
[365:50] então você pode se posicionar e olha que legal
[365:52] eu vou dar uma dica para vocês independente
[365:54] do produto que vocês vendam, tá
[365:56] isso aqui funciona para qualquer produto
[365:58] hoje o meu trabalho e a gente
[366:00] tem um sistema que a gente resolve problemas
[366:02] a primeira
[366:04] coisa que eu preciso entender da sua empresa
[366:06] é, qual que é o parafuso
[366:08] que a gente aperta, ou seja
[366:10] o problema que a gente resolve
[366:12] que a gente literalmente poderia dobrar
[366:14] triplicar o teu faturamento sem necessariamente
[366:16] você investir mais, ou que você investisse
[366:18] o mínimo possível, só que se a gente mudar isso
[366:20] a gente consegue aumentar o seu gargalo
[366:22] e eu quero resolver esse problema junto com você
[366:24] aqui nesse bate-papo e eu quero te dar esse insight
[366:26] e eu tenho certeza que se você estiver disposto
[366:28] a conversar comigo e realmente abrir algumas
[366:30] coisas, eu posso te impressionar
[366:32] e superar suas expectativas
[366:34] para a gente resolver esse problema, fechou?
[366:36] fechou, cara acabou, você pode iniciar a reunião assim
[366:38] inclusive a reunião de clínica que eu fechei
[366:40] desse mesmo webinar que você fechou
[366:42] eu fechei uma reunião de clínica
[366:44] foi aquele contrato que eu fiz ali de
[366:46] cara, se eu não me engano, foi 34 mil
[366:48] a gente recebeu 5 mil de entrada
[366:50] e aí o resto foi em 7 parcelas de 4 mil sim
[366:52] alguma coisa assim, o contrato foi
[366:54] mais ou menos assim, por uma implementação de 60 dias
[366:56] eu acho que foi assim
[366:58] tem que ver ali com o Gabriel
[367:00] quando a gente bate nesse ponto
[367:02] e foi eu que vendi
[367:04] mas desde aquela venda até agora
[367:06] é difícil lá, mas 8 reuniões
[367:08] então não é fácil de você lembrar
[367:10] todos os reuniões que você faz
[367:12] mas vamos lá, quando a gente
[367:14] parte disso, eu preciso que você
[367:16] entenda, é, cara
[367:18] dentro do seu processo de reunião
[367:20] se você sabe mais ou menos quanto que esse
[367:22] li de fatura, você vai
[367:24] ali para esse processo
[367:26] de clarificação, você vai para esse
[367:28] processo aonde você vai entender
[367:30] a dor dele
[367:32] e aí pela dor dele, muitas das vezes
[367:34] e aí você está pensando, cara, qual o serviço
[367:36] que eu vou vender, o que que eu vou vender
[367:38] como que eu vou vender o meu serviço, quanto que eu vou cobrar
[367:40] antes mesmo de entender qual que é o resultado que esse
[367:42] cara quer, qual que é a dor que esse
[367:44] cara quer, então por exemplo
[367:46] você consegue abrir o Google o meu negócio
[367:48] você consegue mandar o Google o meu negócio
[367:50] dessa empresa aqui no chat, eu prometo que ninguém
[367:52] vai prospectar ela, só tem gente boa
[367:54] se você conseguir mandar o Google o meu negócio
[367:56] eu vou procurar aqui agora
[367:58] muitas das vezes no Google o meu negócio
[368:00] eu já vejo, cara, esse cara tem 5 funcionários
[368:02] de dinheiro para me pagar, como que eu vou cobrar
[368:04] barato e outra, ele falou para você
[368:06] eu tenho um processo comercial totalmente
[368:08] alinhado
[368:10] e se ele falou isso, ele é muito confiante
[368:12] ou ele é muito maluco
[368:14] da cabeça, ou ele é aquele dono
[368:16] que acha que sabe de tudo e não sabe de nada
[368:18] na verdade, mas assim
[368:20] você vai ter que identificar isso aqui nesse
[368:22] primeiro momento
[368:24] e você vai ter que quebrar essa objeção
[368:26] de ego dele, e aí você vai usar aquela
[368:28] quebra de objeção que eu falei comparativo
[368:30] que era assim, porra, ele tinha até um processo
[368:32] comercial, só que esse processo comercial
[368:34] ele não foi estruturado para ter sucesso
[368:36] e aí ele acreditava que o processo comercial dele
[368:38] era eficiente, mas podia melhorar muito
[368:40] olha o que eu fiz com esse cliente
[368:42] falando dele mesmo, mas usando o primo
[368:44] exatamente, exatamente
[368:46] então xim e uma pessoa usando o outro
[368:48] que não existe
[368:50] de preferência, você não xingar uma pessoa real
[368:52] mas enfim
[368:54] quando a gente traz isso
[368:56] foi respondido à tua dúvida ou antoni
[368:58] beleza
[369:00] bora lá
[369:02] pessoal
[369:04] alguém tem mais alguma dúvida, antes de eu passar
[369:06] para a próxima parte, tudo ok?
[369:09] vocês estão conseguindo entender?
[369:14] beleza, beleza
[369:16] ninguém está falando nada, não estou
[369:18] escutando nada, não estou
[369:20] vendo uma mensagem no chat, significa
[369:22] que todos estão dormindo
[369:24] pode ou não passar para a próxima parte
[369:26] da aula
[369:28] tá top, beleza
[369:30] Instagram do cliente
[369:32] manda aí o Instagram do cliente
[369:34] vocês querem que eu avali o cliente do
[369:36] do antonio?
[369:38] eu vou avaliar o cliente do antonio aqui rapidão
[369:40] para vocês terem ciência ali
[369:42] pior que eu não estou logado no Instagram
[369:44] acho que não vai dar para avaliar
[369:46] deixa eu avaliar aqui
[369:48] perfil do cliente
[369:52] o perfil não está nem disponível
[369:54] o antonio
[369:58] o perfil do cliente não está nem disponível
[370:00] esse é o link
[370:02] que está no Instagram dele
[370:04] pelo
[370:06] o número de telefone dele
[370:08] ah enfim
[370:10] depois tu dá uma procurada melhor
[370:12] depois a gente avalia esse cliente ali
[370:14] tu me manda no privado, eu te auxilie o início
[370:16] tá, mas vamos lá
[370:18] pessoal, bora iniciar a próxima
[370:20] parte, eu tenho a pergunta sobre a virada
[370:22] de chave, se preparar
[370:24] era o tema do início do evento
[370:26] como assim?
[370:28] eu vou te acompanhar
[370:32] beleza, eu vou iniciar essa parte
[370:34] depois dessa parte de reuniões
[370:36] tu abre o microfone e a gente esclarece isso
[370:38] porque eu acho que é alguma coisa que a gente
[370:40] passou no início do evento fechou
[370:42] e aí a gente parte disso
[370:44] gente, essa parte de R1, R2
[370:46] e tudo mais
[370:48] sabe por que eu não preparei um mapa mental?
[370:50] agustavo, você não preparou um mapa mental
[370:52] de R1, R2?
[370:54] gente, eu vou falar uma coisa para vocês agora
[370:56] e essa coisa vai chocar vocês
[370:58] essa coisa
[371:00] fazer com que vocês
[371:02] expandam a cabeça de vocês
[371:04] de uma vez por todas
[371:06] eu vou ensinar
[371:08] vocês a fazerem uma venda em duas reuniões
[371:10] pessoal
[371:12] quando vocês vão fazer uma venda em uma única reunião
[371:14] tá
[371:16] isso é importante eu explicar pra vocês
[371:18] antes mesmo de eu começar a explicar
[371:20] por que é bom você fazer em duas reuniões
[371:22] mas às vezes você vai fazer uma reunião
[371:24] muitas das vezes eu vou fazer uma única reunião
[371:26] e eu preciso passar por esse processo inteiro
[371:28] quando que você vai fazer
[371:30] em uma única reunião
[371:32] tá
[371:34] a sua venda
[371:36] quando você conseguir, anota isso
[371:38] eu farei em uma única reunião
[371:40] a minha venda
[371:42] primeiro ponto, se o meu Liddy
[371:44] estiver pronto para comprar, se ele for
[371:46] o único dono, o único sócio
[371:48] se eu conseguir
[371:50] dentro dessa reunião eu souber
[371:52] que eu vou conseguir passar por
[371:54] todas essas etapas
[371:56] e aí eu faço uma única reunião
[371:58] e faço a venda
[372:00] se eu não conseguir passar por todas essas etapas
[372:02] eu não vou fazer uma única reunião, eu vou dividir ela em duas
[372:04] se esse Liddy
[372:06] tiver um outro sócio, eu não vou fazer uma única reunião
[372:08] eu vou fazer em duas
[372:10] se esse Liddy deixa muito claro
[372:12] que ele ainda não confie em mim
[372:14] que ele ainda não está pronto para comprar o produto
[372:16] eu não vou fazer uma reunião, eu vou fazer em duas
[372:18] quando eu vou fazer uma única reunião
[372:20] quando esse cara chega com um problema
[372:22] e eu tenho uma resolução mais
[372:24] clara ainda para fazer
[372:26] esse cara realmente
[372:28] solucionar esse problema
[372:30] então quando eu tenho uma oferta para esse Liddy
[372:32] quando eu já tenho estruturado e quando eu já sei
[372:34] informações sobre esse Liddy
[372:36] então quando ele já venho na própria preparação
[372:38] eu já sabia mais ou menos
[372:40] do que se tratava e eu consegui
[372:42] realmente conduzir esse Liddy
[372:44] então nesses quesitos eu faço uma única reunião
[372:46] só faça uma única reunião de vendas
[372:48] para você vender o seu produto
[372:50] direto se você preparou seu cliente
[372:52] antes para comprar
[372:54] Gustavo e produtos menores, produtos low ticket
[372:56] aí sim você vai fazer uma única reunião
[372:58] beleza
[373:00] se for um produto de 500 a
[373:02] 1200 reais
[373:04] você vai fazer uma reunião e aí você vai marcar
[373:06] uma próxima vez só se ele não comprar na hora
[373:08] se for errei aí você tem que deixar
[373:10] sua oferta pronto, tá?
[373:12] como eu falei ali da oferta e tudo mais
[373:14] você tem que deixar sua oferta pronto
[373:16] se for um produto de 1500, sei lá
[373:18] eu estou definindo ali pela média da galera
[373:20] mas assim
[373:22] eu faço algumas vendas de, sei lá
[373:24] às vezes eu meto louco e eu faço
[373:26] uma venda muito alta só na primeira reunião
[373:28] porque eu sabia que o cliente estava apto
[373:30] a comprar naquela primeira reunião
[373:32] pelos primeiros 5 minutos de conversa
[373:34] e olha que louco isso
[373:36] eu defino se vai ter duas reuniões ou não
[373:38] não é durante a prospecção
[373:40] não é durante a qualificação
[373:42] é nos primeiros 5 minutos de conversa
[373:44] sabe o que que eu vou literalmente
[373:46] saber
[373:48] sabe quando que eu vou fazer uma única reunião
[373:50] quando nos primeiros 5 minutos de conversa
[373:52] onde eu estou entendendo a dor dele
[373:54] o problema que ele tem e por que que ele tá aqui comigo
[373:56] eu, se eu entender
[373:58] que isso é uma urgência pra ele resolver
[374:00] e se eu entender que não só é uma urgência
[374:02] pra ele resolver
[374:04] mas
[374:06] ele é o próprio decisor, ele é o cara que decide
[374:08] isso dali
[374:10] se eu entendo isso nos primeiros 5 minutos de conversa
[374:12] é um feeling, você vai conseguir identificar isso
[374:14] se não tá muito difícil pra ele enxergador
[374:16] se não é algo que ele incomoda
[374:18] se não é algo que ele fala bastante
[374:20] cara, eu vou elevar o nível de consciência
[374:22] eu vou pra duas reuniões, beleza?
[374:24] então, a primeira reunião
[374:26] é muito mais um feeling teu
[374:28] ou se o cara ele tá sozinho
[374:30] e ele tem um sócio, não faz uma única reunião
[374:32] não adianta
[374:34] vai ser uma perca de tempo pra ti
[374:36] e esse cara não vai comprar porque o sócio dele
[374:38] ele não vai explicar pro sócio dele tão bem quanto você explica
[374:40] fechou?
[374:42] então, vamos lá
[374:44] como que eu faço uma boa R1?
[374:46] o que seria R1?
[374:48] seria a primeira reunião
[374:50] então, a gente tem um conceito aqui dentro da empresa
[374:52] que as vezes a gente separa
[374:54] as reuniões em R1, R2, R3, R4
[374:56] teve um cliente que eu fiz
[374:58] sei lá, o meu máximo
[375:00] foi até R8
[375:02] R8 pra mim fazer uma venda pra um cliente
[375:04] 8 reuniões até eu fazer essa venda pra um cliente
[375:06] mas o conceito de R1
[375:08] é você fazer um diagnóstico
[375:10] e no R2 você fazer a venda
[375:12] beleza? então, a primeira reunião
[375:14] é o diagnóstico e a apresentação
[375:16] aonde a gente tá se conhecendo
[375:18] e aí, a segunda reunião
[375:20] é aonde a gente firme esse relacionamento
[375:22] então, a segunda reunião é aonde de fato
[375:24] a gente concretiza isso
[375:26] beleza? por qual motivo
[375:28] teve tantas reuniões? porque era um contrato muito caro
[375:32] existiam muitos decisores
[375:34] era um contrato muito difícil de fechar
[375:36] então, cara, foi uma negociação
[375:38] muito extenso, mas não vai acontecer até contrato
[375:40] de, sei lá, 50 mil reais, 100 mil reais
[375:42] não vai acontecer isso não
[375:44] você vai conseguir fazer R1, R2
[375:46] se o cara não comprar, eu vou continuar marcando a reunião infinita
[375:48] até ele comprar de mim, tá?
[375:50] então, qual que é o grande ponto aqui?
[375:52] e eu preciso que vocês entendam esse ponto
[375:54] beleza? a grande
[375:56] é o grande questão da R1
[375:58] é isso aqui, ó
[376:00] opa
[376:05] R1, R1
[376:12] e R1
[376:16] e vocês a fazerem R1
[376:18] só que vocês não perceberam
[376:20] qual que é a primeira coisa que eu preciso entender na primeira reunião
[376:22] eu preciso entregar insights
[376:24] para o meu cliente, entender as dores dele
[376:26] para mim criar uma oferta para ele
[376:28] ou para mim apresentar oferta
[376:30] adaptada para ele, para mim apresentar oferta
[376:32] da melhor maneira para ele
[376:34] olha que louco
[376:36] então, a primeira reunião
[376:38] o que que eu falei da primeira reunião?
[376:40] ela é um diagnóstico, certo?
[376:42] dentro de diagnóstico
[376:44] faz sentido, eu descobri
[376:46] e clarificar qual que é o problema desse cara
[376:48] faz sentido?
[376:50] faz
[376:52] dentro de diagnóstico, é bom eu nomear
[376:54] o problema desse cara e fazer o cliente
[376:56] ele tomar a consciência que aquilo é um problema dele
[376:58] e dar um nome a aquele problema
[377:00] faz
[377:02] dentro de diagnóstico, é importante eu revisar a dor
[377:04] e fazer com que essa dor ela seja potencializada?
[377:06] sim
[377:09] e aí eu posso dar vários insights
[377:11] e aí eu posso falar cara, você pode fazer isso
[377:13] e fazer aquilo
[377:15] isso aqui é o MR1
[377:17] eu fiz de propósito essa aula de closer
[377:19] deixando ali um ponto de
[377:21] como fazer o MR1 R2
[377:23] para vocês prestarem atenção
[377:25] e vocês aprenderem a vender
[377:27] mas a primeira reunião
[377:29] a primeira reunião de diagnóstico
[377:31] a única coisa que você vai acrescentar dentro disso
[377:33] são algumas coisas
[377:35] de autoridade
[377:37] então você vai apresentar muitas vezes a sua metodologia
[377:39] tá?
[377:41] coisas que você vai acrescentar que não estão aqui
[377:43] a tua metodologia
[377:45] que você vai explicando enquanto esse cara vai
[377:47] enquanto você vai intensificando a dor desse cara
[377:49] então quando esse cara ele fala o problema
[377:51] você pergunta, você intensifica a dor
[377:53] e aí você fala algumas soluções
[377:55] e aí você começa a falar
[377:57] sua metodologia em três pilares
[377:59] você pode falar sua metodologia em três pilares
[378:01] e aí você fala assim pro cara
[378:03] pô bacana, entendi todas as informações
[378:05] entendi como eu posso te ajudar
[378:07] esses insights que eu te dei
[378:09] e eu fizerem um sentido
[378:11] posso preparar uma proposta personalizada pra você?
[378:13] pode
[378:16] olha que louco, olha que fácil fazer uma reunião
[378:18] e nessa proposta que eu vou preparar
[378:20] personalizada pra você, posso te fazer um pedido?
[378:22] dentro da próxima reunião
[378:24] você pode tomar uma decisão
[378:26] você pode trazer o seu sócio e tomar uma decisão
[378:28] se a proposta que eu fizer
[378:30] realmente se encaixar com o seu cenário atual
[378:32] cara posso
[378:34] e aí você garante que na segunda reunião
[378:36] você vai ter uma resposta de vendas
[378:38] e se o cara falar cara eu não vou conseguir
[378:40] cara muito provavelmente o meu sócio
[378:42] não vai participar da próxima reunião
[378:44] eu não tomo decisões em qual
[378:46] cara não tem problema ele falar tudo isso
[378:48] se ele falar tudo isso você fala o seguinte
[378:51] não, sem problemas
[378:53] então vamos fazer o seguinte
[378:55] na próxima reunião eu vou te apresentar a proposta
[378:57] e eu vou te apresentar a proposta de uma maneira
[378:59] que faça sentido
[379:01] se ela fizer sentido a única coisa que a gente vai precisar bater
[379:03] depois são os valores, ok?
[379:05] ok
[379:07] então a proposta eu passo a oferta inteira
[379:09] e muitas das vezes eu passo até o valor
[379:11] só que
[379:15] se eu faço essa primeira pergunta
[379:17] dentro da R1 e se eu preparo esse lead
[379:19] para uma R2
[379:21] aonde eu vou
[379:23] ele esteja preparado pra realmente
[379:25] identificar se aquilo faz sentido pra empresa dele
[379:27] ou seja
[379:29] se eu não vou conseguir a resposta de venda
[379:31] dentro da R2 o que eu vou pedir pra ele me respondendo
[379:33] antes da R2? você consegue pelo menos
[379:35] falar
[379:37] com sinceridade a probabilidade de a gente
[379:39] fechar nessa segunda reunião
[379:41] você consegue realmente falar com
[379:43] certeza
[379:45] quanto de chance eu tenho de fechar
[379:47] ou realmente se faz sentido
[379:49] se aquilo se encaixa pra sua empresa
[379:51] dentro dessa próxima reunião
[379:53] porque é importante pra mim seu feedback
[379:55] você comprando ou não diminuir naquela reunião
[379:57] eu quero saber de ti
[379:59] a gente pode bater
[380:01] uma resposta sua definitiva
[380:03] por mim sim eu sei que você tem que ver com seu sócio
[380:05] por mim sim eu só preciso ver com seu sócio
[380:07] ou por mim não eu posso contar com sua resposta honesta
[380:09] pode então eu tento
[380:11] trazer o máximo de confirmação que possível
[380:13] para uma segunda reunião
[380:15] mas caramba é R1 não tem segredo
[380:17] é um diagnóstico e o que você vai fazer
[380:19] o diagnóstico? até o clou
[380:21] o diagnóstico é o clou do closer
[380:23] beleza
[380:25] então você pode apresentar sua metodologia
[380:27] é uma conversa
[380:29] se você já fez uma reunião comigo
[380:31] você vai ver que muitas vezes eu abro um mapa mental
[380:33] só pra encher o saco ali
[380:35] só pra ter alguma coisa na tela
[380:37] porque eu nem falo nesse mapa mental
[380:39] eu vou fazer um diagnóstico
[380:41] eu vou realmente entendendo
[380:43] e aí se eu entendo que eu quebra essa barreira
[380:45] e eu consigo tomar uma decisão com esse cara na hora
[380:47] eu vou pro próximo ponto
[380:49] e olha que legal dentro do webinário
[380:51] se você faz um webinário é muito mais provável
[380:53] que o seu lead vem pronto pra comprar
[380:55] beleza?
[380:57] gente se você vai fazer uma reunião presencial
[380:59] aí isso muda um pouquinho
[381:01] já leva uma oferta
[381:03] já leva um escopo de oferta muito pronto
[381:05] com valores e tudo mais
[381:07] fechou? porque? quando a gente
[381:09] faz uma reunião presencial
[381:11] muda totalmente o aspecto
[381:13] a confiança
[381:15] do seu cliente é muito maior com você
[381:17] presencialmente
[381:19] então você pode
[381:21] passar por todo o processo de closer
[381:23] dentro de uma reunião presencial
[381:25] dentro de uma reunião presencial
[381:27] você pode passar por todo o processo de closer
[381:29] completo sem se preocupar
[381:31] já mandar oferta, já mandar venda, já mandar valores
[381:33] porque
[381:35] provavelmente vai acontecer em uma única venda
[381:37] então não faça uma, duas, três, quatro
[381:39] cinco reuniões presenciais
[381:41] tenta finalizar tudo na primeira
[381:43] caso não finaliza na primeira já deixa a data
[381:45] marcada pra você ir lá de novo na reunião presencial
[381:47] mas
[381:49] lead
[381:51] tá bom, lead que vai tomar uma decisão
[381:53] lead que vai realmente comprar de você
[381:55] normalmente um produto caro
[381:57] que vai fazer em duas reuniões
[381:59] como não tem oferta pra modelar pelo fato do produto ser
[382:01] um serviço, você não precisa modelar oferta
[382:03] tá?
[382:05] você não precisa modelar oferta de ninguém
[382:07] porque eu crio as minhas ofertas
[382:09] eu realmente crio minhas ofertas, eu não fico vendo
[382:11] oferta dos outros no mercado
[382:13] porque eu acho o pessoal do mercado muito ruim
[382:15] muito ruim
[382:17] e aí eu não fico modelando isso
[382:19] beleza, então eu penso muito na minha oferta
[382:21] pega aquela metodologia
[382:23] e pensando na tua oferta
[382:25] se vocês estão na reunião
[382:27] faz sentido
[382:29] dividir em R1
[382:31] o processo de R1 e R2
[382:33] além de ser pra bater o material o caso tenha conseguido
[382:35] fechar ali na hora
[382:37] vamos lá, Gabriel, no seu caso específico
[382:39] eu vou explicar o caso do Gabriel que talvez seja o seu caso
[382:41] produto do Gabriel
[382:43] ticketing inicial, acho que é uns 10 mil reais
[382:45] depois tem reconhecimento, é um produto que gera
[382:47] uma certa objeção
[382:49] a primeira reunião
[382:51] e aí eu vou te dar uma dica, se você for
[382:53] perfeito, que vai fazer com que você
[382:55] eu acho que hoje você não dividir em duas reuniões
[382:57] mas
[382:59] eu recomendaria que você
[383:01] dividisse em duas reuniões
[383:03] o ticketing 10k, boa
[383:05] ou Gabriel
[383:07] uma pergunta que eu tenho, sincera pra ti agora
[383:11] cabe mais um sócio comercial
[383:13] nesse processo, não, o produto de vocês é muito bom mano
[383:15] nossa
[383:17] tá maluco
[383:19] eu me convido
[383:21] eu viajo aí, vou conhecer a empresa de vocês
[383:23] pra realmente
[383:25] a gente bater isso, mas enfim
[383:27] vamos lá
[383:29] quando a gente pega
[383:31] e a gente faz ali uma R1, uma R2
[383:33] no teu caso específico
[383:35] o seu produto Gabriel
[383:37] não é um produto barato
[383:39] e também não é um produto que o cara vai implementar
[383:41] do dia pra noite, então pensa
[383:43] qual é a complexidade pro meu cliente
[383:45] absorver o meu produto
[383:47] qual é a complexidade pro meu cliente
[383:49] enxergar que o meu produto
[383:51] é o melhor produto pra ele
[383:53] realmente
[383:55] pra ele realmente
[383:57] usar, utilizar esse produto
[383:59] e tudo mais, e por aí vai
[384:01] vamos lá
[384:03] quando eu faço isso
[384:05] eu preciso entender se
[384:07] a decisão do meu cliente vai demorar pra ele fechar
[384:09] essa venda, no seu caso a decisão
[384:11] do seu cliente vai demorar, então o que eu vou fazer
[384:13] numa primeira reunião, eu vou mapear
[384:15] eu vou fazer diagnóstico, eu vou entender os problemas
[384:17] que ele tem, e aí os problemas
[384:19] que ele tem, eu vou direcionar os problemas que ele tem
[384:21] recorrelacionado ao seu produto
[384:23] pra quem não sabe, ele tem um clube de benefícios
[384:25] pra clínicas, esse clube de
[384:27] não tem nada a ver com marketing digital
[384:29] esse clube de benefícios, ele vende uma assinatura
[384:31] pro cliente da clínica
[384:33] e aí a clínica ganha
[384:35] requentemente, ele ganha requentemente
[384:37] só que cada implementação é 10 mil reais
[384:39] já falei pra ele subir pra 20, 30 mais, enfim
[384:41] e aí cada implementação custa um
[384:43] dinheiro e por aí vai
[384:45] enfim, ele tem um produto muito bom
[384:47] e aí só que o produto dele é muito
[384:49] complexo, porque a implementação
[384:51] do produto dele dentro da clínica
[384:53] vai ser uma coisa que vai demorar
[384:55] então a primeira coisa que eu vou identificar
[384:57] eu vou fazer esse processo aqui, identificando a dor
[384:59] relacionada ao produto que eu tenho
[385:01] então quais são os obstáculos, quais são as dores
[385:03] hoje, qual que é a tua projeção financeira
[385:05] hoje, qual que foi sua dificuldade
[385:07] você já tentou colocar um produto de recorrência
[385:09] pô, tentei colocar, não deu certo
[385:11] e aí você vai fazer todo esse processo
[385:13] e aí você vai fazer um diagnóstico
[385:15] pra ver se ele está apto
[385:17] a ser um parceiro seu
[385:19] e olha essa narrativa
[385:21] você lembra que eu falo que
[385:23] toda objeção é falta de uma narrativa
[385:25] bem construída
[385:27] se eu chego numa M1
[385:29] e eu tenho um produto
[385:31] e esse cara
[385:33] hoje o lead do Gabriel, ele vem
[385:35] essencialmente por inbound
[385:37] eu acho que ele vai começar a fazer webinário
[385:39] mas se o meu lead ele vende inbound
[385:41] tudo mais, eu posso começar
[385:43] a minha M1 já trazendo
[385:45] uma argumentação de tipo assim
[385:47] cara, eu quero ver se realmente meu produto
[385:49] ele se encaixe pra sua situação ideal
[385:51] se você é o meu perfil de cliente
[385:53] e se eu realmente vou conseguir te ajudar
[385:55] porque se eu não conseguir te ajudar não faz sentido
[385:57] nem eu te apresentar o produto
[385:59] e eu preciso entender algumas coisas da sua empresa
[386:01] a gente pode fazer esse acal e eu entender
[386:03] algumas pontos da sua empresa e eu mostrar
[386:05] também alguns pontos da minha empresa
[386:07] pra ver se a gente conecta
[386:09] a minha reunião, o cara vai falar
[386:11] caralho, não, lógico, lógico eu me encaixo
[386:13] como assim eu não me encaixo
[386:15] e ele vai ficar rio inteiro se provando
[386:17] e aí a primeira reunião inteira
[386:19] ele vai ficar se provando, eu inverti o jogo
[386:21] era eu que tava vendendo pra ele, agora é ele
[386:23] que tá tentando comprar de mim
[386:25] e aí eu vou para uma segunda reunião
[386:27] então dentro da primeira reunião
[386:29] pessoal, eu consigo
[386:31] inverter essa narrativa
[386:33] não é difícil
[386:35] eu poderia passar milhares de coisas
[386:37] mas muitas das vezes você nem vai precisar
[386:39] abrir
[386:41] nada dentro da sua primeira reunião
[386:43] vai ser uma conversa
[386:45] desde que você deixe muito claro pro seu cliente
[386:47] que vai ser uma conversa
[386:49] alguém já viu meu pitch de webinario
[386:51] eu falo pro meu cliente que ele precisa estar aberto
[386:53] que ele precisa conversar com a gente
[386:55] que a gente precisa diagnosticar a empresa dele
[386:57] que ele precisa conversar comigo
[386:59] não adianta eu marcar uma reunião
[387:01] isso é um erro de quem faz prospecção
[387:03] às vezes você esmarca uma reunião e fala assim
[387:05] eu vou melhorar a tua empresa
[387:07] não, a gente tem que colocar que isso é uma conversa
[387:09] porque se eu não conversar com meu cliente
[387:11] não tem como eu vender
[387:13] o único jeito que os únicas duas coisas que fazem
[387:15] com que eu não venda pra um cliente
[387:17] primeiro ele não tem dinheiro, segundo ele não abrir a boca
[387:19] se ele não abrir a boca e não tiver dinheiro
[387:21] é impossível vender para esse cara
[387:23] beleza?
[387:25] então a primeira R1 vocês entenderam?
[387:27] e eu vou mostrar R2 que vocês devem achar
[387:29] que é isso aqui mas não é
[387:31] posso mostrar R2?
[387:36] você entendeu? confirma pra mim a gente tem 20 pessoas
[387:38] cara a gente tá com 20 pessoas
[387:40] desde as 8 da manhã a gente, parabéns
[387:42] quem realmente tá aqui?
[387:44] gente, quem realmente tá aqui? fala aí no chat
[387:46] só pra eu ver se realmente tem uma galera aqui
[387:48] ou se a galera deixou aberto e foi dormir
[387:50] eu acho que muita gente pegou
[387:52] deixou aberto e saiu de casa ali
[387:54] deixou a tela gravando, foi fazer outras coisas
[387:56] ok, ok, boa
[387:58] fechou
[388:00] então vamos lá, pessoal
[388:02] quando a gente coloca
[388:04] a R2, a primeira reunião
[388:06] ela já foi
[388:08] a gente entendeu todos os problemas do nosso cliente
[388:10] a gente vai chegar muito mais
[388:12] municiado com esse cliente
[388:14] na R1
[388:16] a Fernanda aí tá desde o início também
[388:18] a gente vai chegar muito mais
[388:20] municiado no nosso cliente
[388:22] pra uma segunda reunião
[388:24] e aí nessa segunda reunião
[388:26] o que eu vou fazer?
[388:31] a minha R2 é isso
[388:33] apresentação da minha oferta
[388:35] tá, apresentação da minha oferta
[388:37] tipo assim
[388:39] eu personalizo a minha oferta
[388:41] sabe o seu produto?
[388:43] eu vou falar uma coisa que vocês têm
[388:45] a vantagem
[388:47] que ninguém mais do mercado
[388:49] tem
[388:51] e essa vantagem ela é muito mais uma questão
[388:53] de percepção e de insight mesmo pra
[388:55] você aplicar isso
[388:57] define a sua oferta
[388:59] escreve a sua oferta inteira
[389:01] deixe sua oferta 100% adaptada
[389:03] 100% construída
[389:05] você deixou a sua oferta 100% construída
[389:07] depois
[389:09] você vai fazer uma outra reunião com um cliente
[389:11] qual que é a única coisa que você precisa fazer?
[389:15] é, pegar essa mesma oferta
[389:17] só mudar o nome
[389:19] em algumas coisas
[389:21] pra se encaixar com a realidade desse cliente
[389:23] só mudar a explicação da sua oferta pra se encaixar com esse cliente
[389:25] só mudar esse magic
[389:27] mas o resto
[389:29] o escopo inteiro da oferta ele vai continuar o mesmo
[389:31] e aí você vai chegar no MR2
[389:33] e aí o que você vai fazer?
[389:35] você vai apresentar a oferta
[389:37] e aí você vai literalmente vender o destino
[389:39] e não o final do voo
[389:41] então a gente faz toda essa construção
[389:43] Gustavo, então eu fiz toda essa
[389:45] construção, eu vou até mostrar pra vocês aqui
[389:47] slides
[389:49] eu vou achar os slides aqui pra mostrar
[389:51] uma oferta pra vocês
[389:53] beleza?
[389:55] então a gente faz toda essa construção junto com o nosso cliente
[389:57] toda essa parte
[389:59] de closer pra gente fazer o que?
[390:01] demonstrar a oferta no final
[390:03] a segunda reunião
[390:05] eu vou iniciar ela
[390:07] e aí quais pontos eu vou bater?
[390:09] eu vou bater o S de closer
[390:11] e eu vou bater a oferta
[390:13] e aí o S
[390:15] eu vou usar o R também
[390:17] eu vou usar o E também que é a quebra de objeções
[390:19] que tá aqui também
[390:21] e eu vou usar as três perguntas
[390:23] e as três perguntas essenciais
[390:25] então essa é tua R2
[390:28] de verdade mesmo
[390:30] eu coloquei aqui
[390:32] eu achei a oferta
[390:34] que eu tenho aqui construída
[390:36] um desafio treinando aqui
[390:38] deixa eu ver se é essa aqui
[390:46] esse aqui é um dos produtos que eu tenho
[390:48] não sei se vocês estão vendo a tela
[390:50] tá todo mundo vendo a tela?
[390:54] ele não tá vendo ainda
[390:56] esse produto
[390:58] inclusive o Vikas tá aí?
[391:00] eu acho que não vou mostrar isso hoje não
[391:05] mas enfim, esse produto
[391:07] o que ele vai ser
[391:09] ele é literalmente um produto
[391:11] aonde eu vou vender um clube
[391:13] de assinatura
[391:15] a gente vai uma comunidade
[391:17] então eu deixei a minha oferta
[391:19] pronto, ela tem a minha oferta
[391:21] minha oferta é 30 mil entrei da dia
[391:23] e aí tem um mecanismo
[391:25] o que ele vai dominar, o que ele vai ganhar
[391:27] o que ele vai ter acesso, três clientes
[391:29] uma venda paga tudo, aqui o valor
[391:31] então desse valor o que ele ganha
[391:33] e aí vagas
[391:35] estritamente limitadas aqui
[391:37] que tem o dia de hoje
[391:39] que não foi o dia de hoje, que não vou
[391:41] lançar nada hoje, fiquei em tranquilos
[391:43] mas assim, que é um produto que a gente elaborou
[391:45] e que eu tenho a oferta pronto
[391:47] agora, se eu entro numa reunião, numa R1
[391:49] eu já sei que eu vou oferecer isso
[391:51] lembra que eu falei de esteira de produtos
[391:53] se eu vejo o cara não tem dinheiro pra comprar nada
[391:55] o que eu vou vender, eu já vou direto pra sua oferta
[391:57] ah, se eu vejo que o cara
[391:59] ele vai comprar uma oferta mais cara
[392:01] eu vou direto pra próxima oferta mais cara
[392:03] a única coisa que eu preciso adaptar dentro da minha
[392:05] linguagem, dentro da minha venda final
[392:07] depois, é fazer o que?
[392:09] adaptar
[392:11] o jeito que eu apresento pra esse cliente
[392:13] porque o produto de vocês vai mudar
[392:15] vocês vão ficar mudando o produto e o serviço de vocês
[392:17] o tempo todo, não vão
[392:19] vocês vão ficar mudando a oferta de vocês o tempo todo
[392:21] não vão, vocês vão ficar mudando o processo
[392:23] de vocês a entrega de vocês
[392:25] um monte de coisas de vocês o tempo todo, não vão
[392:27] o que vocês precisam mudar
[392:29] o jeito que vocês comunicam essa mesma oferta
[392:31] de vocês publicos
[392:33] só isso
[392:35] só isso, então
[392:37] quando você vai fazer isso, quando você deixa
[392:39] a tua oferta pronta e você prepara pra tua reunião
[392:41] é muito mais fácil porque
[392:43] porque você tem todo diagnóstico dessa pessoa
[392:45] você tem todas as dificuldades
[392:47] dessa pessoa e aí você tá
[392:49] guiando essa pessoa pra essa solução
[392:51] cara, não é difícil
[392:53] você fazer uma R1, R2
[392:55] eu de verdade, eu gostaria de te explicar
[392:57] eu pensei em colocar 30 slides
[392:59] explicando o que que você vai falar no início da R1
[393:01] início da R2, início da R3
[393:03] mas assim
[393:05] não tem porquê, você não precisa
[393:07] disso
[393:09] se você entender que
[393:11] na primeira reunião
[393:13] você tá fazendo a consulta médica
[393:15] que o seu cliente ele precisa
[393:17] pra identificar qual doença ele tem
[393:19] e na segunda reunião
[393:21] você tá demonstrando a avaliação
[393:23] dessa consulta médica e tá apresentando
[393:25] a cirurgia que ele precisa fazer
[393:27] você entendeu como que você faz
[393:29] uma R1, R2, ainda mais com todo esse conteúdo
[393:31] fechou
[393:33] até aqui tudo ok
[393:35] até aqui alguma dúvida
[393:37] porque eu ainda tenho esse e
[393:39] aqui sim, tem um ouro
[393:41] específico, mas
[393:43] até aqui alguma dúvida
[393:45] alguma coisa que vocês querem perguntar
[393:49] boa, ninguém?
[393:51] todo mundo tranquilo?
[393:53] desculpem lá, cara, eu acho que
[394:00] na verdade eu acho que não tem ninguém
[394:02] que ficou do início até o final de tipo assim
[394:04] sem parar
[394:06] as oito horas, além de mim
[394:08] além de mim
[394:10] mas vamos lá, tranquilo
[394:12] tranquilo, boa
[394:14] pessoal, a gente vem pra nossa última etapa
[394:16] que
[394:18] literalmente é a etapa que vai
[394:20] fazer você ganhar muito
[394:22] dinheiro ao longo prazo
[394:24] ganhar muito dinheiro ao longo prazo
[394:26] vamos lá
[394:29] dentro dessa última etapa
[394:31] que eu quero passar pra vocês
[394:33] tá
[394:35] a metodologia de nutrição infinita
[394:37] lembra que o tito ele tava falando um pouco de
[394:39] heather, ah mesmo, heather tá desde o início
[394:41] o jeverson tá desde o início
[394:43] boa, a gente tem alguns guerreiros
[394:45] aqui comigo, valeu
[394:47] então bora lá, lembra que
[394:49] quem tava ali meio dia e escutou
[394:51] o tito falando um pouquinho, vocês escutaram ele falando de
[394:53] nutrição infinita, vocês escutaram ele
[394:55] falando de proposta, o gabriel também tava aí
[394:57] o tempo todo, vocês escutaram ele falando de
[394:59] proposta, vocês escutaram ele falando de um monte
[395:01] de coisa ali, que ele poderia
[395:03] realmente fazer, tá
[395:05] então, ou o que ele faz
[395:07] com os clientes dele pra manter aquela
[395:09] nutrição infinita, então
[395:11] quando a gente pega isso, e quando a gente
[395:13] entende essa nutrição infinita, eu preciso
[395:15] primeiro explicar pra vocês
[395:17] da onde que eu tirei isso
[395:19] tem um cara que ele chama Joey Girard, que
[395:21] ele é um dos melhores vendedores do mundo,
[395:23] ele vendeu 1435 carros em
[395:25] 1980, época que não tinha celular
[395:27] CRM, não tinha nada do tipo, não tinha tecnologia
[395:29] e ele vendeu aquilo lá sozinho
[395:31] porque ele tinha um bom relacionamento com os clientes
[395:33] e ele tinha uma metodologia de vendas muito boa, acabou
[395:35] e a grande
[395:37] insight da metodologia de vendas dele é que ele
[395:39] nunca desistia do cliente dele, ele mandava
[395:41] sei lá, acho que 3 milhões de cartões
[395:43] de visitas por ano pros clientes dele
[395:45] então o que eu quero passar pra vocês
[395:47] em uma visão que eu preciso
[395:49] passar pra vocês, pra que vocês entendam
[395:51] essa metodologia de nutrição infinita
[395:53] se você
[395:55] não entender o que é uma nutrição de
[395:57] verdade
[395:59] o primeiro ponto
[396:01] disso aqui já vai se acabar
[396:03] a maioria das pessoas acredita que a
[396:05] nutrição é você ficar
[396:07] ai conseguiu conferir a proposta
[396:09] e ai você viu tal coisa e ai você viu
[396:11] o resultado de tal não sei o que
[396:13] e ai você faz um monte de coisa
[396:15] e ai você acredita que a nutrição
[396:17] é literalmente você fazer essas perguntas chatas
[396:19] você acredita que a nutrição é você
[396:21] ficar fazendo um follow up de qualquer jeito
[396:23] como ia pra fazer um follow up
[396:25] é você fazer outras coisas ali
[396:27] ou só chamar o seu cliente ou um script
[396:29] que você fez no GPT, isso não é nutrição
[396:31] nutrição é você
[396:33] nutrir uma pessoa
[396:35] com algo que
[396:37] vai fazer bem pra ela
[396:39] então essa nutrição
[396:41] é você sempre entregar
[396:43] coisas de qualidade que vai fazer com que
[396:45] o seu cliente
[396:47] antes mesmo de seu cliente
[396:49] ele já tem um conteúdo bom
[396:51] que ele já tenha ali coisas boas
[396:53] sobre você
[396:55] ele já tem coisas ali que ele
[396:57] fale sobre você que
[396:59] cara bacana isso
[397:01] legal isso aqui que
[397:03] o Gustavo tá me apresentando
[397:05] legal isso aqui que
[397:07] sei lá
[397:09] esse insight que o Gustavo me deu
[397:11] o quanto que ele tá me fazendo
[397:13] evoluir antes mesmo de eu comprar dele
[397:15] então certas coisas
[397:17] eu vou nutrir o meu cliente
[397:19] eu vou buscar soluções pra problemas dele
[397:21] que ele nem pediu pra mim buscar
[397:23] e aí eu trago esse
[397:25] conceito de nutrição porque que eu
[397:27] falo sobre isso
[397:29] hoje tá hoje
[397:31] o mercado
[397:33] ele tá parado em aquisição de
[397:35] hoje o mercado ele tá
[397:37] maluco em aquisição de
[397:39] hoje o mercado ele tá
[397:41] totalmente louco
[397:43] em aquisição de novos leads
[397:45] só que ninguém tá trabalhando a base
[397:49] deixa eu fazer uma pergunta pra vocês
[397:51] se você tivesse um cliente
[397:53] e aí esse cliente
[397:55] você tem uma proposta de 100 mil reais
[397:57] aberta com ele
[397:59] e aí essa proposta que você tem de 100 mil reais
[398:01] aberta com ele
[398:03] você sabe que se você fizer um macol por semana
[398:05] com ele
[398:07] dentro de um ano você vai vender pra esse cliente
[398:09] você faz um macol por mês
[398:11] com esse cliente e aí dentro
[398:13] de um ano você vai vender 100 mil reais
[398:15] pra ele
[398:17] se reunir com ele
[398:19] uma vez por mês pra daqui um ano
[398:21] você vender 100 mil pra ele
[398:23] algum de vocês faria isso
[398:25] algum de vocês se dedicaria nisso
[398:27] olha qual o ponto
[398:31] a maioria de vocês
[398:33] tem isso de oportunidade você só não enxabe
[398:35] porque
[398:37] deixa eu falar uma coisa pra você a maioria
[398:39] dos seus leads eles não vão comprar no primeiro momento
[398:41] eles vão comprar no ciclo de compra que as vezes
[398:43] eles vão demorar um ano
[398:45] 12 meses
[398:47] eu vou falar uma coisa pra vocês
[398:49] o título ele fala uma coisa interessante
[398:51] sabe quando que eu descarto o meu lead
[398:53] quando ele fala assim, Gustavo, eu não tenho interesse
[398:55] nenhum de fechar com você
[398:57] eu não tenho interesse na sua metodologia
[398:59] não tenho interesse no que você me fornece
[399:01] qualquer outra objeção que ele fala
[399:03] eu tenho interesse mas agora não é momento
[399:05] qualquer outro motivo que ele não feche
[399:07] mas ele indique que ele gostou do que ele viu
[399:09] eu vou continuar essa nutrição infinita
[399:11] com esse cara
[399:13] e aí sabe o que significa essa nutrição infinita
[399:15] ali um follow up infinito com ele
[399:17] até eu conseguir vender alguma coisa pra ele
[399:19] e aí o que que vai acontecer
[399:21] você vai abrir no teu CRM
[399:23] as vendas que vão acontecendo no curto prazo
[399:25] elas vão te sustentando
[399:27] mas o que vai realmente te deixar rico
[399:31] é o seu processo de nutrição
[399:33] é quantos clientes você consegue colocar dentro do seu CRM
[399:35] quanto você consegue nutrir esses clientes
[399:37] o que realmente deixa
[399:39] qualquer pessoa muito rica
[399:41] não é nem LTV tá
[399:43] não é isso porque o LTV
[399:45] é quando o seu cliente já comprou de você
[399:47] eu tô falando antes do seu cliente comprar de ti
[399:49] olha que louco isso
[399:51] antonio pega essa visão
[399:53] se você tem ali, sei lá, 10, 15, 20 milhões
[399:55] em propostas
[399:57] ou se você tem não só esses 10, 15, 20 milhões
[399:59] em propostas
[400:01] mas você tem todos esses clientes pra você
[400:03] nutrir e você se reúne com eles
[400:05] mensalmente
[400:07] a chance deles fecharem é muito alto
[400:09] porque eles continuam se reunindo com você
[400:11] em algum momento eles vão fechar com você
[400:13] agora, se você precisa fechar
[400:15] olha que louco isso
[400:17] é muito difícil você fechar
[400:19] um milhão de reais
[400:21] em um mês
[400:23] mas em um ano não é
[400:25] porque vamos supor que
[400:27] tá, beleza, vamos num produto um ticket um pouco mais baixo
[400:31] eu precisaria um milhão dividido por 12
[400:33] e dá quanto mais ou menos?
[400:35] dá uns 80 mil
[400:37] eu precisaria ali de 8 bons clientes
[400:39] novos
[400:41] 8 boas reuniões que eu esteja negociando
[400:43] tá
[400:45] um valor acima de 10 mil reais
[400:47] e eu fosse vender isso de um período de um ano
[400:49] cara
[400:51] pra me vender um milhão
[400:53] eu não preciso vender instantaneamente
[400:55] eu preciso nutrir esse cliente até que eu venda
[400:57] e aí um dos pontos que eu falo pra vocês é
[400:59] hoje o meu CRM
[401:01] ele tá, eu tenho dois CRM
[401:03] eu tenho um CRM atual
[401:05] que é o que eu faço e eu tenho um CRM antigo
[401:07] de lá
[401:09] o meu CRM antigo eu tenho uns 4 milhões de propostas
[401:13] sabe por que eu vendo todo dia?
[401:15] porque eu não vou vender esses 4 milhões de uma vez
[401:17] esses 4 milhões vão vir pra Cadim
[401:19] e eu não tenho problema com isso
[401:21] a maior parte do problema das pessoas
[401:23] não é o quanto elas querem faturar
[401:25] não é o objetivo que elas têm
[401:27] não é a meta que elas têm
[401:29] é o tempo que elas colocam pra essa meta
[401:31] gente
[401:33] eu vou falar uma coisa pra vocês
[401:35] é muito difícil
[401:37] mesmo
[401:39] que você enriqueça nesse mercado de prestação de serviços
[401:41] ou vendas B2B ou qualquer coisa que seja
[401:43] assim ó
[401:45] rápido, empresas grandes
[401:47] elas levam 2, 3, 4, 5, 10 anos pra
[401:49] realmente consolidar
[401:51] e dar um resultado bom
[401:53] significa que
[401:55] você não vai ganhar dinheiro durante o tempo
[401:57] não, mas significa
[401:59] que você precisa se preocupar com longo prazo
[402:01] se você não nutre um cliente
[402:03] que entrou hoje dentro do seu funil
[402:05] e você não tem um processo pra você nutrir
[402:07] esse cara infinitamente
[402:09] ou seja, quanto mais distante o cara
[402:11] tá de comprar de você, significa que mais educação
[402:13] ele precisa
[402:15] se eu não nutro esse cara infinitamente
[402:17] o que eu tô fazendo, eu tô matando a minha empresa a longo prazo
[402:19] agora penso numa empresa
[402:21] que tem 100 milhões de reais
[402:23] em oportunidades
[402:25] e ela sabe que depois de um ano
[402:27] ela consegue sempre fechar 40% dessas vendas
[402:29] ela garante
[402:31] 40 milhões de reais
[402:33] e aí a maioria das pessoas
[402:35] tá perguntando cara
[402:37] como eu posso adquirir mais leads pra vender mais
[402:39] você não cuida nem dos leads que você tem
[402:41] quantos clientes falaram pra você
[402:43] tal mês eu vou comprar
[402:45] tal mês eu conseguiria e você nunca mais chamou esse cara
[402:47] você nem lembra o número desse cara
[402:49] você nem fala com esse cara
[402:51] você nem tem anotado nada sobre esse cara
[402:53] você nunca chamou esse cara
[402:55] você não fez esse cara, você não continuou conversando com ele
[402:57] você não continuou criando o relacionamento
[402:59] você não continua criando
[403:01] você não chega esse mês
[403:03] você fez a apresentação pra algum outro cara
[403:05] vender pra você
[403:08] se você não nutre o seu cliente
[403:10] que gostou da sua apresentação
[403:12] mas às vezes ele não estava no momento de compra
[403:14] parabéns você acabou de preparar alguém
[403:17] pro teu concorrente
[403:19] ou pra alguém do mercado
[403:21] porque ele não vai comprar de você
[403:23] porque senão trabalha esse cara
[403:25] então quando a gente traz
[403:27] esse conceito de nutrição infinita
[403:29] é o que realmente vai te deixar muito rico
[403:31] eu juro pra vocês, é impossível você abrir
[403:33] 10 milhões de propósito e sua empresa
[403:35] não faturar um milhão no ano
[403:37] é impossível
[403:39] porque você precisa trabalhar esses clientes
[403:41] beleza
[403:43] então quando a gente parte
[403:45] pra esse ponto, o que que o Joey fazia
[403:47] o que que eu acredito que você deve fazer
[403:49] primeiro transformar reuniões
[403:51] em um verdadeiro chegar junto
[403:53] reuniões com clientes não devem ser rituais vazios
[403:55] monótonos mas sim oportunidades
[403:57] para energizar, unir pessoas
[403:59] de um objetivo comum e bla bla bla
[404:01] cara eu vou resumir isso aqui
[404:03] depois vocês leiam um bate-papo
[404:07] se o cliente não comprou de você
[404:09] você fica puto com o teu cliente
[404:11] você sai da reunião e fala
[404:13] que merda
[404:15] ou você sai na reunião com o próximo planejamento
[404:17] pra você conversar com o seu cliente
[404:19] deixa eu falar uma coisa pra vocês
[404:21] lembra aquela reunião que eu falei que eu tive R8
[404:23] pra ver um contrato muito alto
[404:25] imagina na segunda reunião
[404:27] onde ele não aceitou a primeira proposta
[404:29] que cara chato
[404:31] queria muito ter vendido
[404:33] eu não falei cara
[404:35] pode marcar outro bate-papo pra gente falar disso
[404:37] opa tudo bem cara
[404:39] eu queria um relacionamento com você
[404:41] e aquele problema lá que você me falou
[404:43] resolveu
[404:45] e eu ligo pro meu cliente
[404:47] eu falo com ele, eu marco reuniões
[404:49] eu marco calls, quando não tenho nada pra fazer
[404:51] eu chamo o cara e falo assim cara
[404:53] lembra que a gente tinha marcado um horário agora
[404:55] mas eu consigo porque
[404:57] eu tenho uma reunião entrei desse cara
[404:59] e aí ele entra na reunião comigo
[405:01] e aí eu vou fazendo isso infinitamente
[405:03] aí o que que acontece
[405:05] eu queria um relacionamento com esse cara
[405:07] então a sua reunião de vendas
[405:09] ela não tem que ser só uma reunião de vendas
[405:11] pra você vender o seu produto
[405:13] você tem que vender o seu relacionamento com esse cliente
[405:15] algum de vocês já teve algum cliente
[405:17] que vocês viraram amigo do seu cliente
[405:19] algum de vocês já tiveram algum cliente
[405:21] que vocês viraram amigo do seu cliente
[405:23] vocês conseguiram falar com esse cliente
[405:25] ou continuam falando com esse cliente até hoje
[405:27] a maioria dos atuais
[405:29] e isso acontece
[405:31] agora imagina se você começa esse processo de virar amigo do cara
[405:33] antes mesmo
[405:35] dele comprar de você
[405:37] antes mesmo dele
[405:39] executar uma compra com você
[405:41] sabe qual que vai ser o maior desejo
[405:43] desse cara depois que você se tornar uma autoridade pra ele
[405:45] vai ser um desejo de comprar de ti
[405:47] porque você agrega tanto valor na vida dele
[405:49] que ele nunca vai contratar outro profissional
[405:51] que não seja você
[405:53] obviamente se você se posicionar como um profissional
[405:55] você não vai chamar esse cara pra jogar futebol com você
[405:57] você realmente vai ajudar ele
[405:59] na sua área de genialidade
[406:01] você sempre vai conversar com ele da sua área de genialidade
[406:03] mas manter um certo relacionamento
[406:05] fechou?
[406:07] então isso aqui
[406:09] pratica a espionagem de magia branca
[406:11] antes do follow up
[406:13] cara porque magia branca porque o girarde
[406:15] ele usa esse termo aqui
[406:17] então literalmente ele não quer que você use
[406:19] isso pra manipular o seu cliente
[406:21] ele quer que você utilize isso
[406:23] realmente pra fazer com que seu cliente
[406:25] fique encantado
[406:27] com o que você tem pra fazer com ele
[406:29] fechou?
[406:31] então para manter um follow up infinito você precisa de
[406:33] informações precisas e continuas
[406:35] a agência deve encarar cada cliente
[406:37] como um projeto de pesquisa
[406:39] olha que interessante isso
[406:41] se eu pego esse cliente
[406:45] vamos lá
[406:47] vamos lá
[406:49] o cliente que ele não fechou comigo
[406:51] ou que ele que eu vou fazer reunião
[406:53] com ele
[406:55] eu posso transformar ele em um objeto de pesquisa
[406:57] qual que é o objeto de pesquisa?
[406:59] qual que é a minha intuito?
[407:01] cara eu descobri o máximo de informações dele
[407:03] e descobri como que eu posso
[407:05] e usando essas informações pra me manter o relacionamento com ele
[407:07] infinitamente
[407:09] então o que que eu vou fazer?
[407:11] cara eu vou descobrir quem que manda na empresa
[407:13] eu vou descobrir qual problema ele tem com qual funcionário
[407:15] eu vou descobrir qual problemas ele tá passando ali
[407:17] no setor que ele realmente pretende me contratar
[407:19] eu vou descobrir várias outras coisas
[407:21] vários outros pontos que eu vou usar
[407:23] durante dois encontros
[407:25] durante um ano inteiro
[407:27] durante várias vezes que eu vou ligar pra esse cara pra perguntar se ele tá bem
[407:29] então
[407:31] você precisa espionar seu cliente
[407:33] sabe qual que é a importância de um CRM
[407:35] por exemplo?
[407:37] as pessoas usam CRM de maneira totalmente equivocada
[407:39] totalmente errada
[407:41] vou colocar e vou ficar passando o lead de um lado pro outro
[407:43] não
[407:45] é só isso
[407:47] para você buscar oportunidade
[407:49] seu CRM é uma máquina de lead
[407:51] e leads aquecidos
[407:53] então o que você precisa fazer dentro do seu CRM
[407:55] esse cara falou que tava com esse
[407:57] e esse problema e ele ia resolver na quinta-feira
[407:59] e aí meu amigo deu certo
[408:01] de resolver aquele problema na quinta-feira
[408:03] às vezes nem tem nada a ver com o que você vai fazer com ele
[408:05] mas só de você ter aquilo
[408:07] ele vai entender que você se preocupou
[408:09] e que você muitas vezes fez uma pergunta
[408:11] que nem esposa desse cara fez pra ele
[408:14] nem os filhos desse cara fez pra ele
[408:16] nem o que esse cara
[408:18] nem a família desse cara fez essa pergunta pra ele
[408:20] e você fez porque?
[408:22] porque você colocou todas as informações dele
[408:24] isso sim é para o CRM
[408:26] isso sim é você ter as informações do lead
[408:28] isso sim é você preparar
[408:30] então o objeto de pesquisa
[408:32] como que esse cliente vai se comportar nos próximos tempos
[408:34] se eu literalmente entender tudo
[408:36] sobre ele
[408:38] e eu usar isso como nutrição
[408:40] sem querer você cria um amizade com os clientes
[408:42] em algum caso e não pode ser sem querer
[408:44] tem que ser intencional
[408:46] e aí é o que a gente fala do triângulo do amor
[408:48] aplicado aos negócios
[408:50] ou seja a fórmula de relacionamento finito
[408:52] para que a relação
[408:54] com empresários perdure infinitamente
[408:56] o relacionamento comercial deve espelhar
[408:58] três elementos
[409:00] primeiro a centelha química
[409:02] ou seja a conexão inicial entusiasmo
[409:04] multo de trabalharmos juntos
[409:06] cara se eu não fecho com o cara
[409:08] olha o que eu vou fazer com ele
[409:10] eu vou ficar o tempo todo
[409:12] tá o tempo todo
[409:14] falando o que para esse cara
[409:16] eu vou ficar o tempo todo falando a seguinte
[409:18] oi tudo bem cara vamos fazer o seguinte
[409:20] pô deixa eu entender
[409:22] eu quero trabalhar com você
[409:24] tenho certeza que a nossa parceria vai trazer bons frutos
[409:26] e não sei o que eu sempre vou me posicionar
[409:28] dentro das reuniões
[409:30] dentro de qualquer contexto dentro dos follow ups
[409:32] com o meu entusiasmo
[409:34] de trabalhar junto com esse cara
[409:36] com meu entusiasmo
[409:38] realmente trabalhar
[409:40] com esse cara e fazer com que o nosso trabalho
[409:42] ele
[409:44] seja algo que já esteja apreciado na mente dele
[409:46] então olha que louco isso
[409:48] muitas vezes eu falo para o cara assim
[409:50] cara a gente vai trabalhar junto a gente vai fazer isso
[409:52] a gente vai fazer aquilo quando a gente fizer isso
[409:54] a consequência é essa e blá blá blá blá
[409:56] e aí eu vou trazendo esse relacionamento junto
[409:58] com esse cara
[410:00] e aí esse relacionamento que eu vou trazendo junto com ele
[410:02] eu vou
[410:04] mensagem esse cara quer muito
[410:06] exatamente
[410:08] exatamente então
[410:10] quando eu vou me posicionando assim esse cara
[410:12] ele já também entendeu que ele vai ter
[410:14] um entusiasmo de trabalhar junto comigo
[410:16] também
[410:18] interesses incomuns agência e empresária
[410:20] deve ter metas de negócios muito bem
[410:22] alinhadas então a meta desse cara é tal
[410:24] e a sua meta com ele também é tal
[410:28] e por mais que não aconteça agora
[410:30] vocês podem fazer a nutrição e aí como que
[410:32] tá o planejamento pra tal coisa
[410:34] e aí como tá o planejamento pra tal etapa
[410:36] como tá acontecendo tal coisa como tá acontecendo
[410:38] aquilo lá pelo outro aquele outro
[410:40] e por aí vai beleza
[410:42] então o interesse
[410:44] em comum a química que vocês vão ter
[410:46] a vontade que vocês vão ter de
[410:48] ficar junto o interesse
[410:50] em comum que vocês têm de fazer a empresa
[410:52] crescer é literalmente
[410:56] o primeiro polo
[410:58] pra vocês conseguirem iniciar esse processo
[411:00] de relacionamento finito e aí vem
[411:02] a parte tá a intenção
[411:04] de processar e comunicar o segredo do follow up
[411:06] esse é o ponto mais importante
[411:08] a agência deve ter
[411:10] uma dedicação
[411:12] inabalável com a comunicação
[411:14] continua
[411:17] eu demonstro que eu quero
[411:19] e que eu estou entusiasmado pra trabalhar
[411:21] com esse cara
[411:23] isso na nutrição
[411:25] eu demonstro pra esse cara
[411:27] que não só trabalhar com ele mas a gente
[411:29] tem um objetivo em comum muito forte
[411:31] e eu continuo com esse
[411:33] mesmo sentimento
[411:35] e passando esse mesmo sentimento pra ele durante
[411:37] um ano
[411:39] qualquer probabilidade de eu não fechar com esse cara
[411:41] é muito baixo
[411:43] é muito baixo
[411:45] é muito difícil cara
[411:47] é muito difícil não fechar com esse cliente
[411:49] então você vai seguir nesse triângulo do amor aplicado
[411:51] realmente pra pro teu negócio
[411:53] e sabe qual que é o problema? de novo que eu vou bater?
[411:55] aí um cara
[411:57] vai pegar o cloud e vai falar assim
[411:59] nossa deixa eu gerar um prompt
[412:01] deixa eu gerar um agente
[412:03] que vai fazer isso aqui de forma automática
[412:05] cara ninguém vai ligar pro teu cliente
[412:07] ninguém vai
[412:09] entrar numa qual o seu cliente do nada
[412:11] nenhuma ia vai fazer isso
[412:13] e é o que eu estou falando
[412:15] e as vão otimizar o seu banco de dados
[412:17] às vezes ela vai te avisar
[412:19] que tá na hora de você fazer um relacionamento com esse cara
[412:21] que tá na hora de você nutrir esse cara novamente
[412:23] ou várias outras coisas
[412:25] mas
[412:27] nada vai substituir o grande dor falando com esse cara
[412:29] nada vai substituir o cara
[412:31] criando um relacionamento com esse cliente
[412:33] então você usa IA pra potencializar
[412:35] e pra tua cabeça não ficar ocupada
[412:37] com tanto de nutricão que você tem que fazer
[412:39] e o resto
[412:41] você vai fazendo conforme você precisar
[412:43] fechou? então o resto
[412:45] você vai literalmente fazendo de forma humanizada
[412:47] pra que esse cara te veja como
[412:49] referência você consiga
[412:51] vender pra ele beleza
[412:53] até que tudo ok?
[412:59] até que tudo ok?
[413:01] conforme pra mim quando eu bebo uma água
[413:05] boa
[413:12] ok?
[413:14] sim sim beleza
[413:16] então bora usar
[413:18] tá, utilize a comunicação consciente
[413:20] e a audição ativa
[413:22] gente na era digital
[413:24] o que mais aconteceu
[413:26] não principalmente pós-pandemia
[413:28] principalmente
[413:30] literalmente pós-pandemia
[413:32] o que que aconteceu dentro
[413:34] do digital
[413:36] e essa pergunta do candido
[413:38] representa exatamente isso que eu vou falar agora
[413:40] mostra modelos de mensagem
[413:42] exemplos e não sei o que é
[413:44] sabe qual que é o grande problema?
[413:46] as pessoas não criam mais relacionamentos
[413:48] é tudo
[413:52] uma mensagem
[413:54] ou um script
[413:56] ou um áudio
[413:58] preparado
[414:00] ou alguma coisa que
[414:02] sei lá
[414:04] as pessoas não têm
[414:06] mais um nível de comunicação
[414:08] onde elas vão escutar e vão entender
[414:10] a situação do seu cliente
[414:12] pra você saber o que você vai fazer de
[414:14] nutrição não é algo que você
[414:16] simplesmente vai pegar e vai
[414:18] deixa eu elaborar os modelos de mensagem
[414:20] que eu vou fazer de nutrição
[414:22] tal mês eu vou falar disso
[414:24] na páscoa vou dar feliz páscoa
[414:26] não, não é isso
[414:28] dentro da conversa que eu tive com ele
[414:30] eu faço uma escutativa
[414:32] eu literalmente estou consciente
[414:34] eu faço o que?
[414:36] eu anoto depois pra mim não esquecer
[414:38] e nessas anotações
[414:40] depois eu revisito essas anotações
[414:42] e a única coisa que eu tenho
[414:44] é o dia do follow up
[414:46] eu vou ler as informações
[414:48] eu vou perguntar sobre isso
[414:50] sobre essa informação que ele me falou naquele dia
[414:52] sobre essa informação
[414:54] que ele me falou naquele momento
[414:56] e aí eu consigo trazer isso
[414:58] de uma maneira aonde
[415:00] eu consigo fluir naturalmente
[415:02] eu consigo fazer com que esse cliente
[415:04] se nutra naturalmente comigo
[415:06] então
[415:08] o que eu preciso que vocês entendam
[415:10] vamos lá, vamos supor que eu estou
[415:12] vendendo agora pro João Carvalho
[415:14] pro João Carvalho eu faço uma venda pra ele
[415:16] e essa venda que eu fiz pra ele
[415:18] eu faço o seguinte
[415:20] eu literalmente
[415:22] eu literalmente
[415:24] o João entendi, fiz a primeira reunião
[415:26] ele não comprou de mim e tudo bem
[415:28] e aí eu vou no treino durante 12 meses
[415:30] uma conversa com ele
[415:32] uma vez por mês eu entro em qual com ele
[415:34] e falo sobre um assunto que ele falou
[415:36] aí dentro dessa cala eu já pego vários outros assuntos
[415:38] pra preencher meu CRM e ter assunto pra falar
[415:40] ele falou, pô, a gente já tá no momento de fechar
[415:42] vamos fazer, vamos não sei o que
[415:44] quando eu sentir que ele tá no momento eu vou agressivar
[415:46] de novo pra fechar
[415:48] mas se ele não tá no momento ainda eu vou continuar nutrindo
[415:50] só que essa nutrição
[415:52] e é importante que vocês entendam isso
[415:54] vocês podem ler todo esse processo depois
[415:56] mas essa nutrição ela é muito mais
[415:58] personalizada do que necessariamente
[416:00] nossa, eu preciso mandar essa mensagem
[416:02] essa mensagem assim que faz
[416:04] assim que faz uma nutrição infinita
[416:06] você vai ficar
[416:08] você vai comprogar um agente pra ficar falando
[416:10] que esse cara o tempo todo, não
[416:12] o objetivo do vendedor é vender
[416:14] o objetivo do vendedor
[416:16] é realmente entrar em qual
[416:18] expor, criar o relacionamento com o cliente
[416:20] cara, a maioria de vocês são vendedores
[416:22] que não vendem muito simplesmente porque vocês
[416:24] não assumem a responsabilidade
[416:26] da sua própria função
[416:28] a maioria do comercial das pessoas
[416:30] elas não vendem muito porque eles não assumem
[416:32] a responsabilidade de um comercial
[416:34] acho que tudo é marketing, acho que tudo é
[416:36] sei lá
[416:38] cara, quantas vezes você ligou pra seu cliente
[416:40] pra ver como que ele tá
[416:42] quantas vezes você ligou pra seu cliente
[416:44] pra fazer aquela nutrição com ele
[416:46] pra trazer uma oportunidade, pra convidar ele pra um evento
[416:48] pra convidar ele pra uma aula, pra convidar ele pra alguma coisa que seja
[416:50] que você acha que faz sentido pra esse cliente
[416:52] se você não faz isso constantemente
[416:54] não tem como tu ter um resultado
[416:56] bom, não tem como tu ter um resultado incrível
[416:58] beleza
[417:00] então, dentro dessa
[417:03] parte de nutrição, o que você precisa entender
[417:05] criar esse relacionamento e fazer essa nutrição infinita
[417:07] e aí eu passo esses tópicos
[417:09] aqui, e muitas das vezes
[417:11] vocês vão ignorar esse tópico, mas cara
[417:13] é muito
[417:15] importante que vocês façam isso
[417:17] é muito importante que vocês
[417:19] mantem um CRM atualizado
[417:21] é muito importante que vocês anotem todas as informações
[417:23] possíveis clientes que entraram em contato com vocês
[417:25] porque se ele não comprar de mim
[417:27] em algum momento, ele vai comprar
[417:29] e agora, e aí vem um ponto que eu
[417:31] falo pra vocês, cara
[417:33] se o cliente não compra de vocês
[417:35] e você continua no trem dele infinitamente
[417:37] quando ele comprar
[417:39] se ele for comprar o
[417:41] exatamente produto ou serviço que você
[417:43] oferece, ele vai comprar de título, não perde
[417:45] esse cara pro mercado
[417:47] ou tu acha, você que é dono de agência
[417:49] que você vende tráfego pago
[417:51] e o cliente que você fez a união, ele nunca vai contar
[417:53] da tráfaga o pago
[417:55] talvez ele realmente não tava no momento
[417:59] e quando ele estiver no momento, quem vai estar lá
[418:01] vai ser você ou você ou outro cara
[418:03] então você plantou o terreno pra outro cara fechar
[418:05] você fez a nutrição pra outra pessoa
[418:07] fechar pra você?
[418:11] não tem como
[418:13] isso daí é loucura, isso daí é insanidade
[418:15] uma vez que o lead entra no teu funil
[418:17] ele só
[418:19] sai se ele te recusar completamente
[418:21] eu não quero fechar com você
[418:23] eu não gostei disso
[418:25] não serve pra minha empresa, obrigado
[418:27] aí você exclui esse cara
[418:29] fora isso você vai nutrir esse cara
[418:31] e aí
[418:33] é você se mostrar vulnerável
[418:35] às vezes
[418:37] você vai ter alguma falha ou outra
[418:39] junto com o seu cliente
[418:41] eu ia fazer reunião com você e não vou conseguir
[418:43] cara, seja sincero
[418:45] fala cara, não consegui me enroleia
[418:47] que aconteceu isso, isso, isso
[418:49] admitiu um erro, também queria conexão
[418:51] admitir que errou
[418:53] admitir que teve alguma falha, também queria conexão
[418:55] e essa conexão
[418:57] faz com que você venda muito
[418:59] faz com que você tenha relacionamento ao longo prazo
[419:01] então quando a gente parte dessa
[419:03] parte de nutrição infinita
[419:05] anota isso aí
[419:07] cara, pegarei todos os clientes
[419:09] que eu tiver
[419:11] e todos os clientes que eu tenho
[419:13] eu farei no mínimo
[419:15] uma reunião por mês
[419:17] que ainda estão pra fechar
[419:19] que eu ainda tenho proposta aberta
[419:21] por que? porque eu não quero que eu perco
[419:23] oportunidade de realmente fechar com esses caras
[419:25] eu não quero perder a oportunidade
[419:27] de perder o relacionamento e ele fechar com outra pessoa
[419:29] aqui você mandou muito bem
[419:31] aqui você fez os bagulhos
[419:33] acontecer
[419:35] fechou? então
[419:37] vou revisar toda a minha agenda, a revisa agenda
[419:39] abre um CRM
[419:41] coloca essas informações lá, coloca esse lid de lá
[419:43] vai marcando reunião, vai conversando com esses clientes
[419:45] algum momento eles vão fechar com você
[419:47] pô, não fechou um produto principal
[419:49] deixa eu vender um, dá um céu aqui
[419:51] e aí eu chamo ele pra uma outra reunião
[419:53] pra eu vender um só, dá um céu
[419:55] e aí eu vou vendendo várias outras coisas
[419:57] cara, não sei o que você vai fazer
[419:59] mas venda pra esse cara
[420:01] venda pra esse cara a ponto de
[420:03] se esse cara não comprar de você
[420:05] pelo menos ele vai te indicar pra alguém
[420:07] se esse cara não comprar de você
[420:09] pelo menos alguma indicação ele vai te passar
[420:11] cara, se você tá fazendo
[420:13] um vídeo a três meses, você não consegue vender pra ele
[420:15] mas ele mantém um relacionamento
[420:17] com você, o que que impediu você falar oi, tudo bem
[420:19] pô, eu tô querendo bater minha meta, você tem três amigos empresários
[420:21] aí pra mim indicar
[420:23] qualquer chance dele não te mandar
[420:25] é muito difícil cara, ele te manda
[420:27] ele vai te mandar
[420:29] ele vai te enviar isso
[420:31] e isso vai fazer com que você venda
[420:33] fechou? isso vai fazer com que
[420:35] você venda, isso vai fazer com que isso
[420:37] aconteça, isso vai fazer com que o teu lid
[420:39] ele compre de você
[420:41] o lid infinitamente é uma obrigação que você tem
[420:43] porque você pagou
[420:45] seja com o tempo, seja com o dinheiro
[420:47] a aquisição desse lid
[420:49] e se você não trabalha ele o tempo todo
[420:51] o que que acontece com você, você perde
[420:53] oportunidade
[420:55] você realmente perde a oportunidade
[420:57] de vender pra esse cara
[421:02] ou você preparou esse cara pra comprar de outras pessoas
[421:04] então
[421:06] de 40 a 50% se você for um
[421:08] enclosure extremamente bom
[421:10] das suas vendas, 40 a 50%
[421:12] das suas vendas
[421:14] elas vão vir nas primeiras uniões
[421:16] nos primeiros momentos, isso se for muito bom
[421:18] sua ferda estiver muito alinhada
[421:20] suas uniões estiverem muito alinhadas
[421:22] seu lid for qualificado e seu nível de consciência
[421:24] for bom, você vai ter 50% de conversão
[421:26] no máximo
[421:28] só que você consegue chegar a 75% de conversão
[421:30] como você chega nisso
[421:32] trabalhando nos outros 35% ao longo prazo
[421:34] que representam milhões de reais
[421:38] e se você for um closer mediano
[421:40] eu acredito que 50% das suas vendas
[421:42] vão acontecer no longo prazo
[421:44] então, eu preciso que vocês entendam
[421:47] que cada vez que você
[421:49] sai de uma reunião com o cliente sem vender
[421:51] e você não tem um processo de nutrição
[421:53] e você não tem um processo
[421:55] aonde você vai criar esse relacionamento
[421:57] aonde você vai criar esses tópicos
[421:59] aonde você vai fazer qual que é o cliente
[422:01] você está perdendo o dinheiro
[422:03] você está jogando seu tempo e seu dinheiro fora
[422:05] porque você literalmente está perdendo
[422:07] a maior parte dos seus volumes de vendas
[422:13] o lid que entrou no funil é semente interno
[422:15] é só regar que uma hora vai
[422:17] exatamente
[422:19] então o lid entrou dentro do seu funil de vendas
[422:21] cara, ele não sai de lá
[422:23] a não ser que ele peça pra sair
[422:25] ele não pediu pra sair, ele não sai de lá
[422:27] fechou?
[422:29] pessoal, de verdade mesmo
[422:31] eu consegui acabar o evento
[422:33] por incrível que pareça
[422:35] 52 minutos antes do previsto
[422:37] e realmente consegui
[422:39] entregar o conteúdo que eu queria entregar
[422:41] vocês têm alguma dúvida?
[422:43] eu quero o feedback de vocês
[422:45] eu gostaria que vocês abrissem o microfone
[422:47] tirasse as dúvidas de vocês
[422:49] algum de vocês tem alguma dúvida
[422:51] alguma feedback, alguma coisa que vocês querem perguntar
[422:53] porque realmente
[422:55] eu acho que esse conteúdo aqui
[422:57] eu acho que ia ser 8 horas
[422:59] mas acabou que deu tempo de fazer
[423:01] um pouquinho menos
[423:03] quem quiser fazer pergunta
[423:05] pode abrir o microfone ali, perguntar pra gente
[423:07] gente, de verdade mesmo
[423:09] essas perguntas
[423:11] esse foi o último capítulo ali
[423:13] esse foi o último módulo
[423:15] eu quero agradecer a presença de todos vocês
[423:17] eu realmente fiz isso aqui pra
[423:19] atualizar alguns conteúdos que eu tenho
[423:21] realmente atualizar algumas coisas que eu tenho
[423:23] mas
[423:25] eu não ia deixar de fazer uma entrega boa aqui
[423:27] e eu espero que essa entrega tenha sido boa pra vocês
[423:29] mas eu quero que vocês entendam
[423:31] que esse é um conteúdo executivo
[423:33] ou seja, que é um conteúdo que você precisa executar
[423:35] não só assistir
[423:37] não é algo que você vai jogar na manhã
[423:39] é algo que você vai realizar
[423:41] então aqui dentro daqui você teve
[423:43] várias tarefas, várias coisas que você pode fazer
[423:45] dentro do teu funil de vendas
[423:47] e eu quero que vocês realizem isso
[423:49] pessoal que é da minha formação
[423:51] que é da formação, amanhã a gente ainda tem
[423:53] mais umas 3 horas
[423:55] de conteúdo somente pra vocês, exclusivo pra galera
[423:57] que é da formação
[423:59] enfim, quando a gente bate
[424:01] nisso e quando eu bato nesse tipo de conteúdo
[424:03] cara, de verdade mesmo
[424:05] você precisa pra estruturar do produto e vender
[424:07] isso aqui
[424:09] tem tudo que você precisa pra você fazer essa venda
[424:11] tem tudo que você precisa pra você fazer
[424:13] o passo a passo e você ter algum resultado
[424:15] você não vai ter resultado se você não executar
[424:17] não, é a formação
[424:19] é uma formação que a gente tem no Alco
[424:21] formação que a gente tem no Alzinho
[424:23] ali
[424:25] é 15 mil reais pra quem quiser saber
[424:27] isso daí é a formação no escondo não
[424:29] é uma formação de 15 mil que a gente tem
[424:31] por ano que a galera participa
[424:33] fechou que há uns conteúdos um pouco mais
[424:35] avançados ali
[424:37] é em grupo também, mas é um conteúdo um pouco mais avançado
[424:39] acho que tem 20 pessoas lá dentro
[424:41] da formação, 30 pessoas
[424:43] alguma coisa assim
[424:45] excelente conteúdo, diversas ideias
[424:47] e ajuste aqui que querem implementar e colocar em curso
[424:49] boa
[424:51] é pergunta nesse tópico que vou
[424:53] precisaria assistir mais tarde, como se separamentalmente
[424:55] pra prospectar sete horas seguidas
[424:57] cara, se você assistir isso
[424:59] depois na gravação
[425:01] que isso aqui vai dar muito bom pra ti
[425:03] que vai conseguir tirar muito site disso
[425:05] pessoal, curtiram? Posso contar
[425:07] com a marcação de vocês ali no Stories?
[425:09] pra dar aquela força, pra dar aquela moral
[425:11] pro amigo
[425:13] Gustavo Nimoto
[425:19] é a única coisa que eu peço pra vocês
[425:21] se você realmente tem alguma dúvida
[425:23] Gustavo
[425:25] eu tenho alguma dúvida
[425:27] eu quero marcar um bate-papo com um
[425:33] eu quero fazer um bate-papo
[425:35] um a um com você
[425:37] eu quero ver algumas coisas
[425:39] que a gente pode fazer, pode me chamar na WhatsApp
[425:41] e a gente marca esse bate-papo, a gente vê
[425:43] o que a gente pode fazer junto
[425:45] não é intuito do evento, mas pode ver
[425:47] falar com a gente
[425:49] Suyane, já investi mais de 10k
[425:51] em treinamento e não aprendi tanto que eu estou aprendendo
[425:53] com Tigo Nimoto, sensacional
[425:55] obrigado demais por esse feedback
[425:57] entrega fora da Curv, irmão, bora
[425:59] é só o início da entrega
[426:01] pessoal, quem puder postar lá no Insta
[426:03] agradeço demais
[426:05] eu finalizo esse evento
[426:07] eu agradeço a presença de todos
[426:09] cara, me motiva saber que a gente
[426:11] iniciou o evento com menos pessoas
[426:13] do que a gente terminou o evento
[426:15] foram crescendo a quantidade
[426:17] de pessoas dentro desse evento
[426:19] a maioria vai assistir gravado

---

**Conteúdo destrinchado em:** [[Mentoria Nimoto — Imersão (Mentalidade, MAGIC, CLOSER, Nutrição Infinita)]]
**Hub:** [[Mentoria Nimoto — Índice]]

---
data: 2026-02-16
cliente: (nome não identificado)
segmento: Energia solar com mix de marketing, indicação e prospecção
aderência: muito boa
tags: [reunião-vendas, solar, pré-vendas, SDR, múltiplos-canais, qualificação]
---

# Geração de Leads — 16/02/2026

## Leitura Executiva

Reunião importante que saiu do discurso genérico de "preciso de mais vendas" e entrou em **arquitetura de canal**. Cliente já pensa em marketing, indicação e prospecção como três pilares, mas ainda precisa organizar pré-vendas, metas e processo para transformar volume em resultado líquido.

---

## Contexto

- Estratégia dividida entre tráfego pago, indicação e prospecção ativa
- Leads pagos atuais em volume moderado, com desejo de crescimento
- Conversão ainda baixa do lead até venda
- Discussão sobre papel de pré-vendas e programa de SDR

---

## Diagnóstico

- Já percebe que geração de demanda sem qualificação cria desperdício
- **Pré-vendas** aparece como peça crítica para elevar eficiência do closer
- Precisa de indicadores por etapa, não apenas volume de leads
- Boa oportunidade para estruturar máquina comercial com múltiplos canais

---

## Sinais

- Disposto a investir em processo e treinamento
- Reconhecimento de que indicação sozinha não sustenta escala
- Abordagem consultiva com metas e comissionamento faz sentido para o cenário

---

## Riscos

- Canal pago pode inflar operação com lead frio e pouco aderente
- Sem pré-vendas bem definido, os closers continuam desperdiçando tempo
- Pode tentar fazer muitas frentes ao mesmo tempo sem priorização

---

## Oportunidades

- Implantar pré-vendas com KPI, script e rotina claros
- Equilibrar os três canais conforme CAC e conversão
- Formalizar **referral program** como fonte recorrente e mensurável
- Criar processo outbound complementar para reduzir dependência de mídia

---

## Próximos Passos

- [ ] Enviar proposta com escopo do SDR e estrutura de qualificação
- [ ] Definir papel exato do pré-vendas no funil
- [ ] Estabelecer meta diária/semanal por canal
- [ ] Criar painel mínimo: leads, visitas, propostas, vendas

---

> **Conclusão:** Aderência muito boa para projeto híbrido de estrutura comercial e geração de demanda.

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Ignição Comercial — Oferta Completa]]

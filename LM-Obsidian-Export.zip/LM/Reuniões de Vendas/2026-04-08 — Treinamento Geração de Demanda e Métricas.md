---
data: 2026-04-08
tipo: treinamento-interno
projeto: Comercial
foco: estruturação de geração de demanda, métricas ligação-para-visita, previsibilidade comercial
tags: [treinamento, geração-de-demanda, métricas, previsibilidade, matemática-comercial]
---

# Treinamento — Geração de Demanda e Métricas (08/04/2026)

## Foco Central
Estruturação de geração de demanda, métricas de ligação para visita e previsibilidade comercial.

## Tese Principal
**Comercial sólido começa quando o dono deixa de pensar em sorte e passa a pensar em taxa.** Quando você sabe quantas ligações geram quantos donos de empresa e quantas visitas, a empresa começa a prever resultado — e pode planejar contratação, treinamento e crescimento com base em dados reais.

---

## Principais Teses

- Prospecção traduzida em **matemática operacional**: ligações → donos de empresa → visitas → vendas
- Forte preocupação em sair da gangorra mensal, substituindo sensação por parâmetros
- O produto Ignição serve para instalar rotina de segmentação, script, acompanhamento e ajuste até a primeira visita qualificada
- A previsibilidade ajuda também no momento de contratar e treinar alguém

---

## A Matemática do Funil

> Exemplo prático:
> - 80 ligações/dia → 40 atendimentos → 16 decisores → 5 reuniões agendadas
> - Com ticket de R$5k: 5 reuniões × 40% fechamento = 2 vendas/semana = R$40k/mês

**Por que isso importa:**
- Quando o número está ruim, você sabe **exatamente onde está o problema**
- Você pode agir na etapa certa, não fazer mais de tudo ao mesmo tempo

---

## Comportamentos-Chave

- Parâmetros simples: ligações, conversas, visitas e vendas
- Segmentação inicial bem definida antes de prospectar
- Acompanhamento próximo via WhatsApp durante implantação
- **Refação de script** quando o resultado não vem em uma etapa específica

---

## Riscos Identificados

- Continuar dependente de oscilações sem entender a causa
- Contratar antes de dominar o próprio processo
- Medir só a venda final e ignorar as etapas intermediárias

---

## Desdobramentos Práticos

- [ ] Definir baseline das métricas atuais da operação
- [ ] Validar um script até gerar a **primeira visita qualificada**
- [ ] Usar a matemática do funil para treinar futuros vendedores

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Benchmarking Solar]] | [[Antecipação de Decisão e Pomodoro]]

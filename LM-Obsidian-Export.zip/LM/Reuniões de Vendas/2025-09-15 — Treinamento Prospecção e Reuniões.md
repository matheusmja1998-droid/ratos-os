---
data: 2025-09-15
tipo: treinamento-interno
projeto: Comercial
foco: clareza na prospecção, controle emocional, uso de CRM, consistência até a reunião
tags: [treinamento, prospecção, controle-emocional, CRM, consistência, energia]
---

# Treinamento — Prospecção e Estratégias de Reuniões (15/09/2025)

## Foco Central
Clareza na prospecção, controle emocional, uso de CRM e consistência no avanço até a reunião.

## Tese Principal
**Comercial forte depende de energia canalizada.** O vendedor não pode transformar cada conversa difícil em novela. A operação cresce quando a prospecção vira processo com clareza, registro e continuidade — não com improviso emocional.

---

## Principais Teses

- O conteúdo valoriza comunicação direta e simples, com **foco em marcar a reunião** — não em explicar demais
- Prospects hostis não devem sequestrar energia da operação; o vendedor precisa preservar ritmo e pragmatismo
- CRM aparece como disciplina básica de continuidade — nada deve depender de memória ou motivação do momento
- Performance comercial é também **competência emocional**: seguir depois do "não", sem contaminar a próxima ligação

---

## Comportamentos-Chave

- Script objetivo e enxuto — sem enrolação
- Registro disciplinado de follow-up no CRM
- Cadência diária de prospecção independente de humor
- **Gestão emocional** após interações negativas (descarte rápido antes da próxima call)

---

## Riscos Identificados

- Sem CRM, a operação perde timing e repetibilidade
- Sem resiliência emocional, a sequência de calls cai de qualidade ao longo do dia
- Sem foco em reunião, o vendedor tende a despejar informação e gerar fuga

---

## Desdobramentos Práticos

- [ ] Definir campos mínimos obrigatórios no CRM após cada call
- [ ] Treinar **descarte emocional rápido** entre uma ligação e outra
- [ ] Reduzir scripts longos para blocos curtos: valor, contexto e convite

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Compromissos e Metodologia OAE]] | [[O Melhor Perdedor Vence — Tom Hougaard]]

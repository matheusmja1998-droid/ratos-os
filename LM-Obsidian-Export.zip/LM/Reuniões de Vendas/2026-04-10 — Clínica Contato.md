---
data: 2026-04-10
cliente: Clínica Contato
segmento: Clínica de terapias / saúde
aderência: muito alta
tags: [reunião-vendas, saúde, clínica, google-meu-negocio, tráfego, conteúdo, pixel, lgpd]
---

# Clínica Contato — 10/04/2026

## Leitura Executiva

A reunião mais completa do ciclo com a clínica — consolidou um diagnóstico robusto. Operação com **retenção muito forte**, quase toda a aquisição vem por indicação e Instagram, e existe enorme potencial econômico em transformar presença digital local em agenda previsível. O projeto já entrou em nível de execução: cronograma, métricas, pixel, conteúdo e lógica financeira de aquisição.

---

## Contexto

- Aquisição atual: praticamente 100% por indicação, escola parceira e Instagram
- Sistema novo de agendamento ainda sem analytics detalhado
- Plano apresentado: **12 semanas** com Google Meu Negócio, pixel, anúncios e conteúdo
- Meta financeira: **dobrar faturamento** (~R$70k/mês → R$140k/mês)

---

## Diagnóstico

- Negócio muito saudável em retenção → aumenta LTV e justifica investimento em aquisição
- Ausência de métricas detalhadas: problema de **gestão**, não de mercado
- Proposta correta ao começar por fundação digital e rastreamento antes de escalar mídia
- Produção de conteúdo será decisiva — a venda exige confiança, empatia e autoridade

---

## Sinais

- Fez perguntas boas sobre LGPD, rastreamento e operacionalização → sinal de interesse real
- Conversa avançou para acessos, cronograma e estrutura de execução
- Clareza de meta e consciência de capacidade de crescimento

---

## Riscos

- Equipe pode ter dificuldade de manter ritmo de gravação
- Sem métricas de origem e retenção, otimização fica mais lenta
- Questões de LGPD exigem comunicação muito correta e sem atalhos

---

## Oportunidades

- Explorar retenção alta como grande vantagem econômica do projeto
- Otimizar Google Meu Negócio para capturar demanda local com intenção
- Criar anúncios e conteúdos empáticos voltados a mães e famílias
- Medir CAC, retorno por terapeuta e ocupação da agenda

---

## Plano de 12 Semanas (Estrutura)

| Fase | Ações |
|---|---|
| Fundação | Google Meu Negócio otimizado, pixel instalado, site estruturado |
| Rastreamento | Tags de conversão, painel básico de métricas |
| Conteúdo | Calendário editorial: educativo + autoridade clínica |
| Anúncios | Campanhas locais com audiências segmentadas (mães, famílias) |
| Otimização | Análise de CAC, retorno por terapeuta, ocupação de agenda |

---

## Próximos Passos

- [x] Reunião de conteúdo e criativos → marcada 14/04/2026 às 18h — [[Clínica Contato — Reunião Conteúdo e Criativos]]
- [x] Google Meu Negócio — acesso obtido
- [ ] Solicitar acessos: BM e Google Ads
- [ ] Estruturar página/site e instalar pixel/tags
- [ ] Criar painel simples: pacientes novos, recorrência, ocupação, origem

---

> **Conclusão:** Aderência muito alta. É um dos cenários mais fortes do projeto para crescimento previsível via digital.

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[2026-03-31 — Clínica Itapema]] | [[Curso Lucas Felix — Assessoria de Performance]]

---
tipo: reuniao-venda-R1
data: 2026-05-15
cliente: Fabio Serpeloni
empresa: BR Energia
nicho: solar / fotovoltaica
cidade: Belo Horizonte
fonte: Fathom
url: https://fathom.video/calls/676030429
recording_id: 146894967
status: pre-proposta
---

# R1 — Fabio Serpeloni (BR Energia Solar)

[Gravação Fathom](https://fathom.video/calls/676030429)

## Contexto da empresa

- BR Energia, **12 anos** (8 em fotovoltaica, 4 em aquecimento solar)
- Belo Horizonte / MG
- Já teve 38 colaboradores + 12 vendedores internos. Hoje enxugou
- Fatura no **ticket alto**, fechamento personalizado, visita técnica antes de orçamento
- **99% das vendas vêm de indicação** (rede pessoal: arquitetos, engenheiros, construtores)
- Base: ~300 arquitetos + ~300 engenheiros + construtoras
- Conversão: **5 a 7 a cada 10 orçamentos** (meta dele = 7)
- Vendeu R$500 acima do concorrente em venda recente, ainda fechou com ele porque foi visita técnica
- Tem CRM em uso (não falou qual — descobrir na próxima call)

## Equipe atual

- **Juliana** — 11 anos com ele, braço direito, gestão de cliente / agenda / visita técnica. **Não traz cliente, nunca trouxe**. Recebeu proposta de concorrente (R$3.500 + 3% de comissão) mas continua. Perfil de executora de processo, não vendedora ativa.
- **Engenheiro(s)** — faz visita técnica
- **Fábio** — fecha venda

## Dor central

**Volatilidade.** Como depende 100% da rede dele, mês que ele para = mês no vermelho. Fez cirurgia recente, mês tá faltando orçamento. Empresa **founder-dependente**.

## O que o Fábio quer (em ordem do que ele falou)

1. **IA pros indicadores dele** (pedido explícito dele): *"queria que o IA me desse [algo pros indicadores]"*. Quer reativar e profissionalizar a rede de 600 indicadores sem precisar a Juliana ligar pra cada um.
2. **Site / posicionamento de autoridade** — comparou com concorrente Hans cujo site "parece que tem 100 anos e 10 mil projetos"
3. **IA como auxiliar operacional / CRM** — lembrar de gerar orçamento, confirmar visita técnica, follow-up
4. **Conteúdo no Instagram** — abandonado, ele "gosta de falar" mas nunca gravou nada

> Atenção: o conceito de "plataforma com funil completo" foi o Matheus que materializou na call. O Fábio deu a semente bruta. Cuidar pra não vender uma visão que não é dele.

## O que ele NÃO quer

- Mídia paga / feirão / lead frio em volume (já se queimou)
- Baixar preço — ticket alto é estratégico
- Juliana operando manualmente — quer plataforma
- IA genérica — pergunta-âncora dele: *"qual vai ser o diferencial se todo mundo usar a mesma IA?"*
- Orçamento no WhatsApp — só passa orçamento depois da visita técnica
- Comercial humano da LM operando dentro dele (decisão nossa)

## Dilema da venda

- Ele está **fechado pra qualquer coisa que não seja IA**. A mente travou nisso depois do curso da Adapta
- A gente sabe que o que vai gerar resultado é **operação comercial** com a base de indicadores que ele já tem
- Solução: **vender produto de IA, embutir a alavanca comercial dentro dele**, sem colocar vendedor da LM

---

## Proposta amarrada (projeto único)

### Nome de trabalho

**BR Energia — Plataforma de Indicadores com IA**

### Pitch numa frase

> Plataforma própria onde os indicadores lançam contatos, a IA conduz o lead até a visita técnica e atualiza o indicador automaticamente quando a venda fecha. Sem vendedor da LM, sem prospecção fria, sem disparo invasivo. Estrutura + IA, o time dele opera.

### Fluxo completo

**Fase 1 — Cadastro manual (Fábio / Juliana)**
- Cadastra indicadores manualmente na plataforma
- Cada indicador recebe acesso ao portal (login/senha)
- Vê: contatos que indicou, status do funil, comissão acumulada

**Fase 2 — Indicação entra**
- Indicador entra no portal, lança nome + telefone do cliente
- Plataforma cria contato no CRM
- IA dispara WhatsApp inicial pro cliente:
  > "Oi [nome], aqui é a BR Energia. O [indicador] me passou seu contato pra gente conversar sobre o projeto de energia solar do seu imóvel. Posso te fazer algumas perguntas rápidas?"

**Fase 3 — Qualificação via IA**
- IA pergunta consumo, tipo de imóvel, urgência, motivação
- **NUNCA manda orçamento** (regra do Fábio)
- Lead qualificado → IA propõe agendamento de visita técnica
- Notifica Juliana / engenheiro

**Fase 4 — Venda humana**
- Engenheiro faz visita técnica
- Fábio fecha (mantém método dele: visita + atenção + ticket alto)
- Equipe atualiza status no CRM

**Fase 5 — Loop com indicador**
- CRM marca "fechado" → portal puxa via webhook
- IA dispara WhatsApp pro indicador:
  > "Boa notícia: o [cliente] que tu indicou fechou. Comissão de R$X creditada. Já tá no teu portal."
- Indicador vê histórico completo na plataforma

---

## Stack técnica

| Componente | Tecnologia |
|---|---|
| Frontend (portal indicador) | Lovable + React |
| Backend / banco | Supabase |
| WhatsApp | Meta Cloud API |
| IA conversacional | Claude API |
| Integração CRM | Webhook + API do CRM (saber qual) |
| Automações de fluxo | n8n (VPS) |

## Cronograma de entrega

| Semana | Entrega |
|---|---|
| 1 | Levantamento técnico (CRM, fluxo, identidade visual) + setup Supabase + wireframe Lovable |
| 2 | Frontend completo + auth + cadastro de indicadores |
| 3 | Cloud API + templates Meta aprovados + Claude API em teste |
| 4 | Integração CRM + n8n + loop fechado |
| 5 | Teste com 5 indicadores reais + ajustes + handoff |

**Tempo total: 4-5 semanas**

---

## Custos de operação (Fábio paga)

### Infra mensal

| Item | Custo/mês |
|---|---|
| Hospedagem Lovable/Vercel | R$0 (free) ou R$100 (pro) |
| Supabase | R$0 (free até 500MB) ou R$130 (pro com backup) |
| VPS para n8n | R$50 |
| Meta Cloud API | R$0 até 1k conversas/mês, depois ~R$0,07/conversa |
| Claude API (~1k conversas/mês) | R$50-150 |
| Domínio (já tem) | R$0 |
| **Total infra** | **R$200-450/mês** |

### Manutenção LM

**R$497-697/mês**, inclui:
- Ajustes pequenos
- Correção de bug
- Atualização de API (Meta muda a cada ~6 meses)
- Suporte WhatsApp direto

Não inclui: nova feature grande (cobrar separado).

### Operação dia a dia

- Juliana: 30-60 min/dia (cadastro de indicador, acompanhamento de conversas escaladas, marcação de visita)
- Ela libera o tempo que hoje perde fazendo follow-up manual

---

## Análise: ele paga?

### Sinais positivos
- Já compra cursos caros de IA (Adapta, R$3-5k)
- Empresa de 12 anos, ticket alto, fluxo recorrente → tem caixa
- Já gastou em coisa pior (feirão, deu prejuízo) → tem orçamento de marketing
- Pediu o produto explicitamente → quando cliente pede, paga mais fácil
- Quando Valentino mencionou faixa R$500-R$20k, ele não recuou
- Empresa dele compete sem baixar preço → respeita preço premium

### Sinais de cautela
- Diz que é "lento com tecnologia" — risco de adoção
- Cético com IA genérica → tem que ser vendida como sob medida pra rede dele
- Retorno orgânico via indicador é lento (60-90 dias) → risco de desistir antes da primeira venda fluir
- Já se decepcionou com Adapta ("comprei e não consigo usar") e feirão → não pode prometer demais

### Faixa sugerida

- **Setup único:** R$10k-15k
  - Abaixo de R$8k: LM trabalha de graça
  - Acima de R$18k: zona de "tá caro, deixa eu pensar"
- **Manutenção mensal:** R$497-697
  - Abaixo de R$300: ele acha pouco e desconfia
  - Acima de R$1k: ele compara com gerente
- **Receita ano 1 LM:** R$15-20k

### Blindagem do "retorno não-visível"

Embutir 3 entregas tangíveis curtas:
1. **Semana 5:** Demo ao vivo com 5 indicadores reais conversando com IA
2. **Mês 2:** Relatório automático "X indicadores ativos, Y leads qualificados, Z visitas marcadas"
3. **Mês 3:** Sessão de revisão pra ajustar

Isso compra tempo até primeira venda real fluir.

---

## Pendências antes da próxima call

- [ ] Descobrir qual CRM ele usa
- [ ] Pegar identidade visual da BR Energia (logo, cores, fontes)
- [ ] Confirmar se ele tem domínio (`brenergia.com.br` ou similar) pra subdomínio do portal
- [ ] Confirmar se ele tem BM Meta + número WhatsApp Business
- [ ] Montar slide da próxima call (5 fases do fluxo + preço + cronograma)
- [ ] Definir contrato + forma de pagamento (PIX ou 12x)

## Próximos passos

1. Matheus + Valentino refinam preço e prazo
2. Monta apresentação visual da proposta
3. Agenda próxima call (já está combinada — semana que vem, 17h)
4. Apresenta proposta ao vivo
5. Se fechar: contrato + sinal + começa semana seguinte

## Frases-chave pra abrir a próxima call

> "Fábio, a gente não vai te dar lead frio. Vamos transformar tua rede de 600 indicadores numa plataforma que faz o trabalho da Juliana 24/7 — só que sem precisar contratar ninguém. Tu cadastra os indicadores, a IA cuida do resto até a visita, e tu fecha do jeito que sempre fechou."

Resposta direta à pergunta-âncora dele (*"qual o diferencial se todo mundo usa IA?"*):

> "O diferencial não é a IA. É que essa IA é construída em cima da TUA rede de 600 indicadores. Concorrente nenhum tem isso. É a tua vantagem competitiva, codificada em software."

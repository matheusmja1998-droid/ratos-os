---
data: 2026-03-04
tipo: treinamento-interno
projeto: Comercial
foco: otimização de script, acesso a decisores, análise de métricas, roleplays
tags: [treinamento, script, decisores, métricas, roleplay, funil, prospecção]
---

# Treinamento — Script e Otimização de Prospecção (04/03/2026)

## Foco Central
Otimização de script, acesso a decisores, análise de métricas e roleplays para elevar conversão de prospecção.

## Tese Principal
O conteúdo trata **prospecção como sistema mensurável**. Não basta dizer que o vendedor está ruim ou bom — é preciso descobrir em que ponto ele perde resultado. Também mostra que pequenas escolhas semânticas alteram significativamente a receptividade.

---

## Principais Teses

- A primeira triagem define boa parte do funil: palavras como *convite*, *diretor* e *análise educacional* **reduzem resistência**
- Forte ênfase em fraseado, tom, cadência, uso do nome da pessoa e sensação de autoridade respeitosa
- O time acompanha métricas em tempo real para diagnosticar gargalo: lista, atendimento, passagem para decisor e reunião marcada
- Roleplays encurtam curva de aprendizado e corrigem execução, não apenas teoria

---

## Comportamentos-Chave

- Troca intencional de palavras que reduzem defesa do prospect
- Frases de exclusividade e valorização do prospect
- Checklist de autoanálise após cada ligação
- **Três check-ins diários** de números
- Ajuste de lista, cidade e discurso com base em dados

---

## Métricas de Diagnóstico por Etapa

| Etapa | O que medir |
|---|---|
| Lista | Qualidade e segmentação correta |
| Atendimento | % de chamadas atendidas |
| Passagem para decisor | % de atendimentos que chegam ao decisor |
| Reunião marcada | % de decisores que aceitam reunião |

> Quando o número trava em alguma etapa, é nessa etapa que está o gargalo — não na anterior.

---

## Riscos Identificados

- Sem leitura de métrica por etapa, a equipe tenta corrigir tudo ao mesmo tempo
- Sem treino auditivo e vocal, o melhor script vira fala mecânica
- Sem revisão frequente, boas frases se perdem na rotina

---

## Desdobramentos Práticos

- [ ] Congelar versão atual do script e versionar mudanças
- [ ] Criar scorecard individual com gargalo principal por vendedor
- [ ] Gravar roleplays modelo e usar como **biblioteca de referência**
- [ ] Instituir feedback baseado em etapa do funil, não em opinião geral

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Mapeamento de Conexão]] | [[Treinamento de POPs]]

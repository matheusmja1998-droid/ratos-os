---
data: 2025-10-13
tipo: treinamento-interno
projeto: Comercial
foco: prospecção ativa como base de aquisição, medição do funil, nicho e CRM
tags: [treinamento, prospecção-ativa, funil, CRM, nicho, métricas, medição]
---

# Treinamento — Prospecção Ativa e CRM (13/10/2025)

## Foco Central
Prospecção ativa como base de aquisição, medição do funil e construção de nicho e CRM.

## Tese Principal
O valor da gravação está na **simplicidade disciplinada**: antes de sofisticar canais, dominar o canal mais controlável — a prospecção direta, mensurada e repetível. Quem não mede não melhora.

---

## Principais Teses

- Prospecção ativa é a forma **mais rápida e barata** de gerar cliente, especialmente para quem ainda não tem caixa ou previsibilidade
- Defesa contundente da medição semanal do funil: ligações → conexões → decisores → reuniões → vendas
- Especialização de nicho melhora repertório e eficiência de conversa
- CRM é **infraestrutura mínima**, não luxo

---

## Funil de Prospecção a Medir

| Etapa | Métrica |
|---|---|
| Ligações | Volume total de tentativas |
| Conexões | Chamadas atendidas |
| Decisores | Chegou ao responsável |
| Reuniões | Agendamento confirmado |
| Vendas | Fechamento |

> Sem esse painel, é impossível saber onde a operação está perdendo. Cada etapa tem uma taxa de conversão que pode ser melhorada individualmente.

---

## Comportamentos-Chave

- Meta diária de ligações definida e cumprida
- Registro semanal do funil completo
- Foco em **nicho específico** — não dispersão por muitos segmentos
- Uso consistente de CRM para todo contato

---

## Riscos Identificados

- Pular para tráfego pago sem ter base comercial funcionando
- Fazer prospecção sem medir (esforço invisível, sem melhoria)
- Conversar com muitos segmentos e aprofundar em nenhum

---

## Desdobramentos Práticos

- [ ] Implantar **painel semanal do funil** de prospecção
- [ ] Escolher nicho principal e montar lista segmentada
- [ ] Definir meta mínima diária de atividade e medir durante 30 dias

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Prospecção Fanática — Jeb Blount]] | [[Benchmarking Solar]]

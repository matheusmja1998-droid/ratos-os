---
data: 2026-04-13
tipo: prospecção-ativa
segmento: Solar / Elétrica / Integradores — Minas Gerais
tags: [prospecção, ligações, lm, b2b, script, objeção, cold-call]
status: transcrição-parcial
---

# Prospecção Ativa — Sessão de Ligações  |  13/04/2026

## Contexto da Sessão

Sessão de ligações de prospecção ativa da equipe comercial da LM. Alvo: empresas do segmento de energia solar, elétrica e integração da região de **Minas Gerais**.

**Pitch da sessão:** convite para evento gratuito (quinta-feira, meio-dia, online) sobre como gerar demanda de clientes comerciais sem tráfego pago e sem Instagram.  
**Público convidado:** integradores, mão de obra, mercado livre de energia, geração distribuída.  
**Volume declarado:** mais de 100 empresas convidadas na região.

> Transcrição disponível: **trecho final da sessão** (pós-ligações principais). Transcrição completa a ser adicionada.

---

## Ligações Identificadas no Trecho

### Ligação 1 — Canadá / Estevam (Valentino)

| Campo | Dado |
|---|---|
| Prospect | Estevam |
| Empresa | Canadá |
| Segmento | Automação / integração solar |
| Contato atendido | Não era o dono — intermediário (instalação) |
| Resultado | Sem confirmação direta — encaminhamento para Marcílio (responsável) via áudio no WhatsApp + ligação no dia seguinte |

**O que aconteceu:** Valentino conduziu a call com boa desenvoltura, quebrou o gelo com observação sobre a foto do Google ("vocês parecem um restaurante"), qualificou o segmento, repassou o pitch do evento. Não conseguiu o dono mas deixou follow-up agendado para manhã seguinte.

---

### Ligação 2 — DNA / Humberto (SDR)

| Campo | Dado |
|---|---|
| Prospect | Roberto / Humberto |
| Empresa | DNA |
| Segmento | Eletrotécnica — integrador + mão de obra |
| Tamanho | 1 pessoa (operação solo) |
| Aquisição atual | 100% indicação, sem anúncios |
| Resultado | Rejeição clara — "Não tenho interesse" (2x) |

**O que aconteceu:** SDR apresentou o pitch completo. Prospect rejeitou de forma clara após cerca de 2 minutos. SDR continuou tentando reverter — prospect desligou. Equipe comentou o erro imediatamente.

---

### Debate interno pós-sessão

**Sobre expansão geográfica (Valentino):**
- Lista atual: Minas Gerais
- Hipótese levantada: prospectar Santa Catarina por afinidade de DDD
- Menção a cidades do litoral catarinense: Itapema, Balneário Camboriú, Tijucas, Itajaí, Porto Belo
- Decisão: montar nova lista às 17h no alinhamento do dia

**Sobre taxa de contato:**
- Valentino: "1h30 para marcar 10" — sinalizando que a taxa de atendimento estava baixa

---

## Análise do Trecho

### O que funcionou
- **Quebra de gelo com contexto real** — Valentino usou a foto do Google ("vocês parecem um restaurante") como abertura leve e desarmante. Funcionou para criar rapport imediato
- **Qualificação logo no início** — pergunta "vocês são integradores ou mão de obra?" está no lugar certo, antes do pitch
- **Gestão de gatekeepers** — na ligação da Canadá, sem conseguir o dono, Valentino já definiu próximo passo concreto (áudio no WhatsApp + ligação manhã seguinte)
- **Pitch do evento bem estruturado** — proposta de valor clara: clientes comerciais, sem anúncio, gratuito

### O que ajustar
- **Corte imediato na rejeição clara:** quando o prospect diz "não tenho interesse" pela segunda vez, encerrar em 5 segundos. A equipe identificou isso sozinha — é o principal ajuste a reforçar no próximo treinamento
- **Qualificação de tamanho antes do pitch:** operação solo (1 pessoa) raramente tem perfil para implementar estratégia de prospecção. Perguntar "hoje você tem equipe comercial ou é só você?" antes de entrar no pitch economiza 2–3 minutos por call errada
- **Taxa de contato baixa:** 1h30 para 10 marcações sugere lista ou horário com baixo aproveitamento. Testar horários diferentes ou refinar critério da lista

### Feedback da equipe (pós-ligação DNA)

> *"Maior fila da puta quando o cara te ouve tudo e depois fala que não."*

> *"Se ele respondesse, cortasse, ele falando que não quer — seria pra não cozinhar esse cara nesse fator. Perde tempo. Não quero, passou dois minutos e não tem interesse."*

---

## Transcrição Bruta — Trecho Final Completo

> Nota: trechos com sobreposição de vozes, caixa postal e ruído de fundo foram mantidos como gravados. Algumas falas estão truncadas por áudio simultâneo.

```
[4070 em diante]

Falante 2: Caralho.
Falante 4: Tarde.
Falante 2: Opa, tarde. E aí, tudo bem?
Falante 4: Tudo bom e você?
Falante 2: Ah, aqui tá ótimo, graças a Deus. É da Canadá, né?
Falante 4: Isso, é da Canadá.
Falante 2: E qual que é teu nome?
Falante 1: A Esteva.
Falante 2: Legal, Estevam. Eu sou o Valentino, sou o diretor aqui da LM.
Falante 3: Vocês são integradores?
Falante 1: Isso.
Falante 2: É que eu vi a foto de vocês aqui do Google, vocês parecem um restaurante, na verdade.
Falante 1: Restaurante?
Falante 2: É, vocês estão com umas saladas aqui na foto do…
Falante 1: Deve ter dado algum erro então, porque aqui a gente faz automação.
Falante 4: Ah! Não dá para economizar solar.
Falante 2: Vocês são integradores?
Falante 1: Boa tarde, tudo bem?
Falante 3: Bom, é com quem eu falo?
Falante 2: É isso? Ah, tá. Ô Estevam, eu tô com um convite aí pro responsável.
Falante 2: Já aproveitando o gancho que vocês são integradores, é você mesmo ou outra pessoa?
Falante 4: No momento, ele não está.
Falante 2: Agora que eu não me entendi.
Falante 3: Deixa eu falar um pouco demais, não, Breno? Eu estou aproveitando, cara, para fazer um convite para a equipe.
Falante 1: É mais cedo.
Falante 4: Ah, eu não sei se ele chega hoje, mas ele tá atendendo um cliente.
Falante 1: Por aí, você quer anotar ou não?
Falante 1: Quer botar no número e você encaminhar para mim?
Falante 3: A gente está fazendo um convite, a gente está fazendo um evento agora quinta ao meio-dia e vai ser online, vai ser gratuito.
Falante 4: É 19,9.
Falante 1: 7,64…
Falante 3: Inclusive, Breno, deixa eu te perguntar, vocês são integradores ou são mão de obra?
Falante 4: Do que se trata convênio?
Falante 3: Legal. Agora você é responsável por completo.
Falante 2: Ô Estevão, a gente vai fazer um evento nessa quinta-feira.
Falante 2: É online e gratuito também.
Falante 2: Onde já confirmaram mais de 100 empresas que vão participar. Aí dentro disso tem integradores.
Falante 2: Tem empresa de energia solar, geração distribuída, mercado…
Falante 2: Tem de mão de obra no geral também, engenheiros, né?
Falante 2: Certo. E daí, Estevam, o intuito do evento, que é gratuito, é ensinar vocês como vocês podem gerar a própria demanda de clientes comerciais.
Falante 3: Nesse evento, a ideia é ensinar vocês como vocês podem fazer a própria demanda de comerciais.
Falante 2: A custo zero, sem investir em anúncio. Sem investir em tráfego pago, sem investir em Instagram, em Google, sem investir em nada.
Falante 3: E assim, mexer em tráfego pago, nada de Instagram, nada de caminho.
Falante 2: Eu vou te mandar um áudio explicando ali, pra tu encaminhar ali pro Marcílio.
Falante 3: E também, eu vou confirmar a tua participação na nossa meta.
Falante 2: Eu vou ligar amanhã de manhã.
Falante 2: É você o fera jogador com a camiseta da Jeep?
Falante 4: Isso.
Falante 3: E aí como funciona? Eu pego o seu e-mail, envio um convite para eventos.
Falante 2: Te mandei um ponto e saiu um Chaves ali também, sem querer. Mas eu vou te mandar um áudio, esse aí é o meu número pessoal, tá?
Falante 3: Beleza. Qualquer coisa também você me passa as informações, eu repasso pra…
Falante 2: Tu é da área de vendas também ou é o Stefan?
Falante 4: Não, eu sou da parte de instalação mesmo.
Falante 2: Engenheiro, né? Legal. Parabéns, então. Eu vou ligar amanhã de manhã, tá bom?
Falante 3: Obrigado.
Falante 1: Beleza, então.
Falante 2: Valeu, fera. Tchau.
Falante 1: Valeu, falou.
Falante 3: Parabéns, então. Vou pegar esse número aqui, esse é o WhatsApp, né?
Falante 3: Deixa só um minuto que eu já vou te enviar o convite na sua agenda. Vou te enviar também o link. Ô Breno, inclusive, pode participar você e sua equipe. Hoje você tem time comercial?
Falante 3: Hoje então é só você que atua fechando o projeto aí, né?
Falante 3: Ô Breno, eu vou te mandar um OPA aqui e vou te enviar o link do calendário também, é só você clicar ali e aceitar, que deixa marcado na sua agenda, fechou?
Falante 3: Fechou, Breno. Abraço. Tenha uma ótima tarde.
Falante 3: Tchau.

--- [pós-ligação — equipe] ---

Falante 3: Vamos repetir, como que foi?
Falante 2: Não marquei, não era o dono.
Falante 3: Marquei aqui, mano.
Falante 2: Uma hora e meia para marcar 10, todos têm que me atender.
Falante 2: Sua ligação foi encaminhada ao correio.
Falante 2: Tenho certeza que se eu ligar em Santa Catarina, eu vou ter muita conexão por conta do DDD.
Falante 2: O que você acha? Eu fazer uma lista de Santa Catarina aqui?
Falante 3: Mais fácil, mano.
Falante 2: Quem quiser prospecto Santa Catarina, ninguém, né?
Falante 3: Acho que muito pouco.
Falante 2: Eu prospectei… que pena, tem muito potencial aqui.
Falante 2: Eu acho que eu prospectei só do Sul, perdão, Rio Grande do Sul.
Falante 2: Rio Grande do Sul é foda.
Falante 2: Tem Itapema, Balneário Camboriú, Tijucas, Itajaí. Porto Belo, tem um monte de lugar.
Falante 2: Hoje à tarde, quando a gente finalizar, às 5 horas no alinhamento, eu vou fazer uma lista.
Falante 1: Boa.
Falante 1: Aloha.

--- [ligação — DNA / Humberto] ---

Falante 3: Boa tarde.
Falante 3: Com quem eu falo?
Falante 3: Roberto.
Falante 3: Do DNA.
Falante 3: Ô Beto, seguinte, na quinta-feira agora vai ser um evento gratuito. Inclusive, deixa eu perguntar, vocês são integradores ou são mão de obra?
Falante 3: Os dois, né? O Humberto, seguinte, você é o responsável da eletrotécnica, acho.
Falante 3: Então, Humberto, nessa semana, ali do meio-dia, a gente vai estar realizando esse evento. A gente já convidou mais de 100 empresas da região de Minas Gerais para participar.
Falante 3: Empresas que a gente convidou têm integradoras, mão de obra, empresas… se é esse seu caso… tem mercado livre de energia, geração distribuída.
Falante 3: Dentro desse evento, a gente vai ensinar como vocês podem gerar a própria demanda de clientes comerciais. São aqueles clientes que pagam mais, têm uma conta de luz maior, então vocês conseguem vender projetos maiores.
Falante 3: E isso sem investir em anúncio, nada de Instagram, nada de tráfego pago, voltado 100% para a área comercial.
Falante 3: O intuito dessa ligação é confirmar sua participação e da sua equipe na quinta-feira, meio-dia. Vai ser online, gratuito. Eu posso confirmar, Humberto?

Falante 1: Não, cara, agradeço, mas não tenho interesse.

Falante 3: Entendi. Mas você não tem interesse para…

Falante 1: Eu não tenho interesse.

Falante 3: Hoje você tem quantas pessoas? Só você mesmo?

Falante 1: Hum-hum.

Falante 3: Entendi. Você faz alguma coisa, anuncia alguma coisa de publicidade ou é só 100% indicação?

Falante 2: Eu não tenho interesse então.

Falante 1: Não, eles não falham.

Falante 3: Só indicação, né? Entendi. Roberto, dentro desse evento, só te falando um pouquinho melhor, a gente vai trazer como diversificar isso.

--- [pós-ligação — equipe] ---

Falante 3: Tomar no cu. Rato, velho.
Falante 2: Vamos lá, teu estupidez humano.
Falante 3: Por quê?
Falante 2: O cara estava muito fechado, mano.
Falante 5: Eu fui, eu só fui falando, tá ligado?
Falante 2: Ele falou que queria pica e tu não tinha.
Falante 3: Oh, hey! Obrigado.
Falante 2: Ele já atendeu, eu já fiquei rindo porque Humberto.
Falante 3: Boa noite.
Falante 2: Ô Matheus, maior fila da puta quando o cara te ouve tudo e depois ele fala que não.
Falante 2: Ainda dá certo, pô. Se ele respondesse, cortasse, ele falando que não quer, seria para não cozinhar esse cara nesse fator.
Falante 2: Perde tempo. Não quero, passou dois minutos e não tem interesse.
Falante 2: O Matheuszinho.
Falante 1: Não quero, não tenho interesse.
Falante 3: Vou ler para ele.

--- [encerramento da sessão — ruído / sobreposição] ---

Falante 5: Esse número está configurado para…
Falante 1: Bom dia.
Falante 3: Ah, é que eu vou dar uma chamada no beijo, vai. Obrigado.
Falante 5: Eu vou finalizar a reunião.
Falante 5: Como vocês chamaram?
Falante 3: Eu vou cantar!
Falante 5: Olha, maravilha.
Falante 3: Vai lá, que Deus te abençoe.
Falante 3: Tchau. Até a próxima, tudo bem.
Falante 5: O que foi?
Falante 5: Okay. I know that. Eu vou ligar.
Falante 3: So please applaud for us.
```

---

## Próximos Passos

- [ ] Adicionar transcrição completa da sessão quando disponível
- [ ] Filtrar leads qualificados da sessão (interesse sinalizado)
- [ ] Análise completa como head comercial (padrões de rejeição, ajustes no script)
- [ ] Extrair script otimizado com base no que funcionou

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[2026-03-04 — Treinamento Script e Prospecção]] | [[2026-04-08 — Treinamento Geração de Demanda e Métricas]]

---
data: 2025-09-02
tipo: treinamento-interno
projeto: Comercial
foco: pré-vendas, qualificação pelo BUNCH, leitura de budget/authority/necessity/timing
tags: [treinamento, pré-vendas, qualificação, BUNCH, decisor, budget, timing]
---

# Treinamento — Framework de Pré-Vendas / BUNCH (02/09/2025)

## Foco Central
Pré-vendas, qualificação pelo BUNCH e leitura de budget, authority, necessity e timing.

## Tese Principal
**Não é sobre marcar o máximo de reuniões — é sobre marcar as reuniões certas.** Uma agenda cheia de leads sem capacidade de compra gera falsa sensação de produtividade e desperdiça o recurso mais escasso: o tempo do closer.

---

## O Framework BUNCH

| Letra | Critério | Como tratar |
|---|---|---|
| **B** | Budget | Critério duro — sem orçamento mínimo, não avança |
| **U** | Authority | Critério duro — sem decisor real na reunião, não avança |
| **N** | Necessity | Pode ser construído na venda |
| **C** | Commitment | Disposição de mudar — pode ser desenvolvida |
| **H** | Has a timeline | Pode ser criado com urgência comercial |

> Budget e authority são **critérios de bloqueio**. Necessity e timing podem ser trabalhados.

---

## Principais Teses

- Nem todo lead merece reunião; a pré-venda protege o tempo do comercial
- Budget e authority são critérios duros → bloqueiam avanço sem negociação
- Necessity e timing podem ser construídos pela condução comercial
- Urgência não precisa existir pronta; parte dela pode ser criada pelo vendedor

---

## Comportamentos-Chave

- Checagem de orçamento mínimo antes de agendar
- Confirmação de presença de decisor real na reunião
- Diagnóstico de necessidade atual no pré-call
- Identificação de janela temporal para compra

---

## Riscos Identificados

- Agenda cheia com leads sem capacidade de compra
- Reuniões com interlocutores sem poder de decisão
- Falsa sensação de pipeline robusto — volume sem qualidade

---

## Desdobramentos Práticos

- [ ] Formalizar checklist BUNCH no pré-agendamento
- [ ] Bloquear avanço sem budget mínimo e sem autoridade confirmada
- [ ] Treinar time para **desenvolver necessidade e timing** dentro da reunião

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Critérios de Nicho]] | [[Ignição Comercial — Script de Diagnóstico v2]] | [[Horizonte de Oportunidades]]

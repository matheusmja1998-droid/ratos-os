---
data: 2025-09-15
tipo: treinamento-interno
projeto: Comercial
foco: aumento de comparecimento em reuniões, repertório de objeções, integração prospecção/marketing/vendas
tags: [treinamento, objeções, no-show, confirmação, comparecimento, roleplay]
---

# Treinamento — Preparação de Reunião e Objeções (15/09/2025)

## Foco Central
Aumento de comparecimento em reuniões, construção de repertório de objeções e integração entre prospecção, marketing e vendas.

## Tese Principal
**Performance comercial não depende só de falar melhor** — depende de reduzir fricções invisíveis antes, durante e depois do agendamento. O grande mérito desse conteúdo está em transformar objeção em matéria-prima de treinamento.

---

## Principais Teses

- A reunião começa **antes da call**: confirmação por WhatsApp, grupo com identidade visual e reforço de presença aumentam comparecimento
- Objeções não devem ser tratadas como atrito isolado — devem ser coletadas, classificadas e treinadas em equipe
- A reversão não é apenas argumentação: envolve surpresa, quebra de padrão, reacomodação e pedido de avanço imediato
- Marketing e vendas precisam conversar — a qualidade da narrativa comercial depende do diagnóstico prévio

---

## Comportamentos-Chave

- Grupo de WhatsApp com data, contexto e link do Meet antes de cada reunião
- Mensagem de confirmação pela manhã do dia da reunião
- **Anotação sistemática** de novas objeções após cada call
- Treino diário curto de reversão antes das ligações
- Análise prévia do negócio para personalizar proposta

---

## Riscos Identificados

- Sem rotina de confirmação, a taxa de no-show tende a subir
- Sem base de objeções, cada vendedor recomeça do zero
- Sem personalização, a reversão parece script pronto e perde credibilidade

---

## Desdobramentos Práticos

- [ ] Criar playbook de comparecimento com mensagens padronizadas por nicho
- [ ] Estruturar **biblioteca viva de objeções** por nicho
- [ ] Implantar aquecimento diário de 10 min com roleplay
- [ ] Alinhar diagnóstico comercial com análise de presença digital antes da reunião

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Canais CAC Zero — Ligação, Disparo e Follow-up]] | [[Compromissos e Metodologia OAE]]

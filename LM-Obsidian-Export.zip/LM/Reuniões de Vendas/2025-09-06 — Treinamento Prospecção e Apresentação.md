---
data: 2025-09-06
tipo: treinamento-interno
projeto: Comercial
foco: vender a reunião como ativo valioso, apresentação como aula que prova valor
tags: [treinamento, prospecção, apresentação, valor-da-reunião, didática, persuasão]
---

# Treinamento — Prospecção e Estratégias de Apresentação (06/09/2025)

## Foco Central
Vender a reunião como ativo valioso — não apenas agendar horário — e construir apresentação como aula que prova valor.

## Tese Principal
**Quem entende que atenção é moeda muda a forma de prospectar.** A reunião deixa de ser um favor do cliente e passa a ser uma troca de valor. O vendedor que trata a reunião como banal vai ter agenda de péssima qualidade.

---

## Principais Teses

- A reunião é tratada como algo que o cliente **paga com atenção e tempo** — por isso o vendedor precisa fazer esse compromisso parecer valioso
- Prospectar não é pedir um horário, mas elevar a percepção de que **vale parar a agenda para ouvir**
- Há forte tom didático: a apresentação comercial precisa ensinar, abrir os olhos do cliente e tornar a proposta uma consequência lógica
- Prospecção e apresentação são etapas do mesmo raciocínio comercial — não silos separados

---

## Comportamentos-Chave

- Venda explícita do **valor da reunião** antes de confirmar horário
- Benefícios concretos apresentados antes do agendamento
- Didática como ferramenta de persuasão na apresentação
- Plano de ação personalizado ao vivo durante a reunião

---

## Riscos Identificados

- Quando a reunião parece banal, o comparecimento cai
- Quando a apresentação não educa, a proposta vira preço contra preço
- Quando o comercial separa prospecção de venda, a jornada perde coerência

---

## Desdobramentos Práticos

- [ ] Reformular abertura de prospecção com **valor percebido do encontro**
- [ ] Desenhar estrutura de apresentação em formato de aula curta
- [ ] Criar roteiro de benefícios específicos por nicho para "vender a reunião"

---

## Checklist de Aplicação

- [ ] Extrair frases, perguntas ou checkpoints mais fortes do conteúdo
- [ ] Converter aprendizados em playbook ou SOP
- [ ] Treinar o time com roleplay, simulação e escuta crítica
- [ ] Amarrar cada tese a uma métrica observável do funil
- [ ] Revisar semanalmente se o conteúdo foi incorporado ou apenas entendido

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Ignição Comercial — Script de Diagnóstico v2]] | [[Mentoria Nimoto — Fundamentos Comercial]]

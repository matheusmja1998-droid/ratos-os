---
data: 2026-01-22
cliente: Leonardo
segmento: Instalação e manutenção de energia solar
aderência: média (comprador direto) / alta (parceiro estratégico)
tags: [reunião-vendas, solar, parceria, instalação, indicação]
---

# Leonardo (Instalação Solar) — 22/01/2026

## Leitura Executiva

Negócio com forte competência de execução, mas pouca estrutura comercial própria. A oportunidade não está em vender diretamente o modelo de prospecção para a empresa atual, e sim em **usar a rede de relacionamentos do cliente como ponte** para integradoras e parceiros comerciais que precisam de demanda previsível.

---

## Contexto

- Empresa vive de parcerias, indicação e prestação de serviço para outras empresas do setor
- Não investe em CAC, não possui time comercial estruturado
- Interesse em aumentar previsibilidade e talvez criar receitas mais recorrentes
- Visão apresentada adaptou a solução ao papel que ocupa na cadeia

---

## Diagnóstico

- Problema principal: **dependência de terceiros** para geração de obra (não falta de tráfego)
- A conversa foi bem conduzida ao não forçar solução desalinhada e **pivotar para parceria comercial indireta**
- Lead tem valor estratégico alto como conector de mercado, mesmo sem ser o comprador ideal agora

---

## Sinais

- Boa abertura para indicar empresas e participar como ponte de confiança
- Interesse genuíno em entender custo, resultado e modelo
- Possibilidade de parceria futura mais ampla se confiança crescer

---

## Riscos

- Se abordagem for muito vendedora, pode perder a confiança de um possível canal de indicação
- Modelo precisa ser explicado com clareza para evitar percepção de concorrência com os parceiros dele

---

## Oportunidades

- Transformar o cliente em **parceiro indicador qualificado**
- Abrir reuniões com integradoras que tenham mais dor comercial do que ele
- Explorar modelos de comissão, indicação ou mensalidade recorrente no futuro
- Usar a relação com instaladores para mapear gargalos reais do mercado

---

## Próximos Passos

- [ ] Manter follow-up leve e consultivo
- [ ] Solicitar indicações com contexto claro de valor para os parceiros
- [ ] Preparar discurso específico para empresas de solar indicadas por ele
- [ ] Registrar esse contato como **ativo estratégico de networking**

---

> **Conclusão:** Aderência média como comprador direto, mas alta como parceiro de acesso e influência.

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Ignição Comercial — Oferta Completa]]

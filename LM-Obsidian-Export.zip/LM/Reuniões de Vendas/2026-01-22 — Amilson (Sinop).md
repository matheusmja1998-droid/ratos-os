---
data: 2026-01-22
cliente: Amilson
local: Sinop
segmento: Energia solar residencial com expansão para baterias e agro/off-grid
aderência: alta
tags: [reunião-vendas, solar, residencial, SDR, prospecção-ativa]
---

# Amilson (Sinop) — 22/01/2026

## Leitura Executiva

Empresa com boa reputação, forte entrega e baixa insatisfação, mas ainda dependente de orgânico e indicação. Desafio principal: transformar qualidade operacional em **previsibilidade comercial**, especialmente em mercado afetado por concorrência desleal e ausência de processo estruturado de aquisição.

---

## Contexto

- Foco em residencial; intenção de ampliar para baterias e agro/off-grid
- Aquisição atual baseada em Google orgânico e indicação
- Mercado local pressionado por concorrentes de preço e baixa qualidade
- Proposta apresentada: SDRs, treinamento e onboarding de **60 dias**

---

## Diagnóstico

- Negócio tem credibilidade suficiente para sustentar canal ativo de prospecção
- Falta previsibilidade e ritmo de geração de visitas qualificadas
- Ausência de CAC estruturado → baixa clareza sobre eficiência comercial real
- O projeto resolve problema de **aquisição e organização**, não de entrega técnica

---

## Sinais

- Entende o valor de aumentar volume sem depender de sorte ou indicação
- Modelo com garantia e transferência futura de autonomia tende a gerar confiança
- Processo decisório compartilhado com sócio → ciclo um pouco mais longo

---

## Riscos

- Possível resistência ao investimento inicial sem prova rápida
- Mercado local pode exigir abordagem muito bem calibrada para fugir da guerra de preço
- Sem critério de qualificação, time pode gerar visitas sem aderência ao ticket ideal

---

## Oportunidades

- Focar prospecção em segmentos locais com consumo energético claro e necessidade latente
- Formalizar CAC, taxa de visita e taxa de fechamento para gestão real
- Usar reputação e qualidade como diferencial contra concorrentes oportunistas
- Criar ponte entre residencial atual e novas frentes sem dispersar comunicação

---

## Próximos Passos

- [ ] Enviar materiais e proposta para validação do sócio
- [ ] Modelar ICP prioritário para primeira leva de prospecção
- [ ] Definir metas de visitas qualificadas e prazo de rampagem do SDR
- [ ] Planejar transferência gradual para operação interna após os 60 dias

---

> **Conclusão:** Aderência alta. O cenário é favorável para implantação, desde que a proposta deixe claro o caminho entre geração de visita e fechamento com qualidade.

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[Ignição Comercial — Oferta Completa]]

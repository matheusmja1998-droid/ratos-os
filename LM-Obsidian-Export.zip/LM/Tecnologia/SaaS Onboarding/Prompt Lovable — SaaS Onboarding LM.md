---
tipo: prompt-lovable
projeto: SaaS Onboarding LM
data_criação: 2026-05-05
status: pronto pra colar na Lovable
admin_seed: matheusmja1998@gmail.com
domínio: a definir
tags: [saas, lovable, onboarding, lm, formulário, ignição-comercial]
---

# Prompt Lovable — SaaS de Onboarding LM Agência

Prompt completo pra colar na Lovable e gerar o SaaS de onboarding da LM. Inclui módulo de Pesquisa Diagnóstica (formulário cliente) + Dashboard Admin pra Matheus e Valentino.

## Como usar

1. Acessa lovable.dev
2. Cria projeto novo: "SaaS Onboarding LM"
3. Cola o prompt da seção abaixo no input inicial
4. Espera ela gerar
5. Conecta com banco Supabase nativo da Lovable quando ela pedir
6. Testa fluxo end-to-end com cliente exemplo Synergy
7. Quando tiver domínio definido, aponta DNS

---

## PROMPT (copiar tudo abaixo)

```
Crie um SaaS de gestão de onboarding de clientes para a LM Agência (consultoria comercial brasileira focada em estruturação de prospecção ativa para integradoras de energia solar). O sistema vai centralizar todo o processo pós-fechamento de venda, começando pelo módulo de Pesquisa Diagnóstica (formulário extenso que o cliente preenche) e crescendo para outros módulos no futuro.

## VISÃO DO PRODUTO

Esse SaaS vai ser usado em duas frentes:

1. Lado do cliente (público): acessa um link único e responde a Pesquisa Diagnóstica pra LM mapear sua empresa antes da reunião de onboarding.

2. Lado da LM (admin): dashboard interno onde Matheus e Valentino veem todos os clientes, status de onboarding, respostas, anexos, e gerenciam o pipeline de implementação.

A arquitetura precisa ser pensada pra crescer: hoje começa com o módulo Pesquisa, mas em breve terão módulos de Cronograma de Implementação, Tracking de Métricas (visitas qualificadas, ligações, conversões), Biblioteca de Scripts/Playbooks, e Dashboard de Resultados pro cliente.

## STACK TÉCNICA

- Next.js 14 (App Router) + React + TypeScript
- Tailwind CSS + Shadcn/ui
- Banco de dados: Supabase nativo da Lovable (não configurar externo)
- Autenticação: Supabase Auth (admin com email/senha; cliente acessa por link tokenizado sem login)
- React Hook Form + Zod
- Lucide icons
- Framer Motion pra animações suaves

## IDENTIDADE VISUAL

- Cores: preto (#0A0A0A), branco (#FFFFFF), accent verde-elétrico (#10B981)
- Tipografia: Inter ou Geist
- Estilo: Linear/Vercel — minimalista, espaçoso, profissional
- Cards rounded-2xl, sombras sutis, gradientes apenas em CTAs principais
- Mobile-first
- Logo: gerar versão tipográfica simples "LM" (duas letras grandes em peso bold, espaçamento generoso) — vou substituir por logo final depois

## ESTRUTURA DE ROTAS

### Público (sem login)
- / — landing simples explicando o que é o onboarding LM (1 frase do destino + CTA "Acessar meu link")
- /p/[token] — página de pesquisa diagnóstica acessada por token único enviado pro cliente

### Admin (autenticado)
- /admin/login — login com email + senha
- /admin — dashboard com lista de clientes
- /admin/clientes — gestão de clientes
- /admin/clientes/novo — criar cliente novo (gera token de pesquisa)
- /admin/clientes/[id] — detalhes do cliente, respostas, anexos, status
- /admin/configuracoes — usuários admin, configurações gerais

## MODELO DE DADOS (Supabase)

Tabela `clientes`:
- id (uuid pk)
- created_at, updated_at
- nome_empresa (text)
- razao_social (text)
- cnpj (text)
- nicho (text default 'integradora-solar')
- contato_principal_nome (text)
- contato_principal_cargo (text)
- contato_principal_email (text)
- contato_principal_whatsapp (text)
- gestor_comercial_nome (text)
- gestor_comercial_email (text)
- gestor_comercial_whatsapp (text)
- token_pesquisa (text unique) — token único pra acessar o formulário
- status_onboarding (enum: 'pesquisa_pendente', 'pesquisa_em_andamento', 'pesquisa_concluida', 'onboarding_agendado', 'em_implementacao', 'concluido', 'arquivado')
- data_onboarding_agendada (timestamp)
- valor_contrato (numeric)
- responsavel_lm (text) — Matheus ou Valentino

Tabela `pesquisas_diagnosticas`:
- id (uuid pk)
- cliente_id (fk clientes)
- created_at, updated_at, submitted_at
- status (enum: 'rascunho', 'enviada')
- bloco_1_saude (jsonb)
- bloco_2_time (jsonb) — inclui array de vendedores
- bloco_3_prospeccao (jsonb)
- bloco_4_crm (jsonb)
- bloco_5_estrategia (jsonb)
- bloco_6_gestor (jsonb)
- observacoes_finais (text)

Tabela `anexos_pesquisa`:
- id (uuid pk)
- pesquisa_id (fk pesquisas_diagnosticas)
- created_at
- nome_arquivo (text)
- url (text) — Supabase Storage
- tamanho_bytes (int)
- tipo (text)

Tabela `usuarios_admin`:
- id (uuid pk, vinculado a auth.users)
- email
- nome
- role (enum: 'super_admin', 'consultor')
- created_at

Tabela `eventos_cliente` (timeline auditável):
- id (uuid pk)
- cliente_id (fk)
- tipo (enum: 'cliente_criado', 'token_gerado', 'pesquisa_iniciada', 'pesquisa_enviada', 'onboarding_agendado', 'status_alterado', 'nota_adicionada')
- payload (jsonb)
- usuario_id (fk usuarios_admin, nullable)
- created_at

Storage bucket: `anexos-pesquisa`. Path: `{cliente_id}/{timestamp}-{filename}`. Limite 10MB por arquivo, máximo 5 arquivos por pesquisa.

## MÓDULO 1 — PESQUISA DIAGNÓSTICA (CLIENTE)

Acesso via /p/[token]. Sem login. Token criado automaticamente quando admin cria cliente.

### Página de boas-vindas
- Logo LM + tagline "Onboarding Ignição Comercial"
- "Olá, [nome do contato]! Bem-vindo ao onboarding da LM."
- Texto: "Esse formulário vai nos ajudar a desenhar o melhor projeto pra [nome da empresa]. Tempo estimado: 25 a 35 minutos. Pode pausar e voltar a qualquer momento — suas respostas ficam salvas."
- Botão: "Começar"

### Formulário em 6 blocos

Cada bloco é uma página com transição suave (Framer Motion). Barra de progresso fixa no topo: "Bloco X de 6 — [Nome]". Botões "Voltar" e "Próximo" fixos no rodapé. Auto-save no banco a cada mudança de campo (debounce 2s).

#### BLOCO 1 — Saúde da operação

1.1. Faturamento mensal médio últimos 6 meses [texto, placeholder "Ex: entre R$300k e R$450k"]

1.2. Ticket médio por venda [3 campos numéricos, máscara R$]:
- Residencial
- Comercial
- Outro (rural/industrial, opcional)

1.3. Vendas por mês últimos 3 meses [3 campos numéricos]:
- Residencial
- Comercial
- Outro

1.4. Margem de lucro líquida atual [radio]:
- Abaixo de 5%
- Entre 5% e 10%
- Entre 10% e 15%
- Entre 15% e 20%
- Acima de 20%
- Não sei / preciso confirmar com o dono

1.5. % do faturamento por canal (validar soma = 100%):
- Indicação
- Prospecção ativa do time
- Tráfego pago / redes sociais
- Outros (input texto + numérico)

1.6. Ciclo médio de venda [radio]:
- Menos de 7 dias / Entre 7-15 / Entre 15-30 / Entre 30-60 / Mais de 60 dias

#### BLOCO 2 — Time comercial

2.1. Vendedores [campo repetível, botão "+ Adicionar vendedor"]:
Para cada:
- Nome
- Função [Closer / SDR / Gerente / Técnico que vende / Outro]
- Regime [PJ 100% comissionado / PJ fixo+comissão / CLT]
- Tempo de empresa
- Faturamento médio últimos 3 meses (R$)
- Horas/dia disponíveis pra prospecção [1h / 2h / 3-4h / Full time]
- Outras atividades por fora? [Não / Sim, qual]
- Complexidade de venda atendida [checkbox múltiplo]:
  - Residencial até R$25k
  - Residencial qualquer ticket
  - Comercial pequeno (até R$80k)
  - Comercial médio (R$80k a R$300k)
  - Comercial grande / usina (acima R$300k)
  - Sistema híbrido com armazenamento
  - Eletroposto / soluções complexas
  - Rural / industrial

2.2. Quem é o melhor performer? Por quê? [textarea]
2.3. Quem é o pior performer? Por quê? [textarea]
2.4. Quem vai abraçar mais rápido o método? [textarea]
2.5. Quem vai resistir mais? [textarea]

#### BLOCO 3 — Como prospectam hoje

3.1. Como cada vendedor prospecta hoje? [checkbox múltiplo]:
- PAP, Ligação fria, Ligação pra indicação, WhatsApp frio, WhatsApp indicação, Redes sociais, Inbound, Outro

3.2. Vocês têm script de prospecção atual? [radio]:
- Sim, vou mandar / Tem mas não formalizado / Não tem

3.3. Já tem lista de empresas trabalhada? [radio]:
- Sim organizada / Sim espalhada / Não

3.4. Segmentos comerciais já vendidos [checkbox múltiplo]:
- Supermercado, Açougue/mercado pequeno, Posto, Academia, Restaurante, Hotel/pousada, Padaria, Loja varejo, Indústria pequena, Clínica, Igreja, Escola/creche, Outros

3.5. Segmentos nunca tentados mas promissores [textarea]
3.6. Regiões cobertas hoje [textarea]
3.7. Onde têm mais autoridade local [textarea]
3.8. Cases fortes pra prova social [textarea, placeholder "Empresa, segmento, problema, resultado"]

#### BLOCO 4 — CRM e ferramentas

4.1. Qual CRM usam [radio]:
- RD Station / Pipedrive / HubSpot / Kommo / Bitrix / Planilha / Outro

4.2. Vendedores têm acesso ao CRM? [radio]:
- Todos têm e preenchem / Todos têm mas só alguns preenchem / Só alguns têm acesso / Ninguém preenche direito

4.3. Campos preenchidos hoje [checkbox múltiplo]:
- Nome, Telefone, Origem, Etapa do funil, Anotações, Próximo passo, Valor estimado, Motivo de perda, Outro

4.4. Como sabe se vendedor bateu meta [radio]:
- Relatório CRM / Planilha por mim / Planilha pelo vendedor / Não tem como saber / Outro

4.5. Plano de telefone dos vendedores [radio]:
- Empresa fornece celular+plano / Empresa fornece chip+ajuda / Vendedor usa próprio celular / Outro

#### BLOCO 5 — Estratégia e contexto

5.1. Faturamento meta dos próximos 6 meses [texto]
5.2. Quantas vendas em CLIENTE COMERCIAL/mês querem fechar [numérico]
5.3. Meta de margem [texto]

5.4. Sazonalidade [dois conjuntos de checkboxes mutuamente exclusivos]:
- Meses fortes: Jan/Fev/Mar/Abr/Mai/Jun/Jul/Ago/Set/Out/Nov/Dez
- Meses fracos: Jan/Fev/Mar/Abr/Mai/Jun/Jul/Ago/Set/Out/Nov/Dez

5.5. Concorrentes diretos na região [textarea]
5.6. Pica-fios — empresas específicas e agressivas em preço? [textarea]

5.7. Obra grande nos próximos 45 dias? [radio]:
- Não, time disponível / Sim mas dá pra conciliar / Sim vai atrapalhar (qual obra)

5.8. Férias/feriado/evento que afeta cronograma [textarea]

#### BLOCO 6 — Sobre o gestor comercial (quem responde)

6.1. Há quanto tempo na empresa [texto]

6.2. Background antes [radio]:
- Vendedor solar / Vendedor outro setor / Gestor comercial outra empresa / Técnico / RH-administrativo / Outro

6.3. Autonomia operacional [radio]:
- Total / Parcial (decisões grandes pelo dono) / Tudo passa pelo dono / Outro

6.4. Como se comunica com o time [radio]:
- Daily de manhã / Reunião semanal / Só WhatsApp grupo / Só individual / Outro

6.5. Maior dor da operação na visão do gestor [textarea]

#### Página final — Antes de enviar

- O que a LM precisa saber que não foi perguntado [textarea]
- Documentos pra mandar junto [textarea + drag-and-drop upload, máx 5 arquivos × 10MB, PDF/Excel/Word]

Botão: "Enviar respostas"

#### Página de confirmação
- Animação check verde
- "Recebemos tuas respostas, [nome]. A gente analisa e te encontra na onboarding marcada pra [data]. Qualquer coisa antes, chama no WhatsApp."

### Funcionalidades transversais do formulário

- Auto-save no banco a cada mudança (debounce 2s) — não precisa localStorage, vai direto pro Supabase via token
- Barra de progresso no topo + tempo estimado restante
- Botão "Pausar e continuar depois" envia email com link de retorno (mesmo token, abre onde parou)
- Validação inline (campo vermelho + mensagem)
- Mobile responsivo perfeito
- Tom de voz: direto, "tu" em vez de "você", sem corporativês

## MÓDULO 2 — DASHBOARD ADMIN (LM)

### /admin/login
Login com email + senha (Supabase Auth). Redireciona pra /admin após autenticar.

### /admin — Dashboard principal
- Cards no topo com métricas:
  - Total de clientes ativos
  - Pesquisas pendentes (cliente ainda não respondeu)
  - Pesquisas concluídas aguardando análise
  - Onboardings agendados nos próximos 7 dias
- Lista de clientes recentes (últimos 10) com status visual
- Ações rápidas: "Novo cliente", "Buscar cliente"

### /admin/clientes — Lista completa
- Tabela com filtros (status, responsável LM, data) e busca
- Colunas: Empresa, Contato, Status, Data onboarding, Responsável LM, Ações
- Status com badge colorido
- Click na linha → vai para detalhes

### /admin/clientes/novo — Criar cliente
Formulário pra cadastrar cliente novo. Quando salva:
- Gera token único pra pesquisa
- Cria registro em clientes com status pesquisa_pendente
- Cria registro vazio em pesquisas_diagnosticas com status rascunho
- Mostra modal com link tokenizado pra copiar e mandar pro cliente
- Botão pra copiar link
- Botão pra mandar via WhatsApp (abre wa.me com mensagem template)

### /admin/clientes/[id] — Detalhes
Layout em abas:

Aba 1 — Resumo:
- Dados da empresa e contato
- Status atual com botão pra mudar
- Link da pesquisa (copiar)
- Data do onboarding agendada (editável)
- Valor do contrato
- Responsável LM
- Botão "Adicionar nota"

Aba 2 — Pesquisa diagnóstica:
- Todas as respostas formatadas em accordions por bloco
- Bloco 2 (vendedores) renderiza como tabela com 1 linha por vendedor
- Botão "Exportar PDF" — gera PDF formatado das respostas
- Anexos da pesquisa (download individual ou em zip)

Aba 3 — Timeline:
- Lista cronológica reversa de eventos do cliente
- Cada evento mostra tipo, data, autor, payload relevante

Aba 4 — Notas:
- Notas internas do time LM sobre o cliente (privadas)
- Editor markdown simples

### /admin/configuracoes
- Lista de usuários admin (Matheus, Valentino, futuros consultores)
- Adicionar usuário (envia convite por email)
- Configuração de roles

## ARQUITETURA PRA ESCALAR (FUTURO)

Estrutura o código pensando que vão entrar mais módulos:

- /app/admin/clientes/[id]/cronograma — módulo futuro de cronograma de implementação
- /app/admin/clientes/[id]/metricas — módulo futuro de tracking de métricas (visitas qualificadas, ligações, vendas)
- /app/admin/biblioteca — módulo futuro de scripts e playbooks reutilizáveis
- /app/c/[token]/dashboard — futuro dashboard pro cliente acompanhar resultados

Não precisa criar tudo agora, só DEIXAR ESPAÇO na estrutura de pastas e na navegação (sidebar com itens "Em breve" desabilitados pros futuros módulos).

## DETALHES UX QUE FAZEM DIFERENÇA

1. Animações suaves entre páginas (fade + slide leve)
2. Skeleton loaders enquanto carrega dados
3. Toast de feedback em todas as ações (salvou, erro, copiou)
4. Modo escuro nativo (toggle no admin)
5. Atalhos de teclado no admin (cmd+k busca global)
6. No formulário do cliente, salvar visualmente "última vez salvo às 14:32"
7. Email automático pro cliente quando começa pesquisa (template), 24h depois lembrando se não terminou, e pra LM quando cliente envia
8. PDF da pesquisa com layout limpo, identidade da LM, pronto pra arquivar

## CONFIGURAÇÕES INICIAIS (SEED)

Cria automaticamente:
- Usuário admin: matheusmja1998@gmail.com com senha temporária mostrada na tela
- Cliente exemplo: "Synergy Soluções em Energia" com dados básicos preenchidos pra testes
  - Razão social: Synergy Soluções em Energia
  - CNPJ: 32.366.610/0001-08
  - Contato: Flávio Narezzi de Oliveira (sócio-administrador)
  - Gestor comercial: Fabrício Coletti
  - Nicho: integradora-solar
  - Cidade: Tangará da Serra/MT
- Token de pesquisa gerado pra Synergy

## TONE OF VOICE

Texto sempre direto, "tu" em vez de "você" no lado público, sem corporativês. No admin pode ser mais técnico mas mantém a clareza.

Exemplos:
- Lado cliente: "Tempo estimado: 25 a 35 minutos. Pode pausar quando quiser."
- Lado cliente: "Quem do time tu acha que vai abraçar mais rápido o método?"
- Lado admin: "Cliente aguardando resposta da pesquisa há 3 dias"
- Lado admin: "Pesquisa concluída — pronta pra análise"

## ENTREGA FINAL

Aplicação rodando com:
- Banco Supabase configurado e populado com tabelas
- Pesquisa funcionando end-to-end (cliente preenche, salva, admin vê)
- Admin com autenticação, dashboard, gestão de clientes
- Cliente exemplo Synergy criado pra testes
- Deploy em URL pública (vou apontar domínio depois)
- README explicando como adicionar usuários e estrutura pra crescimento

Foca em qualidade visual e UX. É melhor ter um módulo funcionando perfeito do que vários módulos meia-boca.
```

---

## Configurações que tu confirmou

- **Email admin seed:** matheusmja1998@gmail.com
- **Domínio:** sem por enquanto (Lovable vai gerar URL temporária, tu aponta domínio depois)
- **Logo:** "LM" tipográfico simples gerado pela Lovable (substituir depois)
- **Cliente exemplo seed:** Synergy Soluções em Energia (com dados que tu já tem)

## O que fazer agora

1. Acessa lovable.dev
2. Cria projeto novo: nome "SaaS Onboarding LM"
3. Copia tudo dentro do bloco entre as três crases ``` acima
4. Cola no input inicial da Lovable
5. Espera ela gerar (5-15 minutos)
6. Quando ela perguntar sobre Supabase, autoriza ela criar instância nativa
7. Testa o fluxo: cria um cliente fake, copia o link, abre em aba anônima e preenche
8. Quando estiver tudo OK, marca pra apontar domínio depois

## Custos esperados (Lovable)

- Plano grátis: pode rodar pra testar
- Plano pago: ~$25/mês depois pra deploy permanente + domínio personalizado

## Próximos módulos (já planejados na arquitetura)

1. **Cronograma de Implementação** — onde define semana a semana o que vai entregar pra cada cliente
2. **Tracking de Métricas** — dashboard pro cliente ver quantas visitas qualificadas, ligações, vendas
3. **Biblioteca de Scripts e Playbooks** — reusar conteúdo entre clientes
4. **Dashboard do Cliente** — área logada pro cliente acompanhar resultado em tempo real

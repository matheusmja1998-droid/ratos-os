# Listas de Cidades para Extração de Leads — por BDR
### Cidades 100k+ hab · prontas pra extração (Apify / Google Maps) e subida no CRM

> Termo de busca sugerido na extração: **"energia solar [cidade]"** ou **"integradora solar [cidade]"**.
> Cada BDR tem sua macrorregião. Extrair, qualificar (3+ vendedores = ICP) e subir na pipe do BDR no Kommo.

---

## AMANDA — Nordeste

```
Natal - RN
Mossoró - RN
Parnamirim - RN
Fortaleza - CE
Caucaia - CE
Juazeiro do Norte - CE
Sobral - CE
Recife - PE
Caruaru - PE
Petrolina - PE
```

---

## GREICE — Centro-Oeste

```
Goiânia - GO
Aparecida de Goiânia - GO
Anápolis - GO
Rio Verde - GO
Luziânia - GO
Cuiabá - MT
Várzea Grande - MT
Rondonópolis - MT
Sinop - MT
Campo Grande - MS
Dourados - MS
Brasília - DF
```

---

## THIAGO CARDOSO — Rio Grande do Sul

```
Caxias do Sul - RS
Bento Gonçalves - RS
Passo Fundo - RS
Santa Cruz do Sul - RS
Guaíba - RS
Porto Alegre - RS
Canoas - RS
Gravataí - RS
Novo Hamburgo - RS
São Leopoldo - RS
Pelotas - RS
Santa Maria - RS
Rio Grande - RS
Uruguaiana - RS
```

---

## VALENTINO — Santa Catarina + São Paulo (interior)

```
Joinville - SC
Florianópolis - SC
Blumenau - SC
São José - SC
Itajaí - SC
Chapecó - SC
Jaraguá do Sul - SC
Balneário Camboriú - SC
Criciúma - SC
Lages - SC
Brusque - SC
Tubarão - SC
Campinas - SP
Ribeirão Preto - SP
São José do Rio Preto - SP
Sorocaba - SP
Bauru - SP
Piracicaba - SP
Presidente Prudente - SP
Araçatuba - SP
```

---

## RESUMO

| BDR | Estados | Nº de cidades |
|---|---|---|
| Amanda | RN, CE, PE | 10 |
| Greice | GO, MT, MS, DF | 12 |
| Thiago Cardoso | RS | 14 |
| Valentino | SC, SP | 20 |
| **Total** | | **56 cidades** |

---

## PASSO A PASSO DA OPERAÇÃO

1. **Extrair** — rodar Apify/Google Maps Scraper com termo "energia solar [cidade]" pra cada cidade da lista do BDR
2. **Qualificar** — manter só integradora real (não só "mão de obra"), priorizar quem tem avaliações no Google e indício de time (3+ vendedores)
3. **Subir no CRM** — importar na pipe do BDR no Kommo (cada um na sua)
4. **Trabalhar** — prospectar seguindo o script de 3 etapas, na cadência de follow-up

*Montado em 03/06/2026 · cidades 100k+ das regiões de alta/média oportunidade (sem Norte, sem residencial popular)*

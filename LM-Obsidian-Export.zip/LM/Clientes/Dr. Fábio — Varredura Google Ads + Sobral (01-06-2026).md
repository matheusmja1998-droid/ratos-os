---
cliente: Dr. Fábio Freire
empresa: Clínica IOT — Instituto de Ortopedia e Traumatologia
segmento: Saúde / Ortopedia
cidade: Varginha/MG
projeto: Google Ads — Varredura + Sugestões Sobral
tipo: varredura-sugestoes
data: 2026-06-01
status: ativo
acesso: API Google Ads (Basic Access) via MCC 211-072-5388
periodo: LAST_30_DAYS
tags: [cliente, lm, google-ads, sobral, ortopedia, varginha, dr-fabio, varredura]
baseline: "[[Dr. Fábio — Auditoria Google Ads + Plano Sobral (14-05-2026)]]"
---

# Dr. Fábio — Varredura Google Ads + Sobral (01/06/2026)

**Conta:** 522-301-5558 · **Período:** últimos 30 dias · **Via:** API (Basic Access destravado hoje)

---

## 0. A verdade que pula aos olhos: o Bloco A não foi executado

Na auditoria de 14/05 o Matheus **aprovou 3 ações** (Bloco A). 18 dias depois, **nenhuma rodou**:

| Ação aprovada em 14/05 | Estado em 01/06 |
|---|---|
| Criar campanha de Marca dedicada (R$10/dia) | ❌ Não existe — só as 2 campanhas antigas |
| Subir verba da Search de R$30 → R$50/dia | ❌ Ainda em R$30/dia |
| Subir novos RSAs (7 fatores Sobral) | ❌ Mesmos anúncios genéricos |

Ou seja: a conta está **congelada no mesmo lugar de 18 dias atrás**. As sugestões abaixo reforçam e atualizam aquele plano com os dados novos.

---

## 1. Estado atual (30 dias)

| Métrica | Valor | Leitura |
|---|---|---|
| Campanhas ativas | 1 (Search) + 1 Pmax pausada | enxuta demais |
| Investimento | R$ 595,62 | ~R$ 20/dia efetivo (budget R$30 não está sendo gasto todo) |
| Cliques | 208 | — |
| Impressões | 2.652 | baixo → limitada por orçamento |
| CTR | 7,84% | ✅ saudável (Sobral espera 3,5–5%) |
| CPC médio | R$ 2,86 | ✅ ok |
| Conversões | 18 | — |
| Custo/conversão | **R$ 33,09** | 🟡 subiu vs R$24 de 14/05 (ainda dentro da meta R$30–35) |
| Negativas configuradas | **0** | 🔴 crítico |
| Campanha de marca | inexistente | 🔴 |

**Comparação com 14/05:** CPA subiu de R$24 → R$33. Continua aceitável, mas o gargalo segue sendo **estrutura + volume**, não lance.

---

## 2. Os 5 vazamentos de dinheiro (dados de search terms — 30d)

A conta tem **0 palavras negativas**. Resultado, pelos termos de pesquisa reais:

### 2.1 Pagando por concorrente: "clínica fort varginha"
- `clínica fort varginha` + variações = **~R$ 54** gastos, 1 conversão duvidosa
- Fort é concorrente. Sobral [L323]: negativar concorrente que não converte ou bloqueia margem.

### 2.2 Pagando por outros médicos (concorrentes pessoais)
Termos que dispararam e gastaram sem retorno:
- `dr henrique procopio varginha` R$ 7,99 · 0 conv
- `dr plinio ortopedista varginha` R$ 4,95 · 0 conv
- `dr jesse ortopedista varginha` + telefone R$ 6,60 · 0 conv
- `eduardo corujinha varginha` R$ 1,24 · 0 conv
- `ortopedista eloi mendes` R$ 2,05 · 0 conv (Eloi Mendes é outra cidade)

### 2.3 Marca dele rodando DENTRO da genérica (sem campanha de marca)
- `iot varginha` R$ 61,81 (o termo mais caro da conta!) · 1 conv
- `clinica iot varginha` + variações ~R$ 35 · 0 conv
- `dr fábio freire ortopedista` + avaliações ~R$ 20 · 0 conv

Isso é busca de MARCA pagando preço de descoberta, competindo orçamento com a prospecção. Sobral [L365]: marca é campanha separada, lance baixo, CPC ~R$1,50. Hoje está pagando R$2-3 por clique no próprio nome.

### 2.4 Plano de saúde que talvez nem atenda
- `ortopedista varginha unimed` R$ 25,46 · 1 conv
- `ortopedista unimed varginha` R$ 4,37 · 1 conv
- **Confirmar com Dr. Fábio:** atende Unimed? Se não, negativar `unimed`. Se sim, criar ad group de convênio.

### 2.5 Buscas informacionais / fora de escopo
- `quiropraxista varginha` R$ 5,11 · 0 conv (quiropraxia ≠ ortopedia)
- `como curar bursite no ombro`, `como curar fascite plantar` — buscas de "como", baixa intenção comercial

**Total estimado de desperdício mensal: ~R$ 100–120** indo pra termo que não vira paciente.

---

## 3. Sugestões de melhoria (priorizadas pelo método Sobral)

### 🔴 PRIORIDADE 1 — Adicionar lista de negativas (fazer hoje, 5 min)
A conta tem ZERO negativas. É o maior buraco. Subir em massa:

**Concorrentes (pessoais e clínicas):**
```
-"clinica fort"  -"clínica fort"  -fort
-"dr henrique"  -"dr henrique procopio"  -"procopio"
-"dr plinio"  -"dr plínio"
-"dr jesse"  -"dr jessé"
-"eduardo corujinha"  -corujinha
-"dr ricardo"  -"dr eduardo"  -"dr ernani"
-"eloi mendes"  -"elói mendes"
-fisiocenter  -fisiocorpus
```
**Informacional / fora de escopo:**
```
-quiropraxia  -quiropraxista  -"como curar"  -"como tratar"
-grátis  -gratis  -gratuito  -"de graça"
-sus  -emprego  -vaga  -concurso  -salário  -crm  -faculdade  -curso
-exercício  -exercicios  -caseiro  -"em casa"
```
**Convênio (CONFIRMAR antes):**
```
-unimed  -hapvida   ← só negativar se o Dr. Fábio NÃO atende esses planos
```

### 🔴 PRIORIDADE 2 — Criar campanha de Marca dedicada (era Bloco A, segue pendente)
- R$ 10/dia, Maximizar Cliques, teto CPC R$ 1,50, só rede de Pesquisa
- Move `iot varginha`, `clinica iot`, `dr fábio freire` etc. pra cá → tira R$ ~100/mês de busca de marca de dentro da genérica e domina a SERP do nome dele barato
- Keywords + RSA + extensões já prontos no doc de 14/05 (seção 5.1)

### 🟡 PRIORIDADE 3 — Subir verba da Search genérica (gradual)
- O budget é R$30/dia mas o gasto real dá ~R$20/dia → a campanha **nem está usando o teto atual** de forma consistente. Antes de subir pra R$50, vale checar por que não gasta tudo (provável: poucas keywords com volume + match types restritivos). 
- Recomendação: primeiro destravar volume (negativas limpam o leilão + adicionar match types broad monitorados nas campeãs), depois subir budget.

### 🟡 PRIORIDADE 4 — Match types das campeãs
Keywords que mais convertem hoje:
- `clínica ortopédica varginha` (PHRASE) — 6 conv, R$184 → a melhor da conta
- `ortopedista em varginha` (BROAD) — 3 conv
- `ortopedista varginha` (BROAD/EXACT) — 5 conv somadas

As broad estão funcionando MAS sem negativas elas são o cano por onde vaza dinheiro de concorrente. Com a lista de negativas da Prioridade 1, dá pra manter broad com segurança. Sobral [L323].

### 🟢 PRIORIDADE 5 — Pausar keywords zumbis
Há ~50 keywords com 0 impressão em 30 dias (especialidades em exact/phrase que nunca disparam). Não custam dinheiro, mas poluem. Limpeza opcional. `ortopedista esportivo` já está com 0 em todos os matches → pausar.

### 🟢 PRIORIDADE 6 — Tracking de conversão (verificar)
Em 14/05 o diagnóstico apontou 3 dos 4 tipos de conversão sem registro recente. As 18 conversões de agora vêm de qual ação? Vale confirmar que o que conta como "conversão" é lead real (WhatsApp/agendamento) e não pageview. Sem isso, otimizar por CPA é otimizar no escuro.

---

## 4. Quality Gates Sobral — onde está hoje

| Métrica | 14/05 | 01/06 | Bom (Sobral) | Status |
|---|---|---|---|---|
| CTR | 9,86% | 7,84% | 3,5–5% | ✅ ainda ótimo (caiu um pouco) |
| CPA | R$24,26 | R$33,09 | R$30–80 | ✅ ok (subiu) |
| CPC | R$2,55 | R$2,86 | nicho | ✅ |
| Negativas | poucas | **ZERO** | lista densa | 🔴 piorou |
| Campanha de marca | inexistente | inexistente | obrigatória | 🔴 |
| Verba mensal | ~R$900 | ~R$600 efetivo | mín R$1.200 local | 🔴 abaixo do piso |
| Impression share | limitada | limitada | ≥80% | 🔴 |

---

## 5. Resumo executivo pro Matheus

A conta não andou desde 14/05. Três coisas resolvem 80% do problema, em ordem:

1. **Subir negativas hoje** (conta tem ZERO — está pagando pra Fort, pra Dr. Plínio, pra Dr. Jessé, pra quiropraxista). ~R$100/mês de vazamento. 5 minutos de trabalho.
2. **Criar a campanha de Marca** que já estava aprovada. R$10/dia tira a busca do próprio nome de dentro da genérica.
3. **Confirmar com o Dr. Fábio:** atende Unimed/Hapvida? E o que está sendo contado como conversão?

Depois disso (e só depois), subir verba faz sentido.

---

## 5.1 EXECUTADO em 01/06/2026 (via API)

- ✅ **41 negativas** adicionadas na Search genérica (concorrentes Fort/Plínio/Jessé/Corujinha/Henrique/Eloi + informacional + quiropraxia + grátis/emprego/curso). **Unimed e Hapvida NÃO foram negativados** — confirmado com o Matheus que o Dr. Fábio atende os dois.
- ✅ **Campanha de Marca criada:** `02 - [MARCA] - [DR FÁBIO + IOT]`, ID `23903752258`, R$10/dia, **PAUSADA** (revisar e ativar). Ad group `Marca - Dr. Fábio + IOT` (ID `197145002396`), CPC teto R$1,50.
  - **25 keywords** de marca (exatas + frase). Várias precisaram de exceção de política `HEALTH_IN_PERSONALIZED_ADS` (nome de médico + saúde) — subidas com `exempt_policy_violation_keys`.
  - **1 RSA** (15 headlines + 4 descriptions), URL `drfabiofreire.com.br/?utm_campaign=marca`, path `/dr-fabio-freire`.
- ✅ **RSA da Marca:** URL final `https://www.drfabiofreire.com.br/` (com www, sem UTM, conforme print do Matheus). Sem o símbolo ★ (Google proíbe — política SYMBOLS); trocado por "5 Estrelas".
- ✅ **4 sitelinks** criados (todos pro domínio principal, com `utm_content` diferente pra rastrear qual converte): Especialidades, Sobre o Dr. Fábio, Agendar Online, Avaliações.
- ❌ **Sem extensão de chamada (telefone)** — Matheus não quis.
- ⏳ **Pendente:** ativar a campanha de Marca (está PAUSADA pra revisão). Extensão de **local (Google Meu Negócio)** ainda não linkada — GMB: ortopedista em Varginha (link salvo no histórico). Subir verba da genérica fica pra depois das negativas assentarem.
- **Conversão confirmada:** clique no botão de WhatsApp + envio de formulário = conversão (lead real, não pageview). Otimização por CPA é válida.

## 5.2 EXECUTADO em 01/06 — Anúncios da Search genérica

Problema central: os 13 RSAs eram **quase idênticos** (mesmos headlines/descrições genéricos nos 3 ad groups). Violava "bolo de cenoura" [L315] e "anúncio é filtro" [L372].

Ações (todas via API, RSAs novos **ATIVOS**):
- ❌ **Pausados 2 anúncios POOR** ativos (`797259056360`, `797148490272`) + 1 AVERAGE fraco (`797180451079`, CTR 5,4%) pra abrir espaço (limite de 3 RSA ativos/ad group).
- ✅ **Ortopedista Varginha** — RSA novo "Ortopedista em Varginha" (7 fatores: Situação "Você há +30 dias com dor?", Crença "Não é receita genérica"). Convive com os 2 GOOD que já performavam.
- ✅ **Dores Específicas** — RSA novo "Dor no Joelho Que Não Passa?" (foco em Situação/dor + Conhecimento "Cirurgia ou tratamento?").
- ✅ **Especialidades** — RSA novo "Especialista em Joelho" (por área + Crença "Cirurgia só se necessária").

Todos com URL `https://www.drfabiofreire.com.br/`, sem ★ (política SYMBOLS), paths `/ortopedista/varginha`, `/dores/varginha`, `/especialidades/varginha`.

⚠️ **Pendência de conteúdo:** o "997+ Pacientes Satisfeitos" dos anúncios antigos parece placeholder — confirmar número real com o Dr. Fábio. Os novos usam "Avaliações 5 Estrelas" sem número cravado.

## 6. Referências do método
- [L323] Negativas, intenção, match types
- [L365] Stack, campanha de marca, geo
- [L372] Anúncio é filtro, 7 fatores
- [L374] Tráfego pra negócio local / médico
- Baseline: [[Dr. Fábio — Auditoria Google Ads + Plano Sobral (14-05-2026)]]

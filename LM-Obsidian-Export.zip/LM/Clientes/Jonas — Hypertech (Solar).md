---
cliente: Jonas
empresa: Hypertech
segmento: Energia Solar
status: ativo
tipo: onboarding-alinhamento
meta-2026: R$ 20 milhões
faturamento-anterior: R$ 6,3 milhões
tags: [cliente, lm, solar, comercial, funil, escala, onboarding]
atualizado: 2026-04-12
---

# Jonas — Hypertech (Solar)

## Contexto
Jonas é sócio da Hypertech, empresa de energia solar com operação já estruturada: tráfego pago ativo, ~400 leads/mês, CRM, equipe de representantes, estrutura física e histórico de +5.000 projetos executados. Faturou **R$ 6,3M no ano anterior** com mais de 200 projetos vendidos.

**Meta 2026:** R$ 20 milhões — com a condição explícita de ser crescimento saudável e lucrativo. Não quer crescimento fake.

---

## Diagnóstico

### O que já existe
- Tráfego pago ativo com agências
- ~400 leads/mês — demanda não é o gargalo
- CRM implementado
- Representantes com carros na rua
- Liderança presente (Jonas + Fernanda)

### Gargalo real
**Não é geração de oportunidade — é conversão e aproveitamento.** O lead entra, o potencial existe, mas a transformação em vendas não acontece na velocidade necessária.

Problemas específicos identificados:
- Resultado ainda depende demais do dono e de poucos nomes-chave
- Indicações quentes perdem timing por falta de cadência de follow-up
- Rotatividade alta de representantes — custo de formação recorrente
- Representantes com diferentes maturidades para vender soluções mais técnicas (híbridos, bateria)
- Funil sem clareza de responsabilidade por etapa

---

## Matemática do Projeto

Com ticket relevante e ~400 leads/mês, **qualquer melhoria em**: velocidade de contato → aproveitamento de lead → comparecimento em visita → eficiência de fechamento gera **efeito composto forte sobre a meta anual**.

Produtos mais valiosos:
- Sistemas híbridos e com bateria → ticket muito superior ao produto convencional
- Meta de R$20M não exige milagre — exige processo

---

## Proposta Discutida

**Modelo híbrido:** estruturação + treinamento + execução assistida (~60 dias)

| Fase | O que acontece |
|---|---|
| Piloto (~30 dias) | Validação prática com metas curtas, acompanhamento próximo |
| Estruturação definitiva | Implantação do funil separado, scripts, contratação, treinamento |

**Princípios:**
- Separar pré-venda (aquece, qualifica, agenda) de fechamento
- Modelo predominantemente comissionado — sem grande peso fixo inicial
- Scripts, contratação e treinamento como parte da entrega
- Percentuais de comissão revisados para cada etapa do funil

---

## O que Jonas Valoriza
- Clareza, tangibilidade, segurança
- Não rejeita investimento — rejeita risco mal explicado
- Gente com fome de resultado e disciplina comercial
- Números reais, funil desenhado, responsabilidade por etapa

---

## Riscos
- Entrar com estrutura nova sem alinhar percentuais pode gerar atrito com equipe atual
- Nova camada comercial sem acompanhamento diário → problema muda de lugar
- Sem critérios claros de handoff → disputa de mérito e perda de accountability
- Meta de R$20M mal desdobrada pode pressionar decisões erradas
- Tráfego continua melhorando e operação comercial não acompanha

---

## Próximos Passos
- [ ] Desenhar funil completo com números-alvo por etapa: lead → contato → qualificação → agendamento → visita → proposta → contrato
- [ ] Modelar percentuais de comissão para pré-venda e fechamento
- [ ] Definir quem assume leads pagos vs. indicações e qual é a cadência mínima de follow-up
- [ ] Criar proposta visual com cenários, payback e impacto na meta anual
- [ ] Implantar fase piloto com metas curtas de validação

---

**Ver também:** [[Índice — Reuniões de Vendas LM]] | [[2026-04-08 — Treinamento Geração de Demanda e Métricas]] | [[2026-02-26 — Marcelo]]

---

**Hub:** [[LM — Visão Geral|L.M Agência]]

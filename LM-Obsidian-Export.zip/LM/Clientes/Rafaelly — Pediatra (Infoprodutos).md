---
cliente: Rafaelly
agencia: LM
nicho: Pediatria / Infoprodutos
modelo: Comissão 30%
status: Ativo
---

# Rafaelly — Pediatra (Infoprodutos)

## Quem é

Médica pediatra. Cuida de criança pequena. Tem cursos sobre sono infantil, alimentação infantil e temas relacionados a cuidados com bebê/criança.

## Relação comercial

- Cliente da L.M Agência
- Modelo atual: **30% de comissão sobre vendas**
- Histórico: começou em modelo fixo, rodou 2 meses sem bons resultados, migramos no 3º mês pra comissionamento

## Escopo

LM responsável pela venda do infoproduto.

## Notas relacionadas

- [[Rafaelly — Pauta Reunião Sexta (Nicho, Avatar, Oferta)]] — pauta de definição de nicho/avatar/oferta
- [[Rafaelly — Big Idea (Aprofundamento Sofisticação + Copy + Escada)]] — diagnóstico Schwartz, Big Idea e escada de produtos
- [[Rafaelly — Funil e Comunicação (Modelo + Instagram + Orçamento)]] — funil, Instagram e orçamento

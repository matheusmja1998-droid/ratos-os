# Funil de Vendas e Comunicação — Rafaelly

Material consolidado da conversa sobre estrutura de funil, modelo recomendado, papel do Instagram/TikTok, ativos necessários e projeção de resultado com R$3k/mês de mídia.

---

## ⚠️ Ponto crítico a validar com a Rafaelly

**Uso do título "pediatra" na comunicação.**

Toda a Big Idea ("O Método da Pediatra. Não é consultoria. É medicina.") e toda a estratégia de funil, conteúdo e copy estão ancoradas no fato de que Rafaelly é médica pediatra. Se o CRM regional dela tiver restrição ao uso do título profissional em comunicação comercial / venda de curso, a estratégia precisa ser redesenhada do zero.

**O que precisa ser validado antes de investir em produção:**
- Pode usar "pediatra" / "Dra." na comunicação?
- Pode dar aula ao vivo ensinando conteúdo médico (sem caso individual)?
- Pode vender curso usando o título profissional?
- Comunidade educativa mensal (sem consultoria/mentoria) é permitida?

**Status:** dúvida levantada pelo Matheus. Tem que conversar com a Rafaelly antes da próxima decisão de produção.

---

## Contexto que define o funil

R$3k/mês de mídia. Isso descarta modelos que dependem de volume alto (lançamento clássico estilo Erico Rocha, que exige R$30-100k em captação).

---

## Os 3 modelos de funil viáveis

### Modelo A — Funil Perpétuo com VSL (Video Sales Letter)

Anúncio → captura → página com vídeo de vendas (15-25 min) → checkout direto → upsells.

**Vantagens:** roda 24/7, escala com mídia, testa rápido.
**Desvantagens:** VSL exige roteiro forte e produção razoável; conversão menor que evento ao vivo (1-3% vs 5-15%).

### Modelo B — Funil de Aula Gratuita

Anúncio → captura → aula gratuita ("Os 3 erros que fazem seu bebê acordar à noite") → oferta do curso → checkout.

**B1 — Aula gravada (perpétuo):** disponível 24/7.
**B2 — Aula ao vivo (semanal/quinzenal):** Rafaelly faz toda terça (ex), mãe assiste ao vivo.

**Vantagens:** conversão maior (5-12% perpétuo, 10-20% ao vivo), constrói autoridade, vence ceticismo de mercado sofisticação 4, permite ticket maior.
**Desvantagens:** ao vivo exige consistência semanal; gravada exige produção decente; roteiro é o ponto crítico.

### Modelo C — Conteúdo Orgânico + Direct Response

Conteúdo IG/TikTok → link na bio → página de venda ou lead magnet → email/WhatsApp → venda.

**Vantagens:** custo baixo, constrói marca, baixa CAC dos anúncios.
**Desvantagens:** lento (6-12 meses), imprevisível, não escala receita rápido. Funciona como complemento, não como funil principal.

---

## Recomendação: Modelo B2 → Modelo A perpétuo

**Fase 1 (mês 1-3): Aula gratuita ao vivo semanal.**

Razões:
1. Mercado sofisticação 4 exige educação antes de venda. Mãe cética não compra curso de R$497 só por anúncio bonito — precisa ver a Rafaelly falando 30-40 min.
2. Aula ao vivo dá interação e prova social em tempo real (mães comentando "minha filha tem isso").
3. Permite testar e iterar oferta semanalmente. Nas primeiras 4-6 semanas ajusta preço, bônus, garantia, CTA.

**Fase 2 (mês 4+): Aula gravada perpétua + VSL.**

Depois que aula ao vivo validar oferta e copy, grava versão definitiva e roda em automático. VSL pra testar segmentos diferentes (ex: VSL pode converter melhor pra mãe de bebê 0-12m, webinário pra 12-24m).

---

## Estrutura completa do funil

```
TOPO — DESCOBERTA
└─ Anúncios Meta Ads (Instagram + Facebook)
└─ Conteúdo orgânico (Instagram + TikTok)
└─ Indicação (mãe que já comprou)
        ↓
LEAD MAGNET — CAPTURA
└─ Página de inscrição da aula gratuita
   "Aula gratuita ao vivo: Os 3 erros que fazem seu bebê acordar à noite"
   Captura: nome + email + WhatsApp + idade do bebê
        ↓
NUTRIÇÃO PRÉ-AULA (3-5 dias antes)
└─ Email + WhatsApp:
   - Confirmação de inscrição
   - História da Rafaelly (por que virou pediatra)
   - Caso clínico real anonimizado
   - Lembrete da aula
        ↓
AULA GRATUITA (40 min)
└─ Live no YouTube/Zoom/Crowdcast
   Estrutura: problema → mecanismo → caso real → oferta
        ↓
OFERTA NA AULA
└─ Curso R$497 (com bônus exclusivo pra quem comprar nas próximas 48h)
   Order bump no checkout: Guia Alimentar (+R$47)
        ↓
PÓS-COMPRA — UPSELLS
└─ Upsell 1 imediato: "Virar o Prato" reposicionado (+R$97)
└─ Upsell 2 (5 dias depois, via email): Pack Obesidade (+R$147)
        ↓
CONTINUIDADE
└─ 30 dias após compra: convite pra Comunidade da Pediatra (R$37/mês)
        ↓
NÃO COMPROU? — REMARKETING
└─ Sequência email/whatsapp por 7 dias:
   - Dia 1: prova social (depoimento de mãe)
   - Dia 2: conteúdo educativo
   - Dia 3: caso clínico
   - Dia 4: derruba objeção (preço, tempo, "vai funcionar pra mim?")
   - Dia 5: garantia ampliada
   - Dia 6: urgência (vagas, bônus expira)
   - Dia 7: última chamada
└─ Remarketing Meta Ads: anúncios diferentes pra quem viu landing mas não comprou
```

---

## Como o Instagram/TikTok alimenta o funil

### Pilares de conteúdo

**Pilar 1 — Educação médica (60%)**
Conteúdo que só pediatra pode ensinar. Reforça Big Idea.

Exemplos:
- "5 sinais de que o sono do seu bebê pode ter causa médica"
- "Por que ferritina baixa atrapalha o sono"
- "Refluxo silencioso: como identificar quando o bebê não vomita mas tem refluxo"
- "Quando a regressão de sono é normal e quando é sinal de alerta"
- "O que a Sociedade Brasileira de Pediatria recomenda sobre cama compartilhada"

Função: constrói autoridade. Mãe que vê 4-5 vezes começa a confiar antes do anúncio.

**Pilar 2 — Storytelling do consultório (25%)**
Casos reais anonimizados. Storytelling Ogilvy.

Exemplos:
- "Atendi uma mãe ontem. Bebê de 8 meses acordando 6x por noite. O que descobri vai te surpreender."
- "Mãe chegou no consultório dizendo: 'tentei tudo, doutora'. O que ela não tinha tentado era pedir 1 exame."
- "A pergunta que faço pra toda mãe que entra no meu consultório com queixa de sono"

Função: humaniza + prova autoridade. Mãe vê que ela atende de verdade, não é só influencer.

**Pilar 3 — Posicionamento direto (15%)**
Ataca categoria de consultora leiga (sem nomear) e reforça por que pediatra é diferente.

Exemplos:
- "Por que método de sono nem sempre funciona — e o que ninguém te conta"
- "A diferença entre rotina de sono e protocolo médico"
- "O que um curso de certificação de fim de semana NÃO ensina"
- "Quando seu bebê precisa de pediatra, e não de consultora de sono"

Função: planta Big Idea. Quando anúncio chegar, ela já tá vendida no posicionamento.

### Frequência sugerida

| Plataforma | Frequência | Formato |
|---|---|---|
| Instagram Feed | 4 posts/semana | Carrossel (educação) + Foto (consultório/caso) |
| Instagram Stories | 4-6 stories/dia | Bastidor + dicas + interação |
| Instagram Reels | 3 Reels/semana | Educação + caso + posicionamento |
| TikTok | 5 vídeos/semana | Mesmos Reels + 2 originais |

**Sobre o TikTok:** algoritmo pra conteúdo médico de mãe é generoso. Pediatra consistente em 90 dias vira referência. Vale priorizar.

### Conexões orgânico → funil

1. **Link na bio sempre na aula gratuita.** Página única, não Linktree com 10 opções.
2. **CTA sutil a cada 3-4 posts.** "Comenta SONO se quer minha aula gratuita" → quem comenta recebe DM com link.
3. **Stories diários com mecânicas de venda.**
   - Caixinha: "qual sua maior dúvida sobre sono?" → responde nas stories → final: oferta da aula
   - Enquete: "seu bebê acorda mais de 3x por noite?" → quem vota "sim" recebe DM
   - Bastidor: "indo pro consultório atender bebês com sono difícil"

Feed/Reels constrói marca. **Stories vende.**

### Calendário semanal padrão

| Dia | Feed | Reels | Stories |
|---|---|---|---|
| Segunda | Carrossel educativo | — | Bastidor consultório |
| Terça | — | Reels educação | Caixinha + CTA aula |
| Quarta | Foto + caso clínico | — | Resposta de pergunta |
| Quinta | — | Reels caso real | Convite pra aula |
| Sexta | Carrossel posicionamento | Reels posicionamento | Bastidor |
| Sábado | — | — | Conteúdo leve |
| Domingo | Foto humanização | — | Preparação semana |

LM produz, Rafaelly grava (ela precisa aparecer falando).

---

## Ativos necessários pra rodar

1. Página de inscrição da aula gratuita
2. Aula gratuita (roteiro + slides + Rafaelly gravando ou ao vivo)
3. Página de vendas do curso R$497
4. Anúncios Meta Ads — 3 versões pra teste
5. Sequência de email/whatsapp — pré-aula, pós-aula, remarketing
6. Calendário de conteúdo orgânico — primeiro mês mapeado

Tempo de montagem: 3-4 semanas. Primeira aula ao vivo: ~30 dias depois da reunião de sexta.

---

## Distribuição do orçamento de mídia (R$3k/mês)

- R$2.000/mês: captação de leads pra aula gratuita (CPL alvo: R$3-8)
- R$1.000/mês: remarketing pra quem viu landing/aula mas não comprou

### Projeção conservadora (mês 2-3)

CPL de R$5 = **400 leads/mês**
Conversão da aula em compra de 5% = **20 vendas/mês**
Receita core: 20 × R$497 = **R$9.940**
Com bumps e upsells: **R$11-13k/mês**
Comissão LM (30%): **R$3.300-3.900/mês**

Mês 4+: com aula perpétua e otimização, possível dobrar.

---

## Riscos

1. **R$3k é justo.** Se CPL passar de R$10, funil aperta. Depende da qualidade dos criativos e da headline da aula.
2. **Rafaelly precisa aparecer.** Ela é o produto. Sem disciplina de gravar conteúdo semanal e fazer aula ao vivo, funil quebra.
3. **CRM é incógnita.** Toda a estratégia pressupõe que ela pode usar o título de pediatra na comunicação. Validar antes de investir em produção (ver topo da nota).

---

## Próximos pontos pra aprofundar (futuro)

1. Roteiro da aula gratuita ao vivo (estrutura de 40 min, slide a slide)
2. Anúncios Meta Ads (3 versões com criativo, copy e segmentação)
3. Calendário editorial detalhado (4 semanas de conteúdo prontos)
4. Sequência de email/WhatsApp (cada mensagem escrita)
5. Métricas e KPIs (o que medir em cada etapa)

---

**Hub:** [[LM — Visão Geral|L.M Agência]]

---
cliente: Daniel Daolio Guidio
empresa: Meta Mavi
tipo: agência de tráfego (solo)
cidade: Guarulhos/SP
produto_contratado: Cockpit Setup
valor: 1000
prazo: 30 dias
data_fechamento: 2026-05-13
status: cliente ativo
tags: [cliente, lm, daniel-daolio, meta-mavi, cockpit]
---

# Daniel Daolio — Meta Mavi (Dossiê)

## Dados

- **Nome:** Daniel Daolio Guidio
- **Empresa:** Meta Mavi
- **CNPJ:** 66.591.815/0001-09
- **CPF:** 493.052.928-01
- **Email:** metamavi1@gmail.com
- **Endereço:** Rua Oboé, 54, apto 56, Vila Nossa Senhora de Fátima, Guarulhos/SP

## Sobre o negócio

Agência solo de tráfego. ~7-8 anos de mercado digital, começou em social media. Já teve agência maior com 2 sócios (Meta Mavi original, 3 pessoas + 2 sócios), passou por burnout da sócia e separação de outro sócio. Hoje toca sozinho com 1 designer/editor (acabou de trocar, anterior foi pra CNN).

**Clientes ativos (8):**
- 4-5 tarólogas (Elaine Sensitiva fatura ~R$50k/mês em Angola, já teve trampo de $100k)
- Clínica Takaki (quiropraxia/pilates) — cliente mais complexo, usa Cláudia CRM
- Academia, nutricionista (pausado)
- 1 projeto com sócio (nicho que queima conta)

## Stack atual

- Claude Pro (assinado)
- VPS Hostinger (configurando OpenCloud, com n8n nativo)
- Gemini Pro (plano 5TB Drive)
- Estudou Obsidian, n8n, MCP em outra mentoria
- Já fez bootcamp Lucas Félix (parcialmente)

## Dores prioritárias

1. **Financeiro da agência** — quer automatizar Conta Azul + NF via Telegram
2. **Cliente Takaki** — equipe gasta 2h/dia preenchendo planilha cruzando Cláudia CRM + Meta + Google
3. **Rastreio WhatsApp** — quer versão própria do Tintin pra clientes sem CRM (tarólogas)
4. **Operação geral** — onboarding, briefing de criativo pro designer, relatório semanal

## O que NÃO quer agora

- Comercial / prospecção ativa (declarou: primeiro otimiza entrega, depois prospecta)
- White label de sistema (achou caro)

## Produto contratado: Cockpit Setup

- **Valor:** R$1.000 parcela única
- **Prazo:** 30 dias
- **Formato:** 4 encontros semanais (~1h cada)
- **Pagamento:** Pix CNPJ LM (62.831.134/0001-01), até 2 dias úteis após assinatura

### Cronograma planejado

1. **Encontro 1** — Setup Claude Code no VPS + Telegram + Obsidian + GitHub
2. **Encontro 2** — Mapear estrutura da agência + criar skills operacionais
3. **Encontro 3** — Solução por cliente (provável foco: Takaki / Cláudia CRM)
4. **Encontro 4** — Solução por cliente + plano de continuidade

## Histórico

- **2026-05-07** — Participou do webinar "A Era da IA" (LM)
- **2026-05-08** — R1 com Matheus e Valentino (transcrição na pasta)
- **2026-05-13** — Fechou Cockpit Setup R$1k, contrato enviado

## Links

- [[Contrato — Daniel Daolio x LM Agência (Cockpit Setup)]]

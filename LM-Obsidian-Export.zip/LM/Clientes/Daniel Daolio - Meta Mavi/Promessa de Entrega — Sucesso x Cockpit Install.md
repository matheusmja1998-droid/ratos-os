---
cliente: Daniel Daolio — Meta Mavi
tipo: promessa-de-entrega
data: 2026-05-15
tier: Cockpit Install
fonte: cruzamento da fala dele em [Onboarding 2026-05-15](https://fathom.video/calls/675553827?timestamp=2258) com a oferta Install
---

# Promessa de Entrega — Daniel Daolio (Meta Mavi)

O que o Daniel definiu como sucesso ao final do projeto cruzado com o que o Cockpit Install entrega.

## A fala dele (37:38 da call de onboarding)

> "Para mim, ter toda essa parte do cloud configurado, eu consegui fazer o gerenciamento dos anúncios, tudo através do celular. Então o mínimo possível é realmente abrir o gerenciador.
>
> Tirando isso, **melhorar a parte de conteúdos da própria agência**, que é uma coisa que eu quero há muito tempo já e, às vezes, dou uma travada nisso.
>
> **Melhorar a parte comercial**, ter uma estrutura comercial que eu consiga, dentro dos meus limites aqui, seguir e gerar resultado.
>
> Eu não preciso, atualmente, de resultado astronômico, porque eu vejo que, dependendo do projeto, eu às vezes posso fazer igual eu fiz em [outros], entrar até [mais fundo no negócio]. E aí isso me toma tempo muito maior, porém a lucratividade daquele projeto vai ser absurda.
>
> **Então a minha ideia é conseguir automatizar a minha empresa, para conseguir automatizar a empresa dos meus clientes, ter valor percebido muito maior, e com isso gerar muito mais ganho para mim.** E automaticamente vai gerar para eles também."

[Link direto da fala no Fathom](https://fathom.video/calls/675553827?timestamp=2258)

---

## 1. "Gerenciar anúncios pelo celular, abrir o gerenciador o mínimo possível"

**Entrega:**
- **Cockpit Meta** — operação de Meta Ads por linguagem natural via Claude. Pausa, duplica, edita budget e criativo conversando, do celular pelo app do Claude.
- **Cockpit Watch (Guardião)** — alerta no Telegram quando algo foge da meta (gasto travado, conta sem saldo, criativo morrendo). Se não chega nada, tá tudo certo. Paz no coração.
- **Cockpit Report** — relatório automático toda segunda 8h no Telegram com fechamento da semana. Pode ligar relatório diário 7h se quiser.
- **Cockpit Track** (em construção, entregue sem custo extra) — captura 25-40% mais conversões que pixel padrão perde no iOS 17+.

**Resultado prático:** abre o gerenciador só pra coisa que exige clique humano. O resto vira mensagem no Telegram + comando no Claude.

---

## 2. "Melhorar a parte de conteúdos da agência"

**Entrega:**
- **Cockpit Creative** — 10 criativos de imagem por demanda (feed 1080x1080 + stories 1080x1920), com identidade visual da Meta Mavi configurada, copy via Schwartz + Hormozi, compliance Meta aplicado.
- **Skills de produção de conteúdo** (carrossel, vídeo de bastidor) — destravar as temporadas de carrosséis do Instagram dele. O que travou na call foi prompt genérico. Com skill estruturada + identidade visual carregada, sai em massa.

**Resultado prático:** a frente que trava há tempos passa a rodar em pipeline. Conteúdo da agência + conteúdo de cliente saindo no mesmo fluxo.

---

## 3. "Estrutura comercial dentro dos meus limites que gere resultado"

**Entrega:**
- **Cockpit Setup** já cria a arquitetura `clientes/`, `dossiês`, `pesquisa`, `criativos`, `marca` — base pra padronizar onboarding novo.
- **Skill Dossiê** — entrevista guiada que gera CLAUDE.md do cliente novo em 15-20 min.
- **Skill Onboarding / Checklist Cliente Novo** — checklist replicável de tudo que precisa coletar quando fecha (acessos, contrato, marca, BM).
- **Cockpit Report** vira ferramenta comercial: cliente recebe relatório semanal formatado, percebe valor, paga melhor e renova.

**Resultado prático:** opera com estrutura comercial enxuta, sem precisar contratar SDR/comercial agora (ele mesmo levantou que comercial contratado é "cara vagabundo"). Pipeline organizado, dossiê padrão, relatório semanal automático = cliente percebe profissionalismo de agência grande.

---

## 4. "Automatizar minha agência pra automatizar a dos clientes, ter valor percebido maior, ganhar porcentagem em projetos onde entro mais fundo"

Esse é o resultado-meta que sai do conjunto, não de uma skill só:

- Stack instalada poupa 8h+/semana (garantia operacional do Install).
- Essas 8h ele realoca pra entrar mais fundo nos clientes premium, virar % do resultado.
- Cliente vê monitor 24/7 + relatório semanal + criativos em massa + tracking server-side = percebe valor de agência R$10-20k/mês, mesmo Daniel cobrando menos.
- A própria stack que roda na agência dele, ele replica na operação dos clientes (mesmas skills, contas diferentes) — virando o sócio operacional automatizado que ele descreveu.

---

## Bônus que o Install cobre (não pediu, mas vai usar)

- **Cockpit Debrief** — análise completa de lançamento/campanha em 5 min.
- **Cockpit Google** — quando rodar Google Ads, mesma fluidez do Meta.
- **30 dias de suporte WhatsApp** — qualquer trava na primeira fase, desbloqueio direto.
- **Garantia operacional 14 dias** — se não economizar 8h/semana, devolve R$1k + R$200.

---

## Frase de fechamento (pra mandar pra ele)

> Daniel, o que tu definiu como sucesso bate exatamente com a stack do Cockpit Install: anúncio no celular (Meta + Watch + Report no Telegram), conteúdo destravado (Creative + carrossel), comercial estruturado (Setup + Dossiê + Checklist) e tudo isso automatizando a tua operação pra tu replicar nos clientes e cobrar como sócio. Sai da call rodando.

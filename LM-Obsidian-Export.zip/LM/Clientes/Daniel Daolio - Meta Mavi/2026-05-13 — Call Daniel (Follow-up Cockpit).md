---
tipo: transcrição
cliente: Daniel Daolio (Meta Mavi)
data: 2026-05-13
contexto: Follow-up pós-fechamento Cockpit Setup
duração_aprox: ~50min
tags: [transcrição, daniel-daolio, meta-mavi, cockpit, lm]
---

# Call Daniel Daolio — 13/05/2026 (Follow-up Cockpit Setup)

Call de follow-up depois do fechamento do Cockpit Setup. Daniel mostra em detalhe o caso da Clínica Takaki (Cláudia CRM + Versátiles), os números do mês de abril e a estrutura do robô de WhatsApp que tá emperrando em 25% de conversão de lead.

## Pontos principais

### Sobre a rotina dele
- Tá rodando agência sozinho + 1 designer/editor nova (contratada recente)
- Conta caiu de novo no projeto com sócio, precisa "alimentar" perfis novos de FB/IG (urgência #1 dele, vai contratar humano pra isso)
- Cockpit é prioridade #2

### Conversa com o contador sobre automação financeira
- Contador não viu integração completa Conta Azul + Claude
- Só viu caso de SDR WhatsApp que conectou API do WhatsApp com API do Conto Azul (gerar cliente novo + link de pagamento)
- Não tem o restante: NF, lançamentos completos, repasses
- Daniel vai "fustar" pra ver se dá pra fazer o resto

### Demo que o Matheus mostrou
- Carrosséis do Cockpit (Claude + Playwright)
- Vídeo motion do carrossel (Remotion)
- 10 cortes virais de 1 reunião de vendas (cortes-virais skill)
- Claude faz tudo nativo, sem ferramenta paga
- Daniel se interessou bastante pelo workflow de conteúdo

### Caso Clínica Takaki — DETALHADO

**Stack atual da clínica:**
- Cláudia (CRM + central de mensagens WhatsApp/IG/FB + robô + relatórios meta)
- Versátiles (gestão de clínica: agenda, faturamento, repasses, folha)
- 4 logins no Cláudia (1 ADM + 3 vendedoras)
- Cláudia ~R$1.100/mês + Versátiles ~R$2.000/mês

**Dor #1 — Robô de WhatsApp converte só 25%:**
- Fluxo atual: pessoa chega → botões (novo paciente / já paciente) → escolhe especialidade → recebe PDF/áudio OU pede atendimento humano → preenche nome/telefone/email/horário
- Só 25% chega até a etapa final (preencher dados)
- Já testaram 4 versões de fluxo em 3 meses
- Dono mandou mensagem pedindo melhoria: muita demanda no atendimento humano travando a equipe
- Ideal seria self-service de agendamento

**Dor #2 — Relatórios do Cláudia não batem com a realidade:**
- Menina ISA preenche planilha diária na unha (~1h30/dia)
- Cláudia gera relatório próprio, mas valores diferem do que a ISA preenche
- Relatórios meta puxam quem veio do anúncio mas NÃO o nome da campanha/criativo
- Dados de venda real (faturamento, repasse) só ficam no Versátiles
- Quem orçou integração Cláudia + Versátiles cobrou R$4.000 só pra conectar

**Dor #3 — Follow-up manual gasta muito tempo da equipe:**
- 3 contatos de lead quente (escritos + ligação no fim do dia)
- Depois cai pra "morto" → quarto contato com cópia diferente
- Depois cai pra "frio" → conteúdo bruto, descarte
- Documentação criada por elas + Daniel

### Números abril 2026 (Takaki)
- Investimento Facebook: R$3.500 (limite R$4k)
- Leads: 502
- Respondeu: 461 (taxa 91% — boa)
- Agendaram avaliação: 61
- Compareceram: 47
- Taxa agendamento: 12% (meta era 10%, próxima 15-20%)
- Taxa de comparecimento: 77%
- Vendas avaliação: 49 / R$11k faturados
- Vendas plano: 9 / R$22k
- Faturamento total da clínica estimado: ~R$50k/mês
- Contrato Daniel: R$2.000/mês

### O que Daniel quer vender pra Takaki como upsell
- Automação completa do atendimento WhatsApp (substituir ou somar ao robô do Cláudia)
- Algo entre R$600-700/mês a mais na mensalidade
- Quer subir o ticket médio da agência

### Solução discutida na call
- Matheus sugeriu: n8n + WhatsApp + cruzar com agenda do Versátiles
- Exemplo de caso anterior: clínica com 8 médicos, 8 agendas, IA cruzava tudo, agendava sozinha, confirmava 1 dia antes
- Trabalhar n8n em paralelo com o Cláudia (não substituir necessariamente)
- Atualizar Kanban via API ou diretamente no n8n

### Sobre a mentoria (reforço da proposta)
- Matheus explicou os ganhos do setup completo (projetos por cliente, skills, organização de pastas)
- Daniel ainda não usa Claude Code (só web), só plano Pro
- Estourou janela domingo (precisou comprar R$20 de crédito extra)
- Tem que aprender macetes pra economizar token
- Quer trabalhar 1-2x/semana sentado junto

### Compromisso final
- Daniel confirmou interesse em começar
- Tava aguardando alinhar agenda/preço
- Já tinha pedido pix das 4 calls antecipado

## Próximos passos (ação Matheus)
- [ ] Combinar dia/hora da 1ª call
- [ ] Confirmar pagamento R$1k via Pix CNPJ LM
- [ ] Preparar setup base pra 1ª call (Claude Code no VPS dele + Telegram + Obsidian)
- [ ] Mapear arquitetura proposta pra automação Takaki (n8n + Cláudia API + Versátiles API)

## Insights pra usar nas calls

1. **Takaki é o cliente âncora dele.** R$2k/mês, dor clara, dono engajado, ROI fácil de calcular (libera 1h30/dia da ISA + sobe taxa de agendamento de 12% pra 20%). Resolver Takaki = caso de uso pra replicar pros outros clientes.

2. **Stack do cliente (Cláudia + Versátiles) é cara e mal integrada.** O orçamento de R$4k pra integração que ele recusou é a abertura: a gente entrega isso por dentro da mentoria + n8n.

3. **Daniel pensa em ticket médio.** Quer subir de R$2k pra R$2.7k vendendo automação. Bom argumento de ROI: a mentoria de R$1k se paga com 1 mês e meio de upsell num cliente só.

4. **Ele tá com cabeça aberta pra n8n.** Aceitou na hora a sugestão de fazer atendimento por fora do Cláudia. Não vai resistir à arquitetura proposta.

## Links

- [[Daniel Daolio — Meta Mavi (Dossiê)]]
- [[Contrato — Daniel Daolio x LM Agência (Cockpit Setup)]]

## Transcrição completa

> Transcrição original colada abaixo (Fathom-style, com timestamps). Arquivo mantido pra consulta futura e re-análise.

```
1:10 Alô, alô,
1:11 >> alô, alô. Fala, meu querido. Tudo bom?
1:14 >> Fala, grande homem. Tudo certo?
1:16 >> Tudo certo. Como que tá aí esse essa semana? Correria?
1:21 >> Correria, bicho. Correria como sempre, né? Não muda muito.
1:25 >> Muita demanda. Como que tá aí?

[... transcrição completa de ~50min, truncada na chegada por limite de mensagem ...]

[Conteúdo completo da call processado nas notas acima. Trechos brutos disponíveis no Fathom original.]
```

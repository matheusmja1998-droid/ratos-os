---
tipo: contrato
cliente: Daniel Daolio (Meta Mavi)
produto: Cockpit Setup — Mentoria de 30 dias
valor: 1000
prazo: 30 dias
data_assinatura: 2026-05-13
status: pendente assinatura
tags: [contrato, daniel-daolio, meta-mavi, lm, cockpit]
---

# CONTRATO DE PRESTAÇÃO DE SERVIÇOS DE CONSULTORIA EM AUTOMAÇÃO E INTELIGÊNCIA ARTIFICIAL

## COCKPIT SETUP — MENTORIA DE 30 DIAS

---

## PARTES

### CONTRATADA

L.M AGÊNCIA, pessoa jurídica de direito privado, inscrita no CNPJ sob nº 62.831.134/0001-01, neste ato representada por seus sócios:

- MATHEUS JARDIM AMARAL, brasileiro, portador do CPF nº 173.657.397-70, telefone (31) 99505-2413
- VALENTINO JOAQUIN PASCUAL, portador do CPF nº 013.494.279-50, residente na Rua 900D, 346, Itapema/SC, CEP 88220-000

Doravante denominada simplesmente CONTRATADA.

### CONTRATANTE

DANIEL DAOLIO GUIDIO, pessoa jurídica de direito privado (Meta Mavi), inscrita no CNPJ sob nº 66.591.815/0001-09, com sede na Rua Oboé, 54, apartamento 56, Vila Nossa Senhora de Fátima, Guarulhos/SP, neste ato representada por DANIEL DAOLIO GUIDIO, brasileiro, portador do CPF nº 493.052.928-01, e-mail metamavi1@gmail.com.

Doravante denominada simplesmente CONTRATANTE.

---

## CLÁUSULA 1ª — OBJETO DO CONTRATO

A CONTRATADA prestará à CONTRATANTE serviços de consultoria executiva em automação e inteligência artificial aplicada à operação de agência de tráfego, denominado COCKPIT SETUP, com duração de 30 (trinta) dias corridos, contados a partir da data de assinatura deste contrato.

O objetivo do projeto é fazer o setup completo da stack de IA da CONTRATANTE (Claude Code + Obsidian + skills personalizadas), entender a estrutura operacional da agência e deixar a CONTRATANTE produtiva para entregar mais resultado aos seus clientes, com automações conectadas a Meta Ads, Google Ads e demais ferramentas do dia a dia.

---

## CLÁUSULA 2ª — ENTREGÁVEIS

A CONTRATADA se compromete a entregar à CONTRATANTE os seguintes itens durante o período do projeto, distribuídos em 4 (quatro) encontros semanais de aproximadamente 1 (uma) hora cada:

### 2.1 — Encontro 1: Setup base

a) Setup completo do Claude Code rodando no VPS da CONTRATANTE
b) Conexão do Claude Code com Telegram, Obsidian e GitHub
c) Estrutura base de pastas, skills iniciais e organização de contexto
d) Configuração do ambiente para uso produtivo a partir do dia 1

### 2.2 — Encontro 2: Estrutura da agência e skills operacionais

e) Mapeamento da estrutura operacional da CONTRATANTE (rotina, equipe, clientes)
f) Criação de skills personalizadas para automatizar tarefas recorrentes
g) Padronização de fluxos internos (briefing de criativo, gestão de designer, onboarding de cliente novo)

### 2.3 — Encontros 3 e 4: Soluções por cliente

h) Análise individual dos principais clientes da CONTRATANTE
i) Desenho de soluções de automação e integração específicas conforme demanda
j) Conexão de skills com Meta Ads, Google Ads e ferramentas dos clientes (conforme viabilidade técnica e disponibilidade de APIs)
k) Plano de continuidade pós-projeto para a CONTRATANTE seguir evoluindo a operação após o encerramento

---

## CLÁUSULA 3ª — METODOLOGIA DE EXECUÇÃO

3.1. A CONTRATADA atuará em formato de consultoria executiva: ensina, faz junto e acompanha. Os encontros são construídos em conjunto, com a CONTRATANTE participando ativamente da construção das soluções no próprio Claude Code.

3.2. As atividades incluirão:
- 4 (quatro) encontros semanais por videoconferência, com duração estimada de 1 (uma) hora cada
- Construção colaborativa de skills, automações e integrações durante os encontros
- Disponibilidade da CONTRATADA via WhatsApp para dúvidas pontuais entre os encontros, sem caráter de suporte 24/7

3.3. Todos os encontros poderão ser gravados e disponibilizados à CONTRATANTE para consulta interna e treinamento futuro.

3.4. O cronograma dos encontros será definido em comum acordo entre as partes na primeira reunião.

---

## CLÁUSULA 4ª — RESPONSABILIDADES DA CONTRATANTE

4.1. Disponibilizar participação ativa nos 4 (quatro) encontros agendados ao longo dos 30 dias.

4.2. Manter o ambiente técnico mínimo necessário ao projeto: assinatura ativa do Claude Code (ou Claude Pro), VPS contratado e funcional, acesso aos clientes e ferramentas que serão integradas.

4.3. Fornecer informações operacionais sobre a agência, rotina e clientes necessárias ao desenho das soluções.

4.4. Custos operacionais não inclusos: assinaturas de Claude, VPS, APIs de terceiros, ferramentas pagas adicionais e quaisquer outras ferramentas utilizadas pela CONTRATANTE em sua operação são de responsabilidade exclusiva da CONTRATANTE.

---

## CLÁUSULA 5ª — VALOR E FORMA DE PAGAMENTO

5.1. O valor total do projeto é de R$ 1.000,00 (mil reais), pago em parcela única no início do projeto.

5.2. Forma de pagamento: Pix para a chave CNPJ 62.831.134/0001-01 (L.M Agência).

5.3. O pagamento deverá ser realizado em até 2 (dois) dias úteis após a assinatura deste contrato, e antes do primeiro encontro.

---

## CLÁUSULA 6ª — CONFIDENCIALIDADE E PROTEÇÃO DE DADOS

6.1. As partes se comprometem a manter sigilo sobre todas as informações estratégicas, comerciais, financeiras e operacionais às quais tiverem acesso durante a vigência deste contrato, incluindo dados de clientes da CONTRATANTE.

6.2. A CONTRATADA se compromete a tratar quaisquer dados pessoais aos quais tenha acesso em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD), utilizando os dados exclusivamente para finalidade de execução do objeto deste contrato.

6.3. Os encontros poderão ser gravados para fins de consulta interna da CONTRATANTE, com acesso restrito.

---

## CLÁUSULA 7ª — VIGÊNCIA E RESCISÃO

7.1. Este contrato vigora pelo prazo de 30 (trinta) dias corridos a partir da assinatura.

7.2. Qualquer das partes poderá rescindir o presente contrato mediante notificação prévia de 7 (sete) dias úteis, com pagamento proporcional dos serviços já entregues até a data da rescisão.

7.3. Em caso de descumprimento contratual por qualquer das partes, a parte prejudicada poderá rescindir o contrato imediatamente, mediante notificação formal, sem prejuízo de eventual indenização cabível.

---

## CLÁUSULA 8ª — DISPOSIÇÕES GERAIS

8.1. Este contrato representa o entendimento integral entre as partes, prevalecendo sobre quaisquer entendimentos anteriores, verbais ou escritos.

8.2. Eventuais alterações deste contrato somente terão validade quando formalizadas por aditivo escrito assinado por ambas as partes.

8.3. Fica eleito o foro da Comarca de Florianópolis/SC para dirimir quaisquer questões oriundas deste contrato, com renúncia expressa a qualquer outro, por mais privilegiado que seja.

---

E por estarem assim justas e contratadas, as partes assinam o presente instrumento em formato eletrônico, que terá plena validade jurídica nos termos da Lei nº 14.063/2020 e da Medida Provisória nº 2.200-2/2001.

Florianópolis/SC, 13 de maio de 2026.

---

### CONTRATADA — L.M AGÊNCIA


_______________________________________________
MATHEUS JARDIM AMARAL
CPF: 173.657.397-70


_______________________________________________
VALENTINO JOAQUIN PASCUAL
CPF: 013.494.279-50

---

### CONTRATANTE — DANIEL DAOLIO GUIDIO (META MAVI)


_______________________________________________
DANIEL DAOLIO GUIDIO
CPF: 493.052.928-01
CNPJ: 66.591.815/0001-09

---

### TESTEMUNHAS

1. Nome: ________________________________ CPF: ___________________

2. Nome: ________________________________ CPF: ___________________

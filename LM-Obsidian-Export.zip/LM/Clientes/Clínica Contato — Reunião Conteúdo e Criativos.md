---
cliente: Clínica Contato
tipo: reunião-operacional
tema: Produção de Conteúdo e Criativos
data: 2026-04-14
horario: 18:00
status: preparação
tags: [cliente, lm, conteúdo, criativos, instagram, google-ads, saúde, terapias]
---

# Clínica Contato — Reunião de Conteúdo e Criativos

**Data:** 14/04/2026 às 18h00
**Objetivo:** Definir o sistema de produção de conteúdo e os primeiros criativos para anúncios

---

## 1. Abertura (5 min)

**O que falar:**

> "Obrigado por abrir espaço pra gente hoje. Na nossa última conversa a gente mapeou bem o cenário de vocês: negócio saudável, retenção boa, mas aquisição ainda dependente de indicação e Instagram orgânico. A gente definiu um plano de 12 semanas pra mudar isso. Google Meu Negócio já está em andamento. Hoje a reunião é mais prática: vamos definir como vai funcionar a produção de conteúdo de vocês e quais criativos a gente vai usar nos anúncios. Ao final dessa conversa, vocês saem com clareza do que postar, como postar e o que vira anúncio."

---

## 2. Posicionamento do Conteúdo (10 min)

**O que falar:**

> "Antes de falar de formato ou frequência, preciso explicar a lógica do conteúdo de vocês — porque a maioria erra aqui. A maioria das clínicas fica com medo de 'entregar demais' e acaba postando muito pouco, ou coisas superficiais que não geram conexão nenhuma."
>
> "O que funciona é o contrário: vocês vão entregar o QUÊ e o PORQUÊ de graça. O conhecimento, o ensinamento, a explicação — tudo isso vai pro conteúdo. O que as pessoas pagam é o COMO, que é a sessão em si, a avaliação, o acompanhamento personalizado."
>
> "Exemplo prático: vocês postam um Reel explicando por que crianças com ansiedade não respondem a castigos. A mãe assiste, aprende, confia. Ela não vai em casa e trata o filho sozinha — ela vai querer marcar uma consulta com quem explicou aquilo tão bem."
>
> "Outro exemplo: vocês postam '3 sinais de que seu filho pode estar sofrendo de burnout escolar'. A mãe lê e pensa: 'meu filho tem dois desses'. Ela não vai resolver sozinha. Ela vai ligar pra clínica."
>
> "Dar esse conteúdo não reduz as consultas. Aumenta. Porque confiança é o que faz a pessoa escolher vocês e não o Google."

---

## 3. Público e Dor Central (5 min)

**O que falar:**

> "Antes de definir o que postar, a gente precisa ter muito claro pra quem a gente está falando. Porque conteúdo genérico não para o scroll de ninguém."
>
> "O público principal de vocês, com base no que me contaram, são mães entre 30 e 50 anos preocupadas com o desenvolvimento emocional dos filhos. E famílias buscando apoio para crianças com ansiedade, dificuldades escolares, TDAH. Tem também adultos em burnout ou passando por transições de vida."
>
> "Mas o que importa mais do que o perfil é a dor. As frases que passam pela cabeça dessas pessoas são:"
>
> "— 'Não sei se meu filho precisa de ajuda ou é só uma fase.'"
> "— 'Meu filho já está na terapia mas eu não vejo progresso, será que está funcionando?'"
> "— 'Quero ajuda mas tenho medo de ir num lugar frio e me sentir julgada.'"
> "— 'Estou exausta. Trabalho, filho, casa — e ainda me cobro por não estar bem.'"
>
> "O conteúdo de vocês precisa nomear essas dores. Quando a mãe vê algo que descreve exatamente o que ela sente, ela para. Ela salva. Ela manda pra outra mãe. E ela segue vocês."
>
> "Me confirma: esses perfis fazem sentido pra realidade de vocês? Tem algum outro que aparece muito na clínica?"

---

## 4. Categorias de Conteúdo (10 min)

**O que falar:**

> "Agora vou mostrar as 5 categorias de conteúdo que a gente vai usar. Não é pra postar uma coisa só — a conta que cresce mistura esses tipos. Cada um serve pra um momento diferente da jornada de quem segue vocês."

**Apresentar cada uma com a voz deles:**

> "**Educação** — é o carro-chefe. Ensina algo que o público não sabia. Exemplo: '3 sinais de ansiedade em crianças que a maioria das mães confunde com birra.' Esse tipo de post é salvo, compartilhado, e posiciona vocês como referência."

> "**Autoridade** — mostra que vocês sabem o que fazem. Formação das terapeutas, especializações, conquistas da clínica, número de pacientes atendidos, tempo de atuação. Não é arrogância, é prova. Mãe que vai colocar o filho na terapia quer saber com quem está deixando ele."

> "**Documentação** — mostra o dia a dia real. Como é a estrutura da clínica, como é um primeiro atendimento, o que acontece na sala de espera. Não precisa mostrar pacientes — mostra o ambiente, a rotina, o cuidado. Isso humaniza a clínica e reduz o medo de entrar."

> "**Contrária** — quebra um mito. Exemplo: 'Terapia não é pra quem está em crise — é pra quem quer crescer.' Ou: 'Seu filho não precisa de mais disciplina. Precisa ser compreendido.' Esse tipo polariza, mas atrai exatamente quem vocês querem."

> "**Conexão** — fala de coração pra coração. Um texto sobre o quanto é difícil ser mãe hoje. Uma mensagem de acolhimento pra quem está no limite. Esse tipo de post gera comentário, gera DM, gera relacionamento real."

> "A minha sugestão pra começar: 3 posts de educação por semana, 1 de autoridade ou documentação, e 1 de conexão ou contrária. Faz sentido pra vocês?"

---

## 5. Estrutura de Todo Conteúdo: Hook → Reter → Recompensar (10 min)

**O que falar:**

> "Todo conteúdo que a gente fizer — Reel, carrossel, post — vai seguir a mesma estrutura de três partes. Isso não é opcional, é o que separa conteúdo que para o scroll de conteúdo que ninguém assiste."

**Parte 1 — Hook:**

> "O hook são os primeiros 1 a 3 segundos. É a primeira linha do post, o primeiro frame do Reel. Se você não ganhar atenção aqui, acabou — a pessoa rolou e foi embora."
>
> "O hook não é um resumo do conteúdo. É uma promessa que faz a pessoa precisar ver o resto."
>
> "Vou dar exemplos do que funcionaria pra clínica de vocês:"
>
> "— 'Seu filho não está sendo difícil. Ele está pedindo ajuda de um jeito que você não reconhece.' — Isso para qualquer mãe que já chamou o filho de difícil."
>
> "— 'A maioria das mães ignora esse sinal de ansiedade no filho — e depois se arrepende.' — Gera medo saudável e curiosidade."
>
> "— '3 perguntas que toda mãe deveria fazer antes de contratar um terapeuta.' — Específico, útil, faz quem está procurando precisar ler."
>
> "Percebem como todos eles nomeiam a dor ou criam uma urgência de saber mais? É isso que vocês precisam no começo de cada conteúdo."

**Parte 2 — Reter:**

> "Depois que você capturou a atenção, precisa manter. O meio do conteúdo entrega o valor de verdade: a explicação, a lista, o passo a passo. O segredo aqui é contraste — 'o que a maioria faz vs. o que realmente funciona.' E também abrir loops: 'vou falar sobre isso daqui a pouco', 'o terceiro sinal é o mais ignorado'. Isso mantém a pessoa até o final."

**Parte 3 — Recompensar:**

> "No final, a pessoa tem que sair com algo: uma ação pra fazer hoje, uma frase que ela vai lembrar, uma conclusão que justificou o tempo que ela gastou. E um CTA — um, só um. Salva esse post. Manda pra uma mãe que precisa. Ou: clica no link da bio e agenda uma conversa."

---

## 6. Sistema de Produção (10 min)

**O que falar:**

> "Agora a parte mais prática: como isso vai funcionar no dia a dia de vocês. Porque conteúdo que depende de inspiração não funciona. A gente precisa de um sistema."
>
> "Antes de eu propor, preciso entender a realidade de vocês. Me respondam:"

**Fazer as perguntas uma por vez e esperar a resposta:**

> "Quantas terapeutas estariam disponíveis pra aparecer no conteúdo? Não precisa ser todo mundo — às vezes uma ou duas já resolvem."

> "Qual seria a frequência realista de gravação? Uma vez por semana? Duas? Preciso entender o que é sustentável pra vocês sem virar um peso."

> "Quem aprova o conteúdo antes de publicar? Precisa ter uma pessoa responsável pra não travar o processo."

> "Vocês têm espaço na clínica com boa luz pra gravar? Não precisa ser estúdio — um consultório arrumado resolve."

**Depois das respostas, apresentar a proposta:**

> "Com base no que vocês me disseram, a minha proposta de sistema mínimo é assim:"
>
> "A gente vai trabalhar assim: nós preparamos o roteiro completo — o que falar, na ordem certa, com o hook já pronto. Vocês gravam no celular de vocês, no espaço de vocês, na hora que for melhor pra rotina da clínica. Não precisa de câmera profissional, não precisa de estúdio. O roteiro garante que o conteúdo vai funcionar mesmo sem a gente presente na gravação."
>
> "Uma vez por semana, reservamos um bloco de 1 a 2 horas pra gravação em lote. Nesse bloco, gravem de 3 a 5 vídeos curtos de uma vez — assim não precisa gravar todo dia."
>
> "A gente entrega o roteiro antes, vocês gravam, mandam pra gente revisar, a gente edita e posta. O fluxo é simples e não depende de improvisar nada na frente da câmera."
>
> "A regra principal: consistência bate qualidade no começo. Três Reels simples por semana, toda semana, valem muito mais do que um Reel perfeito por mês."

---

## 7. Criativos para Anúncios (10 min)

**O que falar:**

> "Agora vamos falar de anúncios. E a primeira coisa que preciso deixar clara é: o melhor anúncio não parece anúncio. Parece conteúdo. Quando a pessoa sente que está vendo um comercial, ela pula. Quando ela sente que está consumindo algo útil, ela para e assiste."
>
> "O ciclo que a gente vai usar é simples: a gente posta orgânico, observa o que engaja mais, pega os conteúdos que performaram e coloca verba em cima deles. Não vamos inventar criativo do zero pra anúncio — vamos amplificar o que já funciona."

**Apresentar os formatos:**

> "Nessa fase inicial, a gente vai testar quatro formatos de criativo:"
>
> "**Talking head** — uma terapeuta olhando pra câmera e falando. Algo como: 'Semana passada uma mãe me disse que o filho dela...' Isso gera autoridade e conexão ao mesmo tempo. É o formato mais poderoso pra clínica de saúde porque humaniza."
>
> "**Depoimento** — um paciente ou responsável contando a experiência. Isso é prova social pura. 'Eu vim sem saber o que esperar e encontrei um lugar que realmente me acolheu.' Precisa de autorização assinada, mas vale muito a pena. Vamos falar sobre isso nos próximos passos."
>
> "**Carrossel estático** — slides com uma lista ou framework. '5 sinais que seu filho pode precisar de apoio psicológico.' Funciona bem no feed e no tráfego frio porque entrega valor rápido."
>
> "**Reel direto de agendamento** — mais simples, mais direto. Mostra a clínica, apresenta as terapeutas, fala que a agenda está aberta. CTA direto: 'Clica no link e agenda sua conversa.'"

**Explicar a estrutura do anúncio:**

> "Qualquer que seja o formato, a estrutura é sempre a mesma: nos primeiros 3 segundos a gente nomeia a dor com especificidade — não 'você sofre de ansiedade?' mas 'sua filha chora toda manhã antes de ir pra escola e você não sabe o que fazer?' Aí entrega valor ou curiosidade no meio. E fecha com um CTA só: clica no link, agenda, fala com a gente."

---

## 8. Próximos Passos (5 min)

**O que falar:**

> "A gente cobriu bastante coisa hoje. Pra sair daqui com tudo claro, deixa eu fechar com o que acontece agora:"

**Confirmar cada item e quem é responsável:**

> "Primeiro: quem vai aparecer no conteúdo? A gente precisa definir isso hoje pra já agendar a gravação."

> "Segundo: vamos marcar o primeiro dia de gravação em lote. Sugestão: semana que vem, num período de 1h a 2h que a clínica esteja mais vazia. Qual dia funciona melhor?"

> "Terceiro: antes da gravação, eu preparo 3 pautas com roteiro — vocês validam e a gente já chega com tudo pronto pra gravar."

> "Quarto: quem vai ser o ponto de aprovação do conteúdo? Precisa ser uma pessoa só, com prazo de resposta de 24h pra não travar a publicação."

> "Quinto: ainda precisamos dos acessos do BM e do Google Ads. Conseguimos resolver isso essa semana?"

> "Sexto: depoimento — se vocês tiverem pacientes que topam gravar ou dar um depoimento escrito, eu mando um modelo de autorização alinhado com a LGPD. É simples, mas precisa estar assinado antes de publicar qualquer coisa."

> "Alguma dúvida antes de fechar? Alguma coisa que ficou no ar?"

---

**Ações fechadas na reunião:**

- [ ] Definir terapeutas que vão aparecer no conteúdo
- [ ] Agendar primeiro dia de gravação em lote
- [ ] Receber 3 pautas com roteiro para validar (responsável: LM)
- [ ] Definir responsável pela aprovação do conteúdo na clínica
- [ ] Solicitar acessos pendentes: BM e Google Ads
- [ ] Enviar modelo de autorização de depoimento (LGPD)

---

## Notas da Reunião

_(preencher durante/após a reunião)_

---

**Ver também:** [[2026-04-10 — Clínica Contato]] | [[Dr. Fábio — Comtato (Google Ads)]]

---

**Ver também:** [[Clínica Contato — Dossiê]] | [[Pesquisa Concorrentes — Clínica Contato]] | [[LM — Visão Geral|L.M Agência]]

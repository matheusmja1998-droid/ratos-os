---
cliente: Rafaelly
agencia: LM
tipo: Pauta de Reunião
data: 2026-04-25
proxima-call: Sexta-feira
relacionado: "[[Rafaelly — Pediatra (Infoprodutos)]]"
---

# Pauta — Reunião Rafaelly (Sexta)

**Objetivo da call:** fechar nicho, avatar, ponto A → ponto B, Big Idea e estrutura de oferta. Sair da call com curso definido em estrutura (módulos virão na próxima call).

---

## 1. Diagnóstico do mercado (contexto rápido)

**Sofisticação do mercado de sono infantil: nível 4 (Schwartz).**
Já tem Nana Nenê, várias consultoras de sono, curso concorrente a R$3.097. Promessa direta ("seu bebê vai dormir a noite toda") já está saturada. Precisa de mecanismo único.

**Consciência do prospect: nível 3-4.**
Mãe sente a dor (não dorme), sabe que existe solução, mas não conhece a Rafaelly nem o método dela. Copy lidera pelo problema agitado + revelação de mecanismo.

**Diferencial estrutural da Rafaelly:**
Ela é pediatra. A maioria das concorrentes são consultoras de sono leigas, sem formação médica. Esse é o ângulo que ninguém ocupa hoje.

---

## 2. Definição de nicho

**Recomendação: sono infantil como produto core.**

Razões técnicas (não pessoais):
- Dor mais aguda das 3 (mãe não dorme = compra hoje, não pesquisa por 3 meses)
- Janela de compra urgente (alimentação e obesidade são dores crônicas, sono é diário)
- Resultado mensurável e rápido ("bebê dormindo em 21 dias" é mais nítido que "filho comendo melhor")

**Alimentação e obesidade entram como order bump e upsell**, não como produto principal.

**Risco a mitigar:** Rafaelly tem mais caso prático em alimentação que em sono. Antes da call de produção de conteúdo, ela precisa coletar **3 a 5 cases reais de sono do consultório dela** (com permissão da mãe). Sem prova, mercado nível 4 não converte.

---

## 3. Avatar

**Mãe primeira viagem, bebê de 6 a 24 meses, classe B/C alta a A.**

Por que 6-24 meses:
- Pico de queixa de sono nos consultórios pediátricos
- Tem janela médica clara (introdução alimentar, dentição, regressões de 8m, 12m, 18m)
- Pediatra tem autoridade técnica que consultora leiga não tem (sabe descartar refluxo, alergia, apneia)
- Evita 0-6m (polêmica de "deixar chorar") e evita 2+ anos (vira birra comportamental, foge do escopo médico)

Por que cortar classe C pura:
- Ticket de R$497 não comporta. Foco em B/C alta + A aumenta conversão sem perder volume real.

**Perfil emocional:**
Já tentou de tudo (chá, ninar no colo, cama compartilhada). Casamento desgastado pelo cansaço. Voltou ou está voltando ao trabalho. Sente culpa de não saber o que fazer. Compra por exaustão + segurança ("é médica, não é palpite").

---

## 4. Ponto A → Ponto B

**Ponto A:**
"Meu bebê acorda 4-5 vezes por noite. Eu não durmo há meses. Já tentei tudo que me indicaram, nada funciona por mais de 2 dias. Tô esgotada, com medo de fazer algo errado, e ninguém me dá uma resposta clara, só palpite de sogra e consultora cara."

**Ponto B:**
"Meu bebê dorme a noite toda em 2-3 semanas. Eu durmo. Eu sei o que fazer em cada regressão, em cada fase. Tenho um plano médico, não um chute."

---

## 5. Big Idea (Ogilvy)

> **"O Método da Pediatra. Não é consultoria de sono. É medicina."**

Posicionamento: para a mãe que já gastou dinheiro com consultora de sono leiga e quer a opinião de quem é médica de verdade.

Por que funciona:
- Desconstrói os concorrentes sem citar nome
- Usa um fato verificável (Rafaelly é médica) como diferencial central
- Sustenta 10 anos de comunicação (não é trend)
- Atende ao critério Ogilvy de "fact > adjective"

---

## 6. Estrutura de Oferta (Hormozi)

| Camada | Produto | Preço |
|---|---|---|
| **Atração** (lead magnet) | Aula gratuita: "Os 3 erros que fazem seu bebê acordar à noite" | R$0 |
| **Core** | Curso "Método [Nome] — Sono do Bebê dos 6 aos 24 meses" (6 módulos) | **R$497** |
| **Order bump** (checkout) | Guia de Introdução Alimentar pra Sono Profundo | +R$47 |
| **Upsell 1** (pós-compra) | Curso "Virar o Prato" reposicionado pra mães do core | +R$97 |
| **Upsell 2** (pós-compra) | Pack "Obesidade Infantil — Prevenção dos 2-6 anos" | +R$147 |
| **Continuidade** | Comunidade mensal de mães + conteúdo educativo novo todo mês | R$37/mês |

**Justificativa do ticket de R$497 (não R$297):**
- Concorrente direto vende a R$3.097
- Sofisticação 4 + diferencial médico aguentam ticket maior
- R$297 deprecia a percepção de produto médico
- R$497 é defensável e ainda tem espaço de upsell

**Garantia (Hormozi — Win Your Money Back):**
"Se em 21 dias seu bebê não tiver melhorado o sono, devolvemos 100% + R$50 pelo seu tempo."
Desarma ceticismo de mercado nível 4.

**Sobre a continuidade e o CRM:**
Rafaelly não pode vender consultoria ou mentoria pelo CRM. Comunidade educativa mensal (vídeo novo, e-book, live educacional sem responder caso individual) é caminho técnico viável, mas precisa ser validado com o CRM antes.

---

## 7. Módulos sugeridos (para ela trabalhar até a próxima call)

1. **Diagnóstico médico do sono do seu bebê** — descartar refluxo, alergia, ferro baixo (nenhum concorrente leigo faz isso)
2. **A janela de sono certa por idade** — 6m, 9m, 12m, 18m, 24m
3. **Rotina de sono médica** — ambiente, temperatura, alimentação pré-sono
4. **As 4 regressões clássicas** — 8m, 12m, 18m, dentição
5. **Desmame noturno seguro** — parte mais procurada e mais polêmica entre consultoras leigas
6. **Plano de ação dos 21 dias** — passo a passo aplicado

---

## 8. Tarefas para a Rafaelly antes da call de aulas

- [ ] Coletar 3 a 5 cases reais de sono do consultório (com permissão da mãe, antes/depois)
- [ ] Definir nome do método dela
- [ ] Validar com o CRM se modelo de comunidade educativa mensal é permitido
- [ ] Listar as objeções que mais ouve no consultório sobre sono (vamos usar pra copy)
- [ ] Listar as 5 perguntas mais frequentes de mães sobre sono

---

## 9. Pontos de decisão da call

1. Confirma sono como nicho core?
2. Confirma faixa de 6-24 meses?
3. Confirma corte de classe C pura?
4. Confirma Big Idea "O Método da Pediatra"?
5. Confirma ticket de R$497?
6. Aprova estrutura de bump + 2 upsells + continuidade?
7. Aprova garantia de 21 dias com devolução + R$50?

---

## Próxima call (depois desta)
Aulas do curso e produção de conteúdo.

---

**Hub:** [[LM — Visão Geral|L.M Agência]]

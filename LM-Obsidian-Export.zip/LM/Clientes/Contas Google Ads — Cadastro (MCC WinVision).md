---
tipo: referencia
projeto: Google Ads — Acessos e Contas
mcc: 211-072-5388 (WinVision)
data: 2026-06-01
status: ativo
tags: [google-ads, credenciais, contas, mcc, winvision, lm]
---

# Contas Google Ads — Cadastro (MCC WinVision)

**MCC (login-customer-id):** `211-072-5388` → `2110725388` (sem hífens)
**Conta dona:** matheusmja1998@gmail.com
**Developer token:** Basic Access **aprovado em 01/06/2026** (antes era Test Access, só funcionava em conta de teste). Limite: 15.000 operações/dia.
**Skill:** `google-ads-ratos` (em `Ratos OS/.claude/skills/`). Credenciais no `.env` da própria skill, contas em `contas.yaml`.

## Contas cadastradas

| Cliente | Customer ID (sem hífens) | UI | Agência | Notas |
|---|---|---|---|---|
| Dr. Fábio Freire | `5223015558` | 522-301-5558 | L.M | Clínica IOT — ortopedia, Varginha |
| Escola Avicultores | `8216314513` | 821-631-4513 | — | Cliente novo, ainda sem dossiê/pasta |

## Atenção — Refresh token expira

O refresh token deu `invalid_grant` em 01/06/2026 e teve que ser regenerado via `setup.py oauth`. Causa provável: **OAuth consent screen do projeto Google Cloud em modo "Testing"**, que o Google expira em ~7 dias.

**Pra parar de quebrar:** publicar o consent screen (mudar de "Testing" pra "In production") no Google Cloud Console. Aí o refresh token deixa de expirar sozinho.

Pra regenerar o token quando quebrar de novo:
```bash
cd "/Users/matheusjardim/claude/Ratos OS/.claude/skills/google-ads-ratos" && python3 scripts/setup.py oauth
```
(abre o navegador, logar com matheusmja1998@gmail.com, autorizar — salva sozinho no .env)

---
cliente: Dr. Fábio Freire
empresa: Clínica IOT — Instituto de Ortopedia e Traumatologia
segmento: Saúde / Ortopedia
cidade: Varginha/MG
projeto: Google Ads — Auditoria + Plano Sobral
tipo: auditoria-plano-acao
data: 2026-05-14
status: ativo
tags: [cliente, lm, google-ads, auditoria, sobral, ortopedia, varginha, dr-fabio]
arquivo_origem: /Users/matheusjardim/claude/Ratos OS/lm/clientes/dr-fabio-iot/auditoria-google-ads-2026-05-14/
---

# Dr. Fábio — Auditoria Google Ads + Plano Sobral

**Data:** 14/05/2026
**Conta:** 522-301-5558 (Dr. Fábio Freire)
**Período auditado:** 7 a 13 mai. 2026 (7 dias)
**Acesso usado:** matheusmja1998@gmail.com via MCC 211-072-5388
**Método:** captura via dev-browser na UI do Google Ads (API ainda em "Acesso de teste", aguardando 2ª aprovação do Google)

---

## 1. Sumário Executivo

A conta está enxuta e com fundamentos bons (CTR alto, CPC sob controle, anúncios responsivos qualificados). O gargalo principal NÃO é otimização — é **volume**. A campanha de Pesquisa está **limitada pelo orçamento** e está **deixando conversão na mesa**.

### Métricas atuais (7 dias)

| Métrica | Valor |
|---|---|
| Impressões | 771 |
| Cliques | 76 |
| CTR | 9,86% (excelente) |
| CPC médio | R$ 2,55 |
| Investimento | R$ 194,12 |
| Conversões | 8,00 |
| Custo/conversão | R$ 24,26 |
| Taxa de conversão | 10,53% |

**Projeção 30d (linear):** ~R$ 832 gastos, ~34 conversões. Verba real está em R$30/dia (R$900/mês). Budget previsto no dossiê é R$2.000/mês → **sobra R$1.100/mês não rodando**.

### Verdade incômoda

| Item | Estado |
|---|---|
| 3 dos 4 tipos de conversão configurados | **Sem registro recente** (tracking quebrado) |
| Estamos pagando por busca direta do nome dele | R$ 8,19 por "dr fábio freire ortopedista varginha" sem converter |
| Pagamos por concorrentes | "clínica fort varginha" 6 cliques / R$ 11,97 / 0 conversões |
| Verba | Abaixo do piso Sobral (R$1.200/mês) [L374] |
| Campanha de Marca dedicada | **Não existe** — obrigatória pelo Sobral [L365] |

---

## 2. Estrutura Atual da Conta

```
📁 01 - [PESQUISA] - [LEAD] - [ALTA INTENÇÃO]    R$30/dia  Search  ATIVA
   │   Estratégia: Maximizar Conversões (CPA desejado R$30)
   │   Status: Qualificada — LIMITADA PELO ORÇAMENTO
   │   Pontuação otimização: 69,7%
   │
   ├─ Ad Group: Ortopedista Varginha    (gasto R$145, 4 conv)
   ├─ Ad Group: Dores Específicas        (gasto R$~37, 4 conv)
   └─ Ad Group: Especialidades           (gasto baixo, 0 conv)

📁 Teste                                  R$2,30/dia  Pmax  PAUSADA
```

- **84 palavras-chave** ativas
- **12 anúncios responsivos** (1 com qualidade "Bom", maioria "Médio", 1 "Ruim")
- **134 termos de pesquisa** disparando nos últimos 7 dias

### Distribuição por dispositivo
- Smartphones: **95,5% do custo**
- Computadores: 4,5%
- Tablets: 0%

---

## 3. Diagnóstico Aplicando Sobral

### Os 4 insights principais do método Sobral que mudam o jogo aqui

#### 3.1 Falta campanha de Marca dedicada [L365]
Hoje a busca pelo nome dele ("dr fábio freire", "iot varginha", "clínica iot") roda dentro da campanha genérica, competindo por orçamento com termos de descoberta. Sobral diz: **marca é a 1ª campanha obrigatória, R$5/dia, lance Max Cliques com teto baixo.** Libera margem da campanha principal e domina a SERP do nome.

**Confirmado:** IOT = clínica do Dr. Fábio (não concorrente). Portanto "iot varginha", "clínica iot varginha", "instituto de ortopedia varginha" são keywords de **MARCA** dele.

#### 3.2 Stack mínimo: Search + Marca + Pmax Local + Display Remarketing [L374]
Médico é "negócio de autoridade" — paciente raramente fecha com o primeiro que vê. Precisa de **mera exposição** (Display remarketing) antes de converter. Só Search é "100% colher, 0% plantar".

#### 3.3 Anúncio é FILTRO, não ímã [L372]
Anúncios atuais são genéricos ("Referência em Ortopedia"). Sobral manda usar pelo menos 1-2 dos **7 fatores de segmentação via copy** no headline: Direta, Conhecimento, Ferramenta, Situação, Comportamento, Crença, Rotina.

#### 3.4 Bolo de cenoura fofinho: keyword = anúncio = LP [L315]
Ad group "Especialidades" mistura coluna, joelho e ombro num só lugar → 1 anúncio "Ruim". Sobral pede **1 tema por ad group**.

---

## 4. Plano de Execução — DECISÕES TOMADAS

**O Matheus já aprovou as seguintes execuções** (em conversa de 14/05/2026):

### ✅ Aprovado pra fazer AGORA (Bloco A)
1. **Criar campanha NOVA de Marca, separada** — R$10/dia, Maximizar Cliques
   - (Sobral diz R$5/dia mas o Matheus subiu pra R$10/dia)
2. **Subir verba da Search Genérica atual** de R$30 → R$50/dia
3. **Implementar sugestões de novos anúncios** (tópico 3.3 acima — apresentar pro Matheus aprovar antes de subir)

### ⏸️ Deixar pra DEPOIS (Bloco B — a conversar)
- Reestruturação completa dos ad groups por especialidade
- Pmax Local
- Display Remarketing

---

## 5. Como executar — Bloco A

### 5.1 Campanha NOVA de Marca

**Tipo:** Search
**Objetivo:** Leads (ou Tráfego do site, se sem conversão configurada na URL)
**Lance:** Maximizar Cliques com **teto de CPC: R$ 1,50** (busca de marca é barata)
**Orçamento:** R$ 10/dia
**Rede:** somente Search — **DESLIGAR** "Incluir parceiros de pesquisa do Google" e "Incluir rede de Display" [L365]
**Geo:** Brasil (não restringir a Varginha — quem busca o nome dele pode estar em qualquer lugar)
**Modo geo:** Presença (não Interesse) [L365]
**Idiomas:** Português + Inglês + Espanhol [L365]
**Programação:** rodar 24/7

#### Estrutura interna
Um ad group único: **`Marca - Dr. Fábio + IOT`**

#### Keywords (exatas e frase)

```
# Marca pessoal
[dr fabio freire]
[dr fábio freire]
[dr. fabio freire]
[dr. fábio freire]
[dr fabio freire varginha]
[dr fábio freire varginha]
[dr fabio ortopedista]
[dr fabio ortopedista varginha]
[fabio freire ortopedista]
"dr fabio freire ortopedista"
"dr fábio freire ortopedista"
"dr fabio freire traumatologista"
"dr fábio freire traumatologista"
"avaliações dr fabio freire"
"avaliações dr fábio freire"

# Marca da clínica (IOT = Instituto de Ortopedia e Traumatologia)
[clinica iot varginha]
[clínica iot varginha]
[instituto de ortopedia varginha]
[instituto de ortopedia e traumatologia varginha]
[iot varginha]
"clinica iot varginha"
"clínica iot varginha"
"instituto de ortopedia"
"instituto de ortopedia e traumatologia"
"iot varginha"
"número de telefone clínica iot"
"telefone clínica iot varginha"
```

#### Negativas obrigatórias na Marca

```
-emprego  -vaga  -estágio  -currículo  -carreira  -salário
-faculdade  -formação  -graduação  -curso  -crm
-falecimento  -obituário  -notícia  -morreu  -faleceu
-grátis  -gratuito  -de graça
-piada  -meme
```

#### RSA da Marca (1 anúncio responsivo)

**URL final:** `https://drfabiofreire.com.br/?utm_source=google&utm_medium=cpc&utm_campaign=marca`
**Caminho de exibição:** `/dr-fabio-freire`

**15 Headlines (cada um pode ter até 30 caracteres):**
1. Dr. Fábio Freire Ortopedista
2. Especialista em Ortopedia | Varginha
3. Instituto de Ortopedia IOT
4. Agende sua Consulta Direto
5. Atendimento Particular em Varginha
6. Ortopedia que Escuta. Você no Centro.
7. Agendar pelo WhatsApp Agora
8. Cirurgião Ortopédico em Varginha
9. Avaliações 5★ na Doctoralia
10. Joelho, Coluna, Ombro: Tratamos Tudo
11. Consultas Particulares e Convênios
12. Site Oficial Dr. Fábio Freire
13. Especialista em Dor Articular
14. Referência em Ortopedia em Varginha
15. Diagnóstico Preciso na 1ª Consulta

**4 Descriptions (cada uma até 90 caracteres):**
1. Site oficial do Dr. Fábio Freire — ortopedista referência em Varginha. Agende online.
2. Consulta longa, escuta atenta, diagnóstico preciso. Tratamento individualizado pra você.
3. Anos de experiência em joelho, coluna e trauma esportivo. Atendimento humanizado.
4. Atendimento particular em consultório próprio. Agendamento rápido via WhatsApp.

**Pinning (opcional, sugestão):**
- Headline 1 (Dr. Fábio Freire Ortopedista) → pin Position 1
- Headline 3 (Instituto de Ortopedia IOT) → pin Position 2
- Restante: livre pra Google testar

#### Extensões obrigatórias [L365]
- **Chamada (telefone)** — número do consultório
- **Mensagem (WhatsApp)** — link WhatsApp Business
- **Local** — Google Meu Negócio linkado
- **Sitelinks (4):**
  - "Especialidades" → `/especialidades`
  - "Sobre o Dr. Fábio" → `/sobre`
  - "Doctoralia" → link Doctoralia
  - "Agendar Online" → `/agendar`
- **Callouts (4):**
  - "Avaliações 5★"
  - "Consulta longa"
  - "Atendimento humanizado"
  - "Resposta em até 1h no WhatsApp"
- **Snippets estruturados (Serviços):**
  - Joelho, Coluna, Ombro, Quadril, Pé e Tornozelo, Trauma Esportivo

---

### 5.2 Subir verba da Search Genérica (campanha atual)

**De:** R$ 30/dia
**Para:** R$ 50/dia
**Como:** dentro da campanha `01 - [PESQUISA] - [LEAD] - [ALTA INTENÇÃO]` → Configurações → Orçamento → editar
**Observação:** Sobral [L365] recomenda subir verba de forma **gradual** quando CPA está saudável. CPA atual R$24 vs meta R$30 → tem folga. Risco: CPA pode subir um pouco. Reverter se passar de R$35/conversão.

---

### 5.3 Sugestões de novos anúncios pra Search Genérica

⚠️ **Apresentar pro Matheus aprovar antes de subir.**

**Princípio aplicado:** Sobral [L372] — "Anúncio é FILTRO. Use os 7 fatores: Direta, Conhecimento, Ferramenta, Situação, Comportamento, Crença, Rotina."

#### Ad Group: Ortopedista Varginha — RSA novo

**URL final:** `https://drfabiofreire.com.br/ortopedista-varginha?utm_source=google&utm_medium=cpc&utm_campaign=search-generica&utm_content=ortopedista-varginha`
**Caminho:** `/ortopedista/varginha`

**15 Headlines:**
1. Ortopedista em Varginha que Escuta
2. Atendimento Particular Sem Pressa            ← Crença
3. Você há +30 dias com Dor?                    ← Situação
4. Consulta Longa, Diagnóstico Real
5. Dr. Fábio Freire — Instituto IOT
6. Avaliações 5★ na Doctoralia
7. Agende sua Consulta em 1 Minuto
8. Ortopedista Particular em Varginha
9. Diagnóstico Antes do Tratamento              ← Comportamento
10. Não é Mais uma Receita Genérica             ← Crença
11. Joelho, Coluna, Ombro, Quadril
12. WhatsApp da Clínica IOT
13. Especialista que Olha no Olho
14. Atendimento Humanizado em Varginha
15. Particular ou Convênio: Confira

**4 Descriptions:**
1. Atendimento particular em Varginha. Consulta longa, escuta atenta e diagnóstico preciso na 1ª.
2. Especialista em joelho, coluna, ombro e trauma esportivo. Plano de tratamento individualizado.
3. Avaliações 5★ na Doctoralia. Mais de [X] pacientes atendidos. Agende pelo WhatsApp.
4. Instituto de Ortopedia e Traumatologia em Varginha. Atendimento que te coloca no centro.

#### Ad Group: Dores Específicas — RSA novo

**URL final:** `https://drfabiofreire.com.br/dores?utm_source=google&utm_medium=cpc&utm_campaign=search-generica&utm_content=dores-especificas`

**15 Headlines:**
1. Dor no Joelho Que Não Passa?                 ← Situação
2. Vamos Descobrir a Causa Real                 ← Direta
3. Hérnia de Disco? Tratamento Sob Medida       ← Situação + Crença
4. Dor no Ombro ao Levantar o Braço             ← Situação
5. Especialista em Dor Articular
6. Diagnóstico em 1 Consulta                    ← Comportamento
7. Sem Receita Decorada                         ← Crença
8. Dr. Fábio Freire — Ortopedia
9. Avaliações 5★ na Doctoralia
10. Consulta Longa, Sem Pressa
11. Atendimento Particular em Varginha
12. Agende pelo WhatsApp Agora
13. Cirurgia ou Tratamento Conservador?         ← Conhecimento
14. Cansou de Ouvir "É da Idade"?               ← Crença
15. Tratamento Individualizado, Não Genérico

**4 Descriptions:**
1. Você convive com dor que limita esporte, trabalho ou sono? Vamos descobrir a causa juntos.
2. Consulta longa, exame físico completo, plano de tratamento sob medida. Sem pressa.
3. Especialista em joelho, coluna, ombro e quadril. Atendimento particular em Varginha.
4. Mais de [X] dores articulares tratadas por ano. Avaliações 5★. Agende pelo WhatsApp.

#### Ad Group: Especialidades — RSA novo

⚠️ Esse é o ad group mais fraco hoje (1 RSA com qualidade "Ruim"). Ideal seria reestruturar (Bloco B), mas pra agora:

**URL final:** `https://drfabiofreire.com.br/especialidades?utm_source=google&utm_medium=cpc&utm_campaign=search-generica&utm_content=especialidades`

**15 Headlines:**
1. Especialista em Joelho — Varginha
2. Especialista em Coluna — Varginha
3. Especialista em Ombro — Varginha
4. Cirurgião de Joelho em Varginha
5. Tratamento de Hérnia de Disco
6. Manguito Rotador e Ombro
7. Trauma Esportivo e Lesão
8. Dr. Fábio Freire — Instituto IOT
9. Atendimento Particular em Varginha
10. Avaliações 5★ na Doctoralia
11. Agende sua Consulta pelo WhatsApp
12. Consulta Longa, Diagnóstico Sólido
13. Mais de [X] Cirurgias por Ano
14. Especialista que Escuta Antes de Operar    ← Comportamento + Crença
15. Cirurgia Só Quando Necessária              ← Crença

**4 Descriptions:**
1. Especialista em joelho, coluna, ombro, quadril e pé. Atendimento particular em Varginha.
2. Consulta longa, exame físico completo. Plano de tratamento sob medida pra você.
3. Cirurgia só quando necessária. Tratamento conservador prioritário sempre que possível.
4. Avaliações 5★ na Doctoralia. Dr. Fábio Freire — Instituto de Ortopedia e Traumatologia.

---

## 6. Quality Gates — Onde Dr. Fábio Está

| Métrica | Atual | Bom (Sobral) | Status |
|---|---|---|---|
| CTR Search | 9,86% | 3,5–5% | ✅ Excelente |
| CPA | R$24,26 | R$30–80 saúde | ✅ Bom |
| CPC médio | R$2,55 | depende do nicho | ✅ Saudável |
| Quality Score anúncios | 1 Bom, vários Médio, 1 Ruim | ≥6 (bom), ≥8 (ótimo) | 🟡 Mediano |
| Impression Share | "Limitada pelo orçamento" | ≥80% | 🔴 Crítico |
| Verba mensal | R$900 (projeção) | mínimo R$1.200 local | 🔴 Abaixo do piso |
| Match types | broad em 4/10 keywords ativas | phrase/exact com R$30/dia | 🟡 Atenção |
| Campanha de marca dedicada | Não existe (em criação) | Obrigatória [L365] | 🔄 Em execução |
| Negativas configuradas | Poucas | Lista densa [L323] | 🟡 Atenção |

---

## 7. Métricas pra acompanhar (revisão em 14 dias)

| Métrica | Baseline 14/05 | Meta 28/05 | Meta 14/06 |
|---|---|---|---|
| Investimento/mês | ~R$ 900 | R$ 1.800 | R$ 1.950 |
| Conversões/mês | ~34 (projeção) | 70 | 100 |
| Custo/conv. | R$ 24,26 | ≤ R$ 28 | ≤ R$ 25 |
| CTR | 9,86% | ≥ 10% | ≥ 12% |
| Pontuação otimização | 69,7% | ≥ 80% | ≥ 90% |
| % conversões de marca vs. genéricas | desconhecido | separar e medir | 30% / 70% |

---

## 8. Backlog — pra conversar depois (Bloco B)

### 8.1 Reestruturação de ad groups em 5 temas
Aplicando "bolo de cenoura fofinho" [L315]:
- AG1: Cidade Genérica (ortopedista varginha puro)
- AG2: Joelho
- AG3: Coluna
- AG4: Trauma/Esportivo
- AG5: Ombro

Cada um com LP específica. Hoje "Especialidades" mistura tudo e tem RSA "Ruim".

### 8.2 Pmax Local
- Objetivo: visitas ao consultório + ligações
- Verba: R$15/dia
- Geo: Varginha + raio 50km
- Audience signals: pacientes (custom audience) + saúde/esporte amador, 35+

### 8.3 Display Remarketing
- Verba: R$5/dia
- Audience: visitantes do site últimos 30d que não converteram
- Frequência: 3x/dia/pessoa

### 8.4 Match types — migrar broad pra phrase
| Keyword | Match atual | Migrar pra |
|---|---|---|
| ortopedista em varginha | broad | "ortopedista em varginha" |
| ortopedista varginha | broad | "ortopedista varginha" |
| especialista em articulações | broad | "especialista em articulações" |
| ortopedista esportivo | broad | **pausar** (0 impressões) |

### 8.5 Negativas universais Sobral [L323]
Lista pronta pra adicionar em massa:
```
-grátis  -gratis  -gratuito  -de graça  -barato  -sem custo
-faixa  -na faixa  -template  -modelo  -exemplo  -planilha
-como  -o que é  -por que  -definição  -conceito
-senha  -login  -registro  -cadastro
-emprego  -vaga  -estágio  -currículo  -carreira  -salário
-faculdade  -curso  -formação  -graduação
-amostra  -comparação  -versus  -vs
```

### 8.6 Negativas de concorrentes locais
```
-"clinica fort"  -"clínica fort"  -"clinica forte"
-"dr jesse"  -"dr jessé"  -"dr corujinha"
-"dr plinio"  -"dr ricardo"  -"dr eduardo"  -"dr ernani"
-"dr valterlei"  -"dr bricio"
-"fisiocenter"  -"fisiocorpus"  -"fort hospitalar"
-"hapvida"  -"unimed"      ← confirmar com Dr. Fábio se atende esses planos
```

### 8.7 As 2 dicas-bomba Sobral pra agência [L374]
1. **Grupo VIP de WhatsApp** com base de pacientes atual — postar 2-3x/semana
2. **Reativação de pacientes inativos +90 dias** — mensagem template

---

## 9. Referências do método

- **[L315]** Live 315 — Como criar campanhas no Google Ads em 2025 (bolo de cenoura)
- **[L323]** Live 323 — Segmentações, públicos e palavras-chave no Google Ads (negativas, intenção, match types)
- **[L365]** Live 365 — Google Ads 2026 — Como anunciar (stack, campanha de marca, geo)
- **[L367]** Live 367 — Como segmentar seus anúncios (públicos quentes > frios)
- **[L372]** Live 372 — Copywriting Parte I (GCC, 7 fatores, anúncio é filtro)
- **[L373]** Live 373 — Copywriting Parte II (depoimentos, maldição do conhecimento)
- **[L374]** Live 374 — Estratégias de tráfego para negócios locais (médicos, autoridade, mera exposição)

---

## 10. Histórico

- **14/05/2026** — Auditoria executada via dev-browser (API ainda em "Acesso de teste"). Plano Sobral consolidado. Matheus aprovou Bloco A (campanha de Marca R$10/dia + verba Search R$30→R$50 + novos RSAs). Bloco B fica pra próxima conversa.

---

## 11. Arquivos brutos da auditoria

Pasta: `/Users/matheusjardim/claude/Ratos OS/lm/clientes/dr-fabio-iot/auditoria-google-ads-2026-05-14/`

- `AUDITORIA.md` — relatório base
- `SUGESTOES-SOBRAL.md` — aplicação Sobral completa
- `screenshots/` — capturas das telas (01-overview, 02-campaigns, 03-adgroups, 04-keywords, 05-ads, 06-search-terms)
- `0X-*.txt` — textos brutos extraídos das telas

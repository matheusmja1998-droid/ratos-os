# Big Idea — Aprofundamento (Rafaelly)

Material consolidado de duas conversas: (1) o que é sofisticação Schwartz e por que a Big Idea foi pra "O Método da Pediatra"; (2) como essa Big Idea se desdobra em copy e atravessa toda a escada de oferta.

---

## Parte 1 — O que é sofisticação de mercado (Schwartz)

**Sofisticação não é sobre o prospect. É sobre o mercado.**

Consciência mede o quanto a pessoa que vai comprar sabe sobre o problema dela e sobre você. Sofisticação mede outra coisa: quantas vezes o mercado já ouviu promessas parecidas com a sua antes de você chegar.

A diferença prática: dois prospects podem estar no mesmo nível de consciência ("sei que existe método pra fazer bebê dormir"), mas se um está num mercado virgem e o outro num mercado saturado, a copy que vende pra eles é radicalmente diferente.

Schwartz mapeou que todo mercado passa por 5 estágios. **Se você usa a copy do estágio errado, você morre — mesmo com produto bom.**

### Os 5 estágios

**Estágio 1 — Mercado virgem.** Você é o primeiro a fazer essa promessa. Estratégia: promessa direta e simples. Exemplo: o primeiro creme de barbear em tubo. "Barba sem precisar bater espuma." Ponto.

**Estágio 2 — Concorrentes copiaram a promessa.** Estratégia: amplificar a promessa. Mais específico, mais ousado, mais rápido. Exemplo: "Perca peso" vira "Perca 10 quilos em 30 dias."

**Estágio 3 — Mercado começou a duvidar.** Promessa pura já não cola. Estratégia: introduzir um mecanismo único — o "como" por trás da promessa. Exemplo: "Perca 10 kg em 30 dias com a dieta cetogênica japonesa."

**Estágio 4 — Mecanismos demais.** Mecanismo virou commodity. Estratégia: sofisticar e aprofundar o mecanismo. Torná-lo proprietário. Exemplo: "O Protocolo Cetogênico de 7 Fases desenvolvido em parceria com a Universidade de Tóquio."

**Estágio 5 — Mercado exausto.** Prospect não acredita em mais nada. Estratégia: abandonar promessa direta. Liderar com identificação — história, persona, tribo. Exemplo: dieta vendida pela história pessoal de quem perdeu 50 kg, virou movimento, comunidade.

---

## Parte 2 — Por que sono infantil está em sofisticação 4

**Evidência 1 — Já existe um líder estabelecido.** Nana Nenê é top of mind do nicho.

**Evidência 2 — Existe ticket alto consolidado (R$3.097).** Ticket alto só sustenta em mercado que já provou que entrega.

**Evidência 3 — Tem dezenas de consultoras de sono leigas vendendo.** Quando uma categoria gera profissão paralela, virou commodity.

**Evidência 4 — As mães já estão cansadas de método.** "Já tentei o método X, o método Y, nada funciona."

**Por que não é estágio 5 ainda:** mães ainda compram cursos, ainda contratam consultora, ainda buscam solução. Estão céticas, não anestesiadas.

---

## Parte 3 — A regra Schwartz pra estágio 4

Em estágio 4, **você não pode competir no mesmo plano dos concorrentes.** Se inventar mais um mecanismo ("Método Soneca Dourada"), vira mais um na pilha.

Duas saídas:

**Saída A — Sofisticar o mecanismo até virar proprietário.** Sistema com camadas, fases, certificação. Exige autor com autoridade prévia (PhD, pesquisador, instituição). **Não funciona pra Rafaelly** (2 anos de prática, 6k seguidores).

**Saída B — Mudar de plano.** Sair do jogo de "qual o melhor método" e mudar a categoria mental que o prospect usa. **Caminho da Rafaelly.**

---

## Parte 4 — A Big Idea: por que "O Método da Pediatra"

Quando você olha a Rafaelly contra os concorrentes, qual é o fato que ninguém mais tem?

- Nana Nenê: consultora de sono. Não é médica.
- Maioria das concorrentes: certificação não regulamentada. Não são médicas.
- Concorrente de R$3.097: provavelmente também consultora.

**O fato é: Rafaelly é médica pediatra. Quase nenhum concorrente é.**

Esse fato muda a categoria mental:

**Antes (jogo dos concorrentes):** "Qual método de sono é o melhor?" → mãe compara → todos prometem a mesma coisa → escolhe pelo preço.

**Depois (jogo da Rafaelly):** "Eu quero opinião médica, não palpite de consultora." → mãe entra no jogo de comparar autoridade técnica → Rafaelly é a única opção viável.

### Big Idea

> **"O Método da Pediatra. Não é consultoria de sono. É medicina."**

A segunda frase faz trabalho cirúrgico: classifica os concorrentes sem nomear. Quando a mãe lê "não é consultoria de sono", rebaixa Nana Nenê e demais pro mesmo balde — "consultoria leiga" — e posiciona Rafaelly num balde superior — "medicina".

### Teste das 5 perguntas Ogilvy

1. **Te fez prender a respiração?** Sim, inverte o jogo do nicho.
2. **Você gostaria de ter tido?** Sim, óbvia em retrospecto, ninguém usa.
3. **É única?** Sim, poucas pediatras vendem curso de sono em escala.
4. **Encaixa na estratégia?** Sim, bate com ticket, avatar e diferencial real.
5. **Pode ser usada por 30 anos?** Sim, "sou médica" não envelhece. Métodos envelhecem.

### Onde a Big Idea pode falhar

1. **Se Rafaelly não defender tecnicamente.** Mãe pergunta "qual a diferença entre seu método e o da Nana Nenê?" e ela não souber responder com termos médicos (ferritina, refluxo, apneia, neurodesenvolvimento), Big Idea morre.
2. **Se ela não tiver cases.** Big Idea sem prova é arrogância. Tarefa de coletar cases é não-negociável.
3. **Se o mercado migrar pra estágio 5.** Mães tão exaustas que nem "médica" funciona mais. Não vejo sinais ainda.

### Lógica completa

```
Mercado em sofisticação 4 (Schwartz)
    ↓
Não dá pra competir com mais um mecanismo
    ↓
Precisa mudar a categoria mental do prospect
    ↓
Buscar o fato mais diferenciador (Ogilvy)
    ↓
Fato: ela é médica, concorrentes não são
    ↓
Big Idea: "O Método da Pediatra. Não é consultoria. É medicina."
    ↓
Reposiciona o jogo: de "qual método" pra "qual autoridade"
    ↓
Nesse novo jogo, Rafaelly é a única opção viável
```

---

## Parte 5 — Como a Big Idea vira copy

Princípio: **uma Big Idea forte é fonte única que alimenta toda comunicação.** Headline, anúncio, post, email, lead da landing page, abertura da aula gratuita — tudo sai dela. Se você precisa "criar copy nova" pra cada peça, a Big Idea é fraca.

### A. Headlines

**1. Problema agitado (estágio 4 puro)**
> "Você já tentou 3 métodos de sono e seu bebê continua acordando 5 vezes por noite. O problema não é o método. É que ninguém olhou seu filho como médico."

**2. Proclamação ousada**
> "Pediatra revela por que a maioria dos cursos de sono não funciona — e o que ela faz diferente no consultório."

**3. Identificação**
> "Para a mãe exausta que quer parar de receber palpite e começar a receber diagnóstico."

**4. Factual (Ogilvy)**
> "Em 2 anos de consultório, esta pediatra atendeu mais de [X] casos de bebês que não dormiam. O que ela aprendeu não está em curso nenhum."

**5. Mecanismo (categoria nova) — headline-mãe da landing**
> "O Método da Pediatra: por que diagnóstico médico vem antes de rotina de sono."

### B. Lead da landing page

> Se você tá lendo isso, provavelmente já tentou de tudo.
>
> Já leu artigo no blog. Já assistiu vídeo no YouTube. Talvez já comprou um curso de consultora de sono. E mesmo assim seu bebê continua acordando 4, 5 vezes por noite — e você continua sem dormir.
>
> Você não tá fazendo nada errado. O problema é outro.
>
> Quase todos os cursos de sono infantil são feitos por consultoras leigas. Pessoas que fizeram um curso de certificação de fim de semana e começaram a vender método. Elas ensinam rotina, ambiente, janela de sono — e funciona pra alguns bebês.
>
> Mas pra muitos bebês não funciona. E quando não funciona, ninguém olha pra causa real.
>
> Refluxo silencioso. Ferritina baixa. Alergia ao leite de vaca. Apneia. Cinco causas médicas que fazem o bebê acordar a noite toda — e que nenhuma consultora pode diagnosticar, porque não é função dela.
>
> Sou Dra. Rafaelly, pediatra. Atendo bebês com problema de sono no consultório todos os dias. E criei um método que começa onde os outros nem chegam: pelo diagnóstico médico.

**O que esse lead faz:**
- Valida frustração (Schwartz estágio 4)
- Reposiciona culpa (tira da mãe, joga no mercado)
- Ataca concorrentes sem nomear (Ogilvy)
- Apresenta mecanismo único (diagnóstico antes de rotina)
- Apresenta autora com autoridade (fato Ogilvy)

### C. Anúncio de tráfego

**Versão 1 — identificação**
> Mãe, você não dorme há meses?
> Antes de comprar mais um curso de consultora de sono, você precisa saber de uma coisa.
> Existem 5 causas médicas que fazem bebê acordar a noite toda — e nenhuma rotina de sono resolve, porque o problema não é comportamental.
> Sou pediatra. Atendo isso no consultório todos os dias. Te explico em uma aula gratuita.

**Versão 2 — proclamação**
> A maioria dos cursos de sono infantil é feita por gente que não é médica.
> Funciona pra alguns bebês. Pra outros, não — porque tem causa médica que ninguém investigou.
> Refluxo silencioso. Ferritina baixa. Alergia. Apneia.
> Eu sou pediatra e mostro tudo isso na aula gratuita.

### D. Post de Instagram (carrossel)

1. "Por que cursos de sono infantil falham com tantos bebês?"
2. "Porque 90% deles ensinam apenas rotina e ambiente. E pra muitos bebês, isso não é o problema."
3. "O problema é médico. E ninguém investiga porque consultora de sono não pode."
4-6. Lista das 5 causas médicas (refluxo, ferritina, alergia, apneia, neurodesenvolvimento)
7. "Sou pediatra. Atendo isso no consultório. Quando o sono não é comportamental, ele é médico — e tem solução."
8. "Salva esse post se você ainda tá tentando descobrir o que tá acontecendo com o sono do seu bebê."

### E. Email (sequência pós lead magnet)

- Email 1: história pessoal da Rafaelly — por que virou pediatra, por que escolheu sono
- Email 2: caso clínico real (bebê do consultório com sono ruim, descobriu refluxo, resolveu)
- Email 3: ataque à categoria de consultora (sem nomear)
- Email 4: apresentação do curso como produto que aplica o método do consultório
- Email 5: prova social + garantia + urgência
- Email 6: última chamada

---

## Parte 6 — Como a Big Idea atravessa a escada de oferta

Hormozi: **toda escada de oferta vende a mesma transformação, em camadas diferentes.** Se cada produto vende coisa diferente, vira bazar. Se todos reforçam a mesma Big Idea, vira ecossistema.

### Camada 1 — Atração (aula gratuita "Os 3 erros que fazem seu bebê acordar à noite")

Os 3 erros precisam ser **erros que só pediatra identifica**:
1. Tratar como comportamental algo que é médico (refluxo silencioso, ferritina)
2. Ignorar sinal de alerta de apneia obstrutiva (criança que ronca)
3. Seguir rotina sem fazer exame de sangue básico

Se a aula ensinasse "rotina de sono", a Big Idea morreria no primeiro contato.

### Camada 2 — Core (curso R$497)

A estrutura do curso é a Big Idea materializada. Por isso o **módulo 1 é "Diagnóstico médico do sono do seu bebê"** — palavra médica.

Ordem dos módulos importa:
1. Diagnóstico médico → autoridade médica primeiro
2. Janela de sono por idade → conhecimento pediátrico aplicado
3. Rotina de sono médica → "rotina" ressignificada como prescrição
4. As 4 regressões clássicas → vocabulário pediátrico
5. Desmame noturno seguro → segurança = autoridade médica
6. Plano de ação dos 21 dias → entrega do resultado

**Bônus que reforçam Big Idea:**
- Modelo de lista de exames pra mãe levar ao pediatra
- Protocolo de quando voltar ao médico (red flags)
- Glossário de termos médicos pediátricos

### Camada 3 — Order Bump (R$47 — Guia de Introdução Alimentar pra Sono Profundo)

Se for "receitas de papinha", dilui tudo. Precisa ser **médico-nutricional**:
- Nutrientes que regulam melatonina (triptofano, magnésio, B6)
- Alimentos que pesquisa pediátrica relaciona a sono fragmentado
- Janela alimentar antes do sono (intervalo médico, não receita)
- O que evitar segundo Sociedade Brasileira de Pediatria

### Camada 4 — Upsell 1 (R$97 — "Virar o Prato" reposicionado)

Reposicionamento: "Para a mãe que já tem o sono do filho regulado e agora quer evitar os 3 erros alimentares mais comuns que pediatras vêm corrigindo no consultório."

Capa muda. Headline muda. Conteúdo pode até ser parecido — embalagem é "extensão da pediatra que já te ajudou a resolver o sono".

### Camada 5 — Upsell 2 (R$147 — Pack Obesidade 2-6 anos)

Big Idea ganha **dimensão temporal**. Sono = dor aguda (agora). Alimentação = dor presente (próximo trimestre). Obesidade = dor futura (próximos anos).

Posicionamento: "Você cuidou do sono. Você ajustou a alimentação. Agora vamos blindar o futuro do seu filho contra a doença crônica que mais cresce em crianças brasileiras."

A escada conta uma história única: **a Pediatra que cuida do seu filho da fase do berço até a idade escolar.**

### Camada 6 — Continuidade (R$37/mês — comunidade)

Comunidade vira facilmente "grupo de WhatsApp pra trocar experiência" — destrói Big Idea.

Posicionamento certo: **"A Comunidade da Pediatra. Acesso mensal a conteúdo médico novo, conforme seu filho cresce e novas dúvidas aparecem."**

Cada mês:
- 1 vídeo educativo sobre fase do desenvolvimento
- 1 atualização de pesquisa pediátrica recente
- 1 live mensal de Q&A educativa (sem caso individual, por causa do CRM)
- E-book mensal sobre tema pediátrico

Não é fórum. É **assinatura de boletim médico-pediátrico em formato digital.**

### O efeito cumulativo

| Camada | A mãe pensa |
|---|---|
| Aula gratuita | "Nossa, ela é médica de verdade. Ninguém tinha me falado dessas causas." |
| Curso R$497 | "Comprei o método da pediatra. Não é mais um curso de sono." |
| Bump R$47 | "A alimentação também tem ciência. Ela explica como pediatra." |
| Upsell R$97 | "Já que ela me ajudou com sono, vou seguir o protocolo dela pra alimentação." |
| Upsell R$147 | "Faz sentido prevenir obesidade agora — ela vê os dois lados." |
| Continuidade | "Vou manter contato. Ela é minha referência pediátrica online." |

Big Idea funciona como gravidade — puxa toda decisão pra mesma direção. A mãe não decide "comprar mais um produto". Ela tá **continuando o relacionamento com a pediatra dela.**

### Armadilhas a evitar

1. **LM não pode produzir conteúdo "genérico de sono".** Cada peça precisa passar pelo filtro: "isso só uma pediatra poderia escrever?" Se não, refazer.
2. **Linguagem visual precisa acompanhar.** Identidade não pode ser "cute, fofa, lifestyle". Tem que ser limpa, médica, séria — sem virar fria. Pensa Hospital Albert Einstein, não Mães da Quebrada.
3. **Rafaelly precisa "ser a pediatra" online.** Se posta storie tomando vinho, lifestyle, dilui. Não precisa virar robô médico, mas o eixo precisa ser autoridade médica acessível, não influencer pediatra.

---

## Pontos a aprofundar no futuro

1. **Variações da Big Idea** — testar 3-4 versões diferentes da mesma ideia central
2. **Como a Big Idea se desdobra na copy** ✅ (feito nesta nota)
3. **Risco do CRM** — se "Método da Pediatra" pode ter problema com Conselho de Medicina (vender curso usando título profissional tem regras)
4. **Como a Big Idea casa com a estrutura de oferta** ✅ (feito nesta nota)
5. **Aprofundar o nome do método** (em vez de "Método [Nome]" genérico)
6. **Roteiro completo da aula gratuita** (lead magnet é o ponto onde a Big Idea conquista ou perde a mãe)
7. **Calendário editorial de Instagram + TikTok** (1 mês de posts saindo da Big Idea)
8. **Argumentação pra reunião com a Rafaelly** se ela resistir a algum ponto (ticket, posicionamento, corte de classe C)

---

**Hub:** [[LM — Visão Geral|L.M Agência]]

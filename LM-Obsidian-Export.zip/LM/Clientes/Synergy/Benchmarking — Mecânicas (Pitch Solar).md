---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
segmento: Mecânicas
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, mecanica, mt]
---

# Benchmarking — Mecânicas (Pitch Solar Synergy)

> Pesquisa de mercado pra prospecção ativa de energia solar B2B em oficinas mecânicas na praça da Synergy.

---

## Contexto regional

- **Distribuidora:** Energisa MT. Reajuste tarifário homologado pela ANEEL em 01/04/2025 — **+0,34% pra baixa tensão** (B3).
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh.
- **Irradiação solar MT:** 5,2–5,6 kWh/m²/dia (top 3 do Brasil) → payback acelerado.
- **Tangará da Serra:** cidade com forte atividade automotiva. Sapezal e Diamantino têm boa demanda por mecânica pesada (agro).

---

## Perfil de consumo

- **Mecânica pequena (2–3 elevadores, sem ar condicionado):** 500–1.200 kWh/mês
- **Mecânica média (compressor grande, solda, ar comprimido, ar no escritório):** 1.500–3.500 kWh/mês
- **Centro automotivo / oficina especializada (alinhamento computadorizado, máquinas pneumáticas):** 4.000–8.000 kWh/mês
- **Energia elétrica = 15% do custo operacional médio de uma oficina** (Guia do Óleo)

## Conta de luz estimada (MT, tarifa B3)

- Pequena: **R$ 500–1.200/mês**
- Média: **R$ 1.500–3.500/mês**
- Grande: **R$ 4.000–8.000/mês**

## Ticket médio do sistema solar

**R$ 15–60 mil**

---

## Dor principal (linguagem do dono)

> "Mês passado a conta veio R$ 2.800. Antes era R$ 2.100. Tô pensando em passar pra ar condicionado mais econômico, mas o problema é o compressor que fica ligado o dia inteiro."

## Decisor

- Dono mecânico ou casal sócio
- Decide sozinho
- Geralmente já trabalha 10–20 anos no ramo
- Conservador, gosta de ver no papel
- **Ciclo de decisão curto** (sem comitê)

---

## Ângulo de pitch

> "Energia é 15% do seu custo operacional. Em 3 anos a Synergy zera essa linha. Você ganha 15% de margem extra pra vida toda. Em 25 anos isso compra outra oficina."

**Argumento técnico:** "Telhado de oficina é largo, plano, sem aparelhos em cima. É o telhado mais barato pra instalar do Brasil."

---

## Gatilhos de urgência

- **Reajuste Energisa anual** (abril)
- **Aumento de seguro/aluguel** (qualquer custo fixo subindo) → solar é o único que **trava** o custo
- **Concorrência:** "concorrente com solar pode baixar mão de obra"
- **Renovação de equipamento** (elevador novo, compressor maior) → "compra junto"

---

## Volume na região

- **Estimativa: 150–250 oficinas** mecânicas (carro + moto + caminhão) na praça da Synergy
- Tangará da Serra concentra a maioria
- Sapezal + Diamantino têm bom volume por causa do agro (manutenção de máquina pesada)

## Sub-segmento ouro

**Mecânicas de caminhão e máquina agrícola** em Sapezal e Diamantino. Conta de luz muito maior (compressores grandes, soldas pesadas, fresas) e dono empresário (não só mecânico fundo de quintal).

---

## Pontos de atenção

- Dono mecânico desconfia de oferta financeira → pedido é **simulação no papel da conta dele**, não simulador genérico
- Algumas oficinas alugam galpão → validar primeiro com o **dono do imóvel** ou contrato de aluguel longo
- Ticket menor que supermercado, mas ciclo de venda mais curto

---

## Score pra prospecção

| Ticket médio | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|
| R$ 15–60 mil | Alto (150–250) | Muito rápido | ⭐⭐⭐⭐ |

**Ranking: 4º** entre os 5 segmentos prioritários. **Maior volume da lista** — bom pra ramping de SDR novato (Camila, Diana).

---

**Fontes:**
- ANEEL Resolução 3.440 (Energisa MT)
- Sebrae DataMPE — Tangará da Serra
- Guia do Óleo / Blog Mobil (consumo oficina)
- Canal Solar / Portal Solar (cases mecânica)

---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
fonte: Adaptação do prompt "Benchmarking de Nicho" (Adriano Aquino) para prospecção B2B solar
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, mt]
---

# Benchmarking de Segmentos B2B — Pitch Solar Synergy

> Pesquisa de mercado dos 5 primeiros segmentos prioritários da Synergy pra prospecção ativa de energia solar em Tangará da Serra, Diamantino, Sapezal, Nova Olímpia e Barra do Bugres.
> Cada segmento traz: perfil de consumo de energia, dor financeira, decisor, ângulo de pitch, gatilhos de urgência e pontos de atenção.

---

## Contexto regional (vale pros 5 segmentos)

- **Distribuidora:** Energisa MT. Reajuste tarifário homologado pela ANEEL em 01/04/2025 (Resolução 3.440) — impacto médio de **+5,42% pra alta tensão** (comércio grande/indústria) e **+0,34% pra baixa tensão**. Comércio entra na **classe B3 baixa tensão**.
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh com bandeiras e impostos. MT está entre os estados com tarifa acima da média nacional.
- **Irradiação solar MT:** entre **5,2 e 5,6 kWh/m²/dia** (uma das melhores do Brasil) → payback mais rápido que média nacional.
- **Cidades-foco (PIB e perfil comercial):**
  - **Tangará da Serra:** comércio + supermercados = 35% dos empregos. Forte em varejo. 65 modalidades de comércio.
  - **Sapezal:** PIB per capita **R$ 254 mil** (4x média estadual). 75% agro, mas comércio cresce. Alto poder aquisitivo.
  - **Diamantino:** PIB per capita **R$ 257 mil**. Crescimento de 71% em 1 ano. Polo comercial.
  - **Nova Olímpia + Barra do Bugres:** menor escala, mas oportunidade de ser o primeiro a entrar com solar B2B.

**Argumento mestre pra qualquer pitch:** tarifa Energisa subiu de novo em 2025, MT tem irradiação top 3 do Brasil, payback médio em comércio de MT está entre **2,5 e 3,5 anos** (canalsolar, ABSOLAR).

---

# 1. SUPERMERCADOS

## Perfil de consumo
- **Câmara fria comercial pequena (mercado de bairro):** 1.000–1.500 kWh/mês só na refrigeração
- **Supermercado médio (4–8 checkouts):** 8.000–15.000 kWh/mês totais
- **Supermercado grande:** 20.000–40.000 kWh/mês
- **Refrigeração representa 50–60% do consumo total**

## Conta de luz estimada (MT, tarifa B3)
- Mercado de bairro: R$ 4.000–8.000/mês
- Médio porte: R$ 8.000–15.000/mês
- Grande: R$ 18.000–40.000/mês

## Dor principal (linguagem do dono)
> "A conta de luz é o segundo maior custo depois da folha. Subiu 7% esse ano e vai subir de novo. Margem do supermercado é 2–4%, qualquer aumento aperta."

## Decisor
- Dono (mercado familiar) ou sócio-administrador. Decide sozinho na maioria. Ticket alto = pode envolver contador/financeiro.

## Ângulo de pitch
- "Você gasta R$ X em luz por mês. 70% disso vai pra refrigeração. Em 3 anos a Synergy paga seu sistema, depois disso são 22 anos de luz quase de graça. Em 25 anos isso é R$ Y de margem direta no caixa."
- **Prova social:** citar **É o Bicho Pet Shop** (case real Synergy, ramo varejo refrigeração) + **Lorenzetti** (indústria, mostra porte).

## Gatilhos de urgência
- Reajuste Energisa anual (abril) → "antes do próximo aumento"
- Bandeira tarifária vermelha → acelera payback em 9%
- Concorrência local: se mercado da esquina puser solar, ele baixa preço final do produto

## Volume na região
- Tangará: comércio varejista de supermercado emprega **1.298 pessoas** (3º maior empregador da cidade) → estimativa **40–60 supermercados** só em Tangará
- Diamantino + Sapezal + Nova Olímpia: estimativa adicional de **30–50 supermercados** (cidades menores, mas com PIB per capita alto)
- **Total endereçável: 70–110 supermercados na praça da Synergy**

## Pontos de atenção
- Telhado de supermercado costuma ter aparelho de ar condicionado, antena, exaustor → engenharia precisa validar área útil
- Alguns têm CNPJ pequeno mas conta de luz alta (3 lojas no mesmo CNPJ) — pré-qualificar pelo nº de checkouts
- Cooperativas (tipo Coopercaibé) têm processo de decisão coletivo → ciclo mais longo

---

# 2. MECÂNICAS

## Perfil de consumo
- **Mecânica pequena (2–3 elevadores, sem ar condicionado):** 500–1.200 kWh/mês
- **Mecânica média (compressor grande, solda, ar comprimido, ar condicionado no escritório):** 1.500–3.500 kWh/mês
- **Centro automotivo / oficina especializada (alinhamento computadorizado, máquinas pneumáticas):** 4.000–8.000 kWh/mês
- **Energia elétrica = 15% do custo operacional médio de uma oficina** (Guia do Óleo)

## Conta de luz estimada (MT, tarifa B3)
- Pequena: R$ 500–1.200/mês
- Média: R$ 1.500–3.500/mês
- Grande: R$ 4.000–8.000/mês

## Dor principal (linguagem do dono)
> "Mês passado a conta veio R$ 2.800. Antes era R$ 2.100. Tô pensando em passar pra ar condicionado mais econômico, mas o problema é o compressor que fica ligado o dia inteiro."

## Decisor
- Dono mecânico ou casal sócio. Decide sozinho. Geralmente já trabalha 10–20 anos no ramo, conservador, gosta de ver no papel.

## Ângulo de pitch
- "Energia é 15% do seu custo operacional. Em 3 anos a Synergy zera essa linha. Você ganha 15% de margem extra pra vida toda. Em 25 anos isso compra outra oficina."
- **Argumento técnico:** "Telhado de oficina é largo, plano, sem aparelhos em cima. É o telhado mais barato pra instalar do Brasil."

## Gatilhos de urgência
- Reajuste Energisa anual
- Aumento de seguro/aluguel (qualquer custo fixo subindo) — solar é o único que **trava** o custo
- "Seus concorrentes que botarem solar antes vão poder baixar mão de obra"

## Volume na região
- Estimativa: **150–250 oficinas** mecânicas (carro + moto + caminhão) na praça da Synergy
- Tangará da Serra concentra a maioria. Sapezal + Diamantino têm bom volume por causa do agro (manutenção de máquina pesada)
- **Sub-segmento bom:** mecânicas de caminhão e máquina agrícola (Sapezal, Diamantino) — conta muito maior

## Pontos de atenção
- Dono mecânico desconfia de oferta financeira → pedido pra ele é **simulação no papel da conta dele**, não simulador genérico
- Algumas oficinas alugam galpão → travar primeiro com o **dono do imóvel** ou contrato de aluguel longo
- Ticket menor que supermercado, mas ciclo de venda mais curto (decisão de dono, sem comitê)

---

# 3. SORVETERIAS

## Perfil de consumo
- **Sorveteria/açaiteria de bairro (3–5 freezers):** 1.000–2.000 kWh/mês
- **Sorveteria com fabricação própria (câmara fria média + freezers + vitrines + máquina de sorvete italiano):** 2.500–5.000 kWh/mês
- **Rede/franquia (Sorvetes Rocha, Sorvete Italiano):** 5.000–10.000 kWh/mês
- **Refrigeração = 70–80% do consumo total** (mais alto que supermercado)

## Conta de luz estimada (MT, tarifa B3)
- Bairro: R$ 800–1.800/mês
- Fabricação própria: R$ 2.500–5.000/mês
- Rede/franquia: R$ 5.000–10.000/mês

## Dor principal (linguagem do dono)
> "Vendo gelado e congelado. Se desligar a energia 6 horas eu perco o estoque inteiro. E pago R$ 4 mil de luz num mês de calor. No inverno cai a venda mas a luz não diminui porque os freezers continuam ligados."

## Decisor
- Dono(a). Negócio familiar quase sempre. Decide casado(a) — entrar com argumento financeiro **e** ambiental (sorveteria atrai público jovem que valoriza sustentabilidade).

## Ângulo de pitch
- "70% da sua conta é refrigeração 24h. Refrigeração não desliga, mas o sol gera todo dia em MT. Match perfeito. Payback em 3 anos. Em 25 anos é R$ Y de margem que entra pelo sorvete e não sai pela Energisa."
- **Diferencial sazonal:** "MT tem calor 9 meses do ano. Quanto mais calor, mais venda + mais luz. Você precisa do solar exatamente no pico."

## Gatilhos de urgência
- Verão chegando → janelas de venda Set–Out e Dez–Mar
- Sorveterias gemêmeas próximas → "primeiro a baixar custo baixa preço"
- Novo equipamento (vitrine, máquina) sendo comprado → "compra o solar junto, mesmo financiamento"

## Volume na região
- Estimativa: **40–80 sorveterias/açaiterias/pamonharias** com refrigeração intensa na praça
- Tangará tem o maior volume. Diamantino e Sapezal têm menos pontos, mas com ticket maior (sorveteria com fabricação)
- **Sub-segmento ouro:** açaiteria e fábrica de polpa de fruta em Tangará (câmara fria 24h)

## Pontos de atenção
- Margem do setor é baixa (10–15%) → investimento precisa ter financiamento bem desenhado
- Donos jovens (sorveteria nova) querem prazo de 60 meses, não 24
- Algumas sorveterias funcionam dentro de shoppings/galerias → não controlam telhado, descartar na pré-qualificação

---

# 4. PADARIAS

## Perfil de consumo
- **Padaria pequena (10h/dia, 1 forno, 1 câmara fria, 2 geladeiras de bebida):** 1.500–2.500 kWh/mês
- **Padaria média com confeitaria (2 fornos, fermentação climatizada, vitrines refrigeradas, ar condicionado salão):** 3.000–6.000 kWh/mês
- **Padaria grande / panificadora industrial:** 6.000–15.000 kWh/mês
- **Potência contratada típica de padaria pequena: 13,8 kVA** (referência mercado)

## Conta de luz estimada (MT, tarifa B3)
- Pequena: R$ 1.500–2.500/mês
- Média: R$ 3.000–6.000/mês
- Grande: R$ 6.000–15.000/mês

## Dor principal (linguagem do dono)
> "Forno fica ligado das 4 da manhã até as 9 da noite. Câmara fria 24h. Vitrines 18h. Ar condicionado no calor de MT, mais 10h. Não tem como diminuir, é o negócio."

## Decisor
- Dono ou casal. Geralmente família. Padaria é negócio **caixa apertado, alta rotatividade, margem fina** (5–10%).
- Decisão envolve esposa(o)/filho que toca o financeiro.

## Ângulo de pitch
- "Você não pode desligar nada. Forno, câmara, vitrine, tudo precisa ficar ligado. Mas você pode trocar a Energisa pelo sol. Em 3 anos quita o sistema. Depois disso, você tira a Energisa do custo da broa pro resto da vida."
- **Argumento de competitividade:** "Padaria que tem solar pode segurar preço do pão. Quem não tem, repassa toda alta de luz pro cliente, e o cliente vai pro mercado da esquina."

## Gatilhos de urgência
- Reajuste Energisa
- Aumento da farinha/leite (custo de insumo subindo) → "se a luz subir também você fica espremido"
- Concorrente com solar (Tangará tem casos)

## Volume na região
- Estimativa: **80–130 padarias/confeitarias** na praça da Synergy
- Tangará concentra **60+ padarias**. Diamantino, Sapezal e Nova Olímpia somam **30–50**
- **Sub-segmento ouro:** padarias com confeitaria + restaurante (almoço executivo) — conta dobra

## Pontos de atenção
- Padeiro acorda 3h da manhã, atende cliente o dia inteiro → janela de ligação é **9h–11h ou 14h–16h**, fora disso ele não atende
- Decisor é casado → marcar visita com o casal junto, não só com o dono operacional
- Padaria muitas vezes aluga ponto → idem mecânica, validar contrato de aluguel longo

---

# 5. ACADEMIAS

## Perfil de consumo
- **Academia de bairro (300m², ar condicionado split, 10 esteiras, sem climatização forte):** 3.000–6.000 kWh/mês
- **Academia média (500–800m², ar central, 20+ esteiras, vestiário com chuveiro elétrico):** 8.000–15.000 kWh/mês
- **Academia grande / rede (1.000m²+, ar condicionado central, piscina aquecida):** 15.000–30.000 kWh/mês
- **Ar condicionado = até 50% do consumo total da academia** (Resolaris)
- **Esteiras: 2,5–4 kW cada por hora.** 10 esteiras 8h/dia = 200–320 kWh/dia só nelas

## Conta de luz estimada (MT, tarifa B3)
- Bairro: R$ 3.000–6.000/mês
- Média: R$ 8.000–15.000/mês
- Grande: R$ 15.000–30.000/mês

## Dor principal (linguagem do dono)
> "Academia tem 3 custos altos: aluguel, folha e luz. A luz já passou o aluguel. Ar condicionado no calor de MT é obrigação, senão aluno cancela. Esteira não tem como desligar. E quanto mais cliente, mais ar e mais luz."

## Decisor
- Dono. Geralmente educador físico ou empresário do ramo. Decide rápido se vê o número. Muitos têm **2–3 unidades** → ticket multiplicado.

## Ângulo de pitch
- "Academia em MT é a regra do calor: ar condicionado obrigatório 9 meses por ano. Sua conta dobra no verão. Solar funciona melhor exatamente no verão. Em 3 anos a Synergy paga, depois disso você tem **22 anos de ar grátis**."
- **Argumento de retenção:** "Aluno cancela se o ar não tá bom. Com solar, você pode deixar o ar 24°C o tempo todo sem medo da conta. Retenção sobe, custo trava."

## Gatilhos de urgência
- Início do verão (Set–Out) → "antes do pico de uso"
- Aluno reclamando do calor → "investe no ar, paga com o sol"
- Plano de expansão (2ª unidade) → "monta a nova já com solar"

## Volume na região
- Estimativa: **30–60 academias** na praça da Synergy
- Tangará tem o maior número (cidade universitária, Unemat) → estimativa **20–30 academias**
- Diamantino e Sapezal têm menos, mas com ticket grande (academia de funcionário de fazenda paga conta dela)
- **Sub-segmento ouro:** academias de funcionários públicos / sindicatos / agropecuárias — quem paga a conta é a empresa-mãe, ciclo de decisão B2B clássico

## Pontos de atenção
- Dono de academia trabalha das 5h às 22h → ligar 9h–11h ou 14h–16h
- Muitas academias têm contrato com franquia (Smart Fit, Bio Ritmo) → contrato franqueado pode travar reforma do telhado
- Estrutura de telhado de academia (galpão metálico) costuma ser perfeita pra solar, mas validar com engenharia

---

## Resumo executivo — Ranking pra prospecção da semana 2

| Ranking | Segmento | Ticket médio (sistema solar) | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|---|---|
| 🥇 1º | **Supermercados** | R$ 60–200 mil | Alto (70–110) | Médio | ⭐⭐⭐⭐⭐ |
| 🥈 2º | **Padarias** | R$ 25–80 mil | Alto (80–130) | Rápido | ⭐⭐⭐⭐⭐ |
| 🥉 3º | **Academias** | R$ 40–150 mil | Médio (30–60) | Rápido | ⭐⭐⭐⭐ |
| 4º | **Mecânicas** | R$ 15–60 mil | Alto (150–250) | Muito rápido | ⭐⭐⭐⭐ |
| 5º | **Sorveterias** | R$ 20–70 mil | Médio (40–80) | Médio | ⭐⭐⭐ |

**Sugestão tática pra Semana 2 (50–100 empresas):**
- **40 supermercados** (Tangará + Diamantino + Sapezal)
- **30 padarias** (Tangará + Diamantino)
- **20 mecânicas** (Tangará — volume + cases B2B Synergy)
- **10 academias** (Tangará — Unemat e centro)

Sorveteria entra na Semana 3 com pitch sazonal (chegada do verão setembro/outubro).

---

## Próximos passos pós-pesquisa

1. Validar tarifa real da Energisa MT B3 (puxar conta de luz de 1 cliente de cada segmento)
2. Bater com Flávio na call de amanhã: ele concorda com o ranking?
3. Construir 5 scripts de ligação (1 por segmento) usando os ângulos de pitch acima
4. Cruzar volume estimado com lista real do Google Maps (rodar `/prospectar` em Tangará por cada segmento)
5. Pedir 3 cases reais Synergy por segmento (já vendeu pra mercado X, padaria Y, etc.) pra usar como prova social

---

**Fontes principais:**
- ANEEL Resolução 3.440 (Energisa MT, 01/04/2025)
- Sebrae DataMPE — Tangará da Serra, Sapezal, Diamantino
- ABSOLAR / Canal Solar / Portal Solar (payback e economia médios)
- Guia do Óleo (consumo oficina)
- Resolaris (consumo academia)
- Bistrobox / Origo Energia (consumo freezer e câmara fria)
- Bluesol / Neoenergia (cases de economia em comércio)

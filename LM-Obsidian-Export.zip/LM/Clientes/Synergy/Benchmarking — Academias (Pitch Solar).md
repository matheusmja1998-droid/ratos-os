---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
segmento: Academias
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, academia, mt]
---

# Benchmarking — Academias (Pitch Solar Synergy)

> Pesquisa de mercado pra prospecção ativa de energia solar B2B em academias de musculação e crossfit na praça da Synergy.

---

## Contexto regional

- **Distribuidora:** Energisa MT. Reajuste em 01/04/2025.
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh.
- **Irradiação solar MT:** 5,2–5,6 kWh/m²/dia.
- **Clima MT:** calor 9 meses do ano → ar condicionado obrigatório em academia (questão de retenção, não conforto).
- **Tangará da Serra:** cidade universitária (Unemat) → alta densidade de academias.

---

## Perfil de consumo

- **Academia de bairro (300m², split, 10 esteiras, sem climatização forte):** 3.000–6.000 kWh/mês
- **Academia média (500–800m², ar central, 20+ esteiras, vestiário com chuveiro elétrico):** 8.000–15.000 kWh/mês
- **Academia grande / rede (1.000m²+, ar central, piscina aquecida):** 15.000–30.000 kWh/mês
- **Ar condicionado = até 50% do consumo total** (Resolaris)
- **Esteiras: 2,5–4 kW cada por hora.** 10 esteiras 8h/dia = 200–320 kWh/dia só nelas

## Conta de luz estimada (MT, tarifa B3)

- Bairro: **R$ 3.000–6.000/mês**
- Média: **R$ 8.000–15.000/mês**
- Grande: **R$ 15.000–30.000/mês**

## Ticket médio do sistema solar

**R$ 40–150 mil**

---

## Dor principal (linguagem do dono)

> "Academia tem 3 custos altos: aluguel, folha e luz. A luz já passou o aluguel. Ar condicionado no calor de MT é obrigação, senão aluno cancela. Esteira não tem como desligar. E quanto mais cliente, mais ar e mais luz."

## Decisor

- Dono. Geralmente educador físico ou empresário do ramo
- Decide rápido se vê o número
- Muitos têm **2–3 unidades** → ticket multiplicado
- **Dono trabalha das 5h às 22h** → ligar 9h–11h ou 14h–16h

---

## Ângulo de pitch

> "Academia em MT é a regra do calor: ar condicionado obrigatório 9 meses por ano. Sua conta dobra no verão. Solar funciona melhor exatamente no verão. Em 3 anos a Synergy paga, depois disso você tem **22 anos de ar grátis**."

**Argumento de retenção:** "Aluno cancela se o ar não tá bom. Com solar, você pode deixar o ar 24°C o tempo todo sem medo da conta. Retenção sobe, custo trava."

---

## Gatilhos de urgência

- **Início do verão (Set–Out)** → "antes do pico de uso"
- **Aluno reclamando do calor** → "investe no ar, paga com o sol"
- **Plano de expansão (2ª unidade)** → "monta a nova já com solar"
- **Verão = pico de matrícula** (gente querendo perder peso) → mais movimento, mais ar ligado

---

## Volume na região

- **Estimativa: 30–60 academias** na praça da Synergy
- **Tangará:** 20–30 academias (cidade universitária)
- **Diamantino + Sapezal + Nova Olímpia:** menos academias, mas com ticket grande

## Sub-segmento ouro

**Academias de funcionários públicos / sindicatos / agropecuárias** — quem paga a conta é a empresa-mãe, ciclo de decisão B2B clássico. Ticket maior, perfil mais profissional.

---

## Pontos de atenção

- Muitas academias têm contrato com franquia (Smart Fit, Bio Ritmo) → contrato franqueado pode travar reforma do telhado
- Estrutura de telhado de academia (galpão metálico) costuma ser perfeita pra solar — validar com engenharia
- Dono trabalha em horário fora do comercial → ligação fora de pico
- Academia pequena (1 unidade) pode não ter ticket pra justificar — pré-qualificar pelo m²

---

## Score pra prospecção

| Ticket médio | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|
| R$ 40–150 mil | Médio (30–60) | Rápido | ⭐⭐⭐⭐ |

**Ranking: 🥉 3º** entre os 5 segmentos prioritários. **Decisão rápida + ticket alto + dono comum ter mais de uma unidade.**

---

**Fontes:**
- ANEEL Resolução 3.440 (Energisa MT)
- Sebrae DataMPE — Tangará da Serra
- Resolaris (energia solar em academias)
- Reforma Engenharia / WebArCondicionado (consumo ar condicionado)
- Canal Solar (cases comércio)

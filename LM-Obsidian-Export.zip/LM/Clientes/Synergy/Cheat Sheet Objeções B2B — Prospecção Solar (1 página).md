---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
fonte: Adaptação B2B do material "Quebra de Objeções" enviado pelo Flávio (07-05-2026) + SWOT interno
uso: Cheat sheet 1 página pra time comercial rodar na 1ª semana de prospecção ativa B2B
criado: 2026-05-11
tags: [synergy, objecoes, b2b, playbook, prospeccao]
---

# Cheat Sheet de Objeções — Prospecção B2B Solar (Synergy)

> 1 página. Cabe no celular do vendedor. As 8 objeções que vão aparecer em **toda** ligação fria pro B2B.
> Cada uma com **3 camadas:** (1) resposta curta pra bater bola, (2) pergunta de redirecionamento, (3) prova/dado.

---

## TOP 4 — ligação fria (vão aparecer em 80% das chamadas)

### 1. "Não conheço a Synergy"
- **(1) Resposta curta:** "Faz sentido. A gente tem 6 anos de mercado em Tangará, instalou em Lorenzetti, Indústria Kallos, Fazenda Boitanga, É o Bicho. Somos técnicos e conservadores — é por isso que tô te ligando, e não te empurrando coisa pelo WhatsApp."
- **(2) Pergunta:** "Posso te mostrar 2 cases parecidos com o seu negócio em 10 minutos por aqui?"
- **(3) Prova:** SWOT da própria Synergy — "verdade, técnica, honestidade, qualidade de instalação". 6 anos, equipe técnica, segue normas. Cases B2B reais (não residencial).

---

### 2. "Tô sem tempo agora"
- **(1) Resposta curta:** "Entendo, dono de [negócio] não tem tempo mesmo. Por isso eu sou rápido: o que eu preciso é só 10 minutos pra olhar uma conta de luz sua e te falar quanto a Synergy economiza em 25 anos. Se não fizer sentido, eu te dispenso."
- **(2) Pergunta:** "Manhã ou tarde funciona melhor pra esses 10 minutos?"
- **(3) Prova:** payback médio em comércio MT é 2,5–3,5 anos. Depois disso são 22 anos de luz quase grátis. Não dá pra deixar isso pra depois.

---

### 3. "Preciso pensar / vou ver depois"
- **(1) Resposta curta:** "Pode pensar, sem problema. Mas o que segura a decisão hoje é o quê: preço, momento da empresa ou alguém que decide junto contigo?"
- **(2) Pergunta:** "Se eu te mostrar que o sistema se paga com a economia que você já tem (sem tirar dinheiro do caixa), muda alguma coisa?"
- **(3) Prova:** financiamento sem entrada, primeira parcela em 120 dias, parcela menor que a economia da conta. Não descapitaliza, usa dinheiro do banco. **Cada mês adiando = 1 mês de luz cara perdida.**

---

### 4. "Tá caro"
- **(1) Resposta curta:** "Caro é continuar pagando a Energisa todo mês. Reajuste só em 2025 já foi de **5,42%** pra comércio. No próximo ano vem outro. O sistema solar trava esse custo por 25 anos."
- **(2) Pergunta:** "Quanto você paga hoje de luz por mês? Posso te mostrar em 2 minutos quanto disso vira lucro nos próximos 25 anos?"
- **(3) Prova:** ROI em 25 anos varia entre **200% e 600%** (Canal Solar / ABSOLAR). Tarifa Energisa MT está entre as mais altas do Brasil = payback mais rápido. **MT tem irradiação top 3 do país.**

---

## TOP 4 — específicas B2B (vão aparecer no decisor empresarial)

### 5. "Quem decide é meu sócio / contador / financeiro"
- **(1) Resposta curta:** "Faz sentido. Decisão dessa importa pra mais de um. O que a gente faz: você marca 30 minutos com você e [sócio/contador] juntos, e eu apresento os números pra vocês dois ao mesmo tempo. Assim ninguém tem que repetir nada."
- **(2) Pergunta:** "Qual o melhor jeito de envolver [ele/ela] — uma call, uma visita ou eu mando um material executivo antes?"
- **(3) Prova:** Synergy entrega proposta com **payback corporativo, fluxo de caixa do investimento e simulação de financiamento**. Material que contador entende em 5 minutos.

---

### 6. "Esse mês não dá / tô com caixa apertado"
- **(1) Resposta curta:** "Justamente por isso. Solar é o único custo da empresa que você consegue **eliminar** — não negociar, não trocar de fornecedor, **eliminar**. Financiamento empresarial sem entrada, primeira parcela em 120 dias. Você não tira nada do caixa hoje."
- **(2) Pergunta:** "Se a parcela do sistema fosse **menor** que a conta de luz que você paga hoje, você toparia trocar uma despesa pela outra?"
- **(3) Prova:** caso clássico — supermercado que paga R$ 3.500/mês de luz cai pra R$ 175 com solar. Financiamento de R$ 72k com payback em 1,8 ano (Portal Solar / Bluesol).

---

### 7. "Já tenho proposta de outra empresa / o concorrente tá mais barato"
- **(1) Resposta curta:** "Boa, isso me ajuda. Me passa o número dele que eu te mostro em 5 minutos onde tá a diferença. Geralmente é: marca de inversor, garantia de geração e pós-venda. **Solar é 25 anos de relação**, não 1 instalação."
- **(2) Pergunta:** "Você sabe quem instala e quem te atende em 5 anos se der problema? A empresa vai existir?"
- **(3) Prova:** SWOT Synergy — conservadora no dimensionamento (vai gerar mesmo), pós-venda estruturado, 6 anos no mercado MT (não some). **G3, Miese, Ecopower, C2 = pica-fios da região** (citar se o concorrente for um deles).

---

### 8. "E se não gerar o que vocês prometem?"
- **(1) Resposta curta:** "Boa pergunta. A gente é conservador de propósito. Dimensionamos pra cima do que o cliente precisa, pra não dar problema. Se você quiser, o contrato prevê **garantia de geração** — se gerar menos do que projetado, a gente cobre a diferença."
- **(2) Pergunta:** "Você prefere que eu visite o local antes de fechar pra testar o telhado, ou já mando o pré-projeto?"
- **(3) Prova:** projeto personalizado por imóvel (não é orçamento de calculadora online). Marca de inversor: **Solis** (maior fabricante do mundo, briga com Huawei e Sungrow). **Garantia de inversor: 10 anos / painel: 25 anos.**

---

## Regra de ouro pra rodar esse cheat sheet

1. **Não recitar.** O cheat sheet é gancho, não roteiro. Vendedor lê 2x antes de ligar e usa do jeito dele.
2. **Pergunta sempre vem depois da resposta.** Resposta curta para a objeção; pergunta retoma o controle da conversa.
3. **Prova entra só se o lead quiser detalhe.** Não despeja o dado se ele já avançou — manda guardar pra reunião.
4. **Se a objeção for de fundo (decisor real, caixa real, momento real), parar de empurrar e marcar follow-up em 7–15 dias.** Insistir queima o lead.

---

## O que muda do B2C deles pro B2B (gap coberto aqui)

| Objeção B2C deles | Gap pro B2B | Resposta nova |
|---|---|---|
| #5 "Diretoria/esposa não aprova" | Decisor B2B é sócio/contador, não esposa | Objeção 5 reescrita |
| #6 "Achei caro" | Empresário pensa em ROI, não em parcela | Objeção 4 com dado de ROI 200-600% |
| #8 "Preciso pensar" | Empresa adia decisão por gestão, não por preço | Objeção 3 ataca o "o que segura" |
| #13 "Financiamento caro" | B2B precisa ouvir "não descapitaliza" | Objeção 6 com fluxo de caixa |
| Nenhuma sobre concorrente técnico | Existem pica-fios na região | Objeção 7 cita G3, Miese, Ecopower, C2 |
| Nenhuma sobre geração | Empresa quer garantia contratual | Objeção 8 com cláusula de garantia de geração |

---

## Próximos passos pós-uso na 1ª semana

1. **Rodar com vendedores na daily** — 1 objeção por dia, vendedor encena, Fabrício corrige
2. **Coletar objeções reais** — vendedor anota o que aparece de novo no campo
3. **Versão 2 em 30 dias** — playbook completo com 16+ objeções e o que aprendeu na rua
4. **Bloco extra a construir:** objeções específicas por segmento (supermercado, padaria, mecânica, sorveteria, academia) — fica no playbook v2

---

**Fonte do material original:** [[Synergy — Quebra de Objeções (cliente, 07-05-2026)]] + [[Synergy — Análise SWOT (cliente, 07-05-2026)]]

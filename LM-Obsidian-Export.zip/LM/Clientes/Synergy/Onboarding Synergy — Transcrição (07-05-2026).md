---
data: 2026-05-07
duracao: 88min
participantes:
  - Matheus Jardim
  - Valentino Pascual
  - Flávio Narezzi (Synergy)
  - Fabrício Coletti (Synergy)
tags:
  - lm
  - synergy
  - onboarding
  - reuniao
gravacao: https://fathom.video/calls/665333748
---

# Onboarding Synergy — Transcrição (07/05/2026)

Reunião de onboarding do Ignição Comercial. Diagnóstico real da operação, reconciliação dos números da pesquisa diagnóstica, definição de meta, squad de prospecção, cidades-foco e cultura de cobrança.

**Action items registrados na transcrição:**
1. Sign contract — https://fathom.video/calls/665333748?timestamp=41.389233
2. Send meeting recording + transcript to Flávio + Fabrício — https://fathom.video/calls/665333748?timestamp=2677.158419

## Transcrição completa

0:00 — Matheus Jardim: Fabricio, alô, bom dia.

0:15 — Fabricio Coletti: Bom dia, bom dia.

0:17 — Valentino: Beleza? Tudo ótimo, e aí, como é que tá?

0:20 — Fabricio Coletti: Tudo certo, tô chegando no escritório, tá? Boa.

0:25 — Matheus Jardim: Tranquilo, pode chegar aí tranquilo que a gente espera aqui, fechou?

0:29 — Fabricio Coletti: Beleza, valeu, vou sair aqui do celular, aí eu entro no computador. Fechou, vai lá. Combinado.

0:42 — Valentino: Coloquei. Eu permiti ele, mas ele não entrou.

1:30 — Matheus Jardim: Talvez ele saiu.

1:32 — Valentino: Eu vou pegar uma água, então. Ele tá entrando aqui. Tá. Fala.

1:41 — Fabricio Coletti: Fabricio, tudo bom?

1:45 — Matheus Jardim: Como que vai as coisas aí essa quinta-feira? Muita correria, muito trampo, como que tá?

1:51 — Fabricio Coletti: Olha, bastante trabalho. Muita coisa, né? Bastante coisa aí pra fazer. Aí resolvendo, né?

1:59 — Matheus Jardim: O Flávio vai conseguir entrar agora? Ele falou que logo, logo entra? Olha, não sei te dizer.

2:07 — Fabricio Coletti: Deve entrar aí nos próximos minutos. Tranquilo.

2:10 — Matheus Jardim: Qualquer coisa a gente vai dar no início e aí quando chegar a gente passa um overview pra ele também, né?

2:17 — Valentino: Fabricio, bom dia.

2:20 — Fabricio Coletti: Tudo certo pra aí?

2:24 — Matheus Jardim: Ô, Fabricio, o intuito aqui desse on-board, se você ver eu olhando pra cá é porque eu olhando pra segunda tela aqui pra gente ir conversando e eu vou tá olhando aqui as respostas de pesquisa, fez uma análise aqui nas pesquisas ali, nas respostas que você trouxe pra gente ali.

2:41 — Matheus Jardim: O intuito desse onboarding, Fabrício, é a gente trazer um diagnóstico real hoje da Synergy, a gente vai sair daqui com basicamente cinco decisões fechadas: faturamento real, quem prospecta, qual cidade primeiro, quando cada um tem capacidade de ligação, e quais empresas, quais nichos, segmentos a gente vai começar. Inclusive, eu estava olhando aqui, com a tela do Pet Shop aberta, "É o Bicho", que estava olhando.

3:25 — Valentino: Fala, Flávio, bom dia.

3:27 — Flávio Narezzi: Fala, bom dia. Tudo bom?

3:31 — Matheus Jardim: Tudo certo. Flávio, eu estava começando a falar aqui com o Fabrício sobre o roteiro dessa reunião de on-board. Hoje a gente vai trazer e fazer um diagnóstico real da operação de vocês, entendendo ponto a ponto. Vamos sair daqui com cinco decisões fechadas: faturamento real, quem prospecta, qual cidade atacar primeiro, quanto cada um pode de capacidade de ligação e quais segmentos a gente vai começar. Eu estava dando uma olhada nas respostas do formulário, fazer uma análise, porque ficou um pouco confuso, principalmente na parte do faturamento. Quando finalizar essa reunião, vamos ter os segmentos que vamos atacar, e a gente vai trazer pesquisa de mercado em cima de cada segmento. Por que pesquisa de mercado? Pra entender com profundidade cada um, exemplo: supermercado tem margem muito baixa, então quando o vendedor for ligar, é legal saber disso, porque a pessoa do outro lado vê que você sabe das dores do negócio dela. No final da reunião, a gente sai com escopo do projeto, monta benchmark, manda pra vocês, começa alinhamento, e na próxima reunião já parte pra mão na massa: geração de lista, scripts, ligações ao vivo com seus vendedores. Quanto maior a velocidade de execução, mais rápido o resultado chega. Fechou? Aí, Flávio, depois olha o contrato lá pra a gente assinar, beleza?

6:41 — Flávio Narezzi: Cara, ontem eu fui fazer exame, ressonâncias que era pra fazer sexta, a clínica antecipou. Ontem não consegui fazer nada.

6:57 — Matheus Jardim: Tranquilo. E como foi a ressonância?

7:01 — Flávio Narezzi: Tudo certo, de boa. Só esperar o resultado.

7:05 — Valentino: Matheus, você não está de aniversário hoje. Meus parabéns, cara.

7:09 — Flávio Narezzi: Valeu.

7:10 — Matheus Jardim: Aniversário pra mim aqui é como se fosse um dia normal, eu toco o barco. Tem famílias que a cultura de aniversário é muito forte. Meu pai nem parabéns dá pra mim, porque a gente é da roça, eu morava no interior do Espírito Santo até os 18. Então não ligam pra essas coisas. Vamos seguir? Estou olhando aqui as respostas da pesquisa que o Fabrício trouxe. Valentino, compartilha a tela pro Flávio acompanhar.

8:12 — Flávio Narezzi: Teve algumas perguntas que eu não entendi muito bem.

8:15 — Fabricio Coletti: Não, foi show.

8:18 — Matheus Jardim: Tranquilo, vamos contextualizar tudo agora. Primeiro, sobre a saúde da operação: vocês falaram que 20% vende tráfego, 50% indicação, 30% prospecção ativa. Ciclo de venda 7 a 15 dias. Margem 10 a 15. Tickets médios: outros 34 mil, comercial 144 mil, residencial 20.500. Vendas por mês, aí entrou numa...

9:04 — Fabricio Coletti: Essa pesquisa reflete os últimos três meses. Teve muitas vendas grandes nesse período, isso fez a média subir.

9:23 — Flávio Narezzi: Esse tratamento estatístico está errado. Deveria ser diferente.

9:32 — Matheus Jardim: Qual sua sugestão, Flávio?

9:36 — Flávio Narezzi: Trabalhar com mediana e não com média.

9:37 — Matheus Jardim: Show. Faturamento mensal médio entre 300 e 600 mil, mas a gente não tinha entendido. Se pegar volume × ticket dá média de R$ 809 mil últimos três meses. Mas somando o faturamento dos vendedores, deu média de R$ 183 mil/mês. Ficou diferença entre média dos vendedores e média geral.

10:49 — Fabricio Coletti: Aí que tá. Faturamento nos últimos 3 meses. Essa é a média dos últimos 3 meses, não a somatória. A pergunta na pesquisa, eu entendi que era a média faturada.

11:14 — Matheus Jardim: Então é a média dos últimos 3 meses que cada um tá vendendo por mês. Perfeito.

11:22 — Flávio Narezzi: Isso aí não reflete a realidade. Mês passado fechei duas vendas significativas, uma de 140 e outra de 550. Eu não atendo residencial. Atendo um ou outro indicado quando é estratégico. Esses números não estão refletindo a realidade. Fabrício, você teria que ter pego sem as minhas vendas.

12:07 — Fabricio Coletti: Eu tratei a média geral sem sua venda maior. Mas quando adicionei vendedores, te incluí, porque você vende usinas mais complexas.

12:34 — Flávio Narezzi: A última que vendi não deveria entrar. A estratégia deles é transformar vendedor que foca em casinha em vendedor capaz de vender pra comércio, com margem melhor. Me colocar nessa média mascara o que está acontecendo, até pra mensurar o trabalho deles, falando "seu ticket médio é 16 mil, vamos passar pra 30 mil".

13:53 — Matheus Jardim: Entendo perfeitamente. Sua venda muito alta foi fora do escopo. Vai distorcer.

14:19 — Flávio Narezzi: Faço três, quatro vendas grandes por ano, no máximo. Ano passado fiz uma só. Se eu passo três meses sem vender, está lá média de 144 mil ou 57 mil. A mediana pega o valor do meio. Por exemplo, 1, 10 e 1.000.000: a média é 500 mil, a mediana é 10. Eu tenho que analisar concentração de vendas e não média.

16:34 — Matheus Jardim: Vou pegar a somatória da média de vendas de cada vendedor. Vou compartilhar a tela inteira pra você ver a calculadora. Importante bater os números nessa primeira reunião. Fernando 57.500, Dayane 62.900, Célia 49.200.

17:29 — Fabricio Coletti: Tira eu também, fiz uma venda grande.

17:36 — Matheus Jardim: Tirei o Fabrício. Camila 23.200. Diana 18.500. Total: R$ 211.300 vendas dos vendedores. Faturamento médio que os vendedores estão entregando, tirando vocês dois.

18:16 — Flávio Narezzi: Você está falando pela média, é isso?

18:20 — Matheus Jardim: A média dos últimos 3 meses de venda de cada vendedor.

18:33 — Fabricio Coletti: Diana não entrou faz 3 meses, faz 2. Camila entrou faz 3.

18:41 — Matheus Jardim: Camila já tem 3 meses, vamos seguir 211.300. Anotando no documento. Depois quero ver quantos projetos cada um fechou pra entender o ticket médio.

19:12 — Fabricio Coletti: Fala quanto eu coloquei.

19:17 — Matheus Jardim: Faturamento gerente, R$ 123.650. Pode colocar 66.700 sem a venda grande.

19:30 — Fabricio Coletti: 66.400.

20:09 — Matheus Jardim: Vendedores: vou pedir quantidade de vendas por vendedor pra calcular ticket médio. Pega quantidade total nos 3 meses, divide por 3, pega ticket médio.

21:00 — Fabricio Coletti: Camila vendeu 4.

21:06 — Matheus Jardim: Diana 1, Dhaiane 10, Fernando 9.

21:41 — Flávio Narezzi: Camila eu acho que não pode entrar, está iniciando ainda. Camila e Diana. O Fabrício você vai entrar porque tem vendas regulares.

22:03 — Fabricio Coletti: Tirei só a do Scapini que foi fora da curva. Camila dá pra entrar, já tem mais de 3 meses. Célia tem 6, vende muito mais, mas teve problemas de saúde.

22:50 — Fabricio Coletti: Eu vendi 10 também.

23:09 — Matheus Jardim: Tirar Diana da equação, não tem muito tempo ainda.

23:22 — Fabricio Coletti: Flávio, tem o Lucas, mas não vendeu nada nos 3 meses. Tá começando de volta.

23:30 — Flávio Narezzi: Vendeu uma, mas não recebeu ainda.

23:42 — Matheus Jardim: Camila R$ 23.200, 4 vendas, dá 1,3/mês, ticket R$ 17.846.

24:22 — Matheus Jardim: Flávio, interessante incluir Júnior só pra estatística?

24:50 — Flávio Narezzi: Como ele saiu... Explica.

24:59 — Fabricio Coletti: Tínhamos vendedor com regularidade. Últimos 3 meses rendeu 7, ticket R$ 23.900. Pra contribuir com número, pode colocar.

25:33 — Matheus Jardim: Dá pra colocar pra ter parâmetro. Fernando, 9 vendas, 3/mês, R$ 19.166. Célia 2/mês.

26:31 — Fabricio Coletti: Júnior 7 vendas, R$ 23.943.

27:02 — Matheus Jardim: Aqui temos a mediana de cada um, o ticket médio. E temos contratos fechados por segmento. Maioria residencial?

27:25 — Fabricio Coletti: Residencial e alguns rurais mais simples.

27:31 — Matheus Jardim: Beleza. Meta R$ 3 milhões em 6 meses. Pelo menos R$ 500 mil/mês.

27:46 — Matheus Jardim: Quanto tem atualmente? Dos últimos 3 meses?

27:57 — Fabricio Coletti: Entre 300 e 600 mil.

28:05 — Fabricio Coletti: Tem outros vendedores esporádicos. Vou pegar abril até fevereiro.

28:37 — Matheus Jardim: Tirar Flávio da conta, ele vende esporádico. Tem que bater R$ 500 mil com o time.

28:54 — Fabricio Coletti: Tirando minha e do Flávio (as maiores): R$ 438 mil de média.

29:19 — Matheus Jardim: Então estamos falando de aumentar R$ 62 mil por mês pra chegar na meta nos próximos 6 meses.

29:31 — Fabricio Coletti: Isso mesmo.

29:31 — Matheus Jardim: Trazendo duas vendas comerciais por mês, atingimos a meta tranquilamente.

29:47 — Fabricio Coletti: Inclusive esse mês estamos em dois feirões: ABV e Citreg local. Campanha do Dia das Mães. Esse mês vai ser muito bom de venda. Já teve algumas vendas fechadas. Espero que vai bombar.

30:27 — Matheus Jardim: Tino, compartilha o Miro com mapa mental. Vamos colocar 2 vendas comerciais. Não comercial absurdamente grande, alguns vendedores ainda não trabalham com comercial maior. Faturamento médio últimos 3 meses R$ 438k tirando Scapini e venda maior. Meta R$ 500k/mês mínimo, então R$ 62k de gap.

31:46 — Matheus Jardim: Construção do sucesso do projeto. Valentino, puxa aba faturamento, R$ 438 mil últimos 3 meses, meta R$ 500 mil/mês. Estamos falando de R$ 62 mil de meta. Construindo a linha do comercial.

[Interrupção: Flávio atende telefone sobre instalação técnica, cabo 16, 30kVA]

34:47 — Matheus Jardim: Indo aos R$ 62 mil. Chutando alto, máximo 2 vendas comerciais batem os R$ 500 mil/mês. Hoje quantas visitas pra fazer venda de prospecção fria? Conversão atual?

35:24 — Fabricio Coletti: Vem em média 20% de vendas frias. Eu prospecto vendendo frio e passo pra eles. Maioria é indicação.

36:08 — Valentino: Em relação a vendas frias, qual a conversão?

36:18 — Fabricio Coletti: Não sei te dar esse dado.

36:18 — Matheus Jardim: Você falou meta de pelo menos 20%. A cada 10 fecha 2. Pra bater 2 vendas/mês precisa 10 visitas qualificadas.

36:46 — Flávio Narezzi: Define visita qualificada.

36:48 — Matheus Jardim: Comercial com conta de luz alta, falar com dono ou tomador de decisão, com interesse em ouvir. Cliente com potencial.

37:11 — Flávio Narezzi: Você está colocando ticket médio de 50 mil.

37:13 — Matheus Jardim: É pelo menos isso. Quebrar pra duas vendas é melhor. Se passar de 68 mil, perfeito. Mínimo 500 mil.

37:39 — Flávio Narezzi: 10 visitas qualificadas, 20% conversão, 2 vendas de 50 mil dá 100 mil. Pelo menos 62 mil pra meta mínima.

37:58 — Matheus Jardim: Quebra nas etapas do funil até chegar na prospecção, definir metas dos vendedores. Quantas ligações por dia? Quantas visitas? A gente parte do extremo zero. Meta sentada, taxa de conversão esperada, em cima disso 10 visitas. Próxima semana com seu time, na semana que vem começam reflexões. Vamos ver desempenho, fazer acompanhamento, definir quantas ligações pra marcar visita qualificada. Estamos fazendo do fundo do funil pro topo. Topo são as ligações.

[Confirmação de raciocínio: 10 visitas → 2 vendas. Altamente alcançável pela equipe.]

39:30 — Matheus Jardim: Próximo: tempo por dia que as 5 pessoas do comercial têm pra ligações. Pessoa faz entre 15 a 20 ligações por hora.

40:41 — Fabricio Coletti: Esse ponto da pesquisa eu também não entendi. Não sabia se era tempo que trabalhavam ou disponível.

40:51 — Matheus Jardim: Tempo que tinham disponível.

41:00 — Fabricio Coletti: Tirando a Dhaiane, fulltime, os demais são todos PJ. Pelo menos duas horas por dia disponíveis pra ligar.

41:15 — Matheus Jardim: Mais que suficiente. Uma de manhã e uma de tarde.

41:45 — Matheus Jardim: Fabrício, queremos alinhar: não adianta chegar e falar "20 ligações por dia, assim e assim". Cara vai fazer um ou dois dias e parar.

42:05 — Flávio Narezzi: Deixa ser mais claro. É importante trabalho de cultura, não só estratégia. Um dos motivos do vendedor que saiu agora: combinei com ele pra ir pra cidade a 150km fazer prospecção. Pagaria hotel uma vez por semana. No primeiro dia paguei. Na segunda semana perguntei: "cadê os leads que cadastrou no CRM?" Falou "não cadastrei, está no caderno". Eu bati pé que não pagava enquanto não registrasse no CRM. Foi um dos motivos que ele saiu. É importante desenvolver cultura. Não adianta estar no caderno, todo trabalho jogado no lixo. Como medir conversão sem registro?

43:57 — Matheus Jardim: Concordo muito. Vou explicar como funciona. Semana que vem, depois da nossa reunião, oficialmente trabalho com vendedores: acompanhamento junto com Fabrício. Ele entra junto. Todos os dias 20 minutos: o Fabrício e os vendedores. Quantas ligações fizeram ontem, quantas atenderam, quantas marcaram visita, principais objeções. Dailies. Cada etapa de uma ligação é um trabalho diferente. Exemplo: liga e não está falando com dono, não está passando autoridade na voz pra secretária. Isso é ajuste. Reuniões diárias 20 min, análise do dia anterior e do dia. Definir metas: Dhaiane tem 2h, faz mínimo 30 ligações. Se fez 10, "Dhaiane, por que 10? Aconteceu alguma coisa?" Implementação de cultura. Sem isso, fica solta.

46:34 — Flávio Narezzi: Deixa eu contar uma história pra corroborar. Empresa começou comigo, depois Fabrício, depois Dhaiane, depois outros. Eu e Fabrício tínhamos taxa de conversão de mais de 50%, pela tecnicidade. Ficava puto de perder 50%. Hoje eu faço alguns atendimentos específicos, mas estou mais na cozinha da empresa, parte operacional, estratégica. Pagar conta, jeito de caixa, infantação, execução de obra, fornecedor. Fabrício ficou responsável de vender também, com cuidado aos vendedores. Está em transição pra desenvolver cultura. Ponto de inflexão importante. Se Fabrício não desenvolver isso, não adianta vocês brigarem com vendedor se gerente não tiver cadência. Minha conversa com ele era toda semana sentar com cada vendedor, bater lead por lead. Eu e Fabrício conversamos ontem, nenhum de nós dois tem essa cadência, apesar de achar importante. Vou pedir: bater com Fabrício no como ele desenvolver essa cultura. Mais com Fabrício do que com vendedores. Vocês vão embora, Fabrício vai ficar.

50:06 — Matheus Jardim: Pra corroborar. Primeira semana do pessoal ligando, a gente faz em conjunto: eu, Valentino e Fabrício, todos os dias. Não estava no escopo, vimos a necessidade, entregamos como bônus. Eu e Valentino fazemos um, dois dias. Depois explicamos pro Fabrício o conceito. Ele faz no dia seguinte com nós acompanhando. Faz uma semana sozinho, a gente acompanha. Depois ele segue sozinho, a gente vê gravações. Conversamos, vê dificuldades, ajusta. Implementar saudavelmente. Fabrício é quem fica no dia a dia.

51:35 — Valentino: Formação de squad. Pessoas que prospectam, líder que lidera, pessoa atrás do líder.

51:49 — Matheus Jardim: A gente fica por trás do Fabrício. Quando saímos, fica o playbook resumido pra ele. Cidades. Vamos setar onde a gente começa o trabalho.

52:49 — Fabricio Coletti: Tangará.

52:56 — Fabricio Coletti: Diamantino bem forte. Bastante cliente comercial.

53:04 — Flávio Narezzi: Comercial em Diamantino vai bem. No residencial não.

53:19 — Fabricio Coletti: Nova Olímpia, próximo, pouca atuação lá.

53:26 — Matheus Jardim: Começar nessas três: Tangará, Diamantino, Nova Olímpia.

53:57 — Matheus Jardim: Tem cliente que separa vendedor por cidade?

53:59 — Fabricio Coletti: Não.

54:07 — Fabricio Coletti: Tirando Sapezal, praça da Célia, demais cidades espalhadas.

54:20 — Matheus Jardim: Valentino, puxa perninha: 2 horas, 30 ligações por dia por pessoa.

54:31 — Flávio Narezzi: Pessoal, vou ter que me ausentar, tenho outra reunião. Vocês tocam, vejo pela gravação.

54:41 — Matheus Jardim: A gente está gravando, transcrição e vídeo a gente manda.

55:00 — Matheus Jardim: 30 ligações por pessoa é o mínimo. 15 discagens por hora, 2 horas = 30 ligações. 5 pessoas prospectando = 150 ligações por dia. Time alinhado, mínimo, pelo menos duas visitas marcadas por dia. Comercial é nutrição de pipeline: vai ligando, encontrando decisores, "me liga amanhã", liga, marca. Empilha ligações em cima de contatos. Pelo menos uma semana ligando começa a refletir visitas agendadas. 30 ligações/pessoa/dia, 150 do grupo, pelo menos 2 visitas/dia.

56:36 — Fabricio Coletti: A ideia é fazer ligação e cadastrar no CRM.

56:43 — Matheus Jardim: Vamos ver organização do CRM. Se não viável, planilha. Precisa contato salvo, número, anotações. Pipeline pra organização.

57:23 — Fabricio Coletti: O CRM é bastante completo.

57:26 — Matheus Jardim: Cria pipeline separada pra prospecção com todos vendedores. Cada um seu login, acessa só os leads dele. Sobe lista, liga, move card, anota observação, quando dono está. Próxima semana montamos estrutura Kanban no Groner, scripts, listas, fazemos 1 a 3 ligações ao vivo com vendedores.

57:59 — Valentino: Pipeline = funil = Kanban.

58:01 — Fabricio Coletti: Beleza.

[Reunião segue alinhando estrutura. Trecho final cortado por limite de caracteres do canal de origem.]

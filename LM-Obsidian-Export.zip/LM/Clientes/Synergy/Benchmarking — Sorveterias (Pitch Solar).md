---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
segmento: Sorveterias
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, sorveteria, mt]
---

# Benchmarking — Sorveterias (Pitch Solar Synergy)

> Pesquisa de mercado pra prospecção ativa de energia solar B2B em sorveterias, açaiterias e fábricas de polpa na praça da Synergy.

---

## Contexto regional

- **Distribuidora:** Energisa MT. Reajuste em 01/04/2025.
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh.
- **Irradiação solar MT:** 5,2–5,6 kWh/m²/dia. **Match perfeito com sorveteria:** mais sol = mais calor = mais venda + mais luz + mais geração solar.
- **Clima MT:** calor 9 meses do ano → demanda quase constante por refrigeração.

---

## Perfil de consumo

- **Sorveteria/açaiteria de bairro (3–5 freezers):** 1.000–2.000 kWh/mês
- **Sorveteria com fabricação própria (câmara fria média + freezers + vitrines + máquina de sorvete italiano):** 2.500–5.000 kWh/mês
- **Rede/franquia / fábrica de polpa:** 5.000–10.000 kWh/mês
- **Refrigeração = 70–80% do consumo total** (mais alto que supermercado)
- **Câmara fria comercial pequena:** 1.000–1.500 kWh/mês só nela (Bistrobox)

## Conta de luz estimada (MT, tarifa B3)

- Bairro: **R$ 800–1.800/mês**
- Fabricação própria: **R$ 2.500–5.000/mês**
- Rede/franquia: **R$ 5.000–10.000/mês**

## Ticket médio do sistema solar

**R$ 20–70 mil**

---

## Dor principal (linguagem do dono)

> "Vendo gelado e congelado. Se desligar a energia 6 horas eu perco o estoque inteiro. E pago R$ 4 mil de luz num mês de calor. No inverno cai a venda mas a luz não diminui porque os freezers continuam ligados."

## Decisor

- Dono(a) — negócio familiar quase sempre
- Decide com o cônjuge → entrar com argumento financeiro **e** ambiental
- Donos jovens (sorveteria nova) querem prazo longo de financiamento (60 meses)

---

## Ângulo de pitch

> "70% da sua conta é refrigeração 24h. Refrigeração não desliga, mas o sol gera todo dia em MT. Match perfeito. Payback em 3 anos. Em 25 anos é R$ Y de margem que entra pelo sorvete e não sai pela Energisa."

**Diferencial sazonal:** "MT tem calor 9 meses do ano. Quanto mais calor, mais venda + mais luz. Você precisa do solar exatamente no pico do consumo."

---

## Gatilhos de urgência

- **Chegada do verão (Set–Out e Dez–Mar)** → janelas de venda
- **Sorveterias gêmeas próximas** → "primeiro a baixar custo baixa preço"
- **Compra de novo equipamento** (vitrine, máquina) → "compra o solar junto, mesmo financiamento"
- **Reajuste Energisa anual**

---

## Volume na região

- **Estimativa: 40–80 sorveterias/açaiterias/pamonharias** com refrigeração intensa na praça
- Tangará tem o maior volume
- Diamantino e Sapezal têm menos pontos, mas com ticket maior (sorveteria com fabricação)

## Sub-segmento ouro

**Açaiteria e fábrica de polpa de fruta em Tangará** — câmara fria 24h, consumo alto, dono mais empresarial (não só atendente).

---

## Pontos de atenção

- Margem do setor é baixa (10–15%) → investimento precisa de financiamento bem desenhado
- Donos jovens querem prazo de 60 meses, não 24
- Algumas funcionam dentro de shoppings/galerias → não controlam telhado, descartar na pré-qualificação
- **Sazonalidade no fluxo de caixa:** inverno aperta o caixa → melhor abordar entre Set e Mar

---

## Score pra prospecção

| Ticket médio | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|
| R$ 20–70 mil | Médio (40–80) | Médio | ⭐⭐⭐ |

**Ranking: 5º** entre os 5 segmentos prioritários. **Sugestão tática:** deixar pra Semana 3 ou pra **setembro** (entrada do verão) — pitch sazonal vai converter melhor.

---

**Fontes:**
- ANEEL Resolução 3.440 (Energisa MT)
- Sebrae DataMPE — Tangará da Serra
- Bistrobox / Origo Energia (consumo freezer e câmara fria)
- São Rafael (consumo câmara fria comercial)

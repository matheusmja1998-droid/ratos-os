---
data: 2026-05-07
tipo: notas-reuniao
cliente: Synergy
participantes:
  - Matheus Jardim
  - Valentino Pascual
  - Flávio Narezzi
  - Fabrício Coletti
relacionado:
  - "[[Onboarding Synergy — Transcrição (07-05-2026)]]"
  - "[[R2 Synergy — Flávio + Fabrício (05-05-2026)]]"
  - "[[Contrato — Synergy x Winvision (Ignição Comercial)]]"
tags:
  - lm
  - synergy
  - onboarding
---

# Onboarding Synergy — Notas e Análise (07/05/2026)

Reunião de 88 min. Diagnóstico real, reconciliação dos números da pesquisa, definição de meta, squad, cidades-foco e plano de cultura. Flávio saiu aos 54 min (outra reunião). Restante alinhado com Fabrício.

## Decisões fechadas

### 1. Faturamento real reconciliado

| Métrica | Valor |
|---|---|
| Faturamento médio últimos 3 meses (sem venda Scapini do Fabrício e sem venda grande do Flávio) | **R$ 438k/mês** |
| Meta dos próximos 6 meses | **R$ 500k/mês mínimo** (R$ 3M acumulado) |
| Gap pra fechar | **R$ 62k/mês** |
| Tratamento estatístico correto | Mediana, não média (correção do Flávio) |

### 2. Time real (sem outliers)

Com vendas e ticket médio dos últimos 3 meses:

| Vendedor | Vendas/3m | Vendas/mês | Ticket médio | Status |
|---|---|---|---|---|
| Fernando | 9 | 3 | R$ 19.166 | Squad |
| Dhaiane | 10 | 3,3 | (calcular) | Squad, fulltime |
| Célia | 6 | 2 | R$ 24.600* | Squad, com problemas de saúde |
| Camila | 4 | 1,3 | R$ 17.846 | Squad |
| Diana | 1 | 0,3 | — | **Fora da equação** (muito nova) |
| Júnior (saiu) | 7 | 2,3 | R$ 23.943 | Histórico, parâmetro |
| Fabrício | 10 | 3,3 | R$ 66.400 (sem Scapini) | Gerente, vende quando entra |
| Flávio | esporádico | — | grande | Fora da operação tática |

*Célia: cálculo aproximado baseado em R$ 49.200 ÷ 6 = ~R$ 8.200, mas Fabrício disse "vende muito mais" normalmente. Validar.

### 3. Plano comercial pra fechar gap

```
2 vendas comerciais/mês × R$ 50k ticket mínimo = R$ 100k/mês
Conversão esperada: 20% (cold)
→ 10 visitas qualificadas/mês
→ 30 ligações/dia × 5 vendedores = 150 ligações/dia
→ 2h/dia × 15 ligações/h = 30/dia por vendedor (PJ, exceto Dhaiane fulltime)
```

**Visita qualificada = comercial com conta de luz alta + falar com dono ou tomador + interesse em ouvir.**

### 4. Cidades-foco definidas

1. **Tangará da Serra** (sede)
2. **Diamantino** (forte em comercial, fraco em residencial)
3. **Nova Olímpia** (próxima, pouca atuação ainda)
4. **Sapezal** (praça específica da Célia)

### 5. Estrutura de cultura/cobrança

- **Daily de 20 min** com Fabrício + vendedores (todos os dias)
- **Squad de implementação:** primeira semana Matheus + Valentino + Fabrício juntos. Depois Fabrício faz sozinho com acompanhamento. No final só Fabrício.
- **Bônus fora do escopo:** Matheus e Valentino entrando nas dailies da primeira semana. Decisão tomada na hora pela necessidade.
- **CRM:** Groner é completo, dá pra criar pipeline separada de prospecção. Cada vendedor com login próprio, acessa só seus leads.

## Pontos altos da reunião

1. **Flávio é técnico, engajado e crítico.** Corrigiu o tratamento estatístico (média → mediana), apontou que se incluir as vendas dele a métrica fica mascarada e prejudica a mensuração do trabalho dos vendedores. Esse nível de rigor é alavanca pra fazer tracking sério.

2. **Fabrício tem os números na ponta da língua.** Sabia o ticket de cada um, quantas vendas, quem teve problema de saúde. Isso é base sólida pra começar.

3. **Autoconsciência cultural.** Os dois admitiram abertamente que **não têm cadência de cobrança hoje**. Flávio: "nenhum de nós dois tem essa cadência apesar de acharmos importante". Reconhecimento explícito do gargalo cultural antes mesmo da gente apontar.

4. **Caso do vendedor que saiu por não cadastrar no CRM** virou prova social interna pro novo método. Já está entendido na empresa que sem registro não dá pra trabalhar.

5. **Aceitaram o framework "fundo pra cima".** Meta → conversão → visitas → ligações. Sem resistência.

6. **Maio é mês quente.** Dois feirões (ABV + Citreg) + campanha Dia das Mães. Pipeline natural ativo, ambiente favorável pra começar prospecção em paralelo.

7. **Flávio pediu explicitamente foco no Fabrício.** "Vocês vão embora, Fabrício vai ficar". Sinal verde pra fazer o Fabrício o ponto focal de execução.

8. **Concordaram com ligações ao vivo na próxima reunião.** Velocidade de execução alta, expectativa de mão na massa imediata.

9. **Cidades fechadas em 5 minutos.** Sem indecisão, foco real.

10. **Diferenciação de função do Flávio.** Ele admitiu que hoje é mais "cozinha da empresa": operação, estratégica, finanças, fornecedor, execução. Não é mais o vendedor da operação. Isso valida que a meta tem que ser batida pelo time, não por ele.

## Pontos de atenção

1. **Flávio saiu aos 54 min.** Não bateu playbook completo, organização do CRM, scripts e segmentos prioritários. Tudo isso vai fechado na próxima reunião com ele. Mandar resumo escrito antes.

2. **Cliente sem cultura de daily.** Risco alto de não execução nas primeiras semanas. Por isso entrar junto.

3. **Conversão de 20% é estimativa, sem base de dados.** Fabrício admitiu não ter o dado real. Tracking real só a partir da próxima semana com a daily.

4. **Fernando e Célia já flagados como resistentes ao CRM** desde a pesquisa. Não brigar de cara.

5. **Diana fora.** Só 1 venda em 2 meses. Reavaliar em 30-60 dias.

6. **Não tem ferramenta de discagem definida.** Vão ligar do celular pelo Groner ou tem discador? Validar na próxima.

7. **Fabrício também vende.** 3,3 vendas/mês com ticket R$ 66k. Risco de ele virar gerente full e isso cair. Plano de transição precisa preservar parte das vendas dele enquanto migra pra liderança.

8. **Júnior (vendedor que saiu) tinha ticket próximo do Fabrício.** R$ 23.943. Era um vendedor de qualidade que saiu por questão cultural (não cadastrava no CRM). Isso é ao mesmo tempo prova de que precisa cultura e custo da falta dela.

9. **Sapezal ficou sem squad.** Só Célia, e ela tem problemas de saúde. Mercado de maior PIB per capita do MT está parcialmente desatendido.

10. **Não fechou a meta de margem (18-20%).** O Flávio pediu na pesquisa, mas a reunião tratou só de faturamento. Próxima reunião precisa amarrar margem ao plano (mix de comercial puxa margem pra cima).

## Alavancas pra usar

- **Engajamento técnico do Flávio** pra desenhar tracking, métricas e mediana correta.
- **Caso do vendedor que saiu** como prova social interna na cultura nova ("o que aconteceu com ele acontece com qualquer um sem CRM").
- **Mês de feirões e Dia das Mães** pra aproveitar pipeline aquecido enquanto monta estrutura.
- **Dhaiane** como ponta de lança interna (já abraçou método, fulltime, vende bem).
- **Fabrício em transição** está formalmente reconhecido pelo Flávio como prioridade, então a gente tem mandato pra investir nele.
- **Cases comerciais** sólidos (Lorenzetti, Kallos, Boitanga, É o Bicho, profissionais liberais) pra calçar pesquisa de mercado e abertura de ligação.
- **Reconhecimento público das limitações** — os dois falaram em voz alta o que não funciona. Trabalho ficou mais fácil.

## Pendências pra próxima reunião

1. Scripts de ligação prontos (3 segmentos × abertura, qualificação, agendamento)
2. Listas extraídas: Tangará + Diamantino + Nova Olímpia + Sapezal (Célia)
3. Pipeline Kanban montada no Groner pra prospecção
4. Pesquisa de mercado por segmento (margem, dor típica, vocabulário)
5. Daily com vendedores começando
6. Conversa direta com vendedores (apresentar método)
7. Definir ferramenta de discagem (manual no celular ou Groner tem discador?)
8. Validar como auditar: gravação de chamadas, escuta do Fabrício, ranking diário?
9. Recalcular ticket da Célia (estranho R$ 49k em 6 vendas → R$ 8k cada, validar)
10. Confirmar se Camila está dentro do squad ou só ramping
11. Status do Lucas (vendedor com 1 venda em recebimento)
12. Próximo passo do Júnior (deixar como histórico ou tem contato?)
13. Margem alvo amarrada ao plano

## Mapa mental fechado

```
META: R$ 500k/mês = R$ 438k atual + R$ 62k de gap

  ↓ resolve com

2 vendas comerciais/mês × R$ 50k = R$ 100k

  ↓ vem de

10 visitas qualificadas/mês (20% conversão)

  ↓ vem de

150 ligações/dia × 5 vendedores (30/cada)

  ↓ acontece em

Tangará + Diamantino + Nova Olímpia + Sapezal

  ↓ executado por

Fernando, Dhaiane, Célia, Camila + Fabrício gerenciando

  ↓ auditado por

Daily 20 min (Fabrício no comando, LM acompanhando 2 semanas)
```

## Próxima reunião

Pendente agendar. Foco: scripts + listas + Kanban + ligações ao vivo.

## Materiais de pesquisa e suporte

**Benchmarking de segmentos (pitch solar B2B):**
- [[Benchmarking de Segmentos — Pitch Solar (Supermercados, Mecânicas, Sorveterias, Padarias, Academias)]], consolidado
- [[Benchmarking — Academias (Pitch Solar)]]
- [[Benchmarking — Mecânicas (Pitch Solar)]]
- [[Benchmarking — Padarias (Pitch Solar)]]
- [[Benchmarking — Sorveterias (Pitch Solar)]]
- [[Benchmarking — Supermercados (Pitch Solar)]]

**Análises do cliente:**
- [[Synergy — Análise SWOT (cliente, 07-05-2026)]]
- [[Synergy — Quebra de Objeções (cliente, 07-05-2026)]]
- [[Cheat Sheet Objeções B2B — Prospecção Solar (1 página)]]

**Hub:** [[LM — Visão Geral|L.M Agência]]

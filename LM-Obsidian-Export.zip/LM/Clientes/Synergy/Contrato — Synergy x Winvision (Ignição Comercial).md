---
tipo: contrato
cliente: Synergy Soluções em Energia
contratada: Agencia Vision Mj LTDA (Winvision)
produto: Ignição Comercial
data_proposta: 2026-05-05
valor_total: 4000
parcelas: 3 (1500 + 1500 + 1000)
prazo: 45 dias
tags: [contrato, synergy, ignição-comercial, lm, winvision]
---

# CONTRATO DE PRESTAÇÃO DE SERVIÇOS DE CONSULTORIA COMERCIAL

## IGNIÇÃO COMERCIAL — PROJETO DE 45 DIAS

---

## PARTES

### CONTRATADA

**AGENCIA VISION MJ LTDA** (nome fantasia: WINVISION), pessoa jurídica de direito privado, inscrita no CNPJ sob nº **46.997.976/0001-81**, com sede na Rua Joaquim Neves, 117, Bairro Pântano do Sul, Florianópolis/SC, CEP 88067-120, neste ato representada por seus sócios:

- **MATHEUS JARDIM AMARAL**, brasileiro, portador do CPF nº **173.657.397-70**, telefone (31) 99505-2413
- **VALENTINO JOAQUIN PASCUAL**, portador do CPF nº **013.494.279-50**, residente na Rua 900D, 346, Itapema/SC, CEP 88220-000

Doravante denominada simplesmente **CONTRATADA**.

### CONTRATANTE

**SYNERGY SOLUÇÕES EM ENERGIA**, pessoa jurídica de direito privado, inscrita no CNPJ sob nº **32.366.610/0001-08**, com sede na Rua Deputado Hitler Sansão, nº 368, Sala 2, Bairro Centro, Tangará da Serra/MT, CEP 78300-072, neste ato representada por seu sócio-administrador **FLÁVIO NAREZZI DE OLIVEIRA**, brasileiro, portador do CPF nº **799.420.321-34**.

Doravante denominada simplesmente **CONTRATANTE**.

---

## CLÁUSULA 1ª — OBJETO DO CONTRATO

A CONTRATADA prestará à CONTRATANTE serviços de consultoria executiva em estruturação comercial, denominado **IGNIÇÃO COMERCIAL**, com duração de **45 (quarenta e cinco) dias corridos**, contados a partir da data de assinatura deste contrato.

O objetivo do projeto é estruturar a operação de prospecção ativa do time comercial da CONTRATANTE para que ela passe a gerar visitas qualificadas com clientes comerciais de forma previsível, retirando a dependência de indicação e a competição direta com concorrentes que praticam preço abaixo do mercado.

---

## CLÁUSULA 2ª — DESTINO DO PROJETO

Em 45 (quarenta e cinco) dias, a CONTRATADA se compromete a tirar a CONTRATANTE da concorrência desleal de mercado por meio da implementação de **prospecção ativa estruturada**, capacitando o time comercial da CONTRATANTE a alcançar clientes comerciais que valorizam qualidade e que não são atingidos pela concorrência atual.

---

## CLÁUSULA 3ª — ENTREGÁVEIS

A CONTRATADA se compromete a entregar à CONTRATANTE os seguintes itens durante o período do projeto:

### 3.1 — Máquina de leads (prospecção ativa)

a) Definição de **ICP** (Ideal Customer Profile) com perfil de empresa compradora (porte, segmento, região, consumo)
b) Definição do perfil do decisor (cargo, dores, autoridade de decisão)
c) **Lista de 50 a 100 empresas** prontas, atualizadas semanalmente, com nome, segmento, cidade e contato
d) **3 scripts validados** de prospecção (WhatsApp, ligação telefônica e abordagem por outros canais conforme necessidade)
e) **Cadência completa** de prospecção (canal → dia → mensagem → intervalo)

### 3.2 — Time estruturado

f) **Pipeline de CRM** estruturada para prospecção, com etapas e atividades por etapa (configurada no CRM da CONTRATANTE ou em planilha estruturada, conforme conveniência da CONTRATANTE)
g) **Playbook comercial** de 1 página para o time
h) **Documento de objeções e respostas** baseado em campo real de prospecção
i) **Roleplays ao vivo** com o time comercial da CONTRATANTE
j) **Treinamento de quebra de objeções** com objeções coletadas em campo real
k) **Ligações de prospecção ao vivo** acompanhadas pela CONTRATADA, com gravação para treinamento futuro

### 3.3 — Previsibilidade

l) **Dashboard de métricas comerciais** com indicadores de funil (ligações, visitas agendadas, propostas enviadas, fechamentos)
m) **Quebra de metas** em diárias, semanais e mensais
n) **Plano de continuidade de 30 dias** pós-projeto, para que a CONTRATANTE mantenha a operação rodando após o encerramento

---

## CLÁUSULA 4ª — METODOLOGIA DE EXECUÇÃO

4.1. A CONTRATADA atuará em formato de **consultoria executiva**, ou seja, ensina, faz junto e acompanha — não atua somente como treinamento teórico ou somente como execução terceirizada.

4.2. As atividades incluirão:
- **Reunião de onboarding** inicial (duração estimada de 1h30 a 2h00) para mapeamento da operação atual e personalização do cronograma
- **Reuniões coletivas com o time comercial** para treinamento, roleplays, ligações ao vivo, scripts e quebra de objeções
- **Reuniões individuais com o gestor comercial** (Sr. Fabricio Coletti) para alinhamento estratégico, análise de métricas e ajustes operacionais
- **Acompanhamento diário** ao longo dos 45 dias, com sessões de até 1 hora por dia útil ou conforme demanda

4.3. **Todas as reuniões serão gravadas** e disponibilizadas à CONTRATANTE para uso em treinamento de novos colaboradores e consulta interna.

4.4. **Primeiro evento/marco de entrega:** a CONTRATADA se compromete a ter o time da CONTRATANTE prospectando ativamente em até **15 (quinze) dias** após a assinatura do contrato.

---

## CLÁUSULA 5ª — RESPONSABILIDADES DA CONTRATANTE

5.1. Disponibilizar acesso e participação ativa do gestor comercial e do time de vendas nas reuniões agendadas.

5.2. Garantir que cada vendedor envolvido tenha disponibilidade mínima de **1 (uma) hora por dia** para atividades de prospecção ativa durante o período do projeto.

5.3. Preencher previamente o formulário de diagnóstico que será enviado pela CONTRATADA antes da reunião de onboarding, contendo informações sobre:
- Quantidade média de leads recebidos por mês
- Quantidade média de vendas por mês
- Taxa de conversão atual (lead → visita → proposta → fechamento)
- Nome e capacidade de horas disponível de cada vendedor

5.4. Manter atualizado o CRM ou planilha estruturada com os dados das prospecções, conforme processo definido na onboarding.

5.5. **Custos operacionais não inclusos:** ferramentas de telefonia, planos de WhatsApp, deslocamento de vendedores e demais custos operacionais do dia a dia comercial são de responsabilidade exclusiva da CONTRATANTE. A CONTRATADA confirma que para a execução do projeto não há necessidade de contratação de ferramentas pagas adicionais.

---

## CLÁUSULA 6ª — VALOR E FORMA DE PAGAMENTO

6.1. O valor total do projeto é de **R$ 4.000,00 (quatro mil reais)**, parcelado em 3 (três) pagamentos vinculados a marcos de entrega:

| Parcela | Valor | Vencimento |
|---|---|---|
| 1ª parcela | R$ 1.500,00 | Após entrega do marco de 15 dias |
| 2ª parcela | R$ 1.500,00 | Após entrega do marco de 30 dias |
| 3ª parcela | R$ 1.000,00 | Após entrega do marco de 45 dias |

6.2. **Forma de pagamento:** a ser definida pela CONTRATANTE entre Pix, transferência bancária ou boleto, mediante envio prévio dos dados pela CONTRATADA.

6.3. Cada parcela será emitida e cobrada após a confirmação da entrega do marco correspondente, comprovada pelos entregáveis listados na Cláusula 3ª.

---

## CLÁUSULA 7ª — GARANTIA DE EXECUÇÃO E CONTINUIDADE

7.1. A CONTRATADA garante que continuará prestando os serviços do projeto **sem qualquer custo adicional** caso, ao final dos 45 (quarenta e cinco) dias contratados, o time comercial da CONTRATANTE **não tenha gerado pelo menos 5 (cinco) visitas qualificadas com clientes comerciais**.

7.2. Para fins desta cláusula, considera-se **"visita qualificada com cliente comercial"**:

a) Visita presencial ou online formalmente agendada
b) Realizada com o decisor da empresa prospectada (proprietário, gestor responsável ou pessoa com autoridade de decisão sobre contratação de energia solar)
c) Empresa prospectada deve corresponder ao perfil de **ICP definido na Semana 1** do projeto (incluindo critérios de porte, segmento comercial e consumo de energia previamente acordados entre as partes)
d) Decisor deve ter confirmado interesse em receber proposta comercial após a visita

7.3. Caso a meta de 5 visitas qualificadas não seja atingida no prazo de 45 dias por motivos atribuíveis à execução da CONTRATADA, esta continuará prestando os serviços **sem custo adicional, sem prazo limite**, até a meta ser atingida.

7.4. Esta garantia **não se aplica** caso o não atingimento da meta seja causado por:

a) Não cumprimento das responsabilidades da CONTRATANTE listadas na Cláusula 5ª
b) Indisponibilidade do time comercial nas atividades agendadas
c) Recusa da CONTRATANTE em seguir as recomendações operacionais e estratégicas da CONTRATADA
d) Atrasos de pagamento por parte da CONTRATANTE

---

## CLÁUSULA 8ª — CONFIDENCIALIDADE E PROTEÇÃO DE DADOS

8.1. As partes se comprometem a manter sigilo sobre todas as informações estratégicas, comerciais, financeiras e operacionais às quais tiverem acesso durante a vigência deste contrato.

8.2. A CONTRATADA se compromete a tratar quaisquer dados pessoais aos quais tenha acesso em conformidade com a **Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD)**, utilizando os dados exclusivamente para finalidade de execução do objeto deste contrato.

8.3. As reuniões serão gravadas para fins de treinamento interno e consulta da CONTRATANTE, com acesso restrito.

---

## CLÁUSULA 9ª — VIGÊNCIA E RESCISÃO

9.1. Este contrato vigora pelo prazo de **45 (quarenta e cinco) dias corridos** a partir da assinatura, podendo ser estendido conforme Cláusula 7ª (garantia).

9.2. Qualquer das partes poderá rescindir o presente contrato mediante notificação prévia de 7 (sete) dias úteis, com pagamento proporcional dos serviços já entregues até a data da rescisão.

9.3. Em caso de descumprimento contratual por qualquer das partes, a parte prejudicada poderá rescindir o contrato imediatamente, mediante notificação formal, sem prejuízo de eventual indenização cabível.

---

## CLÁUSULA 10ª — DISPOSIÇÕES GERAIS

10.1. Este contrato representa o entendimento integral entre as partes, prevalecendo sobre quaisquer entendimentos anteriores, verbais ou escritos.

10.2. Eventuais alterações deste contrato somente terão validade quando formalizadas por aditivo escrito assinado por ambas as partes.

10.3. Fica eleito o foro da Comarca de Florianópolis/SC para dirimir quaisquer questões oriundas deste contrato, com renúncia expressa a qualquer outro, por mais privilegiado que seja.

---

E por estarem assim justas e contratadas, as partes assinam o presente instrumento em formato eletrônico, que terá plena validade jurídica nos termos da Lei nº 14.063/2020 e da Medida Provisória nº 2.200-2/2001.

Florianópolis, ____ de _________________ de 2026.

---

### CONTRATADA — AGENCIA VISION MJ LTDA (WINVISION)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
**MATHEUS JARDIM AMARAL**
CPF: 173.657.397-70

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
**VALENTINO JOAQUIN PASCUAL**
CPF: 013.494.279-50

---

### CONTRATANTE — SYNERGY SOLUÇÕES EM ENERGIA

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
**FLÁVIO NAREZZI DE OLIVEIRA**
CPF: 799.420.321-34
Sócio-administrador

---

### TESTEMUNHAS

1. Nome: ________________________________ CPF: ___________________

2. Nome: ________________________________ CPF: ___________________

---
data: 2026-05-05
horário: 19h00 BRT
tipo: R2 (auditoria privada / fechamento)
prospect: Flávio Narezzi de Oliveira + Fabrício Coletti (gestor comercial)
empresa: Synergy Soluções em Energia
cidade: Tangará da Serra / MT
participantes: Matheus Jardim, Valentino Pascual
duração: 44 min
status: FECHADO — contrato Ignição Comercial R$4.000 em 3 parcelas
produto: Ignição Comercial
valor: 4000
parcelas: 1500 + 1500 + 1000
prazo: 45 dias
tags: [vendas, r2, synergy, lm, winvision, ignição-comercial, fechamento, mentoria-nimoto]
---

# R2 Synergy — Flávio + Fabrício (05-05-2026)

R2 fechada. Synergy assinou o Ignição Comercial, R$4.000 em 3 parcelas vinculadas a marcos de entrega. Onboarding marcado pra quinta-feira 07/05 às 7h BRT.

> [!success] Resultado
> **CONTRATO FECHADO.** R$4.000 (1.500 + 1.500 + 1.000), 45 dias, com bônus de continuidade até gerar 5 visitas qualificadas com clientes comerciais.

## Próximos passos

- [ ] Criar grupo WhatsApp: Matheus + Valentino + Flávio + Fabrício
- [ ] Pedir dados pro contrato: razão social Synergy, CNPJ, endereço, CPF/RG do Flávio
- [ ] Mandar contrato pra assinatura digital
- [ ] Enviar formulário de diagnóstico pré-onboarding
- [ ] Quinta 07/05 7h BRT (8h LM): primeira reunião de onboarding

---

## Transcrição

**0:00 - Valentino**
Vocês têm mais gargalo hoje, seja na parte comercial, seja na parte de contratar, seja na parte de treinar a equipe, seja na parte de escala de equipe comercial e seja na parte de aumentar as visitas, aumentar a conversão de vendas e aumentar realmente tudo que a gente tem na parte comercial, tá? Isso é LM, a gente entra na sua operação, a gente ajuda a escalar seu comercial, tá? Não sei se você chegou a ouvir a parte inicial ali, mas o Matheus é o meu sócio, vou passar a palavra para ele agora.

**0:27 - Fabricio Coletti**
Show de bola, show de bola. Fabrício, prazer estar falando contigo, tá?

**0:32 - Matheus Jardim**
Que bom ter você aqui conosco nesse bate-papo, nessa conversa, nessa reunião aqui com o Flávio. Eu não sei se o Flávio te atualizou alguma coisa sobre o que a gente conversou, sobre alguns feedbacks que ele passou para a gente, sobre algumas dificuldades que tinha aí na operação. E Flávio, a primeira coisa que eu queria perguntar e ver contigo, se alguma coisa mudou da semana passada para essa semana, se teve alguma dificuldade nova, se permanece tudo igual, como é tá? Eu queria saber de você essa parte, se mudou alguma coisa, se as dificuldades continuam.

**1:05 - Flávio Narezzi de Oliveira**
Vamos dizer que tá a mesma coisa. Mesma coisa?

**1:08 - Valentino**
Na verdade, tá pior.

**1:10 - Flávio**
Na verdade, tá pior.

**1:11 - Matheus**
Tá pior em qual parte?

**1:13 - Flávio**
Não, assim, ó, obviamente, toda empresa de solar hoje, pelo menos uma boa parte delas que eu conheço, tá com um certo problema de caixa. Porque, vamos dizer que a gente tá vendendo mais com a mesma despesa, com o mesmo custo. A gente tá vendendo menos com a mesma despesa, ou com uma despesa até maior, porque existem os pós-vendas, né, que tiram a gente do centro, assim. Porque o tempo desprendido em pós-venda é um negócio absurdo, e isso porque o nosso pós-venda ainda é baixo. Porque tem muitas empresas com pós-venda extremamente altas. E aí, Papa?

**2:05 - Fabricio**
Total.

**2:07 - Matheus**
E Fabrício, Flávio e Fabrício, no caso, eu queria saber também que na semana passada você falou conosco que os seus problemas eram os vendedores que não trabalhavam CRM de maneira correta, não faziam preenchimento ali de maneira correta, falou também da autofagia de mercado, que aquela concorrência com os pica-fios, que aquilo ali é uma concorrência desleal na realidade. Só para a gente entender bem, é isso mesmo os seus problemas ou tem mais alguma coisa que tu queria agregar para a gente aqui agora?

**2:38 - Flávio**
Eu gostaria que o Fabrício falasse. Show. Pode falar, Fabrício.

**2:44 - Matheus**
Eu caí de paraquedas aí na reunião.

**2:48 - Fabricio**
Vou te dar um contexto, Fabrício.

**2:50 - Matheus**
O Flávio tinha falado para a gente na última reunião que os principais problemas e gargalos hoje que ele tinha era que a maioria... Tinha vendedores, alguns que eram 100% comissionados, alguns que eram fixos, alguns que eram fixos, mas comissão, e que esses vendedores não faziam o preenchimento correto do CRM, não tinham anotações do CRM, não faziam o trabalho de vendedor da maneira certa, que a gente possa fazer uma análise de dados, que a gente possa entender métricas de comercial e assim por diante. E também ele trouxe também, ele até falou um termo que a gente até pesquisou mais a fundo, foi entender, foi buscar, que é a parte da autofagia de mercado, que é a concorrência desleal ali, onde tem as pessoas que vêm, basicamente o mercado vem comendo o mercado ali, né? Então, ele trouxe isso daí, porque principalmente os superfills ali, vendem projetos muito baratos, com baixa taxa de retorno, e aí ficou uma concorrência realmente desleal. E esses foram os pontos que ele trouxe para a gente, ele pode falar.

**3:52 - Fabricio**
E aí eu queria ver contigo, se permaneça esse assunto, se tem algum ponto que tem para agregar para a gente ali. Na verdade, a parte do CRM, o que os vendedores trazem para mim é que é um CRM complicado de mexer, tem certas dificuldades de mexer, e por conta disso deixam de fazer algumas coisas, e aí muitas vezes acaba sobrando para eu fazer isso, ou para a secretária, hoje eu estou treinando a secretária, a gente passou quase um mês sem secretária, então acabou acumulando bastante coisa, então agora eu estou treinando uma pessoa que já mexia com esse CRM para cobrir, de certa forma, esses gargalos. Hoje, basicamente, um vendedor especificamente que não trabalha com CRM, vende mais na tabela, e depois a gente tem que só finalizar, lançar os clientes fechados dentro do CRM, e os demais têm uma certa dificuldade na hora de compor. A questão da autofagia de mercado, a concorrência hoje é bastante grande, tem muita empresa, principalmente fora da cidade, gente tem pouca competitividade, a gente abriu dois novos mercados que foram novas cidades, foi Mirassol do Oeste e Itapurá, onde a gente não consegue vender trabalhando com deslocamento, alimentação e hospedagem. Inclusive a Camila conversou com um cara lá de Mirassol, Flávio, aí ela passou que ele aceita a parceria com a gente, mas você tem uma ideia, por exemplo, usinas que a gente vende lá a 16 mil e pouco, ele vende por 13, então é uma diferença muito grande.

**5:58 - Flávio**
Esse valor é o que a gente... Vende com alimentação, hospedagem, etc., ou é o valor que a gente vende aqui?

**6:05 - Fabricio**
Não, é o que a gente vende com o deslocamento, alimentação e hospedagem. Mas ele é um tipo de... que eu acho que o Flávio caracteriza eles como pica-fio. É o cara que... é a empresa pastel, o cara ele vende, ele dá pós-venda, ele instala, então ele não tem uma estrutura igual a que nós temos. Então, financeiro, comercial, vendedor, engenheiro, e isso faz com que ele tenha um preço mais baixo do que o nosso. E a mesma coisa está acontecendo com o Tapurá, né, Flávio? Então, fora de Tangará, a gente não consegue ser competitivo justamente por essas questões aí das empresas do mercado de energia solar não ter essa barreira de entrada e qualquer um conseguir vender faturamento direto para o cliente e depois cobrar um valor lá para instalar. Basicamente é isso o cenário aí. E em Tangará também é a mesma coisa, na nossa cidade tem várias... agora que a gente não está vendendo em Itapurá.

**7:06 - Flávio**
A vendeu uma, né? Então, mas você não falou para mim que não estava vendendo, que gente estava perdendo, você não falou nada, para mim também.

**7:19 - Fabricio**
Em questão de competitividade, gente está sem competitividade. Mas se está sem competitividade, nós estamos lá tentando vender faz o quê?

**7:27 - Flávio**
Um mês, mais ou menos?

**7:35 - Matheus**
Pessoal, uma coisa que eu queria trazer e até perguntar de maneira aberta para vocês aí, que a gente vai trazer um projeto, um escopo de projeto aqui para vocês, que a gente traz uma solução, uma maneira de trabalhar para a gente sair dessa concorrência desleal, sair dessa briga realmente desleal com a concorrência. E eu queria perguntar para vocês, para o Flávio, para o Fabrício, qual que é o nível... O de urgência para estar resolvendo esse problema, para estar tentando contornar esse problema, para estar saindo dessa briga desleal, para também estar ajustando a parte do CRM também, que eu entendo que hoje o principal é a parte da briga desleal por preço mesmo, e depois o CRM por segundo. Eu queria estar sabendo, perguntando o nível de urgência que vocês estão para resolver isso hoje, como que está na parte de vocês aí, porque na nossa parte aqui está 100% com sangue no olho para ajudar vocês. Eu queria saber como que está a de Se a gente falar que é urgente, vai ser mais caro, então não.

**8:35 - Fabricio**
Está de boa. Tranquilo, está de boa. Não, é o mesmo preço, a gente já...

**8:40 - Valentino**
A gente pergunta isso, Flávio e Fabricio, porque se não for urgente, a gente vê que é algo que não precisa ser mudado, entende? Entendi. Agora a gente não vai trazer um projeto se a gente ver que não é urgente para vocês, entende? A gente viu que vocês estão aqui hoje, eu até quero confirmar com vocês dois, vocês estão aqui para você... E eueri... Atingiram o cliente certo de vocês? Saírem da comparação? É isso mesmo? Que a está no mesmo caminho? A gente pode dizer isso? Sim. Show.

**9:09 - Matheus**
Que daí, pessoal, hoje a gente traz um projeto aqui para vocês. O destino final que a gente quer levar e trazer para vocês é que em 45 dias, tirar vocês da autofagia de mercado através de uma prospecção ativa e estruturada, onde vocês vão alcançar os clientes que os pica-fios não conseguem alcançar. Vocês vão atingir uma nova leva de clientes que esses pica-fios, inclusive, não tem a capacidade de estar realizando um bom serviço, não tem a capacidade de estar fechando. Que são clientes, principalmente clientes comerciais, que são clientes que esses caras que não têm reputação, não têm mercado, não têm um pós-venda muito bom, eles não conseguem vender. E é isso que a gente quer trazer, essa solução, como que vocês podem estar atingindo esses clientes e como que a gente pode estar te ajudando a atingir esses clientes também. Se vocês quiserem essa parceria, firmar essa parceria com a gente. Então, eu queria só confirmar mesmo... Então, esse destino que a gente quer entregar para vocês, o resultado que a gente quer entregar para vocês, está alinhado com as expectativas também, que é um projeto de 45 dias, onde a gente quer tirar a questão que sai do cartão, e atingir a gente que os tempos, é isso mesmo, a gente está alinhado no mesmo caminho, a gente está no mesmo sentido, que a gente estiver no mesmo sentido e mostrar um projeto que faça sentido, a única coisa que resta no final é basicamente a gente alinhar preço, ver o que encaixa para vocês, e o que encaixa para a gente. Pode ser? Estamos alinhados nisso? Ou tem alguma coisa que impeça nesse primeiro momento? Ou seria um outro destino que você gostaria agora?

**10:40 - Fabricio**
Eu acho que se a gente conseguisse melhorar os leads, né Flávio, que hoje o tráfego que a empresa faz, uma das reclamações é que chega bastante lead desqualificado. Então, se vocês conseguirem melhorar essa parte da qualidade de sleep... De leads que chegam, de clientes que chegam para nós, é muito bom.

**11:04 - Flávio**
Olha, eu tenho quase certeza de que o tráfego pago não gera mais lead qualificado. Quase certeza. Porque eu acho que até a proposta dos meninos aí, Fabrício, não é nesse sentido não. Que isso aí é o que todo mundo vende e o que chega é tudo muito parecido. Você atende 20 para ter duas propostas firmes e para um fechar cada 40, sei lá. Então, assim, eu não acho que isso seja...

**11:42 - Fabricio**
Eu acho que o mercado mudou.

**11:44 - Flávio**
Eu acho que não é mais isso no mercado, não. Acho que o tráfego pago, para gerar autoridade, é ok. Mas para gerar lead, não sei. Está bem corrido. Inclusive, Flávio, eu concordo.

**11:57 - Matheus**
Eu é um grande ponto que você concordo firme. A gente conversa com várias empresas, a gente conversa com empresários da área do solar diariamente, com vários empresários diariamente, e várias reformações dele, é a falta de qualidade dos leads do tráfego, está cada dia mais ficando difícil trabalhar para as pessoas que vêm do tráfego, por isso que a gente foi na contramão disso, a gente rodava muito o tráfego para atrair clientes, para a gente fechar para nós, só que a gente viu que está ficando desneio, está ficando cada vez mais difícil, margem de lucro a pé, no caso que sumiu muito, e daí a gente encontrou esse negócio, encontrou o sistema de captação de lead de cliente para a gente, que é justamente o que a gente vai trazer para vocês aqui hoje, que é o sistema que a gente já trabalha no dia a dia para a gente, que é algo que se assemelha muito no que a gente fez para ter essa reunião, para estar batendo esse papo contigo, tá? Então, a gente basicamente estava no mesmo barco que vocês, só que agora a gente vai trazer o projeto que a gente desenhou para a sua... para a Synergy, para a realidade de vocês, tá? Eu vou apresentar aqui minha tela, inclusive, eu vou colocar, apresentar aqui, eu vou estar olhando para a direita aqui, é porque eu estou com o mapa mental na outra tela, inclusive, na verdade, eu vou chamar o mapa mental para essa tela aqui mesmo, vai ficar melhor a visualização, e vou compartilhar para a gente ir conversando, ir mostrando os caminhos que a gente entendeu para estar rodando esse projeto, seja com a gente, seja com outra pessoa que vocês queiram rodar também, a gente realmente veio para trazer uma solução independente com quem que vocês decidam estar colocando o projeto para rodar, tá bom? Vou compartilhar minha tela aqui, daí só me confirma se vai estar dando para ver certinho, está tranquilo, tá? Deixa eu ver, está dando para ver direitinho? Flávio?

**13:48 - Valentino**
Sim.

**13:49 - Matheus**
Fechou, então. Então, pessoal, a gente trouxe esse produto, esse caminho para o destino final, que é trazer mais números qualificados. Trazer, sair dessa briga de preço ali, com empresas que tem margem muito pequena, e a gente trouxe isso em três caminhos, trouxe isso em três pilares, a máquina de leads, que é basicamente como que você vai atrair leads qualificados para o teu time comercial trabalhar, o time estruturado, como que a gente vai organizar isso dentro da tua empresa, para os teus vendedores conseguirem trabalhar com os leads que estão gerando, conseguir fazer as visitas, conseguir enviar propostas, fazer o trabalho ali com a demanda que vai estar gerando através do comercial. E até Fabrício, te dando uma explicação que o Flávio até tinha dito, que não tem nada a ver sobre tráfego pago, nada a ver com o Instagram, nada dessas coisas, é 100% trabalhando com a capacidade do teu time comercial. Flávio, você consegue me relembrar quantas vendas vocês estão fazendo por mês aí hoje? Porque você falou que tinha em torno de sete vendedores, alguns comissionados, alguns fixos, algum fixo com comissão, como que está o volume de vendas em mensalmente.

**15:00 - Fabricio**
De 20 a 30.

**15:03 - Matheus**
E como está a capacidade do seu time comercial? Eles têm tempo na agenda para estar trabalhando, para estar correndo atrás de novos leads, porque isso é fundamental também para a gente estar gerando mais demanda, porque vai depender 100% da parte comercial. Eles têm, pelo menos, uma hora por dia, cada pessoa tem capacidade... Eu ensino.

**15:21 - Fabricio**
Fechou.

**15:22 - Matheus**
É isso que a gente precisa. E depois, Flávio e Fabrício, a gente parte para o terceiro tópico, que é a previsibilidade, porque não adianta você ter um comercial e não ter previsibilidade ali, tá bom? Então, dentro da máquina de leads, como que funciona? A máquina de leads, a gente vai estar trabalhando listas de empresas ali por semana, de pelo menos 50, 100 pessoas toda semana, para o teu time comercial estar trabalhando. E daí, é importante, pessoal, isso daqui é uma entrega de 45 dias, onde a gente entra, ensina vocês a fazer e faz junto com vocês, tá bom? Então, não é algo que é só treinamento e não é algo que é só implementação. A gente entra, ensina e faz com vocês também, em determinados pontos, tá? Igual, dentro da estrutura, do contexto ali, de te levar pro destino ali, que tem mais leitos fabricados, tem mais... sua venda, pega a sua venda. Quer saber aonde que você vai encontrar os clientes comerciais, que aquelas empresas que vendem ali commodities, que vendem produtos...

**16:20 - Fabricio**
Não consegue chegar, não consegue vender. Clientes comerciais, são clientes que tem uma conta de energia mais alta, são clientes que necessitam de um pós-venda. E fez...

**16:31 - Matheus**
A gente te ensina, e mostra, faz junto. Depois, a gente traz todo o time comercial, você, o Fabrício, todas as outras sete pessoas no seu time comercial, pra tá trabalhando com o que a gente vai ligar, e o que a gente vai falar na ligação. E isso a gente faz junto com vocês também. A gente pega o telefone, vai ter reuniões, isso daí tá dentro do escopo, a gente vai definir na nossa reunião de acordes, a ordem lógica do... do... Do cronograma, tá? A gente trouxe o cronograma por completo da entrega e dentro da nossa reunião de onboard a gente vai personalizar ele de acordo a sua demanda, de acordo as suas necessidades, porque não adianta trazer algo fixo, sendo que você precisa do entregável da sexta semana na primeira. Então por isso a gente não trabalha assim. E daí a gente traz os inscritos de ligação, como ligar, isso daí vai ser um account onde a gente vai entrar com todo mundo no team, já com as listas na mão e vou começar a ligar com o pessoal. E daí a gente, o porquê que isso é bom? Porque muitas vezes o vendedor ou a pessoa do comercial trava ali uma determinada, um determinado ponto da ligação. E aí a gente tá ali pra ajudar elas, tá ali pra ajudar a quebrar a objeção, tá ali pra ajudar a contornar isso. A gente vai ligar pra empresas, pra vocês também, dentro dessa reunião, dentro dessa aula, tudo no ao vivo ali, gravado também pra quando entrar um novo vendedor, você mandar ele assistir e ter uma base de treinamento e já facilitar pra vocês aí também. Depois da parte do script de ligação, a gente vem pra parte... Na área comercial, pessoal, a gente não pode tentar contato com a empresa uma vez e largar ela, aqui muitas vezes a gente consegue falar com o decisor depois do sétimo contato com a empresa, então muitas vezes a cadência é o que faz manter o nosso comercial vivo, que faz manter a nossa pipeline de CRM viva com várias propostas na mesa, com várias reuniões marcadas, com várias visitas marcadas, então isso é um ponto fundamental ali, então na máquina de vendas a gente traz como que, como a sua equipe vai gerar leads, a máquina de leads, a gente traz como sua equipe vai gerar leads e como vai fazer o trabalho no team estruturado, que é o próximo pilar, a gente vai trazer ele só, um CRM rodando para a prospecção, com etapas e atividades para cada etapa, então a gente vai trazer um CRM ali, uma pipeline dentro do mesmo CRM, ver o que vocês têm, qualquer coisa a gente pode adaptar isso em planilha, é super tranquilo fazer isso também, tá bom? Por quê? Porque uma prospecção, A proteção de um processo comercial, onde a gente não consegue mesurar os dados, a gente não consegue ter escala e previsibilidade, que é o próximo tópico, porque pensa só, se você tem um vendedor que faz 50 ligações para marcar duas visitas, o que é que você precisa para escalar esse vendedor são dois pontos, ou melhorar a abordagem dele para 50 ligações dele marcar três, ou dobrar o número de ligações dele por dia, e aí simples assim, a matemática do comercial, mas para isso a gente precisa ter isso anotado, precisa ter esse número em mãos, para a gente sentar com você e fazer essas análises, entendeu? E depois o CRM rodando para a prospecção do playbook, porque não adianta nada a gente ter as ferramentas, ter o treinamento, mas não tem algo que o seu time, a sua equipe comercial vai consultar no dia a dia. Então tá, qual que o script? Toda hora o pessoal do comercial vai estar perguntando, o Flávio, o Fabricio, o que é eu tenho que falar? Não, já tem ali tudo certinho, o é você vai falar em cada parte, o script, como que você vai ligar, tom de voz, palavras que você vai usar. Então isso, dito o ritmo do teu comercial... Para ele parar de depender 100% da pessoa ali, 100% do Flávio, 100% do Fabricio, então a gente já pensou isso para não consumir o teu tempo no dia a dia, fechado? Está dando para entender, pessoal, Flávio, Fabricio, está tranquilo? Sim. Fechou. E daí, pessoal, dentro disso, no time estruturado, a gente tem os roleplays, que é basicamente a gente entrar com vocês, entrar para o seu time comercial e ligar junto, entender, fazer ligação de teste, então a gente vai pegar eu e o Fabricio, Fabricio, liga para mim, eu vou ser um cliente, vamos supor, vou ser uma panaria e você vai ligar para tentar marcar uma reunião comigo, marcar uma visita para mim, vamos lá, eu vou fazer agora um cliente mais tranquilo, para você entender como que é uma pessoa mais tranquila, vou fazer agora uma pessoa difícil, para testar realmente os pontos e te passar um feedback ali na hora, fazer isso com todo o teu time, isso daqui é de extrema importância, isso daqui é um dos fatores determinantes para o sucesso ali dentro de operação. E depois, pessoal, um treinamento de quebra de objeções, a gente trazer ali, fazer um, depois de uma semana do time prospectando, pedir... E eles, para anotar, no bloco de notas que estejam, as principais objeções que eles estão tendo, então eu liguei para a empresa e o cara falou que já tinha painel solar, mas se ele já tem painel solar, porque aí a gente vê os serviços certinhos que você vende, tudo isso a gente vai entender no onboard, mas por que que não vendeu uma manutenção? Por que que você não entendeu? Às vezes ele só tinha o mercado de energia, podia vender o painel solar no Coraco, o mercado de energia tem um desconto menor e a integração do painel solar ali, vai dar um desconto maior no campo de luz. Então isso são objeções que a gente pede para as pessoas do comercial anotar, que a gente faça uma reunião só disso, para deixar o seu time comercial blindado relacionado a isso, tá? Depois disso, pessoal, a gente vem para a parte de previsibilidade, porque uma empresa que não tem previsibilidade comercial, ela não consegue planejar as ações no mês seguinte, não consegue planejar ações de marketing, seja ações de investimento na própria empresa, porque realmente ela não sabe quanto vai faturar no próximo mês. E você já tem uma base de previsibilidade. Você já entende, opa, eu estou no mês de maio, eu já sei mais ou menos quanto eu vou faturar em junho. Então, opa, eu posso subir um pouco mais tranquilo. Que daí a gente vai entregar para vocês um dashboard com todos os dados condensados da sua equipe e a gente vai te entregar isso também, onde quando a gente encerre o projeto nos 45 dias, esse dashboard fica para vocês, onde os seus vendedores realmente só vai anotando ali quantas ligações fez, quantas visitas foram agitadas, quantas reuniões foram fechadas, quantas quantas visitas viraram propostas, quantas propostas foram fechadas. Isso daí, tu consegue entender, opa, no mês de maio, minha equipe fez 500 ligações, 500 prospecções de empresa, dessas 500, exemplo, tá? 50 virou visitas e dessas 50 virou visitas, 10 fecharam. Então, opa, peraí, vamos manter o mesmo nível, o mesmo ritmo para a semana para o mês seguinte, que a gente, teoricamente, a gente vai conseguir bater as 10 vendas, tá? Tá ficando tranquilo? Tranquilo até agora? Show. Então, pessoal, a partir disso, a gente consegue, a partir desse dashboard, você consegue quebrar isso em metas semanais, mensais e diárias. Então, porque quando a gente coloca uma meta mensal, está muito longe para bater. Então, a gente quebra isso em pequenas metas para ficar atingido e essa pessoa conseguir desempenhar melhor a atividade e você conseguir controlar para ver se está no caminho certo também. Porque, às vezes, a venda é o estágio final, mas você está tendo pequenas vitórias antes de ter a venda. Então, quando você está tendo as vitórias certas antes de ter a venda, o caminho para a venda está segurado lá na frente. E depois disso, pessoal, a gente não quer largar a mão de vocês, depois dos 45 dias do projeto implementado, de toda a estrutura que são feitas. A gente quer entregar um plano para vocês de como vocês vão seguir, pelo menos nos próximos 30 dias, e rodar essa estrutura. Essa estrutura com o seu comercial ligando, com o CRM rodando para a operação, mostrar a vocês e vocês entenderem. Então a gente vai te entregar um plano ali para os próximos 30 dias para vocês conseguirem estar trabalhando com o seu time comercial e entregando o resultado ali. E pessoal, agora eu queria saber da parte de vocês, eu queria saber se vocês acreditam que isso faz sentido hoje para a realidade de vocês, se vocês acreditam que isso é para vocês hoje, eu queria realmente ouvir um feedback sobre esse organograma que a gente trouxe aqui da entrega do projeto para vocês.

**24:28 - Fabricio**
Eu que estou na ponta ali, eu que lido direto com os vendedores, faz muito sentido sim, porque muitas vezes os clientes, os vendedores não sabem prospectar, não sabem como, não sabem onde, não sabem o que falar, quando tem objeção, às vezes não sabe contornar, então faz sentido sim. Que legal, que legal.

**24:58 - Matheus**
E da sua parte, Flávio?

**25:03 - Flávio**
E pessoal, a gente já tem um playbook, tá faltando formatar ele.

**25:11 - Matheus**
Legal, então a gente pode trabalhar o melhor dos mundos e formatar o seu playbook, se tiver algo que a gente possa agregar voltado para a prospecção antiga, gente já agrega e já adiciona isso dentro do seu playbook.

**25:23 - Flávio**
No ano passado, a gente fez um bom conjunto de reuniões, eu fazia dinâmicas de grupo e voltadas à criação do playbook. Então, por exemplo, controle de objeção, a gente fez algumas dinâmicas para tentar colocar na cabeça dos vendedores os controles de objeção. E tiveram muito boas soluções para os controles. Tem que melhorar, mas controle de objeção sempre tem que melhorar. Então, assim, tem que iniciar o processo e ir atualizando o playbook à medida da necessidade, da solução, do compartilhamento de coisas que deram certo, etc.

**26:19 - Matheus**
Flávio, e é exatamente isso a maneira mais correta de criar um playbook de processos comerciais, principalmente na parte de objeção, é realmente colher no feedback do seu time ali no campo de batalha, no dia a dia real ali, que não adianta nada da teoria, né? Sempre o campo de batalha vence a teoria em 100% dos casos. Então, isso que você fez no seu playbook, imagino eu que é um baita playbook, um playbook bem completo. Então, a gente entraria ali realmente para agregar o que falta relacionado à parte de prospecção ativa, que possa ser que talvez não tenha 100% da metodologia que a gente vai empregar aí dentro com vocês, com seus vendedores ali. Então, pô, a gente pode ter certeza... certeza que a gente vai entrar, ver o trabalho de vocês, o playbook ali, e trazer, antes de modificar o que você já fez, tá? E de acrescentar, a gente senta e te via, Flávio, a gente gostaria de adicionar isso no teu playbook, isso, isso, isso, isso. Você daria a liberdade da gente formatar e trazer uma formatação do seu playbook original com essas atualizações? Então a gente viria e fazer essas atualizações e apresentava pro time, mostrava pra eles o que que tem, como que eles utilizam, como funciona o dia a dia, porque não adianta de nada o playbook se o pessoal não tá usando, né?

**27:30 - Flávio**
Sim, com certeza.

**27:31 - Matheus**
Certeza. E pessoal, outra coisa que eu queria saber, hoje você, Flávio, você, Fabricio, vocês acreditam que na gente pra estar executando isso com vocês aí, pra estar executando isso em parceria, porque a parte da confiança e do comprometimento e do entendimento que a gente pode avançar e pode ajudar vocês é de grande valia, porque se hoje tem alguma dúvida, algum pé atrás pra gente tá realizando isso com vocês, é o momento da gente conversar, da gente entender qual dúvida é o momento Se não tiver, estiver tudo tranquilo, gente segue para a parte de preço, entender se não tem mais nenhuma dúvida e a gente bate preço e ver se a gente vai, vamos casar as ideias ali para começar os trabalhos.

**28:13 - Flávio**
A pergunta que eu faço é o seguinte, você vai conversar só comigo e com o Fabricio ou você vai conversar com os vendedores?

**28:21 - Matheus**
Não, com todo mundo, o treinamento é com todo mundo, todo mundo que você conseguir colocar dentro da reunião e no horário, vamos supor, a gente seta um horário que seja melhor para os dois, para mim e para você, independente do horário aqui, você já viu que a gente é bem aberto para fazer coisas fora do horário comercial, se o seu vendedor, seu time for aberto para isso, a gente faz mais cedo, antes de entrar no serviço, a gente faz, a depender da sua rotina. E Flávio, hoje tem mais alguma dúvida relacionada a produto, a entrega, a qualquer coisa que você tenha relacionada a isso, para a gente estar batendo isso e depois só falar... Só de preços, tá tranquilo?

**29:04 - Valentino**
Fabricio, alguma dúvida a mais?

**29:08 - Fabricio**
Não, acho que ficou bem claro aí qual que é a atuação deles, né? Basicamente treinamento e organização aí dos resultados, né? Sim, e eu acordo com vocês ali também no dia a dia.

**29:25 - Matheus**
E pessoal, até algo antes de falar do preço ali, que eu queria trazer para vocês, esse projeto de 45 dias, ele se estende indefinidamente, sem custo nenhum para vocês, até seu time estiver gerando reuniões com clientes comerciais, tá? Então a gente não larga a mão de vocês enquanto seu time não estiver performando, tá bom? Porque a gente quer realmente que vocês virem cases nossos aqui. Fechado? Então a gente traz essa garantia até antes de falar o preço aqui, porque a gente quer realmente entregar resultado para vocês. Hoje, pessoal, o valor dessa implementação da ignição comercial... No projeto de 45 dias, ela fica no valor de R$4.000,00, tá? R$4.000,00.

**30:07 - Flávio**
Isso. Como que é esse pagamento?

**30:10 - Matheus**
Pode ser à vista no Pix ou também parcelado no cartão de crédito, tá?

**30:15 - Flávio**
Certo.

**30:16 - Matheus**
Pra você fica melhor no Pix ou fica melhor no cartão?

**30:21 - Flávio**
Cara, eu não gostaria de pagar nada à vista e eu não gostaria de pagar nada no cartão. É assim, eu não vou julgar vocês, mas cachorro picado por cobra tem medo de linguiça. Então, assim, vocês conversaram conosco, etc. O contato que eu tenho é via telefone. Um é de Minas Gerais, o outro é argentino, mas mora em Santa Catarina. Pô, o máximo que eu posso fazer é falar mal do Boca ou River, não sei qual que a gente sabe.

**30:58 - Valentino**
É.

**31:00 - Matheus**
Eu acredito que, pensa num bicho que é todo esquisito, ele mora na Argentina, que é um país de futebol, mora do Brasil, quer mais futebol ainda, ele não gosta de futebol direito.

**31:11 - Valentino**
Eu sou da luta, rapaziada. Qual luta? Boxe.

**31:17 - Flávio**
Boxe é Você luta alguma coisa, Flávio?

**31:20 - Valentino**
Gil? Oh, o Jiu Jitsu é massa.

**31:24 - Matheus**
Tem vontade de começar o Jiu Jitsu? Tem muito tempo que você luta ou recente?

**31:29 - Flávio**
Eu fiquei um ano no Karatê, aí depois fui pro Gil. Hoje eu marquei duas ressonâncias também, né? O Jiu Jitsu foda. Porrada que ele é roupa?

**31:45 - Valentino**
É, porrada. Quadril?

**31:46 - Flávio**
Não, joelho e dedo do pé.

**31:49 - Valentino**
Eu falo que o Jiu Jitsu, na briga de rua em si, ela é a luta que mais é efetiva, o Jiu Jitsu, por conta de derrubar a pessoa. Cara, se for placa. Imobilização.

**31:59 - Fabricio**
Obrigado.

**32:00 - Flávio**
Se for próximo, sim, mas se tiver espaço, o karatê é melhor, e o boxe é indegavelmente melhor em boate, por exemplo, lugar apertado, o cara que luta boxe, arrebenta os outros, o MMA é o MMA, é múltiplo, são vários esportes, e falando até de MMA, eu gosto muito de se acompanhar, muito bom, muito bom, muito bom, e Flávio, você tinha falado que não conhece a gente, conhece a gente só por telefone, um da Argentina, parra brasileira e outro brasileiro de Belo Horizonte, essa parte, e isso daí a gente tem tudo firmado em contrato também, tá, pra garantir a sua segurança também. Eu sei, entendo, mas é porque eu já fui enganado mais de uma vez, então assim, não é que eu fui picado uma vez só, fui picado várias vezes, então... Eu não gostaria de pagar nada à vista, e nem no cartão, porque, por exemplo, teve um serviço que eu dividi no cartão, o cara precisou dois meses do serviço e depois desapareceu, respondia a cada dois, três dias, falava, oi, vamos analisar seu caso, etc. Aí só me restava a justiça, entendeu? poxa, cara, a trabalha com a justiça, está gastando tempo com o advogado. Oi?

**33:29 - Valentino**
O valor pequeno você vai gastar mais com o advogado do que o próprio valor que ele tem que te voltar?

**33:34 - Flávio**
Exatamente, entendeu? Então, assim, aí a gente não é empresa do simples, então nem a pequenas causas a gente tem acesso. Seria mais simples sem advogado, nada. Mas, então, assim, é muito complicado do meu ponto de vista, entendeu?

**33:51 - Matheus**
Eu te entendo, Flávio.

**33:53 - Valentino**
E a gente também, assim, a gente é desconfiado, principalmente com o digital. E eu queria te perguntar, é mais para... picadas que você recebeu ou é realmente pela gente, pelo nosso lado aqui?

**34:03 - Flávio**
Pelas picadas, eu estabeleci uma regra na minha cabeça e eu sigo essa regra, entendeu?

**34:10 - Valentino**
Sim, a gente foi picado também algumas vezes, na parte do digital, em parte de cursos também, e a gente entende a tua sensação, né? Nós temos que estabelecer uma outra forma, entendeu?

**34:23 - Flávio**
Eu estou confiando que vocês vão prestar o serviço, se não a gente está perdendo tempo, etc. Mas a gente precisa estabelecer uma outra forma, de outra forma.

**34:34 - Matheus**
Uma ideia que eu tive aqui, Valentino, o que a gente pode fazer? A gente pode setar, a gente faz o contrato de entrega de serviço, tudo bonitinho, e a gente seta pagamentos pós entrega. Exemplo, a gente fez entrega de 15 dias, vocês pagam R$.500,00. Fez mais entrega de 15 dias, mais R 1.500,00. Fez a entrega dos últimos 15 dias, o outro pagamento do restante... Aí faz sentido, porque daí meu pai gosta de falar que gado escaldado tem meio de água fria, né, então aí agora a gente já entra num consenso que a gente consegue fazer esse ajuste pelos dois lados, que daí a gente pode firmar desse modelo, pra gente estar dando início? Por mim tá ok, dessa forma sim.

**35:23 - Flávio**
O Fabricio tá, creio, por ti também. Vocês vão conversar direto com o Fabricio, tá, Fabricio e o time comercial, eu não vou poder me comprometer com isso, porque já teve casos assim de, ah, precisa de mim, precisa de mim, que eu sinto, sinto, que quem tava fornecendo o serviço já sabia que eu não conseguiria participar, entendeu? E aí fica procrastinando até vencer o contrato e acabou. Então assim, não acho... Com certeza, não tem problema.

**35:57 - Matheus**
Então, Fabricio, a gente pode tratar... A primeira reunião, Flávio, seria interessante que é a reunião de on-board para a gente entender um apanhar no geral sobre a Synergy, que daí é uma hora e meia, duas horas, onde a gente vai definir todos os entregáveis e o que você precisa dentro daquele escopo que a gente passou para vocês. Essa primeira reunião é tranquilo para participar? Sim, tranquilo.

**36:21 - Flávio**
Fechou. A pergunta que eu faço é a seguinte, o que vocês precisam de dado? Vocês precisam do que? De número de leads, número de venda? O que vocês precisam exatamente?

**36:33 - Matheus**
A gente, basicamente, gente vai entrar dentro da nossa reunião, depois que a gente, eu vou te dar o cronograma depois daqui. A gente dando o acerto positivo aqui, a gente vai fazer o contrato, mandar para vocês assinatura de contrato com tudo que a gente conversou aqui. Inclusive, a gente está gravando, a gente vê a transcrição dessa gravação, como você tem lá também.

**36:52 - Flávio**
Depois disso, a gente marca a primeira reunião de on-board.

**36:55 - Matheus**
Antes da reunião de on-board, gente vai montar um formulário com perguntas de tudo que a gente precisa. Saber, antes de entrar, de fazer nossa reunião de onboard, exemplo, quantidade de livros que vocês têm por mês, quantidade de vendas, taxas de conversão, quantas pessoas, de quantos livros que chegam, quantos vai para a visita, quantos de visita, quantos fecha, quantos de orçamento, quantos fecha, depois disso, capacidade de tempo de cada vendedor que vocês têm, quais são os nomes dos vendedores que vocês têm, para a gente montar um planejamento em cima das horas de trabalho dos seus vendedores, que tem livro também em cima disso, para a gente, em cima disso, fazer um planejamento prévio de metas já para entregar para vocês dentro dessa primeira reunião, ou então dentro dessa primeira reunião a gente já construir isso com vocês, porque, vamos supor que cada vendedor seu tem uma, duas horas por dia, então a gente pode setar uma meta de 30 a 40 ligações por vendedor por dia, então isso tem 7 vendedores, ou que seja 5, 6, a depender da demanda, a gente consegue montar um cronograma de metas de ligações para os seus vendedores, que é o primeiro estágio do funil. E a partir disso, A gente vai marcar a próxima reunião assim, o mais rápido possível, para já estar ensinando eles a fazer esse trabalho, entendeu?

**38:06 - Flávio**
Vocês vão entrar dentro do CRM?

**38:09 - Matheus**
Não, a gente não precisa entrar dentro do CRM, mas aí daí, como a gente vai conversar direto com o Fabrício, se a gente precisar, aí depende de vocês. Se vocês quiserem que a gente entre, a gente entre e organiza. Se não quiser, a gente organiza junto com o Fabrício, ou em reunião com Carlos aqui no vídeo, o Fabrício compartilha a tela. Somente da pipeline que a gente vai construir, somente para prospecção, ou então a gente fala, Fabrício, eu preciso de uma pipeline do CRM, assim, assim, assim, com esses fluxos que você constrói para a gente, aí é a depender de como que vocês gostariam de trabalhar, entendeu? Certo. Para não ser vazio, a gente entende que também dentro do seu CRM pode ter dados ali, a lei geral de proteção de dados vem muito rigorosa relacionada a isso, então a gente trabalha de acordo com as normas da empresa. Se vocês estão contratando a gente, a gente vai te entregar o serviço, mas a gente tem que entregar o serviço dentro das normas que vocês trabalham. A gente não pode passar por cima de vocês, entendeu?

**39:03 - Flávio**
Tem algum custo extra?

**39:05 - Matheus**
Não, basicamente não. Todas as listas que a gente extrai ali, listas do Google mesmo, de empresas que estão no Google. Depois, telefone, os próprios vendedores têm telefones e tem planos de telefone para ligar, que utilizam no dia a dia para conversar no WhatsApp, para ligar para as pessoas. Então, isso daí não tem custo. Caso vocês optem por não trabalhar dentro do segmento, a parte de prospecção ativa, a gente monta uma planilha para cada vendedor, monta um sistema de planilhas ali e fica tranquilo. De início, é só o custo operacional mesmo para a gente estar implementando aí contigo. Certo.

**39:39 - Flávio**
Tem mais alguma dúvida? Fabrício, faz sentido para você? Faz sim.

**39:47 - Fabricio**
Você acha que você consegue atender pelo tempo que você está tendo agora, pelas suas tarefas que estão acontecendo?

**39:55 - Flávio**
Você acha que faz sentido você participar desse treinamento e depois... Pelo que eu entendi, posso estar enganado, mas uma parte grande do treinamento será contigo, para você depois implementar isso daí com os vendedores, vamos dizer assim.

**40:13 - Matheus**
A gente, em grande parte, para bater te interrompendo, vamos supor, tudo que, a parte teórica basicamente é com o Fabricio separado, mas na grande maioria vai ser muito mão na massa junto com o seu time comercial, porque a gente tem que apoiar ele, porque é no dia a na rotina de ligações, no dia a dia, que vai surgindo as dúvidas, que vai precisando da ajuda. Então, basicamente, a gente vai entregar o treinamento e fazendo junto com eles, e deixando isso tudo gravado. E te entregando esses meetings, igual a gente está aqui, tudo gravado para vocês terem um pouco de treinamento também depois. E toda reunião que eu tiver com o Fabricio também, a gente deixa isso gravado. Vamos supor, quais reuniões que o time não participa? Reunião de meta, definição de meta, reunião de on-board, reunião de treinamento do time participa, reunião de roleplay do time Reunião de script, extração de lista, ligação ao vivo, todo mundo participa, então na grande maioria entrega o coletivo com todo o time comercial e uma ou duas ali vai ser o Fabricio, que aí vai ser uma hora, uma hora e meia, cada reunião, em cada semana ali, fechou? Beleza.

**41:20 - Fabricio**
Fabricio, tudo tranquilo do teu lado?

**41:22 - Matheus**
Tu consegue cumprir? Tudo tranquilo.

**41:25 - Fabricio**
Fechou?

**41:26 - Matheus**
Ô Flávio, então a gente pode estar fazendo um contrato do nosso lado pra gente estar dando um start?

**41:30 - Fabricio**
Pode. Fechado, então.

**41:32 - Matheus**
Flávio, qual é a disponibilidade de vocês pra estar marcando um onboard assim? A gente já pode estar marcando, o ideal seria ali quinta-feira mais ou menos, porque amanhã a gente mandava pra vocês o formulário pra gente entender um pouco mais a fundo a Synergy e na quinta-feira a gente já viria com uma reunião mais, uma reunião montada e organizada pra gente dar o maior proveito ali no tempo que a gente tem. É tranquilo na quinta ou tá agarrado? Tchau.

**42:00 - Flávio**
Para mim, quinta-noite pode ser. Para você, Fabricio.

**42:04 - Valentino**
Mesmo horário ali?

**42:05 - Flávio**
Mesmo horário. O Valentino acha que na quinta-noite a gente não consegue, porque a gente tem...

**42:09 - Fabricio**
Quinta-noite acho que não dá não para mim. Na sexta é difícil?

**42:15 - Matheus**
Como que está?

**42:16 - Flávio**
Sexta eu tenho duas ressonâncias magnéticas que eu não sei que hora que termina. Tem a hora que manucada, a hora que termina é outra conversa.

**42:27 - Fabricio**
Quinta-feira, para mim, não marca nada, que geralmente tem um compromisso na igreja.

**42:34 - Matheus**
Quarta-feira de noite também.

**42:36 - Fabricio**
Então, acho que seria melhor no começo da manhã, Flávio. Por exemplo, ir mais cedo para o escritório, vou às sete, lá para eles vai ser às oito. Eu acho que seria mais jogo do que de noite. Certo.

**42:50 - Flávio**
Quantas horas é isso aí? Uma hora e meia, duas horas no máximo, né?

**42:55 - Matheus**
Finalizando. Aí, na quinta ou na sexta, qual que fica mais tranquilo? E aí,

**ACTION ITEM:** Create WhatsApp group w/ Flávio, Fabricio, Valentino; send contract for e-sign; after sign send onboarding form

**43:00 - Flávio**
Não, por mim pode ser, a partir das sete horas tá tranquilo. Então fechou, pode ficar na quinta ali então, Fabrício?

**43:12 - Fabricio**
Pode, depois de amanhã, né?

**43:14 - Flávio**
Fechou.

**43:14 - Matheus**
Pessoal, a gente vai criar um grupo, eu, você, o Valentino, o Fabrício também, e ali a gente vai montar um contrato, entrega, amanhã vocês podem ler com calma o contrato, assinando, a gente já manda o formulário para estar fazendo as primeiras perguntas ali, para a gente entender mais a fundo.

**ACTION ITEM:** Host onboarding call May 7 7:00 BRT (8:00 LM) w/ Flávio, Fabricio, Valentino; record

E na quinta-feira, ali, sete horas da manhã para vocês, e oito horas da manhã para nós, a gente já faz a nossa primeira reunião. Fechou? Beleza.

**43:38 - Flávio**
Fechou então, pessoal?

**43:41 - Matheus**
Agradeço vocês pela confiança, e a gente vai empenhar o máximo do nosso lado aqui para entregar resultado para vocês, tá bom? Combinado.

**43:48 - Valentino**
Foi muito prazer falar com vocês, pessoal. Boa noite. Parabéns para a gente. Mateus, Valentino, boa noite. Boa noite. Boa noite. Tchau.

---

## Documentos relacionados

- [[Contrato — Synergy x Winvision (Ignição Comercial)]]
- [[2026-04-22 — Matheus e Tino vs Synergy (R1)]] — análise da R1
- [[CLOSER R2 — Versão Matheus]]
- [[Apresentação Miro — Ignição Comercial]]

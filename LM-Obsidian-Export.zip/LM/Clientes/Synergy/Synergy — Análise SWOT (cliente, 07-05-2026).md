---
data: 2026-05-07
tipo: material-cliente
origem: enviado pelo Flávio (dinâmica interna Synergy)
cliente: Synergy
relacionado:
  - "[[Onboarding Synergy — Notas e Análise (07-05-2026)]]"
  - "[[Synergy — Quebra de Objeções (cliente, 07-05-2026)]]"
tags:
  - lm
  - synergy
  - swot
  - playbook
---

# Synergy — Análise SWOT (material do cliente)

Documento que o Flávio mandou. Saiu de uma dinâmica interna da Synergy. Vai virar insumo do playbook depois.

## Forças

- Verdade
- Transparência
- Técnica
- Honestidade
- Conservador
- Realista
- Comprometimento com o cliente
- Confiável
- Bom planejamento
- Preço competitivo
- Bons produtos
- Cumpre o combinado
- Vendedores humildes
- Cumpre boas técnicas
- Equipe bem remunerada
- Experiência no setor
- Qualidade na instalação
- Segue as normas de instalação
- Busca melhorias técnicas
- Empresa setorizada
- Pós-venda
- Instalação de qualidade

## Fraquezas

- Falta de agilidade nos processos internos
- Falta de comunicação
- Falta de parceria
- Medo da concorrência
- Agilidade nas decisões pra crescimento da empresa
- Planos de pagamento
- Força comercial / marketing
- Sócio ainda com reflexos de empresa anterior
- Poucos investimentos
- Frota
- Empresas exclusivas WEG com marketing melhor
- Logística / rastreio
- Timer / ação / resposta rápida
- Força de venda
- Marketing

## Oportunidades

- Ser referência em solar na região
- Chegar nas pessoas mais simples
- Chegar nos investidores mais técnicos
- Ser mais sociável
- Clientes mais sólidos / indicação
- Ser mais ágil em resolução dos problemas

## Ameaças

- Concorrente com planos melhores
- Somos ameaça também pros concorrentes
- Concorrência desonesta
- Concorrência com falta de experiência
- Perder vendas pros concorrentes desleais

---

## Leitura LM (rápida)

**O que salta aos olhos:**

1. **Eles se enxergam técnicos, honestos, conservadores.** Esse é o DNA. Posicionamento da marca tem que reforçar isso, não fugir.
2. **Fraquezas se concentram em 3 blocos:** velocidade interna, força comercial/marketing e estrutura (frota, logística, planos). Os 2 primeiros a gente resolve com o Ignição. O 3º é responsabilidade do Flávio.
3. **"Medo da concorrência" + "concorrência desonesta"** aparecem nos dois lados. Tem ferida aberta com o mercado local. Útil pra construir narrativa de prospecção: "fugir de promessa fácil, ir no que é técnico".
4. **Oportunidade "chegar nos investidores mais técnicos"** casa exatamente com a tese B2B (Lorenzetti, Kallos, Boitanga). Esse é o caminho que vamos seguir.
5. **"Ser referência em solar na região"** = ambição declarada. Boa pra usar em campanha de autoridade no comercial.

**Pra usar no playbook:**

- Pitch de abertura comercial pode encaixar em "verdade, técnica, conservador". É território seguro pra eles falarem.
- Bloco de qualificação pode atacar "compra ágil de solução técnica" (oportunidade) vs. "promessa fácil do concorrente desleal" (ameaça).
- Treinamento interno: trabalhar a fraqueza "agilidade na resposta" com SLA de retorno (24h pra orçamento, X horas pra dúvida técnica).

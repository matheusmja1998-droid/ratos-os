---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
segmento: Padarias
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, padaria, mt]
---

# Benchmarking — Padarias (Pitch Solar Synergy)

> Pesquisa de mercado pra prospecção ativa de energia solar B2B em padarias e confeitarias na praça da Synergy.

---

## Contexto regional

- **Distribuidora:** Energisa MT. Reajuste em 01/04/2025.
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh.
- **Irradiação solar MT:** 5,2–5,6 kWh/m²/dia.
- **Tangará da Serra:** alto volume de padarias por causa do perfil familiar e da Unemat (universidade).

---

## Perfil de consumo

- **Padaria pequena (10h/dia, 1 forno, 1 câmara fria, 2 geladeiras de bebida):** 1.500–2.500 kWh/mês
- **Padaria média com confeitaria (2 fornos, fermentação climatizada, vitrines refrigeradas, ar no salão):** 3.000–6.000 kWh/mês
- **Padaria grande / panificadora industrial:** 6.000–15.000 kWh/mês
- **Potência contratada típica de padaria pequena: 13,8 kVA** (referência mercado)

## Conta de luz estimada (MT, tarifa B3)

- Pequena: **R$ 1.500–2.500/mês**
- Média: **R$ 3.000–6.000/mês**
- Grande: **R$ 6.000–15.000/mês**

## Ticket médio do sistema solar

**R$ 25–80 mil**

---

## Dor principal (linguagem do dono)

> "Forno fica ligado das 4 da manhã até as 9 da noite. Câmara fria 24h. Vitrines 18h. Ar condicionado no calor de MT mais 10h. Não tem como diminuir, é o negócio."

## Decisor

- Dono ou casal — negócio familiar
- **Caixa apertado, alta rotatividade, margem fina (5–10%)**
- Decisão envolve esposa(o)/filho que toca o financeiro
- Padeiro acorda 3h da manhã → **janela de ligação é 9h–11h ou 14h–16h**

---

## Ângulo de pitch

> "Você não pode desligar nada. Forno, câmara, vitrine, tudo precisa ficar ligado. Mas você pode trocar a Energisa pelo sol. Em 3 anos quita o sistema. Depois disso, você tira a Energisa do custo da broa pro resto da vida."

**Argumento de competitividade:** "Padaria que tem solar pode segurar preço do pão. Quem não tem, repassa toda alta de luz pro cliente, e o cliente vai pro mercado da esquina."

---

## Gatilhos de urgência

- **Reajuste Energisa anual**
- **Aumento da farinha/leite** (custo de insumo subindo) → "se a luz subir também você fica espremido"
- **Concorrente com solar** (Tangará tem casos)
- **Lojas grandes (Atacadão, Assaí)** entrando no nicho de pão → padaria precisa enxutar custo pra competir

---

## Volume na região

- **Estimativa: 80–130 padarias/confeitarias** na praça da Synergy
- **Tangará:** 60+ padarias
- **Diamantino + Sapezal + Nova Olímpia:** 30–50 padarias

## Sub-segmento ouro

**Padarias com confeitaria + restaurante (almoço executivo)** — conta de luz dobra (cozinha quente + freezer + ar do salão). Dono mais empresarial, ticket maior.

---

## Pontos de atenção

- Decisor é casado → **marcar visita com o casal junto**, não só com o dono operacional
- Padaria muitas vezes aluga ponto → validar contrato de aluguel longo (mín. 5 anos restantes)
- Margem fina exige financiamento bem desenhado
- Padeiro tem rotina apertada → ligação rápida e direta, sem rodeio

---

## Score pra prospecção

| Ticket médio | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|
| R$ 25–80 mil | Alto (80–130) | Rápido | ⭐⭐⭐⭐⭐ |

**Ranking: 🥈 2º** entre os 5 segmentos prioritários. **Volume + ticket razoável + decisão rápida do casal.**

---

**Fontes:**
- ANEEL Resolução 3.440 (Energisa MT)
- Sebrae DataMPE — Tangará da Serra
- Loja Luz (despesas de luz em padaria)
- Canal Solar / Portal Solar (cases comércio)
- Bulb Energia (consumo forno elétrico)

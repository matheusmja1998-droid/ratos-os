---
cliente: Synergy Soluções em Energia
programa: Ignição Comercial (L.M Agência)
segmento: Supermercados
regiao: Tangará da Serra, Diamantino, Sapezal, Nova Olímpia, Barra do Bugres (MT)
distribuidora: Energisa Mato Grosso (B3 baixa tensão)
criado: 2026-05-11
tags: [synergy, solar, prospeccao, benchmarking, supermercado, mt]
---

# Benchmarking — Supermercados (Pitch Solar Synergy)

> Pesquisa de mercado pra prospecção ativa de energia solar B2B em supermercados na praça da Synergy.

---

## Contexto regional

- **Distribuidora:** Energisa MT. Reajuste tarifário homologado pela ANEEL em 01/04/2025 (Resolução 3.440) — **+5,42% pra alta tensão** (comércio grande) e **+0,34% pra baixa tensão**. Comércio entra na **classe B3 baixa tensão**.
- **Tarifa comercial estimada (B3):** R$ 0,85–1,05/kWh com bandeiras e impostos.
- **Irradiação solar MT:** 5,2–5,6 kWh/m²/dia (top 3 do Brasil) → payback mais rápido que média nacional.
- **Tangará da Serra:** comércio + supermercados = **35% dos empregos**. Comércio varejista de supermercado emprega **1.298 pessoas** (3º maior empregador da cidade).
- **Sapezal + Diamantino:** PIB per capita R$ 254–257 mil (4x média estadual).

---

## Perfil de consumo

- **Mercado de bairro (1–3 checkouts):** câmara fria pequena 1.000–1.500 kWh/mês só na refrigeração
- **Supermercado médio (4–8 checkouts):** 8.000–15.000 kWh/mês totais
- **Supermercado grande:** 20.000–40.000 kWh/mês
- **Refrigeração representa 50–60% do consumo total**

## Conta de luz estimada (MT, tarifa B3)

- Mercado de bairro: **R$ 4.000–8.000/mês**
- Médio porte: **R$ 8.000–15.000/mês**
- Grande: **R$ 18.000–40.000/mês**

## Ticket médio do sistema solar

**R$ 60–200 mil**

---

## Dor principal (linguagem do dono)

> "A conta de luz é o segundo maior custo depois da folha. Subiu 7% esse ano e vai subir de novo. Margem do supermercado é 2–4%, qualquer aumento aperta."

## Decisor

- Dono (mercado familiar) ou sócio-administrador
- Decide sozinho na maioria dos casos
- Ticket alto pode envolver contador/financeiro
- Cooperativas têm decisão coletiva → ciclo mais longo

---

## Ângulo de pitch

> "Você gasta R$ X em luz por mês. 70% disso vai pra refrigeração que não pode desligar. Em 3 anos a Synergy paga seu sistema, depois disso são 22 anos de luz quase de graça. Em 25 anos isso é R$ Y de margem direta no caixa."

**Prova social:** **É o Bicho Pet Shop** (case real Synergy, ramo varejo com refrigeração) + **Lorenzetti** (mostra porte e seriedade).

---

## Gatilhos de urgência

- **Reajuste Energisa anual** (abril) → "antes do próximo aumento"
- **Bandeira tarifária vermelha** → acelera payback em 9%
- **Concorrência local:** mercado da esquina pondo solar pode baixar preço final do produto
- **Final do exercício fiscal:** investir em ativo antes do fechamento contábil

---

## Volume na região

- **Tangará:** 40–60 supermercados (3º maior empregador da cidade)
- **Diamantino + Sapezal + Nova Olímpia + Barra do Bugres:** 30–50 supermercados adicionais
- **Total endereçável: 70–110 supermercados na praça da Synergy**

## Sub-segmento ouro

Mercados de médio porte familiares (4–8 checkouts) com 5+ anos no mercado. Conta de luz alta o suficiente pra justificar sistema grande, decisor único, ciclo de venda mais curto que cooperativas.

---

## Pontos de atenção

- Telhado costuma ter ar condicionado, antena, exaustor → engenharia precisa validar área útil
- Alguns têm CNPJ pequeno mas conta de luz alta (3 lojas no mesmo CNPJ) → pré-qualificar pelo nº de checkouts
- Cooperativas (tipo Coopercaibé) têm processo de decisão coletivo → ciclo mais longo
- Margem do setor é baixa (2–4%) → investimento precisa ter financiamento bem desenhado

---

## Score pra prospecção

| Ticket médio | Volume na praça | Velocidade de decisão | Score |
|---|---|---|---|
| R$ 60–200 mil | Alto (70–110) | Médio | ⭐⭐⭐⭐⭐ |

**Ranking: 🥇 1º** entre os 5 segmentos prioritários.

---

**Fontes:**
- ANEEL Resolução 3.440 (Energisa MT, 01/04/2025)
- Sebrae DataMPE — Tangará da Serra, Sapezal, Diamantino
- ABSOLAR / Canal Solar / Portal Solar
- Bluesol / Neoenergia (cases de economia em comércio)
- Origo Energia (consumo câmara fria)

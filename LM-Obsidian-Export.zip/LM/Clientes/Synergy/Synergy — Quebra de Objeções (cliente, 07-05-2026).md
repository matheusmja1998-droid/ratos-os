---
data: 2026-05-07
tipo: material-cliente
origem: enviado pelo Flávio (documento interno Synergy)
cliente: Synergy
relacionado:
  - "[[Onboarding Synergy — Notas e Análise (07-05-2026)]]"
  - "[[Synergy — Análise SWOT (cliente, 07-05-2026)]]"
tags:
  - lm
  - synergy
  - objecoes
  - playbook
---

# Synergy — Quebra de Objeções (material do cliente)

Documento interno que o Flávio mandou. Lista 16 objeções clássicas de venda solar com resposta do vendedor + pergunta pra contornar. Insumo bruto do futuro playbook.

> **Nota:** copiei a estrutura como veio do cliente. Não corrigi os atalhos, ortografia ou formatação. Quando virar playbook a gente reescreve com tom comercial.

---

### 1. "Gostei da solução, mas vou deixar para outro momento"
- **Vendedor:** Gostaria de entender o motivo de você não aproveitar essa oportunidade neste momento.

### 2. "Eu preciso disso?"
- **Vendedor:** Você já parou para analisar quanto de dinheiro você está pagando para a Energisa?

### 3. "Já tenho energia solar"
- **Vendedor:** Está gerando corretamente? Você está fazendo manutenção anual obrigatória?

### 4. "Não conheço sua empresa"
- **Vendedor:** Apresentar a empresa, falar do número de clientes atendidos.

### 5. "Minha diretoria / esposa(o) não aprova a ideia"
- **Vendedor:** Vamos agendar uma reunião pra hoje, você tem disponibilidade pra conversarmos e apresentarmos os benefícios da empresa.
- **Pergunta pra contornar:** Quem decide sobre esse investimento está presente? É você que decide sobre esse investimento? Podemos agendar pra conversarmos juntos?

### 6. "Achei muito caro"
- **Vendedor:** Caro é você continuar pagando a conta para a Energisa que tem reajuste todo ano.
- **Pergunta pra contornar:** Estudar a proposta antes da negociação. Demonstrar a viabilidade financeira durante/no final da apresentação. Fazer cálculos de parcela, retorno, payback e perguntar se faz sentido pro cliente.

### 7. "Seu concorrente tem preço menor"
- **Vendedor:** Precisamos comparar as propostas pra verificar o que estão te oferecendo.
- **Pergunta pra contornar:** Mostrar vantagens, benefícios e qualidade de fechar com a Synergy. Mostrar fotos da instalação. Falar sobre resposta rápida no pós-venda.

### 8. "Preciso pensar a respeito"
- **Vendedor:** O que te impede de tomar essa decisão agora, aproveitar essa oportunidade?
- **Pergunta pra contornar:** Direcionar pra forma de pagamento.

### 9. "Será que vai gerar o que você está falando?"
- **Vendedor:** O seu projeto é personalizado e somos conservadores nos projetos, então vai gerar.
- **Pergunta pra contornar:** Apresentar o projeto se for proposta. Se for pré-orçamento, falar pro cliente que testamos o telhado antes de fechar negócio.

### 10. "Eu quero WEG, porque é o melhor do mundo"
- **Vendedor:** A WEG é conhecida no Brasil pela atuação em motores, mas temos outras marcas como SOLIS (maior fabricante de inversores do mundo, disputa com Huawei e Sungrow).
- **Pergunta pra contornar:** Falar brevemente sobre as marcas. Independente da marca, garantia no Brasil demora. Pós-venda depende da empresa que fechou o negócio. Falar da expertise pra acionar garantia. Empresa precisa ter inversor reserva.

### 11. "Mas aí eu vou pagar a taxa do sol. Não quero pagar a taxa"
- **Vendedor:** Essa taxa é apenas um custo pra utilização da rede que hoje é em torno de 13 centavos por kW utilizado.
- **Pergunta pra contornar:** Só se o cliente tocar no assunto.

### 12. "Vai baixar mais porque está baixando o dólar"
- **Vendedor:** O dólar está baixando, mas o incentivo/subsídio vai ser reduzido. Agora é o momento certo pra aproveitar a oportunidade.
- **Pergunta pra contornar:** Só se o cliente tocar no assunto.

### 13. "O financiamento está muito caro"
- **Vendedor:** Tô te oferecendo uma solução de investimento sem entrada, pra começar a pagar em até 120 dias e você vai começar economizando.
- **Pergunta pra contornar:** Buscar a melhor condição de parcelamento. Fazer a matemática sobre a fatura de energia. Cliente não vai se descapitalizar, vai usar o dinheiro do banco.

### 14. "Desculpe, mas estou sem tempo"
- **Vendedor:** Me dá 10 minutos do seu tempo hoje que eu te apresento a proposta e depois eu cuido do resto.
- **Pergunta pra contornar:** Antecipar visita pessoal. Forçar atendimento presencial. Falar que pode atender em qualquer horário, inclusive fim de semana.

### 15. "Vou gastar muito com custos adicionais"
- **Vendedor:** As únicas despesas que não estão inclusas no orçamento são adequação ou troca do padrão, cobertura do inversor (se necessário) e custo de interligação caso o inversor fique muito longe do padrão.
- **Pergunta pra contornar:** Cada vendedor tem sua estratégia.

### 16. "Envia esse projeto pelo WhatsApp pra mim"
- **Vendedor:** O projeto é propriedade intelectual da empresa. Nossa política é só enviar depois de fechado o negócio, porque já envolveu toda a nossa experiência em sistema solar.
- **Pergunta pra contornar:** Cada vendedor tem sua estratégia.

---

## Leitura LM (rápida)

**Qualidade do material:**

- Cobre as **objeções clássicas do solar B2C residencial**. Tá bom como ponto de partida.
- **Falta o B2B inteiro.** Nada sobre payback empresarial, fluxo de caixa pra PJ, dedução fiscal, conta industrial, demanda contratada, locação de telhado. Esse é o gap principal pro Ignição (foco comercial).
- Algumas respostas estão fracas ("cada vendedor tem sua estratégia" não é resposta, é fuga).
- **Estrutura mistura "resposta do vendedor" com "pergunta pra contornar"** — confuso. Playbook bom separa: gancho → pergunta de qualificação → reforço técnico → fechamento.

**O que aproveitar pro playbook final:**

1. As 16 objeções como base, mais 6-8 novas pro B2B (financiamento empresarial, payback corporativo, depreciação, conta de demanda, etc).
2. Estrutura nova: cada objeção com 3 camadas — *resposta curta de bater bola*, *pergunta de redirecionamento*, *prova/dado pra reforçar*.
3. Decisor empresarial precisa de seção própria (objeção 5 fala disso mas no script residencial).
4. Adicionar objeções específicas dos cases que eles já venderam: Lorenzetti, Kallos, Boitanga, É o Bicho.

**Pro lado da prospecção (curto prazo):**

- Objeções 1, 4, 8 e 14 vão aparecer em quase toda ligação fria. Vale tirar essas 4 e fazer um *cheat sheet* de 1 página antes da reunião de terça pra rodar com o time já na primeira semana.
- Objeção 4 ("não conheço sua empresa") é onde o SWOT entra: técnica, conservador, qualidade na instalação, 6 anos de mercado, casos. A resposta do material atual ("apresentar a empresa") é genérica demais.

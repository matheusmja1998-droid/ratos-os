---
cliente: Dr. Fábio Freire
empresa: Clínica IOT — Instituto de Ortopedia e Traumatologia
segmento: Saúde / Ortopedia
cidade: Varginha/MG
status: ativo
projeto: Marca pessoal + Google Ads
tipo: onboarding-alinhamento
tags: [cliente, lm, saúde, ortopedia, google-ads, marca-pessoal, reputação]
atualizado: 2026-04-12
---

# Dr. Fábio — IOT (Varginha)

## Contexto
Ortopedista com boa reputação clínica em Varginha/MG. Já tem Instagram ativo, Doctoralia forte e Google Meu Negócio, mas presença digital fragmentada. Objetivo central: aumentar pacientes particulares e, principalmente, cirurgias particulares.

**Dor emocional principal:** avaliações negativas em destaque no Google distorcem percepção pública apesar de maioria esmagadora de reviews positivos.

---

## Objetivo Real
Não é encher agenda — é **melhorar a composição da agenda**: migrar de convênio para particular, onde há mais margem e mais controle. Além disso, fortalecer marca pessoal para ser buscado diretamente pelo nome.

---

## Diagnóstico

### O que existe hoje
- Doctoralia muito forte, alto volume de avaliações positivas
- Instagram ativo com produção de conteúdo em andamento
- Google Meu Negócio presente, mas frágil por destaque de avaliações negativas
- Sem site proprietário — dependência total de plataformas de terceiros
- Baixa dominância em buscas genéricas ("ortopedista em Varginha")

### Lacunas identificadas
- Nenhum ativo proprietário para ranqueamento orgânico
- Doctoralia não migra avaliações para o Google automaticamente
- Tráfego e conteúdo não conversam — custo de aquisição sobe sem necessidade
- Sem processo de pedido de avaliações no Google — pool positivo cresce devagar

---

## Estratégia Proposta — 5 Pilares

| Pilar | Objetivo |
|---|---|
| Google (busca + marca) | Capturar intenção local e defender nome do médico |
| Meta | Despertar interesse e ampliar alcance da autoridade |
| Site institucional | Ranquear, defender marca, organizar prova, converter |
| Gestão de reputação | Diluir peso de avaliações negativas com volume positivo |
| Conteúdo orgânico | Baratear aquisição e reforçar autoridade |

---

## Verba e Viabilidade
- Verba mensal de mídia estimada: **~R$ 2.000**
- Ticket de paciente particular + cirurgia é relevante → não precisa de volume absurdo para pagar o projeto
- Entrada racional: começar por canais de maior resposta (Google) antes de escalar Meta

---

## Riscos
- Sem site: continua dependente de terceiros, ranqueamento fraco
- Sem processo de reputação: Google segue destacando negativas
- Tráfego sem conteúdo alinhado = CAC alto desnecessariamente
- Competição local pode avançar antes do projeto entrar no ar

---

## Próximos Passos
- [ ] Criar site institucional com foco em marca pessoal e conversão
- [ ] Estruturar campanha de marca + busca por especialidades/cidade
- [ ] Implementar rotina de pedido de avaliações no Google
- [ ] Alinhar produção de conteúdo social com temas de maior intenção

---

**Ver também:** [[Dr. Fábio — Comtato (Google Ads)]] | [[Índice — Reuniões de Vendas LM]]

---

**Hub:** [[LM — Visão Geral|L.M Agência]]

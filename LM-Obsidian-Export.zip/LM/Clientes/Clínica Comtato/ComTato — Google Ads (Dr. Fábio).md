---
cliente: Dr. Fábio Freire
empresa: Clínica IOT — Instituto de Ortopedia e Traumatologia
projeto: Comtato — Google Ads
cidade: Varginha/MG
status: ativo
tipo: onboarding-alinhamento
tags: [cliente, lm, google-ads, mídia-paga, saúde, política-google]
atualizado: 2026-04-12
---

# Dr. Fábio — (Google Ads)

## O que é
Frente tática e operacional da estratégia digital do Dr. Fábio. Enquanto [[Dr. Fábio — IOT (Varginha)]] trata da estratégia completa, o Comtato foca a **execução da mídia paga**: estrutura de campanhas, palavras-chave, anúncios e segurança de política no Google.

**Objetivo:** gerar ligações, cliques para WhatsApp e agendamentos qualificados na região de Varginha/MG sem cair em bloqueios de política de saúde do Google.

---

## Arquitetura de Campanhas

| Campanha | Função | Observação |
|---|---|---|
| Pesquisa — Especialidades / Cidade | Capturar procura ativa | Grupos: ortopedista em Varginha, consulta ortopédica, especialista em joelho/coluna |
| Pesquisa — Marca | Defender nome e intenção quente | Dr. Fábio Freire, Clínica IOT, variações |
| Expansão futura | Ganhar volume com cautela | Só ativar após base aprovada, convertendo e com aprendizado suficiente |

---

## Palavras-Chave

**Núcleo seguro:**
- ortopedista em Varginha
- consulta ortopédica
- especialista em joelho / coluna
- traumatologista esportivo

**Marca:**
- Dr. Fábio Freire
- Clínica IOT
- Instituto de Ortopedia e Traumatologia

**Evitar:** termos excessivamente clínicos, promessas de resultado médico, descrições de condições sensíveis — risco de reprovação de conta.

---

## Racional Criativo dos Anúncios
- Títulos descritivos > promessas fortes (política de saúde)
- Autoridade via especialidade, nome do profissional e estrutura clínica
- Sitelinks: especialidades, localização, institucional, formas de contato
- Lógica de confiança, não de exagero

---

## Segurança de Política
Projeto mais sensível que operação genérica. Toda modelagem prioriza a **zona mais estável das políticas do Google Ads para saúde**:
- Começar limpo, simples, bem segmentado
- Páginas de destino, extensões e textos do site precisam seguir a mesma lógica
- Não adianta anúncio seguro se a landing aciona problemas

---

## Métricas de Sucesso

| Métrica | O que avalia |
|---|---|
| CTR | Aderência entre anúncio e busca |
| CPC / CPL | Eficiência de mídia |
| Ligações + cliques WhatsApp | Contatos práticos gerados |
| Qualidade do lead | Avaliação pela clínica, não só quantidade |
| Buscas de marca | Crescimento de presença ao longo do tempo |

---

## Fase Atual e Próximos Passos
- [ ] Finalizar estrutura de campanhas com grupos enxutos e coerentes
- [ ] Subir anúncios e extensões adaptados à política de saúde
- [ ] Garantir que WhatsApp e pontos de contato estejam prontos para receber demanda
- [ ] Implementar rastreamento de chamadas, cliques e formulários
- [ ] Rodar fase inicial de aprendizado **antes de qualquer expansão**

---

**Ver também:** [[Dr. Fábio — IOT (Varginha)]] | [[Índice — Reuniões de Vendas LM]]

**Hub:** [[LM — Visão Geral|L.M Agência]]

# Pediabilitare

**Perfil:** https://www.instagram.com/pediabilitare/

## Top 10 Reels Virais

1. https://www.instagram.com/pediabilitare/reel/ClCPeUIOo0i/
2. https://www.instagram.com/pediabilitare/reel/CjqjGOYDcGW/
3. https://www.instagram.com/pediabilitare/reel/CivFAFzvhrw/
4. https://www.instagram.com/pediabilitare/reel/C3p27QXOStE/
5. https://www.instagram.com/pediabilitare/reel/DWhtlJckdwA/
6. https://www.instagram.com/pediabilitare/reel/CfpsKByjZXO/
7. https://www.instagram.com/pediabilitare/reel/Ci2uoOBuGOd/
8. https://www.instagram.com/pediabilitare/reel/CkN4Kn6rLMU/
9. https://www.instagram.com/pediabilitare/reel/Cpxe2bnA7Kx/
10. https://www.instagram.com/pediabilitare/reel/DMLsihURnzV/

---

**Análise correspondente:** [[01-pediabilitare/analise|analise]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

# Pediabilitare — Análise dos 10 Reels Virais

**Perfil:** https://www.instagram.com/pediabilitare/
**Posicionamento:** Instituto de Reabilitação Pediátrica Integrativa. Falam direto pra **mãe** (não pra pediatra). Linha didática, tom acolhedor, terapeuta na frente da câmera (Gabi).

---

## Análise vídeo a vídeo

### 1. ClCPeUIOo0i — "Pedido de casamento" (música Taylor Swift "Love Story")
**Sem fala — só música.** Trend de Reel romântico, provavelmente cena de uma terapeuta da clínica. Viralizou pelo **lado humano** da equipe, fora do tema clínico.
**Aprendizado:** humanização da equipe gera alcance fora da bolha de mães.

### 2. CjqjGOYDcGW — "Por que NÃO usar esse andador"
> "Eu sou a Gabi e vem comigo que eu vou te contar porque você não deve usar nunca esse tipo de andador. Esse modelo é proibido pela Sociedade Brasileira de Pediatria…"

**Formato:** talking head, terapeuta no enquadramento, gancho negativo ("nunca").
**Por que viralizou:**
- Gancho de **alerta** ("não use") + **autoridade institucional** (cita SBP)
- **Dor concreta da mãe:** medo de estar usando produto que prejudica o filho
- Entrega resposta prática (qual modelo trocar)
- CTA simples no final
**Padrão replicável:** "produto comum que tá prejudicando teu filho + alternativa segura"

### 3. CivFAFzvhrw — "Como posicionar a criança na alimentação"
> "Como posicionar a criança na hora da alimentação? Primeiro, você pode usar um banco onde os pés da criança fiquem apoiados…"

**Formato:** tutorial passo a passo, voz off + demonstração visual.
**Por que viralizou:**
- **Gancho-pergunta** que toda mãe se faz na hora do almoço
- Solução prática, executável no mesmo dia
- Conteúdo "save-worthy" (mãe salva pra revisitar)
**Padrão:** tutorial de problema cotidiano + 4-5 passos visuais

### 4. C3p27QXOStE — SEM ÁUDIO
Reel de imagem/cena curta, possivelmente trend visual. Não há fala pra analisar.

### 5. DWhtlJckdwA — "Esta é a clínica da minha mãe e da Gabi" (10 anos da clínica)
> "Essa é a clínica da minha mãe e da Gabi, ela trabalha com crianças. Elas põem desquentes nessa gaiola…"

**Formato:** **filhas das donas tour pela clínica**, narração infantil ingênua e engraçada (chamam aparelhos de "gaiola", "treco que sobe"). Aniversário de 10 anos.
**Por que viralizou:**
- Gimmick das **gêmeas** + **olhar de criança** sobre clínica adulta
- Documentação humanizada do espaço (não é venda)
- Marketing de aniversário travestido de conteúdo fofo
**Padrão:** documentação institucional pela ótica de quem mora ali

### 6. CfpsKByjZXO — Música em inglês, sem fala estruturada
Trend musical. Provavelmente carrossel/transição.

### 7. Ci2uoOBuGOd — "Como estimular autonomia na alimentação"
> "Um ponto muito importante desse processo é que pelo menos uma refeição no dia seja feita na mesa junto com os familiares…"

**Formato:** voz off + B-roll de criança comendo. 5 dicas práticas.
**Por que viralizou:**
- **Mesmo padrão do reel 3** (tutorial de alimentação infantil)
- Clínica claramente identificou que "alimentação infantil" é o **tema-imã** delas
- Linguagem aprofundada mas acessível ("coordenação motora dos dedinhos")
**Padrão:** repetir o nicho que já performa, com ângulos diferentes

### 8. CkN4Kn6rLMU — "Let's go!" (sem fala estruturada)
Trend ou abertura curta. Sem material pra análise textual.

### 9. Cpxe2bnA7Kx — Sem fala
Trend musical/visual.

### 10. DMLsihURnzV — "Eu me enxerguei no Búlgaro" (trend)
**Trend de áudio viral.** Sem conteúdo educacional. Aposta em alcance de áudio em alta.

---

## Padrão geral do Pediabilitare

**O que viraliza:**
- **5 dos 10 são puramente trends/música** sem conteúdo educacional → eles surfam audio viral pra alcance
- **3 são tutoriais** (alimentação x2, andador x1) → todos com gancho de **dor cotidiana da mãe**
- **2 são institucionais humanizados** (gêmeas tour, casamento)

**Tema-imã identificado:** **alimentação infantil** (2 dos 3 educacionais). É a janela onde eles se posicionam como autoridade.

**Estilo de abertura preferido:**
- "Como [verbo + dor]?" (pergunta direta)
- "Eu sou a [nome] e vem comigo…"
- "Você não deve usar nunca…" (proibição)

**Frequência de talking head:** baixa. A maioria é voz off + B-roll. Apenas 1 dos 3 educacionais usa rosto da terapeuta.

---

**Perfil correspondente:** [[01-pediabilitare/perfil|perfil]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

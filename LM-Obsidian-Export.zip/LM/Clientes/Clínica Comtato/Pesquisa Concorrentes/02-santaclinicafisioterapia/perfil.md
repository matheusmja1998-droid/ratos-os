# Santa Clínica Fisioterapia

**Perfil:** https://www.instagram.com/santaclinicafisioterapia/

## Top 10 Reels Virais

1. https://www.instagram.com/santaclinicafisioterapia/reel/CslxkvRAB1t/
2. https://www.instagram.com/santaclinicafisioterapia/reel/CsSB0SLgHwj/
3. https://www.instagram.com/santaclinicafisioterapia/reel/DWUvw-EifR-/
4. https://www.instagram.com/santaclinicafisioterapia/reel/CrlTYIdAhfg/
5. https://www.instagram.com/santaclinicafisioterapia/reel/Cdo8LhVjCgD/
6. https://www.instagram.com/santaclinicafisioterapia/reel/DUGCyf3kXT-/
7. https://www.instagram.com/santaclinicafisioterapia/reel/CqYvUUSAQxI/
8. https://www.instagram.com/santaclinicafisioterapia/reel/CTPSszngDss/
9. https://www.instagram.com/santaclinicafisioterapia/reel/Cmh4Uk5KJaU/
10. https://www.instagram.com/santaclinicafisioterapia/reel/DOrsopHDCCI/

---

**Análise correspondente:** [[02-santaclinicafisioterapia/analise|analise]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

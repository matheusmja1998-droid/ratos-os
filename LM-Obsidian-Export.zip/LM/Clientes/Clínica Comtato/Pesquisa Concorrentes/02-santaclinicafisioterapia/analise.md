# Santa Clínica Fisioterapia — Análise dos 10 Reels Virais

**Perfil:** https://www.instagram.com/santaclinicafisioterapia/
**Posicionamento:** Clínica multidisciplinar focada em **reabilitação infantil** (capacete de plagiocefalia, neuroreabilitação de síndromes raras, hidroterapia). Foco em **prova social pesada** — depoimentos longos de pais.

---

## Análise vídeo a vídeo

### 1. CslxkvRAB1t — "Funk do patinho" (música infantil, sem fala)
> "Dança o funk do patinho / Verde, azul, amarelinho / Mão pra cima, acenando…"

**Trend infantil viral.** Provavelmente terapeutas dançando com crianças.
**Por que viralizou:** áudio de música infantil em alta + ambiente terapêutico → gera "é aqui que meu filho ia se divertir tratando".

### 2. CsSB0SLgHwj — Sem fala estruturada
Reel musical.

### 3. DWUvw-EifR- — **Depoimento completo da mãe do Lorenzo (capacete)**
> "Meu nome é Shwetiane, sou a mãe do Lorenzo, ele tem um ano e cinco meses. Fiquei hospitada porque eu não sabia como seria o tratamento do dedo. Quando eu vim fazer a avaliação, no começo eu fiquei com medo… A cabecinha toca nunca mais!"

**Formato:** depoimento puro de mãe, 2-3min, com B-roll do bebê de capacete e do antes/depois.
**Por que viralizou:**
- **Prova social específica** (capacete craniano = nicho com mãe perdida buscando solução)
- **Antes/depois físico** — mostra resultado visível
- Mãe quebra **objeções comuns** dentro do depoimento ("ficou com medo", "achou que ia machucar", "preocupada com escola")
**Padrão:** prova social que **mata as 3 objeções principais** dentro do mesmo vídeo

### 4. CrlTYIdAhfg — SEM ÁUDIO

### 5. Cdo8LhVjCgD — SEM ÁUDIO

### 6. DUGCyf3kXT- — **Depoimento longo dos pais do Benjamin (síndrome de Pfeiffer / atrofia cerebral)**
> "Sou a Magliane, mãe Benjamin… O Benjamin teve uma lesão imune aos 8 meses, atrofia cerebral… Aqui na Santa Clínica foi bem diferente das outras clínicas que a gente procurou…"

**Formato:** depoimento ainda mais longo (~3-4min), pai e mãe juntos.
**Por que viralizou:**
- **Caso emocional pesado** (criança com síndrome rara, evolução visível)
- **Comparação explícita** com outras clínicas ("foi a primeira que mostrou o que precisávamos")
- Lista evoluções concretas: bicicleta, esteira, hidroterapia, comandos
- **Elogio nominal à proprietária Bruna** — humaniza a marca pessoal por trás da clínica
**Padrão:** depoimento em formato "antes da clínica vs. depois", listando ganhos concretos e nominal

### 7. CqYvUUSAQxI — Trend musical (sem fala estruturada)

### 8. CTPSszngDss — "MÚSICA"
Sem fala — só trend.

### 9. Cmh4Uk5KJaU — **Vazio (sem áudio detectável)**
Pode ser reel só visual.

### 10. DOrsopHDCCI — Música "Hawaiian Roller Coaster Ride" (Lilo & Stitch)
Trend de música infantil.

---

## Padrão geral da Santa Clínica

**O que viraliza:**
- **2 depoimentos longos de pais** = os reels com **maior densidade de conteúdo** (e provavelmente os mais convertem em consulta)
- **6+ trends musicais** com terapeutas + crianças → estratégia clara de **alcance via áudio viral**
- Quase zero conteúdo educacional

**Diferenças vs. Pediabilitare:**
- Santa Clínica **aposta em prova social** (depoimento)
- Pediabilitare aposta em **tutorial educacional**
- Os dois usam trends musicais como ferramenta de alcance

**Estilo de depoimento:**
- Longo (2-4min) — não tenta caber em 60s
- Mãe e pai juntos quando possível
- Caso clínico **específico e nominal** (Lorenzo do capacete, Benjamin da síndrome)
- B-roll do antes/depois junto com o áudio do depoimento

**Tema-imã identificado:** **reabilitação infantil de casos complexos** (capacete craniano, síndromes neurológicas raras). A clínica vira "última esperança" pra mãe que já tentou outros lugares.

---

**Perfil correspondente:** [[02-santaclinicafisioterapia/perfil|perfil]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

# Plano Tático 30 Dias — Conteúdo Comtato
## Baseado na pesquisa de concorrentes (5 perfis, 50 reels analisados)

**Objetivo macro:** crescer alcance 2x em 30 dias, atingir 1 reel com 50k+ views nos primeiros 60 dias, gerar 5+ DMs/semana de mães interessadas.

**Posicionamento sugerido pra liderar a comunicação:** **ansiedade infantil 5-12 anos** (janela aberta — nenhum dos 5 concorrentes ocupa esse espaço com profundidade).

---

## Pilares de conteúdo (3 pilares, frequência semanal)

### Pilar 1 — EDUCACIONAL (1 reel/semana)
**Modelo:** Pediabilitare — voz off + B-roll demonstrativo + dor concreta da mãe + resposta prática.

**Estrutura padrão:**
- **Gancho 0-3s:** pergunta-dor ou alerta ("Por que NÃO castigar quando…", "Como acalmar a criança quando…")
- **Desenvolvimento 3-40s:** explicação em 3-5 passos, voz off + B-roll
- **Fechamento 40-50s:** frase de autoridade + CTA leve (curtir, salvar, seguir)

**Não usar:** talking head puro, jargão técnico, frases longas sem ritmo.

### Pilar 2 — TREND MUSICAL (2 reels/semana)
**Modelo:** NeuroReab — B-roll da clínica sobreposto a áudio em alta.

**Banco mínimo de B-rolls a gravar antes de começar:**
- Sala de atendimento vazia (recepção da luz natural)
- Sofá da terapia em close
- Brinquedos sendo organizados
- Caderno terapêutico sendo aberto/fechado
- Plantas, jardim, ambiente externo
- Recepção (com pessoa atrás vista de costas)
- Terapeuta caminhando pelo corredor (pés ou silhueta)
- Mão escrevendo
- Detalhe de objetos do espaço (vela, livro, almofada)
- Timelapse de luz natural mudando ao longo do dia

**Banco de áudios — mapear semanalmente:**
- 5 áudios infantis em alta (música, brincadeira)
- 5 áudios emocionais (música pop nacional/internacional sobre cuidado, superação)
- 3-5 áudios cristãos (se posicionamento da Comtato permitir — confirmar com cliente)
- 5 áudios virais "do momento" (reels do feed, trends de dança, áudios cômicos)

### Pilar 3 — INSTITUCIONAL/FRICÇÃO (1 reel/quinzena)
**Modelo:** Dea Clínica — voz off institucional sobre detalhe operacional que vira diferencial.

**5 ângulos pra explorar (cliente confirma quais existem):**
1. Sala de espera com brinquedo enquanto a mãe é atendida
2. Recepção que sabe o nome da criança quando chega
3. Estacionamento/localização fácil
4. Horários flexíveis pra mãe que trabalha
5. Sigilo absoluto (mostrar bastidor — caderno trancado, sala isolada, sem expor nada)

---

## Cronograma Semana a Semana

### Semana 1 — Setup e produção de banco

**Segunda:**
- [ ] Reunião com a clínica: validar posicionamento (ansiedade infantil 5-12 anos OK?), confirmar 1 terapeuta-rosto da marca
- [ ] Listar 10 dores concretas da mãe de criança ansiosa (briefing)

**Terça-Quarta:**
- [ ] Sessão de gravação na clínica (1h–2h):
  - 10 B-rolls listados acima
  - 5 frases-âncora da terapeuta (talking head curtos, pra encaixar em qualquer reel)
  - 1 tour humanizado pelo espaço (estilo Pediabilitare reel 5, pelas mãos da equipe)

**Quinta:**
- [ ] Roteirar **5 tutoriais educacionais** (1 por semana × 5 semanas):
  1. "Como acalmar a criança em crise de ansiedade na escola"
  2. "Por que NÃO dizer 'isso é bobagem' quando seu filho tá ansioso"
  3. "3 sinais de que seu filho precisa de terapia (e não é só birra)"
  4. "Como diferenciar TDAH de ansiedade — e por que importa"
  5. "O que fazer no domingo à noite quando a criança chora pra não ir pra escola"
- [ ] Roteirar **3 reels institucionais** (1 a cada 2 semanas):
  1. Sigilo na clínica
  2. Sala de espera acolhedora
  3. Equipe que se reúne pra discutir cada caso (supervisão clínica)

**Sexta:**
- [ ] Mapear **20 áudios em alta** pra usar nos próximos 14 dias
- [ ] Listar **modelo de autorização LGPD** pra abordar 3-5 pacientes para depoimento

### Semana 2 — Início da operação

**Cronograma de postagem:**
- **Terça:** Trend musical 1 (B-roll + áudio emocional)
- **Quinta:** Tutorial educacional 1 ("Como acalmar a criança em crise de ansiedade na escola")
- **Sábado:** Trend musical 2 (B-roll + áudio infantil)

**Em paralelo:**
- [ ] Abordar 1 paciente/responsável pra gravação de depoimento (com LGPD)
- [ ] Análise diária dos primeiros reels (qual gancho engajou mais)

### Semana 3 — Adicionar institucional + iniciar depoimento

**Cronograma:**
- **Terça:** Trend musical 3
- **Quinta:** Tutorial educacional 2 ("Por que NÃO dizer 'isso é bobagem'")
- **Sábado:** Reel institucional 1 (Sigilo na clínica)

**Em paralelo:**
- [ ] Gravar primeiro depoimento (modelo Santa Clínica: 2-4min, mãe falando, B-roll do ambiente, sem expor paciente)
- [ ] Editar depoimento — formato: áudio do testemunho + B-roll do espaço + legenda destacando frases-chave

### Semana 4 — Lançar primeiro depoimento + medir

**Cronograma:**
- **Terça:** **Depoimento longo (3-4min)** — formato Santa Clínica reel 6 (Benjamin)
- **Quinta:** Tutorial educacional 3 ("3 sinais de que seu filho precisa de terapia")
- **Sábado:** Trend musical 4

**Reunião de fechamento do mês:**
- [ ] Análise de métricas dos 12+ reels postados
- [ ] Identificar top 3 reels (alcance, salvamento, DM)
- [ ] Plano semana 5-8 com base no que performou

---

## Tabela de tracking diário

| Reel | Data | Pilar | Gancho usado | Views (7d) | Salvamentos | DMs gerados | Conversão (consulta) |
|---|---|---|---|---|---|---|---|
| #1 | | Trend | | | | | |
| #2 | | Educacional | | | | | |
| ... | | | | | | | |

**Salvar tabela em planilha viva** (Google Sheets) pra cliente acompanhar.

---

## Métricas de sucesso

**30 dias:**
- 12 reels postados sem falha de cronograma
- Alcance mensal 2x do baseline atual
- 1 reel com >20k views
- 3-5 DMs novas/semana de potenciais pacientes
- 1 depoimento gravado e publicado

**60 dias:**
- 24 reels postados
- 1 reel com >50k views
- 1 reel viral (>100k views) — possível com trend bem encaixado
- 5-10 DMs/semana
- 2+ pacientes novos diretamente atribuídos a reels

**90 dias:**
- Banco de 5+ depoimentos publicados
- Posicionamento "Comtato = ansiedade infantil em [cidade]" começando a colar
- Início de tráfego pago em cima dos reels que mais converteram organicamente

---

## Ferramentas de produção sugeridas

- **CapCut** — edição rápida de reels com legendas automáticas
- **InShot** — alternativa simples
- **Metricool** — agendamento + análise
- **Trello/Notion** — calendário editorial
- **iPhone recente** — câmera (não precisa equipamento profissional pra esse formato)

---

## Bloqueios prováveis (e como resolver)

| Bloqueio | Solução |
|---|---|
| "Terapeuta não quer aparecer" | Voz off + B-roll resolve 80% dos reels educacionais. Talking head é opcional. |
| "Sigilo me impede de gravar paciente" | Depoimento da mãe (não do paciente menor), B-roll do ambiente sem rosto, leitura de carta anônima |
| "Demora pra produzir 4 reels/semana" | Bloco de gravação 1x/mês = 16 reels. Editar 4 por semana. |
| "Mãe paciente não quer dar depoimento" | Começar com adultos (burnout) que aceitam mais facilmente. |
| "Não sei o que falar tecnicamente" | Banco de 50 perguntas frequentes = 50 reels educacionais ano todo |
| "Trend muda muito rápido" | Mapear 1x/semana, manter 5 áudios "atemporais" reservados pra uso a qualquer hora |

---

## Próxima ação (essa semana)

1. **Aprovar este plano com a clínica** (quem decide o quê, quem aparece, posicionamento confirmado)
2. **Agendar a sessão de gravação inicial** (banco de B-rolls + 5 frases-âncora)
3. **Receber autorização LGPD redigida** pra começar a abordar pacientes pra depoimento
4. **Definir 1 ponto focal na clínica** que aprova roteiros em até 24h (sem isso, cronograma trava)

---

**Ver também:** [[Pesquisa Concorrentes — Clínica Contato]] | [[INSIGHTS-GERAIS]] | [[Clínica Contato — Dossiê]]

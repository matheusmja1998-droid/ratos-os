---
cliente: Clínica Contato
agencia: LM
tipo: índice-pesquisa
atualizado: 2026-05-05
---

# Pesquisa Concorrentes — Clínica Contato

Mapeamento de 5 concorrentes da Clínica Contato no Instagram. 50 reels analisados (10 por perfil), 46 transcritos com sucesso.

## Saídas consolidadas

- [[INSIGHTS-GERAIS]] — leitura do que tá funcionando no nicho
- [[PLANO-30-DIAS]] — plano tático aplicando os insights

## Concorrentes mapeados

| # | Concorrente | Perfil | Análise |
|---|---|---|---|
| 1 | Pediabilitare | [[01-pediabilitare/perfil\|perfil]] | [[01-pediabilitare/analise\|analise]] |
| 2 | Santa Clínica Fisioterapia | [[02-santaclinicafisioterapia/perfil\|perfil]] | [[02-santaclinicafisioterapia/analise\|analise]] |
| 3 | Dea Clínica (Especialmente) | [[03-deaclinica/perfil\|perfil]] | [[03-deaclinica/analise\|analise]] |
| 4 | NeuroReab Clínica | [[04-neuroreabclinica/perfil\|perfil]] | [[04-neuroreabclinica/analise\|analise]] |
| 5 | Clínica Integrada Pipa | [[05-clinicaintegradapipa/perfil\|perfil]] | [[05-clinicaintegradapipa/analise\|analise]] |

## Ver também

- [[Clínica Contato — Dossiê]] — hub do cliente
- [[LM — Visão Geral|L.M Agência]]

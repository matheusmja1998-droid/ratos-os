# Pesquisa de Concorrentes — Insights Gerais
## Clínica Comtato — L.M Agência

**Base:** 50 reels analisados (10 por concorrente). 46 transcritos com sucesso, 4 sem áudio.

---

## Os 5 concorrentes mapeados

| # | Concorrente | Posicionamento | Volume top reel | Estratégia dominante |
|---|---|---|---|---|
| 1 | **Pediabilitare** | Reabilitação pediátrica integrativa | (sem dado) | Tutorial educacional + trends |
| 2 | **Santa Clínica Fisioterapia** | Reabilitação infantil de casos complexos | (sem dado) | Depoimento longo + trends |
| 3 | **Dea Clínica (Especialmente)** | Multidisciplinar com foco em experiência | (sem dado) | Estética + posicionamento de marca |
| 4 | **NeuroReab Clínica** | Reabilitação neurológica infantil | **505k views** | Cena real de sessão + música emocional |
| 5 | **Clínica Integrada Pipa** | Multidisciplinar + mentoria B2B | 46k views | Talking head autoridade + trends |

---

## Insight #1 — A maioria do top 10 desses concorrentes é TREND MUSICAL, não conteúdo educacional

**Dado bruto:** dos 46 reels transcritos com áudio, **mais da metade não tem fala estruturada** — são trends de áudio sobreposto a B-roll.

**Implicação:** o algoritmo do Instagram favorece conteúdo que usa áudio em alta. Conteúdo educacional bem feito viraliza, mas é exceção. A maior parte do alcance vem de **surfar trends musicais com B-roll da clínica**.

**Aplicação pra Comtato:**
- Não tente competir só com tutorial educacional
- Crie um **banco de B-rolls da clínica** (ambiente, plantas, sofá, brinquedos, jardim, recepção, terapeuta caminhando, escrevendo no caderno) que possa ser sobreposto a qualquer trend
- Toda semana, identificar 2-3 áudios em alta e gerar reels com esse banco de B-rolls
- Frequência sugerida: **1 reel educacional + 2 reels com trend musical por semana**

---

## Insight #2 — O conteúdo educacional que viraliza tem DOR ESPECÍFICA + RESPOSTA PRÁTICA

Os tutoriais que viralizaram seguem **mesma estrutura**:
- **Gancho-dor:** "Por que NÃO usar esse andador" / "Como posicionar a criança na alimentação"
- **Voz off explicativa** (não talking head)
- **B-roll demonstrativo** (não terapeuta apenas falando pra câmera)
- **Resposta prática executável no mesmo dia**
- **CTA leve no final** (curtir, salvar, seguir — não consulta)

**Padrões de gancho que funcionaram:**
- "Por que NÃO + [coisa que mãe usa]" — alerta
- "Como [verbo + dor cotidiana]" — tutorial
- "[Especialidade pouco conhecida] + [definição com slogan próprio]" — autoridade

**Aplicação pra Comtato:**
- Listar **5 mitos/erros mais comuns** sobre saúde mental infantil → vira 5 reels do tipo "Por que NÃO castigar quando a criança…"
- Listar **5 dores cotidianas** que mãe enfrenta com criança ansiosa/birrenta/escolar → vira 5 reels "Como acalmar a criança quando…"
- **Aposte em voz off + B-roll** (não talking head puro). Mostra o setting, a sala, o brinquedo — não exige rosto exposto.

---

## Insight #3 — Depoimento de mãe é o conteúdo de MAIOR conversão (e o mais subutilizado)

A Santa Clínica é a única dos 5 que aposta **forte em depoimento longo de pais**. Os depoimentos têm 2-4 minutos, são caso clínico nominal (Lorenzo do capacete, Benjamin da síndrome de Pfeiffer), e listam evolução concreta.

**Por que funciona:**
- Mãe que ainda não procurou ajuda **se vê** na mãe que já procurou
- Quebra **3+ objeções por vídeo** ("achei que não ia funcionar", "fiquei com medo", "me preocupei com a escola")
- Resultado visível (capacete: cabeça moldada / Benjamin: anda na esteira)

**Aplicação pra Comtato (com adaptação ética):**
- Saúde mental tem barreira de exposição que reabilitação infantil não tem. Mas dá pra fazer:
  - **Depoimento da mãe** (não do paciente menor)
  - **Áudio do depoimento + B-roll do ambiente** (sem mostrar rosto do paciente)
  - **Depoimento de adulto que se sentiu acolhido** (com autorização)
  - **Carta lida pela terapeuta** (anonimizada)
- O modelo da Comtato no CLAUDE.md já prevê "depoimento de paciente com autorização LGPD" — **executar isso é prioridade.** É o conteúdo que mais converte e nenhum concorrente direto da região faz.

---

## Insight #4 — A FRICÇÃO OPERACIONAL é diferencial subexplorado

O reel da **Dea Clínica sobre estacionamento** é o ângulo mais inteligente desses 50 vídeos. Ninguém vende "fácil de estacionar" — mas é exatamente uma das fricções da mãe que leva criança em terapia (carro, fralda, atraso, criança chorando).

**Outras fricções que dá pra transformar em conteúdo:**
- "Sala de espera com brinquedo enquanto você atende seu filho"
- "Recepção que sabe o nome da criança quando chega"
- "Horários flexíveis pra mãe que trabalha"
- "Café/água na espera"
- "Sigilo absoluto sobre o que acontece na sessão"

**Aplicação pra Comtato:**
- Mapear **5 fricções operacionais** que a clínica já resolve (mas ninguém comunica) → cada uma vira um reel
- Esse formato é **muito barato de produzir** (voz off + B-roll do ambiente)
- Funciona como diferencial de marca **antes** da consulta

---

## Insight #5 — MOSTRAR o trabalho > FALAR sobre o trabalho

O NeuroReab faturou 505k views mostrando **uma sessão real de fisioterapia infantil** com som ambiente — a terapeuta gritando "força!", a criança esforçando, sem voz off vendedora.

**O que isso ensina:**
- Mãe não quer ouvir clínica falando bem dela própria. Quer **ver acontecendo.**
- Som ambiente real cria autenticidade que voz off não cria
- O trabalho **é o conteúdo**

**Aplicação pra Comtato (adaptada):**
- Não dá pra mostrar paciente em sessão (LGPD/sigilo).
- Mas dá pra mostrar **bastidor da preparação:**
  - Terapeuta organizando brinquedos antes da sessão
  - Sala sendo preparada
  - Caderno de anotações sendo aberto
  - Diário sendo escrito após a sessão (sem mostrar conteúdo)
  - Equipe em supervisão clínica conversando
  - "Um dia na clínica" (timelapse do ambiente)
- Áudio: **som ambiente real + música suave de fundo**, sem narração vendedora
- Esse formato **mata 2 coelhos:** humaniza a equipe + mostra dedicação invisível

---

## Insight #6 — POSICIONAMENTO DE NICHO bate posicionamento genérico

Todos os 5 concorrentes têm um **tema-imã** identificável:

| Concorrente | Tema-imã |
|---|---|
| Pediabilitare | Alimentação infantil |
| Santa Clínica | Reabilitação de casos complexos (capacete, síndromes raras) |
| Dea Clínica | Experiência da família na clínica |
| NeuroReab | A sessão em si (cena real) |
| Pipa | Empreendedorismo de saúde |

**Nenhum dos 5 fala genericamente "somos uma clínica multidisciplinar".** Cada um se especializa em uma faixa estreita do mercado.

**Aplicação pra Comtato:**
- O CLAUDE.md aponta que o público é "mães preocupadas com desenvolvimento emocional" + "adultos em burnout".
- **Esses são DOIS temas-imã**, não um. Sugestão: **escolher um pra liderar a comunicação** nos próximos 90 dias.
- Recomendação: **ansiedade infantil + escolar** (5-12 anos) — é o tema mais subexplorado pelos concorrentes (todos focam em desenvolvimento motor/reabilitação, ninguém em saúde mental infantil propriamente dita). Janela aberta.

---

## Insight #7 — O áudio CRISTÃO/EMOCIONAL converte muito no nicho de mães

3 dos top 10 do NeuroReab usam **música cristã/gospel**:
- "Em qualquer situação, na fartura ou escassez, quem me fortalece é Deus" — 505k views
- "Tô preparando o cenário, vai ser um espetáculo" — 248k
- "Deixa eu trabalhar do meu jeito, deixa acontecer no meu tempo" — 235k

**Por que funciona:** mãe de criança com necessidade especial vive em **incerteza emocional alta**. Música que fala de **fé, esperança, paciência com o tempo da criança** ressoa profundo.

**Aplicação pra Comtato:**
- Saúde mental tem mesma carga emocional. Música cristã pode funcionar (depende do posicionamento religioso da clínica — confirmar antes).
- Alternativa secular: **música de letra que fala de superação/esperança/cuidado.**
- Mapear 10-15 áudios desse mood pra reaproveitar.

---

## Plano tático — Próximos 30 dias da Comtato (sugestão)

**Semana 1:**
- [ ] Gravar **10 B-rolls** da clínica (ambiente, sofá, sala, brinquedo, jardim, recepção, terapeuta organizando)
- [ ] Listar **5 mitos** sobre saúde mental infantil → 5 roteiros de tutorial
- [ ] Listar **3 fricções operacionais** que a Comtato resolve melhor que ninguém
- [ ] Mapear **20 áudios em alta** (mães, infantil, emocional, cristão se aplicável)

**Semana 2-4:**
- 1 reel educacional/semana (formato Pediabilitare: voz off + B-roll + dor concreta)
- 2 reels com trend musical/semana (formato NeuroReab: B-roll + áudio em alta)
- 1 reel institucional/quinzena (formato Dea: estacionamento, ambiente, equipe)
- **A partir do dia 15:** começar a abordar 1 paciente para depoimento gravado (com LGPD)

**KPI mínimo de tração:**
- Crescer alcance 2x em 30 dias (versus baseline atual)
- Pelo menos 1 reel atingir 50k views nos primeiros 60 dias
- 5+ DMs/semana de mães querendo info da clínica

---

## Limitações desta pesquisa

- **Sem dados de visualização** dos perfis 1, 2 e 3 — eles não foram fornecidos (só NeuroReab e Pipa tiveram views explícitas)
- **Reels sem áudio (4 de 50)** não puderam ser analisados no conteúdo — só no formato
- **Análise é baseada em transcrição**, não no vídeo. Estética, edição, ritmo visual, cor — fatores importantes — não foram avaliados aqui
- **Sem cruzamento com legendas** dos posts — só áudio do vídeo

**Próximo passo sugerido:** se quiser aprofundar, abrir os 5 reels de maior view via dev-browser pra capturar legenda + estética visual completa.

---

**Ver também:** [[Pesquisa Concorrentes — Clínica Contato]] | [[PLANO-30-DIAS]] | [[Clínica Contato — Dossiê]]

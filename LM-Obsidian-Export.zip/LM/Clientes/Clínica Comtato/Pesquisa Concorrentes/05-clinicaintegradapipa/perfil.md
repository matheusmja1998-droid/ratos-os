# Clínica Integrada Pipa

**Perfil:** https://www.instagram.com/clinicaintegradapipa/

## Top 10 Reels Virais (com views)

1. https://www.instagram.com/clinicaintegradapipa/reel/DKK_fTaSPJ_/ — 46 mil views
2. https://www.instagram.com/clinicaintegradapipa/reel/DMYlcM6BG86/ — 43,9 mil views
3. https://www.instagram.com/clinicaintegradapipa/reel/DMX8PthRaiQ/ — 43,4 mil views
4. https://www.instagram.com/clinicaintegradapipa/reel/DJkVYUdB2z5/ — 43,2 mil views
5. https://www.instagram.com/clinicaintegradapipa/reel/DNVxmrix3UO/ — 39,1 mil views
6. https://www.instagram.com/clinicaintegradapipa/reel/DLkdlvqx1g8/ — 35,8 mil views
7. https://www.instagram.com/clinicaintegradapipa/reel/Cr4CHZot1q4/ — 34,9 mil views
8. https://www.instagram.com/clinicaintegradapipa/reel/CmzldAMpm7c/ — 34,2 mil views
9. https://www.instagram.com/clinicaintegradapipa/reel/DQiHOHejRo3/ — 33,7 mil views
10. https://www.instagram.com/clinicaintegradapipa/reel/DIe0xlySVp6/ — 33,5 mil views

---

**Análise correspondente:** [[05-clinicaintegradapipa/analise|analise]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

# Clínica Integrada Pipa — Análise dos 10 Reels Virais

**Perfil:** https://www.instagram.com/clinicaintegradapipa/
**Posicionamento:** Clínica integrada de Balneário Camboriú. Marca pessoal forte da fundadora ("a Pipa"). Combina **conteúdo de gestão/empreendedorismo** com posicionamento clínico — fala pra **outras donas de clínica**, não só pra mães-pacientes.

---

## Análise vídeo a vídeo

### 1. DKK_fTaSPJ_ — 46k views — **"Trabalho integrado: o protagonista é o paciente"**
> "Você já tentou fazer uma equipe de especialistas pensarem juntos tendo uma agenda lotada e cada um respeitando seu ritmo? Eu já e nem sempre flui. Às vezes o desafio é técnico e às vezes o desafio é humano. É lembrar que no trabalho integrado o único protagonista é o paciente. E quando a gente entende isso, a equipe se transforma em um time. Clínica integrada não é só ter vários profissionais no mesmo prédio e sim todos eles conversando e tendo o mesmo propósito."

**Formato:** talking head da fundadora.
**Por que viralizou:**
- **Audiência B2B** (donas de clínica, gestores) — engajamento qualificado mesmo com volume menor
- Frase de impacto repetível ("não é só ter vários profissionais no mesmo prédio")
- **Vulnerabilidade** ("eu já tentei e nem sempre flui")
**Padrão:** posicionamento de autoridade falando com pares

### 2. DMYlcM6BG86 — 43,9k views — **Apresentação institucional da clínica**
> "Você já conhece a Clínica Integrada Pipa? Estamos localizados na rua 1822, número 837, no centro de Balneário Camboriú… Aqui você encontra uma equipe transdisciplinar completa: fonoaudiologia, terapia ocupacional, nutricionista, psicologia para adultos, psicologia infantil, neuropsicologia…"

**Formato:** voz off + B-roll da clínica.
**Por que viralizou:**
- Lista enorme de especialidades = **palavras-chave** que o algoritmo cruza com buscas
- Localização precisa (mãe da região se identifica)
- "Transformando vidas através do afeto" — frase-marca

### 3. DMX8PthRaiQ — 43,4k views — Trend musical em inglês
Sem fala.

### 4. DJkVYUdB2z5 — 43,2k views — Sem fala
Trend.

### 5. DNVxmrix3UO — 39,1k views — Sem fala
Trend.

### 6. DLkdlvqx1g8 — 35,8k views — Música em inglês ("It feels like I'm going in circles")
Trend.

### 7. Cr4CHZot1q4 — 34,9k views — SEM ÁUDIO

### 8. CmzldAMpm7c — 34,2k views — Música "Pompeii" (Bastille)
> "But if you close your eyes, doesn't it almost feel like nothing changed at all?"
Trend musical em inglês.

### 9. DQiHOHejRo3 — 33,7k views — Música "Ain't No Mountain High Enough"
Trend.

### 10. DIe0xlySVp6 — 33,5k views — **"Empreender na área da saúde é diferente"**
> "Empreender na área da saúde é diferente, a gente não entrega um produto, a gente entrega confiança, cuidado, a vida em movimento, por isso o caminho é mais desafiador, porém é muito gratificante. Quando eu comecei a Pipa eu não imaginava o quanto eu precisaria aprender sobre gestão, liderança, pessoas e posicionamento, mas algo que eu aprendi: quem empreende com propósito precisa também se preparar com estratégias. Hoje empreender é parte do meu cuidado. Você é da área da saúde e quer empreender? Deseja ter uma pipa sua? Então comenta a pipa!"

**Formato:** talking head da fundadora.
**Por que viralizou:**
- **Conteúdo de mentor B2B** — está vendendo treinamento/franquia ("uma pipa sua")
- CTA forte ("comenta a pipa") gera engajamento direto
- **Diferenciação total** dos outros 4 concorrentes (nenhum fala pra empreendedores da área)
**Padrão revelador:** A Pipa monetiza não só com pacientes, mas vendendo método/franquia pra outras clínicas

---

## Padrão geral da Clínica Integrada Pipa

**Volume menor (33-46k views) que os outros concorrentes**, mas com audiência mais qualificada (B2B + paciente).

**Estratégia diferenciada:**
- **2 reels falam com donos de clínica** (#1 e #10) — posicionamento de autoridade/mentora
- **1 reel institucional clássico** (#2) — apresentação
- **7 reels são trends musicais** — alcance puro

**A Pipa não compete pelos mesmos 250k views do NeuroReab** — ela compete por **engajamento de empresários da saúde**, que vale muito mais por view. Possível modelo de negócio dela: **clínica + curso/franquia/mentoria pra outras clínicas**.

**Pra Comtato isso indica:** existe um **ângulo B2B latente** que a Pipa explora bem. Se a Comtato tem ambição de virar referência de gestão na região, esse formato pode replicar bem (talking head curto, dor de gestão de clínica, frase de autoridade).

**Tema-imã identificado:** **empreendedorismo de saúde** (audiência paralela à de mães).

---

**Perfil correspondente:** [[05-clinicaintegradapipa/perfil|perfil]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

# Dea Clínica — Análise dos 10 Reels Virais

**Perfil:** https://www.instagram.com/deaclinica/
**Posicionamento:** Clínica multidisciplinar de Itapema (SC) chamada **Especialmente**. Inaugurada em março/2025. Marca pessoal forte da fundadora. Foco no **conceito de cuidado afetivo + estrutura física diferenciada**.

---

## Análise vídeo a vídeo

### 1. DNoG2OMOOYd — "Psicomotricidade — o Brincar Transforma"
> "Na psicomotricidade, o corpo é ponto de partida para o desenvolvimento global da criança. No circuito terapêutico, cada desafio é uma oportunidade de crescer, brincar e aprender, tudo isso em movimento, com um afeto e cheio de propósito. Aqui, o Brincar Transforma."

**Formato:** voz off institucional, tom poético, B-roll da terapia em ação.
**Por que viralizou:**
- **Slogan próprio** ("o Brincar Transforma") repetido
- Posicionamento conceitual da especialidade (psicomotricidade não é tão conhecida → educa o mercado)
- Estética cuidada
**Padrão:** explicar especialidade pouco conhecida com **conceito-marca** próprio

### 2. DPB5eiMDhlJ — "Estacionamento e localização da clínica"
> "Você sabia que a clínica especialmente foi pensada para acolher com conforto e segurança a cada família que nos visita? Além de todas as especialidades… nosso grande diferencial está na localização. Rua tranquila, fácil acesso, baixo fluxo de trânsito e muitas vagas de estacionamento."

**Formato:** voz off + B-roll da entrada.
**Por que viralizou:**
- **Fricção concreta de mãe que leva criança em terapia:** estacionamento. Ninguém fala disso.
- Vende **conveniência logística** num momento em que mãe já tá esgotada
- Ângulo lateral (não vende o serviço, vende o "ir até a clínica")
**Padrão genial:** **transformar fricção operacional em diferencial de marketing**

### 3. DJ_-DINOmS3 — Sem fala
Trend.

### 4. DH61hcIu47C — **Vídeo de inauguração da clínica**
> "Sejam todos muito bem-vindos a esse momento e primeiramente nós agradecemos a presença de cada um de vocês. Hoje, dia 29 de março, foi um dia escolhido para inaugurar a Especialmente. Especialmente é uma clínica multidisciplinar… é uma clínica Especial. Traz como foco principal o amor, o carinho, o afeto…"

**Formato:** discurso no evento de inauguração, captado ao vivo.
**Por que viralizou:**
- **Marco institucional** (inauguração) gera engajamento natural da rede de contatos
- Define **posicionamento de marca** ("especialmente" = especial + atendimento)
- Tom emocional + missão clara
**Padrão:** transformar evento institucional em conteúdo de posicionamento

### 5. DOOYF7_jp7K — Música em inglês (sem fala estruturada)
Trend musical.

### 6. DOwSP8ukTmN — Trecho de algum áudio viral ("foi ao chão senhoras e senhores")
Trend.

### 7. DPW6jEOkc-A — Hino americano (Star-Spangled Banner)
Trend musical.

### 8. DKKafbLu_2y — Sem fala ("You")
Trend.

### 9. DAD7uQBPT7S — Música pop em inglês (sem fala estruturada)
Trend.

### 10. C4MTESqvfmN — Sem fala detectável
Trend ou transição.

---

## Padrão geral da Dea Clínica

**O que viraliza:**
- **3 reels institucionais com narração própria** (psicomotricidade, estacionamento, inauguração) — são os com conteúdo real
- **7 trends musicais** sem fala — alcance puro

**Insight forte:** o reel do **estacionamento** é o melhor ângulo desses 50 vídeos. Mãe que vai pra terapia infantil tá com 2 crianças no carro, fralda, mochila, atrasada. Quando a clínica vende "fácil de estacionar", tá vendendo **alívio operacional** que ninguém percebe que é dor. Comtato pode replicar isso com qualquer **fricção de bastidor da terapia** que a mãe enfrenta.

**Estilo de comunicação:**
- Voz off **mais "conceitual" e poética** que as outras clínicas
- Estética visual aparenta ser mais cuidada (sugestão pelo padrão dos textos)
- Linguagem afetiva ("afeto", "acolhimento", "amor") — bem alinhada com saúde mental

**Tema-imã identificado:** **a experiência da família na clínica** (não só o tratamento). Cuidado com tudo ao redor — estacionamento, ambiente, recepção.

**Risco da estratégia deles:** sem depoimento de mãe e quase sem tutorial educacional. Vivem de **estética + posicionamento de marca**. Funciona pra status, pode ser fraco pra conversão direta.

---

**Perfil correspondente:** [[03-deaclinica/perfil|perfil]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

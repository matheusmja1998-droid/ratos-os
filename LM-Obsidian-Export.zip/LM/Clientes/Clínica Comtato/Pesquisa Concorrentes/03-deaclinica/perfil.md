# Dea Clínica

**Perfil:** https://www.instagram.com/deaclinica/

## Top 10 Reels Virais

1. https://www.instagram.com/deaclinica/reel/DNoG2OMOOYd/
2. https://www.instagram.com/deaclinica/reel/DPB5eiMDhlJ/
3. https://www.instagram.com/deaclinica/reel/DJ_-DINOmS3/
4. https://www.instagram.com/deaclinica/reel/DH61hcIu47C/
5. https://www.instagram.com/deaclinica/reel/DOOYF7_jp7K/
6. https://www.instagram.com/deaclinica/reel/DOwSP8ukTmN/
7. https://www.instagram.com/deaclinica/reel/DPW6jEOkc-A/
8. https://www.instagram.com/deaclinica/reel/DKKafbLu_2y/
9. https://www.instagram.com/deaclinica/reel/DAD7uQBPT7S/
10. https://www.instagram.com/deaclinica/reel/C4MTESqvfmN/

---

**Análise correspondente:** [[03-deaclinica/analise|analise]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

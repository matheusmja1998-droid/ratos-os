# NeuroReab Clínica

**Perfil:** https://www.instagram.com/neuroreabclinica/

## Top 10 Reels Virais (com views)

1. https://www.instagram.com/neuroreabclinica/reel/DKSIGUNObWF/ — 505 mil views
2. https://www.instagram.com/neuroreabclinica/reel/DGlzq-eSXhF/ — 345 mil views
3. https://www.instagram.com/neuroreabclinica/reel/C7m5enwIkrs/ — 289 mil views
4. https://www.instagram.com/neuroreabclinica/reel/C6Pp-PnOAQ_/ — 284 mil views
5. https://www.instagram.com/neuroreabclinica/reel/DBZ0XZWuSOm/ — 264 mil views
6. https://www.instagram.com/neuroreabclinica/reel/B9ox9zapND1/ — 264 mil views
7. https://www.instagram.com/neuroreabclinica/reel/B94Bj7yptsO/ — 261 mil views
8. https://www.instagram.com/neuroreabclinica/reel/C2ao8Z4O8pY/ — 250 mil views
9. https://www.instagram.com/neuroreabclinica/reel/C5WEKeZubFa/ — 248 mil views
10. https://www.instagram.com/neuroreabclinica/reel/C5lv1iVO_T-/ — 235 mil views

---

**Análise correspondente:** [[04-neuroreabclinica/analise|analise]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

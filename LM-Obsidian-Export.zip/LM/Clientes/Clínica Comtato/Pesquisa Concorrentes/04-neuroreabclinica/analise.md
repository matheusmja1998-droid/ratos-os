# NeuroReab Clínica — Análise dos 10 Reels Virais

**Perfil:** https://www.instagram.com/neuroreabclinica/
**Posicionamento:** Reabilitação neurológica infantil. **MAIORES NÚMEROS DOS 5 CONCORRENTES** — top reel tem 505 mil views, 7 dos 10 acima de 250 mil. Estratégia 100% **trend musical + cenas de terapia em movimento**.

---

## Análise vídeo a vídeo

**Observação prévia:** quase todos os reels desse perfil são **música + cenas curtas de terapia em ação**. Praticamente zero conteúdo falado/educacional. A escala de visualização (250k+) mostra que isso funciona MUITO bem nesse nicho.

### 1. DKSIGUNObWF — 505k views — Música gospel "Em qualquer situação"
> "Em qualquer situação / Na fartura ou escassez / Tendo a provisão ou não / Quem me fortalece é Deus / Eu não sei do amanhã / O que vestir ou comer…"

**Por que viralizou:**
- **Música cristã/gospel** ressoa fortíssimo com mães de crianças com necessidades especiais
- Provável B-roll da clínica com letra alinhada às lutas familiares
- **Áudio com forte carga emocional** + nicho específico = viralização emocional
**Padrão:** **emoção espiritual** + cena terapêutica = combo poderoso pra esse público

### 2. DGlzq-eSXhF — 345k views — "Música Vamos vamos oh!" (sessão de fisioterapia gravada)
> "Vamos, vamos, oh! Música. Isso foi a Elsa? Olha! Vai ter! Celi, né?… Força! Para fazer o barulhão!"

**Formato:** ASMR/captação da sessão de fisioterapia + criança fazendo + terapeuta incentivando.
**Por que viralizou:**
- Som ambiente real ("força!", "vai ter!") cria autenticidade
- Mãe vê o **tipo de estímulo** que a clínica dá pro filho
- Gera identificação ("ah, é isso que eles fazem com as crianças")
**Padrão:** captação ao vivo de sessão real, sem voz off

### 3. C7m5enwIkrs — 289k views — "93 million miles from the sun" (música em inglês)
Trend musical.

### 4. C6Pp-PnOAQ_ — 284k views — "Pula corda" (música infantil)
> "De todas as brincadeiras que eu gosto a melhor é pula corda…"
Trend de música infantil + cena de terapia.

### 5. DBZ0XZWuSOm — 264k views — Música rap/funk em inglês
Trend musical (provavelmente cena divertida da clínica).

### 6. B9ox9zapND1 — 264k views — **Sessão real de fisioterapia gravada**
> "Segura! Vamos, vamos, vamos! Bumbum, bumbum! Vamos lá! Bota força, bota força! Para fora!"

**Formato:** captação da terapeuta incentivando criança em exercício.
**Por que viralizou:**
- **Energia da terapeuta + criança esforçada** = empatia imediata
- Áudio real cria autenticidade
- Mãe sente "isso é o que meu filho precisa"

### 7. B94Bj7yptsO — 261k views — **Outra sessão real ("Pé 1, Pé 2, cadê o pé 2?")**
> "Pé 1, Maria! O que você vai fazer? Cadê o pé 2? Vem! Vem!"

Mesma fórmula do reel 6.

### 8. C2ao8Z4O8pY — 250k views — Música em espanhol
Trend.

### 9. C5WEKeZubFa — 248k views — "Tô preparando o cenário, vai ser um espetáculo"
> "Tô preparando o cenário, vai ser um espetáculo, o que tá vindo aí é extraordinário…"
Trend de música cristã motivacional.

### 10. C5lv1iVO_T- — 235k views — "Deixa eu trabalhar do meu jeito"
> "Deixa, deixa eu trabalhar do meu jeito / Deixa acontecer o meu tempo…"
Trend de música cristã (Tarcísio do Acordeon? ou similar). Tema da **paciência com o tempo da criança**.

---

## Padrão geral do NeuroReab — **O MAIS IMPORTANTE**

**Eles entenderam a fórmula que viraliza no nicho:**

1. **Cenas reais da sessão** com som ambiente (terapeuta incentivando, criança esforçando)
   - Reels 2, 6, 7 — autenticidade pura
2. **Trends musicais cristãos/emocionais** sobreposto a B-roll da clínica
   - Reels 1, 9, 10 — apela à fé das mães
3. **Música infantil pop** com B-roll de terapia divertida
   - Reels 4, 5, 8 — diferenciação alegre
4. **Zero conteúdo educacional falado nos top 10**

**Volume:** 250k-505k views por reel. **10x os outros concorrentes.**

**Por que funciona melhor que os outros:**
- Outros perfis tentam "vender a clínica". NeuroReab **mostra a clínica em ação**.
- Não tem voz off vendedora. É o som real do trabalho.
- A música faz o trabalho emocional, o vídeo faz o trabalho de prova.

**Tema-imã identificado:** **a sessão em si**. O conteúdo é o trabalho. Não é tutorial nem depoimento — é **observação da terapia**.

**Insight crítico pra Comtato:**
Comtato é saúde mental adulta + infantil. Adaptação: mostrar **o ambiente da terapia** (sem expor pacientes, claro), bastidor de bonecos/jogos usados, fila de espera acolhedora, terapeuta organizando ferramentas. **Som ambiente real, sem voz off vendedora.**

**Limitação ética importante:** clínica de saúde mental NÃO pode mostrar paciente em sessão como o NeuroReab faz com criança em fisioterapia (dimensão LGPD/sigilo é diferente). Mas pode mostrar **o setting** — a sala, o sofá, o brinquedo, o caderno, o ambiente que recebe — com som ambiente e música emocional. Esse é o caminho replicável.

---

**Perfil correspondente:** [[04-neuroreabclinica/perfil|perfil]]
**Hub:** [[Pesquisa Concorrentes — Clínica Contato]] | [[Clínica Contato — Dossiê]]

---
cliente: ComTato Terapias
agencia: LM
tipo: identidade-visual
atualizado: 2026-05-07
---

# ComTato Terapias — Identidade Visual

Centro Multidisciplinar de Terapias · Itapema/SC
Instagram: @comtato_terapias

## Paleta oficial

| Função | Nome | HEX |
|---|---|---|
| Primária | Teal Cuidado | `#4CBFB0` |
| Secundária | Azul Vibrante | `#4A5CC7` |
| Acento | Coral Vitalidade | `#F2795A` |
| Apoio | Dourado Alegria | `#F5C842` |
| Neutro | Menta Suave | `#F0F7F6` |
| Base | Branco Limpo | `#FFFFFF` |

Azul institucional (fundo dos slides do guia): `#1F3A5F` aprox.

## Aplicação por categoria de post

| Categoria | Cor dominante |
|---|---|
| Post Educativo | Teal `#4CBFB0` |
| Dica Terapêutica | Azul Vibrante `#4A5CC7` |
| Data Comemorativa | Coral `#F2795A` |
| Conquista da Clínica | Dourado `#F5C842` |
| Stories & Rotina | Menta `#F0F7F6` |

## Regra de combinação
Máximo **3 cores por post** pra manter harmonia visual.

## Arquivos
- PDF original: `Ratos OS/lm/clientes/clinica-comtato/paleta-comtato.pdf`
- Guia local: `Ratos OS/lm/clientes/clinica-comtato/marca/design-guide.md`

## Ver também
- [[Clínica Contato — Dossiê]]

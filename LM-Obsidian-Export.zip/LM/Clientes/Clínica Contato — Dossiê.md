---
cliente: ComTato Terapias
agencia: LM
nicho: Saúde / Reabilitação multidisciplinar (infantil e adulto)
status: ativo
atualizado: 2026-05-07
---

# ComTato Terapias — Dossiê

Hub central do cliente **ComTato Terapias** (atendido pela L.M Agência).

> Nota de grafia: nome correto é **ComTato** (com T maiúsculo, jogo com "contato" + "tato" terapêutico). Pasta histórica e algumas notas antigas usam "Contato" — é o mesmo cliente.

## Identificação
- **Razão/nome:** Comtato Centro Multidisciplinar de Terapias
- **Responsável:** Caroline Lopes Gomes de Abreu (CREFITO 10/8988)
- **Fundação:** setembro/2024
- **Endereço:** Rua 900, 150, Sertãozinho, Itapema/SC, CEP 88220-000
- **Contato:** (47) 99664-7774
- **Instagram:** @comtato_terapias
- **Site:** ainda não tem (interesse em criar)

## O que oferecem
Reabilitação infantil e adulto com equipe multi: fisioterapia, terapia ocupacional, fonoaudiologia, psicologia, psicopedagogia, atendente terapêutica, avaliação multiprofissional.

**Formações da equipe:** Bobath, PediaSuit, ABA, treino locomotor, treino de habilidades de vida diária.

**Públicos atendidos:**
- Bebês e crianças com atrasos e transtornos do desenvolvimento (autismo, paralisia cerebral, síndromes, atrasos motores, torcicolo congênito, atraso de linguagem)
- Adultos com deficiências motoras e cognitivas (AVC, hemiparesia, Parkinson, lesão medular, demência)

## Operação
- Seg–sex, 08h–17h (almoço 12h–13h)
- Não atende sábado, domingo nem feriados
- Banheiro acessível pra cadeirantes
- Estacionamento coberto e descoberto, gratuitos
- Espaço amigável pra mães (acolhe amamentação)
- Aceitando novos clientes

## Frentes do projeto

### Conteúdo e Criativos (Instagram)
- [[Clínica Contato — Reunião Conteúdo e Criativos]] — reunião 14/04/2026 que originou o sistema de produção
- [[Pesquisa Concorrentes — Clínica Contato]] — mapeamento dos 5 concorrentes principais (50 reels analisados)

### Identidade visual
- [[ComTato — Identidade Visual]] — paleta oficial (Teal/Azul/Coral/Dourado/Menta) e regras de aplicação

### Plano e Insights da Pesquisa
- [[INSIGHTS-GERAIS]] — insights consolidados dos 5 concorrentes
- [[PLANO-30-DIAS]] — plano tático de conteúdo dos próximos 30 dias

## Profissionais ligados
- [[Dr. Fábio — IOT (Varginha)]] — Dr. Fábio é cliente separado da LM (não confundir com ComTato). Frente de Google Ads dele: [[Dr. Fábio — Comtato (Google Ads)]]

## Acessos pendentes
- BM (Meta Ads)
- Google Ads
- Modelo de autorização de depoimento (LGPD)
- Decisão sobre criação de site

## Ver também
- [[LM — Visão Geral|L.M Agência]]

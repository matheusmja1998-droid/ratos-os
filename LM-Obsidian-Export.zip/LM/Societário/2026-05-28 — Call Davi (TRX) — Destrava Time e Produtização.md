---
tipo: mentoria/call estratégica
data: 2026-05-28
participantes: Matheus, Valentino, Davi (TRX Group)
duração: ~98min
fonte: Fathom
recording_id: 150368387
url: https://fathom.video/calls/690927288
tags:
  - lm
  - cultura
  - time
  - produtizacao
  - meta-100k
links:
  - "[[LM — Visão Geral]]"
  - "[[Aula - Cultura de Alta Performance]]"
  - "[[2026-05-08 — Alinhamento Sócios (Metas Maio)]]"
---

# 2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização

Call com Davi do TRX Group (projeção R$10M no primeiro ano) compartilhando como ele resolveu time, retenção e cultura. Conversa que destravou pontos travados há meses na L.M (retenção de BDR, produtização das competências do Matheus e Valentino, meta agressiva de receita).

---

## Diagnóstico que o Davi fez da L.M

O gargalo real **não é venda**. É **retenção de time**.

- Matheus e Valentino tavam perdendo BDR em 1-2 semanas
- Cada saída zerava a esteira de prospecção e travava operação
- Enquanto isso não resolve, escalar é impossível

---

## Modelo de Contratação — "Fire Test" (45 dias)

Davi roda assim no TRX:

- **45 dias 100% comissão** (sem fixo)
- **15% do upfront** recebido pela empresa
- **5% do MRR vitalício** do cliente que aquele BDR trouxe
- **Bônus diários/semanais em cash** pra dar tração (ex: R$150 pro primeiro a bater 5 agendamentos no dia)
- Só depois dos 45 dias entra fixo

Função do modelo: filtrar quem tem fome real e validar fit cultural **antes** de assumir custo fixo.

---

## "Dream Plan" — a sacada de retenção

Cada funcionário define um **objetivo pessoal grande** (carro, casa, viagem). A empresa monta um bônus de performance que casa com esse objetivo.

**Exemplo real do TRX:**
- BDR quer Jetta de R$320k → precisa de R$50k de entrada
- BDR junta R$25k do próprio salário
- Empresa promete R$25k de bônus condicionado a 45 contratos fechados no período
- BDR realiza o sonho + empresa retém o cara por anos

**Lógica:** liga trabalho diário a uma recompensa tangível e pessoal. Vira loyalty real, não retórica.

---

## Os 2 produtos escondidos na L.M

Davi identificou duas competências raras que tão sendo dadas de graça hoje:

### Valentino — Treinamento Rápido de BDR
Tirar BDR do zero pra 5-7 agendamentos/dia em 2 semanas é raro no mercado.

- **Front-end:** R$30k-40k por implementação de time comercial em 45 dias
- **Recorrência:** R$3-4k/mês de gestão contínua (calls diárias, coaching de performance)

### Matheus — Automação de Meta Ads com IA
Sistema com contingência de BM, rotação criativa, pacing de lead, Guardião 24/7 é rara no mercado.

- **Mentoria/curso** pra outros gestores de tráfego construírem o mesmo sistema
- Resolve dor real de agência (operação manual + falta de visão estratégica)
- Essa é a frente do [[Cockpit]]

---

## Meta R$100k/mês até dezembro/26

Davi falou que é **conservador** pro nível dos dois.

**A matemática:**
- 15 clientes novos × R$7k médio = **R$105k**
- Close rate 35% (realista pro perfil de venda da L.M)
- = **45 reuniões/mês**
- = **~2 reuniões/dia**

Matheus faz 2 reuniões/dia tranquilo. **Gargalo não é demanda — é time pra entregar.** Volta no ponto 1: precisa resolver retenção antes de escalar receita.

---

## Próximos passos definidos na call

1. Definir **cultura e valores** da L.M antes de contratar de novo
2. Desenhar **Dream Plan** estruturado pros próximos hires
3. Montar **funil de contratação** (ads + formulário filtro detalhado)
4. Rodar **piloto Fire Test** com 4-5 BDRs
5. **Produtizar** treinamento de BDR (Valentino) e Cockpit/automação (Matheus)
6. Cravar meta firme de **R$100k/mês até dezembro/26**
7. Matheus oferecer automação IA pro **SaaS novo do Davi** (possível JV)

---

## Conexões internas

- Base teórica de cultura pra implementar: [[Aula - Cultura de Alta Performance]] (Os Escolhidos, Adriano)
- Divisão atual de papéis (Nimoto/Adriano): [[2026-05-08 — Alinhamento Sócios (Metas Maio)]]
- Linha de produtos pra Matheus: [[00 — Visão Geral|Cockpit]]

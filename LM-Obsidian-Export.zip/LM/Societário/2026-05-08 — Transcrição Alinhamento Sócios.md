---
tipo: transcrição
data: 2026-05-08
duração: 59min
fonte: Fathom (Google Meet)
relacionado: "[[2026-05-08 — Alinhamento Sócios (Metas Maio)]]"
---

# Transcrição — Alinhamento Sócios 2026-05-08

Reunião impromptu Matheus + Valentino. Análise: [[2026-05-08 — Alinhamento Sócios (Metas Maio)]]

---

0:00 - Matheus Amaral
  Creação psicológica para entrar com algum processo, para receber alguma coisa. Olha aí, mano, a identidade visual delas, um pouco da logo aqui, a logo aqui em cima, cores da paleta, tipografia delas. O que tu achou aí, mano?

0:24 - Valentino
  Hum, isso aí é bom. Mano, sabia que tem um hospital de autista aqui. Será que tem como, sei lá, de alguma forma, anúncia lá não faz sentido, né, mano? Mas algum panfleto, talvez? Sei lá.

0:51 - Matheus
  Mano, tem como anunciar no lugar, pô. Coloca um pino lá e um raio de um calendro, pô. Hum, já tá lá já, provavelmente. Mas dá pra colocar só lá, específico. Gostou dos criativos, mano? Que aí eu mando pra aprovação delas.

1:06 - Valentino
  É o... dos cinco ali pra baixo.

1:36 - Matheus
  Ficou bom pra caralho, velho. Não ficou não? Ficou, mano. Ficou bom. São stories deles. Ficou bom pra caralho, mano. Não que elas não gostariam disso daqui agora. Olha lá no grupo já, mano. Mano, mas não ficou tão claro, velho.

1:56 - Valentino
  Não ficou claro pra mim, o que elas fazem. Eu não sei se elas só atendem pessoas com especialidades?

2:06 - Matheus
  Só? Ah, ué, por que que atenderia a outra coisa sendo que elas não conseguem? Como assim elas não conseguem? Ah, porque elas não tem formatura pra atender isso.

2:27 - Valentino
  Talvez, mano. Esse criativo sim, a gente pode subir ele. Mas eu senti que teve um só que pegou a dor ali, que deixou evidente. É o que elas querem esses criativos, tá ligado? Que mostra tudo o que elas fazem e tudo mais. Teve um criativo que é mostrador, aquele do "Acho que seu filho não fala bem", algo assim.

2:57 - Matheus
  Aquele lá é bom, mano.

3:00 - Valentino
  Bom dia, pessoal.

3:29 - Matheus
  Tudo bem? Estou enviando aqui os criativos para aprovação. Todos os criativos foram feitos com a paleta de cores de vocês, a logo de vocês, a identidade visual e também as especialidades de vocês, todos os criativos e também a tipografia. Aguardo um feedback sobre eles para a gente subir os anúncios.

3:57 - Valentino
  Não está aparecendo o ícone aqui. Não está limpo.

3:59 - Matheus
  Não está limpo. Ah pô, o contato e o wikini deles, ele é longe deles. Eles vão reclamar disso daí, nossa senhora.

4:16 - Valentino
  A imagem tá aqui, pelo visto. Porque tá aparecendo, né?

4:24 - Matheus
  Mano, ficou muito alinhadinho, pô. Esse aqui ficou pirope, mano. Esse aqui ficou foda.

4:32 - Valentino
  Todos ficaram bons, né mano? Mas esse aqui pega dor pra caralho, esse aqui. Porque assim, tu já fez muito criativo, né? Tu tem noção. Aí assim, eu pego o anúncio, aparece na minha tela, que tá uma campanha aberta, né? Pra pessoas assim de 20 anos, uns 23 ali, e daí aparece esse anúncio aqui, e aí aparece assim "olha o que a gente faz, físio, fono, psicopedagogia, atendente terapêutica, tudo no seu lugar, só com a equipe inteira discutindo o caso do seu filho".

5:21 - Matheus
  Mano, velho, depende muito, no Facebook não dá pra entender não, tem umas coisas que você fala assim, porra, como é que esse criativo deu bom. É muito aleatório, mano, muito aleatório. Mano, você quer ver? Esse criativo aí vai ser um dos melhores, e a gente só vai ficar trocando curva.

  Vamos lá, tipo assim, mano, dividir, toca o Fathom já tá aí, que daí o que a gente faz, tipo assim, cada um fica meio que o head da sua área, e o operacional a gente faz junto. Vamos dividir a área comercial. Quando um conseguir ajudar no outro, consegue. Principalmente você, quando quiser participar das calls de venda, ou se eu ficar nas calls de venda. Mec, quer ficar em qual parte? Prospecção ou venda?

  Não, prospecção, né?

6:33 - Valentino
  Tá, beleza.

6:34 - Matheus
  É que tem que perguntar, né, velho? Que porra que tu tá querendo agora? E daí, mano, beleza. Então, tu coloca a meta pra mim e me cobre, e eu coloco a meta pra você e te cobro. Por quê? Eu preciso que tu entregue resultado pra me vender. E tu precisa que eu venda o resultado que tu tá me entregando. Senão o teu esforço vai ser em vão.

  Aí agora a gente começa a definir as metas, porque se não fica vago, quanto que cada um tem que entregar por dia. E aí depois a gente vem trabalhar trampando operacional. O que que você acha desse jeito? Sim.

  E aí, mano, isso aí talvez ajude a tirar esse peso na consciência que tu tá achando que tá entregando menos. E até uma coisa que eu acho interessante nós fazer, mano, como equipe eu e tu, eu acho que a gente deveria fazer dailys. Trazer como que foi o dia anterior e a principal dificuldade em cada ponto na venda e na prospecção, e um ajuda o outro. Primeiro vamos falar de prospecção: qual que foi a dificuldade. E eu, como que foi na venda? Dificuldade, tal. E aí, pô, dele dos dois comerciais, nós dois fazendo, que aí fica alinhado, mano. Fechou?

8:10 - Valentino
  E aí, quando a gente for implementar pra gente, uma equipe de verdade, com mais pessoas, aí gente já vai saber.

8:17 - Matheus
  Sim, mano. E daí, mano, até nessa organização aí de separar e ajustar as coisas, pô, basicamente, tu vai ser o Adriano, eu vou ser o Nimoto, né? E daí, tu é responsável no time de prospecção e eu responsável no time de vendas. E não quer dizer que um tá no dentro do outro ajudando, né? Qual eles fazem.

  E aí, é um bagulho de escalar, né, mano? Eu acho que eu não sou bom de vendas, nem um Nimoto. Você tá muito mais perto de virar o Adriano do que eu virar o Nimoto nas vendas, tá ligado? Então, a minha caminhada tá meio mais longa, mano.

8:53 - Valentino
  O teu caminho é muito longe. Tem vários quilômetros.

9:00 - Valentino
  O que é vendas é mais complicado.

9:03 - Matheus
  É porque, mano, pensa só, uma reunião de venda é dividida em duas reuniões de uma hora, R1 e R2. Basicamente, tu tem que ajustar duas horas de conversa pra tu vender. E na ligação, tu tem que ajustar três minutos de ligação pra tu marcar a reunião. É a diferença de ajustar três minutos pra ajustar duas horas.

9:26 - Valentino
  Ontem eu chamei um cara que a gente fez reunião lá em fevereiro. E esse cara, ele sempre deu no show na gente. E eu falei com ele dois minutos, ele riu, ficou alegre, que é uma coisa que ele nunca tinha feito. E falou que vai participar do Webinar também.

9:44 - Matheus
  E um cara qualificado. Mano, vamos lá. O que tu quer colocar? Vamos começar a traçar as metas. Tu quer começar a traçar as metas da tua parte ou da minha parte? De vendas ou da parte de prospecção? Primeiro da minha.

10:00 - Valentino
  Sendo, senão não vai ter da tua, porque da tua não tem o que estipular também, tem que estipular a conversão daí.

10:06 - Matheus
  Ó, eu pensei, vamos, você falou, pô, eu tô sentindo que eu tô fazendo menos coisa, mano. Pelo menos 10 preenchimentos por dia, e eu preciso de 3 reuniões por dia, mano. 3 reuniões por dia? E 10 preenchimentos. E depois a gente vai pra parte de qualificado, vamos começar a gerar esse daí, depois a gente começa a qualificar.

10:38 - Valentino
  Tá, 10 preenchimentos e 3 reuniões, pelo menos.

10:43 - Matheus
  No final das contas vai ficar 13 ali. É, só que 10 preenchimentos é mais fácil que 3 reuniões pra marcar. Não, o número que tu passou é legal, vai, tranquilo. Dá pra bater, né? Dá. Pensa só, a gente tem 5 dias da semana pra marcar pro webinar. 10 preenchimentos, a gente sempre vai ter um webinar com 50 pessoas lá dentro, sacou?

  E aí, o que que eu posso vir te ajudando, mano? Que eu tava pensando ontem. Talvez no início... Um webinar toda semana? É, pô, eu preciso de reunião de venda pra me vender. E se eu não tiver reunião de venda, não treino, né?

11:22 - Valentino
  Tá, peraí, vamos fazer assim. Eu trago tanto quanto tu quiser. Isso aí é zero problema. Mas você vai me ajudando no follow.

11:33 - Matheus
  É isso que eu ia falar agora, velho. Quando, tipo assim, vamos supor, os follows, deixa que eu faço. Vamos supor, o follow que é, vamos supor, acho que é um segundo, um quarto e o de quinta, né? Os três follows. Então, esses daí eu faço. Porque, pô, vamos supor que tem 30 pessoas. Pô, pega o celular e liga as 30 falando: "Ô, fulano, ligando aqui pra confirmar. O Valentino marcou o webinar contigo, o nosso evento vai ser na quinta-feira, meio-dia. Estou passando aqui para confirmar. Posso confirmar a sua presença? Você já falou que conseguia, só estou ligando para confirmar mesmo. Pô, eu consigo. Ô, fulano, vê lá no seu WhatsApp, que o Valentino tinha te mandado o link para você clicar e aceitar na agenda. Vê se chegou e clica e aceita aí pra mim, por favor."

  Eu faço, mano. Sacou? Então, aí já aumenta a tua produtividade pra caralho, mano.

12:21 - Valentino
  O que mais me travava era aumentar a demanda e ter que aumentar o follow, daí eu ficava assim.

12:27 - Matheus
  É, mano. Tipo, porra, ficava perdido no meio tempo aí. Então, pô, a gente pode setar os follows ali, segunda, quarta e quinta. Segunda melhor eu acho ligação com os caras. Quarta a gente vê se faz ligação ou WhatsApp. E quinta, acho que o WhatsApp.

12:54 - Valentino
  Eu tô pensando... Como é que eu... Que nem agora. Agora é sexta-feira, eu... Como que eu vou tirar três reuniões de hoje, mano? Não sei como.

13:10 - Matheus
  Não, hoje, vamos supor, hoje já tem três reuniões pra hoje, pô.

13:14 - Valentino
  Ah, tu quer três reuniões todos os dias? Tá, mas daí pós-webinar, no caso.

13:22 - Matheus
  Mano, pode ser pós-webinar, depois do webinar.

13:25 - Valentino
  Eu achei que tu queria antes do webinar, três reuniões e dez agendamentos.

13:29 - Matheus
  Se a gente conseguir antes do webinar, é bom, mano, se tu conseguir.

13:34 - Valentino
  Eu consigo na semana do webinar. Então, vai, tá suave, mano.

13:36 - Matheus
  Na semana do webinar. Uma semana antes, não. É, porque, pensa só, se vai ter webinar toda semana, o webinar vai gerar, é pra gerar as reuniões da semana, sacou?

13:48 - Valentino
  O bagulho que o Adriano falou é fazer uma... antecipar a call. Antes do webinar, antes do cara participar do webinar, já marca a reunião. Aí ele vê o webinar e já tem a reunião marcada.

14:05 - Matheus
  Eles estão fazendo isso?

14:09 - Valentino
  Estão. Estão marcando um monte de reunião antes do webinar.

14:15 - Matheus
  Ver como que eles estão fazendo, usando scripts pra fazer isso daí.

14:19 - Valentino
  Eu sei, eu sei como faz.

14:22 - Matheus
  Dá pra tentar, pô. Mas é no mesmo dia ou, tipo assim, espera um dia pra marcar?

14:30 - Valentino
  Na mesma semana, eles ligam assim e falam, tipo assim, Eduardo, tá ligado?

14:35 - Matheus
  Tipo assim, então é basicamente o mesmo funil que a gente tinha desenhado de fazer a reunião antes, só que eles jogaram a reunião depois do webinar e já deixaram a reunião pré-marcada depois do webinar. Já deixou ele arrumadinho já. Da hora, mano.

  Então vamos lá. E daí, com essas três calls por dia? Buscar vender uma por dia, né? 33% de conversão, né? Um closer bom, tem que entregar isso aí, pelo menos. Aí, se tu quiser, mano, se tu tiver dentro da meta, você participa. Pra você treinar cada vez mais. E se eu estiver tranquilo aqui relacionado ao tráfego, eu venho ajudando você na desligação também, pô. O que que tu acha? Acho que tá bom?

  Sim, válido.

15:31 - Valentino
  Tipo assim, hoje, agora é 8h04, eu vou ter que tomar banho, que minha mãe sai agora do banho. Eu prospectaria de umas 8h09 e daí só as 3h.

15:48 - Matheus
  Que agora tem call de venda, né? Tem umas 9h, tem a Rafa as 10h, tem o Daniel 11h30 e tem o Kaique as...

16:00 - Matheus
  Essas daí a gente faz com todo mundo, faz normal. Vou começar nas calls de venda pra não atrapalhar toda a dinâmica. Tu organiza o seu dia e vê quanto de tempo que tu precisa pra estar gerando a demanda da meta. E aí o tempo que tu tiver livre, tu participa da call. Aí encaixa.

16:21 - Valentino
  Em uma hora eu marquei seis ontem.

16:24 - Matheus
  É, aí vê, mano, quanto que é a sua média.

16:28 - Valentino
  Mano, eu não entendo como eu faço isso, viado.

16:34 - Matheus
  Mano, tipo, tu pega uma semana...

16:37 - Valentino
  Não, não, não. Eu falo assim, como é que eu marco tanta reunião em pouco tempo, viado?

16:44 - Matheus
  Isso aí é bizarro, velho. Se tu tiver trabalhando pouco e tá marcando muita reunião, a gente dobra a meta, pô.

16:54 - Valentino
  Ontem nós saí do onboard. Aí, não lembro o que a gente ficou falando. Aí eu liguei, botei cinco reunião e aí já deu cinco horas, gente. Acabou já.

17:23 - Matheus
  Mano, é porque tu tá muito bom de prospecção, velho? E pegou o time que os caras atenderam, daí pegou o time também que tu tá bom. Um bom magabundo, né? Mano, tá. Daí o que que você fala assim, mano? Você olha, pô, a gente tem as calls marcadas, é agora? E aí lembra, mano, de marcar no mar? Sim. E... vou responder ela, vou falar que não necessariamente precisa... aí se não tiver mesmo tu marca na parte da tarde.

  Segura essa linha e aí tu pega o teu dia, seu dia de prospecção e dessas reuniões qual que tu consegue participar, mano. E aí eu participei, aí eu tô fazendo. E aí pô, se tu quiser tocar uma reunião pra tu se desenvolvendo também é só vai. Também às vezes tocar alguma que é desqualificada pra tu treinar.

19:02 - Valentino
  E é isso, mano?

19:04 - Matheus
  O que você acha? Sim.

19:10 - Valentino
  Mas eu não queria ser o Adriano, porque o Adriano não vai em call de vendas. Mas tu vai em call de vendas, não tem problema tu ir em call de vendas. O Adriano não gosta de call de vendas, eu gosto.

19:23 - Matheus
  Pois é. Não tem problema ser em call de vendas. A gente agora só tá masterizando o que cada um é bom. Você é bom em prospecção. Mas eu ainda não sou bom em vendas, mas eu tô começando a melhorar o fim. E daí, o que dá pra fazer? Pô, tu vir fazendo call de vendas também, mano. Pra ir melhorando. Você só vai melhorando as call de vendas a partir do momento que você for fazendo também. Tá bom?

  E aí, tu tem a meta. E aí, pra tu não ficar com o sentimento de que tu tá fazendo menos, eu coloco a meta pra você. E daí, fica no arrocho. E aí, eu te ajudo no futuro.

20:51 - Valentino
  [interlúdio]

22:36 - Matheus
  [interlúdio em inglês — possível ruído da transcrição]

24:14 - Valentino
  Clica nele, na linha. Clica no coisa, no Matheus ali, e no pontinho. No ponto azul ali, que vai.

25:48 - Matheus
  Aí puxa pra metas. Mas esse daqui ficou linkado ainda, vendo? Apaga ele então.

25:58 - Valentino
  Aí puxa do...

26:00 - Matheus
  Do ponto azul ali, tá grande, né?

26:29 - Valentino
  A gente tinha que definir de faturamento também, né?

26:33 - Matheus
  É, pô, a gente vai fazer. Nunca definimos meta. Deixa eu subir ali pro PC, mano, o que tá mesmo? Ai, tá pequeno. Com o computador aqui, vou colocar na tela grande.

27:42 - Valentino
  [ligação prospecção — Milena]
  Bom dia, Milena. Milena, Valentino, diretora aqui da L&M, tudo certo? Tudo ótimo, graças a Deus. Lembra que ontem eu falei que tinha evento, daí eu não ia conseguir ligar? Boa. Ok, tá bom. Obrigado, tchau, tchau.

29:15 - Matheus
  Acho que essa ideia é pra fazer com um IA, mano.

30:08 - Matheus
  Não sei, né? Testei aqui, velho. Comercial, prospecção, vendas, Matheus, Valentino. Melhorou um pouquinho, né?

31:33 - Valentino
  [ligação prospecção — Júlio]
  Bom dia, Júlio. Tudo bem? Aqui é o Valentino, diretor aqui da LM. Eu falei com o Rafael e o Luiz, e o Bernardo até participou de um dos nossos eventos voltado para a energia solar. E eu queria ver se o Rodrigo, o Fábio ou o Bernardo estão aí pra falar com eles.

32:00 - Valentino
  Ele é somente com o Rodrigo, Fábio e o Bernardo. O 0426, o final 0426, é de quem? Eu até sei que tenho o número do Bernardo, mas é difícil falar com ele por ligação. Ah, é o Rafael, é o número do Rafael aqui. E do Bernardo é 6495, né? Beleza. Eles ficam no home office só? E que dia eles ficam na empresa? Tá, fechou. Obrigado, Júlio. Vou ligar pra ele então. Tranquilo, zero problema. Fechou, querido? Valeu, tchau, tchau.

33:02 - Matheus
  Cara, se tu tem uma meta diária que é de 10, a tua meta, quando não tiver reuniões, de marcar webinars, agendamentos, é no mínimo 4. Beleza.

34:26 - Valentino
  Então, praticamente tu quer, deixa eu ver, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 reuniões. Se tiver 15 reuniões toda semana, 33%, então a gente fecharia em torno de 4, mano, 4 por semana, será?

35:03 - Matheus
  Ali é 15 reuniões para cada semana, semanais. É basicamente isso, né mano? Da minha meta diária, 3 call de venda e um fechamento.

37:52 - Valentino
  Isso com 0% de no-show, né? E 0% de... é real marcamento.

38:02 - Matheus
  Zero por cento de tudo. Não entendi.

38:11 - Valentino
  Mas se tem cinquenta pessoas... Se tem cinquenta preenchimentos... Provavelmente vai a umas vinte ou trinta. Será que a gente vai dar conta de quinze projetos mensais?

38:55 - Matheus
  Mas com 15, você vai pra contratar, né? Mano, assim, aqui a gente tá chutando algo pra caralho, 33% de fechamento. Pra ser dentro da realidade aqui, dá pra chutar dois, tipo assim, dois fechamentos por semana, mano. Então aqui, ó, seria dois fechamentos. Pra ser uma meta ok. E aqui, quatro semanas no mês, oito fechamentos.

39:36 - Valentino
  Jogando pra baixo, né?

39:46 - Matheus
  Mas, aliás, uns 15% de taxa de conversão, né? Tá, então vamos lá. Ficou a meta de faturamento mensal de 32k, mano.

41:11 - Valentino
  Me manda esse miro aí.

41:14 - Matheus
  O que que tu acha que falta aqui, mano?

41:46 - Valentino
  Esse aqui ficou muito massa, mano. De ontem.

41:57 - Matheus
  Acho que dá pra conectar aqui. Mano, agora a gente tem que fazer os cálculos dessa semana, mano. Eu acho que vai fazer isso só pro comercial, mano.

43:55 - Valentino
  Sei lá, mano. É que a gente vai ver quanto a gente consegue entregar.

44:01 - Matheus
  Coloquei em maio. Vou passar as metas agora pra três semanas de maio, vamos lá. O que que a gente tem? Metas de webinar, depois reunião agendada, depois reunião feita. E os follows de reunião você faria ou não faria? A reunião fácil, tá? Porque tu marcou, né, tá com a conexão com o cara, beleza.

  Tem três semanas. Tira semana 1 no caso. Pode pode. Ou então deixa semana 1, mano, porque aí a gente coloca que a gente fez um fechamento na semana 1. Aí na semana 2, vamos lá, puxa ali webinar, reuniões e fechamento. Vai sair três ganchinhos, tá ligado?

46:35 - Valentino
  Reuniões e o quê?

46:37 - Matheus
  Fechamentos, porque a gente tem que colocar meta de preenchimento, meta de reunião e meta de fechamento. Então vamos lá, webinar, então na semana 2, qual que é a meta que a gente colocaria pro webinar? 40 preenchimento. Quantos preenchimentos a gente já tá? A gente tem que colocar 40 preenchimentos a mais.

47:41 - Valentino
  Quanto tu acha que é bom a gente falar de comparecimento?

47:52 - Matheus
  Metade. Vou colocar metade de metade. 50%? 100%. Isso. A gente teria 20% daí já. E aí, mano, é reuniões. Essa semana que vem, deixa eu ver como é que tem reunião semana que vem. Tem duas reuniões de venda semana que vem, basicamente. Duas calls de venda. Cê acha que dá pra embarcar reunião de venda semana que vem?

  Eu não sei. Pós webinar? Não, antes do webinar, nesse webinar aí. Tem alguma coisa pra espremer reunião de venda? Deixa eu ver aqui minha pipe.

48:41 - Valentino
  Deixa eu ver o que eu tenho guardado na bolsa aqui. Hum, não dá não, mano. Tá seco.

48:55 - Matheus
  Pessoal que não foi no webinar.

48:57 - Valentino
  Todos esses daqui que tão aqui que... eu tô indo na tela, eu vou chamar pro webinar. Ah não, fechou. Aí disso vai vir, vai vir a galera.

49:16 - Matheus
  Tu, como é que tua pipeline, mano?

49:17 - Valentino
  Não faço ideia.

49:20 - Matheus
  Tem bastante coisa aqui. Aí, mano, como eu vou ter pouco tempo de prospectar, se tu quiser vir fazendo follow na minha pipe, vai ser. Ó, esse aqui foi no show, no show também.

49:53 - Valentino
  Tá pequenininha tua pipe.

50:01 - Valentino
  Dá pra ver aqui, mano, ó, acho que é aqui.

50:16 - Matheus
  Caralho, agora tem. Finalmente tem. Ah, não tem, né. Nunca tem. Mano, tá.

50:24 - Valentino
  Ó, 1820 leads meus e 643.

50:32 - Matheus
  É, vamos lá. Tu quer continuar com a meta de 10 por dia ou quer colocar pra 13? Porque tu tem meta de 10 mais 3 reunião marcada. Tu quer começar mais leve? Começar nos 10 ou começar nos 13?

50:53 - Valentino
  Começar nos 10.

50:56 - Matheus
  Reuniões. Reuniões não tem meta de reunião essa semana porque... e tem duas, coloca duas aqui, as reuniões que vai ter essa semana. São as duas que vai ter. Acho que vai ter mais. Mas como vai ter mais? Você não tem o webinar de agências, tem um solo de agência pra fazer, né mano? Não, então coloca aí pelo menos uma meta de dez reuniões essa semana semana que vem, mano.

  Aí dez eu já assisti muito, já sete. Então tá sete. Quantas reuniões por dia você tem que marcar? Uma vírgula três. Um e-mail por dia, coloca ali. E ali pelo menos um fechamento.

  Então, beleza. Esses caras aí. E aí, mano, vai ser muito importante tu lembrar de taguear essas pessoas, viu, mano? Taguear os preenchimentos, pra gente saber o que é qualificado e o que é desqualificado, mano. Ligado.

  Então, semana três.

52:26 - Valentino
  Semana três aí.

52:28 - Matheus
  Copia. Pode copiar tudo de cima aí, mano. Copia tudo.

52:43 - Valentino
  Caralho. Vou trouxer de novo, porque apagou a semana três.

53:00 - Matheus
  Copia só do webinar pra frente. Shift e copia. Aí vem e seleciona no 3 ali e cola. Ctrl Z. Cola aí, tá vendo? Uma merda. Bargulho feio da porra. Na moral, dá um Ctrl Z só. É, não sei se pra conectar. Puxa na setinha do mais ali, tenta conectar os mais ali. Não vai. É só clicar.

  E aí, na semana 4, as metas de cima, a mesma coisa na semana 4, basicamente.

  Tá, então, mano, a gente tem uma meta de no mínimo cinco fechamentos esse mês, né? Cinco fechamentos esse mês.

  Pô, mano, agora a despreparação de reunião de venda tá demorada, né? A despreparação de reunião de venda agora tá demorada. Por quê? Eu demorei uma hora para montar o doc de guerra do Carol, uma hora para montar o doc de guerra do Lazarento. Ele deu um show. Ele deu um show, vagabundo.

  [responde Caroline pelo WhatsApp]
  Bom dia, pessoal. Tudo bom? Caroline, eu coloquei a logo ali, só que acho que deu um bug na imagem. Acho que é só o bug visual mesmo, mas a logo está lá. E não necessariamente precisa aparecer a logo. Nos outros quesitos ali das imagens, está tudo aprovado pra gente rodar? Está dentro do que você esperava? Está tudo certo?

57:57 - Valentino
  Não está aprovado, Matheus. Não tem a foto.

58:08 - Matheus
  É, mano, uma vendinha ali. Mesmo de maio, né? Vamos buscar bater este daí, mano. Fazer este aí de qualquer jeito.

58:38 - Valentino
  Semana 2 é semana que vem, né? É segunda.

58:41 - Matheus
  Começa segunda, semana 2. Lembra que a semana 3 começa sexta, viu? Nossa semana começa na sexta. Pra você que vai ser na sexta pro preenchimento, né? Da semana que vem.

  Mano, agora acho que ficou bem legal, mano. Encerra o Fathom aí, manda a transcrição, mano. Cara confirmou reunião.

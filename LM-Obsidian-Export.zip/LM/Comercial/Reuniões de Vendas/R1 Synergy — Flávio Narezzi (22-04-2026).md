---
data: 2026-04-22
horário: 19h BRT
tipo: R1 (auditoria privada)
prospect: Flávio Narezzi de Oliveira
empresa: Synergy Soluções em Energia
participantes: Matheus Jardim, Valentino Pascual
duração: 37 min
status: R2 marcada para terça-feira seguinte
---

# Auditoria Privada da Synergy Soluções em Energia

> R1 que fizemos para vender para LM

**Resumo rápido:**
- Flávio é engenheiro eletricista, RT da empresa, tem 7 vendedores (1 fixo+comissão, 6 100% comissionados)
- Canais: indicação + prospecção ativa (porta a porta) + um pouco de tráfego
- Tem eletroposto próprio
- Dor principal trazida: manter a empresa aberta + briga de preço (autofagia do mercado) + gestão de equipe (CRM não preenchido)
- Cortou a apresentação pedindo praticidade: "fala logo o que vende, quanto custa"
- Fechou marcando R2 pra terça da semana seguinte

---

## 0:05 - Valentino
Um prazer imenso te conhecer, que bom te ver aqui no Nossa Cal. Matheus é meu sócio, a gente é diretores aqui da LM, e o título aqui, Flávio, é conhecer um pouco mais sobre a tua empresa, e como a gente conversou ali na ligação, é te ajudar no que tu precisa hoje. Tu falou que hoje teus vendedores, o teu time comercial não preenche o CRM. O que tu faz hoje para incentivar aqueles que preenchem o CRM, que eles sigam a cultura que tu quer implementar na empresa, e quais também são os seus canais de venda, além dessa pergunta que eu te fiz agora?

## 0:45 - Flávio
Cara, canal de venda, maioria por indicação, uma parte é lead via rede social, mas... A maioria hoje é indicação e prospecção ativa. Quando a gente fala venda, é o que se concretiza como venda, que se consolida como venda, que fecha contrato e paga. Então, a maioria dos leads que chegam por rede social não fecha. E uma parte dos leads que chegam via prospecção ativa ou por indicação, a gente fecha.

## 1:34 - Matheus
Legal, que legal. Basicamente, esses canais. Hoje você está, o Valentino até tinha confirmado, hoje você está com sete pessoas da equipe comercial, é isso mesmo? Você tinha falado com ele? Sim. Sete, né? Eu, vamos contar a todo mundo que vende.

## 1:57 - Flávio
O gerente, aí... Fernando, Diana, Daiane, mais uns dois ou três aí, Camila, Júnior, já são sete. É que tem muita gente que entra e depois sai, entendeu? Eu até esqueço o nome.

## 2:27 - Matheus
E eles são PJ, CLT, são parceiros, como que é hoje? Tudo, tudo PJ.

## 2:34 - Flávio
Legal, legal, legal.

## 2:37 - Matheus
E é sempre sendo comissionado ou fixo mais comissão? Como que vocês trabalham aí?

## 2:42 - Flávio
Uma delas é fixo, porque ela desenvolve outras atividades também, fixo mais comissão. Legal. E é a minha terceira contratação. Na verdade, é a segunda contratação. E os outros é tudo fixo, é tudo comissionado. Que legal, que legal.

## 3:15 - Matheus
Então a gente tá falando ali de umas três ou quatro pessoas ali que é fixo, mais comissionado, fixo e comissão e o restante comissionado ali. E uma pessoa fixo, mais comissão. Ah, os outros seis são comissionados, então. 100% comissionados.

## 3:30 - Flávio
100% comissionado. Vendeu, recebeu.

## 3:32 - Matheus
Legal, legal. E essas pessoas, a gente pergunta isso pra entender um pouquinho a mais como funciona a estrutura, como que é a operação, como se opera. Porque várias integradoras que a gente conversa e vê por aí, elas trabalham muitas vezes, as pessoas que são 100% comissionadas, muitas vezes ela não tá full time ali, tem outros desempenho, outras atividades por fora. Hoje, essas pessoas comissionadas aí com vocês, elas são full time, elas têm outras atividades... Como é hoje?

Cortou a ligação, eu não entendi sua pergunta. Basicamente, Flávio, hoje essas pessoas que são comissionadas, elas são full time ou elas têm outras atividades por fora? Como é hoje que você trabalha essas pessoas?

## 4:18 - Flávio
Alguns são full time, outros vendem outras coisas. Eu tenho o vendedor, por exemplo, que é corretor de imóveis também. Eu permito isso, o meu contrato permite, o meu contrato só não permite que venda a mesma coisa, mesmo produto. Mas ele pode vender quantos produtos ele quiser, na hora que ele quiser, do jeito que ele quiser.

## 4:40 - Matheus
Que legal.

## 4:41 - Flávio
Eu peço, peço, não que seja obrigação, mas eu só peço que venda pelo menos 100 mil por mês. Porque o cara tem que vender pelo menos sem conto, esse cara não vender sem conto, pelo amor de Deus. Vai tomar mais o seu tempo, né Flávio?

## 4:57 - Matheus
Vai tomar o tempo seu e o tempo da equipe para estar... Estar conversando para estar gerindo esse cara, comprando o cara CRM, comprando o cara as coisas?

## 5:07 - Flávio
Normalmente nem sempre vende. O mercado não está muito legal, taxa de juros está complicada, está restrito, etc. Mas é assim que funciona.

## 5:20 - Matheus
Total, total. E Flávio, você tinha falado que um dos seus garros, além da conversa com o Valentino ali, um dos seus problemas era a parte do preenchimento de CRM, anotações além de CRM. Além disso, tem alguma outra coisa que você gostaria de a gente estar conversando, de a gente estar tentando trazer uma ajuda para vocês, a parte de venda. Você falou que trabalha indicação, às vezes você já tem um plano de indicação, uma estruturação de pedir indicação. Como que está também a parte, você falou que tem a prospecção ativa, como que vocês fazem, se está no PAP, ou é ligação, ou é WhatsApp.

## 6:00 - Valentino
Até antes do Flávio falar, para que fique mais claro... Não chegou a participar do evento, né Flávio? Não. Vamos apresentar para ele um pouco, antes dele falar sobre a empresa dele?

## 6:09 - Flávio
Eu gostaria que seja um pouco rápido, porque eu tenho uma reunião mais tarde um pouquinho.

## 6:15 - Matheus
Você tem quantos minutos mais ou menos, Flávio?

## 6:20 - Flávio
Aproximadamente mais 20 minutos para começar a outra reunião. Tá, beleza.

## 6:25 - Matheus
Você quer que eu compartilhe aqui, Valentino? Vou olhar aqui, Flávio.

## 6:30 - Valentino
A pauta ali do webinar, que é o evento que a gente trouxe para integradores, foi semana passada, teve em torno de 100 pessoas, Flávio. E nesse evento, Flávio, a gente trouxe uma pauta onde, como vocês podem gerar demanda de clientes comerciais, Flávio, sem investir em anúncios, por meio de prospecção ativa, gerou uma demanda alta, pelo menos 100 oportunidades por semana de projetos comerciais. Dentro disso, falou de açougues, academias... As dores desses setores também, que tem uma conta de energia cara, por exemplo, e como você pode prospectar esses setores, isso não te gera custo, como implementar isso na sua equipe também, e a metodologia de trazer várias empresas em um evento só, no caso você trazer um evento, e que as próprias empresas te chamem para comprar de você, e o Matheus vai apresentar aqui para agora.

## 7:27 - Matheus
Show. Flávio, até para entender um pouquinho hoje, o teu comercial é PAP ou é ligação que você falou, prospecção ativa? O que é PAP? É porta a porta, que o pessoal fala nas integradoras. Porta a porta.

## 7:39 - Flávio
Cara, cada vendedor funciona de um jeito. Ah, tá. Ligação o que menos acontece. É, ligação é o que menos acontece, entendeu? Porque a ligação hoje, cara, essas pragas desses telefones de spam, velho, tá um inferno isso aí, nem consegue mais sobreviver. Aí o cara simplesmente... Ele não atende mais quem ele não conhece. Ele já até cadastra o celular dele para nem tocar.

## 8:06 - Matheus
É verdade. Muitas vezes é assim mesmo. Mas daí, Flávio, eu vou trazer aqui brevemente o resumo do que a gente trouxe ali no evento dos empresários. Dentro desse evento teve integradoras, teve empresas de mão de obra, teve empresas de mercadoras de energia, teve empresas de geração distribuída.

## 8:23 - Valentino
A gente trouxe... De painéis solares que participaram.

## 8:26 - Matheus
E daí, Flávio, eu vou estar olhando para cá porque os meus slides estão aqui. E daí, um dos topos que a gente trouxe é que... Isso daqui é uma pesquisa de mercado. Se você quiser, depois a gente te manda essa pesquisa de mercado ali também no teu WhatsApp também. A gente manda as referências que a gente pegou, tirou esses dados.

Em média, 96% das unidades consumidoras do Brasil hoje, elas não geram a própria energia. Então, o mercado, muitas das vezes, ele não está saturado. Ele está mal trabalhado. Então, eu vou ser bem sucinto na explicação, vou passar bem rápido. Não vai ser uma riqueza de detalhes que a gente traz no evento, por conta do tempo que a gente tem ali, que é mais curto.

E aí, Flávio, dentro disso, a gente tem a amostra da prospecção genérica que a gente trouxe, que o contexto, ele substitui o esforço bruto, ele substitui o trabalho braçal, digamos assim, aquele trabalho bruto. Porque no modelo antigo, você investe em anúncio hoje, Flávio, só para me entender, você falou que chega cliente... Anúncios, sim.

## 9:31 - Flávio
Um pouco, sim, mas é mais para fixação de marca e um ou outro. Cada campanha hoje, vamos supor que eu vou fazer uma campanha de 15 dias aí, ela rende duas vendas, três vendas, ela já rendeu 20, entendeu? É, eu só chamo o cara que quer preço. Preço. A não ser que eu faça uma campanha focada só em preço. Se eu não fizer uma campanha focada só em preço, é difícil vender pela rede social.

## 10:18 - Valentino
É muita comparação ali de orçamento e até a gente traz esse evento como uma solução para essa questão de comparação de preço, perder clientes por nem que seja 500 reais a menos do orçamento. O cliente residencial vai lá e escolhe o menor valor ali.

## 10:35 - Matheus
Com certeza. E aí, Flávio, dentro do evento a gente trouxe um modelo antigo, que vem tráfego pago, cada vez mais caro, lead frio. Então o cara que te chama através dos anúncios, ele vem e pede orçamento para você e para mais cinco pessoas. E aí quem paga, quem tiver o orçamento melhor, leva. É como se fosse um leilão realmente ali. Tô-lhe uma, tô-lhe duas, tô-lhe três e pulei... Briga de porquê... R$500 a mais, a menos, igual Valentino falou.

Dependência de indicação, cada vez mais as empresas ficam dependentes de indicação, e tem mês bom e mês ruim, o mês acaba que vira uma loteria por conta da indicação, quando a indicação vem, você fecha, quando não vem, o teu faturamento cai, isso daí é muito perigoso, acaba virando uma roleta ali.

E aí a gente trouxe nesse evento a prospecção estruturada, que é um CAC próximo a zero, lead qualificado exclusivo, porque somente você tá indo atrás daquele lead, dificilmente outras empresas tá indo, dificilmente quando o Facebook ele funciona assim. Aqui a gente já investiu mais de 8 milhões só em anúncio pra outras empresas, então a gente tá falando isso, porque a gente já viu isso se repetir várias e várias e várias vezes, que é o que: o cara quando clica no seu anúncio, ele pode nunca ter pesquisado energia solar, mas quando ele clica no teu anúncio, ele te chama no WhatsApp, e quando ele volta com o Instagram, o Facebook, ou seja, ele começa a rolar, aparece 3, 5 anúncios de outras empresas, porque quando ele clicou a inteligência, algoritmo entendeu que ele tem interesse, e aí entrega de outras pessoas.

Então tu começa a brigar por preço, e daí o lead que você vai atrás com a prospecção ativa estruturada é um lead exclusivo, ninguém tá brigando por esse lead, ele muitas vezes não tá procurando ainda energia solar, mas tu consegue trazer uma conscientização ali, e daí você vende por valor e não por preço, você vende por aquilo que você entrega, aquilo que agrega no usuário, no cliente final, no cliente residencial, no cliente comercial.

## 12:37 - Valentino
Querendo ou não, Flávio, até te cortando, perdão, Matheus, o cliente residencial vai comparar preço, porque ele não tem, ele não tá pensando no futuro, ou nos colaboradores, por exemplo. Agora você pega um cliente comercial, o cara vai calcular se pode colocar no teto dele, no telhado, se vale a pena, se vai ter um payback bom pra ele, porque senão não. E aí, ele não compara preço, ele compara qualidade, e se você tem qualidade, ele vai comprar de ti, mesmo que seja mais barato, é mais caro.

## 13:07 - Matheus
E daí, Flávio, hoje você trabalha com híbridos com armazenamento ou ainda não, Flávio? Não forneci nenhum ainda. Mas você já tem a opção de estar entregando, né? Sim.

## 13:19 - Flávio
Legal, mas a conta ainda não fechou para os clientes. Os clientes estão ainda falando só em custo de bateria, custo, custo, custo, custo.

## 13:33 - Matheus
E como hoje, Flávio, eu não sei se é assim que vocês estão abordando. Mas uma abordagem muito interessante para trazer, para estar trazendo a venda desse híbrido com armazenamento, nem que seja o híbrido e depois trazer a bateria para estar plugando no híbrido ali, principalmente clientes comerciais, é tu fazer um, não vender aquele payback padrão ali, pô, economia de energia em tantos anos ali, você vai conseguir ter o retorno. Mas sim a possibilidade dele não perder, vamos supor, um cliente que tem uma sorveteria e a rua dele falta energia uma, duas vezes por mês, cada vez faltou uma hora, cara, aí você vem e fala com ele, fulano, quando falta energia aqui, você perde materiais, você perde produtos, como que é? Se o cara perde, você consegue estar trazendo uma conta de payback de quanto ele está deixando de perder.

E aí quando ele perde um produto, um açougue, por exemplo, se faltar energia por muito tempo, perde carnes, perde qualidade dos alimentos dele ali, e aí você consegue trazer uma conta que é mais que segurança, isso, é uma conta que ele vai deixar de perder. Então, um supermercado, por exemplo, se cair a energia, ele para de perder, o PDV não roda, então você vende para ele uma segurança de sempre estar rodando.

E é até legal, Flávio, trazendo até uma dica aqui, muitas empresas estão fazendo é trazer o armazenamento para apartamentos, você já viu essa linha? Já. Então é bem legal, é bem legal você trabalhar.

E daí até continuando aqui nos slides, a gente traz ali, através da prospecção ativa estrutural, uma previsibilidade mensal, então você tem métricas ali que te traz um indicativo de quanto você vai faturar mês a mês, e um pipeline construído de oportunidades ali para você estar trabalhando mês a mês.

E depois disso, Flávio, o custo de aquisição está matando as margens das empresas. Por quê? O CPL, o custo da energia solar lead qualificado, muitas vezes passou de 50, 80 reais a depender da região. Realmente muito caro. E daí, pensa só, você paga 50, 80 reais no lead, e o cara pede orçamento para você e pede orçamento para outras cinco empresas. E aí, a briga fica em 500 reais por preço.

E daí, pensa só, o dia que essas empresas que investem em anúncio perderem o CPL, dobrar, começar a ficar insustentável cada vez mais, da onde que essas empresas começam a tirar cliente? Da onde você vai começar a tirar cliente? Então, muitas das vezes, quando você investir nas campanhas de tráfego, igual você vinha 20 clientes, era uma maravilha. Mas daí, quando começou a reduzir para 3 clientes, você teve que pensar em outros canais ali para estar conseguindo suprir esse volume. Porque querendo ou não, quando chegava 20, você tinha um tanto de conta, mas aí começou a chegar a 3, as contas continuam. E para reduzir custos é um processo lento, mas para reduzir faturamento é de um dia para a noite. Então isso daí acaba mexendo muito na saúde da empresa, no geral.

E muitas vezes, vem a parte do fio B ali também, que vem comendo margem. Diferenciação, você vai ser mais um integrador ali... E muitas vezes, quando você briga por preço, você espreme sua margem, e quando você espreme sua margem, tua empresa deixa de ter a lucratividade que ela tinha. E daí, muitas pessoas, vamos supor, muitas pessoas que trabalham com instaladores nas integradoras, elas saem das integradoras depois de ter um nível de consciência maior, ou até mesmo como trabalha de vendedores, ele é um bom vendedor, ele sai e começa a vender para ele mesmo. E às vezes, muitas vezes, as pessoas vendem com a margem baixinha para ganhar só na instalação e passam o produto com os painéis ali por custo. E aí, como você briga com um cara desse? Como você briga com uma margem apertada desse? Você tinha de várias pessoas, carro, equipamento, aluguel de loja, acaba ficando insustentável. E essa briga acaba ficando desleal para a pessoa.

## 17:53 - Flávio
Eu chamo de **autofagia do mercado**. O setor de ar condicionado passou por isso. E a gente está começando a passar por isso. Se o mercado não se proteger de alguma forma, a gente vai quebrar.

## 18:08 - Matheus
Sim, porque é muito perigoso, né Flávio? Porque entre pessoas, a gente aqui no mercado digital, muitas vezes a gente viu muitas agências quebrarem, porque pessoas que estão entrando agora no mercado sem experiência nenhuma, acabam vendendo muito barato serviços. Serviços que, cara, não tem condição dele vender um preço daquele. Eles acabam vendendo porque não tem equipe, não tem estrutura para pagar por trás, e aí acaba que, fazendo um comparativo, são mercados totalmente diferentes e opostos, mas ocorrem com os mesmos problemas ali.

## 18:41 - Flávio
Oi? Ele está lá no lugar. Ah, beleza. Obrigado. Oi, desculpa.

## 18:47 - Matheus
Tranquilo. Aí, Valentino, você ia completar alguma coisa?

## 18:49 - Valentino
E aí, Flávio, o intuito do evento é trazer justamente a gente mapeçador no mercado de solar, viu que tem muitas empresas perdendo clientes por conta de diferença no orçamento. Dificuldade para trazer mais clientes comerciais, trazer clientes comerciais, híbridos com bateria, que é algo novo também, e a gente está começando a trazer a pauta de eletropostos também. É uma forma de você vender para quem você já tem de cliente, ou você vender para um novo cliente, um açougue. Eletropostos não, na verdade, postos de gasolina. Ou clientes finais, por exemplo, CPFs, que podem comprar um terreno e colocar numa rodoviária. Então a gente está começando a trazer essa pauta.

## 19:34 - Matheus
Você já chegou a ouvir, já chegou a pensar em trabalhar com esse segmento também, ou ainda não, Flávio? Qual segmento?

## 19:43 - Flávio
Dos eletropostos.

## 19:45 - Matheus
Eu já tenho um.

## 19:46 - Flávio
Legal, que legal, que legal.

## 19:48 - Matheus
É você mesmo ou instalou para cliente? Meu, meu, meu. Inclusive, Valentino, foi... Eu, eu...

## 19:56 - Flávio
Pode falar. Pode falar. Alguém próximo, né?

## 19:58 - Matheus
É... Estava tirando um bom faturamento com eletropostos que você tinha comentado.

## 20:04 - Valentino
Sim, Solar Sinop foi inclusive uma empresa que participou do evento, deixa eu ver aqui, vou mostrar para vocês, essa empresa aqui, Solar Sinop é do Amilson, e eles estão trazendo essa pauta ali dos eletropostos para clientes deles, e está dando bastante resultado para eles, inclusive.

E aí, Flávio, voltando ali para a questão da tua empresa, além da gestão do teu time, manter eles e tudo mais, que foi a última pergunta que a gente fez para ti, o que está sendo um desafio para você?

## 20:45 - Flávio
Cara, basicamente **manter a empresa aberta**, bem claro. Porque hoje eu tenho muitas obras a serem entregues, três obras grandes que... E teve problema de Energiza, de concessionária, etc. E eu tenho que manter uma despesa um mais alta para a empresa em um cenário de menos venda. E além de menos venda, eu concorro com esse pica-fio aí que você falou que estão vendendo com margem baixinha achando que vão ganhar dinheiro. E o mercado está se matando.

Na verdade, o mercado está se matando. Então, agora, esse ano, vai selecionar mais um monte. Vão ficar as eficientes, mas as honestas, as que sabem fazer, sabem executar direito, que normalmente é muito mais caro executar direito do que executar de qualquer jeito, elas vão sofrer, que é o que acontece comigo.

Eu estou sofrendo isso. Por quê? Eu concorro com quem faz totalmente errado. Eu sou engenheiro eletricista, eu sou responsável técnico da empresa e eu muitas vezes tenho um tipo de público que eu não consigo vender valor, porque o cara só pensa em preço.

Eu entendo o que vocês estão falando. Vocês estão falando, ah, tem que pensar em valor. Beleza, eu entendo isso daí. Só que tem um tipo de público que eu não vou vender valor nunca, porque o cara só pensa preço. Aí, para esse cara, eu tenho algumas estratégias, algumas coisas estão funcionando, só que eu ainda não consigo pegar todo mundo. Então, eu estou com um certo sofrimento de mercado aí, que é normal, entendeu? Normal. Isso faz parte do processo.

Meu problema é crédito muito caro, que nem você nem ninguém consegue resolver. Eu não sei quem troca esse governo aí. Quando tiver essa merda, a gente não tem... E Lula, esses caralhos, essas bostas, isso é bosta.

## 23:07 - Valentino
Tenho fé que vai dar certo esse ano, Flávio.

## 23:10 - Matheus
Oi? Só vem pra lascar o empresário, né?

## 23:14 - Flávio
Não, não é nem empresário, é todo mundo, cara. É assim, olha a inflação do jeito que tá e cada vez pior e taxa de juros altos. Isso aí, tipo assim, é uma... Assim, eu fico impressionado que tem gente que ainda acredita e etc. Mas não vamos falar disso porque isso é perda de tempo. Sim, total.

## 23:40 - Matheus
Vamos falar da redução. Eu queria trazer pra vocês aqui, pra você também, inclusive, até trazendo uma análise de mercado, você já chegou... Eu queria trazer contigo aqui uma análise de mercado e avaliar o mercado pra ver como que tá o mercado na sua região, em Tangará da Serra aí, no Mato Grosso. Eu não sei se você conhece essa ferramenta, até saindo um pouquinho fora, Valentino, aqui, onde a gente depois pode estar voltando, porque isso é uma das coisas que a gente faz e gosta de trazer para os empresários. Deixa eu compartilhar a minha tela aqui, porque eu primeiro queria saber, você já teve acesso a essa ferramenta aqui, que é da ANEEL, que é a Agência Nacional de Energia Elétrica? Esse BI deles?

## 24:28 - Flávio
Antes eu acessava, mas aí não... Perdeu um pouco o sentido depois.

## 24:34 - Matheus
Por que que você não... Você disse que perdeu um pouco o sentido? Eu estou olhando aqui para o lado, porque eu estou colocando o endereço de vocês. Porque eu preciso entender o que exatamente que você quer me mostrar.

Ah, porque, Flávio, a gente está querendo ver aqui, basicamente, a análise do consumo de energia na região. A gente vê como foi em 2025. A gente viu que 2024 foi o pico das instalações e 2025 teve uma retraída, mas ainda assim, 2025, um ano muito bom comparado ao outro ano, que vinha em uma crescente, 2025 teve uma retraída.

E aí a gente veio analisar a classe de consumo. E nessa classe de consumo, a gente vê que tem pouquíssimas oportunidades para explorar dentro dos comerciais. E é justamente isso que a gente vem trazendo, principalmente no nosso evento. Eu queria trazer pra você porque, de residencial, tem muito mais lugares pra serem trabalhados. Mas aqui, em termos de percentualidade, tem pouquinho trabalho aqui.

O que a gente vê em 2025, em 2026 normalmente não está tão atualizado. Em 2025, deixa eu ver quantos foram os comerciais aqui, 67 comerciais, frente a 1597, então é percentual muito pouco a ser retrabalhado dentro da sua região aqui.

## 26:20 - Flávio
Mas esse número, ele não reflete a realidade, porque aqui é muito comum a gente ter comerciais alugados, e o empresário ele instala na casa própria ou no sítio, na chácara, e transfere a energia para o comercial, porque ele não quer instalar no comercial.

## 26:46 - Matheus
Legal, legal, legal. E daí, Flávio, a gente vem trazendo, inclusive nessa análise, também faz todo sentido. A gente concorda com você que isso é uma prática normal no mercado mesmo. E dentro do nosso evento, a gente vem trazendo...

Para vocês começarem a parar... Eu estou olhando aqui porque eu estou colocando a apresentação dos slides agora, para voltar na linha de raciocínio, para a gente começar a parar de brigar por preço, principalmente na área do solar, a gente tem que se diferenciar, e se diferenciar é parar de vender para todos, para todo mundo, e começar a trazer segmentos específicos, porque quando cada vez mais você entende do mercado das pessoas, entende do negócio das pessoas, você começa a se portar perante elas ali como uma referência.

Exemplo, quando você começa a trabalhar em um segmento específico, vamos pegar supermercados de exemplo, ou postos de gasolina que seja, quando você começa a entender profundo ali sobre o negócio da pessoa, quando você chega para abordar em uma prospecção estruturada ali, por exemplo, você consegue conversar com aquele empresário de igual para igual, sabendo as dores deles, sabendo, por exemplo, que o supermercado tem uma margem de lucro baixíssimo. Então, se você consegue estar ajudando trazendo uma baita economia na energia solar, a margem de lucro dele vai subir bastante, e a margem de lucro subindo ele tem duas opções, ele tem ou ele tirar um pró-labore maior ou baixar o preço e conseguir ganhar na concorrência dos produtos.

E daí você consegue trazer uma comunicação muito mais assertiva e uma facilidade, e aí você para de vender preço e começa a vender valor, e aí você sai do cliente residencial que você traz o valor para ele, que ele olha muito mais o preço do que o valor, aí você começa a sair fora desse cliente, e aí você consegue vender o valor realmente, que aquilo que o seu trabalho realmente vale, aquilo que o seu trabalho realmente entrega, que muitas vezes os pica-fios, ele não tem uma qualidade de serviço ali.

E aí, Flávio, até sendo mais sucinto e mais rápido aqui para a gente aqui, hoje, basicamente, como que funciona a prospecção ativa estruturada? É um motor de autoridade ali, que você traz uma definição de nicho para estar abordando, vamos supor, escolhe segmento por segmento, entende o mercado, Flávio? Então, maneira profunda ali daquela pessoa, traz ali uma prospecção da pessoa, em vez de trazer uma prospecção genérica, você faz um convite para ela, depois você traz um evento ensinando, que é o evento que a gente até trouxe ali ensinando os empresários, e depois você traz um diagnóstico para estar vendendo para aquelas pessoas ali, traz um diagnóstico, uma visita, e por aí vai.

E daí, Flávio, dentro dessa prospecção ativa estruturada, é um pouco desse resumo do que foi o evento, bem rápido ali, bem sucinto, porque você falou que tinha que sair, estava um pouco na correria, tinha uma outra reunião. Imagino que você já está até no horário de ir para outra reunião, e Flávio, a gente aqui, a gente não conseguiu, não teve o tempo de realmente, de falar um pouquinho mais como que a gente poderia te ajudar, trazer uma proposta para vocês ali, e ver se você está aberto realmente a ter a nossa ajuda para dar o próximo passo, para estar cada vez mais saindo dessa briga por preço, começar a vender mais valor, trabalhar o seu comercial. Porque você falou ali que muitas vezes o problema de vocês aí, hoje, é manter a aberta, então para manter a aberta, a empresa precisa de vendas para ficar aberta, então a gente entende ali que basicamente um pouco de vendas também, é mais ou menos isso ou eu fiquei...

## 30:22 - Flávio
Sim, mas assim, vamos lá, **a gente precisa ser mais prático um pouco**. Eu preciso entender, o Valentino falou, eu preciso te perguntar qual é a sua dor para eu saber o que eu vou te vender. Beleza, eu entendi e falei minha dor. Eu tenho outras dores relacionadas à operação, mas aí, gestão de pessoas, são outras questões. Gestão de caixa, etc., mas é outra coisa.

## 30:55 - Valentino
O que que eu preciso? Eu preciso que você me diga agora, você já sabe minha dor...

## 31:00 - Flávio
A principal, eu preciso ouvir proposta agora, ver como você cobra, como é que funciona, o que você oferece, etc. É isso, basicamente é isso. E assim, sendo bem prático, tem um monte de gente que fala, fala, fala, fala, fala, e na hora de colocar preço e tal, não faz sentido. Sim, por isso que falo, às vezes fala logo o que você vende, fala quanto custa, para a gente ver se faz sentido. Porque se não fizer sentido, a gente já não precisa continuar, eu não preciso gastar meu tempo e o tempo de vocês para isso.

## 31:35 - Valentino
E quando tu fala dessa forma, o que eu vejo que é um exemplo até nosso, que todos os empresários têm que se validar, têm que se mostrar sempre que conseguem resolver o problema do cliente, eu vejo que tu conseguiu fazer isso no teu trabalho também.

E Flávio, falando agora sobre a questão que você trouxe da tua dor, que é basicamente... A inteligência de equipe, eu vou te contar um pouco o que a gente faz para reter os nossos colaboradores que também são 100% comissionados e o que a gente faz na cultura do dia a dia para mantê-los também.

A gente pode trazer ali um projeto em relação a isso. O que a gente faz, a gente chama isso de **dailies**, onde no início do dia a gente separa pelo menos 30 minutos para a gente falar o que a gente vai fazer durante o dia, estipula metas e não são metas gigantescas, são metas diárias, o que pode ser feito dentro de um dia. Por exemplo, para ligações que funcionam para a gente, estipula uma meta de 100 ligações por dia e pelo menos 10 reuniões por dia também.

A gente faz esse complemento na parte da manhã, a gente conversa com o time inteiro, analisa o que eles fizeram no dia anterior e a gente parte para o dia. A gente já entra ali às 8 horas, começando a prospectar as empresas, empresas de energia solar. 11 horas a gente volta com a equipe e vê se eles conseguiram bater a meta na parte da manhã. Por quê? Caso a pessoa não tenha conseguido bater a meta na parte da manhã que você estipulou, por exemplo, prospectar cinco pessoas presencialmente, porta a porta. Você estipulou uma meta e quando a pessoa é 100% comissionada, a meta dela é fazer isso. É cinco empresas, cinco residências para ela prospectar.

Bateu a meta? Não. Por quê? O que aconteceu no processo? Não conseguiu chegar? Ficou muito tempo com o cliente? Você vai acompanhando essa pessoa. Chegou o final do dia, cinco horas ali, você volta com a equipe e vê se o dia rendeu. Conseguiram bater as dez reuniões? Conseguiram chegar nas cinco reuniões porta a porta? As visitas? Conseguiram? Não. Por que não conseguiram?

Ah, tomei muita rejeição. Na hora de prospectar, o pessoal não estava ali, o decisor, o responsável não estava lá. Como a gente pode resolver isso? E você traz esse questionamento para eles, para você também treinar eles a pensarem em resolver futuramente, entende?

Questionamento? Então, tá, por que que eu não consegui falar com tanto dono, por exemplo, de uma academia? Eu não pensei em um horário que eu poderia ter ido lá, que o dono estaria, por exemplo, 5 da tarde é bom horário pra falar com o dono de academia. Não mapei o horário exato pra eu falar com ele. E isso foi o gargalo do dia. Isso fez eu não marcar as 10 reuniões que eu poderia ter marcado.

Então, amanhã, no início do dia novamente, a gente volta e pensa, tá, João, por que você não bateu a meta ontem? Porque não foi o horário correto. Então, hoje a gente vai acertar. Eu entendi.

## 34:30 - Flávio
O que você faz, na verdade, é o que a gente chama de **gestão de projeto agile**. E é isso aí.

## 34:40 - Matheus
Aí, Flávio, até trazendo de forma um pouco mais resumida o que você entenda, a gente entra na tua empresa e ajuda e faz com que o time comercial performe mais do que ele performa hoje. E é independente do que precisa ser entregue. Tem times comerciais que precisam de quê? De acompanhamento deles, igual você falou aí, o Valentino falou, deu o exemplo de como funciona. Tem times comerciais que precisa de estruturação de um novo canal de aquisição de leads, pô, seu time faz, como que seus vendedores hoje estão prospectando de forma ativa? Qual que é a melhor maneira de fazer isso? Como que a gente pode melhorar a produtividade para eles? Tá, beleza.

## 35:16 - Flávio
E aí, eu entendi as possibilidades, agora eu quero, ou a gente marca outro dia, ou vocês falam o que que é.

## 35:25 - Matheus
Não, show de bola. Flávio, o que a gente pode fazer? Hoje você tá na correria, você tá em cima do horário ali. A gente pode estar marcando um outro dia pra se sentar e bater um papo de 20 minutinhos, e daí a gente pode estar agendando e a gente formula uma proposta baseada na sua situação atual. Na eficiência do teu time. No seu time atual. Pode ser?

## 35:48 - Flávio
Então, vamos marcar um outro dia, então, aí a gente volta a conversar.

## 35:52 - Matheus
Essa semana fica tranquilo pra ti ainda, ou tá mais errado?

## 35:58 - Flávio
Melhor nesse horário. Amanhã nesse horário pode ser? Amanhã eu não consigo, como vou conseguir semana que vem, terça-feira.

## 36:06 - Matheus
Terça-feira nesse horário? Pode ser, então a gente fica firmado ali. Pode ser, Valentino? Sim, terça-feira está ótimo para mim.

Perfeito, então a gente traz uma proposta para ti, formula como que a gente vai entregar o seu projeto, fechou? E aí a gente acerta a barriola. Agora se a gente falar, você vai estar na correria, para ir para a outra reunião, vai guardar o preço, nem pensa direito. Então é melhor a gente sentar com calma e bater um papo. Show de bola? Combinado.

Combinado, então, Flávio. Abraço. Boa quarta-feira e ótima próxima reunião.

## 36:36 - Valentino
Flávio, prazer em conhecer.

## 36:37 - Flávio
Boa. Até mais. Até mais. Tchau, tchau.

---
data: 2026-04-23
horário: 11h BRT
tipo: R1 (auditoria privada)
prospect: Artur Cinco Reis Quintas
empresa: Asafe Energia Solar
participantes: Matheus Jardim, Valentino Pascual
duração: 57 min
status: parcial (transcrição truncada)
---

# Auditoria Privada da Asafe Energia Solar

> Outra R1 para vender para LM

**Resumo rápido:**
- Artur é estrangeiro (África), veio pro Brasil via vaga da USP, formou Engenharia Elétrica
- Trabalhou na 4ª maior empresa de fotovoltaico do Brasil como instalador → engenheiro
- Sociedade anterior deu errado (perdeu R$300k), abriu Asafe há 30 dias sozinho
- Sem capital, escritório na casa, fatura ~3 projetos/mês (R$10k a R$25k cada — residencial)
- Sem equipe, faz tudo sozinho (engenheiro, vendedor, técnico, financeiro)
- Tem eletroposto próprio
- Sem experiência em prospecção/vendas, quer aprender
- Sentiu-se conectado pela história e energia positiva apesar das dificuldades

---

## 0:00 - Valentino
Oi, Artur, tudo bem?

## 0:03 - Matheus
Tudo bem, graças a Deus, e você?

## 0:05 - Artur
Prazer imenso te conhecer, Artur. Prazer, meu amigo, prazer. Esse aqui é o Matheus, é meu sócio. Que legal.

## 0:13 - Matheus
Tudo bom, Artur?

## 0:14 - Artur
Tudo bem, meu amigo, e você? Tudo jóia.

## 0:18 - Matheus
Que bom. Prazer falar contigo. Prazer, tudo bem, meu amigo.

## 0:22 - Artur
Eu, inclusive, tô em um lugar, fiz uma mudança do meu escritório, então, ainda tô arrumando as coisas. Acho que eu te contei, aí, não sei se eu te contei. Então, não sei se vocês tão me vendo bem, eu peguei uma posição que eu sou, né?

## 0:38 - Valentino
Não, estamos te vendo perfeitamente, Artur. O intuito aqui, a gente conheceu um pouco mais sobre você. Eu conversei ali contigo no WhatsApp, e tu me falou que tem... Tu atende ali em torno de três projetos por mês, que iniciou recentemente empresa, tá procurando saída operacional também, que você é mais engenheiro do que... E eu queria entender um pouco mais também, Artur, o que está sendo a trava hoje para ser mais vendedor, que é o teu objetivo hoje? Isso.

## 1:11 - Artur
Antes disso, né? Só queria avisar que, olha, eu não sei quanto tempo pode demorar essa reunião, porque eu tenho mais ou menos 30 minutos.

## 1:21 - Matheus
Pode ser sim.

## 1:22 - Artur
11h40, vou ter uma outra reunião. Não sei se é até lá o que vocês têm para me falar. Ah, beleza. A gente conversa até 11h40, então. Pode ser? Pode ser, pode ser.

## 1:36 - Valentino
Hoje, Artur, até apresentando um pouco sobre a gente, a LM, ela é focada em performance em vendas, justamente na área comercial. Nos últimos dois anos, a gente gerou mais de 8 milhões de resultados para os clientes. E nos últimos 30 dias, inclusive, Artur, eu sozinho aqui, marquei mais de 100 reuniões com empresários, aqui para a nossa operação. E eu vou te mostrar aqui na tela, só um minutinho. Deixa eu ver aqui.

## 2:10 - Artur
Vou te mostrar aqui na tela, Artur, para você ver.

## 2:15 - Valentino
Aqui. A gente pode ver que nos últimos 30 dias a gente conseguiu marcar 117 reuniões com empresários, donos de empresas de energia solar, só nos últimos 30 dias. E a gente vem trazendo justamente isso no evento que a gente fez semana passada. Como é que vocês podem gerar demandas para vocês de clientes comerciais a custo zero, né? Por meio de prospecção ativa. Então, a gente tem bastante conhecimento nessa área de prospecção ativa. A gente liga e a gente ensina empresários também a venderem para comércios, por exemplo, açougues, academias, muitos setores que existem que podem ser vendidos para comércios também.

## 2:59 - Artur
Entendi. Sim.

## 3:00 - Matheus
E daí, Artur, o bom de trabalhar com essa parte de clientes comerciais é que o teu ticket médio, ele sobe muito. Então, o valor do projeto que você fecha, depois você está fechando o projeto em média, de quanto por projeto? É projeto residenciário. E gira em torno de quanto ali, mais ou menos?

## 3:21 - Artur
É projeto de 10 a 25. Legal.

## 3:27 - Matheus
E a gente sabe que o comercial, o projeto do comercial, é projeto de um ticket maior. Então, R$35.000, R$40.000, R$100.000, até R$100.000 para cima, dependendo do negócio.

E daí, Artur, pensa só. Você trabalhando hoje com um ticket de 10 a R$25.000 ali, fazendo três vendas, é um patrulhamento X. Mas se você estivesse trocando essas três vendas do residencial por três vendas comercial, cara, você poderia estar duplicando, triplicando ali o valor que você está conseguindo vender no mês.

Então, isso daí se encaixa muito. Principalmente na tua realidade de hoje, que a gente entende que você é uma equipe mais reduzida, que teve aquele probleminha com o teu sócio, que você, se você quiser se sentir aberto pra falar, você pode até falar que a gente tá super aberto pra te ouvir, pra entender como é que foi, porque a gente sabe que um momento como esse não é fácil pra toda, não é fácil pra ninguém.

Então, reestruturação do zero, começo de empresa do zero, é realmente algo que é desafiador, realmente. Principalmente a gente olhando pra você e você falando pra gente, pô, eu não era da área de vendas, eu era mais na área técnica, então o desafio acaba sendo maior ainda, porque a parte de vendas, ela tem um quê a mais de entender com pessoas, entender as pessoas, ver a pessoa do outro lado, ter empatia, entender no negócio das outras pessoas. Se conectar com elas pra conseguir vender.

Então, tem todo um processo pra você conseguir fazer uma venda. E não é só a venda, é também a geração da demanda para você converter em venda, onde que você vai achar as pessoas, como que você vai achar as pessoas, como que você vai achar as pessoas certas que vão poder te pagar mais. Então sempre é uma construção de aprendizado que você vem trazendo ao longo do tempo ali, que você vem construindo, igual todo início sempre é muito desafiador.

E a gente aqui, a gente separou esse tempo realmente para te ouvir, para entender como que está hoje você, se você quiser contar um pouquinho como que foi o seu negócio, como que foi essa separação, como que está sendo esse momento tão desafiador para você mesmo. Que daí a gente pode vir trazendo isso, trazendo para uma parte, como que você pode estar gerando a sua demanda, trazendo para você como que você pode estar atrás desses clientes que pagam mais. A gente queria entender também um pouquinho de você também, como que você está chegando a esses clientes para fazer dois, três fechamentos por mês. Porque talvez não seja interessante de momento trazer um novo jeito de você trazer clientes, mas talvez seja interessante a gente trazer um jeito de potencializar aquilo que você já vem fazendo, potencializar aquilo aí acaba sendo mais tranquilo.

## 6:13 - Valentino
Ou uma nova forma de você vender e uma forma que você sente confortável em vender e tirar uma trava que de repente você tem hoje e te ajudar a vender mais, ser mais comercial e igualar entre operacional e comercial. Por exemplo, o Matheus é mais operacional e eu sou mais comercial, por exemplo.

## 6:34 - Matheus
E Artur, hoje me explica um pouquinho mais como que vem os seus clientes, de onde vem esses dois a três fechamentos de LinkedIn, de projetos que você fecha por mês. Se você quiser dar um overview de como foi, como está sendo esse início, a trajetória, as suas dificuldades que você está tendo hoje, que a gente pode vir conversando e te ajudando em cima disso. Entendi.

## 7:00 - Artur
Então, só para entender primeiro, vocês são uma empresa de venda, não é? É isso? Isso, isso mesmo. Uma empresa comercial.

É, beleza. Entendi, que bom. Eu já conto uma breve história para o Valentino, que eu tinha uma empresa e essa empresa estava com um sócio meu, estava perfumado, a sociedade não foi bem porque a gente combinou uma coisa e ele começou a fazer outra coisa.

Ele já tinha uma outra empresa, então eu trabalhava 80%, ele trabalhava 20%, mas as ações da empresa eram tudo igual, o salário era tudo igual. Ele falou, não, eu vou deixar aquela empresa, a minha esposa, eu vou vir trabalhar 100% com você. Mas o tempo foi passando, então, tipo, eu combinei para ser engenheiro, aliás, inicialmente eu era engenheiro e ele vendedor, mas no final ele também não era vendedor.

E eu peguei a conta da empresa onde eu estava, estava sem salário, e o cara me deixou na mão, então eu tenho que correr atrás para vender porque não tenho salário. Eu contei um pouco para o Valentino, que eu sou estrangeiro, sou da África, eu vim aqui no Brasil, porque a USP oferece quatro vagas no mundo todo ano, e eu concorri em uma dessas vagas, e eu passei no curso de Engenharia Elétrica.

Que legal, parabéns, parabéns.

## 8:31 - Valentino
Tu estudou lá ou estudou aqui, Artur?

## 8:35 - Artur
Estudei aqui, aqui no Brasil, eu concorri à USP lá no meu país, e eu passei, então vim aqui no Brasil. Parabéns.

## 8:44 - Valentino
É uma coisa que não é todo mundo que consegue. E Artur, inclusive eu sou estrangeiro também, sabia?

## 8:50 - Artur
Isso, você falou, argentino, né? Que legal. Então, isso é muito bacana.

Aí eu me formei em Engenharia Elétrica. Fiz estágio em Energia Solar, trabalhei na quarta maior empresa de fotovoltaico do Brasil, e a gente fez bastante instalação. Eu já fui instalador, comecei como instalador, eu pedi uma vaga lá e me dei como instalador. E como instalador tive o problema já de instalar grandes usinas. Inclusive instalei a usina fotovoltaica, não, a gente é equipe, instalou Energia Solar na fazenda do Daniel Cantor, em Brotas, esse Daniel Cantor famoso, na chácara dele, do pai dele e irmão. Vários lugares, Campinas, estacionamento de esgoto, Santa Casa de São Carlos, de Ribeirão Preto, então vários lugares a gente instalou.

Depois a empresa vendeu, a polícia como engenheiro, como engenheiro eu coordenei muitos projetos fotovoltaicos também, projetos do MH2, e aí o dono da empresa faleceu. Eu tinha dois caminhos, arrumar outro emprego ou ser empreendedor. Voltei.

Eu me especializei só em fotovoltaico, conheci esse cara, esse amigo, e a gente abriu uma empresa em 2023. A empresa faturava R$150 mil por mês, isso depois ficou seis meses sem vender, ele não era vendedor, também ele, enfim, o cara não era vendedor, ele me ajudava só na parte da gestão e precisava de vendedor, então não tinha experiência, não era vendedor, não tinha experiência de nada.

E aí eu tinha que correr atrás, fazer alguns cursos gratuitos no SEBRAE, começar a estudar desenvolvimento pessoal, seguir esses caras grandes, estudar um pouco o tráfego pago, gestão, inteligência emocional, lei da atração. Então fui me atirando, porque entendi que eu preciso me transformar para ser a pessoa que eu quero ser, então preciso reconfigurar todo o meu ser, então comecei a estudar muito sobre, pra me transformar, sobre a minha pessoa, sobre emoções.

E aí comecei a estudar sobre gestão, fiz um curso básico de gestão de negócio, fiz a estudar sobre vendas, mas assim, eu não fiz um curso específico de venda, mas estudei sobre gestão, estudei alguns cursos do SEBRAE, participei palestra, fiz parte de um movimento por seis meses, chama o BNI, uma rede de network internacional, fiquei lá uns seis meses.

Então fui me atirando, e nisso eu ganhei uma experiência, que começamos a vender uma média de 10 projetos por mês, que dava aí uns 150 mil por mês. Aí a sociedade não deu certo, como eu disse, que ele não cumpriu o que a gente combinou, e queria que as coisas continuassem desse jeito.

Então eu larguei mão da empresa, deixei tudo pra ele. O senhor da empresa está aqui, você troca, eu consegui sair sem nada. Preferi perder tudo, eu perdi mais de 300 mil reais. Então, eu fiquei triste, não me preocupei muito porque eu sei que... Porque hoje eu estou buscando algo na minha vida assim, não de me apegar em algo que eu conquistei, mas de criar as coisas, de pegar as coisas do nada, levantar.

Então, eu sei que se a empresa deu certo, então eu vou abrir uma outra, vai dar certo. Você só quebrar, abrir uma outra, se quebrar quantas vezes possível. Então, eu gosto muito de aprender a desenvolver essa mentalidade. Então, para mim, isso está sendo um treino, estou amando, mas é difícil, é difícil porque perdi muita grana, cara.

Agora, essa empresa que eu abri, essa empresa eu abri um mês passado, tem 30 dias só. Então, para ser sincero, eu conheci o Valentino bem na minha vida... Abri uma empresa, então não tem nada, eu abri uma empresa sem capital, não tenho dinheiro, como fez eu para vocês, soltei no CNPJ, as redes sociais, talvez o Valentino me segue lá, e o escritório é minha casa. Então a empresa está assim, eu abri sem nada, e estou buscando um milagre de Deus para eu virar o jogo.

## 13:25 - Valentino
Ô Artur, pelo tudo que tu falou, e até parabéns por onde você está hoje, tu é uma pessoa que correu muito atrás de conseguir as suas próprias coisas, sabe, e eu acho que esse foi um dos motivos de você ter preferido deixar para ele e construir o seu próprio legado, né, por assim dizer. E quando não deu certo, você foi atrás de aprender, quando deu errado, você foi atrás de dar certo, entende, então realmente é a garra do empresário e parabéns por isso. Você saiu de um país diferente, estudou, se dedicou, fui lá, fiz projetos, fui lá, abri uma empresa, A deu errado, abriu outra empresa, pô, é isso, continua a vida, e é isso, a vida, a nossa vida tem altos e baixos. E principalmente pela tua energia, eu vejo que, seja um momento ruim ou não, eu acho que você sempre vai estar sorrindo, e é difícil alguém ser assim, parabéns por ser assim também.

## 14:18 - Artur
Verdade, muito obrigado. Então hoje, conforme, para responder a essas perguntas, como é que está a empresa? A empresa ainda está em fase de reestruturação, eu não contratei ninguém, porque nunca tinha dinheiro para contratar. Então hoje quem sou? Eu sou engenheiro, sou vendedor, sou técnico e sou financeiro, tudo praticamente.

Mas e agora a empresa, como é que está indo? Estou mexendo com tudo. No início, tinha uma equipe que trabalhou comigo, essa equipe, o que que ela fez? Ela trabalhou um mês comigo, mas houve alguns desentendimentos e acabou não dando.

Eu lutava com um gestor e com o cara do marketing. Esse cara é um desenvolvedor de software e ele inclusive fez um software, um CRM e uma proposta, eu ajudei ele a gente elaborar e a gente estava trabalhando junto no marketing e na elaboração de algumas coisas. Mas depois houve algum desentendimento porque eles queriam, a gente combinou uma coisa, ou seja, a percentagem que eles queriam, foi do jeito que a gente não combinou, por mais que a semana comprada, eu não concordei. Então a gente ficou assim. Então hoje literalmente eu estou sozinho.

Agora como é que eu faço as vendas? Eu sei que as vendas são a prospecção, a prospecção por ligação, porta a porta, tráfego pago, disparo de mensagem por WhatsApp que existe e parcerias. Então eu sei que existe todo esse tempo. Eu vou agora.

Qual delas estão ativas no meu negócio? Eu diria que praticamente ainda nenhuma delas está bem ativa. Eu sei que eu tenho que começar, mas eu faço mil coisas ao mesmo tempo, uma porta para fazer, de outra empresa tem alguns clientes que ainda tem que dar assistência, eu tenho que fazer visita. Então eu sei que eu tenho que sair para fazer porta a porta, por exemplo, sei que eu tenho que sair para fazer porta a porta e ainda não estou conseguindo.

Eu sei que tem que fazer ligação, tem que estar em uma lista lá no Google Ads, ou nas plataformas que vendem, e eu tenho que ligar. Eu confesso que na minha vida não tenho essa experiência de fazer prospecção por ligação que vocês têm. Eu queria muito aprender, queria muito dominar, então a gente não tem.

Esse cara aí me ajudou, me ensinou como a gente comprou uma lista. Em uma das plataformas, baixamos uma lista de adegas, depois de bebidas, e começamos a ligar, comecei a ligar, então por dia ligava 15, ligava 10, então...

---

> ⚠️ **Transcrição truncada** — atingiu o limite de caracteres. Falta a parte final da call (cerca de 43 minutos restantes).

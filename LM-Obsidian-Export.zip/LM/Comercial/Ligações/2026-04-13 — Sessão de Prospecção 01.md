---
date: 2026-04-13
type: sessão-prospecção
evento: Solar de Elite
periodo: manhã (1h)
vendedores: [Valentino, Falante 2, Falante 3]
total_ligacoes_identificadas: 5
tags: [comercial, lm, solar, prospecção]
---

# Sessão de Prospecção 01 — 2026-04-13

## Contexto do evento sendo promovido

**Evento:** Solar de Elite
**Data:** quinta-feira, meio-dia
**Formato:** online, gratuito
**Público-alvo:** integradores e empresas de energia solar
**Proposta de valor:** aprender a gerar demanda de clientes comerciais sem investir em anúncios
**Social proof usado na abordagem:** "mais de 100 empresas confirmadas"

---

## Ligações desta sessão

| Prospect | Vendedor | Resultado |
|---|---|---|
| [[2026-04-13 — Laís — Integrador Solar]] | Valentino | Confirmada + vai chamar time |
| [[2026-04-13 — Aguinaldo — Integrador Solar]] | Valentino | Descartado (viagem China) |
| Sem nome — não consegue quinta | Falante 3 | Descartado |
| Sem nome — sem interesse | Falante 3 | Descartado |
| Matheus — empresa solar | Falante 3 | Sem resultado registrado |

---

## Status geral da prospecção

- **Convidados:** 45
- **Confirmados:** 5
- **Taxa de confirmação:** ~11%

---

## Decisões e ações definidas na sessão

- [ ] Follow-up em todos os convidados que não confirmaram
- [ ] Quem não confirmar até 14h → ligar
- [ ] Mandar mensagem com link para todos
- [ ] Ligar para Carlinhos às 13:40 (Valentino)
- [ ] Voltar para Laís à tarde se não conseguir na ligação da manhã

**Script de confirmação definido:**
> "Fala, [nome], tudo bom? Confirmamos sua presença no evento de quinta. Te mandei o link no WhatsApp. Clica lá e aceita pra agenda te lembrar."

---

## Insights internos da sessão

- **Qualificação:** não vale fazer follow-up em empresa pequena — qualificar melhor antes de convidar
- **Evento:** parceria com Onimoto (dono da Ascend) — 4h no final de semana (2h de oferta + 2h de webinar)
- Registrar objeções sistematicamente para melhorar o processo com o tempo

---

## Objeções encontradas

- "Vou viajar para a China" (indisponibilidade)
- "Não consigo na quinta ao meio-dia"
- "Não tenho interesse"

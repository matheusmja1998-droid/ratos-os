---
date: 2026-04-13
type: ligação-comercial
prospect: Aguinaldo
empresa: Integrador Solar (nome não registrado)
segmento: Energia Solar — Integrador
vendedor: Valentino
resultado: descartado-temporário
motivo: viagem internacional (China)
evento: Solar de Elite
tags: [comercial, lm, solar, descartado, reativar]
---

# Ligação — Aguinaldo — 2026-04-13

## Resultado
- [ ] Confirmada para o evento
- [ ] Fechou
- [ ] Seguimento agendado
- [x] Descartado para este evento — reativar depois

## Contexto do prospect

- **Contato:** Aguinaldo (decisor)
- **Gatekeeper:** Gabriela (quem atendeu primeiro)
- **Contatos anteriores na empresa:** Rosa, Abriele, Erika (abordadas semana passada)
- **Segmento:** integradores de energia solar

## Resumo da ligação

Valentino chegou via Gabriela (gatekeeper). Ao falar com Aguinaldo, apresentou o convite para o Solar de Elite. Aguinaldo informou que vai viajar para a China e não poderá participar. Valentino optou por manter o relacionamento — vai adicioná-lo a um grupo para convites futuros.

## Objeção

- **"Vou viajar pra China"** — indisponibilidade pontual, não é rejeição à proposta

## O que funcionou

- Chegou ao decisor passando pelo gatekeeper sem atrito
- Não descartou o lead definitivamente — manteve relacionamento para reativação

## Próximos passos

- [ ] Adicionar Aguinaldo ao grupo de leads para próximo evento
- [ ] Reativar no próximo ciclo de prospecção

---

## Trechos da ligação

**Com Gabriela (gatekeeper):**
> Bom dia, Gabriela, tudo bem?
> Falei com a Rosa, Abriele e Erika semana passada.
> Estou com um convite para o Aguinaldo.
> Evento quinta-feira, meio-dia, online e gratuito.
> Mais de 100 empresas confirmadas.
> Posso falar com o Aguinaldo?

**Com Aguinaldo:**
> Aguinaldo, tudo bem? Aqui é o Valentino.
> Vocês são integradores, né?
> Quinta-feira vamos fazer um evento gratuito ao meio-dia.
> Já tem mais de 100 empresas confirmadas.
> O objetivo é ensinar como gerar demanda sem investir em anúncios.
> Posso confirmar sua participação?

**Aguinaldo:** Vou viajar pra China.

> Perfeito, então vou te chamar depois e te colocar no grupo. Pode ser?

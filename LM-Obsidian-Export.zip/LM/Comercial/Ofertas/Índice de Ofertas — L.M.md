---
tipo: índice
agência: LM
tags: [ofertas, produtos, ignição, pipeline-comercial]
atualizado: 2026-06-17
---

# Ofertas da L.M

## Linha Ignição — Consultoria Comercial para Integradores Solares

| Oferta | Para quem | Preço | Formato |
|---|---|---|---|
| [[Ignição Solo/Ignição Solo — Oferta]] | Dono solo, sem time, sem budget para R$5k | R$ 497 | Sessão 90 min |
| [[Ignição Comercial/Ignição Comercial — Oferta Completa]] | Dono com time comercial, dependente de indicação | R$ 5.000 | 45 dias / 6 semanas |
| [[Pipeline Comercial/Pipeline Comercial — Oferta Completa]] | Dono afogado que não quer aprender nem montar time, quer a venda entrando | R$ 1.500/mês + 5% | Done-for-you recorrente |

## Funil natural
```
Webinar → Diagnóstico → Ignição Solo (R$497) → Ignição Comercial (R$5k, com crédito de R$497)
                                                      ↓ done-for-you / recorrência
                                              Pipeline Comercial (R$1.500/mês + 5%)
```

## Scripts de diagnóstico
- [[Ignição Solo/Ignição Solo — Script de Diagnóstico v1]]
- [[Ignição Comercial/Ignição Comercial — Script de Diagnóstico v2]]
- [[Pipeline Comercial/Pipeline Comercial — Script de Diagnóstico]]

## Regra de ouro das calls
> Você fala 30% da call. O cliente fala 70%. Quem mais fala no diagnóstico, mais compra.

---
tipo: template
produto: Ignição Comercial
uso: formulário de onboarding pra todo cliente novo
versão: 1.0
data_criação: 2026-05-05
respondido_por: gestor comercial do cliente
tags: [template, onboarding, ignição-comercial, lm, formulário]
---

# Template — Formulário de Onboarding Ignição Comercial

Formulário pra ser respondido pelo gestor comercial do cliente novo ANTES da reunião de onboarding. Serve pra calibrar tudo: meta, ICP, time, ferramentas, estratégia.

## Como usar

1. Subir esse formulário em **Google Forms, Tally ou Typeform** (recomendação Tally — é o mais bonito e gratuito)
2. Mandar link no grupo do WhatsApp do cliente após assinatura do contrato
3. Pedir resposta em até 48h antes da onboarding
4. Revisar todas as respostas antes da reunião e usar pra customizar o cronograma

## Plataforma recomendada: Tally.so

- Gratuito até resposta ilimitada
- Visual limpo, parece site profissional (não tem cara de Google Forms)
- Lógica condicional fácil (se responder X, aparece pergunta Y)
- Exporta resposta em Google Sheets automático
- Suporta 7 vendedores em loop sem virar formulário gigante (campo repetível)

**Plano B:** Google Forms (gratuito, mais feio mas funcional). Pra Synergy, recomendo Tally.

---

# Formulário de Onboarding — {{NomeCliente}} x Winvision

**Pra quem responde:** {{NomeGestor}} (gestor comercial)
**Tempo estimado:** 25 a 35 minutos
**Por que pedimos:** essas informações vão direto pra reunião de onboarding. Quanto mais detalhe, melhor o projeto que a gente desenha. Algumas perguntas tu pode precisar puxar do dono — sem problema, fica à vontade pra responder no que tu sabe e marcar "preciso confirmar com o {{NomeDono}}" no que ainda não souber.

---

## Bloco 1 — Saúde da operação

**1.1.** Qual o faturamento mensal médio da empresa nos últimos 6 meses?
*(Resposta aberta — pode dar uma faixa: ex. "entre R$300k e R$450k")*

**1.2.** Qual o ticket médio por venda? Separa por tipo:
- Residencial: R$ ____________
- Comercial: R$ ____________
- Outro (rural/industrial, se houver): R$ ____________

**1.3.** Quantas vendas por mês, em média, nos últimos 3 meses?
- Residencial: _____
- Comercial: _____
- Outro: _____

**1.4.** Qual a margem de lucro líquida média atual da empresa?
( ) Abaixo de 5%
( ) Entre 5% e 10%
( ) Entre 10% e 15%
( ) Entre 15% e 20%
( ) Acima de 20%
( ) Não sei / preciso confirmar com o dono

**1.5.** % do faturamento que vem de cada canal hoje (somando 100%):
- Indicação: _____%
- Prospecção ativa do time: _____%
- Tráfego pago / redes sociais: _____%
- Outros (quais?): _____%

**1.6.** Qual o ciclo médio de venda? (do primeiro contato até pagamento)
( ) Menos de 7 dias
( ) Entre 7 e 15 dias
( ) Entre 15 e 30 dias
( ) Entre 30 e 60 dias
( ) Mais de 60 dias

---

## Bloco 2 — Time comercial

**2.1.** Lista nominal dos vendedores ativos hoje. Pra cada um, preencha:

```
NOME 1: ____________
- Função: ( ) Closer  ( ) SDR  ( ) Gerente  ( ) Técnico que vende  ( ) Outro: _______
- Regime: ( ) PJ 100% comissionado  ( ) PJ fixo + comissão  ( ) CLT
- Tempo de empresa: _____ meses/anos
- Faturamento médio gerado nos últimos 3 meses: R$ _____
- Horas/dia disponíveis pra prospecção: ( ) 1h  ( ) 2h  ( ) 3-4h  ( ) Full time
- Tem outras atividades por fora? ( ) Não  ( ) Sim, qual: _______

Complexidade de venda que esse vendedor atende:
□ Residencial até R$25k
□ Residencial qualquer ticket
□ Comercial pequeno (até R$80k)
□ Comercial médio (R$80k a R$300k)
□ Comercial grande / usina (acima de R$300k)
□ Sistema híbrido com armazenamento
□ Eletroposto / soluções complexas
□ Rural / industrial
```

*(Repete o bloco pra cada vendedor)*

**2.2.** Quem é o melhor performer do time hoje? Por quê?
*(Resposta aberta)*

**2.3.** Quem é o pior performer? Por quê?
*(Resposta aberta)*

**2.4.** Quem do time tu acha que vai abraçar mais rápido o método de prospecção ativa?
*(Resposta aberta)*

**2.5.** Quem tu acha que vai resistir mais ou ter dificuldade?
*(Resposta aberta)*

---

## Bloco 3 — Como prospectam hoje

**3.1.** Como cada vendedor prospecta hoje? (pode marcar mais de uma)
□ Porta a porta (PAP)
□ Ligação fria
□ Ligação pra indicação/lead
□ WhatsApp frio
□ WhatsApp pra indicação/lead
□ Redes sociais (Instagram, LinkedIn)
□ Espera o lead chegar (inbound)
□ Outro: _____

**3.2.** Vocês têm script de prospecção atual? Se sim, podem mandar junto com esse formulário?
( ) Sim, vou mandar
( ) Tem mas não é formalizado
( ) Não tem

**3.3.** Já tem alguma lista de empresas trabalhada (telefones, CNPJs)?
( ) Sim, organizada
( ) Sim, mas espalhada/desorganizada
( ) Não

**3.4.** Quais segmentos comerciais vocês JÁ venderam? (marca todos que se aplicam)
□ Supermercado
□ Açougue / mercado pequeno
□ Posto de gasolina
□ Academia
□ Restaurante / lanchonete
□ Hotel / pousada
□ Padaria
□ Loja de varejo
□ Indústria pequena
□ Clínica / consultório
□ Igreja
□ Escola / creche
□ Outros (quais?): _____

**3.5.** Quais segmentos vocês NUNCA tentaram mas acham promissor?
*(Resposta aberta)*

**3.6.** Em quais regiões vocês cobrem hoje?
*(Resposta aberta)*

**3.7.** Onde vocês têm mais autoridade local / mais clientes / mais reputação?
*(Resposta aberta)*

**3.8.** Tem algum case forte de cliente comercial que a gente possa usar como prova social na prospecção?
*(Resposta aberta — nome da empresa, segmento, qual problema resolvemos, resultado)*

---

## Bloco 4 — CRM e ferramentas

**4.1.** Qual CRM vocês usam hoje?
( ) RD Station CRM
( ) Pipedrive
( ) HubSpot
( ) Kommo
( ) Bitrix
( ) Planilha Google / Excel
( ) Outro: _____

**4.2.** Os vendedores têm acesso ao CRM?
( ) Todos têm e preenchem
( ) Todos têm mas só alguns preenchem
( ) Só alguns têm acesso
( ) Ninguém preenche direito

**4.3.** Quais campos preenchem hoje no CRM? (pode marcar mais de uma)
□ Nome do lead
□ Telefone
□ Origem do lead
□ Etapa do funil
□ Anotações da conversa
□ Próximo passo agendado
□ Valor estimado
□ Motivo de perda (quando perde)
□ Outro: _____

**4.4.** Como tu sabe hoje se um vendedor bateu meta?
( ) Relatório do CRM automatizado
( ) Planilha manual atualizada por mim
( ) Planilha manual atualizada pelo vendedor
( ) Não tem como saber direito
( ) Outro: _____

**4.5.** Plano de telefone dos vendedores:
( ) Empresa fornece celular + plano ilimitado
( ) Empresa fornece chip + ajuda no plano
( ) Cada vendedor usa o próprio celular pessoal
( ) Outro: _____

---

## Bloco 5 — Estratégia e contexto

**5.1.** Qual o faturamento meta dos próximos 6 meses?
*(Resposta aberta)*

**5.2.** Quantas vendas em CLIENTE COMERCIAL vocês querem fechar por mês?
*(Resposta aberta — não é quantas visitas, é quantas vendas fechadas)*

**5.3.** Tem alguma meta de margem? (ex: subir de 8% pra 15%)
*(Resposta aberta)*

**5.4.** Tem sazonalidade no setor solar de vocês? Marca os meses de pico e os fracos:

Meses fortes: □ Jan □ Fev □ Mar □ Abr □ Mai □ Jun □ Jul □ Ago □ Set □ Out □ Nov □ Dez

Meses fracos: □ Jan □ Fev □ Mar □ Abr □ Mai □ Jun □ Jul □ Ago □ Set □ Out □ Nov □ Dez

**5.5.** Concorrentes diretos na sua região — quantos são, quem são os principais?
*(Resposta aberta)*

**5.6.** Os "pica-fios" (concorrentes que vendem com margem zerada) — tem nome de empresa específica? Algum deles é especialmente agressivo em preço?
*(Resposta aberta)*

**5.7.** Tem alguma OBRA grande prevista nos próximos 45 dias que vai consumir tempo do time comercial?
( ) Não, time tá disponível
( ) Sim, mas dá pra conciliar
( ) Sim, vai atrapalhar bastante (qual obra/cliente?): _____

**5.8.** Tem férias coletivas, feriado regional ou evento que afeta o cronograma de 45 dias?
*(Resposta aberta)*

---

## Bloco 6 — Sobre o gestor comercial (tu)

**6.1.** Há quanto tempo tu tá na empresa?
*(Resposta aberta)*

**6.2.** Qual o teu background antes daqui?
( ) Vendedor de solar
( ) Vendedor de outro setor
( ) Gestor comercial em outra empresa
( ) Técnico (engenheiro / instalador)
( ) RH / administrativo
( ) Outro: _____

**6.3.** Tu tem autonomia pra tomar decisões operacionais (mudar script, redirecionar vendedor, mudar meta semanal) ou tudo passa pelo dono?
( ) Total autonomia operacional
( ) Autonomia parcial, decisões grandes passam pelo dono
( ) Tudo passa pelo dono
( ) Outro: _____

**6.4.** Como tu se comunica com o time hoje?
( ) Daily de manhã (presencial / online)
( ) Reunião semanal
( ) Só WhatsApp em grupo
( ) Só individual quando precisa
( ) Outro: _____

**6.5.** Pra ti, qual é a maior dor da operação comercial hoje (na tua visão de gestor, não a do dono)?
*(Resposta aberta — quero a tua versão sincera)*

---

## Final

**O que tu acha que a Winvision precisa saber sobre a empresa que não foi perguntado nesse formulário?**
*(Resposta aberta)*

**Tem documentos, planilhas, scripts, dashboards atuais que tu pode mandar junto?**
*(Resposta aberta — lista os anexos)*

---

**Após preencher, envia tudo no nosso grupo do WhatsApp.**

Quinta-feira, 7h da manhã, a gente se vê na onboarding pra fechar o cronograma personalizado em cima dessas respostas.

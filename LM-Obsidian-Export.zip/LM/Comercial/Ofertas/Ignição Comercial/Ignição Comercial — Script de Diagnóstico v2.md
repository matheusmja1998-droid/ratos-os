---
fonte: Ignicao-Comercial-Script-Diagnostico-v2.docx
produto: Ignição Comercial
tipo: script
agência: LM
tags: [script, diagnóstico, call, vendas]
---

# Script de Diagnóstico — Ignição Comercial
**Duração:** 60 min | **Formato:** vídeo 1:1 | **Origem:** lead vindo do webinar

---

## Regra de ouro
> Você fala **30%** da call. O cliente fala **70%**.
> Quem mais fala no diagnóstico, mais compra.
> **Nunca antecipe objeções. Nunca fale após fazer a pergunta de fechamento.**

---

## Visão geral dos blocos

| Bloco | Objetivo | Tempo |
|---|---|---|
| 1. Abertura | Rapport + definir agenda + tirar pressão | 5 min |
| 2. Situação Atual | Entender de onde vêm os clientes hoje | 5 min |
| 3. Dor e Custo | Quantificar a dor em dinheiro e tempo | 10 min |
| 4. Tentativas Anteriores | Entender o que já falhou e por quê | 5 min |
| 5. Consequências | Amplificar o custo de continuar como está | 5 min |
| 6. Sonho | Fazer o cliente descrever o resultado que quer | 3 min |
| 7. Apresentação | Solução usando as palavras do cliente | 15 min |
| 8. Ancoragem + Fechamento | Math do preço + garantia + silêncio | 10 min |
| 9. Objeções | Responder se surgir — não antecipar | Conforme necessário |

---

## Bloco 1 — Abertura (0–5 min)

> "Antes de começar — essa call não é uma apresentação. É um diagnóstico. Vou te fazer algumas perguntas para entender onde você está hoje. Se fizer sentido trabalharmos juntos, eu te mostro como funciona. Se não fizer, sem problema. Combinado?"

📌 Espere o "sim". Não continue sem a confirmação.

---

## Bloco 2 — Situação Atual (5–10 min)

| Pergunta | O que avaliar |
|---|---|
| "Como você está chegando nos clientes hoje?" | Dependência de indicação vs canal ativo |
| "Você tem alguém dedicado ao comercial ou é você que vende?" | Maturidade do time |
| "Quantos clientes novos você fecha por mês em média?" | Volume atual |
| "Qual é o ticket médio dos seus projetos?" | Potencial de ROI |

📌 Não julgue as respostas. Apenas anote. Você vai usar esses números na ancoragem.

---

## Bloco 3 — Dor e Custo (10–20 min)

**🔀 Identifique o perfil antes de prosseguir:**
- **PATH A** — cliente que investe (ou investiu) em tráfego pago
- **PATH B** — cliente que nunca investiu, só depende de indicação

### PATH A — Investe em tráfego

| Pergunta | O que avaliar |
|---|---|
| "Você investe em tráfego pago — Meta, Google?" | Abertura para ancoragem |
| "Quanto você gasta por mês nisso?" | CAC real em dinheiro — **anote o número** |
| "Como estão chegando esses leads — são qualificados?" | Frustração com canal atual |
| "Quanto tempo do time vai para atender lead que não fecha?" | Custo oculto em horas |
| "Nos últimos 6 meses, quantos clientes vieram de tráfego vs indicação?" | Evidência concreta |

**Momento do cálculo:**
> "Então você gastou R$[X]/mês × 6 meses = R$[X total]. E de todo esse investimento, quantos clientes fecharam via tráfego?"

🔇 **SILÊNCIO.** Quando ele responder: "Entendi." — e continue.

### PATH B — Só indicação

| Pergunta | O que avaliar |
|---|---|
| "Você nunca investiu em tráfego ou tentou e parou?" | Histórico de resistência |
| "Além das indicações, faz alguma prospecção ativa?" | Confirma ausência de outbound |
| "Quantas indicações chegam por mês, em média?" | Volume base atual |
| "Dessas, quantas viraram proposta? Quantas fecharam?" | Taxa de conversão |
| "Já ficou algum mês sem indicação chegando? O que aconteceu?" | Fragilidade do modelo |

**Momento do cálculo (PATH B):**
> "Você me disse que fecha [X] clientes por mês por indicação, ticket médio de R$[Y]. Se você tivesse mais 2 novos clientes por mês que você foi buscar — quanto isso representa por mês?"

🔇 **SILÊNCIO.**
> "Em 6 meses seriam R$[2×Y×6] que ficaram na mesa — não porque o mercado é ruim, mas porque não existia processo para buscar. Sem gastar nada em tráfego."

📌 Não faça a conta por ele. Quando ele disser o número: "Exato." — e continue.

---

## Bloco 4 — Tentativas Anteriores (20–25 min)

| Pergunta |
|---|
| "Você já tentou alguma coisa diferente de tráfego pago e indicação para prospectar?" |
| "O que aconteceu?" |
| "O que você acha que faltou para funcionar?" |

**Como usar a resposta:**
- "Faltou processo" → "Processo é exatamente o que a gente constrói."
- "Faltou tempo" → "Por isso o modelo é done-with-you — a gente faz junto."
- "O time não sabia abordar" → "Script e treinamento de objeções estão no programa."

📌 Use as palavras dele — não invente. **Espelho.**

---

## Bloco 5 — Consequências (25–30 min)

| Pergunta |
|---|
| "Se as indicações pararem por 60 dias — o que acontece com o faturamento?" |
| "Você consegue prever hoje quanto vai faturar no próximo mês?" |
| "Se você pudesse ter 3 a 5 reuniões por semana com empresários qualificados sem pagar tráfego — quanto isso representaria em receita?" |

🔇 **SILÊNCIO após a última pergunta.** Essa é o turning point da call.

---

## Bloco 6 — Sonho (30–33 min)

| Pergunta |
|---|
| "Qual seria o cenário ideal para você em 90 dias no comercial?" |
| "Se o time estivesse prospectando sozinho sem depender de você — o que mudaria no seu dia?" |
| "Como seria fechar o mês sabendo de onde vem o próximo cliente?" |

📌 **Anote as palavras exatas dele.** Você vai repeti-las na apresentação.

---

## Transição

Só avance para a apresentação depois de ter:
- [ ] Valor gasto em tráfego (PATH A) **ou** custo de oportunidade calculado (PATH B)
- [ ] Ausência de processo comercial confirmada
- [ ] O sonho dele em palavras dele

> "Tá. Deixa eu te contar o que a gente faz — porque acho que faz muito sentido para o que você me descreveu."

📌 Não peça permissão. **Afirme.**

---

## Bloco 7 — Apresentação (33–48 min)

Conecte cada semana do programa a uma dor que ele citou:
> "Você me falou que quer **[PALAVRA DELE]**. É exatamente isso que a gente constrói na semana [X] do programa."

Slides na ordem: Capa → A Solução → Como Funciona → 10 Entregas → Bônus → Prova/Case → Para quem é.

---

## Bloco 8 — Ancoragem e Fechamento (48–58 min)

**Passo 1 — Stack de valor:**
> "O programa completo mais os três bônus representam R$12.500 em valor. O investimento é bem abaixo disso."

**Passo 2A — Math PATH A:**
> "Você me disse que gasta R$[X]/mês em tráfego. Em 6 meses foram R$[X×6]. Com resultado ruim, certo?"

🔇 SILÊNCIO.
> "O Ignição Comercial é R$5.000 — pagamento único. Em menos de um mês de tráfego você já pagou mais — e aqui a estrutura fica na sua empresa para sempre."

**Passo 2B — Math PATH B:**
> "Você me disse que o ticket médio é R$[Y]. Um único cliente que a gente vai buscar paga o Ignição inteiro. Com troco. E a estrutura fica na sua empresa para sempre."

🔇 SILÊNCIO.

**Passo 3 — Garantia:**
> "Se você completar as 4 primeiras semanas com ICP definido, lista montada, scripts configurados e cadência ativa, e não tiver gerado nenhuma reunião qualificada... a gente continua trabalhando junto gratuitamente até você ter. Sem prazo. Sem custo extra."

**Passo 4 — Fechamento:**
> "Faz sentido para você? Quer começar?"

🔇 **SILÊNCIO TOTAL. O próximo que falar perde.**

---

## Bloco 9 — Objeções (só se surgir)

**"Preciso pensar."**
> "Claro. O que especificamente você precisa pensar — é sobre o valor, sobre o timing ou sobre se funciona para o seu negócio?"

**"Está caro." (PATH A)**
> "Caro em relação ao quê? Você me disse que gasta R$[X]/mês em tráfego. Em 3 meses pagou mais do que o Ignição — com resultado ruim. Aqui é pagamento único e a estrutura fica na empresa."

**"Está caro." (PATH B)**
> "Um único fechamento via prospecção ativa cobre o Ignição — e a estrutura fica para sempre. O custo real não é R$5.000. É continuar mais 6 meses sem prospectar."

**"Já tentei algo parecido e não funcionou."**
> "O que você tentou foi uma agência ou um curso? O Ignição é diferente — a gente senta junto com o seu time e constrói dentro da sua empresa. E se não gerar reunião, continuamos de graça."

**"Vou falar com meu sócio."**
> "Faz sentido. Seu sócio teria 15 minutos para uma call rápida essa semana? Assim explico direto para os dois."

**"Não tenho time comercial."**
> "Uma das entregas é o Kit de Contratação de SDR Solar — você sai com vaga pronta, roteiro de entrevista e onboarding de 7 dias." → **Pivota para [[Ignição Solo — Script de Diagnóstico v1]]**

---

## Bloco 10 — Depois do Sim

> "Perfeito. Vou te mandar o contrato ainda hoje por e-mail. Assim que assinar, a gente agenda a primeira sessão ainda essa semana."

- [ ] Contrato enviado por e-mail em até 2 horas
- [ ] Confirmação via WhatsApp
- [ ] Link para agendar Sessão 1 após assinatura
- [ ] Formulário de contexto enviado na véspera da Sessão 1

📌 **Não deixe esfriar. Contrato na mesma hora.**

---

## Cola do Consultor — 1 Página

| Bloco | Tempo | Frase-chave |
|---|---|---|
| Abertura | 5 min | "Isso é um diagnóstico, não uma apresentação." |
| Situação atual | 5 min | "De onde vem a maioria dos seus clientes hoje?" |
| Dor e custo | 10 min | "Quanto você gasta por mês em tráfego?" |
| Tentativas | 5 min | "O que você acha que faltou para funcionar?" |
| Consequências | 5 min | "Se as indicações pararem 60 dias — o que acontece?" |
| Sonho | 3 min | "Qual seria o cenário ideal em 90 dias?" |
| Apresentação | 15 min | "Deixa eu te contar o que a gente faz." |
| Ancoragem | 5 min | "Você gastou R$[X×6] em 6 meses com resultado ruim." |
| Garantia | 2 min | "Se não gerar reunião, continuamos de graça." |
| Fechamento | 2 min | "Faz sentido? Quer começar?" → **SILÊNCIO** |

---

**Ver também:** [[Ignição Comercial — Oferta Completa]] | [[Ignição Solo — Script de Diagnóstico v1]] | [[Índice de Ofertas — L.M]]

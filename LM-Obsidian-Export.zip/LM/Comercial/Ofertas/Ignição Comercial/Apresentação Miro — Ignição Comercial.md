---
tipo: apresentação
data: 2026-05-05
produto: Ignição Comercial
formato: mapa mental Miro
contexto: usado na R2, depois do destino confirmado e da urgência verbalizada
tags: [ignição-comercial, miro, r2, apresentação]
---

# Apresentação Miro — Ignição Comercial

Estrutura do mapa mental pra apresentar o produto na R2, depois que o cliente confirmou o destino ("é esse o destino que tu quer?") e verbalizou urgência alta.

A apresentação do produto é o de menos. O Miro só sustenta visualmente o que tu já vendeu na voz com a oferta-frase. **Esconde o tempo.** Não mostra "semana 1, semana 2". Mostra ativos que ficam na empresa.

---

## Centro do mapa

**45 DIAS**
**Da autofagia → pra clientes que valorizam qualidade**

---

## Os 3 blocos (cada bloco = 1 porta)

### Bloco 1 — MÁQUINA DE LEADS
**Pipeline ativo toda semana**

- Lista de 50-100 empresas
- 3 scripts (WhatsApp, LinkedIn, cold call)
- Cadência completa

→ Pergunta no fim do bloco: **"faz sentido?"**

---

### Bloco 2 — TIME ESTRUTURADO
**Comercial sem depender de ti**

- CRM rodando
- Playbook de 1 página
- Role play
- Documento de objeções
- Primeira prospecção ao vivo

→ Pergunta no fim do bloco: **"isso é pra ti?"**

---

### Bloco 3 — PREVISIBILIDADE
**Sabe em janeiro quanto fevereiro vai faturar**

- Dashboard de métricas
- Metas semanais
- Plano pra continuar sozinho

→ Pergunta no fim do bloco: **"tu acredita que eu sou a pessoa pra te entregar isso?"**

---

## Bloco lateral — GARANTIA

> "Se tu completar as 4 primeiras semanas com lista, scripts e cadência ativa, e não gerar nenhuma reunião qualificada, a gente continua trabalhando contigo de graça até gerar."

---

## Bloco final (esconde até as 3 portas estarem fechadas) — INVESTIMENTO

**Stack de valor:**
- Programa: R$ 9.000
- Bônus: R$ 3.500
- **Total: R$ 12.500**
- **Investimento: R$ 5.000**

---

## Como apresentar

1. Abre o Miro mostrando só o **centro** (oferta-frase visualmente)
2. Navega bloco 1 (1-2 min) → fecha 1ª porta
3. Navega bloco 2 (1-2 min) → fecha 2ª porta
4. Navega bloco 3 (1-2 min) → fecha 3ª porta
5. Mostra garantia rapidão pra desarmar risco
6. Resgata urgência: "tu falou que é urgente, tu confia, isso é pra ti"
7. Revela investimento
8. **"Eu só quero uma resposta de sim ou não. Pode ser?"**

---

## Regras pro Miro

- Cada caixa: 3-5 palavras no máximo
- Tu fala, o Miro só sustenta
- Cor diferente pra cada bloco
- Investimento fica fora da tela inicial, só aparece no fim
- Sem texto longo, sem ícone genérico
- Hierarquia clara: centro forte, 3 blocos médios, sub-itens pequenos

---
fonte: Ignicao-Comercial-Oferta-Completa.docx
produto: Ignição Comercial
agência: LM
preço: 5000
nicho: Integradora Solar
tags: [oferta, ignição-comercial, solar, outbound]
---

# Ignição Comercial
**Do zero ao time prospectando em 45 dias.**

---

## Para quem é

Dono de integradora solar que:
- Depende de indicação e sabe que não escala
- Já tentou tráfego pago e queimou dinheiro com lead desqualificado
- Tem time comercial, mas sem processo — cada um faz do seu jeito
- Fecha o mês sem saber de onde vem o próximo cliente

---

## O Resultado (antes × depois em 45 dias)

| Antes | Depois |
|---|---|
| Depende de indicação | Pipeline ativo de prospects B2B toda semana |
| Gasta em tráfego pago com lead ruim | Custo de aquisição próximo de zero |
| Time sem processo | Cadência definida, CRM rodando, playbook na mão |
| Fecha o mês no escuro | Dashboard com métricas visíveis em tempo real |
| Dono resolve tudo no comercial | Time prospecta sem depender do dono |

---

## Value Equation

> Um único cliente gerado pela estrutura paga o Ignição Comercial inteiro.
> A pergunta certa não é "quanto custa contratar". É "quanto custa não contratar por mais 6 meses".

**Custo de NÃO contratar:**
| Item | Estimativa mensal |
|---|---|
| Tráfego pago com leads desqualificados | R$ 3.000–12.000/mês |
| Tempo do dono/vendedor em leads ruins | 20–30h/mês desperdiçadas |
| Ticket médio solar perdido por mês | R$ 25.000–80.000 |

---

## Programa — 6 Semanas / 10 Horas

### Semana 1 — Diagnóstico + ICP + Avatar B2B (2h)
- Ticket médio, faturamento, CAC atual, como prospecta hoje
- Definição do ICP: perfil da empresa compradora (porte, segmento, região, consumo)
- Definição do decisor: cargo, dores, quem assina
- **Entrega:** Documento de ICP + perfil do decisor

### Semana 2 — Lista + Scripts (2h)
- Lista ao vivo: 50–100 empresas com nome, segmento, cidade e contato do decisor
- 3 scripts prontos: WhatsApp, LinkedIn e cold call
- **Entrega:** Lista qualificada + 3 scripts prontos para usar no dia seguinte

### Semana 3 — Cadência + PlayBook + CRM (1.5h)
- Cadência completa: canal → dia → mensagem → intervalo
- PlayBook de 1 página para o time
- CRM configurado e operacional com lista importada
- **Entrega:** CRM rodando + funil visível

### Semana 4 — Objeções + Primeira Prospecção ao Vivo (2h)
- As 5 objeções mais comuns em prospecção solar B2B com respostas
- Role play com o time
- Primeira prospecção ao vivo — primeiros contatos enviados juntos
- **Entrega:** Time destravado e com ritmo

### Semana 5 — Metas e Métricas (0.5h assíncrono)
- Dashboard de KPIs do funil
- Meta semanal por etapa
- Benchmark do que é normal esperar em outbound B2B solar
- **Entrega:** Dashboard + metas definidas

### Semana 6 — Review + Encerramento (2h)
- Análise de números reais do CRM
- Ajuste de scripts com base em dados
- Plano de 30 dias para continuar sozinho
- Orientação sobre quando e como escalar

---

## As 10 Entregas Tangíveis

| # | Entrega | Formato |
|---|---|---|
| 1 | ICP + Perfil do Decisor | Documento |
| 2 | Lista de 50–100 empresas pronta | Planilha |
| 3 | 3 Scripts validados (WhatsApp, LinkedIn, cold call) | Documento |
| 4 | Cadência completa | Documento |
| 5 | PlayBook de 1 página | Documento |
| 6 | CRM configurado e operacional | Ferramenta |
| 7 | Documento de objeções com respostas | Documento |
| 8 | Dashboard de métricas + metas semanais | Planilha |
| 9 | Scripts ajustados com base em respostas reais | Documento |
| 10 | Plano de 30 dias pós-programa | Documento |

---

## Bônus — Stack de Valor

| Bônus | O que resolve | Valor standalone |
|---|---|---|
| Kit de Contratação de SDR Solar | "E se meu vendedor sair?" | R$ 1.500 |
| Vault de 30 Mensagens que Convertem | "E se meu script parar de funcionar?" | R$ 1.200 |
| Calculadora de Meta Comercial Solar | "Quantos contatos preciso para bater minha meta?" | R$ 800 |

**Stack total:**
| Item | Valor percebido |
|---|---|
| Programa core | R$ 9.000 |
| Bônus 1 | R$ 1.500 |
| Bônus 2 | R$ 1.200 |
| Bônus 3 | R$ 800 |
| **VALOR TOTAL** | **R$ 12.500** |
| **INVESTIMENTO REAL** | **R$ 5.000** |

---

## Garantia

**Garantia de Resultado Condicional:**
> "Se você completar as 4 primeiras semanas — com ICP definido, lista montada, scripts configurados e cadência ativa — e não tiver gerado nenhuma reunião qualificada, a gente continua trabalhando juntos gratuitamente até você ter. Sem prazo. Sem custo extra."

**Garantia secundária (antes do contrato):**
> "Se depois da reunião de diagnóstico você sentir que não é para você, sem problema. Nenhum compromisso."

---

## Precificação e Ancoragem

**Math da call de diagnóstico:**
> "Quanto você gastou nos últimos 6 meses em tráfego pago?"
> Se R$3.000/mês → já jogou fora R$18.000. Você pede R$5.000 com garantia de resultado.

**Comparativo:**
| Alternativa | Custo | Resultado |
|---|---|---|
| Tráfego pago | R$3–12k/mês (recorrente) | Lead desqualificado |
| Agência de marketing | R$3–8k/mês (recorrente) | Leads, não estrutura |
| SDR sem processo | R$2–4k/mês + encargos | SDR perdido |
| **Ignição Comercial** | **R$5.000 (único)** | **Estrutura permanente** |

---

## Caminho pós-Ignição Comercial

| Produto | Para quem | Preço |
|---|---|---|
| Ignição Comercial | Quer estrutura para implementar com o time | R$ 5.000 |
| Protocolo Pipeline Zero | Quer implementação done-with-you completa | R$ 12.000–15.000 |

> Na call de encerramento: oferecer o Protocolo Pipeline Zero com os R$5.000 já pagos como crédito.

---

**Ver também:** [[Ignição Comercial — Script de Diagnóstico v2]] | [[Ignição Solo — Oferta]] | [[Índice de Ofertas — L.M]]

## Templates
- [[Template — Contrato Ignição Comercial]]
- [[Template — Formulário Onboarding Ignição]]
- [[Apresentação Miro — Ignição Comercial]]

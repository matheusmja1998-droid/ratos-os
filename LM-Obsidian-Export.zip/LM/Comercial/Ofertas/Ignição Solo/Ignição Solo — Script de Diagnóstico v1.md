---
fonte: Ignicao-Solo-Script-Diagnostico-v1.docx
produto: Ignição Solo
tipo: script
agência: LM
tags: [script, diagnóstico, call, solo, entrada]
---

# Script de Diagnóstico — Ignição Solo
**Duração:** 30–45 min | **Formato:** vídeo 1:1
**Origem:** lead sem time comercial ou sem budget para R$5k

---

## Regra de ouro
> Você fala **30%** da call. O cliente fala **70%**.
> A âncora é sempre o **ticket médio solar** — não o preço de R$497.
> **Nunca antecipe objeções. Nunca fale após a pergunta de fechamento.**
> O objetivo não é apresentar o produto — é fazer o cliente sentir o custo de continuar parado.

---

## Quando usar este script

- **Cenário A — Pivot mid-call:** lead veio para o Ignição Comercial, mas não tem time ou budget. Você pivota aqui.
- **Cenário B — Call standalone:** lead captado diretamente para o Ignição Solo.

---

## Bloco 0 — Pivot (só Cenário A)

Quando na call do Ignição Comercial o lead disser "não tenho time comercial" ou "tá apertado agora":

> "Faz sentido. O Ignição Comercial pressupõe que você já tem alguém prospectando — ou está pronto para contratar. Você ainda não está lá, e tudo bem.
> Mas você precisa de cliente essa semana, certo? Tenho uma sessão de 90 minutos por R$497 onde a gente monta sua lista e manda as primeiras mensagens juntos. Uma reunião B2B qualificada já paga isso em uma tarde. Se funcionar — e vai funcionar — aí a gente conversa sobre escalar com um time."

📌 Não explique o produto ainda. Plante a semente. Espere a resposta.
📌 Se ele disser "sim, quero" diretamente → pule para o Bloco 7.

---

## Bloco 1 — Abertura (0–3 min)

> "Antes de começar — essa conversa não é uma apresentação. Quero entender onde você está hoje com prospecção. Vou te fazer algumas perguntas rápidas. Se fizer sentido trabalharmos juntos, eu te mostro como funciona. Se não fizer, sem problema. Combinado?"

📌 Espere o "sim". Não continue sem a confirmação.

---

## Bloco 2 — Situação Atual (3–10 min)

| Pergunta | O que avaliar |
|---|---|
| "Como a maioria dos seus clientes chega hoje?" | Canal atual |
| "Quantos clientes novos você fecha por mês em média?" | Volume |
| "Qual é o ticket médio de uma instalação sua?" | **Anote — âncora principal** |
| "Você tem alguém te ajudando em vendas ou é tudo no seu pescoço?" | Solo mesmo? |
| "Você já tentou mandar mensagem fria alguma vez?" | Histórico + bloqueio |

📌 A resposta de "já tentei mensagem fria" revela o maior bloqueio — geralmente travamento na primeira mensagem ou não saber para quem mandar.

---

## Bloco 3 — Dor e Custo (10–20 min)

| Pergunta | O que avaliar |
|---|---|
| "Numa semana normal — quantas horas você gasta pensando em onde vai vir o próximo cliente?" | Custo em tempo |
| "Quando foi a última vez que você abordou ativamente um empresário que não te conhecia?" | Ausência de outbound |
| "Você sabe quais empresas da sua região pagam conta de energia alta e nunca ouviram falar de você?" | Oportunidade invisível |

**Momento do cálculo:**
> "Você me disse que fecha [X] clientes por mês e o ticket médio é R$[Y]. Se você tivesse conseguido 1 reunião qualificada por semana nas últimas 4 semanas, quantas oportunidades a mais você teria aberto?"

🔇 **SILÊNCIO.**
> "Em 4 semanas com 1 reunião por semana e ticket médio de R$[Y] — você deixou R$[4×Y] na mesa. Não porque o mercado está ruim. Porque não existia processo para ir buscar."

📌 Não faça a conta por ele. Quando ele disser o número: **"Exato."** — e continue.

---

## Bloco 4 — Tentativas Anteriores (20–23 min)

| Pergunta |
|---|
| "Você já tentou prospectar sozinho antes? O que aconteceu?" |
| "O que travou — foi saber para quem ligar, o que escrever, ou simplesmente não ter tempo?" |

**Como usar a resposta:**
- "Não sabia para quem mandar" → "A gente resolve isso em 20 min definindo o ICP."
- "Travei na hora de escrever" → "Por isso a gente escreve o script junto e manda as primeiras mensagens ao vivo."
- "Não tive tempo" → "Por isso é 90 minutos — você aparece, a gente faz junto. Sem homework."

📌 **Espelho.**

---

## Bloco 5 — Consequências (23–27 min)

| Pergunta |
|---|
| "Se você terminar esse mês sem uma reunião qualificada nova — o que acontece com o faturamento?" |
| "Essa situação de depender só de indicação — há quanto tempo está assim?" |
| "Se nada mudar nos próximos 3 meses, onde você vai estar?" |

🔇 **SILÊNCIO.** Turning point da call.

---

## Bloco 6 — Sonho (27–30 min)

| Pergunta |
|---|
| "Se você saísse daqui com uma reunião qualificada agendada para essa semana — o que mudaria para você?" |
| "Como seria prospectar sem travar na primeira mensagem?" |

📌 **Anote as palavras exatas.** Você vai repeti-las na apresentação.

---

## Transição

Antes de avançar, confirme que tem:
- [ ] Ticket médio (em reais)
- [ ] Confirmação de que não existe prospecção ativa
- [ ] Custo de oportunidade calculado (reuniões perdidas × ticket)
- [ ] O sonho dele em palavras dele

> "Tá. Deixa eu te contar o que a gente faz — porque acho que faz muito sentido para o que você me descreveu."

---

## Bloco 7 — Apresentação da Solução (30–40 min)

> "O Ignição Solo é uma sessão de 90 minutos onde a gente faz tudo junto — eu não te mando dever de casa."

**Apresente conectando cada bloco à dor dele:**

| Bloco da sessão | Como conectar |
|---|---|
| ICP em 20 min | "Você disse que não sabe para quem ligar — em 20 min a gente define." |
| Lista ao vivo em 30 min | "30 empresas com nome, segmento e contato do decisor. Você sai com o alvo na mão." |
| Script + 1as mensagens em 40 min | "O ponto que você disse que trava — a gente escreve e manda as primeiras 5 mensagens juntos, ao vivo." |

---

## Bloco 8 — Ancoragem e Fechamento (40–45 min)

**Passo 1 — Stack:**
> "O valor standalone dessa sessão é R$750. O investimento para fazer tudo isso hoje comigo é R$497."

**Passo 2 — Math:**
> "Você me disse que o ticket médio é R$[Y]. Uma única reunião qualificada que sair dessa sessão e vire proposta já paga o Ignição com troco. Você não está pagando R$497. Você está apostando R$497 para abrir uma oportunidade de R$[Y]."

🔇 **SILÊNCIO.**

**Passo 3 — Garantia:**
> "Se você aparecer na sessão, montar a lista e mandar as mensagens ao vivo comigo — e não tiver recebido nenhuma resposta em 7 dias — eu refaço os scripts e faço uma segunda sessão de ajuste sem custo."

**Passo 4 — Fechamento:**
> "Faz sentido para você? Quer começar essa semana?"

🔇 **SILÊNCIO TOTAL. O próximo que falar perde.**

---

## Bloco 9 — Objeções

**"Preciso pensar."**
> "Claro. O que especificamente — é sobre o valor, o timing ou se funciona para o seu caso?"

**"Está caro."**
> "Caro em relação ao quê? Uma reunião que vire proposta paga o Ignição Solo com troco — e você ainda sai com o script e a lista para continuar usando."

**"Não tenho tempo para 90 minutos."**
> "Você passa quantas horas por semana preocupado com onde vai vir o próximo cliente? 90 minutos uma única vez resolve isso essa semana."

**"Já tentei mensagem fria e não funcionou."**
> "O que você tentou foi no escuro — sem ICP, sem lista qualificada, sem script testado. Aqui a gente faz junto ao vivo. E se não tiver resposta em 7 dias, a gente refaz sem custo."

**"E se eu quiser o programa completo depois?"**
> "Os R$497 viram crédito no Ignição Comercial. Você experimenta com segurança e decide com prova."

---

## Bloco 10 — Depois do Sim

> "Perfeito. Vou te mandar o link de pagamento agora por WhatsApp."

- [ ] Link de pagamento enviado em até 5 minutos
- [ ] Confirmação do recebimento
- [ ] Link para agendar a sessão de 90 min ainda essa semana
- [ ] Confirmação rápida via WhatsApp na véspera

📌 **Não deixe esfriar. Link na mesma hora.**

---

**Ver também:** [[Ignição Comercial — Script de Diagnóstico v2]] | [[Ignição Solo — Oferta]] | [[Índice de Ofertas — L.M]]

---
fonte: Ignicao-Solo-Oferta-Entrada.docx.pdf
produto: Ignição Solo
agência: LM
preço: 497
nicho: Integradora Solar
tags: [oferta, ignição-solo, entrada, solar]
---

# Ignição Solo — Oferta de Entrada

> **Uma sessão de 90 minutos. Você sai com lista montada e as primeiras mensagens enviadas.**

---

## Para quem é

Dono de integradora solar que:
- Não tem time comercial ainda
- Não tem budget para o Ignição Comercial (R$5k)
- Quer prospectar mas trava na primeira mensagem
- Depende 100% de indicação e quer mudar isso sem gastar em tráfego

---

## O que acontece na sessão (90 min)

| Bloco | Tempo | Entrega |
|---|---|---|
| **ICP** — definir para quem prospectar | 20 min | Perfil da empresa e do decisor definidos |
| **Lista ao vivo** — montar junto | 30 min | 30 empresas com nome, segmento e contato |
| **Script + primeiras mensagens** | 40 min | Script adaptado + 5 mensagens enviadas ao vivo |

---

## Resultado esperado
Você sai da sessão com:
- [ ] Alvo definido (quem prospectar e quem ignorar)
- [ ] Lista de 30 empresas qualificadas na mão
- [ ] Script adaptado ao seu contexto
- [ ] Primeiras mensagens já enviadas — o maior bloqueio some

---

## Precificação

| Item | Valor |
|---|---|
| Valor standalone | R$ 750 |
| **Investimento** | **R$ 497** |

**Âncora:** ticket médio solar = R$25k–80k. Uma reunião qualificada que vire proposta paga o Ignição Solo com troco.

---

## Garantia
> "Se você aparecer na sessão, montar a lista e mandar as mensagens ao vivo — e não tiver recebido nenhuma resposta em 7 dias — eu refaço os scripts e faço uma segunda sessão de ajuste sem custo."

---

## Caminho natural depois do Ignição Solo

> "Quando você ver que o método funciona, os R$497 viram crédito no Ignição Comercial."

| Produto | Preço | Crédito |
|---|---|---|
| Ignição Solo | R$ 497 | — |
| Ignição Comercial | R$ 5.000 | R$497 de crédito |

---

**Ver também:** [[Ignição Solo — Script de Diagnóstico v1]] | [[Ignição Comercial — Oferta Completa]] | [[Índice de Ofertas — L.M]]

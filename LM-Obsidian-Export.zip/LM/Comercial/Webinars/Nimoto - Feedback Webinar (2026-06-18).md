# Feedback do Nimoto sobre o Webinar — call 18/06/2026

> Call no Fathom: https://fathom.video/calls/716395117 (a parte do webinar vai do início até ~22min; o resto foi sobre leads/CRM/oferta da LM).

## Diagnóstico geral
- Métricas **não estão ruins**. Presentes → reuniões marcadas tá ótimo, conversão boa. Comparecimento (show-up) tá um pouquinho fraco.
- Dois únicos furos: **pouco pitch** e falta de **"explosão na cabeça"** pra reter.
- O evento **demora a engatar** (que nem trem) e o engajamento **começa a cair lá pelos 21 min**.
- **NÃO mudar conteúdo nem estrutura** — está certo. São micro-ajustes, não macro.

## As 4 jogadas dele
1. **Microtarefas a cada ~5-10 min.** O tempo todo: ou provocação ou microresultado. Ex. (prospecção): "decide o nicho agora, anota. Quais setores na tua cidade mais gastam energia? Quem já mapeou? Quem não mapeou? Quem mapeou, qual foi a estratégia?". A pessoa sai com coisa FEITA. Dá pra pedir as tarefas pra IA.
2. **Antecipar a oferta no meio.** Solta a isca do entregável: "eu nem poderia fazer isso, mas no fim vou te fazer uma proposta de fazer isso contigo de graça. Quem quer?". Gera retenção (o cara segura até o fim pra saber como pega o prêmio).
3. **Chamar gente pelo nome.** Sempre que exemplificar, puxa alguém de câmera ligada. Quando um interage, os outros querem também.
4. **Pitch com energia e incisivo.** O problema não é o QUE fala, é o JEITO. Frase de custo de inação: *"e se a gente entrar nesse bate-papo e eu mudar o destino da tua empresa? Quanto que vai ter te custado por NÃO ter entrado?"*. Macete pra não ler: tratar a apresentação como **música** (começa a cantar e o resto vem). Valentino notou que o pitch tava curto demais.

## Onde já caiu no nosso script (Copa)
Aplicado no roteiro detalhado e na colinha de tópicos (18/06):
- Microtarefa nova no **slide 5** (quanto a conta do maior cliente sobe na Copa), **slide 11** (anota 1 bar que enche em dia de jogo), **slide 12** (escolhe 1 cliente com vizinho reclamando). Já tínhamos interação no 3, 7 e 14 → agora fica ~1 a cada 5 min.
- **Antecipação da oferta no slide 9** (a Máquina): "no fim vou te fazer uma proposta... quem quer, digita EU QUERO".
- **Pitch reforçado no slide 15/16:** energia, incisivo, frase de custo de inação, amarrado com a isca do slide 9.
- **Etapa do arco marcada em cada slide** da colinha (atenção/pico, surpresa, dor, quebra de crença, esperança, chamado) pra guiar o tom.

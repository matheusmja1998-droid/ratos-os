# A Máquina de Indicação da Copa — Tópicos por slide

> Colinha de apresentação. NÃO é fala-por-fala, são os tópicos do que falar em cada slide. Glance e fala com tuas palavras (que nem cantar música: começa a frase e o resto vem). Deck: 16 slides.
>
> **Marcadores:** 〔ETAPA〕 = onde tu tá no arco, te guia o TOM. 💬 = script/número pra citar. ✋ = MICROTAREFA (manda a galera FAZER algo e lê 2-3 do chat PELO NOME). 🎁 = antecipa a oferta. Scripts completos ficam no "Arsenal" (handout).
>
> **As 3 dicas do Nimoto pra esse webinar:** (1) microtarefa a cada ~5 min pra não cair o engajamento (o evento caía lá pelos 21 min); (2) NÃO leia, só tópicos, e chama gente pelo nome o tempo todo; (3) o pitch é o momento mais importante: energia lá em cima e mais incisivo.

---

## SLIDE 1 — CAPA
**〔AQUECIMENTO · pertencimento〕** (Valentino abre)
- Boas-vindas, 3 combinados: ao vivo (chat), liga a câmera, ninguém vai te vender nada.
- "Pega papel e caneta, hoje é pra anotar."

## SLIDE 2 — CHOQUE
**〔ABERTURA · PICO DE ATENÇÃO〕** tom: energia alta, provocação
- A Copa vai movimentar bilhões em 39 dias. Quanto vai cair na tua integradora? Zero, se esperar.
- Promessa concreta: tu sai daqui com scripts no caderno + plano de 3 passos pra começar amanhã.

## SLIDE 3 — IDENTIFICAÇÃO + AÇÃO AO VIVO
**〔ABERTURA · ATENÇÃO〕**
- Quem eu sou (rápido) + "não vou te vender nada, é conteúdo".
- ✋ MICROTAREFA: "Abre o WhatsApp AGORA e conta quantos orçamentos parados tu tem. Digita no chat." (lê 3-4 PELO NOME)
- Esse número é a primeira mina. Teu mês hoje é uma roleta; a ideia é tirar tua empresa da roleta.

## SLIDE 4 — PROMESSA
**〔ABERTURA · ATENÇÃO〕**
- O que leva hoje, tudo concreto: (1) os scripts, anotados na tela; (2) o plano de 3 passos; (3) a rotina de 15 min que faz virar venda.
- "Caneta na mão."

## SLIDE 5 — 1ª REVELAÇÃO
**〔1ª REVELAÇÃO · SURPRESA〕**
- A Copa não é futebol pro teu negócio. É o maior pico de conta de luz do ano.
- Pra faturar nessa Copa tu não precisa de anúncio. Precisa de roteiro.
- ✋ MICROTAREFA: "Pensa no teu maior cliente AGORA. Quanto a conta de luz dele sobe num mês de Copa? Joga o número no chat." (lê 2-3 PELO NOME)

## SLIDE 6 — A COPA PASSA, A INDICAÇÃO FICA
**〔1ª REVELAÇÃO · SURPRESA〕**
- Solar é compra única. O ativo não é recompra, é a indicação.
- Cada cliente tem ~5 vizinhos reclamando da conta. Só nunca foi provocado a indicar.
- "Lembrei de ti na Copa" abre porta; "vai fechar?" fecha. A Copa dá o contexto de graça.

## SLIDE 7 — A DOR
**〔IDENTIFICAÇÃO + DOR · 5 min de desconforto proposital〕** tom: baixa a energia, pesa a dor, sem pressa
- "Vou te deixar desconfortável de propósito."
- Bar lotado todo jogo, conta recorde, e tu não bate na porta. (✋ "quem já olhou pro bar cheio e nunca pensou nisso? digita EU")
- Orçamentos parados = comissão que não entra.
- O concorrente com kit pior usa a Copa, fala toda semana, e leva teu cliente. Ele falou, tu calou.

## SLIDE 8 — O QUE TE DEIXA NO BANCO
**〔QUEBRA DE CRENÇA · o coração do webinar〕** tom: firme, "te tiro do banco"
- Abre: 3 desculpas que te seguram no banco enquanto a Copa rola. "Carreguei todas, sem julgamento. Bora te tirar do banco."
- Banco "prospecção queima minha marca" → Campo: convite + análise grátis, é autoridade (não é telemarketing).
- Banco "cliente não indica do nada" → Campo: indicação se pede, no momento certo. A Copa é a desculpa.
- Banco "se precisar, ele me procura" → Campo: quem espera apanha no leilão dos 5 orçamentos; chega antes.
- Fecha NA FALA (sem slide): "isso é pra empresa grande?" Custo zero, no teu WhatsApp, com quem tu já tem. Saiu do banco, sobra fazer.

## SLIDE 9 — A MÁQUINA
**〔ENTREGA DE VALOR · ALÍVIO + ESPERANÇA〕** tom: vira a chave, sobe a energia
- O sistema tem 5 jogadas, e o coração é UM ENCONTRO: juntar a turma de clientes num bar pra ver o jogo.
- Apresenta as 5: Bola Parada, Camarote, Terceiro Tempo, Torcida, Vestiário.
- "Cada jogada vem com o script na tela pra anotar."
- 🎁 ANTECIPA A OFERTA: "No fim eu vou te fazer uma proposta. Eu e o Valentino numa call de 45 min montando essa Máquina pra TUA cidade, de graça. Quem quer, digita EU QUERO." (segura a galera até o fim, é o que gera retenção)

## SLIDE 10 — JOGADA 1: A BOLA PARADA
**〔ENTREGA DE VALOR · ESPERANÇA〕**
- O orçamento travado tu não cobra, tu CONVIDA pra ver o jogo junto.
- No clima do boteco, sem pressão, destrava o negócio parado há meses.
- 💬 Script do convite (na tela): "vou levar uns clientes pra ver o jogo, bora? sem papo de venda. e se quiser te atualizo o número do solar."

## SLIDE 11 — JOGADA 2: O CAMAROTE
**〔ENTREGA DE VALOR · ESPERANÇA〕**
- Parceria com o bar, não aluguel: desconto pro teu grupo, casa cheia pro dono, custo zero.
- A turma de clientes reunida = networking.
- Pulo do gato: a conta do bar explode na Copa. Vende solar pro dono na mesma conversa.
- 💬 Script da parceria + a emenda da análise grátis pro dono (na tela).
- ✋ MICROTAREFA: "Anota AGORA o nome de 1 bar perto de ti que enche em dia de jogo. Esse é teu primeiro Camarote."

## SLIDE 12 — JOGADA 3: O TERCEIRO TEMPO
**〔ENTREGA DE VALOR · ESPERANÇA〕**
- Depois do jogo, galera reunida e feliz: a hora de ouro pra pedir indicação.
- Olho no olho, não mensagem fria. Pede nome específico (vizinho, parente, sócio).
- Prêmio de indicação só sai depois que a venda fecha (caixa protegido).
- 💬 Script do pedido presencial (na tela).
- ✋ MICROTAREFA: "Escolhe AGORA 1 cliente teu que com certeza tem vizinho reclamando de luz. Anota o nome. É a tua primeira indicação da Copa."

## SLIDE 13 — JOGADAS 4 e 5: A TORCIDA e O VESTIÁRIO
**〔ENTREGA DE VALOR · ESPERANÇA〕**
- Torcida: presença os 39 dias sem mídia. 3 status por jogo (pré/intervalo/pós) + grupo de resenha.
- Vestiário: a rotina dos bastidores. Tudo que sai do encontro (negócio, indicação, contato) tu anota num lugar só (bloco de notas serve) e dá um toque, 15 min toda manhã.
- A Copa acaba em 39 dias, mas o lead fecha semanas depois. Sem o Vestiário, vaza tudo.

## SLIDE 14 — PLANO DE AÇÃO
**〔PLANO DE AÇÃO · ação〕** tom: prático, direto, "anota e faz"
- Passo 1 (essa semana): fecha a parceria com 1 bar + oferece análise grátis pro dono.
- Passo 2 (próximo jogo): chama clientes + orçamentos parados pro encontro. Destrava e pede indicação.
- Passo 3 (toda manhã): revisa tua lista de contatos do encontro e dá os toques, 15 min.
- ✋ MICROTAREFA: "Quem vai marcar pelo menos 1 encontro nessa Copa, digita EU VOU." (compromisso, lê os nomes)

## SLIDE 15 — O CONVITE / CTA (o pitch)
**〔CHAMADO · O PITCH〕** tom: ENERGIA NO TALO, incisivo, NÃO lê. É o momento mais importante do evento.
- Tu já sai com tudo pra fazer sozinho + recebe o material com os 52 scripts hoje.
- Pra quem quer ir além: diagnóstico de 45 min, eu e o Valentino, montando a Máquina pra tua cidade e tua base. Sem custo.
- 💬 Custo de inação (Nimoto): "e se a gente entrar nesse bate-papo e eu mudar o destino da tua empresa? Quanto que vai ter te custado por NÃO ter entrado?"
- Incisivo, sem pressa: "eu QUERO mudar tua empresa, eu quero fazer isso contigo." Não corta curto, segura no pitch.
- Fechamento: chama quem te convidou no WhatsApp e manda 2 horários.

## SLIDE 16 — ENCERRAMENTO
**〔FINALIZAÇÃO〕**
- Frase: "A Copa passa em 39 dias. O cliente que tu pega agora indica por anos."
- Tarefa de amanhã (escolhe 1): lista os parados e dispara o 1º script, OU manda a Pergunta da Conta de Luz pros 5 melhores clientes.
- "Me conta no WhatsApp o que aconteceu."

---

**Material de apoio (não é slide):** o "Arsenal dos 52 scripts" prontos fica no roteiro detalhado / handout PDF. Os scripts completos de cada jogada (Bola Parada, Camarote, Terceiro Tempo) estão lá pra colar na tela quando tu chegar na jogada.

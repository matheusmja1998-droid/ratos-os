# Prompt pronto pra colar no Claude (design) — Deck "A Máquina de Indicação da Copa"

> Cola tudo abaixo da linha no Claude. Se ele cortar, manda "continua" que ele termina o HTML.

---

Você é um diretor de arte e front-end sênior. Crie uma **apresentação de slides premium, em UM único arquivo HTML autocontido** (só Google Fonts como dependência externa), no nível de qualidade de um deck cinematográfico de produto de luxo. O tema é um webinar B2B chamado **"A Máquina de Indicação da Copa"**, da consultoria **L.M Consultoria**, para donos de integradoras de energia solar.

## Referência estética (siga de perto)
Pense nos slides de evento de alto padrão: **fundo preto absoluto**, um **objeto-herói renderizado em 3D** ocupando metade do slide, título enorme em caixa-alta, pouquíssimo texto, e bullets no formato **ícone fino + rótulo em dourado + uma linha curta de descrição**. Atmosfera escura, luz volumétrica roxa, detalhes dourados metálicos. Caro, sofisticado, com profundidade. NADA de slide chapado ou simples.

## Identidade visual (use exatamente)
- **Fundo:** preto profundo levemente arroxeado, `#07070C` a `#0B0A14`. Use gradientes radiais, vinheta forte, leve textura de grão (filme) e um halo roxo difuso por trás do herói.
- **Dourado (cor de destaque, números e palavras-chave):** gradiente `#F8E7B0 → #E9C063 → #B8801F`, com brilho suave. Dourado = dinheiro/indicação, é a alma do deck.
- **Roxo/violeta (atmosfera, brilhos, halos):** `#8B5CF6`, `#A98BFF`, profundo `#3A1D7A`.
- **Branco quente (texto):** `#F4F0E6`. **Cinza (descrições):** `#9B94AD`.
- **Tipografia (NÃO use Inter/Roboto/Arial):** títulos em **Archivo (peso 800/900)** ou **Anton**, caixa-alta, bem condensados e pesados; corpo em **Manrope**. Números e palavras de destaque ganham o gradiente dourado com `background-clip:text`.

## Sistema de layout
- 16:9, design base 1920x1080, responsivo, ocupa a tela inteira.
- Cada slide de conteúdo: **coluna de texto** (título caixa-alta + 1 linha de subtítulo + até 3 bullets) e **coluna do herói 3D**. Alterne o lado do herói (esquerda/direita) entre os slides pra dar ritmo.
- Bullets no padrão da referência: caixinha de ícone (line-icon fino, traço dourado) + **rótulo curto em dourado (Archivo bold)** + uma linha de descrição em cinza. No máximo 3 por slide.
- "Eyebrow" (sobrelinha) pequena em maiúsculas espaçadas, dourada, acima de cada título.
- Canto superior: marca **L.M Consultoria** (com um ponto dourado). Rodapé: contador `01 / 18` + barra de progresso dourada fininha.

## Riqueza visual obrigatória (o que faltou antes: não pode ficar simples)
- Cada herói 3D deve ter **profundidade real**: camadas, sombras suaves, brilho/glow, reflexo, e um **pedestal elíptico com halo roxo** embaixo. Pode usar CSS 3D, SVG, gradientes cônicos/radiais e blur. Se o ambiente permitir gerar imagem, gere o herói; senão, construa em CSS/SVG caprichado.
- Partículas de poeira luminosa flutuando, anéis orbitais, leve animação de flutuar (float) no herói.
- Glassmorphism (blur + transparência) nos cards/bullets. Gradiente dourado nos números e palavras-chave. Vinheta + grão no fundo.
- Animação de entrada com stagger (título, depois bullets, depois herói) a cada troca de slide.

## Navegação
Setas ← →, espaço e clique nas laterais trocam de slide. `Home`/`End` vão pro início/fim. Mostre o número do slide e a barra de progresso. Transição suave (fade + leve translate) entre slides.

## Regras de conteúdo
- **Pouco texto.** Título curto, uma linha de subtítulo, bullets de no máximo 1 linha. O herói e o espaço negativo fazem o trabalho.
- Sem travessão (—). Use ":" ou "|". Tom direto, informal, "você/tu".
- Marca sempre "[TUA EMPRESA]", nunca nome real de cliente.

## OS 18 SLIDES (conteúdo fiel ao roteiro, siga à risca)

**Slide 1 — CAPA**
- Eyebrow: L.M CONSULTORIA · WEBINAR AO VIVO
- Título: A MÁQUINA DE INDICAÇÃO DA COPA (com "INDICAÇÃO" em dourado)
- Subtítulo: Como transformar 39 dias de futebol no maior pico de vendas do ano da sua integradora. Sem gastar um real.
- Herói: um emblema/troféu dourado abstrato (losango ou obelisco de ouro maciço) sobre pedestal, anéis orbitais girando, partículas roxas. *Render: glowing solid-gold abstract trophy emblem on a black pedestal, purple volumetric rim light, floating dust particles, cinematic, 3D render.*

**Slide 2 — CHOQUE**
- Eyebrow: A PERGUNTA DE BILHÕES
- Título: BILHÕES VÃO CIRCULAR NA COPA
- Subtítulo: E quanto disso vai cair na sua integradora?
- Destaque (chip/pílula dourada): "ZERO se você esperar o cliente aparecer."
- Herói: pilhas de moedas de ouro brilhando, com algumas moedas escapando/caindo no escuro. *Render: stacks of glowing gold coins on black, a few coins falling away into darkness, volumetric purple light, 3D render.*

**Slide 3 — IDENTIFICAÇÃO (a roleta)**
- Eyebrow: A SUA REALIDADE
- Título: O SEU MÊS É UMA ROLETA
- Subtítulo: Indicação, anúncio, espera. E a folha vence todo dia 5.
- Bullets: **Veio indicação** — mês bom, respira. / **Não veio** — mês de aperto. / **O telefone na mão** — o dia inteiro esperando tocar.
- Herói: uma roleta de cassino estilizada / órbitas concêntricas com uma esfera de vidro roxa girando no centro, luz dramática. *Render: stylized glass roulette wheel with a glowing violet sphere at center, concentric orbital rings, dramatic light, 3D render.*

**Slide 4 — PROMESSA**
- Eyebrow: O QUE VOCÊ LEVA HOJE
- Título: TRÊS ARMAS PRONTAS
- Subtítulo: Custo zero. Pra aplicar amanhã de manhã.
- Bullets: **A Gaveta** — scripts pra reabrir todo orçamento parado. / **A Máquina** — seu cliente satisfeito virando seu vendedor. / **O Ataque** — todo comércio com a conta explodindo na Copa.
- Herói: três painéis/cartas de vidro flutuando em leque, cada um com um selo dourado. *Render: three floating glass panels in a fan, each with a glowing gold seal, purple glow, 3D render.*

**Slide 5 — PRIMEIRA REVELAÇÃO**
- Eyebrow: PRIMEIRA REVELAÇÃO
- Título: A COPA NÃO É FUTEBOL
- Subtítulo: É o maior pico de conta de luz do ano. 39 dias com a cidade inteira gastando energia em dobro. E essa é exatamente a dor que você resolve.
- Herói: um raio/relâmpago de energia dourado descendo sobre um pedestal, ou um medidor de energia disparando. *Render: a golden lightning bolt of energy striking a pedestal, sparks, purple haze, 3D render.*

**Slide 6 — SEGUNDA PARTE DA REVELAÇÃO**
- Eyebrow: O JOGO
- Título: A COPA PASSA, A INDICAÇÃO FICA
- Bullets: **Compra única** — o cliente instala uma vez, recompra não existe. / **O ativo é a indicação** — cada cliente tem 5 vizinhos reclamando da conta. / **Não precisa de anúncio** — precisa de roteiro, e a Copa é a desculpa de graça.
- Herói: uma ampulheta de vidro onde a areia, ao cair, vira uma rede de pontos conectados que permanece brilhando embaixo (o tempo passa, a rede fica). *Render: glass hourglass whose violet sand turns into a glowing connected network at the bottom, gold frame, 3D render.*

**Slide 7 — A DOR**
- Eyebrow: O CUSTO DE ESPERAR
- Título: OS 39 DIAS QUE PASSAM DO SEU LADO
- Bullets: **O bar lotado** — conta de luz batendo recorde, e você não bate na porta. / **Os orçamentos parados** — cada mês parado é comissão que não entra. / **O concorrente** — usa a Copa, fala toda semana, e leva o cliente que era seu.
- Herói: uma esfera se apagando/drenando, luz fria, areia escorrendo pelo escuro. *Render: a dimming, draining sphere losing its glow, cold light, sand slipping into the dark, 3D render.*

**Slide 8 — QUEBRA DE CRENÇAS**
- Eyebrow: O QUE TE TRAVA DE VERDADE
- Título: AS 4 MENTIRAS
- Layout: 4 linhas, cada uma com a mentira riscada (cinza) → seta → a verdade (dourado):
  1. "Prospecção queima minha marca" → É convite e análise grátis. É autoridade.
  2. "Meu cliente não indica do nada" → Indicação não cai. Se pede, no momento certo.
  3. "Se precisar, o cliente me procura" → Quem espera apanha no leilão dos 5 orçamentos.
  4. "Isso é coisa de empresa grande" → Custo zero. No seu WhatsApp, com quem você já tem.
- Herói: um painel/vidro estilhaçando em 4 cacos que se desfazem em luz dourada. *Render: a dark glass panel shattering into four shards dissolving into golden light, 3D render.*

**Slide 9 — A MÁQUINA (o sistema numa tela)**
- Eyebrow: O SISTEMA COMPLETO
- Título: A MÁQUINA DE INDICAÇÃO
- Subtítulo: Cinco jogadas. Do dinheiro fácil que já está na sua gaveta ao sistema que não deixa nada escapar.
- Centro: um **diagrama de 5 nós conectados** (engrenagem/máquina premium), numerados: 1 Bola Parada · 2 Time dos Indicadores · 3 Ataque ao Comércio · 4 A Torcida · 5 O Segundo Tempo. Nós com brilho dourado, conexões em gradiente dourado-roxo. *Render: an elegant 5-node connected machine diagram, gold nodes, violet-gold energy connections, premium tech, 3D render.*

**Slide 10 — JOGADA 1: A BOLA PARADA**
- Eyebrow: JOGADA 1
- Título: A BOLA PARADA
- Subtítulo: O gol fácil que já está na sua gaveta.
- Bullets: **Foco** — o orçamento que travou: já viu preço, só não fechou. / **Gatilho** — "lembrei de você na Copa", nunca "vai fechar?". / **Resultado** — o dinheiro mais rápido da campanha inteira.
- Herói: uma bola de futebol dourada parada sobre o gramado/pedestal, com um feixe de luz vindo de cima (bola parada). *Render: a golden football resting on a pedestal under a single dramatic spotlight beam, 3D render.*

**Slide 11 — JOGADA 2: O TIME DOS INDICADORES**
- Eyebrow: JOGADA 2
- Título: O TIME DOS INDICADORES
- Subtítulo: Seu cliente satisfeito vira seu melhor vendedor.
- Bullets: **Momento** — o apito final do jogo, no pico da euforia. / **Pedido** — nome específico, nunca "alguém". / **Prêmio** — só sai depois que a venda fecha. Caixa protegido.
- Herói: um nó central dourado irradiando linhas para muitos nós roxos ao redor (rede de pessoas/constelação). *Render: a central gold hub radiating glowing lines to many violet nodes, constellation of people, 3D render.*

**Slide 12 — JOGADA 3: O ATAQUE AO COMÉRCIO**
- Eyebrow: JOGADA 3
- Título: O ATAQUE AO COMÉRCIO
- Subtítulo: Todo bar e comércio com a conta explodindo na Copa.
- Bullets: **Gancho** — a conta sobe na Copa, você oferece análise grátis. / **Alvo** — bar, padaria, açougue, academia, posto. / **Sacada** — o bar é parceiro E o seu maior cliente.
- Herói: uma fileira/grade de fachadas de comércio estilizadas, uma delas acesa em dourado. *Render: a stylized row of small storefronts on black, one glowing gold, purple ambient, 3D render.*

**Slide 13 — JOGADA 4: A TORCIDA**
- Eyebrow: JOGADA 4
- Título: A TORCIDA
- Subtítulo: Presente 39 dias sem gastar um real de mídia.
- Bullets: **Conteúdo** — 3 posts por jogo, salvos no celular, no automático. / **Grupo** — a resenha dos jogos vira canal de indicação. / **Custo** — zero. Você surfa a atenção do jogo de graça.
- Herói: uma onda de equalizer/torcida em barras douradas e roxas, ou uma arquibancada estilizada de luz. *Render: a glowing equalizer wave of gold and violet bars, stadium crowd energy, 3D render.*

**Slide 14 — JOGADA 5: O SEGUNDO TEMPO**
- Eyebrow: JOGADA 5
- Título: O SEGUNDO TEMPO
- Subtítulo: O que separa quem fatura de quem só agita.
- Bullets: **O Cofre** — uma planilha, e cada linha vale milhares. / **O Ritmo** — 15 minutos por dia. / **A Verdade** — a Copa acaba, mas o lead solar fecha semanas depois.
- Herói: um cronômetro/relógio premium dourado fundido com um funil de luz. *Render: a premium gold stopwatch merged with a funnel of light, 3D render.*

**Slide 15 — DEMONSTRAÇÃO: O COFRE**
- Eyebrow: DEMONSTRAÇÃO AO VIVO
- Título: O COFRE, MONTADO AGORA
- Subtítulo: Zero ferramenta cara. Uma planilha de 8 colunas que guarda cada indicação antes que ela evapore com o fim dos jogos.
- Herói: um cofre/vault de aço com porta entreaberta vazando luz dourada, ou uma grade de planilha brilhando com algumas células acesas em dourado. *Render: a steel vault door ajar leaking golden light, OR a glowing spreadsheet grid with gold-lit cells, 3D render.*

**Slide 16 — A ANATOMIA DO PEDIDO**
- Eyebrow: POR QUE CADA PALAVRA FUNCIONA
- Título: A ANATOMIA DO PEDIDO
- Layout: mostre uma **mensagem de WhatsApp estilizada** (balão de chat) com a frase, e 4 chamadas (callouts) douradas apontando cada trecho:
  - "Fala [Nome], pronto pro jogo?" → o gancho da Copa, abre leve.
  - "Quanto você economiza por mês?" → faz o CLIENTE dizer o número.
  - "Quem na sua rua ainda paga essa fortuna?" → nome específico, não "alguém".
  - "Me dá um nome que eu cuido." → pedido pequeno, fechamento leve.
- Herói/visual: o balão de chat dourado/escuro flutuando com as 4 linhas conectadas a etiquetas douradas. *Render: a dark glossy chat bubble floating with four gold annotation tags pointing to phrases, 3D render.*

**Slide 17 — CHAMADO (CTA)**
- Eyebrow: O PRÓXIMO PASSO
- Título: VAMOS MONTAR A SUA?
- Subtítulo: 45 minutos, eu e o Valentino, montando a sua Máquina pra sua cidade e sua base. Sem custo.
- Bullets: **Chama quem te convidou** — no WhatsApp, agora. / **Manda dois horários** — a gente encaixa na agenda.
- Herói: o emblema dourado da capa, agora com uma seta/portal de luz apontando pra frente. *Render: the gold emblem with a forward arrow/portal of light, inviting, 3D render.*

**Slide 18 — ENCERRAMENTO**
- Eyebrow: BORA FATURAR
- Frase grande (caixa-alta, "indica por anos" em dourado): "A COPA PASSA EM 39 DIAS. O CLIENTE QUE VOCÊ PEGA AGORA INDICA POR ANOS."
- Rodapé centralizado: marca L.M Consultoria.
- Fundo: o mais cinematográfico de todos, halo roxo amplo + partículas douradas.

## Entrega
Devolva o **HTML completo, em um único arquivo**, pronto pra abrir no navegador e apresentar em tela cheia. Capriche nos detalhes: brilhos, profundidade, grão, animação de entrada. Se faltar espaço na resposta, continue de onde parou quando eu disser "continua".

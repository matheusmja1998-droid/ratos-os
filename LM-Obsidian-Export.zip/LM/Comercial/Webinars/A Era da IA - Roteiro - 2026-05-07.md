# Roteiro Estrutural — Operação Invisível
**Webinar:** quinta-feira, 07 de maio de 2026
**Big idea:** Operação Invisível (os 6 instrumentos que rodam atrás da estrutura das agências que escalam sem contratar)
**Público:** agências de tráfego que já rodam com clientes (gestor solo até agência média)
**Duração-alvo:** 50-55 min
**CTA:** conversa de 30min → participante chama **quem o convidou** no WhatsApp com 1 dia + 2 horários disponíveis
**Identidade visual:** Cockpit (neon ciano/roxo, dark mode profundo)
**Deck:** 14 slides em `slides-operacao-invisivel/index.html`

> Cada bloco mostra o slide ativo. Os slides são curtos por design — você fala o roteiro completo enquanto eles ficam na tela.

---

## BLOCO 1 — AQUECIMENTO (Tino) | 0:00 – 7:00

### ▶ Slide 1 — Capa "Operação Invisível"

Meu nome é Valentino, sou um dos CEOs da L.M. Já já o Matheus entra pra dar início ao evento, antes disso quero alinhar algumas coisas com vocês.

Se você tá aqui hoje é porque a gente olhou a tua agência e viu que faz sentido tu estar nesse evento. Não é pra qualquer agência de tráfego. A gente selecionou agências e gestores que já rodam operação de verdade, com cliente real, dinheiro real rodando, e que a gente acredita que podem multiplicar a operação nos próximos meses sem contratar ninguém.

Esse é um evento ao vivo. Teve insight, dúvida, opinião, manda no chat que o Matheus responde. Quem puder ligar a câmera, liga, isso muda a energia do evento.

Vocês são gestores. Tô vendo a tela de vocês daqui. WhatsApp piscando, cliente cobrando, criativo pra subir, planilha aberta. Eu sei que tá assim. E é exatamente por isso que eu peço: dedica 50 minutos. Tira o WhatsApp do lado, fecha a aba do gerenciador, foca. Porque o que o Matheus vai mostrar é o que tá rodando atrás dos ads das agências que escalam sem virar fábrica de gente.

Nosso objetivo aqui não é vender nada. É mostrar como agência de tráfego escala a operação sem dobrar o time, sem virar a noite e sem perder cliente no caminho.

**Aquecimento de chat (ainda no Slide 1):**
- De qual cidade vocês tão vendo a gente? Comenta no chat.
- Há quanto tempo vocês tão rodando tráfego? Quantas contas vocês tocam hoje? Manda o número.
- Pessoal de 5+ contas, joga 🙋 no chat.

Ninguém aqui é concorrente. Tão todos no mesmo barco. Dediquem esse tempo pra anotar o máximo. Matheus, passo pra ti.

---

## BLOCO 2 — ABERTURA COM AUTORIDADE (Matheus) | 7:00 – 12:00

### ▶ Slide 2 — Autoridade (+20 contas, +R$6mi, verticais)

Eu sou o Matheus, opero tráfego há [X] anos. Hoje toco mais de 20 contas em paralelo entre WinVision e L.M. Já passei dos R$ 6 milhões rodados em mídia. Cliente em lançamento, ecommerce, B2B, infoproduto e negócio local.

E eu vou ser direto: não vou falar de criativo, não vou falar de copy, não vou falar de estratégia de campanha. Tem 500 caras falando isso melhor do que eu faria. Eu vou falar do que ninguém ensina: a **Operação Invisível** que roda atrás dos ads das agências que escalam.

### ▶ Slide 3 — Micro-revelação "9 em 10"

Quero começar com um dado que vai te incomodar. **9 em cada 10** gestores que eu olho operam ads do mesmo jeito que se operava em 2019. Mesma planilha, mesma rotina, mesmo gerenciador aberto 30 vezes por dia.

O problema não é falta de esforço. É que o jogo mudou e o instrumento não. Em 2026, IA não é mais "vai chegar". Já chegou. E quem entendeu primeiro tá rodando 3x mais conta com 1/3 do esforço. Quem não entendeu, tá brigando pra não perder cliente todo mês.

### ▶ Slide 4 — Promessa do webinar

Eu prometo 3 coisas. Se eu não cumprir até os 45 minutos, pode sair que eu não te incomodo:

1. Você vai sair sabendo **por que** tu tá sufocado mesmo trabalhando 12h por dia.
2. Vai conhecer os **6 instrumentos** que toda operação grande tem rodando 24/7 e que tu não tem.
3. Vai sair com **1 coisa** que dá pra plugar na tua operação ainda essa semana, sem contratar ninguém.

E faço um desafio: testa **uma coisa** que eu falar aqui hoje. Hoje ainda. Vai ver que dá resultado.

---

## BLOCO 3 — TENSÃO | 12:00 – 19:00

### ▶ Slide 5 — Modelo antigo: apagar incêndio

O modelo que todo gestor usa hoje: abre o gerenciador de manhã, olha campanha por campanha, pausa o que tá ruim no olho, sobe criativo na mão, manda relatório no domingo, responde cliente em pânico no WhatsApp quando o ROI cai. Isso não é operação. **Isso é apagar incêndio.**

E quando o cliente pergunta "como tá o ROI?", você trava. Porque tu não tem dado consolidado, tem 4 abas abertas, tem que abrir cada conta uma a uma. Você fica no meio, dependendo da memória.

### ▶ Slide 6 — Espelho da realidade

Quem aqui já abriu o gerenciador no fim de semana? Manda 🙋 no chat.

Quem já queimou mais de R$ 500 num criativo morto que devia ter pausado horas antes?

Quem o cliente já perguntou "qual o ROI?" e você não soube responder com precisão?

Quem pulou viagem, fim de semana ou jantar em família por causa de campanha?

*[Lê 3-4 respostas em voz alta. Comenta cada uma.]*

Tá rolando muito 🙋 aí, eu sei. Não é falha tua. É falha de **instrumento**.

### ▶ Slide 7 — 3 consequências

Três coisas vão acontecer com quem continuar assim:

1. **Tu vira o teto da própria operação.** Cresce até onde tu aguenta. E tu não aguenta muito.
2. **O cliente bom sai antes do cliente ruim.** Porque o bom tem pra onde ir. O ruim não.
3. **Daqui 12 meses, tu não disputa mais com agência. Disputa com IA.** E IA não dorme, não adoece, não tira férias.

---

## BLOCO 4 — LIBERAÇÃO | 19:00 – 22:00

### ▶ Slide 8 — Operação Invisível (big idea)

Eu passei por tudo isso. Operação cheia, criativo queimando, cliente cobrando ROI, domingo morto fazendo relatório. Até que eu parei e pensei: **se agência grande consegue rodar 30 contas com 1 time, alguma coisa eles têm que eu não tenho. Não é gente. É instrumento.**

Aí eu fui montar. Testei, quebrei a cara, refiz. E hoje rodo a operação de mais de 20 contas em paralelo com a mesma stack. E o melhor: instalo essa stack em outras agências e o jogo delas vira em 2 semanas.

Eu chamo isso de **Operação Invisível**. São os 6 instrumentos que rodam 24/7 atrás da estrutura das agências que escalam. E é isso que eu vou te mostrar agora.

---

## BLOCO 5 — CONTEÚDO PRINCIPAL | 22:00 – 47:00

### 5.1 — Quebra de crenças

### ▶ Slide 9 — As 4 crenças que te travam

Antes de mostrar os instrumentos, preciso tirar 4 pedras do caminho. Porque se essas crenças tiverem na tua cabeça, tu vai assistir o resto e não vai aplicar nada.

**Crença 1: "É mais fácil fazer eu mesmo."**
Mais fácil hoje. Insustentável amanhã. Tu tá comprando velocidade no curto prazo trocando por liberdade no longo. E quanto mais cliente entra, mais cara fica essa troca.

**Crença 2: "Meu cliente é diferente, não dá pra automatizar."**
80% da tua operação é igual em todo cliente. Subir criativo, pausar, duplicar, reportar, debriefar. Cada cliente tem sua estratégia, claro. Mas a execução é a mesma. E é aí que mora o teu tempo.

**Crença 3: "Quando eu tiver tempo, eu monto."**
Tu nunca vai ter tempo. Quem tá no operacional não monta operação. Justamente por isso precisa montar agora, com a estrutura que tu tem, antes de pegar o próximo cliente.

**Crença 4: "IA é pra quem não sabe operar."**
É o contrário. IA é pra quem sabe demais e cansou de fazer manual. Quem não sabe, pede pra IA fazer e a IA faz errado. Quem sabe, usa IA pra escalar o que já domina.

### 5.2 — Os 6 Instrumentos da Operação Invisível

### ▶ Slide 10 — Os 6 instrumentos (overview)

Esses são os 6 instrumentos. Não vou ensinar a instalar. Vou mostrar **o que cada um faz** e **o que muda na operação**.

**1. O Vigia — vigia enquanto você dorme.**
Cliente meu, ad queimando R$ 1.247 num sábado. Telegram alerta às 7h da manhã: "criativo X queimou R$ 1.247 sem conversão. Pausar?". Pauso pelo celular. Salvou R$ 3 mil em 48h. Tu nunca mais vai abrir o gerenciador no fim de semana.

**2. O Comando — troca clique por palavra. [DEMO AO VIVO]**
Vou abrir uma conta real aqui. Vou digitar 3 comandos. Cronometra comigo:
- "Lista campanhas com gasto acima de R$ 100 nos últimos 7 dias."
- "Pausa todos os criativos com CPA acima de R$ 80."
- "Duplica esse conjunto e troca pra lookalike de compradores."

21 segundos. No gerenciador isso é 12 minutos. Não é mais clique. É comando.

**3. O Debrief — análise pós-campanha em 5 minutos.**
*[Mostra debrief printado]* Isso aqui é o que tu manda pro cliente na quinta. E tu fez em 5 min. Criativo vencedor, conclusões, próximos passos.

**4. O Relatório — domingo nunca mais.**
*[Mostra exemplo de relatório semanal automático no WhatsApp do cliente]* O domingo volta a ser teu.

**5. O Criativo — 10 peças por demanda.**
*[Mostra grid de 10 criativos pra cliente real]* Briefing às 9h. 10 criativos prontos às 14h. Na identidade do cliente.

**6. O Cérebro — vou abrir num slide só pra ele.**

### ▶ Slide 11 — O Cérebro

O sexto instrumento merece um slide só. Porque ele não é um aplicativo. É a tua operação inteira virando memória.

Tudo que tá na tua cabeça sai dela. E entra num lugar onde não esquece, não some e não depende de tu lembrar.

- **Cliente novo?** Já sabe o histórico do nicho, o que outros clientes parecidos fizeram funcionar.
- **Criativo novo?** Já sabe o que funcionou antes, o que queimou, em qual cliente, com qual público.
- **Decisão difícil?** Já sabe o que tu decidiu da última vez que apareceu uma situação parecida.

A agência aprende sozinha. Tu para de ensinar do zero toda vez. Para de ser o gargalo. E o que tá na tua cabeça hoje vira ativo da agência amanhã.

### 5.3 — Corte no auge

### ▶ Slide 12 — "Eu te mostrei o que fazem"

Isso é a Operação Invisível. 6 instrumentos. Eu te mostrei o que fazem.

Não te mostrei como instalar, porque a ordem certa pra **tua** operação só dá pra ver olhando **tua** agência. Tem agência que precisa do Vigia primeiro porque tá perdendo dinheiro com ad queimando à noite. Tem agência que precisa do Debrief primeiro porque o cliente cobra relatório toda semana. Tem agência que precisa do Cérebro primeiro porque o dono é o gargalo de tudo.

E é isso que a gente vai fazer agora.

---

## BLOCO 6 — CTA (Matheus fecha) | 47:00 – 53:00

### ▶ Slide 13 — E se a gente fizesse isso junto?

Eu prometi não passar de 50 minutos e tô cumprindo. Última coisa antes de soltar vocês.

Se nada do que eu falei fez sentido pra tua realidade, beleza. Sai da sala, valeu o tempo. Sem ressentimento.

Mas se em algum momento desses 50 minutos você pensou *"cara, isso é exatamente o que eu preciso"* — eu quero conversar contigo.

Não é venda. É uma conversa de 30 minutos onde eu olho a operação da tua agência, a gente entende teus clientes, teu time, e mapeia quais dos 6 instrumentos fazem mais sentido pra ti **agora**. Se fizer sentido a gente trabalhar junto, a gente fala de proposta. Se não fizer, tu sai com um plano que pode aplicar sozinho.

E se fizer sentido, em **uma tarde** o primeiro instrumento já tá rodando na tua operação. Não é "vou estudar 3 meses". É instalação ao vivo, contigo do lado, e quando a call acaba, tá rodando.

Faz o seguinte agora: chama **quem te convidou** pra esse evento no WhatsApp. Manda **um dia + dois horários** que tu pode conversar essa semana. A pessoa te coloca direto na minha agenda.

Sem palavra-chave no chat, sem formulário, sem espera. Tu chama, manda dia e horário, e tá marcado.

*[Pausa. Reforça com calma:]* Quem te convidou tá te esperando. Manda agora.

---

## BLOCO 7 — FINALIZAÇÃO | 53:00 – 55:00

### ▶ Slide 14 — Já chegou. É instrumento.

A era da IA pra agência não é "vai chegar". Já chegou. Já tem agência rodando 30 contas com 3 pessoas. Já tem gestor solo rodando 12 contas com 1 chat aberto.

A diferença entre tu estar nesse grupo daqui 6 meses ou continuar onde tá hoje **não é talento. Não é esforço. É instrumento.**

Quem entrou hoje, entrou porque a gente acreditou que tu roda operação séria. Eu não convido em massa. Eu convido pra fazer caber.

Bom resto de quinta. Valeu pelo tempo. Quem chamou no WhatsApp com dia e horário, te vejo na conversa.

---

## Mapa de slides (resumo)

| # | Slide | Bloco | Quando troca |
|---|---|---|---|
| 1 | Capa "Operação Invisível" | Aquecimento | 0:00 — Tino abre |
| 2 | Autoridade (+20 contas, +R$6mi) | Abertura | 7:00 — Matheus entra |
| 3 | "9 em 10" | Abertura | 9:00 |
| 4 | Promessa | Abertura | 10:30 |
| 5 | "Apagar incêndio" | Tensão | 12:00 |
| 6 | Espelho (chat) | Tensão | 14:00 |
| 7 | 3 consequências (D híbrida) | Tensão | 16:30 |
| 8 | Operação Invisível (big idea) | Liberação | 19:00 |
| 9 | 4 crenças | Quebra | 22:00 |
| 10 | Os 6 instrumentos | Conteúdo | 27:00 |
| 11 | O Cérebro | Conteúdo | 42:00 |
| 12 | Corte no auge | Transição | 46:00 |
| 13 | "E se a gente fizesse isso junto?" | CTA | 47:00 |
| 14 | "Já chegou. É instrumento." | Encerramento | 53:00 |

**Total: 14 slides** — você fala o roteiro completo enquanto cada slide fica na tela como âncora visual.

---

## Notas de produção

### Antes de quinta
- [ ] 2-3 prints reais do Watch (alertas anonimizados) pro Slide 10 (instrumento 1)
- [ ] Conta de teste pra demo ao vivo Slide 10 (instrumento 2) + fallback gravado
- [ ] Debrief printado anonimizado (instrumento 3)
- [ ] Print de relatório semanal no WhatsApp (instrumento 4)
- [ ] Grid de 10 criativos (instrumento 5)
- [ ] Lista outbound (30-40 nomes pra puxar 20-25 confirmados)

### Princípios Nimoto aplicados
- [x] Outbound (a gente escolhe quem entra)
- [x] Abertura sub-5 min
- [x] Big idea com nome próprio (Operação Invisível)
- [x] Identificação com frases reais do avatar
- [x] Quebra de 4 crenças
- [x] Storytelling em todos os blocos
- [x] Resolve parte, não tudo (mostra os 6 sem ensinar a instalar)
- [x] Corte no auge no fim do bloco 5
- [x] CTA = conversa individual (não venda no webinar)
- [x] Promessa cumprida antes do CTA

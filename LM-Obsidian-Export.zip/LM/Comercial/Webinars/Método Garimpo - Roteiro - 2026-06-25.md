# Roteiro Estrutural: Método Garimpo

**Webinar:** quinta-feira, 25/06/2026, 19h (sugestão no padrão Nimoto: quinta 19h, fim de mês. Confirmar data)
**Big idea:** Método Garimpo (tem ouro na tua cidade, e o teu time tá sentado em cima da pá. Extrair 100% do time comercial = time que gera a própria demanda todo dia, em vez de esperar cliente cair do céu)
**Posicionamento:** capítulo 3 da série. Solar de Elite mostrou A ESTRATÉGIA (nicho, evento, autoridade). 11/06 mostrou A MÁQUINA (IA, listas, CRM). Este mostra QUEM EXECUTA: o time que tu já paga, prospectando todo dia. Essa ponte vai na copy do convite
**Público:** donos de integradoras solares com 2+ vendedores (critério de cerco validado na mentoria; quem vende sozinho entra, mas cai na rota da escada de ofertas, não no Diagnóstico do Time)
**Duração-alvo:** 45 minutos
**CTA:** Diagnóstico do Time Prospector (45 min, individual, feito pessoalmente por Matheus e Valentino). Ação única: chamar quem convidou no WhatsApp com 2 opções de horário
**Identidade visual:** L.M Consultoria
**Deck:** 16 slides + 1 reserva (gerar HTML depois de aprovado o roteiro)
**Regra de anonimização:** os scripts e ganchos por nicho vêm de material real de cliente. NUNCA citar o nome da empresa nem a cidade do cliente. Nos slides e falas, sempre "[NOME DA TUA EMPRESA]" e "[TUA CIDADE]", o que inclusive transforma o script em template pro público copiar

> Cada bloco mostra o slide ativo. Os slides são curtos por design: tu fala o roteiro completo enquanto eles ficam na tela. Estrutura emocional do Nimoto (variante da Imersão): choque nos primeiros segundos → promessa antes do minuto 5 → surpresa → 5 min de dor proposital → alívio + esperança → confiança a 10 min do fim → chamado com pitch de até 5 min vendendo a REUNIÃO, não o produto.

---

## BLOCO 1 | AQUECIMENTO (Valentino) | 0:00 - 1:30
**Função:** housekeeping mínimo. O evento de verdade começa no choque do Matheus | **Slide:** 1 (Capa)

> Pré-show (18h55, enquanto o público entra): Valentino roda no chat as duas perguntas de aquecimento e vai lendo nomes. "Enquanto dá 19h, me responde duas coisas: quantas pessoas vendem na tua empresa hoje, contando tu? Digita o número. E o teu último cliente fechado veio de onde: Indicação, Anúncio ou Prospecção? Digita I, A ou P." Ele ANOTA nomes + respostas: o placar de I/A/P volta no Bloco 3 e os números de vendedores voltam nos Blocos 6 e 7.

### ▶ Slide 1: Capa MÉTODO GARIMPO

Boa noite! Valentino aqui, um dos CEOs da L.M. Rapidinho, três combinados antes do Matheus entrar.

Um: isso aqui é ao vivo. Dúvida, opinião, discordância: chat. A gente responde tudo.

Dois: quem puder, liga a câmera. Muda a energia do evento.

Três: ninguém vai vender nada pra ti hoje. E continua respondendo ali no chat: quantas pessoas vendem na tua empresa, e o último cliente veio de Indicação, Anúncio ou Prospecção? I, A ou P.

Matheus, contigo.

---

## BLOCO 2 | ABERTURA COM AUTORIDADE (Matheus) | 1:30 - 6:30
**Emoção:** ATENÇÃO (só atenção, nada mais). Choque nos primeiros segundos, promessa completa antes do minuto 5 | **Slides:** 2-4

### ▶ Slide 2: Choque mental

*[Entra direto. Sem "deixa eu me apresentar". A primeira frase é o choque:]*

**Tu paga o teu vendedor por 8 horas de trabalho. Ele passa 2 falando com cliente. E a culpa não é dele.**

Pode discordar no chat. Guarda essa frase, porque até o fim desse evento tu vai entender as outras 6 horas, e o que elas valem em dinheiro.

Quem acompanha nossos eventos sabe a sequência: eu já te mostrei a estratégia de virar autoridade no nicho, e no último evento te mostrei a máquina, a IA montando lista e analisando CRM. Hoje é o capítulo que falta, e é o mais importante: QUEM EXECUTA. O time que tu já paga, gerando a própria demanda todo santo dia, em vez de ficar olhando pro WhatsApp esperando cliente cair do céu.

Eu sou o Matheus. Eu passo a semana inteira dentro de operação comercial de integradora, e o que mais me dói de ver é isso: vendedor bom, parado, esperando lead. Se na tua empresa o telefone só toca quando a indicação vem ou quando o anúncio tá rodando, esse evento foi montado pra ti.

E pra deixar claro: eu não vou vender nada aqui hoje. Fica tranquilo e presta atenção no conteúdo, porque hoje eu vou entregar coisa que normalmente só cliente nosso vê.

### ▶ Slide 3: O que eu NÃO vim falar

O que eu NÃO vou fazer hoje:

Não vim falar de tráfego pago, nem de Instagram, nem de ferramenta de IA. Disso eu já falei nos outros eventos.

Não vim te dar palestra motivacional pro teu time. Motivação sem método dura uma semana.

E não vim te mandar contratar SDR, montar call center, nada disso. O que eu vou te mostrar roda com o time que tu JÁ tem, nas horas que ele JÁ tem.

### ▶ Slide 4: A promessa (3 coisas)

Hoje o evento é sobre uma coisa só: **extrair 100% do time que tu já paga.** E eu vou ser específico no que tu leva daqui:

**Um: o Alvo.** O mapa de 6 nichos comerciais da tua cidade com a dor de energia exata de cada um. Não é teoria: é o gancho pronto, nicho por nicho.

**Dois: o Script.** A anatomia da ligação que transforma vendedor parado em gerador de agenda. Palavra por palavra, incluindo como passar da secretária sem ser barrado.

**Três: o Ritmo.** Como fazer teu time rodar isso todo dia sem desanimar na segunda semana. Porque script sem ritmo é papel na gaveta.

Se até o minuto 45 eu não tiver cumprido as três, sai do evento e nem precisa me dar tchau.

E o desafio de sempre: pega UMA coisa daqui, testa essa semana, e me conta o que mudou. Manda um SIM no chat quem topa. *[Lê 3-4 nomes.]*

---

## BLOCO 3 | PRIMEIRA REVELAÇÃO | 6:30 - 12:00
**Emoção:** SURPRESA | **Slides:** 5-6

### ▶ Slide 5: O lead mais barato do Brasil

Antes do evento eu pedi pro Tino perguntar de onde veio o último cliente de cada um: Indicação, Anúncio ou Prospecção. Olha o placar do chat. *[Valentino fala o placar em voz alta. Esperado: quase tudo I e A.]*

Quase tudo indicação e anúncio. Quase nenhum P. Agora a revelação da noite:

**O lead mais barato do Brasil custa 3 minutos. E ele não disputa leilão.**

Deixa eu explicar. O lead de anúncio te custa 50, 80 reais, e quando ele chega no teu WhatsApp, ele já pediu orçamento pra mais 5 empresas. Tu entra num leilão de preço que esmaga a tua margem. A indicação é ótima, mas tu não controla: mês que vem ela some.

Agora pensa no dono do açougue da tua cidade. Ele tem uma câmara fria ligada 24 horas por dia, sangrando a conta de energia dele TODO mês, faça chuva ou faça sol, tenha movimento ou não. Ele nunca pediu orçamento de energia solar. Ninguém liga pra ele. E o teu vendedor, entre um atendimento e outro, tá com o telefone na mão... rolando o Instagram.

Uma ligação de 3 minutos separa esses dois. Sem leilão, sem concorrente na disputa, sem custo de anúncio. Tu chega ANTES do orçamento existir. Quem chega antes do orçamento não disputa preço: define a conversa.

**Tu não tem falta de lead. Tu tem um time sentado em cima de uma mina de ouro, sem pá na mão.**

### ▶ Slide 6: A conta das horas mortas

E a pá já tá paga. Faz a conta comigo, digita no chat:

- Quantas horas por dia o teu vendedor passa efetivamente FALANDO com cliente? Chuta a real, não a bonita.

*[Lê 3-4 pelo nome. Esperado: "umas 2", "3 no máximo". Plano B se o chat travar: "quando a gente mede em operação, dá entre 2 e 3 horas. O resto é espera, proposta, CRM e celular".]*

Então tu paga 8 e usa 2 ou 3. As outras horas não são culpa do vendedor: ninguém deu pra ele um alvo, um script e um ritmo. Ele não sabe pra quem ligar, não sabe o que falar, e ninguém cobra a atividade. Aí ele espera. E espera custa caro: é salário rodando sem gerar agenda.

Guarda esse número de horas que tu digitou. Ele volta no final numa conta que vai te assustar.

Até aqui faz sentido? Manda um SIM. *[Lê nomes.]*

---

## BLOCO 4 | CENÁRIOS DE CONSEQUÊNCIA | 12:00 - 17:00
**Emoção:** DOR / desconforto produtivo (5 minutos propositais, não aliviar antes da hora) | **Slide:** 7

### ▶ Slide 7: O custo de esperar

Agora pensa comigo em 4 cenários. Vou ser duro, porque eu já vivi cada um.

**Cenário 1: o mês roleta.** Indicação veio, mês bom. Não veio, mês de desespero. Anúncio performou, respira. CPL dobrou, sufoco. Isso não é empresa, é cassino. E a folha de pagamento não aceita ficha: ela vence todo dia 5, no mês bom e no mês ruim.

**Cenário 2: a hora morta no espelho.** Pega o salário do teu vendedor e divide por hora. Agora multiplica pelas 5 horas por dia que ele passa esperando. Multiplica por 22 dias úteis. Por todos os vendedores. Esse é o valor que tu paga POR MÊS pra alguém esperar o telefone tocar. Quem nunca fez essa conta digita NUNCA FIZ. *[Pausa. Lê.]*

**Cenário 3: o leilão eterno.** Continuando só no lead de anúncio: cada lead chega com 5 orçamentos na mão. Pra ganhar, tu baixa preço. Baixando preço, tua margem encolhe. Margem encolhendo, tu corta estrutura. E o material que tu compra nunca baixa. Esse caminho tem um destino só, e tu sabe qual é.

**Cenário 4: a cidade tem dono.** Enquanto teu time espera, em algum lugar tem uma integradora cujo time liga todo dia. Açougue, padaria, mecânica, academia. Cada comércio que ela fecha vira referência e fecha a porta pra ti por anos, porque comércio atendido indica pro vizinho. Daqui 12 meses, os melhores pontos comerciais da tua cidade já vão ter "uma empresa de confiança". Ou é a tua, ou é a dela.

*[Segura o silêncio 2 segundos. Não alivia ainda.]*

E o mais cruel: pra mudar isso tu não precisa contratar ninguém. Precisava só de alvo, script e ritmo nas mãos de quem tu já paga.

---

## BLOCO 5 | LIBERAÇÃO NA PRÁTICA: O MÉTODO GARIMPO | 17:00 - 31:00
**Emoção:** ALÍVIO + ESPERANÇA ("nada gera mais urgência do que esperança"). Aqui mora o OURO do evento | **Slides:** 8-12

### ▶ Slide 8: Respira: tem caminho

Agora deixa eu te mostrar como sai disso. A gente chama de **Método Garimpo**, e o nome é literal: tem ouro na tua cidade, enterrado na conta de energia dos comércios, e a pá já tá na mão do teu time. São 3 movimentos: **o Alvo, o Script e o Ritmo.**

### ▶ Slide 9: Antes dos movimentos, as 4 mentiras

Quatro crenças que seguram teu time parado. Eu carreguei todas:

| O que todo mundo acredita | A verdade |
|---|---|
| "Prospecção ativa queima a marca, parece telemarketing" | Ligação de diretor oferecendo análise gratuita é autoridade, não spam |
| "Meu vendedor não tem perfil pra ligar" | Ligar não é dom, é habilidade. Com script e treino, qualquer vendedor aprende |
| "Se o cliente precisar, ele procura" | Quem espera entra no leilão dos 5 orçamentos. Quem liga antes define a conversa |
| "Prospecção é coisa de SDR contratado" | É função do time que tu JÁ paga, nas horas mortas que ele JÁ tem |

### ▶ Slide 10: Movimento 1, O ALVO

Primeiro movimento: **o Alvo.** Teu vendedor não liga porque não sabe pra quem nem com qual motivo. Resolve os dois de uma vez: um nicho por vez, com a dor de energia específica daquele nicho na ponta da língua.

E aqui vai o primeiro ouro da noite. O mapa que a gente usa em operação real, 6 nichos, printa essa tela:

**Açougue:** câmara fria ligada 24 horas, independente do movimento. Só de refrigeração, 1.500 a 4.000 reais por mês. É custo que não dorme.
**Padaria:** forno, câmara e iluminação ligados desde as 4 da manhã. Quanto mais a padaria cresce, mais a conta cresce junto.
**Mecânica:** compressor ligado a jornada inteira. Gasto invisível no dia a dia, pesado na conta todo mês.
**Academia:** pico de consumo das 17 às 21h, ar-condicionado e esteira a pleno vapor. E o detalhe que vende: o pico começa exatamente quando a geração solar ainda tá alta.
**Sorveteria:** o freezer não pode desligar NUNCA. Queda de energia no verão é estoque inteiro no lixo. Aqui tu não vende só economia, vende proteção.
**Supermercado:** margem de 2 a 5%, e energia entre os 3 maiores custos fixos. O concorrente dele que tem solar opera com vantagem real de custo.

Percebe o que esse mapa faz? O teu vendedor não liga mais "vendendo painel". Ele liga falando da câmara fria do açougueiro, do forno do padeiro às 4 da manhã. Na quinta ligação pro mesmo nicho, ele conhece o negócio do cara melhor que muito contador. E quem entende do negócio do cliente não compete com o pica-fio.

Quem aqui já sabe qual nicho atacaria primeiro na tua cidade? Digita o nicho no chat. *[Lê 3-4 e comenta: "açougue é ótimo começo, custo brutal e dono acessível".]*

### ▶ Slide 11: Movimento 2, O SCRIPT

Segundo movimento: **o Script.** E aqui vem o ouro maior da noite, porque eu vou te dar a anatomia da ligação, palavra por palavra. Isso aqui vem de operação real nossa, rodando agora.

Primeiro as regras de ouro, anota:

**Regra 1: sem diminutivo.** "Minutinho", "reuniãozinha", "rapidinho" matam a tua autoridade na hora. Diretor não pede minutinho.
**Regra 2: sem pergunta de sim ou não.** Pergunta fechada é convite pro "não". Quem pergunta aberto, conduz.
**Regra 3: a palavra é "conversa", nunca "reunião".** Reunião cheira a venda. Conversa cheira a conversa.
**Regra 4: pra chegar no dono, tu é diretor.** Secretária barra vendedor. Secretária NÃO barra diretor que tem um convite pro dono.
**Regra 5: o objetivo da ligação é a CONVERSA, não a venda.** Quem tenta vender painel por telefone perde os dois.

Agora a anatomia, em 4 passos, usando o açougue como exemplo:

**Passo 1, a secretária:** "Boa tarde. Aqui é o [teu nome], diretor da [NOME DA TUA EMPRESA]. Preciso falar com o responsável pelo estabelecimento." Direto, sem explicar demais. Diretor não se justifica pra secretária.

**Passo 2, a abertura com o dono:** "Boa tarde, [nome do dono]. Aqui é o [teu nome], diretor da [NOME DA TUA EMPRESA], aqui de [TUA CIDADE]. Tô entrando em contato porque tenho um convite pro responsável do estabelecimento." Convite. Não é venda, é convite. Lembra do que eu ensinei sobre evento? Mesma lógica na ligação.

**Passo 3, o gancho com a dor do nicho:** "A gente tá realizando uma análise energética gratuita na região, e atualmente trabalhamos com açougues aqui da cidade. Câmara fria em açougue é um dos maiores custos fixos da operação: fica ligada 24 horas, independente do movimento." E emenda a pergunta ABERTA: "Como vocês estão administrando esse custo hoje? Já chegaram a levantar o que a câmara representa na conta?"

**Passo 4, o fechamento de agenda:** ele respondeu, tu escutou de verdade, e aí: "Faz sentido. Essa análise mostra exatamente onde tá o maior peso na conta e qual seria a redução real pro perfil do teu negócio. Como tá a tua agenda pra essa semana ou pra próxima? Nosso analista vai até você, não toma mais que 30 minutos." Olha a pergunta de agenda: aberta, essa semana OU próxima. Não é "pode ser terça?". É "como tá a tua agenda?".

E a regra que amarra tudo: o script é um caminho, não uma rodovia engessada. Ele existe pra eliminar o branco mental dos primeiros segundos. Quanto mais o teu vendedor ouve o dono, mais o script se adapta. Decora o CONCEITO, não a frase.

Tudo certo até aqui? Quem quer ver isso funcionando ao vivo daqui a pouco digita QUERO VER. *[Lê nomes. Loop aberto pra demo do Bloco 6.]*

### ▶ Slide 12: Movimento 3, O RITMO

Terceiro movimento: **o Ritmo.** E presta atenção, porque é aqui que 9 em cada 10 empresas falham. Script sem ritmo é papel na gaveta.

**Primeiro: o bloco sagrado.** Uma hora e meia por dia, todo dia, no mesmo horário, o time inteiro só prospecta. Exemplo: 9h às 10h30. Nesse bloco não tem proposta, não tem CRM, não tem "só vou responder um cliente". Telefone na mão. O que tira vendedor da prospecção nunca é falta de tempo, é falta de bloco protegido.

**Segundo: mede atividade, não só resultado.** Venda de solar comercial demora meses pra fechar. Se tu cobrar só fechamento, teu time desanima na segunda semana. Então o espelho diário mede o que não mente: ligações feitas, conversas com dono, análises agendadas. Por vendedor, na tela, todo dia, num ritual de 15 minutos de manhã. Agenda marcada é a métrica rainha: ela vira venda lá na frente.

**Terceiro: um parafuso por vez.** Não treina a ligação inteira de uma vez. Semana 1: só passar da secretária. Semana 2: o gancho do nicho. Semana 3: o fechamento de agenda. Roleplay de 20 minutos por semana, um de frente pro outro. E a regra da paciência, que eu trago da mentoria que a gente faz: em uma semana tu não vê resultado, em duas tu ainda não vê. Em três meses de ritmo é impossível não ver. Quem muda de método a cada 15 dias nunca colhe nada.

**Quarto: o incentivo certo.** Se a comissão só paga fechamento, ninguém planta. Então premia também a atividade que gera o futuro: análise agendada vale reconhecimento e bônus. E o teu gerente entra aqui: comissão dele atrelada ao número do TIME, não à venda própria dele, senão ele compete com os vendedores em vez de puxar o ritmo. Gerente que vive do número do time roda o bloco sagrado com gosto.

*[Pausa. Reforça com calma:]*

Sendo honesto contigo: dá pra montar tudo isso sozinho? Dá. Escolher o nicho, escrever o script da tua cidade, proteger o bloco, montar o espelho de atividade, treinar parafuso por parafuso. Foi o caminho que a gente construiu na nossa operação e na de cliente, errando muito. O que eu não consigo fazer daqui é calibrar isso pro TEU time e pra TUA cidade: qual nicho primeiro, qual gancho local, qual vendedor começa. Guarda isso, que já já eu te falo como a gente faz junto.

---

## BLOCO 6 | SEGUNDA REVELAÇÃO: PROVA + DEMONSTRAÇÃO | 31:00 - 38:00
**Emoção:** CONFIANÇA (10 minutos antes do fim) | **Slides:** 13-14

### ▶ Slide 13: A prova é que tu tá aqui

Agora a segunda revelação da noite, e essa é a minha preferida.

Deixa eu te contar como TU chegou nesse evento. Tu não viu anúncio. Tu não clicou em link patrocinado. Ninguém aqui veio de tráfego pago, porque a gente não investiu um real em mídia pra esse evento.

Cada pessoa nessa sala recebeu uma ligação ou uma mensagem NOSSA. A gente escolheu as integradoras a dedo, ligou, fez o convite, confirmou na agenda, lembrou no dia. Exatamente o processo que eu acabei de te ensinar: alvo, script, ritmo.

**Tu não tá assistindo a teoria da prospecção ativa. Tu É o resultado dela.** Tá todo mundo aqui numa quinta à noite por causa de uma ligação bem feita. Funciona pra encher evento, funciona pra agendar análise energética, funciona pra marcar visita. É o mesmo músculo.

### ▶ Slide 14: A ligação ao vivo **[DEMO: ROLEPLAY]**

E pra fechar, o que vocês pediram no chat: a ligação acontecendo na frente de vocês.

Tino, vira dono de açougue pra mim. Faz cara de quem tá ocupado cortando picanha.

*[ROLEPLAY ensaiado, 90-120 segundos, com leveza e humor: Matheus liga, passa pela "atendente" (Tino faz as duas vozes ou só o dono), roda os 4 passos do script do açougue na íntegra, com uma objeção real no meio ("ah, energia solar é caro") contornada com pergunta aberta, e fecha agenda: "quinta às 15h então, nosso analista passa aí". Termina com os dois rindo.]*

Viu o tamanho disso? Três minutos. Sem leilão, sem custo de lead, e o dono do açougue saiu da ligação se sentindo convidado, não abordado. Agora imagina o teu time fazendo 10 dessas por dia, cada um.

Aliás, faz essa conta comigo, a conta da esperança. Tu digitou lá no começo quantos vendedores tu tem. Se cada um marcar UMA análise por dia, uma só, em 20 dias úteis: quantas visitas qualificadas teu time gera num mês? Digita o número: vendedores vezes 20. *[Lê 2-3: "Fulano com 3 vendedores: 60 visitas qualificadas por mês. SESSENTA. Quanto custou de anúncio? Zero."]*

Esse é o garimpo. Tava aí o tempo todo.

---

## BLOCO 7 | CHAMADO | 38:00 - 43:00
**Emoção:** decisão (próximo passo lógico, ação única, sem pitch mirabolante) | **Slide:** 15

### ▶ Slide 15: Vamos garimpar junto?

Turma, prometi 3 coisas: o Alvo, tu levou o mapa dos 6 nichos. O Script, tu levou a anatomia completa com as regras de ouro. O Ritmo, tu levou o bloco sagrado, o espelho de atividade e o incentivo. Promessa cumprida, dentro do tempo. Agora o próximo passo lógico.

Cada cidade é uma cidade, cada time é um time. O nicho certo pra começar em Sinop não é o mesmo de Uberaba. O vendedor que abre o jogo na tua empresa não é o mesmo da do vizinho.

Então a gente vai fazer o **Diagnóstico do Time Prospector.** 45 minutos, eu e o Valentino, pessoalmente, contigo. A gente mapeia teu time, escolhe o primeiro nicho da TUA cidade, e te entrega o plano pra rodar na semana seguinte: quem liga, pra quem liga, com qual gancho, e como tu mede. Se no meio do papo fizer sentido a gente trabalhar junto na implementação, eu te mostro como. Se não fizer, tu sai com o plano do mesmo jeito.

Quem já fez diagnóstico com a gente nos eventos anteriores: esse é outro escopo, é o capítulo da execução. Me chama direto que tu tem prioridade na agenda.

E transparência total, sem gatilho falso de "últimas vagas": como somos nós dois que fazemos, pessoalmente, a agenda comporta [NÚMERO REAL, travar antes do evento] diagnósticos por semana. Quem marcar agora entra nessa semana e na próxima. *[Se não houver limite real verificável, cortar a frase inteira da escassez e fechar só com "quem marcar agora entra nessa semana".]*

É pra ti se tu se enxergou em alguma dessas três portas:

**Porta 1:** "Meu time só atende quem chega. Ninguém prospecta nada."
**Porta 2:** "Minha empresa vive de indicação e anúncio. Mês bom, mês ruim, roleta."
**Porta 3:** "Eu já tentei prospecção ativa e o time desanimou na primeira semana."

*[Leitura nominal com os dados do chat pré-show: "Fulano, tu falou que tem 3 vendedores e o último cliente veio de indicação: a Porta 2 é literalmente a tua. Ciclano, que digitou A: faz a conta do que tu paga de lead hoje."]*

Como marcar, ação única: chama AGORA no WhatsApp a pessoa que te convidou e manda duas opções de horário. "Quero o diagnóstico, posso quinta às 14h ou sexta às 10h." Ela encaixa na agenda.

---

## BLOCO 8 | FINALIZAÇÃO | 43:00 - 45:00
**Slide:** 16

### ▶ Slide 16: Encerramento

Último recado, e é o desafio do início.

Amanhã, pega UM vendedor, UM nicho do mapa, e 10 ligações com o script que eu te mostrei. Só isso. Dez ligações. E me manda no WhatsApp o que aconteceu: meu número pessoal tá aqui na tela, me manda áudio que EU te respondo. Eu garanto que em 10 ligações tu já agenda conversa. E aí tu vai entender que o problema nunca foi falta de cliente.

Fica com a frase da noite:

**Cliente não cai do céu. Tem ouro na tua cidade, e a pá já tá na mão do teu time.**

Ficar até o final de um evento numa quinta à noite é exatamente o tipo de consistência que o Ritmo exige. Tu acabou de dar o exemplo pro teu time. Boa noite, e bora garimpar.

---

## Mapa de slides (resumo)

| # | Slide | Bloco | Quando troca |
|---|---|---|---|
| 1 | Capa: Método Garimpo | 1 | 0:00 |
| 2 | Choque mental ("paga 8, usa 2") | 2 | 1:30 |
| 3 | O que eu NÃO vim falar | 2 | 3:30 |
| 4 | A promessa (Alvo, Script, Ritmo) | 2 | 4:30 |
| 5 | O lead mais barato do Brasil (placar I/A/P) | 3 | 6:30 |
| 6 | A conta das horas mortas (chat) | 3 | 9:30 |
| 7 | O custo de esperar (4 cenários) | 4 | 12:00 |
| 8 | Respira: tem caminho (Garimpo, 3 movimentos) | 5 | 17:00 |
| 9 | As 4 mentiras (tabela de crenças) | 5 | 18:30 |
| 10 | Movimento 1: O Alvo (mapa dos 6 nichos) | 5 | 20:00 |
| 11 | Movimento 2: O Script (regras de ouro + 4 passos) | 5 | 23:30 |
| 12 | Movimento 3: O Ritmo (bloco sagrado, espelho, parafuso, incentivo) | 5 | 28:00 |
| 13 | A prova é que tu tá aqui | 6 | 31:00 |
| 14 | DEMO: a ligação ao vivo (roleplay) | 6 | 33:30 |
| 15 | CTA: Diagnóstico do Time Prospector (3 portas) | 7 | 38:00 |
| 16 | Encerramento + frase da noite | 8 | 43:00 |

**Total: 16 slides + 1 reserva (script do açougue por escrito, caso o roleplay falhe)**

---

## Notas de produção

**Conteúdo e fatos (fazer antes de gerar o deck):**
- [ ] Confirmar data e horário (sugestão: quinta 25/06, 19h, fim de mês no padrão Nimoto)
- [ ] ANONIMIZAÇÃO: conferir slide por slide que o nome da empresa e a cidade do cliente dono dos scripts NÃO aparecem em lugar nenhum (sempre "[NOME DA TUA EMPRESA]" e "[TUA CIDADE]")
- [ ] Confirmar que a faixa de custo da câmara fria (R$1.500-4.000/mês) pode ser citada publicamente; se houver dúvida, falar "milhares de reais por mês"
- [ ] Validar a afirmação "não investimos um real em mídia pra esse evento" (precisa ser 100% verdade no dia; se rodar qualquer anúncio, cortar a frase e manter só "cada um aqui recebeu uma ligação nossa")
- [ ] Ensaiar o ROLEPLAY com o Valentino (2 passadas no mínimo): os 4 passos do script do açougue + 1 objeção ("é caro") contornada com pergunta aberta + fechamento de agenda. Definir se ele faz só o dono ou também a atendente
- [ ] Mapeamento manual obrigatório (regra Nimoto: conteúdo intelectual não se terceiriza pra IA): Matheus escreve à mão as 5 crenças centrais do dono de integradora sobre prospecção e o banco de 30-50 tópicos (objeções de ligação, nichos extras, horários de ligação, scripts de WhatsApp), rankeados. O top 5 já tá no roteiro; o resto fica à mão pro chat e pros diagnósticos
- [ ] Travar o NÚMERO REAL de diagnósticos por semana na agenda dos dois. Se não houver limite real, cortar a frase da escassez (instrução inline no Bloco 7)
- [ ] Slide reserva: script do açougue por escrito (4 passos), caso o roleplay trave ou o som falhe
- [ ] Copy do convite outbound com a ponte de capítulo 3: "já te mostramos a estratégia e a máquina; nesse evento, quem executa: o teu time gerando demanda todo dia"

**Convite e comparecimento (diagnóstico do Nimoto na Call 1: o gargalo é comparecimento, não conversão):**
- [ ] Filtro do outbound: priorizar integradoras com 2+ vendedores. Quem vende sozinho pode vir, mas no pós-evento cai na rota da escada de ofertas (Ignição), não no Diagnóstico do Time
- [ ] Aquecimento D-7: a semana anterior com conteúdos, cases e prova social no WhatsApp dos convidados
- [ ] Aceite no Google Calendar no MESMO dia do convite, com confirmação verbal: "posso deixar travado na agenda?"
- [ ] Ligação 48h antes + WhatsApp na manhã do evento + ligação pra quem não entrou em 10 min
- [ ] Gatilho pra quem some: "seu convite foi cancelado por falta de aceite na agenda"
- [ ] Valentino anota nomes + nº de vendedores + placar I/A/P do chat pré-show (voltam nos Blocos 3, 6 e 7 e no follow-up)

**Pós-evento (não deixar esfriar):**
- [ ] Follow-up na mesma noite e na manhã seguinte, saindo com agenda marcada
- [ ] Quem confirmou e faltou: ligação no dia seguinte + gravação + resumo, oferecendo o Diagnóstico direto
- [ ] Precall de qualificação 1 dia antes de cada Diagnóstico (2+ vendedores, faturamento, decisor identificado, sócio convidado se existir)
- [ ] Quem participou e não marcou: volta pra base aquecida e é convidado pro próximo evento
- [ ] Roleplay do evento inteiro 1 vez antes (melhore uma coisa por vez: foco desta edição = o roleplay da ligação sair natural)

### Princípios Nimoto aplicados

- [x] Outbound seletivo com filtro de qualificação (2+ vendedores)
- [x] Choque mental nos primeiros segundos da fala do palestrante (housekeeping reduzido a 90s)
- [x] Promessa completa antes do minuto 5 + identificação na abertura ("se o telefone só toca quando a indicação vem, esse evento é pra ti")
- [x] Desarme em primeira pessoa ("eu não vou vender nada aqui hoje")
- [x] Big idea com nome próprio (Método Garimpo: Alvo, Script, Ritmo) e sequência declarada (capítulo 3: estratégia → máquina → quem executa)
- [x] Pergunta-mestra: ensina a resolver SEM o serviço (mapa de nichos aberto, script palavra por palavra, ritmo explicado); o esforço de calibrar sozinho cria o valor do atalho
- [x] Curva emocional da Imersão: atenção → surpresa → 5 min de dor proposital → alívio + esperança → confiança a 10 min do fim → chamado
- [x] Quebra de 4 crenças mapeadas do público (sobre prospecção ativa)
- [x] Storytelling e cena concreta em todos os blocos (açougueiro e a câmara fria, o vendedor no Instagram, a cidade que ganha dono, o roleplay)
- [x] Entrega de OURO real (mapa de nichos + script + regras de ouro de material de operação real, anonimizado)
- [x] Prova social viva e meta-prova ("tu tá aqui por causa de uma ligação nossa")
- [x] Demonstração prática a 10 min do fim (roleplay ao vivo), com plano B (slide reserva com o script escrito)
- [x] Esperança quantificada PELO participante (vendedores x 20 análises/mês, no chat)
- [x] Checkpoints nominais de chat em todos os blocos
- [x] Resolve parte, não tudo (método aberto; calibração de nicho/cidade/time fica pra reunião)
- [x] Promessa cumprida ANTES do CTA (recap explícito)
- [x] CTA = reunião individual, ação única, pitch de menos de 5 min, diferenciado dos CTAs anteriores
- [x] CTA segmentado por dor (3 portas com leitura nominal) + escassez só se for real (instrução inline)
- [x] Banco de tópicos reserva pro chat e pras reuniões (nota de produção)

# Roteiro Estrutural: A Máquina de Indicação da Copa

**Webinar:** quinta-feira, 19h (confirmar data dentro da janela da Copa, fim de mês). Padrão Nimoto
**Big idea:** A Máquina de Indicação da Copa (a Copa infla a conta de luz da cidade inteira por 39 dias. Quem tem roteiro vira esse barulho em indicação e venda. Quem não tem, assiste o dinheiro passar)
**Público:** donos de integradoras solares, SEM caixa (outbound selecionado)
**Duração-alvo:** 50 a 55 minutos
**CTA:** leve (não é o foco). Diagnóstico pra montar a Máquina junto, chamando quem convidou no WhatsApp
**Identidade visual:** L.M Consultoria
**Deck:** ~18 slides + handout "Arsenal dos 52 plays"

> ESTRUTURA = arco emocional do Nimoto, na ordem exata da mentoria (módulo de webinar da imersão + nota Webinário de Alto Impacto). NÃO é catálogo, é roteiro: cada bloco tem UMA emoção alvo e o apresentador conduz por fala, com checkpoints de identificação o tempo todo.
>
> Abertura (ATENÇÃO) → Primeira Revelação (SURPRESA) → Identificação + Consequências (DOR, 5 min propositais) → Quebra de Crenças (o coração) → Entrega de Valor com Storytelling (ALÍVIO + ESPERANÇA, resolve PARTE e corta no auge) → Segunda Revelação/Demonstração (CONFIANÇA, 10 min antes do fim) → Chamado (reunião, próximo passo lógico).
>
> PRINCÍPIO (corrigido após feedback): isso é um WORKSHOP DE CONTEÚDO, não um webinar enxuto que segura tudo pra reunião. A pessoa tem que SAIR com coisa concreta na mão. Então o valor começa nos primeiros 4 minutos (com uma ação ao vivo), os scripts principais são ENTREGUES e ANOTADOS na tela ao vivo (não empurrados pro material), e no fim tem um PLANO DE AÇÃO de 3 passos pra rodar amanhã. O material com as 52 variações vai junto, mas o essencial a pessoa já leva escrito no caderno. A emoção do Nimoto conduz, mas o conteúdo é generoso e prático.
>
> Regra: nenhum nome de cliente real. Sempre [TUA EMPRESA], [Nome]. Sem travessão.

---

## BLOCO 1 | AQUECIMENTO (Valentino) | 0:00 - 1:30
**Função:** housekeeping mínimo | **Slide:** 1 (Capa)

> Pré-show (18h55): Valentino joga no chat: "Enquanto dá 19h: o teu último cliente fechado veio de Indicação, Anúncio ou esperando aparecer? Digita I, A ou E. E quantos orçamentos parados (gente que pediu e não fechou) tu tem na gaveta?" Anota nomes e respostas: voltam no Bloco 4.

### ▶ Slide 1: Capa A MÁQUINA DE INDICAÇÃO DA COPA

Boa noite! Valentino aqui, um dos CEOs da L.M. Três combinados rápidos.

Um: é ao vivo, joga tudo no chat que a gente responde. Dois: liga a câmera quem puder. Três: ninguém vai te vender nada hoje, isso aqui é conteúdo de verdade. Pega papel e caneta. Matheus, contigo.

---

## BLOCO 2 | ABERTURA | 1:30 - 6:30
**Emoção alvo: ATENÇÃO (só atenção, nada mais).** Choque nos primeiros segundos, identificação, "não vou vender", promessa | **Slides:** 2-4

### ▶ Slide 2: Choque

*[Entra com a afirmação forte, sem se apresentar antes:]*

**A Copa do Mundo vai movimentar bilhões de reais no Brasil em 39 dias. E quanto disso vai cair na tua integradora? Se tu esperar o cliente aparecer igual sempre, a resposta é uma só: zero.**

Hoje eu vou mudar isso na prática, e vou ser bem concreto. Tu vai sair desse evento com os scripts escritos no teu caderno, palavra por palavra, e um plano de 3 passos pra começar a faturar com a Copa amanhã de manhã. Sem gastar um real. Não é palestra, é pra anotar e fazer.

### ▶ Slide 3: Quem eu sou (rápido) + identificação

Eu sou o Matheus, passo a semana dentro de operação comercial de integradora solar, e não vou te vender nada hoje, isso aqui é conteúdo pra aplicar.

E pra não ficar no blá-blá, faz uma coisa AGORA comigo, leva 30 segundos: abre o teu WhatsApp e conta quantos orçamentos tu mandou nos últimos meses que NÃO fecharam. Aquele cara que pediu, viu o preço e sumiu. Conta e digita o número no chat. *[Espera de verdade. Lê 3-4 números pelo nome.]*

Esse número que tu acabou de digitar é dinheiro parado, e é a PRIMEIRA mina que a gente vai abrir hoje, com script pronto. Segura ele que daqui a pouco a gente volta nele. Teu mês hoje é uma roleta: veio indicação, mês bom; não veio, aperto. A ideia do evento é tirar tua empresa da roleta. Bora.

### ▶ Slide 4: A promessa

Olha o que tu leva daqui hoje, e é tudo concreto, nada de teoria:

Um: os scripts exatos, palavra por palavra, que tu vai ANOTAR aqui comigo, na tela, pra reativar esses orçamentos parados e pra fazer teu cliente te indicar. Dois: o plano de 3 passos pra rodar na Copa inteira. Três: a rotina de 15 minutos por dia que faz isso virar venda semanas depois. Tudo de graça, pra fazer amanhã de manhã.

Caneta na mão, porque hoje tu anota e sai aplicando. Se eu não cumprir, sai e nem me dá tchau. Quem topa anotar, manda BORA no chat. *[Lê 3-4 nomes.]*

---

## BLOCO 3 | PRIMEIRA REVELAÇÃO | 6:30 - 11:00
**Emoção alvo: SURPRESA.** Um conceito simples e potente que bate com a crença | **Slides:** 5-6

### ▶ Slide 5: A Copa não é sobre futebol pro teu negócio

Deixa eu te dar a revelação da noite, e ela vai contra tudo que tu vê os outros fazendo na Copa:

**A Copa não é o maior evento de futebol do ano pra tua integradora. É o maior pico de conta de luz do ano.** 39 dias com a cidade inteira de TV ligada, ar no talo, geladeira cheia, bar lotado. Todo mundo vai pagar a luz mais cara. E essa, meu amigo, é exatamente a dor que tu resolve, servida de bandeja por mais de um mês.

E a segunda parte da revelação, essa quebra a cabeça da maioria: **pra faturar nessa Copa tu não precisa de um real de anúncio. Tu precisa de roteiro.**

✋ *[MICROTAREFA (Nimoto): "Pensa no teu maior cliente AGORA. Quanto a conta de luz dele sobe num mês de Copa? Joga o número no chat." Lê 2-3 pelo nome. Ancora a revelação num número real da cabeça deles.]*

### ▶ Slide 6: A Copa passa, mas a indicação fica

Por que roteiro e não anúncio? Porque o teu negócio não é a venda de hoje. Solar é compra única, o cara instala uma vez. Então o teu ouro não é vender de novo pra ele, é a INDICAÇÃO dele. Cada cliente teu tem uns 5 vizinhos e parentes reclamando da conta de luz, gente que confia nele. Ele só nunca foi provocado a indicar.

A Copa é a desculpa perfeita pra essa provocação. "Lembrei de ti agora na Copa" abre qualquer porta. "E aí, vai fechar?" fecha todas. Mesma intenção, resultado oposto, e a Copa te dá o contexto de graça.

A Copa passa em 39 dias. Mas o cliente que tu pega agora indica por anos. Esse é o jogo. Faz sentido até aqui? Manda SIM. *[Lê.]*

---

## BLOCO 4 | IDENTIFICAÇÃO + CONSEQUÊNCIAS | 11:00 - 16:00
**Emoção alvo: DOR / desconforto produtivo (5 minutos propositais).** Primeiro o espelho, depois amplifica a dor | **Slide:** 7

### ▶ Slide 7: Os 39 dias que vão passar do teu lado

Agora eu vou te deixar desconfortável de propósito por uns minutos, porque tu precisa sentir o tamanho do que tá em jogo.

Olha lá no chat o que vocês responderam pro Tino: a maioria fechou o último cliente por indicação ou anúncio, e quase ninguém por prospecção. E todo mundo tem dezenas de orçamentos parados na gaveta. *[Lê 2-3 números.]* Isso é o retrato de um negócio que vive esperando.

Agora deixa eu te mostrar o que esses 39 dias vão fazer com quem espera:

Vai ter bar lotado na tua cidade todo dia de jogo, com a conta de luz daquele bar batendo recorde. E tu não vai bater na porta de nenhum. Quem aqui já olhou pro bar cheio e nunca pensou nisso? Digita EU. *[Lê.]*

A cidade inteira vai pagar luz mais cara, e essa é literalmente a tua venda. E tu vai ficar calado, esperando o WhatsApp tocar.

Os teus orçamentos parados vão continuar parados. Cada mês que aquele cara não fecha é comissão que não entra na tua conta, e dinheiro que ele manda pra concessionária e não volta nunca.

E o pior: tem UM concorrente teu, com kit pior que o teu, que vai usar a Copa de desculpa pra falar com a base dele toda semana. Daqui dois meses, os clientes que eram teus vão estar com ele. Não porque ele é melhor. Porque ele falou e tu calou.

*[Pausa 2 segundos. Não alivia ainda.]*

---

## BLOCO 5 | QUEBRA DE CRENÇAS | 16:00 - 21:00
**Emoção alvo: remover o obstáculo mental (o coração do webinar).** Ataque cirúrgico nas desculpas que te deixam no banco | **Slide:** 8

### ▶ Slide 8: O que te deixa no banco

A pergunta honesta: se prospecção e indicação são tão boas, por que tu não faz? Porque tem três desculpas que te seguram no banco de reservas enquanto a Copa tá rolando em campo. Eu carreguei todas, então não é julgamento. Bora te tirar do banco.

**Primeira, "prospecção queima minha marca, parece telemarketing".** No banco. Telemarketing é ligar empurrando produto. O que eu vou te ensinar é ligar oferecendo uma análise de graça e um convite. Isso é autoridade, não spam. Quem avisa que a conta do cara vai subir tá ajudando, não incomodando. Isso te bota em campo.

**Segunda, "meu cliente não vai me indicar do nada".** Claro que não vai do nada. Indicação não cai, ela se PEDE, no momento certo e com a desculpa certa. A Copa é a desculpa. Eu vou te dar a fala exata.

**Terceira, "se o cliente precisar de solar, ele me procura".** Essa é a mais cara. Quem espera ser procurado entra no leilão dos 5 orçamentos e apanha no preço. Quem chega ANTES, na conversa, define o jogo. A Copa te coloca antes.

E se ainda passar pela tua cabeça que "isso é coisa de empresa grande, com equipe e dinheiro": esquece. Tudo que eu vou te mostrar custa zero ou só sai do teu bolso depois que a venda já entrou. É no teu WhatsApp, na tua casa, com o cliente que tu já tem.

Saiu do banco, sobra o quê? Sobra fazer. E é isso que eu vou te entregar agora.

---

## BLOCO 6 | ENTREGA DE VALOR COM STORYTELLING | 21:00 - 38:00
**Emoção alvo: ALÍVIO + ESPERANÇA ("nada gera mais urgência do que esperança").** Este é o CORAÇÃO DO CONTEÚDO. Cada jogada vem com o script na tela pra anotar e uma instrução de "faz amanhã". A pessoa sai com o caderno cheio, não com promessa de material | **Slides:** 9-13

### ▶ Slide 9: A Máquina de Indicação da Copa (o sistema inteiro numa tela)

Respira, porque agora vem o alívio. Tem caminho, e ele não custa nada.

A gente chama de Máquina de Indicação da Copa, e o coração dela é UM ENCONTRO: tu junta tua turma de clientes num bar pra ver o jogo do Brasil. É de graça pra ti (já já tu entende como), e desse encontro saem duas coisas que valem ouro: negócio destravado e indicação. Olha o sistema de 5 jogadas:

1. A Bola Parada (chamar o orçamento travado pra ver o jogo e destravar ali)
2. O Camarote (a parceria com o bar que te dá o palco de graça, e o dono vira cliente)
3. O Terceiro Tempo (depois do jogo, a hora de pedir indicação, no olho no olho)
4. A Torcida (tua presença os 39 dias entre um encontro e outro)
5. O Vestiário (a rotina dos bastidores que não deixa nenhum lead vazar)

E presta atenção: cada jogada eu vou te dar AGORA com o script na tela pra tu anotar. Caneta na mão de verdade, porque o que vem é pra copiar.

🎁 *[ANTECIPA A OFERTA (Nimoto): aqui, já com a Máquina na tela, solta a isca do entregável. "Ó, no fim do evento eu vou te fazer uma proposta: eu e o Valentino entrando numa call de 45 min pra montar essa Máquina pra TUA cidade, de graça. Quem quer, digita EU QUERO." Lê os nomes. Segura a galera até o fim e antecipa o pitch.]*

### ▶ Slide 10: A Bola Parada (destravar o orçamento parado no clima do jogo)

Lembra do número de orçamentos parados que tu digitou lá no começo? Aquele cara que pediu, viu o preço e travou. A maioria comete o erro de cobrar ele por WhatsApp seco, "e aí, vai fechar?". Isso só afasta.

A jogada é outra: tu CONVIDA ele pra ver o jogo do Brasil junto. Anota o script:

> *"Fala [Nome]! Vou levar uns clientes meus pra ver o jogo do Brasil quinta, num bar aqui. Vai ser massa, bora? Sem papo de venda, é só ver o jogo e tomar uma. E se tu quiser, aproveito e te mostro como ficou aquele número do solar com os valores de hoje. Mas sem compromisso nenhum."*

Olha o que acontece: ele vai num clima leve, sem pressão de reunião. E lá, no meio da resenha, com um chopp na mão, tu destrava o negócio que tava travado há meses. Orçamento parado raramente fecha por mensagem fria. Fecha numa conversa de boteco vendo o Brasil ganhar. Esse é o jeito de cobrar a bola parada.

### ▶ Slide 11: O Camarote (a parceria com o bar, e o dono vira cliente)

Jogada 2, e aqui é o motor de tudo. "Matheus, mas eu não tenho caixa pra alugar bar." Tu não vai alugar nada. Tu vai fazer uma PARCERIA. Anota a abordagem com o dono do bar:

> *"Fala [dono], tudo bem? Sou da [TUA EMPRESA]. Eu junto um grupo de clientes e empresários pra ver os jogos do Brasil, e queria trazer essa galera aqui pro teu bar. Casa cheia garantida na noite de jogo. Em troca eu só te peço um desconto pro meu grupo e um cantinho reservado. Fechamos?"*

O dono AMA, porque tu enche o bar dele numa noite de jogo. Teu cliente AMA, porque ganha desconto e networking. E tu não paga nada.

Agora o pulo do gato, e isso quase ninguém faz: enquanto tu fecha essa parceria, o dono do bar tá com a conta de luz EXPLODINDO na Copa, TV, ar, geladeira e chopeira ligados o jogo inteiro. Então tu emenda, na mesma conversa:

> *"E já que a gente vai ser parceiro, deixa eu te falar uma coisa rápida: com tudo isso ligado o jogo inteiro, tua conta de luz desse mês vai dar um susto. Eu trabalho com energia solar. Me deixa fazer uma análise grátis da tua última conta, em 5 minutos te mostro quanto tu economizaria por mês."*

Fechou a parceria E abriu um orçamento gordo na mesma conversa. O dono do bar é o teu maior cliente da semana, e tu nem precisou procurar ele.

✋ *[MICROTAREFA (Nimoto): "Anota AGORA o nome de 1 bar perto de ti que enche em dia de jogo. Esse é teu primeiro Camarote." Puxa 2-3 nomes do chat pelo nome.]*

### ▶ Slide 12: O Terceiro Tempo (a hora de ouro pra pedir indicação)

Jogada 3. O Brasil ganhou, a galera tá eufórica, teus clientes todos reunidos no bar, no maior clima. Esse é o terceiro tempo, e é A HORA de pedir indicação. Não por mensagem, é olho no olho, com o cara feliz na tua frente depois de tu ter dado um bom papo e pago um chopp. Anota como pede:

> *"Pô [Nome], que noite boa essa, hein. Ó, deixa eu te pedir uma força rápida: tu que já economiza com o solar, quem tu conhece que ainda paga aquela fortuna de luz e merecia economizar igual tu? Pensa num nome aí: vizinho, parente, sócio. Me apresenta que eu cuido de tudo, do mesmo jeito que cuidei do teu."*

Presencial, no clima, depois do encontro. A taxa de resposta disso é muito maior do que qualquer mensagem fria. Na real, o encontro inteiro existe pra chegar nesse momento. E o incentivo que protege teu caixa: prêmio de indicação só sai DEPOIS que a venda fecha. "Te dou 300 no PIX quando o teu indicado fechar." Tu paga com dinheiro que já entrou.

✋ *[MICROTAREFA (Nimoto): "Escolhe AGORA 1 cliente teu que com certeza tem vizinho reclamando de luz. Anota o nome. É a tua primeira indicação da Copa." Puxa 2-3 nomes do chat pelo nome.]*

### ▶ Slide 13: A Torcida e O Vestiário (presença + a rotina que segura tudo)

**Jogada 4, A Torcida:** entre um encontro e outro, tu mantém presença os 39 dias sem gastar mídia. Salva 3 mensagens nas Notas do celular e posta no status em todo dia de jogo:
> PRÉ-JOGO: "Hoje tem Brasil! Palpite do placar aí." (engaja, sem vender)
> INTERVALO: "Intervalo. Igual jogo, conta de luz também tem segundo tempo, e quem tem solar já tá ganhando o dele."
> PÓS-JOGO: "Quem mais ganhou hoje foi quem não paga luz cara. Quer ver quanto economiza? Me chama."

E o grupo de WhatsApp pra resenhar os jogos com os clientes e os convidados. É de lá que tu chama a galera pros encontros e mantém todo mundo aquecido.

**Jogada 5, O Vestiário:** é a rotina dos bastidores, onde tu organiza o time. Cada negócio que tu destravou na Bola Parada, cada indicação do Terceiro Tempo, cada contato novo do encontro, tu anota num lugar só (o bloco de notas do celular já serve) e dá um toque 15 minutos toda manhã. Porque a Copa acaba em 39 dias, mas o lead de solar fecha SEMANAS depois. Sem o Vestiário, tudo que tu colheu no bar vaza e some.

*[Transição:]* Pronto. Tu acabou de anotar o coração das 5 jogadas, com script e tudo. No material que eu te mando hoje tem 52 variações dessas. Mas o que tá no teu caderno agora já basta pra começar essa semana. Antes do plano de 3 passos, deixa eu te provar, linha por linha, por que esses scripts funcionam.

---

## BLOCO 7 | SEGUNDA REVELAÇÃO / DEMONSTRAÇÃO | 38:00 - 46:00
**Emoção alvo: CONFIANÇA (10 minutos antes do fim).** Demonstração ao vivo: por que o script funciona | **Slide:** 14

### ▶ Slide 14: A anatomia do pedido (por que cada palavra funciona) **[SCRIPT NA TELA]**

Eu não vou encenar um cliente aqui, porque encenação não prova nada. Vou fazer melhor: vou abrir na tela a mensagem que mais traz indicação e te mostrar POR QUE ela funciona, linha por linha. Porque quando tu entende o porquê, tu adapta pra qualquer cliente teu.

*[Mostra "A Pergunta da Conta de Luz" na tela e disseca, frase por frase:]*

> *"Fala [Nome], pronto pro jogo?"* Esse é o gancho da Copa. Abre leve, sem cara de cobrança. Não é "e aí, vai indicar?", é "bora ver o jogo".

> *"Depois do solar, quanto você economiza por mês?"* Olha a sacada: eu faço o CLIENTE dizer o número. Quando ele mesmo fala "economizo 400 por mês" em voz alta, ele se convence sozinho de que vale a pena passar isso pra frente. Quem fala a economia, vende a economia.

> *"Quem na tua rua ainda paga essa fortuna de luz?"* Eu peço nome ESPECÍFICO, "na tua rua", "na tua família", nunca "você conhece alguém?". Genérico vira nada. Específico vira contato.

> *"Me dá um nome que eu cuido."* Pedido pequeno, fechamento leve. Um nome. Não dez. Um.

Quatro linhas, e cada uma tem função. Isso não é sorte, é roteiro. E todas as 52 do material são montadas assim.

*[PROVA REAL, se tiver: mostra 1 ou 2 prints de WhatsApp ANONIMIZADOS de um pedido de indicação que funcionou de verdade, mesmo que de antes da Copa. Print real vale mais que qualquer encenação. Se ainda não tiver, pede no chat: "quem aqui já recebeu uma indicação de um cliente satisfeito, digita SIM". O mar de SIM é a prova.]*

---

## BLOCO 8 | PLANO DE AÇÃO + CHAMADO | 46:00 - 50:00
**Emoção alvo: ação concreta, depois decisão.** Primeiro o plano que a pessoa leva, depois o convite curto | **Slides:** 15-16

### ▶ Slide 15: Seu plano pra amanhã (os 3 passos) **[ANOTA E EXECUTA]**

Antes de eu te liberar, anota o teu plano pra amanhã de manhã. Não é pra fazer as 5 jogadas de uma vez, é pra começar por 3 coisas. Escreve aí:

**Passo 1 (essa semana):** fecha a parceria com UM bar pra teu encontro. Pede o desconto pro teu grupo, e já oferece a análise de energia grátis pro dono. Tu sai com o palco do encontro E um orçamento gordo na mão.

**Passo 2 (no próximo jogo do Brasil):** chama pro encontro teus melhores clientes E os orçamentos parados. No clima do jogo, tu destrava negócio travado e, no fim, pede indicação olho no olho pra galera reunida.

**Passo 3 (toda manhã):** revisa tua lista de contatos do encontro (negócio destravado, indicação, contato novo) e dá os toques, 15 minutos por dia.

Faz esses 3 e tu transforma a Copa em encontro, e o encontro em venda, sem gastar um real. Quem vai marcar pelo menos UM encontro nessa Copa, digita EU VOU no chat. *[Lê os nomes, isso é compromisso.]*

### ▶ Slide 16: O convite (pra quem quiser ir além)

⚡ *[O PITCH. É o momento mais importante do evento (Nimoto): NÃO lê, energia no talo, mais incisivo, e não corta curto. Amarra com a isca que tu soltou no slide 9 ("lembra da proposta que eu prometi?").]*

Tu já sai com tudo pra fazer sozinho, e ainda recebe o material com as 52 mensagens hoje. Mas deixa eu te falar uma coisa olhando no olho: eu QUERO mudar a tua empresa, eu quero fazer isso contigo. Por isso, lembra da proposta que eu prometi lá no começo? É essa: quem quiser ir além, a gente faz um diagnóstico de 45 minutos, eu e o Valentino, e monta a tua Máquina calibrada pra tua cidade e tua base. A gente puxa teus orçamentos parados, escolhe teus primeiros nichos de comércio e monta tua rotina de follow-up junto. Sem custo.

E pensa comigo: e se a gente entrar nesse bate-papo e eu mudar o destino da tua empresa? Quanto que isso vai ter te custado por tu NÃO ter entrado? Quem topa, chama quem te convidou no WhatsApp agora e manda dois horários.

---

## BLOCO 9 | FINALIZAÇÃO | 50:00 - 52:00
**Slide:** 17

### ▶ Slide 17: Encerramento

A tarefa de amanhã, escolhe UMA: ou tu lista teus orçamentos parados e dispara o primeiro script, ou tu manda a Pergunta da Conta de Luz pros teus 5 melhores clientes. Só uma. E me conta no WhatsApp o que aconteceu.

A frase pra levar:

**A Copa passa em 39 dias. Mas o cliente que tu pega agora indica por anos. Não deixa o jogo passar do teu lado.**

Obrigado por ficar até o fim. Boa Copa, e bora faturar.

---

## Mapa de slides

| # | Slide | Bloco | Emoção |
|---|---|---|---|
| 1 | Capa | 1 Aquecimento | pertencimento |
| 2 | Choque (bilhões x zero) | 2 Abertura | ATENÇÃO |
| 3 | Quem sou + AÇÃO ao vivo (conta teus orçamentos parados) | 2 Abertura | ATENÇÃO |
| 4 | A promessa concreta (scripts + plano de 3 passos) | 2 Abertura | ATENÇÃO |
| 5 | A Copa é pico de conta de luz, não precisa de anúncio | 3 Primeira Revelação | SURPRESA |
| 6 | A Copa passa mas a indicação fica | 3 Primeira Revelação | SURPRESA |
| 7 | Os 39 dias que passam do teu lado | 4 Identificação + Consequências | DOR |
| 8 | O que te deixa no banco (3 travas) | 5 Quebra de Crenças | obstáculo removido |
| 9 | A Máquina (5 jogadas, o encontro no centro) | 6 Entrega de Valor | ALÍVIO + ESPERANÇA |
| 10 | A Bola Parada (convida o orçamento parado pro jogo) | 6 Entrega de Valor | ESPERANÇA |
| 11 | O Camarote (parceria com o bar + vende pro dono) | 6 Entrega de Valor | ESPERANÇA |
| 12 | O Terceiro Tempo (pede indicação depois do jogo) | 6 Entrega de Valor | ESPERANÇA |
| 13 | A Torcida + O Vestiário (presença + rotina) | 6 Entrega de Valor | ESPERANÇA |
| 14 | Anatomia do pedido (script na tela + print real) | 7 Segunda Revelação | CONFIANÇA |
| 15 | PLANO DE AÇÃO: os 3 passos pra amanhã | 8 Plano + Chamado | ação |
| 16 | O convite (diagnóstico, pra quem quiser) | 8 Plano + Chamado | decisão |
| 17 | Encerramento + frase | 9 Finalização | ação |

---

## Notas de produção

**Fidelidade ao arco (checar antes do deck):**
- [ ] Cada bloco entrega UMA emoção. Não adiantar a esperança no bloco de dor, não dar conteúdo no bloco de abertura
- [ ] Storytelling em todos os blocos (o bar lotado, o concorrente que liga, o apito final)
- [ ] Checkpoint de identificação a cada bloco ("quem aqui já...", "digita EU"), com leitura nominal do chat
- [ ] Corte no auge no fim do Bloco 6: NÃO ler os 52 scripts no palco, amostrar os melhores e mandar o resto no material

**Conteúdo e fatos:**
- [ ] Confirmar data dentro da janela da Copa
- [ ] VERIFICAR o número de "bilhões" antes de cravar no Slide 2. Sem fonte sólida, falar "bilhões" sem número exato
- [ ] JURÍDICO no deck e na fala: pode verde-amarelo e clima de Copa, NÃO pode logo da FIFA, escudo da CBF nem a marca registrada do torneio
- [ ] ANONIMIZAÇÃO: nenhum nome de cliente real. Sempre [TUA EMPRESA], [Nome]
- [ ] Handout "Arsenal dos 52 plays" (abaixo) em PDF, mandado a TODOS na mesma noite (é o que cumpre a promessa de conteúdo máximo e o "manda o material" do Bloco 6 e 8)
- [ ] Slide 14: preparar o slide com "A Pergunta da Conta de Luz" destacada linha por linha. Separar 1-2 prints de WhatsApp REAIS e anonimizados de indicação que funcionou (mesmo pré-Copa). Print real > encenação

**Convite e pós (protocolo Nimoto):**
- [ ] Aquecimento D-7, aceite no Google Calendar no mesmo dia, ligação 48h antes, WhatsApp na manhã, ligação pra quem não entrou em 10 min
- [ ] Pós-evento: mandar o Arsenal pra presentes e ausentes confirmados na mesma noite, não deixar esfriar

### Princípios Nimoto aplicados (arco)
- [x] Abertura só pra ATENÇÃO: choque nos primeiros segundos + identificação + "não vou vender" + promessa, menos de 5 min
- [x] Primeira Revelação = conceito simples e potente que bate na crença (SURPRESA)
- [x] Identificação ("isso é pra mim", a roleta) antes de amplificar a dor
- [x] 5 minutos de DOR proposital ("vou te deixar desconfortável de propósito")
- [x] Quebra de Crenças como bloco próprio, o coração (o que te deixa no banco)
- [x] Entrega de valor com STORYTELLING e ESPERANÇA, não catálogo
- [x] Resolve PARTE e corta no auge: framework + amostra no palco, 52 scripts no material
- [x] Big idea com nome próprio (A Máquina de Indicação da Copa, 5 partes nomeadas)
- [x] Segunda Revelação = demonstração ao vivo (CONFIANÇA) a ~10 min do fim
- [x] Chamado curto = próximo passo lógico (reunião), sem pitch agressivo
- [x] Promessa cumprida antes do CTA
- [x] Viabilidade real: caixa zero, compra única, sem marca FIFA/CBF

---

# ARSENAL DOS 52 PLAYS (handout completo, com script pronto)

> Material que o participante leva. É a entrega de conteúdo máximo do evento. Organizado pelas 5 jogadas (ordem de palco: A Bola Parada, O Camarote, O Terceiro Tempo, A Torcida, O Vestiário). (ouro) = prioridade.

## A BOLA PARADA (convidar o orçamento parado pro jogo e destravar)

**0. O Convite pra Ver o Jogo (ouro).** A jogada principal: em vez de cobrar o orçamento parado, convida ele pra ver o jogo junto e destrava no clima informal.
Script: *"Fala [Nome]! Vou levar uns clientes meus pra ver o jogo do Brasil quinta, num bar aqui. Bora? Sem papo de venda, é só ver o jogo e tomar uma. E se tu quiser, aproveito e te mostro como ficou aquele número do solar com os valores de hoje, sem compromisso."*

**1. A Lista do Orçamento Frio (ouro).** Liste todo orçamento não fechado dos últimos 12 meses, marque quase-fechou/sumiu/achou-caro, ataque os quentes primeiro, 30 min por dia.
Script: *"Fala [Nome]! Lembrei de você agora que começou a Copa e o consumo de energia dispara nessa época. Cheguei a te passar um orçamento de solar lá atrás. Ainda faz sentido pra você? Sem compromisso, só pra te atualizar com o número de hoje."*

**2. A Conta de Luz da Copa (ouro).** O gancho central: nos 39 dias a conta sobe 15 a 30%. Use como abertura tangível.
Script: *"[Nome], real talk: nesses 39 dias de Copa a conta de luz da maioria das casas sobe uns 15 a 30% só de TV, ar e geladeira dobrados. No seu caso daria uns R$[X] a mais. Quem já botou painel assiste tudo de graça. Bora retomar aquele orçamento?"*

**3. Resgate do Quase-Fechou (ouro).** Pro que travou perto de fechar. Retoma do ponto, não do zero.
Script: *"[Nome], lembra que a gente tava quase fechando e parou no [motivo]? Desde aquele papo a conta de luz e a tarifa só subiram. Cada mês parado é dinheiro que você manda pra concessionária e não volta. Topa destravar isso essa semana? Te mostro quanto você já deixou na mesa."*

**4. A Tarifa Subiu (forte).** Urgência real sem dar desconto.
Script: *"[Nome], aproveitei a Copa pra revisar os orçamentos antigos e o seu me chamou atenção. A tarifa já subiu [X]% desde então. Cada mês sem solar foi dinheiro indo embora. Dá pra travar uma condição boa antes de subir de novo. Quer o número atualizado?"*

**5. Resgate do Achou Caro (forte).** Reenquadra o preço com a conta acumulada.
Script: *"[Nome], lembra que achou o solar caro? Conta rápida: de lá pra cá você pagou uns R$[X] de luz. Esse dinheiro foi embora. O solar não é caro, caro é pagar a concessionária pra sempre. Bora refazer com os números de hoje?"*

**6. Reativação por Áudio Humano (forte).** Pro que ignora texto, áudio de 30s tem cara de gente.
Script (áudio): *"Opa [Nome], é o [Teu nome] da [TUA EMPRESA]. Tava vendo a Copa, conta de luz subindo, e lembrei que a gente conversou sobre solar. Ainda faz sentido ou já resolveu de outro jeito? Me dá um retorno rapidinho. Abraço!"*

**7. Resgate do Sumiu com Quebra de Padrão (apoio).** Honesto e bem-humorado.
Script: *"[Nome], serei honesto: a gente conversou, você sumiu, eu também não corri atrás, tamo quites kkk. Mas vendo a Copa lembrei de você. Ainda rola o interesse no solar ou é assunto encerrado? Me dá só um oi."*

**8. Filtro de Não-Resposta (apoio).** Última cartada, pergunta fechada de um toque.
Script: *"[Nome], última mensagem, prometo. Refiz teu orçamento com valores de hoje. Responde só o número: 1) manda o orçamento, 2) hoje não, 3) já resolvi. Qualquer resposta tá ótima."*

## O TERCEIRO TEMPO (pedir indicação, presencial no encontro e online)

**8b. O Pedido do Terceiro Tempo, presencial (ouro).** A jogada principal: depois do jogo, com a galera reunida e feliz, pede indicação olho no olho. Vale muito mais que mensagem.
Script: *"Pô [Nome], que noite boa, hein. Deixa eu te pedir uma força: tu que já economiza com solar, quem tu conhece que ainda paga fortuna de luz e merecia economizar igual tu? Pensa num nome: vizinho, parente, sócio. Me apresenta que eu cuido de tudo, do mesmo jeito que cuidei do teu."*

**9. Pedido no Apito Final (ouro).** Mensagem individual no minuto seguinte ao fim do jogo, pico de euforia.
Script: *"Fala [Nome]! Que jogo, hein?! Tô pegando o embalo da vitória pra te pedir uma força: você conhece alguém que vive reclamando da conta de luz e merecia economizar igual você? Me passa o contato que eu cuido de tudo. Vamo fazer mais um gol juntos."*

**10. A Pergunta da Conta de Luz (ouro).** Faz o cliente verbalizar a economia antes do pedido.
Script: *"Fala [Nome], pronto pro jogo? Pergunta rápida: depois do solar, quanto você economiza por mês? [espera] Pô, é muita coisa no ano! Por isso te chamei: quem na tua rua ainda paga essa fortuna de luz e merecia economizar como você? Me dá um nome."*

**11. A Escalação dos Indicados (forte).** Ancora alto, pede 3 a 5 nomes.
Script: *"[Nome], se você fosse o técnico da seleção dos economizadores, quem escalaria? Me manda de 3 a 5 nomes de gente que paga caro de luz. Monta tua escalação que eu chamo cada um pra entrar em campo!"*

**12. O Card de Convocação (forte).** Card verde-amarelo no Canva "EU CONVOCO ___ PRA ECONOMIZAR".
Script: *"[Nome], a seleção tá convocada e agora é a TUA vez! Quem você CONVOCA pra parar de pagar caro de luz? Manda o nome e o contato que eu chamo pra jogar."*

**13. Áudio da Resenha (apoio).** Áudio empolgado pós-lance, transição natural pro pedido.
Script (áudio): *"Eaí [Nome], que jogo! O Brasil tá voando! Ó, lembrei de você: tem alguém aí no teu círculo pagando fortuna de luz? Me joga o contato que eu faço o mesmo trabalho caprichado que fiz pra você. Bora Brasil!"*

**14. O Resgate do Torcedor Sumido (forte).** Reativa cliente antigo, resolve pendência, depois pede.
Script: *"Opa [Nome], quanto tempo! Lembrei de você no clima de Copa. Tudo certo com o sistema, conta comportada? [espera] Ótimo! Já que reapareci: conhece alguém que ainda paga caro de energia? Me passa um contato?"*

**15. O Vizinho que Já Instalou (forte).** Prova social geográfica, oferece levar pra ver o sistema.
Script: *"[Nome], lembra que você pediu orçamento? Instalei o sistema de um vizinho seu aqui pertinho. Casa cheia na Copa, conta praticamente zerada. Quer que eu atualize teu orçamento? Posso até te levar pra ver o dele funcionando."*

**16. Comissão de Craque, prêmio só se fechar (ouro).** R$300 a 500 por venda fechada, nada adiantado.
Script: *"[Nome], montei o TIME DOS CRAQUES da [TUA EMPRESA]. Você me indica alguém, e SE fechar a instalação, você ganha R$[valor] no PIX. Nada adiantado, só quando a venda acontece. Tem alguém cansado de pagar caro de luz?"*

**17. Desafio do Pênalti (forte).** Cada indicação que fecha é um pênalti convertido, meta por quantidade.
Script: *"[Nome], bora pro DESAFIO DO PÊNALTI? Cada amigo que indicar e FECHAR é um gol pra você. Fez 3, leva [prêmio]. Só conta quando a venda acontece. Quem é teu primeiro chute?"*

**18. Brinde do Distribuidor (ouro).** Prêmio de indicação bancado pelo fornecedor, custo real zero.
Script (pro fornecedor): *"Fala [representante], tô montando uma ação de indicação na Copa e queria saber se vocês têm brindes de marca pra parceiro. Cada cliente que me indicar ganha um mimo, o que vira venda de kit de vocês no fim. Mandam uma caixa?"*

**19. Reconhecimento do Capitão (forte).** Prêmio = ego, faixa de capitão pro maior indicador.
Script (post): *"Temos um CAPITÃO! O [Nome] foi quem mais indicou amigos pra economizar com solar nessa Copa. Esse cara veste a camisa! Quem vai ser o capitão da próxima?"*

## O CAMAROTE (parceria com o bar + vender pro dono + comércio)

**19b. A Parceria do Camarote, com venda pro dono (ouro).** A jogada principal: fecha o bar como sede do encontro via desconto (sem alugar), e já oferece solar pro dono na mesma conversa.
Script (com o dono): *"Fala [dono]! Sou da [TUA EMPRESA]. Eu junto um grupo de clientes e empresários pra ver os jogos do Brasil e queria trazer essa galera pro teu bar, casa cheia na noite de jogo. Em troca só te peço um desconto pro meu grupo e um cantinho reservado. Fechamos? E já que vamos ser parceiros: com TV, ar e chopeira ligados o jogo inteiro, tua conta de luz vai dar um susto esse mês. Eu trabalho com solar, me deixa fazer uma análise grátis da tua última conta? Em 5 minutos te mostro quanto economiza."*

**20. Análise de Conta Grátis pro Comércio (ouro).** Tática-mãe. Bar, restaurante, padaria, posto, academia, açougue, oficina. Pico de consumo = argumento. Fale com o DONO.
Script: *"Oi [dono], sou da [TUA EMPRESA], energia solar. Tô passando nos comércios que vão exibir os jogos: com TV, ar e geladeira ligados o jogo inteiro, tua conta vai dar um susto esse mês. Como cortesia de Copa, faço uma análise grátis: me passa tua última conta que em 5 min te mostro quanto solar te devolve. Sem compromisso."*

**21. Bar/Comércio como Ponto Oficial (forte).** Parceria de palco custo zero + o bar é prospect.
Script: *"Fala [dono], te proponho uma parceria que não custa nada: eu divulgo teu bar pros meus clientes como ponto pra ver os jogos, e você deixa meu cartaz e me apresenta como o parceiro de energia da casa. E já que vai ligar tudo o jogo inteiro, me deixa fazer uma conta rápida da tua economia com solar?"*

**22. Indicação Cruzada com Quem Atende o Mesmo Cliente (forte).** Eletricista, pedreiro, corretor, contador. Comissão só se fechar.
Script: *"Fala [nome], sou da [TUA EMPRESA]. Você vive dentro da casa dos clientes e escuta reclamação de luz toda hora. Cada vez que me indicar alguém e fechar, te pago uma comissão boa. Você não faz nada além de falar meu nome. Topa?"*

**23. Decoração de Copa com Tua Marca (apoio).** Bandeirinha barata com teu selo em padaria/mercadinho, e prospecta o comércio.
Script: *"Oi [dono], tô oferecendo decoração de Copa de graça pros comércios do bairro, só com um cartãozinho meu junto. Quer pra tua padaria? E aproveitando: forno e câmara fria gastam uma fortuna. Me deixa olhar tua conta?"*

**24. Condomínio/Síndico Parceiro (apoio).** Anima a confraternização com brinde do fornecedor, ganha acesso aos moradores + áreas comuns.
Script: *"Oi [síndico], sei que vão organizar algo pra ver os jogos. Quero ajudar a animar sem custo, levo brindes pra sortear. Em troca, 5 min pra mostrar pros moradores quanto o prédio economizaria com solar nas áreas comuns. Topa um café?"*

## A TORCIDA (presença sem mídia entre os encontros)

**25. Calendário de Conteúdo Jogo a Jogo (ouro).** 3 modelos salvos nas Notas (pré/intervalo/pós), roda 39 dias no automático.
Script (Notas): PRÉ *"[Hora] tem Brasil! Palpite do placar nos comentários."* | INTERVALO *"Intervalo: [placar]. Igual jogo, conta de luz também tem segundo tempo, e meu cliente já ganha o dele."* | PÓS *"[Resultado]! Quem mais ganhou hoje foi quem não paga luz cara. Bora conversar?"*

**26. Status do Verde-Amarelo (ouro).** Status diário comentando o jogo, quem reage vira lead.
Script (após gol): *"GOOOL DO BRASIL! E falando em comemorar: esse mês quem me indicar alguém que feche o solar marca um gol comigo e leva prêmio. Quem conhece alguém afundado na conta de luz? Responde esse status."*

**27. Antes e Depois em Placar (ouro).** Conta de luz antes/depois formatada como placar, em dia de jogo.
Script: *"PLACAR DO MÊS: Conta de luz ANTES R$380 x R$42 DEPOIS do solar. Golaço. Quer ver o teu placar? Manda foto da tua conta aqui."*

**28. Tabela de Jogos com Tua Marca (forte).** Tabela no Canva com teu contato no rodapé, viaja sozinha.
Script: *"Fiz a tabela dos jogos do Brasil pra ninguém perder horário. Salva e compartilha com a galera do churrasco. Cortesia da [TUA EMPRESA], quem cuida da tua energia cuida pra você não perder gol."*

**29. Depoimento de Cliente de Camisa do Brasil (forte).** Vídeo de 15s do cliente, ele reposta pros amigos dele.
Script (convite): *"Fala [nome]! No clima da Copa tô gravando depoimentos rápidos dos clientes. Topa um vídeo de 15s, de camisa do Brasil, falando como foi instalar solar comigo? Posto e te marco. Teus amigos vão ver que você é o cara que economiza."*

**30. Status Consolo da Derrota (apoio).** Conteúdo pronto pra quando o Brasil perde, ocupa o espaço vazio.
Script: *"Doeu, né? O Brasil decepcionou. Mas tem uma coisa que NUNCA decepciona: conta de luz baixa todo mês. Solar é o craque que não dá vexame. Bola pra frente."*

**31. Bastidor da Equipe Torcendo (apoio).** Vídeo cru da equipe de camisa do Brasil, humaniza.
Script (legenda): *"Dia de Brasil e a gente não para. Instalando sol de manhã, torcendo à tarde. Se você quer mais luz e menos conta, chama a [TUA EMPRESA] no direct."*

**32. Churrasco da Vitória bancado pelo grupo (forte).** Potluck na casa que tu já tem, ingresso = trazer um amigo que reclama da conta.
Script: *"Galera, vou fazer um churrasco aqui em casa pra ver o jogo! Cada um leva uma coisinha, e o combinado é: pode trazer aquele amigo que vive reclamando de conta de luz, porque vai ter gente que entende do assunto pra trocar ideia. Quem topa?"*

**33. Grupo de Copa que Vira Canal de Indicação (ouro).** Grupo "Resenha do Sol", aquece com futebol, depois vira ativo. Migra no fim com transparência.
Script (abertura): *"Galera, criei esse grupo pra resenhar os jogos juntos, só zoeira e torcida. Vocês são meus clientes, a turma que eu mais gosto. Bora torcer junto!"* | (migração) *"Esse grupo agora vira a Comunidade de Energia da [TUA EMPRESA]. Quem quiser fica, quem não quiser sai numa boa. Valeu pela torcida!"*

**34. Bolão do Sol (ouro).** Bolão de palpites, entrada = indicar 1 contato, prêmio do fornecedor.
Script: *"[Nome], tô fazendo o BOLÃO DO SOL na Copa! Você palpita os placares e quem acertar mais leva um kit de brinde. Pra entrar é fácil: me indica 1 pessoa interessada em economizar energia. Manda o palpite e o contato!"*

**35. Convite Pré-Jogo Marca um Amigo (apoio).** Véspera do jogo, pede pra marcar um amigo nos comentários.
Script: *"HOJE TEM BRASIL! Quem vai torcer comigo? Marca nos comentários aquele amigo que você vai chamar pra ver o jogo. Bora encher essa torcida!"*

## O VESTIÁRIO (a rotina dos bastidores + pós-Copa, o que segura tudo)

**36. O Telefonema dos 10 por Dia (ouro).** 30 a 45 min/dia, 10 contatos (5 orçamento parado + 3 comércio + 2 indicação), todo dia útil.
Roteiro (cola na parede): *"17h = Hora da Copa. 5 ligações orçamento parado + 3 comércios + 2 pedidos de indicação. Anota o resultado. Contato pesado depois das 19h. Repete até a final."*

**37. O Caderninho da Copa, lista de 1 página (ouro).** Uma lista simples (bloco de notas do celular, caderno ou onde tu já anota) com 8 infos por contato: nome, telefone, quem indicou, data, temperatura, último contato, próximo passo, status. Joga todo contato no mesmo dia. Ninguém sem próximo passo.

**38. Ritual da Manhã, 15 min (forte).** Todo dia abre tua lista, filtra os próximos passos vencidos, manda os toques.

**39. Os 3 Baldes (forte).** Quente (vai rápido pro orçamento), Morno (nutre com conteúdo antes de oferecer), Cliente antigo (não vende, pede indicação). Nunca a mesma mensagem.

**40. A Régua de 60 Dias por Status (forte).** Novo: toque em 24h. Conversando: orçamento em 5 dias. Orçamento: follow-up dias 3, 8, 15. Morno: nutrição semanal. Perdeu: reativa no dia 45, nunca apaga.

**41. Programa Indica e Ganha, só se fechar (ouro).** Recompensa paga só após o indicado fechar. Pode ser R$, limpeza grátis 1 ano, ou brinde do fornecedor.
Script: *"Programa Indica e Ganha da [TUA EMPRESA]: me indique alguém cansado de pagar luz alta. Se fechar, VOCÊ ganha [R$X / limpeza grátis / brinde]. Sem limite. Manda o nome aqui."*

**42. Primeiro Toque Quente (ouro).** Mensagem pro indicado citando quem indicou (transfere confiança).
Script: *"Oi [Nome]! Aqui é o [Teu nome] da [TUA EMPRESA]. O [Quem indicou] me passou teu contato, ele instalou solar comigo e disse que você queria fugir dessa conta de luz também. Posso te mostrar rapidinho quanto economizaria? Sem compromisso."*

**43. Follow-up de 4 Toques (ouro).** Dia 0, 3, 8, 15. Ticket alto fecha entre o 4º e o 8º contato.
Script: TOQUE 2 (dia 3) *"Oi [Nome], conseguiu pensar sobre zerar a conta de luz?"* | TOQUE 3 (dia 8) *"Vi que veio reajuste de novo. Um cliente meu economiza R$[X]/mês. Quer a conta certinha pro teu consumo?"* | TOQUE 4 (dia 15) *"Não quero te encher. Se não for o momento, me avisa. Mas se ainda fizer sentido, encaixo tua instalação esse mês."*

**44. Resgate do Cliente Antigo vira Indicador (forte).** Não vende, converte o vínculo da Copa em indicação.
Script: *"Oi [Nome], que Copa boa! Curti ter você no grupo. Tua instalação tá rodando redondo? Tô abrindo vagas pros próximos meses, me dá uma força: conhece alguém cansado de pagar luz cara? Pra cada indicação SUA que fechar, te dou [recompensa]. Me manda 2 ou 3 nomes?"*

**45. Pedido de Indicação no Pós-Venda, loop infinito (ouro).** No dia que liga o sistema e o cliente vê a geração, pede 2 a 3 indicações.
Script: *"[Nome], teu sistema tá ligado e já gerando! Agora que viu como funciona, quem você conhece que ia AMAR pagar menos luz? Pensa em 2 ou 3: vizinho, colega, parente. Me manda os nomes. E lembra: se fechar, você ganha [recompensa]."*

**46. Conteúdo da Conta de Luz, nutrição do morno (forte).** 1 conteúdo/semana nos 60 dias pros mornos. Quem reage vira quente.
Script (status): *"Conta de luz do [cliente] ANTES: R$680. DEPOIS do solar: R$87. Quanto será que tá vindo a tua esse mês? rs"*

**47. Pesca de Orçamento Parado pós-Copa (forte).** Pro que recebeu orçamento na Copa e sumiu.
Script: *"Oi [Nome], lembra que na época da Copa te mandei o orçamento? Saiu reajuste na tarifa, a economia ficou ainda melhor. Atualizo com os números de hoje? Minha agenda de instalação tá enchendo, mas garanto tua vaga se decidir essa semana."*

**48. Reativação dos Perdidos, dia 45 (apoio).** Leva única pros marcados "perdeu", última chamada com porta de saída.
Script: *"Oi [Nome], faz um tempo desde aquela conversa na Copa. Última passada na lista antes de fechar o mês. Se ainda passa pela sua cabeça parar de pagar luz cara, te encaixo com condição boa. Se não, sem problema, paro de te procurar. Me dá um oi?"*

**49. Cuidar do Cliente pra Indicar pra Sempre (forte).** Relacionamento pós-venda: 30 dias, trimestral, aniversário da instalação. Aba "Clientes Embaixadores".
Script (aniversário): *"Oi [Nome]! Hoje faz 1 ano que tua usina tá ligada. Sabe quanto já economizou? R$[X]! Parabéns pela decisão. Se conhecer alguém que merece economizar assim, você sabe onde me achar."*

**50. Etiqueta de Saída Honesta (apoio).** Sempre porta de saída, máximo 4 toques, trata o não com a mesma educação. Em cidade pequena, reputação é tudo.
Script: *"Sem problema nenhum, [Nome]! Já te tirei daqui. Se um dia bater a vontade de economizar na conta de luz, é só me chamar. Abraço!"*

**51. Balanço dos 60 Dias (apoio).** No dia 60, conta total de contatos, orçamentos, fechados, faturamento. Vira meta do próximo gancho (festa junina, fim de ano).

**52. Os 3 Públicos Separados na Comunicação (forte).** Cliente novo, cliente atual e cliente a resgatar nunca recebem a mesma mensagem nem pelo mesmo canal. Princípio que rege todas as partes.

---

## Os 10 que o cara aplica AMANHÃ

1. A Lista do Orçamento Frio
2. Pedido no Apito Final
3. A Pergunta da Conta de Luz
4. Análise de Conta Grátis pro Comércio
5. Programa Indica e Ganha (só se fechar)
6. O Telefonema dos 10 por Dia
7. Resgate do Quase-Fechou
8. Pedido de Indicação no Pós-Venda
9. O Caderninho da Copa
10. Churrasco da Vitória bancado pelo grupo

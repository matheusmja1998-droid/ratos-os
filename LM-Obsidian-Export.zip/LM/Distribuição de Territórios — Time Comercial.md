# Distribuição de Territórios — Time Comercial L.M
### Cidades acima de 100 mil habitantes · por BDR · Junho 2026 (v3 — com status de lista)

> Distribuição ajustada aos leads que cada BDR JÁ tem no CRM Kommo.
> **Legenda de status:**
> ✅ **Lista feita** — já tem leads dessa cidade/região no CRM, é só trabalhar
> ⬜ **Extrair** — ainda não tem lista, precisa rodar extração (Apify/Google Maps) e subir no CRM

---

## FOTO ATUAL DO CRM

| BDR | Já no CRM (por DDD) | Frente |
|---|---|---|
| **Amanda** | RN/Nordeste — 154 leads | Nordeste |
| **Thiago Cardoso** | RS (138) + MS (36) — 251 leads | RS + MS |
| **Greice** | GO (24) + MT (14) + DF (13) + MG (8) — 64 leads | Centro-Oeste + MG |
| **Valentino** | SC (131) + SP (23) | SC + SP |

---

## ⚠️ AJUSTE DE CONFLITO — Thiago × Greice (MT)
- **MT fica 100% da Greice** · **MS fica 100% do Thiago**
- **4 leads duplicados saem do Thiago** (ficam na Greice): Enerzee · Geração Solar · Solar Chio · Solares Corporativa

---

## 🟢 AMANDA — Nordeste

| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Natal | RN | Lista feita (21+ leads no CRM) |
| ⬜ | Mossoró | RN | Extrair — agro + petróleo |
| ⬜ | Parnamirim | RN | Extrair — metropolitana de Natal |
| ⬜ | Fortaleza | CE | Extrair — capital |
| ⬜ | Caucaia | CE | Extrair |
| ⬜ | Juazeiro do Norte | CE | Extrair |
| ⬜ | Sobral | CE | Extrair |
| ⬜ | Recife | PE | Extrair — capital |
| ⬜ | Caruaru | PE | Extrair |
| ⬜ | Petrolina | PE | Extrair — agro, ticket alto |

> A pipe da Amanda tem 154 leads do RN, mas com cidade no nome só Natal aparece claramente. O restante do RN está na pipe (DDD 84) mas sem cidade identificada — tratar como **Natal e região metropolitana já cobertas**.

---

## 🟢 THIAGO CARDOSO — Rio Grande do Sul + Mato Grosso do Sul

### Rio Grande do Sul
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Porto Alegre | RS | Lista feita (presente no CRM) |
| ✅ | Caxias do Sul | RS | Lista feita |
| ✅ | Novo Hamburgo | RS | Lista feita (5 leads) |
| ✅ | Santa Maria | RS | Lista feita (3 leads) |
| ✅ | Rio Grande | RS | Lista feita (3 leads) |
| ✅ | Gravataí | RS | Lista feita |
| ✅ | Passo Fundo | RS | Lista feita |
| ⬜ | Bento Gonçalves | RS | Extrair — Serra, ticket alto |
| ⬜ | Santa Cruz do Sul | RS | Extrair — indústria forte |
| ⬜ | Guaíba | RS | Extrair — Arauco |
| ⬜ | Canoas | RS | Extrair |
| ⬜ | São Leopoldo | RS | Extrair |
| ⬜ | Pelotas | RS | Extrair |
| ⬜ | Uruguaiana | RS | Extrair |

> O DDD 51/53/54 (RS) tem 138 leads na pipe — boa parte do RS metropolitano e serra já está coberta. As marcadas ⬜ são reforço/expansão.

### Mato Grosso do Sul
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Campo Grande | MS | Lista feita (5 leads) |
| ✅ | Três Lagoas | MS | Lista feita (2 leads) |
| ⬜ | Dourados | MS | Extrair — agro |

> DDD 67 (MS) tem 36 leads — Campo Grande e região já cobertos.

---

## 🟢 GREICE — Goiás + Mato Grosso + DF + Minas Gerais

### Goiás
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Goiânia | GO | Lista feita (DDD 62 — 24 leads na pipe) |
| ✅ | Rio Verde | GO | Lista feita (1 lead) |
| ⬜ | Aparecida de Goiânia | GO | Extrair |
| ⬜ | Anápolis | GO | Extrair — polo industrial |
| ⬜ | Luziânia | GO | Extrair |

### Mato Grosso (frente exclusiva)
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Cuiabá | MT | Lista feita (DDD 65 — leads na pipe) |
| ✅ | Rondonópolis | MT | Lista feita (2 leads) |
| ⬜ | Várzea Grande | MT | Extrair |
| ⬜ | Sinop | MT | Extrair — agro |

### Distrito Federal
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Brasília | DF | Lista feita (DDD 61 — 13 leads) |

### Minas Gerais (8 leads — expandir)
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | (MG geral) | MG | 8 leads na pipe (DDD 31/34) |
| ⬜ | Uberlândia | MG | Extrair — maior do Triângulo |
| ⬜ | Uberaba | MG | Extrair — agro |
| ⬜ | Montes Claros | MG | Extrair |
| ⬜ | Patos de Minas | MG | Extrair |
| ⬜ | Araguari | MG | Extrair |

---

## 🟢 VALENTINO — Santa Catarina + São Paulo (interior)

### Santa Catarina
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Florianópolis | SC | Lista feita (DDD 48 — 131 leads SC na pipe) |
| ✅ | Joinville | SC | Lista feita |
| ✅ | Blumenau | SC | Lista feita |
| ✅ | São José | SC | Lista feita |
| ⬜ | Itajaí | SC | Extrair |
| ⬜ | Chapecó | SC | Extrair — agro (BRF, Aurora) |
| ⬜ | Jaraguá do Sul | SC | Extrair — WEG |
| ⬜ | Balneário Camboriú | SC | Extrair — maior renda/m² do Brasil |
| ⬜ | Criciúma | SC | Extrair |
| ⬜ | Lages | SC | Extrair |
| ⬜ | Brusque | SC | Extrair |
| ⬜ | Tubarão | SC | Extrair |

> SC tem 131 leads na pipe do Valentino — as 4 maiores (Floripa, Joinville, Blumenau, São José) já cobertas. O resto é expansão.

### São Paulo (interior)
| Status | Cidade | UF | Observação |
|---|---|---|---|
| ✅ | Ribeirão Preto | SP | Lista feita (5 leads) |
| ⬜ | Campinas | SP | Extrair — polo tech/industrial |
| ⬜ | São José do Rio Preto | SP | Extrair |
| ⬜ | Sorocaba | SP | Extrair |
| ⬜ | Bauru | SP | Extrair |
| ⬜ | Piracicaba | SP | Extrair — agroindústria |
| ⬜ | Presidente Prudente | SP | Extrair |
| ⬜ | Araçatuba | SP | Extrair |

---

## 📋 RESUMO — O QUE FALTA EXTRAIR

| BDR | Cidades com lista ✅ | Cidades a extrair ⬜ |
|---|---|---|
| **Amanda** | Natal | Mossoró, Parnamirim, Fortaleza, Caucaia, Juazeiro do Norte, Sobral, Recife, Caruaru, Petrolina |
| **Thiago** | Porto Alegre, Caxias, Novo Hamburgo, Santa Maria, Rio Grande, Gravataí, Passo Fundo, Campo Grande, Três Lagoas | Bento Gonçalves, Santa Cruz do Sul, Guaíba, Canoas, São Leopoldo, Pelotas, Uruguaiana, Dourados |
| **Greice** | Goiânia, Rio Verde, Cuiabá, Rondonópolis, Brasília, MG geral | Aparecida, Anápolis, Luziânia, Várzea Grande, Sinop, Uberlândia, Uberaba, Montes Claros, Patos de Minas, Araguari |
| **Valentino** | Floripa, Joinville, Blumenau, São José, Ribeirão Preto | Itajaí, Chapecó, Jaraguá, Balneário, Criciúma, Lages, Brusque, Tubarão, Campinas, Rio Preto, Sorocaba, Bauru, Piracicaba, Pres. Prudente, Araçatuba |

---

## ⚠️ AÇÕES NO CRM

1. **Limpar os 4 leads duplicados** da pipe do Thiago (MT é da Greice): Enerzee · Geração Solar · Solar Chio · Solares Corporativa
2. **Extrair as cidades ⬜** e subir cada uma na pipe do BDR responsável
3. **Considerar campo "Cidade"** no Kommo pra relatório por cidade no futuro

---

*v3 montada em 03/06/2026 · status de lista cruzado com os leads reais do Kommo (nome + DDD) · ✅ = já no CRM · ⬜ = extrair*

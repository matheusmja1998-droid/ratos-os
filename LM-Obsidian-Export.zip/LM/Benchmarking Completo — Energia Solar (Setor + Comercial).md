---
tipo: benchmark de setor
empresa: L.M Agência
nicho: Energia Solar Fotovoltaica (B2B)
atualizado: 2026-06-02
fontes: ABSOLAR, Greener (Estudo GD 2025), Canal Solar, Portal Solar, Exame, pv-magazine, dados internos L.M
status: oficial — referência para reuniões de vendas, treinamento de BDR e posicionamento
---

# Benchmarking Completo — Energia Solar Fotovoltaica
### Setor + Comercial · Mercado Brasileiro · 2025/2026
### Referência oficial da L.M Agência

> Esse documento é a fonte única de verdade sobre o mercado solar pra reunião de vendas, treinamento de prospecção e calibragem de pitch. Os números aqui são pra serem usados na boca do BDR e do closer.

---

## SUMÁRIO EXECUTIVO — O que tu precisa saber em 60 segundos

1. **O mercado solar brasileiro PAROU de crescer.** Depois de anos de boom, 2025 caiu **-29%** e 2026 deve cair mais **-7%**. A maré subiu pra todo mundo; agora ela baixou.
2. **90% das integradoras fundadas antes de 2016 já fecharam.** Só 10% sobreviveram. O setor é um cemitério de empresas que cresceram por acidente e morreram quando o fluxo secou.
3. **68% das integradoras têm até 4 funcionários.** É um mercado de operações minúsculas, sem processo comercial, onde o dono é o vendedor.
4. **O número de propostas caiu 19% em 2025.** Quem dependia de demanda passiva (indicação, lead inbound) está sangrando agora.
5. **A diferença entre quem cresce e quem morre não é o produto. É o processo comercial.** É exatamente isso que a L.M vende.

**A tese da L.M em uma frase:** *num mercado que parou de crescer, ganha quem tem máquina de vendas — não quem espera a indicação chegar.*

---

## 1. TAMANHO E ESTADO DO SETOR

### 1.1 Os números macro (acumulado até 2026)

| Indicador | Valor | Fonte |
|---|---|---|
| Potência solar operacional acumulada | **63,7 GW** | ABSOLAR 2025 |
| └ Geração distribuída (telhados/terrenos) | 43,7 GW | ABSOLAR |
| └ Geração centralizada (usinas) | 20 GW | ABSOLAR |
| Posição na matriz elétrica nacional | **2ª maior fonte (24,5%)** | ABSOLAR |
| Investimento acumulado no setor | R$ 300 bi+ | ABSOLAR/ANEEL |
| Empregos gerados | 1,9 milhão | ABSOLAR |
| Projeção acumulada até fim de 2026 | 75,9 GW | ABSOLAR |
| Empresas que aderiram à solar em 2025 | 217 mil | Portal Solar |

### 1.2 A virada — o mercado retraiu (dado crítico de 2025/2026)

Esse é o ponto que muda tudo. Por anos o setor cresceu em linha reta. Acabou:

| Ano | Capacidade nova adicionada | Variação | Investimento |
|---|---|---|---|
| 2024 | 15 GW | — | R$ 54,9 bi |
| 2025 | 10,6 GW | **-29%** | R$ 32,9 bi (-40%) |
| 2026 (projeção) | ~10,6 GW | **-7%** (mercado) | R$ 31,8 bi |

**Por que caiu:**
- **Curtailment** — cortes de geração nas grandes usinas sem ressarcimento, matando o apetite por novos projetos
- **Entraves de conexão à rede** — distribuidoras barrando novos sistemas alegando incapacidade da rede e inversão de fluxo
- **Alta do dólar** — equipamento importado ficou mais caro
- **Fio B / Lei 14.300** — fim gradual da isenção encareceu o payback em parte dos casos

**O que isso significa pra venda:** o discurso de "energia solar tá bombando, todo mundo quer" morreu. Agora é mercado de disputa. Quem não tiver processo comercial vai brigar por migalha de preço. **Esse é o gancho de urgência mais forte que existe.**

---

## 2. O RETRATO DA INTEGRADORA MÉDIA (o teu cliente)

### 2.1 Quem é (Estudo Greener GD 2025 — base de 6.590 empresas)

| Característica | Dado |
|---|---|
| Integradoras com até 4 funcionários | **68%** |
| Integradoras com 10-30 funcionários | apenas 13% |
| Tamanho médio do time | 6 pessoas (caiu de 7 em 2024, **-17%**) |
| Empresas fundadas nos últimos 5 anos | mais de 50% |
| Empresas fundadas entre 2019-2022 (boom) | 48% |

**Tradução:** o teu cliente é uma operação pequena, jovem, enxuta, que cresceu na onda do boom de 2019-2022 e nunca estruturou comercial de verdade. Quando o mercado virou, ficou exposto.

### 2.2 A taxa de mortalidade (o argumento de venda mais forte do setor)

> **Só 10% das integradoras fundadas antes de 2016 seguem ativas.**
> **90% fecharam.**
> — Canal Solar / Estudo Greener 2025

Isso não é detalhe. É a estatística que tu coloca na mesa do dono na R1:

> *"Cara, 9 em cada 10 integradoras que abriram antes de 2016 já fecharam. As que sobraram não foram as que tinham o melhor painel ou o menor preço — foram as que estruturaram comercial. A pergunta é: tu vai ser os 10% ou os 90%?"*

### 2.3 O colapso da demanda passiva

| Métrica | 2025 | Sinal |
|---|---|---|
| Nº de propostas comerciais por empresa | -19% vs 2024 | Demanda secando |
| Média mensal de orçamentos por empresa | ~21/mês | Volume baixo |
| Integradoras que venderam até 500 kWp/ano | 80% | ~5 sistemas/mês (8 kWp médio) |
| Redução do time médio | -17% | Empresas demitindo |

**Tradução:** o cliente que dependia de "o telefone toca" está vendo o telefone parar de tocar. Ele sente a dor AGORA. Janela perfeita de abordagem.

---

## 3. AS 5 DORES LATENTES (validadas)

**Dor 1 — Dependência total de indicação.**
Tem meses ótimos e meses secos, sem prever qual será qual. Com o mercado em queda, os meses secos viraram regra. **72% das integradoras dependem de indicação como principal canal** (ABSOLAR).

**Dor 2 — O dono é o comercial.**
Fecha a maioria dos contratos pessoalmente. Teto invisível: não cresce mais do que a própria agenda permite. Com time médio de 6 pessoas, não há quem vender no lugar dele.

**Dor 3 — Guerra de preço com concorrente inferior.**
Perde projeto pra quem instala mais barato e pior. Sem argumento estruturado pra justificar valor. Num mercado encolhendo, a pressão de preço aumenta.

**Dor 4 — Sazonalidade matando o caixa.**
Sem pipeline previsível pra antecipar meses fracos. Sem fundo de caixa pra absorver. É o que mata as 90% que fecham.

**Dor 5 — Não sabe onde estão os clientes bons.**
Já tentou anúncio, Instagram, agência. O que chega é lead frio ou caçador de preço.

---

## 4. KPIs DE REFERÊNCIA — O QUE É NORMAL vs ALTO DESEMPENHO

> Use esses números pra diagnosticar o cliente na reunião. "Qual sua taxa de fechamento hoje?" → compara com a tabela → mostra o gap.

### 4.1 Funil comercial

| Métrica | Média do mercado | Alto desempenho |
|---|---|---|
| Conversão lead → reunião | 8-12% | **25-35%** |
| Conversão reunião → proposta | 40-55% | **65-75%** |
| Fechamento de proposta | 15-25% | **40-55%** |
| Taxa de indicação da base | 5-10% | **25-35%** |

### 4.2 Ticket e ciclo

| Segmento | Ticket médio | Ciclo de venda |
|---|---|---|
| Residencial | R$ 18-30k (alto: R$ 30-50k) | 15-30 dias (alto: 7-14) |
| Comercial | R$ 80-250k (alto: R$ 200-500k) | 45-90 dias (alto: 30-60) |
| Industrial/Agro | R$ 300k-2M+ | 60-120 dias |

### 4.3 Custo de aquisição (CAC)

| | Média do mercado | Alto desempenho |
|---|---|---|
| CAC | R$ 800-2.500 | **R$ 300-700** |

**Insight comercial:** no B2B o CAC é naturalmente mais alto (ciclo longo, múltiplos decisores), mas processo estruturado derruba o CAC porque elimina desperdício de tempo com lead errado. Quem prospecta ativo + qualifica bem paga menos por cliente.

### 4.4 Dados estruturais do setor

- **72%** das integradoras dependem de indicação como canal principal
- **Menos de 15%** usam CRM de forma consistente
- Integradoras com processo comercial estruturado crescem em média **3,2x mais rápido**
- B2B representa **40% do volume instalado**, mas menos de **20%** da carteira das integradoras regionais → gap de oportunidade enorme

---

## 5. SEGMENTAÇÃO — ONDE ESTÁ O DINHEIRO

### 5.1 Por perfil de consumo (2024)

| Segmento | % do novo volume | Característica comercial |
|---|---|---|
| Residencial | 57% | Volume alto, ticket baixo, ciclo curto, guerra de preço |
| Comercial | ~25% | Ticket médio-alto, ciclo médio, menos competição |
| Industrial/Rural | ~18% | Ticket alto, ciclo longo, **maior margem e menor competição** |

### 5.2 A grande virada — o B2B/comercial é a saída

Enquanto o residencial sofre com queda de demanda e guerra de preço, o **comercial e industrial** seguem fortes:

- Indústria de alimentos, supermercados, agronegócio: grandes áreas de telhado/terreno, conta de luz alta, decisão racional por payback
- **Migração ao Mercado Livre** (consumidores >50 kW podem migrar em 2026) abre conta nova: economia de até 35% sem investimento
- **Geração Distribuída Compartilhada (GDC)** / energia por assinatura: produto recorrente, MRR, pra quem não tem espaço pra placa

**Setores que mais adotam GD compartilhada:** condomínios comerciais e residenciais, restaurantes, supermercados, centros logísticos, academias, pet shops, escolas, hotéis, hospitais e agronegócio.

**Tradução pro pitch:** a integradora que só vende residencial está no segmento que mais encolheu. A L.M reposiciona ela pro B2B/comercial/agro — onde tem ticket alto, menos concorrência e margem maior.

---

## 6. SOLUÇÕES QUE O CLIENTE JÁ TENTOU (e por que falharam)

| Tentativa | Por que fracassou |
|---|---|
| **Tráfego pago (Meta/Google)** | O problema não era tráfego, era conversão. Lead chegou, mas ninguém qualificou, ninguém seguiu script, lead morreu no WhatsApp. |
| **Instagram / conteúdo orgânico** | Conteúdo genérico sobre solar não gera decisão de compra. Faltou autoridade + mecanismo de captura. |
| **SDR interno sem processo** | Contrataram, deram telefone e lista. Sem script, sem qualificação, sem follow-up. Desistiu em 2 semanas de rejeição. |
| **Parceria com despachante/eletricista** | Sem formalização, sem incentivo, sem acompanhamento. Indicação virou sorte. |
| **Proposta padrão por email** | PDF técnico + preço. Cliente sumiu. Proposta feita no produto, não no diagnóstico. |

**Por que isso importa:** quando o BDR fala com o dono, ele JÁ tentou tudo isso e se queimou. O pitch não é "faça anúncio". É "você já tentou anúncio e não funcionou porque faltava processo — é isso que a gente estrutura".

---

## 7. TENDÊNCIAS 2026 (use pra parecer quem entende do mercado)

1. **Mercado em retração obriga profissionalização.** Acabou o crescimento fácil. Ganha quem tem processo. (Argumento de urgência nº1.)
2. **Agronegócio = maior oportunidade do momento.** Conta de luz alta, área disponível, ticket alto, menos competição. Quem estruturar prospecção ativa agora colhe por 3 anos.
3. **Mercado Livre de Energia abrindo** (consumidores >50 kW em 2026). Economia de até 35%. Nova linha de receita pra integradora vender.
4. **GD Compartilhada / energia por assinatura.** Produto recorrente (MRR) pra quem não tem espaço de telhado.
5. **Financiamento facilitado** (Solfácil e fintechs) reduz ciclo de venda em até 40% quando integrado ao pitch.
6. **IA na prospecção** (Apollo, Clay, Lusha) → listas hiperqualificadas por consumo estimado, setor e porte. (É o diferencial técnico da L.M.)
7. **Reputação digital como ativo comercial.** Decisor pesquisa antes de comprar. Avaliação positiva + presença no Google vende mais sem gastar mais.

---

## 8. POSICIONAMENTO DA L.M (o que a gente vende, contra o que)

### 8.1 L.M vs Agência de marketing tradicional

| Critério | Agência tradicional | L.M Agência |
|---|---|---|
| Foco | Tráfego e conteúdo | **Processo comercial + crescimento de receita** |
| Entregável | Leads, posts, relatórios | **Pipeline previsível, taxa de conversão, fechamentos** |
| Suporte | Relatório mensal | Acompanhamento semanal, roleplay, ajuste de rota |
| Modelo | Retainer fixo sem compromisso | Estruturado em fases com marcos claros |
| Especialização | Genérico | **Nicho B2B / comercial / solar** |

### 8.2 As soluções da L.M (mapeadas pras dores)

| Dor do cliente | Solução L.M |
|---|---|
| Depende de indicação | Máquina de prospecção ativa B2B do zero (lista, script, cadência, treino) |
| Dono é o comercial | Diagnóstico R1+R2 que transforma vendedor em consultor, tira o dono do operacional |
| Guerra de preço | Script de valor que elimina a disputa por menor preço |
| Sazonalidade | Pipeline previsível e mensurável (CRM + funil por etapas) |
| Não acha cliente bom | Segmentação B2B/comercial/agro + reativação de base + programa de indicação |

### 8.3 Expectativa de resultado (cronograma de entrega)

- **30 dias:** prospecção ativa rodando, CRM configurado, primeiras reuniões B2B com perfil certo
- **60 dias:** pipeline previsível, conversão de proposta subindo, dono saindo do operacional
- **90 dias:** canal de prospecção gerando receita independente de indicação, primeiros projetos comerciais grandes no funil, meta com base em dado

---

## 9. MUNIÇÃO PRA REUNIÃO (frases-prontas com dado)

> Pra BDR e closer usarem na boca. Cada frase tem um número que dá autoridade.

**Abertura de urgência:**
> *"O mercado solar caiu 29% ano passado e deve cair mais 7% esse ano. A época de 'o telefone tocar sozinho' acabou. Quem não tiver máquina de vendas vai brigar por preço com concorrente pior."*

**Choque de mortalidade:**
> *"90% das integradoras que abriram antes de 2016 já fecharam. As que sobraram não tinham o melhor painel. Tinham o melhor comercial."*

**Gap de processo:**
> *"Menos de 15% das integradoras usam CRM de verdade. E as que têm processo comercial crescem 3,2 vezes mais rápido. Onde tu tá nessa conta?"*

**Oportunidade B2B:**
> *"O B2B é 40% do volume instalado do país, mas é menos de 20% da carteira da maioria das integradoras. Tem dinheiro na mesa que tu não tá pegando."*

**Reposicionamento agro/comercial:**
> *"O residencial é o segmento que mais caiu. O agro e o comercial seguem fortes — ticket maior, menos concorrência, margem melhor. A gente reposiciona tua operação pra onde o dinheiro tá."*

---

## 10. FONTES

- **ABSOLAR** — Associação Brasileira de Energia Solar Fotovoltaica (dados de potência, investimento, retração 2025/2026)
- **Greener — Estudo de Geração Distribuída 2025** (base de 6.590 empresas, perfil de integradoras, mortalidade, propostas)
- **Canal Solar** — taxa de sobrevivência de integradoras pré-2016
- **Portal Solar** — adesão de empresas, projeção 2026
- **Exame / pv-magazine Brasil / eixos / Seu Dinheiro** — análise da retração de 29%
- **Dados internos L.M** — KPIs de funil, ticket, ciclo e CAC (Estudo de Mercado abril/2026)

---

*Compilado em 02/06/2026 · L.M Agência · Atualizar a cada novo Estudo Greener (anual) e balanço ABSOLAR (trimestral)*

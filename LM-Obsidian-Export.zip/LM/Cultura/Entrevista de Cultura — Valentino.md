---
tipo: entrevista cultura
data: 2026-05-28
entrevistado: Valentino Pascual
contexto: Base pra construir Missão, Visão e Valores da L.M Agência
status: respondido
links:
  - "[[LM — Visão Geral]]"
  - "[[Entrevista de Cultura — Matheus]]"
---

# Entrevista de Cultura — Valentino

Respostas do Valentino pra base de Missão, Visão e Valores da L.M.

---

## Bloco 1 — Visão de futuro e identidade

**1. Visão de 3 anos da L.M (revisado 2026-05-28):**
Empresa **gigantesca**, com todas as equipes montadas, escritórios físicos, líderes em cada frente. Valentino aparece de vez em quando pra gerenciar líderes, não pra operar. Em paralelo, tem outras empresas próprias (possivelmente de tecnologia) gerando alta renda passiva. L.M vira holding de uma vida com múltiplas operações + renda passiva pesada.

**2. O que dá orgulho de verdade:**
- Construir algo que vai durar e virar referência
- A dupla forte que ele e Matheus formam
- Ter escolhido o caminho difícil (B2B sério, não infoproduto fácil)

**3. Linha vermelha — não tolera:**
- Linguagem de vítima
- Falsa modéstia / falta de ambição
- Preguiça intelectual
- Falta de palavra (combinou, não cumpriu, sumiu)

**4. Cliente ideal:**
Indústria/integradora de porte que vira case grande. Cliente âncora, R$10M+/ano, vira referência no nicho.

---

## Bloco 2 — Comportamento sob pressão e legado

**5. Como quer que sintam ao trabalhar com ele:**
- Confiante — "com o Valentino junto, vai dar certo"
- Inspirado — quer ser melhor depois de conhecer ele
- Exigido no limite, mas respeitado

**6. Decisão difícil que mostra quem é:**
Cobrar o Matheus numa parada que ia gerar atrito.

**7. Reação natural quando dá ruim:**
Foco frio — para, analisa, monta plano em horas. Estratégia primeiro, emoção depois.

**8. Legado pro mercado solar B2B:**
*"Tudo acontece por um motivo — e a L.M renasceria."* Frase de identidade quase espiritual. A L.M não é um projeto, é uma missão.

---

## Bloco 3 — DNA do time e modo de operar

**9. Quem vai dar certo na L.M:**
*"A pessoa que vai dar certo na L.M é a que faz dobrado sem ser pedido. A que não vai, faz o mínimo."* — definição própria, mais forte que qualquer opção pré-pronta.

**10. Ritmo certo de operar:**
Rápido + cirúrgico — pensa bem, executa em volume. Estratégia antes, volume depois.

**11. Hábito que separa quem vence:**
Métrica na mesa todo dia (número, não achismo).

**12. Contra-padrão — onde a maioria erra:**
- Confundir movimento com resultado
- Subestimar a parte humana — acha que tecnologia resolve tudo

---

## Bloco 4 — A sociedade e o dia 1

**13. Maior força da dupla Matheus + Valentino:**
Mesma fome — os dois querem o mesmo tamanho de vida. Ambição alinhada.

**14. Sombra — crítica verdadeira:**
Pegam coisa demais — não conseguem delegar.

**15. Frase na parede:**
*"Se não for excelência, não vai pro cliente."*
**Interpretação correta (Valentino esclareceu 2026-05-28):** NÃO é sobre a entrega — é sobre **a pessoa**. Quem vai pra frente do cliente tem que SER excelência antes. Preparo, postura, conhecimento, energia, presença. Se não tá no nível, não vai. Sobre o profissional, não sobre o produto.

**16. Mensagem dia 1 pro novo BDR/vendedor:**
*"Aqui o piso é alto. Vem pra performar, não pra ficar."*

---

## Padrão emergente nas respostas do Valentino

**Sobre quem ele é:**
Estrategista frio sob pressão. Lidera por inspiração + confiança (não por força bruta como o Matheus). Tem visão de longo prazo quase mística ("L.M renasceria"). Acredita em qualidade antes de volume. Filtra duro na entrada ("piso alto").

**Sobre o que ele quer da L.M (revisado):**
**Conglomerado.** L.M virando empresa gigantesca com escritórios e equipes completas + ele construindo outras empresas (tecnologia) gerando renda passiva pesada. Quer ser **gestor de líderes**, não operador. Quer cliente âncora grande que valide o trabalho. Quer time autônomo (gente que faz dobrado sem mandar) porque ele não vai estar no dia-a-dia.

**Tensões visíveis (revisadas):**
- Quer império + renda passiva via outras empresas, mas pega coisa demais hoje (sombra).
- Acredita em rápido + cirúrgico, mas Matheus opera no rápido sempre — atrito de ritmo possível.
- Quer cliente âncora (R$10M+), mas Matheus quer empresa estruturada com gargalo cirúrgico — ICPs diferentes (mas agora compatíveis dentro de um conglomerado com múltiplas frentes).

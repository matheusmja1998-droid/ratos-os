---
tipo: índice
empresa: L.M Agência
data: 2026-05-28
status: oficial
links:
  - "[[LM — Visão Geral]]"
---

# Índice — Cultura e Contratação L.M

Pacote completo de cultura, contratação e retenção construído em 28/05/2026 após a call com o Davi (TRX Group). Tudo aqui foi extraído da entrevista cruzada entre Matheus e Valentino + transcrição fiel do método do Davi.

---

## 📂 Arquivos da pasta

### Origem (entrevistas)

1. [[Entrevista de Cultura — Matheus]] — respostas do Matheus às 16 perguntas-base
2. [[Entrevista de Cultura — Valentino]] — respostas do Valentino às 16 perguntas-base

### Documento oficial

3. [[Cultura L.M — Manifesto]] — Missão, Visão 2028/2030, ICP trilho duplo, 5 valores, frase da parede, ritual de pre-flight, janelas quebradas em aberto

### Playbooks operacionais

4. [[Rotina de Contratação — Modelo Davi (TRX)]] — playbook completo das 11 etapas com timestamps do Fathom pra rastreabilidade
5. [[Script Entrevista de Pressão]] — 6 blocos + checklist pós-entrevista pra aplicar antes de cada R1 de hiring

### Templates contratuais

6. [[Template — Acordo Fire Test]] — 12 cláusulas + resumo prático + checklist pré-assinatura (dia 1 do hiring)
7. [[Template — Dream Plan]] — formulário + contrato de bônus + rituais pós-assinatura + regras de ouro (dia 46+)

---

## 🎯 Resumo executivo

**Missão:** operação comercial mais bem-feita do mercado solar B2B brasileiro, sem hype, sem promessa fácil.

**Visão dupla:**
- 2028: máquina escalável de 30+ pessoas, escritório físico, líderes por frente, cliente âncora R$10M+
- 2030: L.M vira primeira peça de um conglomerado — sócios lideram líderes, outras empresas em paralelo gerando renda passiva

**ICP trilho duplo (80/20):**
- 80% Ignição Comercial (cirurgia rápida em empresa estruturada)
- 20% Conta âncora R$10M+/ano (1-2 por ano, longo prazo)

**5 valores:**
1. Faz dobrado, sem mandar
2. Número na mesa. Hoje.
3. Se não for excelência, não vai pro cliente (sobre a pessoa, não a entrega)
4. Caminho difícil por escolha
5. Palavra vale contrato

**Frase da parede:** *Número na mesa hoje. Excelência antes de sair pro cliente.*

**Meta cravada (Davi):** R$100k/mês até dezembro/26.

---

## 🔁 Funil de hiring (modelo Davi)

```
Anúncio (Meta+Google)
    ↓
Formulário (15 perguntas + 5 valores + Dream Plan inicial)
    ↓ (corta 66%)
Entrevista de Pressão (20-30 min, 6 blocos)
    ↓ (aprova 1-2 de cada 5)
Fire Test 45 dias (100% comissão, 15% upfront, bônus esporádicos R$25-50)
    ↓ checkpoint dia 15 + 30 + 45
Efetivação (fixo + comissão mantida)
    ↓ dia 53
Dream Plan ativo (bônus atrelado ao sonho material grande)
    ↓
Plano de carreira: BDR → Closer → Head/Sócio em projeto novo
```

---

## ✅ Decisões fechadas (28/05/2026)

| Tema | Decisão |
|---|---|
| Visão 2028+2030 | Confirmada (escala COM liberdade + conglomerado) |
| ICP | Trilho duplo 80/20 |
| Frase da parede | "Número na mesa hoje. Excelência antes de sair pro cliente." |
| Bônus diário Fire Test | R$25 (esporádico, sem regra fixa) |
| Bônus semanal Fire Test | R$50 (esporádico, sem regra fixa) |
| Bônus de saída | Não tem |
| Meta Fire Test | 2 contratos em 45 dias |
| Horário | 8h-17h seg-sex |
| Comissão | 15% sobre upfront (sem MRR) |
| Confidencialidade Dream Plan | Mantida (estilo Davi) |

---

## ⏳ Em aberto (próximos passos)

- [ ] Validar Acordo Fire Test e Dream Plan com advogado (1x só, R$300-800)
- [ ] Definir Dream Plan do Matheus e do Valentino (vocês como piloto antes de virar regra)
- [ ] Decisão Cockpit/portfólio até **2026-06-15** (próximas empresas são juntas ou cada um toca as suas paralelas?)
- [ ] Atacar 1ª janela quebrada: pre-flight obrigatório de R2 + confirmação 2h antes (próximas 48h)
- [ ] Imprimir frase da parede e colar no espaço de trabalho
- [ ] Ler o manifesto junto (Matheus + Valentino, 30 min, frase por frase)

---

## 🔗 Conexões externas

- [[LM — Visão Geral]] — visão geral da L.M
- [[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]] — call de origem
- [[Aula - Cultura de Alta Performance]] — base teórica (Adriano/Os Escolhidos)
- [[2026-05-08 — Alinhamento Sócios (Metas Maio)]] — divisão de papéis Nimoto+Adriano

---

## 📅 Histórico

- **2026-05-28** — Pacote completo criado após call com Davi (TRX Group). 7 arquivos. Decisões cravadas com Matheus e Valentino na sessão.

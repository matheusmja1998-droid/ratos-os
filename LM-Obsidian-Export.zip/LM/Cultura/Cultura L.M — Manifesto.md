---
tipo: manifesto cultural
empresa: L.M Agência
data_criacao: 2026-05-28
versao: 1.0
status: oficial
fonte:
  - "[[Entrevista de Cultura — Matheus]]"
  - "[[Entrevista de Cultura — Valentino]]"
  - "[[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]]"
  - "[[Aula - Cultura de Alta Performance]]"
links:
  - "[[LM — Visão Geral]]"
---

# Cultura L.M — Manifesto

> Cultura é comportamento tolerado, não valor declarado.
> — Adriano (Os Escolhidos)

Esse documento foi construído a partir de entrevista cruzada entre os dois sócios. Não é cópia de mentor, não é texto de consultoria. É o que Matheus e Valentino realmente exigem de si mesmos, um do outro e de quem entrar na L.M.

---

## Missão

Provar que dá pra construir a operação comercial mais bem-feita do mercado solar B2B brasileiro — sem hype, sem promessa fácil, só com pessoas que entregam dobrado, número na mesa todo dia e excelência antes de qualquer contato com o cliente.

---

## Visão

**Em 2028,** a L.M é a operação comercial mais bem-feita do mercado solar B2B brasileiro. Máquina de 30+ pessoas distribuída em equipes completas, com escritório físico, líderes em cada frente e clientes âncora de R$10M+ na carteira.

**Em 2030,** a L.M é a primeira peça de um conglomerado. Matheus e Valentino lideram líderes, não operação. Em paralelo, cada sócio constrói outras empresas (tecnologia, produto, infraestrutura) gerando renda passiva pesada. A L.M deixou de ser um trabalho e virou um ativo dentro de um portfólio.

---

## ICP — pra quem a L.M existe

Dois trilhos rodando em paralelo desde já (80/20):

**Trilho principal (80%) — Ignição Comercial:**
Empresa estruturada (integradora solar B2B) que já fatura, tem time, e precisa só destravar gargalo comercial específico. Implementação rápida e cirúrgica.

**Trilho de elite (20%) — Conta Âncora:**
Indústria ou integradora de porte (R$10M+/ano) que vira case de referência no setor. 1-2 contas por ano. Operação longa, validação de mercado, abre portas pra mais.

---

## Os 5 Valores da L.M

### 1. Faz dobrado, sem mandar
Aqui não existe "fiz o que mandaram". Quem espera ordem está no lugar errado. Quem fica na L.M é quem entrega 110% e ainda olha pro lado pra cobrir gap do colega antes do gap virar fogo.

**Comportamento esperado:**
- Entregar acima do combinado, sem precisar de cobrança
- Trazer problema com solução, nunca só problema
- Cobrir gap do colega antes de virar fogo
- Pegar a próxima tarefa antes de ser pedido

**Comportamento intolerável:**
- Fazer o mínimo
- Esperar mandão
- "Não era minha função"
- Entregar no prazo e parar

---

### 2. Número na mesa. Hoje.
Métrica é a única verdade que circula na L.M. Sem narrativa pra esconder número ruim, sem "acho que tá indo bem". Decisão é por dado, não por sensação.

**Comportamento esperado:**
- Abrir dashboard antes de qualquer reunião
- Trazer número exato do dia anterior na daily
- Decisão fundamentada em dado
- Compartilhar número ruim com a mesma velocidade do número bom

**Comportamento intolerável:**
- "Acho que tá indo bem"
- Esconder número ruim em texto longo
- Chegar em reunião sem o número
- Justificar resultado sem mostrar o dado

---

### 3. Se não for excelência, não vai pro cliente
A régua aqui não é a entrega — é o profissional. Quem entra numa sala, numa call ou num WhatsApp em nome da L.M tem que estar **no nível antes**. Preparado, descansado, estudado, presente. Se não tá no nível hoje, avisa antes — não improvisa em cima do cliente.

**Comportamento esperado:**
- Doc de guerra pronto antes de toda R2
- Estudo do cliente antes de R1 (site, faturamento, gargalo)
- Postura, energia e foco no momento do contato
- Avisar quando não tá no nível e remarcar — sem improvisar
- Primeira impressão tratada como decisiva

**Comportamento intolerável:**
- Entrar mal preparado e "ver no que dá"
- Atender cliente importante exausto, distraído, de qualquer jeito
- Improvisar resposta técnica que não sabe
- Tratar primeira impressão como descartável

---

### 4. Caminho difícil por escolha
A L.M existe porque os sócios recusaram o caminho fácil (infoproduto, hype, promessa rasa). Quem entra escolheu o difícil também. Aqui pressão é filtro, não acidente.

**Comportamento esperado:**
- Abraçar pressão como filtro de quem fica
- Encarar a conversa difícil em 48h
- Estudar fora do horário, sem precisar de cobrança
- Não terceirizar problema — pega e resolve

**Comportamento intolerável:**
- Linguagem de vítima ("o mercado", "o cliente", "ninguém me avisou")
- Falsa modéstia / falta de ambição ("tá bom assim")
- Preguiça intelectual (não estudou, não testou, repete o mesmo erro)
- Acumular conversa difícil por medo de atrito

---

### 5. Palavra vale contrato
Combinou, cumpriu. Não vai cumprir, avisa antes. Sumiu, tá fora. Aqui a palavra de um membro da L.M tem o mesmo peso jurídico de um contrato assinado.

**Comportamento esperado:**
- Prazo combinado é prazo entregue
- Se não vai cumprir, avisa **antes** de estourar
- Conversa difícil em até 48h, sem acúmulo
- Cumprir o que falou, mesmo quando ninguém tá olhando

**Comportamento intolerável:**
- Sumir
- Quebrar combinado sem aviso
- Engolir cobrança pra evitar atrito
- Prometer pra fechar e ajustar depois

---

## Frase da parede

> **Número na mesa hoje. Excelência antes de sair pro cliente.**

A frase combina os dois pilares de operação da L.M: dado como única verdade + pessoa preparada antes do contato. Toda manhã, antes de qualquer coisa, é o que vocês releem.

---

## Ritual de Excelência — Pre-flight obrigatório

> Valor 3 sem ritual vira discurso. Esse aqui é o sistema que garante que **quem vai pro cliente tá no nível antes**.

### Pre-flight de R1 (ligação ou call de descoberta) — 10 minutos

Antes de qualquer R1, o responsável (vendedor ou BDR) preenche:

1. **Cliente:**
   - Nome completo + empresa + cargo
   - Faturamento estimado (Receita Federal / LinkedIn / site)
   - Site lido — produto/serviço principal em 1 linha
   - Concorrente direto identificado
2. **Hipótese de gargalo:**
   - Por que ele preencheu o webinar? Qual dor pública?
   - Qual gargalo mais provável (prospecção, conversão, retenção)?
3. **Objetivo da call:**
   - Qual a pergunta exata que tu precisa responder ao sair?
   - O que conta como "R1 bem feita"?
4. **Estado pessoal:**
   - Tô descansado? Foquei? Comi? Bebi água?
   - Se não tô no nível: avisar o sócio antes da call. Não improvisar.

**Regra:** sem pre-flight preenchido, não entra na call. Se a pessoa entrou sem, **a call não conta** pra meta do dia.

---

### Pre-flight de R2 (call de venda / fechamento) — 60 minutos

R2 não negocia o doc de guerra. Sem doc, não tem R2.

1. **Doc de guerra preenchido** (template existente em `lm/comercial/docs-de-guerra/`)
2. **Replay da R1** revisado (Fathom)
3. **Resposta às 3 objeções mais prováveis** escritas e treinadas
4. **Tríade de ofertas** definida antes de entrar
5. **Estado pessoal:** mesma checagem do pre-flight de R1, mas mais rígida
6. **Confirmação 2h antes:** WhatsApp ou ligação pra reduzir no-show

**Regra:** sem doc de guerra, a call não acontece. Reagenda. O Matheus assume isso pessoalmente até o time aprender o padrão.

---

### Pre-flight diário (toda manhã, 5 minutos)

Antes do daily Matheus + Valentino:

1. Dashboard aberto? **Número de ontem na mesa?**
2. Calls do dia mapeadas? **Pre-flight de cada uma feito?**
3. Tô no nível hoje? **Se não, do que preciso pra ficar?**

**Regra:** quem chega no daily sem ter feito o pre-flight diário fala por último — e perde tempo do colega. Janela quebrada que vira padrão se não for tratada em 48h.

---

## Janelas quebradas que precisam ser tratadas agora

Antes do manifesto rodar, listar e tratar as janelas quebradas atuais entre os sócios:

- [ ] Despreparação de R2 demora 1h e às vezes o cara dá no-show — virou o gargalo. **Solução:** pre-flight obrigatório + confirmação 2h antes.
- [ ] Pegar coisa demais (admitido pelos dois) — trava escala. **Solução:** todo novo "agarro" passa pelo filtro "isso só eu posso fazer?". Se não for, delega ou agenda.
- [ ] Pipe gigante do Valentino (1820 leads) com follow-up irregular. **Solução:** Matheus assume folow do webinar (já combinado em 2026-05-08).

---

## Como esse manifesto vira operação

1. **Hiring:** todo candidato lê os 5 valores **antes** de aplicar. Formulário pergunta qual valor mais incomoda. Quem não responde com profundidade não passa.
2. **Onboarding (dia 1):** novo membro escolhe seu Dream Plan e lê o manifesto em voz alta com Matheus ou Valentino.
3. **Daily:** começa com pre-flight diário (5 min).
4. **Weekly (sexta):** revisa 1 valor por semana. Quem exemplificou? Quem violou? O que foi feito?
5. **Monthly:** revisa os 4 pilares (rituais, linguagem, consequências, referências) usando o framework do Adriano em [[Aula - Cultura de Alta Performance]].
6. **Janela quebrada:** tratada em até 48h, em conversa individual, usando SBI (Situação, Comportamento, Impacto).

---

## Decisões abertas que vão entrar em versões futuras

- **Cockpit e outras empresas do portfólio:** Matheus já constrói o Cockpit. Valentino quer outras empresas próprias (tecnologia, renda passiva). Decisão pendente: as próximas empresas do portfólio são construídas juntos (modelo L.M 50/50) ou cada um toca as suas paralelas? **Definir até:** 2026-06-15.

---

## Próximos passos (próximas 2 semanas)

1. [ ] Matheus e Valentino lerem juntos esse manifesto e ajustarem o que ainda não fica de pé
2. [ ] Imprimir frase da parede e colar no espaço de trabalho
3. [ ] Atacar a 1ª janela quebrada listada (pre-flight de R2)
4. [ ] Adicionar pre-flight diário no daily a partir de segunda
5. [ ] Definir o Dream Plan dos dois sócios primeiro (vocês são o piloto antes de virar regra pro time)
6. [ ] Montar funil de hiring do Fire Test com os 5 valores no formulário
7. [ ] Decisão Cockpit/portfólio até 15/06

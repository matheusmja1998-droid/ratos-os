---
tipo: template contratual
empresa: L.M Agência
data: 2026-05-28
status: rascunho (validar com advogado antes do primeiro uso)
contexto: Documento assinado no dia 1 do Fire Test pelo candidato + sócios da L.M
links:
  - "[[Cultura L.M — Manifesto]]"
  - "[[Rotina de Contratação — Modelo Davi (TRX)]]"
  - "[[Script Entrevista de Pressão]]"
---

# Template — Acordo de Período de Avaliação (Fire Test)

> Esse é o documento que o candidato assina no dia 1 do Fire Test. Linguagem direta, sem juridiquês exagerado. Antes de usar pela primeira vez, **passa por advogado** pra validar (R$300-800 numa revisão).
>
> Texto entre `[colchetes]` é variável — preencher antes de imprimir/assinar.

---

## Como usar

1. Imprime 3 vias (1 candidato, 1 L.M, 1 backup)
2. Lê em voz alta com o candidato na reunião de onboarding
3. Pausa em cada cláusula e pergunta: *"Tu entendeu? Tu concorda?"*
4. Candidato + Matheus + Valentino assinam todas as vias na frente de uma testemunha
5. Candidato leva a via dele, L.M arquiva as outras 2

---

# ACORDO DE PERÍODO DE AVALIAÇÃO

**Data:** [DD/MM/AAAA]

## 1. PARTES

**Avaliado(a):**
- Nome completo: [NOME]
- CPF: [CPF]
- WhatsApp: [WHATSAPP]
- E-mail: [E-MAIL]

**Avaliador (L.M Agência):**
- Razão social: L.M Agência
- CNPJ: 62.831.134/0001-01
- Sócios responsáveis: Matheus Jardim e Valentino Pascual

---

## 2. NATUREZA DO ACORDO

Este documento formaliza um **período de avaliação de 45 dias corridos** entre o Avaliado e a L.M Agência, com o objetivo de validar performance comercial e adequação cultural antes de uma eventual contratação formal.

**Este acordo NÃO constitui:**
- Vínculo empregatício (CLT)
- Estágio
- Contrato de prestação de serviços continuado

**Este acordo constitui:**
- Período de avaliação remunerado exclusivamente por comissão sobre resultado, com possibilidade de bônus pontuais de desempenho.

Ambas as partes reconhecem que durante esse período não há garantia de continuidade da relação após o dia 45.

---

## 3. PRAZO

- **Início:** [DD/MM/AAAA]
- **Término:** [DD/MM/AAAA] (45 dias corridos após o início)
- **Decisão sobre continuidade:** comunicada em até 3 dias úteis após o término.

---

## 4. ROTINA E CARGA DE TRABALHO

- **Horário base:** segunda a sexta, das **08h00 às 17h00**
- **Modalidade:** [presencial / home office / híbrido — DEFINIR]
- **Disponibilidade complementar:** o Avaliado se compromete a estar disponível para demandas pontuais fora do horário base, incluindo eventuais comunicações em horários estendidos relacionadas a follow-up de clientes, ajustes urgentes ou reuniões estratégicas.
- **Rituais obrigatórios:**
  - Daily de 15 minutos todo dia útil (horário a combinar)
  - Weekly de 45 minutos toda sexta
  - Pre-flight obrigatório antes de cada R1 (conforme [[Cultura L.M — Manifesto]])

O Avaliado reconhece que aceitou voluntariamente essas condições após ter sido informado expressamente sobre elas durante a entrevista.

---

## 5. REMUNERAÇÃO

### 5.1 Comissão sobre resultado

O Avaliado receberá **15% (quinze por cento) sobre todo valor efetivamente recebido pela L.M Agência** referente a contratos comerciais originados por sua atividade de prospecção/agendamento durante o período de avaliação.

**Regras:**
- A comissão incide apenas sobre **leads prospectados pelo Avaliado** (não sobre leads do pipeline geral da L.M ou do sócio Valentino).
- A comissão é paga **quando o valor entra no caixa da L.M**, não na assinatura do contrato.
- Em contratos parcelados, a comissão segue o cronograma de entrada do dinheiro (15% sobre cada parcela recebida).
- Em caso de cancelamento, estorno ou chargeback do cliente, a comissão correspondente é descontada do próximo pagamento ao Avaliado.
- O pagamento da comissão ao Avaliado é realizado em até **5 dias úteis** após a confirmação da entrada do valor no caixa.

### 5.2 Bônus pontuais de desempenho

A L.M Agência poderá oferecer **bônus pontuais em dinheiro por desempenho diário ou semanal**, a critério dos sócios.

- **Não há valor fixo** desses bônus
- **Não há garantia** de oferta ou pagamento regular
- São prêmios esporádicos para incentivar resultado em momentos específicos (ex: "primeiro a bater X agendamentos hoje leva R$ Y")
- Não compõem remuneração regular nem geram expectativa de continuidade

### 5.3 Sem remuneração fixa

Durante os 45 dias de avaliação, **não há salário fixo, ajuda de custo, vale-refeição, vale-transporte ou qualquer outro pagamento garantido** além das comissões e bônus pontuais descritos acima.

---

## 6. META DO PERÍODO

Ao final dos 45 dias, o Avaliado deverá ter **fechado no mínimo 2 (dois) contratos comerciais** para a L.M Agência.

Entende-se por "contrato fechado":
- Cliente assinou proposta
- Pagamento inicial entrou no caixa da L.M
- Cliente está em status de "ativo" no CRM

---

## 7. CHECKPOINTS DE ACOMPANHAMENTO

A L.M realizará 3 checkpoints formais durante o período:

| Dia | Foco | Critério |
|---|---|---|
| **Dia 15** | Atividade | Volume mínimo de ligações e agendamentos sendo cumprido |
| **Dia 30** | Resultado | Pelo menos 1 R2 qualificada agendada ou 1 contrato em negociação avançada |
| **Dia 45** | Decisão final | Avaliação completa de performance + fit cultural |

A L.M reserva-se o direito de **encerrar este acordo antes do dia 45** caso o Avaliado não cumpra os marcos de atividade ou viole de forma grave os valores culturais descritos no [[Cultura L.M — Manifesto]] (linguagem de vítima recorrente, falta de palavra, sumiço sem aviso, desrespeito a cliente).

---

## 8. AO FINAL DO PERÍODO

### 8.1 Aprovação (efetivação)

Caso o Avaliado seja aprovado, será iniciada negociação de um novo contrato envolvendo:
- Remuneração fixa mensal de R$ 2.100,00 (dois mil e cem reais)
- Comissão de 5% (cinco por cento) sobre o valor efetivamente recebido pela L.M Agência referente aos contratos originados pelo Avaliado
- Estruturação de bônus específico atrelado ao plano de desenvolvimento pessoal (Dream Plan)

O modelo exato da efetivação será apresentado ao Avaliado nos últimos 5 dias do período de avaliação.

### 8.2 Não aprovação

Caso o Avaliado não seja aprovado:
- L.M paga todas as comissões já devidas (sobre contratos que efetivamente entraram no caixa até a data de encerramento)
- O acordo é encerrado sem aviso prévio adicional e sem indenização (uma vez que não constitui vínculo CLT)
- Não há bônus de saída ou contrapartida adicional

### 8.3 Encerramento antecipado

Caso a L.M encerre o acordo antes do dia 45 (por descumprimento de meta ou cultura) ou o Avaliado decida desistir antes do prazo:
- Aplicam-se as mesmas regras do item 8.2
- Comissões já devidas continuam sendo pagas conforme cronograma original (incluindo MRR/parcelas futuras de contratos já fechados pelo Avaliado durante o período)

---

## 9. SIGILO E PROPRIEDADE

Durante e após o período de avaliação, o Avaliado se compromete a:

- **Não compartilhar com terceiros:** listas de leads, dossiês de cliente, scripts comerciais, doc de guerra, materiais internos, dashboards, métricas da L.M ou de seus clientes
- **Não levar consigo:** cópias físicas ou digitais de qualquer material proprietário da L.M
- **Não utilizar:** informações obtidas durante o período de avaliação em concorrentes diretos da L.M Agência por **12 meses** após o encerramento deste acordo

Em caso de violação dessa cláusula, a L.M reserva-se o direito de adotar as medidas legais cabíveis.

---

## 10. RESCISÃO

Qualquer uma das partes pode encerrar este acordo a qualquer momento durante os 45 dias, mediante comunicação direta (verbal ou escrita), aplicando-se as regras do item 8.

---

## 11. DISPOSIÇÕES FINAIS

11.1 Este acordo representa o entendimento integral entre as partes sobre o período de avaliação e substitui qualquer comunicação verbal anterior.

11.2 Alterações neste acordo somente terão validade se feitas por escrito e assinadas por ambas as partes.

11.3 As partes elegem o foro da comarca de [CIDADE/UF] para dirimir quaisquer dúvidas ou litígios decorrentes deste acordo.

---

## 12. DECLARAÇÃO DO AVALIADO

Declaro que:

- [ ] Li este acordo integralmente
- [ ] Tive a oportunidade de tirar todas as minhas dúvidas antes de assinar
- [ ] Entendo que não há remuneração fixa garantida durante os 45 dias
- [ ] Entendo que minha continuidade depende exclusivamente da minha performance e fit cultural
- [ ] Entendo que este acordo não constitui vínculo empregatício
- [ ] Li o [[Cultura L.M — Manifesto]] e concordo com os 5 valores descritos
- [ ] Estou aceitando este acordo por livre vontade

---

## 13. ASSINATURAS

**Avaliado:**

_____________________________________
[NOME]
CPF: [CPF]

**L.M Agência:**

_____________________________________
Matheus Jardim
Sócio

_____________________________________
Valentino Pascual
Sócio

**Testemunha:**

_____________________________________
Nome: [NOME DA TESTEMUNHA]
CPF: [CPF DA TESTEMUNHA]

---

**Local e data:** [CIDADE/UF], [DD] de [MÊS] de [AAAA].

---

## ANEXO — RESUMO PRÁTICO (em 1 página)

Pra ler com o candidato antes de assinar, em linguagem simples:

> **O que tu tá assinando:**
>
> - 45 dias trabalhando comigo na L.M. Cem por cento comissão. Sem fixo.
> - Tu fecha contrato, tu recebe 15% do que entrar no caixa. Não fechou, não ganhou nada.
> - Tem bônus pontual quando bater meta do dia (R$25, R$50, varia). Não é todo dia, não é garantido.
> - Tua meta é fechar 2 contratos nos 45 dias.
> - Tem 3 checkpoints: dia 15, 30 e 45. Em qualquer um eu posso cortar se tu não tiver entregando.
> - Se tu passar, a gente negocia teu fixo + comissão + bônus do teu sonho.
> - Se tu não passar, a gente paga só o que tu já fechou e acabou. Sem indenização, sem aviso prévio, sem briga.
>
> **O que tu tá comprometendo:**
>
> - 8h às 17h de segunda a sexta. Ponto.
> - Mas se tiver fogo, tu atende fora do horário. Cliente importante não espera horário comercial.
> - Daily todo dia. Weekly toda sexta. Pre-flight obrigatório antes de cada R1.
> - Não vai levar lista de lead, script ou material da L.M se tu sair.
> - Não vai trabalhar pra concorrente direto por 12 meses depois de sair.
>
> **Tu entendeu?**
> **Tu topa?**
> **Assina aqui.**

---

## CHECKLIST PRÉ-ASSINATURA (sócios)

Antes de fazer o candidato assinar, conferir:

- [ ] Documento revisado por advogado (na primeira vez de uso)
- [ ] Variáveis entre `[colchetes]` preenchidas
- [ ] Data de início definida
- [ ] Modalidade (presencial/home/híbrido) definida
- [ ] Cidade/UF do foro preenchida
- [ ] 3 vias impressas
- [ ] Testemunha disponível na assinatura
- [ ] Candidato leu o [[Cultura L.M — Manifesto]] antes
- [ ] Resumo prático lido em voz alta com o candidato

---

## PRÓXIMOS PASSOS

- [ ] Passar esse template por advogado (uma vez só, depois reutiliza)
- [ ] Criar versão final em Google Docs ou Notion pra editar rápido por candidato
- [ ] Criar pasta `LM/Cultura/Acordos Fire Test/` pra arquivar contratos assinados
- [ ] Anexar foto/scan do contrato assinado no CRM do candidato

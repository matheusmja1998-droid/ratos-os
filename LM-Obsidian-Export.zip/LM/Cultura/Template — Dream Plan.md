---
tipo: template + processo
empresa: L.M Agência
data: 2026-05-28
status: rascunho (validar com advogado o contrato antes do primeiro uso)
contexto: Plano de desenvolvimento pessoal aplicado no dia 46+ (pós-efetivação do Fire Test) — método Davi (TRX)
links:
  - "[[Cultura L.M — Manifesto]]"
  - "[[Rotina de Contratação — Modelo Davi (TRX)]]"
  - "[[Template — Acordo Fire Test]]"
---

# Template — Dream Plan

> **Dream Plan = a empresa vira o veículo que leva o funcionário até o sonho material grande dele.**
>
> Método do Davi (TRX). Aplicado APENAS depois do Fire Test (dia 46+).
> Davi: *"Eu dou uma semana para o cara listar o sonho dele bem, de bem material mesmo."*

---

## Por que existe

A retenção real não vem de salário maior. Vem de **ligar o trabalho diário a uma recompensa pessoal específica**.

Concorrente oferece R$500 a mais? O BDR não sai porque sair = perder o sonho inteiro.

**Davi (call 28/05):**
> *"Ele não me larga, essa é minha mentalidade."*

---

## Quando aplicar

| Momento | O que acontece |
|---|---|
| **Dia 1 do Fire Test** | Apenas MENCIONAR como cenoura: "tem BDR aqui que vai comprar Jetta de R$320k até dezembro" |
| **Dia 1-45 do Fire Test** | NÃO mexer no Dream Plan ainda. Foco em provar que ele aguenta. |
| **Dia 46 (efetivação)** | Apresentar a estrutura. Dar 7 dias pro funcionário trazer o sonho. |
| **Dia 53** | Reunião de fechamento do Dream Plan. Assinar o contrato de bônus. |
| **Mensal** | Refresh: quanto falta pro sonho? Quantos contratos? |
| **A cada 25%/50%/75%/100% do progresso** | Conversa formal de marco + reconhecimento público. |

---

# PARTE 1 — FORMULÁRIO DO SONHO

Esse é o formulário que o funcionário recebe no dia 46. Ele tem **7 dias** pra preencher e devolver.

Pode ser em Google Forms, Notion ou impresso. Sugestão: começar impresso pra ter peso simbólico.

---

## FORMULÁRIO DO DREAM PLAN

**Funcionário:** ____________________________________________
**Data de início na L.M:** _______________
**Data de preenchimento deste documento:** _______________

---

### Parte A — O sonho

**1. Qual é o seu sonho material grande para os próximos 1-3 anos?**

Não vale "ser feliz", "ter sucesso", "ter estabilidade". Tem que ser uma coisa concreta que tu consegue desenhar na cabeça e que custa dinheiro.

Exemplos válidos:
- Comprar um carro específico (modelo X, ano Y)
- Dar entrada num apartamento na cidade Z
- Fazer um intercâmbio em [país] de X meses
- Abrir uma empresa do seu próprio negócio
- Pagar a faculdade do seu filho/irmão
- Tirar a família de [situação atual]
- Comprar a moto/equipamento/instrumento dos seus sonhos

**Seu sonho:**

________________________________________________________________
________________________________________________________________
________________________________________________________________

---

**2. Por que esse sonho?**

Conta a história. Por que ESSE e não outro? O que muda na tua vida quando tu realizar?

________________________________________________________________
________________________________________________________________
________________________________________________________________
________________________________________________________________

---

**3. Quanto custa exatamente?**

Vai no Google, na concessionária, no site da imobiliária. Pesquisa o valor real. Não chuta.

- Valor total do sonho: **R$ _________________**
- Entrada necessária (se for o caso): **R$ _________________**
- Parcela mensal (se for financiar): **R$ _________________**
- Outros custos relevantes: **R$ _________________**

---

**4. Em quanto tempo tu quer realizar?**

- Prazo: **_________ meses** (a partir de hoje)
- Data alvo: **___/___/______**

---

**5. Quanto tu consegue juntar do teu salário sem matar tua vida?**

Pensa realisticamente. Quanto sobra do teu salário (depois de aluguel, comida, conta, lazer básico) pra guardar todo mês?

- Valor mensal de poupança realista: **R$ _________________**
- Total que tu vai juntar no prazo (item 4): **R$ _________________**

---

### Parte B — O cálculo

**6. Faz a conta:**

- Valor total do sonho (item 3): R$ _________________
- Total que tu junta do salário (item 5): R$ _________________
- **GAP (o que falta):** R$ _________________

Esse GAP é o que a L.M pode te ajudar a cobrir com o Dream Plan.

---

### Parte C — O compromisso

**7. Por que tu acha que MERECE esse bônus?**

A L.M só investe em quem investe na L.M também. O que tu vai entregar de extra pra justificar?

________________________________________________________________
________________________________________________________________
________________________________________________________________

---

**8. O que tu vai fazer DIFERENTE no teu trabalho a partir de hoje pra atingir esse sonho?**

Não vale "vou me esforçar mais". Tem que ser concreto. Vai ligar mais? Vai estudar fora do horário? Vai assumir outra responsabilidade?

________________________________________________________________
________________________________________________________________
________________________________________________________________

---

**9. Como tu quer que a L.M te lembre desse sonho nos momentos difíceis?**

(Tipo de pergunta sutil mas importante. Mostra se ele quer ser cobrado pelo sonho ou se vai achar invasivo.)

Exemplos: "imprime o carro e cola na minha mesa", "no daily, fala quantos contratos faltam", "manda foto do sonho no WhatsApp toda segunda".

________________________________________________________________
________________________________________________________________

---

### Parte D — A assinatura

> Declaro que esse sonho é verdadeiro, calculado com base em valores reais de mercado, e que estou disposto(a) a fazer o que for necessário (dentro dos valores da L.M) para realizá-lo.

**Funcionário:** ____________________________________
**Data:** ___/___/______

---

# PARTE 2 — REUNIÃO DE FECHAMENTO DO DREAM PLAN (dia 53)

Depois do funcionário preencher, vocês marcam uma reunião de 90 minutos pra:

1. **Validar o sonho** (5 min) — faz sentido? Tá calculado direito?
2. **Refazer a matemática junto** (30 min) — abrir planilha, validar valores, ver se tem cenário melhor
3. **Estruturar o bônus L.M** (30 min) — quantos contratos? Em qual prazo? Quanto a L.M paga?
4. **Escrever o contrato** (15 min)
5. **Assinar e colar o sonho na mesa** (10 min) — imprime foto do carro/apartamento/intercâmbio + valor + prazo + assinatura, cola onde o BDR vê todo dia

---

## Matemática do bônus L.M (regra de bolso)

A L.M cobre uma PARTE do GAP, não o GAP inteiro. O funcionário ainda precisa juntar uma parte significativa do salário pra ter "skin in the game".

**Regra sugerida (ajustar conforme caixa):**

| Cenário | L.M cobre |
|---|---|
| Sonho pequeno (até R$30k) | Até 30% do GAP |
| Sonho médio (R$30-100k) | Até 40% do GAP |
| Sonho grande (R$100k+) | Até 50% do GAP |

**Exemplo aplicado (caso Danilo do Davi, adaptado pra L.M):**

- Sonho: Carro de R$150k
- Entrada: R$30k
- BDR junta do salário em 12 meses: R$15k
- **GAP:** R$15k
- **L.M cobre:** R$10k (66% do GAP nesse caso, porque sonho médio com BDR engajado)
- **Meta atrelada:** fechar 20 contratos de Ignição Comercial em 12 meses
- **Comissão sobre os 20 contratos:** 15% × R$5k × 20 = R$15k extra além do salário e dos R$10k de bônus

**Resultado:** BDR ganha R$25k extras em 12 meses + realiza sonho de R$30k de entrada.

---

# PARTE 3 — CONTRATO DE BÔNUS DREAM PLAN

Esse é o documento formal que vai junto. Linguagem mais simples que o Fire Test porque já existe relação de confiança estabelecida.

---

## ACORDO DE BÔNUS DE PERFORMANCE — DREAM PLAN

**Data:** ___/___/______

### 1. Partes

**Beneficiário:**
- Nome: [NOME]
- CPF: [CPF]
- Cargo na L.M: [BDR / Closer / outro]
- Data de efetivação na L.M: ___/___/______

**Concedente:**
- L.M Agência (CNPJ 62.831.134/0001-01)
- Sócios: Matheus Jardim e Valentino Pascual

---

### 2. Objetivo

Este acordo estabelece um bônus financeiro condicionado a performance, com a finalidade de viabilizar a realização do sonho pessoal do Beneficiário, declarado no Formulário Dream Plan anexo a este documento.

---

### 3. Sonho declarado

- **Descrição:** [SONHO DESCRITO PELO FUNCIONÁRIO]
- **Valor total:** R$ [VALOR]
- **Prazo desejado:** [X meses]
- **Data alvo:** ___/___/______

---

### 4. Estrutura do bônus

A L.M Agência se compromete a pagar ao Beneficiário um bônus total de **R$ [VALOR] (___________________ reais)** condicionado ao cumprimento integral das metas descritas no item 5.

**Forma de pagamento:**
- [ ] Pagamento único ao final do prazo
- [ ] Pagamento parcelado a cada [marco de 25% / 50% / 75% / 100%]
- [ ] Outro: ___________________________________

---

### 5. Metas atreladas

Para receber o bônus integral, o Beneficiário precisa atingir, no prazo de [X meses]:

| Meta | Quantidade | Prazo |
|---|---|---|
| Contratos comerciais fechados | [N] | [X meses] |
| Faturamento gerado pra L.M | R$ [VALOR] | [X meses] |
| Manutenção da cultura (sem violação grave dos 5 valores) | Período inteiro | [X meses] |

**Definição de "contrato fechado":** cliente assinou + pagamento inicial entrou no caixa + cliente em status "ativo" no CRM por pelo menos 30 dias.

---

### 6. Pagamento parcial (em caso de cumprimento parcial)

Caso o Beneficiário atinja parcialmente a meta, o bônus é pago proporcionalmente:

| % da meta cumprida | % do bônus pago |
|---|---|
| Menos de 50% | Nenhum bônus |
| 50% a 74% | 50% do bônus |
| 75% a 99% | 80% do bônus |
| 100%+ | 100% do bônus |

---

### 7. Acompanhamento

- **Refresh semanal:** durante o daily de segunda, revisão do progresso (quantos contratos faltam)
- **Marco formal a cada 25%:** reunião curta + reconhecimento público interno
- **Revisão de cenário a cada 6 meses:** caso o sonho mude (ex: inflação no carro, mudança de prioridade), reescrever o contrato

---

### 8. Saída antecipada

- Se o Beneficiário **sair voluntariamente** da L.M antes de atingir a meta, perde direito ao bônus integralmente. Mantém apenas comissões já devidas sobre contratos fechados.
- Se a L.M **desligar o Beneficiário** sem motivo cultural grave, paga o bônus proporcional conforme tabela do item 6 sobre o percentual já realizado.
- Se a L.M **desligar por violação grave de cultura** (linguagem de vítima recorrente, sumiço, mentira, desrespeito a cliente), o bônus é perdido integralmente.

---

### 9. Renegociação

Este acordo pode ser **renegociado a qualquer momento** mediante consenso entre Beneficiário e sócios da L.M. Renegociações precisam ser escritas e assinadas.

---

### 10. Confidencialidade

O Beneficiário se compromete a **não divulgar internamente** o valor exato do seu bônus para outros funcionários da L.M, evitando comparações que possam atrapalhar a cultura. Pode falar do sonho em si — mas não dos valores.

---

### 11. Assinaturas

**Beneficiário:**

_____________________________________
[NOME]

**L.M Agência:**

_____________________________________
Matheus Jardim

_____________________________________
Valentino Pascual

**Local e data:** [CIDADE/UF], ___/___/______.

---

# PARTE 4 — RITUAIS DO DREAM PLAN APÓS ASSINATURA

## Dia da assinatura

1. **Imprimir foto** do sonho (carro, apartamento, intercâmbio — o que for) em A4
2. **Imprimir os números** (sonho + valor + meta + bônus + data alvo)
3. **Colar na mesa do funcionário** (presencial) ou enviar pra ele colar em casa (home office)
4. **Foto coletiva** com a assinatura (opcional, mas marca o momento)

## Refresh semanal (toda segunda no daily, 2 min)

> *"[Nome], quantos contratos tu fechou pro [SONHO]? Quantos faltam? Tu tá no ritmo pra dezembro?"*

Liga o número diário ao sonho de novo. Não deixa virar abstração.

## Marco a cada 25%

A cada 25% de progresso (5 de 20 contratos, 10 de 20, 15 de 20, 20 de 20):

1. **Conversa formal de 30 min** entre Matheus/Valentino e o funcionário
2. **Atualização visual** (gráfico ou bar de progresso impresso, marcado a caneta)
3. **Reconhecimento público interno** no daily da semana ("[Nome] tá a 75% do [SONHO]")
4. **Pequena celebração** (café especial, parabéns, gesto simbólico — não precisa ser grande)

## Quando o sonho é realizado

1. **Celebração coletiva** (almoço, jantar, gesto público forte)
2. **Foto do sonho realizado** com o time (o cara na frente do carro novo)
3. **Post interno** (e externo, se o funcionário topar — vira marketing forte)
4. **IMEDIATAMENTE definir novo Dream Plan** — não deixa o cara sem âncora

Davi: *"O segundo sonho é geralmente maior, porque ele já provou que consegue."*

---

# PARTE 5 — REGRAS DE OURO DO DREAM PLAN

1. **Sonho é território emocional. Trata com respeito.** Se o cara escreveu "comprar uma casa pra minha mãe", trata com a mesma seriedade de um carro de luxo. Não julga, não compara.

2. **Nunca compara Dream Plans entre funcionários.** Por isso a cláusula 10 (confidencialidade). O sonho de um não diminui o sonho do outro.

3. **A L.M paga o bônus mesmo se for difícil.** Quebrar a palavra aqui é matar a cultura inteira. Se prometeu, paga. Se duvida que vai conseguir pagar, NÃO PROMETE.

4. **Não cria Dream Plan pra quem ainda não passou no Fire Test.** Privilégio é depois da prova. Antes disso, vira promessa vazia.

5. **Renegociação é OK. Quebra de palavra não é.** Se o sonho mudou, abre o documento e renegocia formalmente. Mas não suma do compromisso.

6. **A frase de gestão Davi se aplica aqui:**
   > *"Meu intuito é te dar 7 mil por mês, todo mês, no mínimo. É por isso que eu vou cobrar."*

   Cobrança = cuidado. Dream Plan = forma concreta desse cuidado virar resultado.

---

# CHECKLIST PRÉ-ASSINATURA

Antes de assinar o Dream Plan com o funcionário, conferir:

- [ ] Formulário do sonho preenchido por completo
- [ ] Valores validados (não chutados)
- [ ] Matemática refeita junto (planilha aberta)
- [ ] Caixa da L.M aguenta o bônus prometido nas projeções
- [ ] Meta é desafiadora mas alcançável (nem fácil demais, nem impossível)
- [ ] Contrato revisado por advogado (na primeira vez de uso)
- [ ] Variáveis entre `[colchetes]` preenchidas
- [ ] Foto do sonho impressa pra colar
- [ ] Cláusula de confidencialidade explicada em voz alta
- [ ] 3 vias impressas (funcionário, L.M, backup)
- [ ] Testemunha disponível

---

# PRÓXIMOS PASSOS

- [ ] Validar contrato com advogado (uma vez só, depois reutiliza)
- [ ] Criar pasta `LM/Cultura/Dream Plans/` pra arquivar planos assinados
- [ ] Definir Dream Plan do Matheus e do Valentino primeiro (vocês como piloto)
- [ ] Decidir valores de teto do bônus por faixa de sonho (item "Matemática do bônus")

---

## CONEXÕES

- [[Cultura L.M — Manifesto]] — onde aparece o valor 1 (Faz dobrado, sem mandar) que sustenta o Dream Plan
- [[Rotina de Contratação — Modelo Davi (TRX)]] — Etapa 7 (Efetivação) detalha quando aplicar
- [[Template — Acordo Fire Test]] — documento que vem antes desse
- [[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]] — call de origem do método

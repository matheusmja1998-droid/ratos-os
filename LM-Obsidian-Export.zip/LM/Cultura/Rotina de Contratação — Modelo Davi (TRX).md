---
tipo: playbook operacional
empresa: L.M Agência
data: 2026-05-28
fonte: Call Davi (TRX Group) — recording_id 150368387
status: oficial
links:
  - "[[Cultura L.M — Manifesto]]"
  - "[[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]]"
  - "[[LM — Visão Geral]]"
---

# Rotina de Contratação — Modelo Davi (TRX) aplicado à L.M

Esse playbook é a transcrição fiel do que o Davi destrinchou na call de 28/05. Cada bloco abaixo cita o trecho de origem com timestamp do Fathom pra rastreabilidade. Tudo aqui foi falado por ele, não inventado.

---

## Princípios que o Davi bateu forte (regras de cabeceira)

1. **Sem cultura + plano de desenvolvimento, ninguém fica.** ([09:14](https://fathom.video/calls/690927288?timestamp=554))
   > *"Se vocês não tiver a primeira coisa, primeira coisa, cultura, e plano de desenvolvimento para cada profissional atrelado ao plano de cultura de vocês, ninguém fica."*

2. **A empresa precisa ser o veículo pro funcionário realizar o sonho dele.** ([10:12](https://fathom.video/calls/690927288?timestamp=612))
   > *"O cara precisa ver, rapaziada, que a empresa de vocês precisa ser veículo pra ele realizar o objetivo próprio."*

3. **Cadeira ocupada por mediano é cadeira que poderia ser de sênior.** ([19:53](https://fathom.video/calls/690927288?timestamp=1193))
   > *"Quando você tem uma cadeira sendo ocupada por mediano, essa cadeira poderia estar sendo ocupada por cara sênior."*

4. **Demitir rápido se não der match. Cortar antes de criar dependência.** ([20:00](https://fathom.video/calls/690927288?timestamp=1200))
   > *"Eu não crio dependência nenhuma de ninguém."*

5. **Contratação não se acelera. É o ponto mais importante da empresa.** ([1:38:12](https://fathom.video/calls/690927288?timestamp=5892))
   > *"Não aceleraria, porque é muito importante isso, é o principal ponto de uma empresa, crescimento e contratação."*

---

## ETAPA 1 — ATRAÇÃO DE CANDIDATOS

### Onde anunciar a vaga ([25:19](https://fathom.video/calls/690927288?timestamp=1519))

Davi listou 3 canais:
1. **Anúncio pago** (Meta/Google)
2. **Plataformas de contratação**
3. **Comunidade Novo Mercado do Ícaro de Carvalho** — *"é a galera que já tem mínimo de conhecimento de CRM, de própria ligação e tal"*

Para a L.M, ele recomendou começar por anúncio pago. Bootcamp (Lucas) **não pode** porque vocês não são alunos atuais.

### Volume necessário pra montar microtime ([26:42](https://fathom.video/calls/690927288?timestamp=1602))

Davi trabalha com **microtime de 5 pessoas**:
> *"De 4 ou 5, meus números, em 15 dias, ou eles vão embora ou eles integram. Eu sempre contrário. Nesses 15 dias, pelo menos 2 de 5."*

Pra ter 5 efetivado, precisa do funil:
> *"Pra ter 5 efetivado ali, iniciar o período, eu preciso aí de, no mínimo, 15-20 candidaturas e vou fazer umas 10 entrevistas."*

**Funil de hiring do Davi:**
| Etapa | Volume |
|---|---|
| Candidaturas (formulário) | 15-20 |
| Entrevistas | 10-15 |
| Iniciam período de fogo | 5 |
| Sobrevivem (integram) | 2 |

---

## ETAPA 2 — FORMULÁRIO DE FILTRO

### Por que formulário antes de entrevista ([1:08:45](https://fathom.video/calls/690927288?timestamp=2925))

> *"Coloca ali, não trabalha com currículo, esquece currículo, coloca formulário de direcionamento."*
>
> *"Eu gosto de colocar formulário porque no formulário já eu já mato muita coisa. (...) De 30 candidatos que vai ter, eu vou fazer 10 entrevistas. Porque o formulário já me responde muita coisa, o perfil do cara, já me responde a cabeça pouco dele."*

### Perguntas que ele mostrou no formulário dele ([1:09:36](https://fathom.video/calls/690927288?timestamp=4176) em diante)

Davi compartilhou tela mostrando o formulário real dele. Reproduzi aqui as perguntas que apareceram, na ordem em que ele passou:

1. **Nome completo**
2. **Idade**
   - Davi: *"Mais de 26 anos, eu já exijo mais, né, pô, moleque não é novo, já tem experiências."*
3. **Por que você se interessou pela vaga?**
   - Resposta do candidato (exemplo positivo): *"Pela condição financeira e ter mais liberdade e buscar por crescimento profissional."*
4. **Característica principal sua**
   - Exemplo positivo: *"Flexibilidade"* — Davi: *"é o que eu quero."*
5. **Horário de trabalho ideal**
   - Davi corta quem pede horário fechado: *"Horário de trabalho definido daqui já mostra que ele não tem tanto perfil de porra, velho, preciso que você fique até as 10 hoje, porra, não bateu a meta. Esse cara já não tem muito esse perfil."*
6. **O que você espera da vaga?**
   - Davi: *"Estabilidade e previsibilidade — se o cara tiver mais de 30 anos, é mais que aceitável."*
   - *"O que eu espero é mais cisco com crescimento."*
7. **Tipo de demanda que você prefere**
   - Resposta positiva: *"Tarefa objetiva com resultado pré-estabelecido"* — Davi: *"porque o BDR tem o mesmo diário e pronto."*
8. **Qual foi a última coisa que você aprendeu?**
   - Quem responde *"não sei"* → corta direto.
9. **Qual foi o último livro que você leu?**
   - Quem responde *"não sei"* → corta direto.
10. **Copia a sequência de números e habilidades abaixo e preenche a nota na frente (de 1 a 10)**
    - Teste de atenção. Quem faz errado → corta.
11. **Qual sua pretensão salarial?**
12. **Como você se enxerga daqui 2 anos?**
    - Resposta ruim: *"Me enxergo daqui dois anos numa ocupação bem definida."* — Davi: *"Foda-se o que ele vai estar fazendo. Ele quer ter ocupação."*
13. **Por que você deveria ser contratado?**
    - Quem responde *"não sei"* → Davi: *"Ô, lei! Vai tomar no cu, mano. Já dá vontade de xingar o cara."*
14. **Você fez algum curso? Qual?**
15. **6x1 ou 5x2, qual você prefere?**
    - Davi: *"Se o cara me falar 24x7, ele nem entra. Foda-se. Óbvio que não é isso, irmão."* (resposta robótica = corta)

### Como ler o formulário

Davi avalia em 2 dimensões:
- **Profundidade da resposta** (curta + genérica = corta)
- **Sinais de comprometimento real** (orgulho do que faz, capacidade de aprender, expectativa realista)

> *"De 30 candidatos que vai ter, eu vou fazer 10 entrevistas."* — taxa de corte de 66% no formulário.

---

## ETAPA 3 — ENTREVISTA

### A pergunta de abertura do Davi ([1:16:42](https://fathom.video/calls/690927288?timestamp=4602))

> *"O cara cai na minha mesa, irmão. Matheus, pra gente começar, eu quero que você me fale uma única coisa foda que você já fez na sua vida, que você se sente orgulhoso."*

**Por que essa pergunta?** ([1:17:19](https://fathom.video/calls/690927288?timestamp=4639))
> *"Porque se o cara não tem orgulho de si mesmo, e eu não tô falando de grandeza, o que o cara vai pensar? (...) o Danilo me falou: Davi, eu, com 16 anos, eu abri lava-rápido. Durou 40 dias. Não consegui ganhar dinheiro, mas eu, com 16 anos, eu entendi o que ia ser empresário no país. Foi fracasso, mas o moleque com 16 anos abriu lava-rápido. Eu admirei. (...) Acabou, ele tá comigo até hoje."*

A pergunta filtra:
- **Tem orgulho de si mesmo** (mesmo de fracasso bem encarado) → passa
- **Não tem ou não consegue articular** → corta

### A entrevista é pressão do começo ao fim ([1:13:48](https://fathom.video/calls/690927288?timestamp=4428))

> *"Na entrevista, irmão, é pancada o tempo todo, velho. E o cara, em dois minutos eu já defino se o cara tá alinhado ou não tá. Porque eu já começo a falar monte de groselha, já começo a jogar o cara a pressão no cara lá embaixo."*

### Script de pressão real do Davi ([1:13:48](https://fathom.video/calls/690927288?timestamp=4428))

> *"Ó, o negócio é o seguinte, Matheus, eu preciso de você de segunda a segunda, você vai no escritório sete horas da manhã e você vai embora sete horas da noite. Enquanto você não bater meta, você não pode ir embora. Tá alinhado com isso, irmão, tá alinhado que eu te ligar meia-noite se eu esquecer de te pedir relatório."*

**Lógica do exagero (metáfora do caçador de baleia, [1:15:42](https://fathom.video/calls/690927288?timestamp=4542)):**
> *"Tem até uma metáfora, o cara que caçava baleia. O anúncio da vaga dele foi: vamos fazer uma viagem única, não tem volta, a probabilidade de você morrer é 99,9%, você vai passar fome, frio, calor, sede por 40 dias, e o máximo que você pode ganhar dando tudo certo é uma boa história pra contar. Irmão, deu monte de preenchimento, ele foi lá, enfim, deu tudo certo. Só que ele já condicionou o sistema ruim pra que quando a galera entrasse, a galera já entrasse sabendo do que esperar."*

**Aplicação:** condicionar o pior cenário possível. Se o cara topa o pior, vai topar a realidade (que é melhor). Se trava, sai antes de custar.

---

## ETAPA 4 — TESTE DE FOGO (45 DIAS)

### Estrutura financeira exata ([10:55](https://fathom.video/calls/690927288?timestamp=655))

> *"45 dias o cara fica no teste de fogo, 100% comissionado, 15% do que eu recebo, não é da minha venda."*

**Explicação do Davi sobre o 15%:** ([11:15](https://fathom.video/calls/690927288?timestamp=675))
> *"Porque a gente fecha contrato aqui de 30 mil, de 70 mil no MRR anual inteiro. Pô, como que eu vou pagar 15% de 10 mil pro cara, sendo que eu estou recebendo 3 mil por mês, 4 mil por mês? Não fecha. Então, eu pago 15% do que eu recebo no upfront e o MRR da mensalidade."*

**Estrutura final:**
- 15% do **upfront** (o que entrou no caixa na assinatura)
- 5% do **MRR vitalício** (enquanto o cliente paga, o BDR recebe)

> *"Pô, o Matheus vendeu contrato pra mim de 60 mil, 5 pau por mês, e eu recebi 10 na hora. Ele vai receber 15% dos 10 que eu acabei de receber. Enquanto esse cliente estiver pagando a mensalidade pra mim, ele vai receber 5% de comissão junto. Então ele criou uma recorrência comigo."*

### Meta dos 45 dias ([12:09](https://fathom.video/calls/690927288?timestamp=729))

> *"O cara tem uma meta de fechar 3 contratos, 2 contratos, 5 contratos, depende do nível do profissional que eu estou contratando, do BDR, se ele é júnior, sênior ou pleno."*

Decisão de nível depende do volume de candidaturas e qualidade. Pra L.M (BDR júnior partindo do zero), sugestão: meta de **2-3 contratos fechados** nos 45 dias.

### Bônus diário/semanal — o que segura o cara ([12:35](https://fathom.video/calls/690927288?timestamp=755))

> *"O que eu trago pro cara não desistir até ter a conclusão desses fechamentos e ele não começar a olhar pra fora? Eu começo a bonificar esse cara pelo trabalho que ele realiza e não depender 100% de terceiro."*

> *"Porque o trabalho dele só vai dar resultado dependendo de filho da puta que talvez ele pode fechar. Então, fazendo isso em conjunto, gente traz muita bonificação semanal, diária."*

**Sistema de bônus do Davi:**
> *"Todo dia aqui o primeiro que bate 5 agendamentos, eu mando o pico de 150, 200, 100, 30, foda-se, depende de como tá o caixa da empresa. Mas eu vou criando essas bonificações."*

**Meta de bonificação semanal:** R$500/semana por BDR.

**Composição do salário do Danilo (BDR do Davi):**
- Bônus semanal: ~R$1.200/semana (R$300 × 4 = R$1.200/mês de bônus)
- Fixo: R$1.500/mês
- Comissão de fechamento: 8% de R$20 mil (exemplo) = R$1.600
- **Total: ~R$4.300-5.000/mês**

> *"Cara vê que comigo, ele trabalhando, só ligando, fazendo 70 ligação por dia, 100 ligaçãozinha por dia, ele vai estar muito mais feliz, ganhando muito mais."*

---

## ETAPA 5 — PRIMEIRA REUNIÃO DE ONBOARDING (dia 1 do Fire Test)

Embora o Davi não tenha descrito passo-a-passo a "primeira reunião", ele deixou claro o **conteúdo obrigatório** dela. Montei abaixo a estrutura derivada do que ele falou, na ordem que faz sentido executar:

### Bloco 1 — Pressão de condicionamento (revisão da entrevista) ([1:15:42](https://fathom.video/calls/690927288?timestamp=4542))

Repetir as condições extremas que ele topou na entrevista, agora em tom de contrato verbal:

> *"Você topou trabalhar de segunda a segunda. Você topou eu te ligar meia-noite se eu esquecer relatório. Você topou. Tá confirmado?"*

**Por quê:** ancorar o pior cenário pra que a realidade (que é melhor) pareça leve depois.

### Bloco 2 — Cultura e valores ([1:21:45](https://fathom.video/calls/690927288?timestamp=4905))

> *"Coloca os valores de vocês dois, depois apresenta para o outro e aí vai tangibilizando. Deixa 10 no máximo no começo, valores, princípios, tudo bonitinho. E todo mundo que contratar já vai entrar nesse formato. Acabou, aí é só manter gestão e performance."*

**Aplicação L.M:** ler os 5 valores do manifesto em voz alta (já existe). Pessoa lê em voz alta, sócio acompanha, para em cada valor e pergunta *"isso fica de pé pra ti?"*. Última chance de desistir antes de começar.

### Bloco 3 — Plano de Desenvolvimento (Dream Plan) ([14:18](https://fathom.video/calls/690927288?timestamp=858) em diante)

**Importante:** o Davi falou explicitamente que o Dream Plan **só entra depois do Fire Test**, quando o cara já provou que dá pra ficar:

> *"Bateu lá, tudo certinho, enfim, deu certo, atualizei o contrato dele com o Fixo. Eu dou uma semana para o Matheus listar sonho dele bem, de bem material mesmo."*

**Mas mencionar o Dream Plan na primeira reunião** funciona como cenoura. Algo tipo:

> *"Olha, nos primeiros 45 dias é Fire Test. Você só tem comissão. Mas depois desse período, se você passar, eu pego o sonho que você listou no formulário e a gente estrutura um bônus específico pra tu realizar. Tem BDR aqui (referência ao Danilo) que vai comprar Jetta de R$320k até o final do ano. Esse é o jogo."*

**Detalhamento do método Dream Plan** ([14:18](https://fathom.video/calls/690927288?timestamp=858)):

> *"Matheus chega para mim e fala: pô, eu quero comprar essa Mercedes de 200 mil. Qual a entrada, Matheus? Eu preciso de 30 mil de entrada. Quanto que é a parcela? Pô, vai, sei lá, carro de 200 mil, se eu der 50 mil de entrada, financiar 150, vai ficar uns 4 mil de parcela. Você precisa ganhar 10, pelo menos."*
>
> *"Nessa hora, eu pego a jornada dele diária de desenvolvimento e crio bonificações exclusivas pra esse cara pra que atingindo a gente vai ganhando dinheiro pra primeiro fazer plano pra entrada e depois fazer plano de salário dele de 10 mil."*

> *"Eu tangibilizo o sonho do cara no trabalho cotidiano dele."*

**Exemplo concreto que ele citou (Danilo, o do Jetta):** ([16:30](https://fathom.video/calls/690927288?timestamp=990))
- Sonho: Jetta R$320k
- Entrada necessária: R$50k
- Danilo junta: R$25k do salário até novembro/dezembro
- TRX promete: R$25k de bônus se fechar 45 contratos no período
- Resultado: Danilo realiza o sonho + nunca mais sai

### Bloco 4 — Acordo financeiro Fire Test (assinar tudo)

Formalizar por escrito (não precisa de cartório, mas papel assinado):
- 45 dias 100% comissão
- 15% do upfront + 5% do MRR vitalício
- Bônus diários (ex: R$150 pelo 1º a bater 5 agendamentos)
- Meta de 2-3 contratos fechados no período
- Critério de aprovação ao fim dos 45 dias

### Bloco 5 — Setup operacional

- Acesso a CRM, dialer, base de leads
- Apresentação do script base (que o Valentino domina, [23:11](https://fathom.video/calls/690927288?timestamp=1391))
- Definição do primeiro dia útil + horário daily

### Bloco 6 — Demonstração de prospecção ao vivo (técnica do Valentino, [23:11](https://fathom.video/calls/690927288?timestamp=1391))

> *"Eu fui assim dar as boas-vindas, em call, marquei 11 agendamentos na frente dele, no primeiro dia, em duas horas."*

Davi reagiu a isso como **uma das maiores forças da L.M**. Faz parte do onboarding: Valentino prospecta na frente do novo BDR, mostra que o método funciona, mata medo, dá referência prática.

---

## ETAPA 6 — ACOMPANHAMENTO DURANTE OS 45 DIAS

### Daily diária (mencionado em todo o método dele)

Davi não descreveu o formato exato da daily com BDRs em treino, mas mostrou como faz com cliente (que pode ser adaptado):

> *"Tem monte de cliente aqui que o cara me paga 3, 4 mil por mês, eu faço daily por dia de 15 minutos. Ó Matheus, você vai fazer isso, isso, isso, como foi ontem, tal, como que vai ser hoje. Beleza, só isso. E foda-se, e tá lá 4 mil na minha mesa."* ([32:42](https://fathom.video/calls/690927288?timestamp=1962))

**Estrutura sugerida pra L.M (15 min, todo dia útil):**
1. Número de ontem (ligações, agendamentos, contratos)
2. Plano de hoje
3. Onde tá travando
4. Recado/treino do dia (Valentino aproveita pra calibrar)

### Bonificação aplicada diariamente

Davi reforçou que o bônus é o que **mantém o BDR no ritmo** durante o período sem fixo:

> *"Todo dia aqui o primeiro que bate 5 agendamentos, eu mando o pico de 150, 200, 100, 30."* ([12:55](https://fathom.video/calls/690927288?timestamp=775))

**Aplicação L.M (sugestão inicial, ajustar conforme caixa):**
- R$100 pelo primeiro a bater 5 agendamentos no dia
- R$200 pelo primeiro a fechar a primeira reunião com R2 agendada
- R$300 pelo primeiro contrato fechado da semana

### Checkpoints

Embora o Davi não tenha citado checkpoints formais, ele descreveu o padrão dele de **acompanhamento contínuo + corte preventivo**:

> *"Pô, eu tô com BDR aqui e o Valentino trouxe o cara. E eu vejo que esse cara não tá alinhado e eu já corto o cara antes. Eu não crio dependência nenhuma de ninguém."* ([20:00](https://fathom.video/calls/690927288?timestamp=1200))

**Aplicação L.M:**
- **Dia 15:** revisar atividade (volume de ligações, agendamentos). Se piso não bateu, conversa séria. Se claramente não vai dar, corta.
- **Dia 30:** revisar resultado (R2s realizadas, primeiro contrato). Se não trouxe nada, corta antes do dia 45.
- **Dia 45:** decisão final — efetiva ou encerra.

### Métrica de integração que a L.M já alcança

> *"Tempo de integração no mercado, rapaziada. No nosso mercado é 90 dias. Tem top 1, top 2 na comunidade que leva 90 dias pra integrar o BDR. Se vocês fazem o cara sair de zero a sete agendamentos por dia, vocês estão levando o cara de zero a pleno/sênior em 30. Vocês estão muito bem."* ([22:15](https://fathom.video/calls/690927288?timestamp=1335))

**Implicação:** o Fire Test de 45 dias da L.M dá tempo suficiente, porque o Valentino integra mais rápido que a média do mercado.

---

## ETAPA 7 — EFETIVAÇÃO (dia 46 em diante)

### O momento da virada

> *"Atualizei o contrato dele com o Fixo."* ([14:00](https://fathom.video/calls/690927288?timestamp=840))

**Estrutura financeira pós-efetivação (modelo Danilo):**
- Fixo: ~R$1.500/mês (BDR júnior)
- Comissão: mantém 15% upfront + 5% MRR vitalício
- Bônus diário/semanal: continua, com meta de R$500/semana de bonificação
- Bônus Dream Plan: agora ativado com a meta de longo prazo

### Onboarding do Dream Plan (semana 1 pós-efetivação)

> *"Eu dou uma semana para o Matheus listar o sonho dele bem, de bem material mesmo, apartamento, carro, a porra que for."* ([14:18](https://fathom.video/calls/690927288?timestamp=858))

**Estrutura:**
1. Pessoa tem 7 dias pra trazer sonho material concreto + quantia
2. Sócios fazem a matemática (entrada, parcela, salário necessário)
3. Quebram a meta em quantidade de contratos fechados no período
4. Definem bônus que cobre uma parte significativa do gap
5. Assinam o "contrato do sonho" e colam na mesa do BDR

---

## ETAPA 8 — RETENÇÃO DE LONGO PRAZO (Dream Plan ativo)

### Por que ninguém sai do TRX ([21:54](https://fathom.video/calls/690927288?timestamp=1314))

> *"Nunca cara chegou para mim... Eu, Davi, tchau. Nunca, nunca, nunca."*

> *"Eu vou ofertar 100 reais a mais, eu vou tirar ele de vocês. Vai vir concorrente, vai ligar pro Matheus, vai ligar pro Valentino e falar: irmão, vem pra cá. Aí você tá se fudendo."* ([17:54](https://fathom.video/calls/690927288?timestamp=1074))

A diferença é o Dream Plan. Quando o cara sai, perde o sonho inteiro, não só o salário.

### O caso de exceção do Davi ([22:30](https://fathom.video/calls/690927288?timestamp=1350))

A única BDR que ele perdeu (foi pra Rugido):
> *"Os caras meteram 4 pau e meio de fixo para ela, e foda-se. Eu não consegui. Mas ela era uma KBDR que me colocava 15 a 18 preenchimentos por dia. Aí, irmão, a hora que a pessoa tem esses números no CRM, ela manda para uma empresa. Acabou, irmão, não segura."*

**Lição:** existe limite financeiro pra retenção. Quando o BDR vira top de mercado, ou tu sobe ele de cargo (closer, head) ou ele vai. O Dream Plan compra muito tempo, mas não é eterno.

### O upgrade natural do BDR ([15:48](https://fathom.video/calls/690927288?timestamp=948))

> *"Óbvio que não existe BDR pra ganhar 10 mil reais. O que esse cara vai precisar fazer? Vai precisar depois de BDR vir pra closer. Depois de closer ele pode ser puta closer e aí dá pra ele construir salário de 10 mil tranquilamente. Ou ele vai ter que ser head, vai ter que ser sócio meu e trazer alguma coisa pra gente investir."*

**Plano de carreira derivado:**
1. **BDR** (R$3-5k total) → 0-12 meses
2. **Closer** (R$5-10k total) → 12-24 meses
3. **Head / Sócio em projeto novo** (R$10k+) → 24+ meses

---

## ETAPA 9 — METAS E RITMO DE EXECUÇÃO

### A meta firme do Davi pra L.M ([1:25:30](https://fathom.video/calls/690927288?timestamp=5130) e [1:28:20](https://fathom.video/calls/690927288?timestamp=5300))

> *"Se vocês não fechar o ano faturando mais de 100 mil, é negligência, de verdade."*

> *"Não é muito, rapaziada. É 15 vendinha de 7 mil, 6 mil. É 15 vendinha, não é nada. Vocês estão batendo 10 agendamentos por dia. Se você tá com efetividade ali de 35%, pra fechar 15 e contratir, você precisa de 45 reuniões por mês. Gente, é 20 dias, duas reuniões por dia."* ([1:29:09](https://fathom.video/calls/690927288?timestamp=5349))

### Ritmo de trabalho ([1:21:54](https://fathom.video/calls/690927288?timestamp=4914))

> *"Trabalha 15 horas por dia. Se não trabalhar 15 horas, não dá."*

---

## ETAPA 10 — DIVISÃO DE RESPONSABILIDADES (sócios) ([1:21:45](https://fathom.video/calls/690927288?timestamp=4905))

> *"Tá muito alinhado pelo que vocês falaram, entrega, o comercial. Agora, só contrata, divide as responsabilidades de cada e olha pra isso. Eu acho que os dois fazer pouco de tudo é pouco complexo. Agora, se cada tiver na sua área de responsabilidade, consegue até cobrar o outro e exige o outro, então cria senso de responsabilidade mais foda."*

Já existe a divisão (Matheus = Vendas/Nimoto, Valentino = Prospecção/Adriano), confirmada no manifesto. Aprofundar.

---

## ETAPA 11 — POSTURA DE LÍDER (mentalidade do Davi)

### O líder não precisa ser amigo primeiro ([1:18:00](https://fathom.video/calls/690927288?timestamp=4680))

> *"Eu falo também na integração, irmão, não me importa se você vai me achar bosta, se você não vai ser meu amigo, eu não me importo com nada disso. Eu me importo em colocar dinheiro no seu bolso e tirar sua performance."*

> *"Quero que no final de semana você durma, descansa, fica puto, mas que quando a gente alinhar o seu pagamento, você recebe 7, 8, 10 mil por mês. Esse é o meu objetivo."*

### Postura final que ele bateu ([1:38:23](https://fathom.video/calls/690927288?timestamp=5903))

> *"Amigo do cara antes de ser líder, a amizade vai vir propriamente pelo respeito que ele vai ter por vocês. Foda-se se ele vai gostar, não. Fala isso, cara: eu não tô nem aí, você vai me xingar a noite, meu intuito é te dar 7 mil por mês, todo mês, no mínimo. É por isso que eu vou te xingar, é por isso que eu vou cobrar, é por isso que se você for embora sem bater meta, eu vou ficar puto."*

---

## RESUMO EXECUTIVO — PASSO A PASSO DO PRIMEIRO HIRE L.M

1. **Subir anúncio de vaga BDR** (Meta + Google) — meta de 20 candidaturas em 1 semana
2. **Formulário pré-entrevista** com 15 perguntas do Davi (replicar acima) + 5 valores do manifesto pra leitura prévia + Dream Plan inicial
3. **Triagem assíncrona** (Valentino) — cortar 66% baseado em profundidade de resposta
4. **Entrevista de pressão** (Matheus ou Valentino) — abrir com "me conta uma coisa foda que tu já fez", aplicar o script extremo, ver se topa
5. **Reunião de onboarding (dia 1)** — pressão, valores, plano de desenvolvimento, contrato Fire Test assinado, demonstração de prospecção ao vivo
6. **Fire Test 45 dias** — daily 15 min, bônus diários, checkpoints dia 15/30/45
7. **Decisão final** — efetiva ou corta
8. **Pós-efetivação** — semana 1 = construir Dream Plan, contrato com fixo + comissão + bônus + Dream Plan ativado
9. **Plano de carreira** — BDR → Closer → Head/Sócio em 24+ meses
10. **Retenção contínua** — Dream Plan sempre na mesa, revisão semanal de quanto falta pro sonho

---

## ANEXOS (a criar)

- [ ] Formulário do Davi adaptado pra L.M (Typeform ou Google Forms)
- [ ] Roteiro completo da Entrevista de Pressão (script Matheus/Valentino)
- [ ] Template do Acordo Fire Test (papel assinado)
- [ ] Template do Dream Plan (formulário + contrato de bônus)
- [ ] Anúncio da vaga (copy + criativo) pra Meta/Google

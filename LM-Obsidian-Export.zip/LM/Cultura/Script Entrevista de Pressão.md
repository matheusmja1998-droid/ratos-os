---
tipo: script operacional
empresa: L.M Agência
data: 2026-05-28
status: oficial
contexto: Script de entrevista de hiring baseado no método do Davi (TRX) — Bloco 4 das ações pós-call
links:
  - "[[Cultura L.M — Manifesto]]"
  - "[[Rotina de Contratação — Modelo Davi (TRX)]]"
  - "[[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]]"
---

# Script da Entrevista de Pressão — L.M

> Script não é literal — é um arsenal de pressão. Tu escolhe quais cartas joga dependendo de como o candidato responde. Mas a estrutura abaixo é a sequência que o Davi seguiria se entrevistasse pra L.M.

Tempo total: **20-30 minutos**, nunca mais que isso.

---

## Pré-call (2 min antes)

Antes de entrar, tu confere:
- Formulário do candidato aberto
- Resposta dele em "última coisa que aprendi" e "último livro que li" — vai usar pra cobrar
- Resposta dele em Dream Plan — vai usar pra ancorar
- **Estado pessoal** (manifesto valor 3): se tu não tá no nível, **remarca**. Entrevista mal feita queima candidato bom.

---

## ABERTURA (min 0-3) — Sem aquecimento, direto

> *"E aí, [nome]. Tudo bem? Vamos direto ao ponto que meu tempo é curto e o teu também. Antes de qualquer coisa, eu quero que tu me conte UMA coisa foda que tu já fez na vida e que tu se sente orgulhoso. Pode ser do trabalho, pode ser pessoal, pode ser fracasso, mas que TE marcou. Pensa 30 segundos e me conta."*

### Como ler a resposta

| Resposta | Diagnóstico | O que fazer |
|---|---|---|
| Trava, não consegue responder | Sem orgulho de si mesmo. Não tem âncora interna. | **Corta**. Termina educado em 5 min e some. |
| Resposta vaga ("fui promovido", "fiz faculdade") | Não tem história própria, só conquista comum | Faz 1 pergunta de aprofundamento. Se continuar raso, **corta**. |
| Resposta com história específica (mesmo fracasso) | **Tem orgulho de quem é**. Esse é o ouro. | **Continua a entrevista**. |

**Exemplo de resposta boa (caso real do Davi):**
> *"Cara, eu abri um lava-rápido com 16 anos. Durou 40 dias, quebrou, mas eu entendi com 16 anos o que era ser empresário."*

Davi contratou esse cara (Danilo) na hora. Tá com ele até hoje, vai comprar Jetta R$320k.

---

## BLOCO 1 — Cobrar o formulário (min 3-7)

Pegar 2-3 perguntas do formulário e **bater forte** em cima. Não é amigável. É teste.

### Pergunta 1 — Última coisa que aprendeu
> *"Tu colocou no formulário que a última coisa que aprendeu foi [X]. Me conta: o que mudou na tua rotina depois que tu aprendeu isso? Tu aplicou em algum lugar?"*

**Se ele não consegue aplicar:** *"Então tu leu, não aprendeu. Aprender é mudar comportamento. Pensa de novo: qual a última coisa que mudou de verdade na tua rotina por algo que tu estudou?"*

### Pergunta 2 — Último livro
> *"Falou [livro X]. Resume pra mim em 2 minutos a ideia central do livro. Não a história. A ideia."*

**Se ele não consegue:** tá lendo por aparência ou tá mentindo. Anota mentalmente e segue.

### Pergunta 3 — Por que deveria ser contratado
> *"Tu respondeu [resposta dele]. Cara, [Fulano da concorrência] também responderia isso. O que TU tem que ninguém mais tem? Por que eu vou contratar TU e não outro?"*

**Pressão real:** força ele a achar a diferenciação dele. Quem trava aqui não vai bater meta porque não consegue se vender pra cliente também.

---

## BLOCO 2 — Apresentar o cenário extremo (min 7-12)

Aqui é a parte do **caçador de baleia**. Tu condiciona o pior cenário possível. Lê pausado, sem sorrir.

> *"Beleza, [nome]. Agora eu vou ser bem direto contigo pra tu saber no que tá entrando. Lê bem o que eu vou falar."*

> *"Os primeiros 45 dias na L.M são teste de fogo. Cem por cento comissão. Sem fixo. Sem garantia. Se tu não fechar contrato, tu não ganha nada além dos bônus diários que eu vou explicar."*

> *"Eu preciso de tu de segunda a segunda. Tu vai ligar 70, 100 vezes por dia. Tu vai ouvir 'não' 80% das vezes. Tu vai começar 8h da manhã e vai embora quando bater a meta do dia — não quando der o horário."*

> *"Se eu esquecer de pedir teu relatório à meia-noite, eu vou te ligar à meia-noite. Tu vai atender. Não me importa se tu tá dormindo, se tu tá com a namorada, se tu tá no aniversário do teu pai. Se a meta do dia não bateu, tu tá trabalhando."*

> *"Eu não vou ser teu amigo. Eu vou te xingar. Eu vou cobrar feio. Tu vai chegar em casa cansado, vai ficar puto comigo. Tudo bem. Meu objetivo aqui não é tu gostar de mim. Meu objetivo é tu botar R$7k, R$8k, R$10k no bolso todo mês daqui 6 meses. Se isso acontecer, tu vai me agradecer. Se não acontecer, tu vai me odiar e tudo bem também."*

**Pausa. Olha pra cara dele.**

> *"Tu tá topando até agora?"*

### Como ler a reação

| Reação | Diagnóstico |
|---|---|
| "Topo, sim, isso é o que eu procuro" — rápido demais | Tá vendendo. Não absorveu. Aprofunda. |
| Trava, hesita, faz cara feia | Real. Tá processando. **Esse pode passar.** |
| "Pera aí, e o final de semana?" | Saudável. Tem limite. Boa pergunta. |
| "Eu não trabalho final de semana, isso é abuso" | Honesto. **Corta**. Não é pra L.M. |
| Sorriso amarelo, "tá bom, tá bom" | Tá com medo de perder a vaga. **Corta**. Vai sumir no dia 10. |

---

## BLOCO 3 — Aprofundar a pressão (min 12-17)

Se ele sobreviveu ao bloco 2, agora tu **tira a máscara da pressão** e mostra a lógica.

> *"Por que eu te falo isso tudo? Porque eu já contratei errado antes. Já trouxe cara que parecia bom no papel, falou que era movido a pressão, falou que queria crescer. No dia 10 sumiu. No dia 15 mandou áudio chorando dizendo que não dava conta. No dia 20 já tava trabalhando em outra empresa falando mal da L.M no LinkedIn."*

> *"Então a única pergunta que importa agora é essa: tu tá entrando aqui porque tu QUER esse jogo, ou porque tu PRECISA de qualquer emprego?"*

**Pausa.**

> *"Não tem resposta certa. Quem precisa pode topar e crescer aqui também. Mas eu preciso saber qual dos dois é tu. Porque o meu tratamento muda."*

### O que tu procura

- **"Eu QUERO esse jogo"** + explica por quê com convicção → ouro
- **"Eu PRECISO"** + honesto sobre situação financeira atual → respeitável, pode dar bom
- **"Os dois"** + consegue articular → pensa antes de falar, bom sinal
- **Resposta evasiva** → não pensou direito. Corta.

---

## BLOCO 4 — Ancorar no Dream Plan (min 17-22)

Agora tu pega o Dream Plan que ele colocou no formulário e mostra **como a L.M é o veículo**.

> *"Tu colocou no formulário que tu quer [SONHO X] que custa [R$Y] em [PRAZO Z]. Conta mais pra mim sobre isso. Por que esse sonho?"*

Deixa ele falar. Não interrompe. Sonho é território emocional — tu tá vendo se ele consegue verbalizar com clareza ou se é só resposta vazia.

**Depois ele falar, tu calcula ao vivo:**

> *"Olha só. Tu quer [R$Y] em [Z meses]. Isso é [R$X] por mês de extra que tu precisa fazer."*

> *"Aqui na L.M, no Fire Test, se tu fechar [N contratos] de R$7k, tu recebe [R$X] de comissão upfront. Mais bônus diário/semanal. Mais 5% MRR vitalício do cliente."*

> *"Depois do Fire Test, se tu passar, a gente estrutura um bônus específico em cima desse sonho teu. Tem BDR que tá comprando Jetta de R$320k até dezembro. Outro tá fazendo intercâmbio. Outro tá comprando o primeiro apartamento."*

> *"Então a pergunta é: tu vê a L.M como um lugar onde tu vem cumprir 8h de trabalho, ou como o veículo que vai te levar pra [SONHO X]?"*

### O que tu procura

- Ele se acende falando do sonho → **passa**
- Ele responde com profissionalismo robotizado → não tem motor → **corta**
- Ele já começa a fazer conta junto contigo → **ouro, contrata na hora**

---

## BLOCO 5 — Reverter a pressão (min 22-26)

Agora tu **inverte o jogo**. Em vez de tu vender a vaga, ele tem que vender ele.

> *"Beleza, [nome]. Eu já te falei o que tu vai ter que aguentar e o que tu pode ganhar. Agora eu quero saber TU. Por que a L.M deveria escolher TU em vez dos outros 10 candidatos que tô entrevistando essa semana?"*

> *"Eu não quero ouvir 'sou esforçado, sou dedicado, sou comprometido'. Todo mundo fala isso. Eu quero UMA coisa que tu sabe que se eu te contratar, EU vou ganhar. E que se eu contratar outro, eu não vou ganhar."*

**Pausa. Espera.**

### O que tu procura

- Ele puxa uma habilidade concreta + impacto mensurável → **passa**
- Ele puxa um diferencial pessoal real (não chavão) → **passa**
- Ele repete o que disse no formulário, sem profundidade → **corta**
- Ele faz pergunta inteligente em vez de responder → **ouro** (mostra que ele tá pensando estratégico)

---

## BLOCO 6 — Fechamento e decisão (min 26-30)

### Se tu vai aprovar:

> *"Beleza, [nome]. Pelo que tu falou, eu vejo encaixe. Mas eu nunca decido na hora. Eu vou conversar com meu sócio, vou olhar de novo tuas respostas, e eu te dou retorno em até 48h. Se for sim, eu te explico o Fire Test em detalhe e a gente marca o dia 1."*
>
> *"Tem alguma pergunta tua pra mim antes de encerrar?"*

A pergunta dele aqui também filtra:
- *"Quando começa?"* → bom, prático
- *"Tem benefícios? Vale refeição?"* → corta, perfil errado
- *"Como vocês treinam? Como é a primeira semana?"* → ouro, quer performar

### Se tu vai cortar:

> *"[Nome], obrigado pelo tempo. Vou ser honesto contigo: pelo que eu vi aqui, eu não acho que tu vai ser feliz na L.M e nem que a gente vai conseguir te entregar o que tu precisa. Não é demérito teu, é encaixe mesmo. Vou te dar retorno formal por email em 48h, mas já adianto que não vai dar match."*

Cortar na cara dói mais, mas é mais respeitoso que sumir. E protege a reputação da L.M no mercado.

---

## REGRAS DE OURO DURANTE A ENTREVISTA

1. **Nunca sorri no bloco 2.** Pressão precisa parecer real, não brincadeira.
2. **Olha nos olhos, não na câmera.** Câmera dá distância. Olho intimida no bom sentido.
3. **Pausa longa depois de pressão.** Quem é raso preenche silêncio. Quem é forte aguenta.
4. **Anota tudo no notion/papel.** Volta depois pra avaliar com cabeça fria.
5. **Nunca aprova na hora.** Mesmo se for o melhor candidato, fala "decido em 48h". Cria respeito e tempo pro Valentino opinar.
6. **Cortar é mais barato que segurar errado.** Custou 30 min cortar. Vai custar 3 semanas segurar errado.

---

## CHECKLIST PÓS-ENTREVISTA (5 min depois)

Tu para 5 min imediatamente depois e responde:

1. **Ele tem orgulho de si mesmo?** (bloco 0) — sim/não
2. **Ele leu/aprendeu de verdade ou tá fingindo?** (bloco 1) — sim/não
3. **Ele consegue se diferenciar?** (bloco 1 + 5) — sim/não
4. **Ele topou o cenário extremo de verdade ou tava vendendo?** (bloco 2) — sim/não
5. **Ele explica o sonho com brilho no olho?** (bloco 4) — sim/não
6. **Ele faz pergunta inteligente no fechamento?** (bloco 6) — sim/não

**Regra de decisão:**
- 5-6 sim → contrata
- 3-4 sim → 50/50, discute com Valentino
- 0-2 sim → corta

---

## CONEXÕES

- Base cultural: [[Cultura L.M — Manifesto]]
- Playbook completo de hiring: [[Rotina de Contratação — Modelo Davi (TRX)]]
- Call original: [[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]]

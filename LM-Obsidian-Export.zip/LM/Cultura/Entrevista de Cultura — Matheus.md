---
tipo: entrevista cultura
data: 2026-05-28
entrevistado: Matheus Jardim
contexto: Base pra construir Missão, Visão e Valores da L.M Agência
status: respondido
proximo_passo: entrevistar Valentino com as mesmas perguntas e cruzar
links:
  - "[[LM — Visão Geral]]"
  - "[[2026-05-28 — Call Davi (TRX) — Destrava Time e Produtização]]"
---

# Entrevista de Cultura — Matheus

Respostas do Matheus pra base de Missão, Visão e Valores da L.M. Próximo passo: Valentino responde as mesmas 16 perguntas, cruza as respostas e fecha a cultura.

---

## Bloco 1 — Visão de futuro e identidade

**1. Visão de 3 anos da L.M:**
Máquina escalável, 30+ pessoas, virou case no mercado solar.

**2. O que dá orgulho de verdade (mais que faturamento):**
- A qualidade do que a gente entrega — cliente sai outro
- Construir algo que vai durar e virar referência

**3. Linha vermelha — não tolera de jeito nenhum:**
- Linguagem de vítima (mercado, cliente, ninguém me avisou)
- Preguiça intelectual (não estudou, não testou, repete erro)
- Falsa modéstia / falta de ambição

**4. Cliente ideal:**
Empresa estruturada que precisa só destravar gargalo específico. Já tá rodando, tem time, só precisa de cirurgia comercial. Implementação rápida.

---

## Bloco 2 — Comportamento sob pressão e legado

**5. Como tu quer que sintam ao trabalhar contigo:**
Exigido no limite, mas respeitado. Pressão construtiva — cobra duro, mas a pessoa sai melhor.

**6. Decisão difícil que mostra quem tu é:**
Cobrar o Valentino numa parada que ia gerar atrito. Ter conversa difícil com sócio em vez de engolir.

**7. Reação natural quando dá ruim:**
Volume de execução — trabalho dobrado até virar. Força bruta. Roda mais, fecha mais, resolve no esforço.

**8. Legado pro mercado solar B2B:**
"Era a operação comercial mais bem feita que eu já vi." Excelência de execução reconhecida. Padrão benchmark.

---

## Bloco 3 — DNA do time e modo de operar

**9. Quem vai dar certo na L.M (mesmo com técnica boa):**
Fome — quer crescer, não aceita medianidade. Ambição pessoal forte.

**10. Ritmo certo de operar:**
Rápido sempre — melhor errar tentando que ficar pensando. Velocidade > perfeição. Decisão em horas, não dias.

**11. Hábito que separa quem vence:**
Métrica na mesa todo dia (número, não achismo). Acompanha número diário. Decisão por dado, não sensação.

**12. Contra-padrão — onde a maioria erra e a L.M faz diferente:**
Vender o que não consegue entregar. A L.M só vende o que executa.

---

## Bloco 4 — A sociedade e o dia 1

**13. Maior força da dupla Matheus + Valentino:**
Complementaridade real (ele prospecta, tu fecha, sem ego). Cada um no que é bom, sem brigar por espaço. Soma.

**14. Sombra — crítica verdadeira que precisa virar valor:**
Pegam coisa demais — não conseguem delegar. Mão em tudo trava escala. Precisa virar disciplina de soltar.

**15. Frase na parede do escritório:**
"Número na mesa. Hoje." Mantra de execução + métrica. Sem achismo.

**16. Mensagem dia 1 pro novo BDR/vendedor:**
"Teu sonho aqui é levado a sério. A gente constrói junto." Dream Plan vira contrato real. Empresa banca a vida da pessoa.

---

## Padrão emergente nas respostas do Matheus

**Sobre quem ele é:**
Executor de alta velocidade que acredita em força bruta sob pressão, métrica como única verdade e ambição como filtro de pessoas. Tem coragem de conversa difícil (cobrou sócio). Tem a tara da excelência ("operação mais bem feita") sem precisar de holofote.

**Sobre o que ele quer da L.M:**
Não quer boutique de elite. Quer **máquina escalável** com **excelência mantida na escala**. Quer ser benchmark de operação comercial no setor solar, não apenas referência de tráfego.

**Tensão visível:**
- Quer escalar pra 30+ pessoas, mas pega coisa demais (sombra).
- Quer velocidade máxima, mas exige métrica e excelência (precisa de sistema, não só fôlego).
- Quer cliente que decide rápido, mas o ICP "empresa estruturada" geralmente decide devagar (precisa calibrar).

**Sinais fortes pra cultura:**
- Métrica diária é inegociável
- Honestidade comercial é inegociável ("só vende o que entrega")
- Linguagem de vítima é demissão
- Dream Plan é compromisso real, não retórica
- Excelência > volume → mas precisa de volume pra chegar nos 30+

---

## Próximo passo

Aplicar mesmas 16 perguntas no Valentino. Cruzar respostas e identificar:
1. Convergências → viram **valores da L.M**
2. Divergências → viram **decisão consciente** (qual lado vence)
3. Pontos cegos compartilhados → viram **regras de operação** (ex: ambos pegam coisa demais → disciplina de delegar vira sistema)

Depois disso: Missão + Visão + 5 Valores finais. Documento oficial em `LM/Cultura/Cultura L.M — Manifesto.md`.

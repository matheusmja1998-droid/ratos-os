---
tags: [conteúdo, estratégia, lm, instagram, autoridade, integradora, solar]
data: 2026-04-21
status: ativo
---

# Estratégia de Conteúdo — @eumatheusj

## Posicionamento

Matheus Jardim como **referência em comercial B2B para o setor solar**, usando o Instagram pessoal como canal de atração orgânica para a L.M Agência.

O conteúdo não vende serviço diretamente. Ele cria espelho: o dono de integradora se reconhece no problema descrito, chega convencido de que precisa de estruturação comercial, e procura quem escreveu.

**Conta:** @eumatheusj (perfil pessoal)
**Canal principal:** Instagram (carrosséis)
**Público:** donos e gestores de integradoras solares
**Ângulo:** inteligência comercial aplicada ao setor solar

---

## Lógica do conteúdo

O setor solar tem um problema estrutural: a maioria das integradoras foi aberta no boom (2019–2022), quando cliente chegava sozinho. Nunca precisaram montar processo comercial. Quando o mercado desacelerou em 2025, ficaram sem motor de vendas.

O conteúdo explora esse diagnóstico usando dados reais do setor (ABSOLAR, Greener, etc.) pra criar reconhecimento no leitor. Quem lê e se identifica quer falar com quem tem a solução — que é exatamente o que a L.M Agência entrega.

**O conteúdo não precisa mencionar a agência. O follow + DM já é a conversão.**

---

## Fluxo de produção



Todo carrossel é salvo em:


Skills usadas:
- [[.claude/skills/pauta-solar]] — busca pauta com dados do setor solar
- [[.claude/skills/carrossel]] — produz carrossel completo (roteiro + visual + PNG)

---

## Pilares de conteúdo

1. **Diagnóstico de mercado** — dados do setor que expõem problemas estruturais (ex: 72% dependem de indicação)
2. **Espelho** — perguntas que fazem o dono se reconhecer na situação (ex: se a indicação parasse amanhã...)
3. **Processo comercial** — como funciona na prática: SDR, cadência, CRM, prospecção ativa
4. **Casos e bastidores** — o que integradoras que crescem fazem diferente
5. **Contrário** — ângulos que desafiam crenças comuns do setor

---

## Formato padrão do carrossel

- **10 slides** (1080x1350px)
- **Slide 1:** capa impactante, frase curta, gera curiosidade
- **Slides 2–3:** contexto e dado de mercado
- **Slides 4–7:** desenvolvimento, um insight por slide
- **Slides 8–9:** virada / implicação prática
- **Slide 10:** CTA + @eumatheusj

**Identidade visual:** fundo #080808, verde #00E878, fonte Plus Jakarta Sans

---

## Primeiro carrossel produzido

**Tema:** Integradoras que abriram no boom e nunca aprenderam a vender
**Data:** 2026-04-21
**Pauta escolhida via:** skill /pauta-solar
**Arquivo:** 

Dados usados:
- 48% das integradoras ativas foram abertas entre 2019–2022
- 72% dependem de indicação como canal principal (ABSOLAR, 2024)
- 10% das integradoras abertas antes de 2016 ainda estão ativas (Greener, 2026)

---

## Conexão com L.M Agência

O conteúdo do @eumatheusj é o topo de funil da L.M. Integradora que acompanha o perfil:
1. Se identifica com o diagnóstico
2. Entende que o problema é real e tem solução
3. Busca quem tem autoridade no assunto
4. Chega no DM ou pelo link da bio

A L.M entrega exatamente o que o conteúdo promete: estruturação comercial completa (SDR, funil, CRM, cadência de prospecção).



---

## Fluxo de produção (completo)

Passo 1: /pauta-solar — pesquisa tendências do setor + decide tema com ângulo forte
Passo 2: /carrossel — cria roteiro 10 slides + HTMLs estilizados + renderiza PNGs via Playwright
Passo 3: Revisão — ajuste visual ou textual se necessário
Passo 4: Publicação — postar no @eumatheusj com legenda gerada pela skill

Todo carrossel salvo em: conteudo/carrosseis/YYYY-MM-DD_[nome-do-tema]/

Primeiro carrossel: conteudo/carrosseis/2026-04-21_boom-integradora/
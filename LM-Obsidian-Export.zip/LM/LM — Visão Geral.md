---
empresa: LM
tipo: agência
status: ativo
cnpj: 62.831.134/0001-01
faturamento_mensal: 4000
sócio: Valentino Pascual
divisao_societaria: 50/50
atualizado: 2026-04-14
---

# L.M Agência

## Sobre
Nova agência em sociedade com Valentino Pascual. Faturamento atual: R$4.000/mês.
Foco em estruturação comercial B2B para integradoras solares.

**CNPJ:** 62.831.134/0001-01

## Sociedade
- **Matheus Jardim** — 50% · Head de Vendas (papel "Nimoto")
- **Valentino Pascual** — 50% · Head de Prospecção (papel "Adriano")
- Time: apenas os dois sócios (sem SDRs internos)

Alinhamentos:
- [[Societário/2026-05-08 — Alinhamento Sócios (Metas Maio)]]

## Números
- Faturamento mensal: R$ 4.000
- Clientes ativos: 7
- Meta mensal: R$ 50.000 (meta conjunta Matheus — todas as empresas)

## Ofertas

| Produto | Para quem | Preço | Formato |
|---|---|---|---|
| [[Comercial/Ofertas/Ignição Solo/Ignição Solo — Oferta\|Ignição Solo]] | Dono solo, sem time, sem budget | R$ 497 | Sessão 90 min |
| [[Comercial/Ofertas/Ignição Comercial/Ignição Comercial — Oferta Completa\|Ignição Comercial]] | Dono com time, dependente de indicação | R$ 5.000 | 45 dias |

Funil: `Webinar → Diagnóstico → Ignição Solo → Ignição Comercial`

Ver índice completo: [[Comercial/Ofertas/Índice de Ofertas — L.M]]

### Produtos digitais (em desenvolvimento)

- [[00 — Visão Geral|Cockpit — Stack de Tráfego com IA pra Agências e Gestores]] — linha de produtos (Kick, Install, Operation, Black) voltada pra agências e gestores de tráfego
  - [[02 — Esteira e Oferta]] — esteira completa e nomenclatura
  - [[09 — Oferta Cockpit Kick]] · [[10 — Oferta Cockpit Install]] · [[11 — Oferta Cockpit Operation]] · [[12 — Oferta Cockpit Black]]

## Comercial
- Time de vendas: [[Time/]]
- Webinars: [[Comercial/Webinars/]]
  - [[A Era da IA - Roteiro - 2026-05-07]] · [[A Era da IA - Slides - 2026-05-07]]
  - [[Solar de Elite - Roteiro - 2026-04-16]] · [[Solar de Elite - Slides - 2026-04-16]] · [[Solar de Elite - Webinar 2 - 2026-04-16]]
- Reuniões de vendas: [[Comercial/Reuniões de Vendas/]]
  - [[R1 Asafe Energia Solar — Artur Quintas (23-04-2026)]]
  - [[R1 Synergy — Flávio Narezzi (22-04-2026)]]

## Estudos de mercado
- [[Benchmarking Completo — Energia Solar (Setor + Comercial)]] — referência oficial 2025/2026 (dados ABSOLAR/Greener + KPIs + munição de reunião)
- [[Estudo de Mercado - Energia Solar]]
- [[Horários e Regiões - Prospecção Solar]]

## Tecnologia
- [[Prompt Lovable — SaaS Onboarding LM]], prompt-base do SaaS de onboarding

## Treinamentos
- [[Aula - Cultura de Alta Performance]] (Os Escolhidos, Adriano)

## Clientes

| Cliente | Frente |
|---|---|
| [[Jonas — Hypertech (Solar)]] | Solar — meta R$20M |
| [[Dr. Fábio — IOT (Varginha)]] | Ortopedia (estratégia geral) |
| [[Dr. Fábio — Comtato (Google Ads)]] | Ortopedia (mídia paga Google Ads) |
| [[Clínica Contato — Dossiê]] | Reabilitação infantil — conteúdo + criativos |
| [[Rafaelly — Pediatra (Infoprodutos)]] | Pediatra — infoprodutos (sono infantil) |
| [[Daniel Daolio — Meta Mavi (Dossiê)]] | Agência solo de tráfego — Cockpit Setup (30 dias) |

## Financeiro
- [[Financeiro/]]

## Societário
- [[Societário/]]

## Referências de tráfego (estudo)
- [[../Aprendizado/Cursos/Pedro Sobral — Lives Subido/Pedro Sobral — Índice de Lives|Pedro Sobral — Lives do Subido]]
  - [[../Aprendizado/Cursos/Pedro Sobral — Lives Subido/Live 383 — Futuro do trabalho no digital com IA|Live 383 — Futuro do trabalho no digital com IA]]


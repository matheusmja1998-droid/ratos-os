# Como importar isso no teu Obsidian

Fala Valentino. Esse pacote é um export de tudo que tá no Obsidian do Matheus relacionado à **L.M Agência**, mais os livros e cursos que ele já portou pra dentro do vault.

## O que tem aqui dentro

- **LM/** — a pasta inteira da L.M Agência:
  - `Clientes/` — Clínica Comtato (com pesquisa de concorrentes), Daniel Daolio / Meta Mavi, Synergy (com benchmarks em PDF)
  - `Comercial/` — ofertas (Pipeline Comercial, Ignição), ligações, reuniões de vendas, webinars (só as notas)
  - `Cultura/` — manifesto, missão, visão, valores
  - `Societário/` — documentos da sociedade
  - `Tecnologia/` — SaaS de onboarding
  - `Reuniões de Vendas/` — transcrições e análises
  - **`Treinamentos/`** — aqui tá o ouro:
    - `Mentoria Nimoto/` — transcrições completas (Imersão 7h, Call 1, Webinar, R1/R2), CLOSER R1 e R2, fundamentos, MAGIC, nutrição infinita, e a pasta `Análises R1 R2/` com todas as reuniões analisadas pelo framework
    - `Os Escolhidos — Adriano/` — playbook completo + dailies
- **Aprendizado/Livros/** — resumos dos livros: $100M Money Models (Hormozi), SPIN Selling, Neurovendas, Prospecção Fanática, A Vaca Roxa, O Mito do Empreendedor, e outros
- **Aprendizado/Cursos/** — Leonardo Tabari (Turbo Academy) e Pedro Sobral (Lives), com transcrições

> Obs: os projetos de slides web dos webinars (código Vercel + imagens pesadas) ficaram de fora de propósito — eles não viram nota no Obsidian, só pesariam o arquivo. Se precisar deles, é só pedir pro Matheus.

## Passo a passo pra importar

1. Descompacta esse zip num lugar fácil de achar (Desktop serve).
2. Abre o **Obsidian** no teu computador.
3. Tem dois caminhos:

   **Opção A — colar dentro de um vault que já existe:**
   - Abre teu vault no Obsidian
   - Arrasta as pastas `LM` e `Aprendizado` (descompactadas) pra dentro da pasta do teu vault, pelo Finder/Explorer
   - Volta no Obsidian, ele vai indexar tudo sozinho

   **Opção B — abrir como vault novo:**
   - No Obsidian: `Open another vault` → `Open folder as vault`
   - Seleciona a pasta que você descompactou
   - Pronto, tá tudo lá

4. Se quiser que o **Claude** te ajude a navegar/alimentar teu vault com isso, abre o Claude Code apontando pra essa pasta e pede o que precisar (ex: "me resume o método CLOSER do Nimoto", "lista as objeções B2B da Synergy").

Qualquer coisa que faltar, fala com o Matheus.
